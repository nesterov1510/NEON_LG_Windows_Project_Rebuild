package a0;

import android.content.Context;
import android.content.pm.PackageManager;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.os.Build;
import android.util.Log;
import j$.util.Map;
import java.util.ArrayList;
import java.util.LinkedHashMap;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class u1 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final pi.a f338a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final c0.n f339b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final a2 f340c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final pi.a f341d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final kotlinx.coroutines.p0 f342e;
    public final Object f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public ArrayList f343g;
    public final LinkedHashMap h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final LinkedHashMap f344i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final int f345j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final kotlinx.coroutines.flow.l0 f346k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final qi.m f347l;

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r9v7, types: [boolean, int] */
    public u1(pi.a cameraManager, c0.n threads, Context context, PackageManager packageManager, a2 cameraErrorListener, pi.a cameraDeviceSetupCompatFactoryProvider, e0.g cameraPipeLifetime, kotlinx.coroutines.f2 cameraPipeJob) {
        kotlin.jvm.internal.q.g(cameraManager, "cameraManager");
        kotlin.jvm.internal.q.g(threads, "threads");
        kotlin.jvm.internal.q.g(packageManager, "packageManager");
        kotlin.jvm.internal.q.g(cameraErrorListener, "cameraErrorListener");
        kotlin.jvm.internal.q.g(cameraDeviceSetupCompatFactoryProvider, "cameraDeviceSetupCompatFactoryProvider");
        kotlin.jvm.internal.q.g(cameraPipeLifetime, "cameraPipeLifetime");
        kotlin.jvm.internal.q.g(cameraPipeJob, "cameraPipeJob");
        this.f338a = cameraManager;
        this.f339b = threads;
        this.f340c = cameraErrorListener;
        this.f341d = cameraDeviceSetupCompatFactoryProvider;
        kotlinx.coroutines.p0 p0VarCoroutineScope = kotlinx.coroutines.q0.CoroutineScope(kotlinx.coroutines.d3.SupervisorJob(cameraPipeJob).plus(threads.f).plus(new kotlinx.coroutines.o0("Camera2DeviceCache")));
        this.f342e = p0VarCoroutineScope;
        this.f = new Object();
        this.h = new LinkedHashMap();
        this.f344i = new LinkedHashMap();
        int iHasSystemFeature = packageManager.hasSystemFeature("android.hardware.camera");
        int i10 = packageManager.hasSystemFeature("android.hardware.camera.front") ? iHasSystemFeature + 1 : iHasSystemFeature;
        this.f345j = i10;
        p0.e.t("Camera2DeviceCache: Expected minimum camera count = ", i10, "CXCP");
        cameraPipeLifetime.c(e0.e.X, new l0(1, this));
        this.f346k = kotlinx.coroutines.flow.k.shareIn(kotlinx.coroutines.flow.k.distinctUntilChanged(kotlinx.coroutines.flow.k.callbackFlow(new t0(this, (ui.d) null, 2))), p0VarCoroutineScope, kotlinx.coroutines.flow.s0.WhileSubscribed$default(kotlinx.coroutines.flow.t0.Companion, 0L, 0L, 3, null), 1);
        this.f347l = g0.c.w(new q1(0, this));
    }

    public static final void a(u1 u1Var, kotlinx.coroutines.channels.y yVar, String str, boolean z5) {
        ArrayList arrayList;
        Object obj;
        synchronized (u1Var.f) {
            arrayList = u1Var.f343g;
        }
        int i10 = 0;
        ArrayList arrayListD = null;
        if (z5) {
            if (arrayList != null && !arrayList.isEmpty()) {
                int size = arrayList.size();
                do {
                    if (i10 >= size) {
                        Log.i("CXCP", "New camera " + str + " detected");
                        arrayListD = u1Var.d();
                        break;
                    }
                    obj = arrayList.get(i10);
                    i10++;
                } while (!kotlin.jvm.internal.q.c(((z.p) obj).f23381a, str));
            } else {
                Log.i("CXCP", "New camera " + str + " detected");
                arrayListD = u1Var.d();
                break;
            }
        } else {
            if (z5) {
                throw new ad.n(11);
            }
            if (arrayList == null) {
                Log.i("CXCP", "Unavailable camera " + str + " detected");
                arrayListD = u1Var.d();
                break;
            }
            if (!arrayList.isEmpty()) {
                int size2 = arrayList.size();
                while (i10 < size2) {
                    Object obj2 = arrayList.get(i10);
                    i10++;
                    if (kotlin.jvm.internal.q.c(((z.p) obj2).f23381a, str)) {
                        Log.i("CXCP", "Unavailable camera " + str + " detected");
                        arrayListD = u1Var.d();
                        break;
                    }
                }
            }
        }
        if (arrayListD != null && (arrayListD.size() >= u1Var.f345j || arrayList == null)) {
            arrayList = arrayListD;
        }
        if (arrayList != null) {
            e(yVar, arrayList);
        }
    }

    public static void e(kotlinx.coroutines.channels.y yVar, ArrayList arrayList) {
        Log.d("CXCP", "Emitting camera ID list: " + arrayList);
        Object objTrySendBlocking = kotlinx.coroutines.channels.p.trySendBlocking(yVar, arrayList);
        if (objTrySendBlocking instanceof kotlinx.coroutines.channels.n.c) {
            kotlinx.coroutines.channels.n.m31exceptionOrNullimpl(objTrySendBlocking);
            Log.e("CXCP", "Failed to send camera ID list: " + arrayList + '!');
        }
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    public final Object b(String str, wi.c cVar) {
        r1 r1Var;
        kotlinx.coroutines.x0 x0Var;
        if (cVar instanceof r1) {
            r1Var = (r1) cVar;
            int i10 = r1Var.f306r0;
            if ((i10 & Integer.MIN_VALUE) != 0) {
                r1Var.f306r0 = i10 - Integer.MIN_VALUE;
            } else {
                r1Var = new r1(this, cVar);
            }
        } else {
            r1Var = new r1(this, cVar);
        }
        Object objAwait = r1Var.Y;
        vi.a aVar = vi.a.f21252e;
        int i11 = r1Var.f306r0;
        if (i11 == 0) {
            g6.y.I(objAwait);
            ui.d dVar = null;
            if (Build.VERSION.SDK_INT < 35) {
                return null;
            }
            synchronized (this.f) {
                try {
                    LinkedHashMap linkedHashMap = this.h;
                    z.p pVar = new z.p(str);
                    Object objAsync$default = linkedHashMap.get(pVar);
                    if (objAsync$default == null) {
                        objAsync$default = kotlinx.coroutines.k.async$default(this.f342e, this.f339b.f3844d, null, new m0(str, this, dVar, 3), 2, null);
                        linkedHashMap.put(pVar, objAsync$default);
                    }
                    x0Var = (kotlinx.coroutines.x0) objAsync$default;
                } catch (Throwable th2) {
                    throw th2;
                }
            }
            r1Var.f305e = str;
            r1Var.X = x0Var;
            r1Var.f306r0 = 1;
            objAwait = x0Var.await(r1Var);
            if (objAwait == aVar) {
                return aVar;
            }
        } else {
            if (i11 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            kotlinx.coroutines.x0 x0Var2 = r1Var.X;
            String str2 = r1Var.f305e;
            g6.y.I(objAwait);
            x0Var = x0Var2;
            str = str2;
        }
        b1.d dVar2 = (b1.d) objAwait;
        if (dVar2 != null) {
            return dVar2;
        }
        Log.d("CXCP", "Removing null CameraDeviceSetupCompat from cache for " + ((Object) z.p.b(str)));
        synchronized (this.f) {
            Map.EL.remove(this.h, new z.p(str), x0Var);
        }
        return dVar2;
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    public final Object c(String str, wi.c cVar) {
        s1 s1Var;
        kotlinx.coroutines.x0 x0Var;
        if (cVar instanceof s1) {
            s1Var = (s1) cVar;
            int i10 = s1Var.f318r0;
            if ((i10 & Integer.MIN_VALUE) != 0) {
                s1Var.f318r0 = i10 - Integer.MIN_VALUE;
            } else {
                s1Var = new s1(this, cVar);
            }
        } else {
            s1Var = new s1(this, cVar);
        }
        Object objAwait = s1Var.Y;
        vi.a aVar = vi.a.f21252e;
        int i11 = s1Var.f318r0;
        if (i11 == 0) {
            g6.y.I(objAwait);
            synchronized (this.f) {
                try {
                    LinkedHashMap linkedHashMap = this.f344i;
                    z.p pVar = new z.p(str);
                    Object objAsync$default = linkedHashMap.get(pVar);
                    if (objAsync$default == null) {
                        objAsync$default = kotlinx.coroutines.k.async$default(this.f342e, this.f339b.f3844d, null, new t1(str, this, null), 2, null);
                        linkedHashMap.put(pVar, objAsync$default);
                    }
                    x0Var = (kotlinx.coroutines.x0) objAsync$default;
                } catch (Throwable th2) {
                    throw th2;
                }
            }
            s1Var.f317e = str;
            s1Var.X = x0Var;
            s1Var.f318r0 = 1;
            objAwait = x0Var.await(s1Var);
            if (objAwait == aVar) {
                return aVar;
            }
        } else {
            if (i11 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            kotlinx.coroutines.x0 x0Var2 = s1Var.X;
            String str2 = s1Var.f317e;
            g6.y.I(objAwait);
            x0Var = x0Var2;
            str = str2;
        }
        z1 z1Var = (z1) objAwait;
        if (z1Var != null) {
            return z1Var;
        }
        Log.d("CXCP", "Removing null camera2DeviceSetupWrapper from cache for " + ((Object) z.p.b(str)));
        synchronized (this.f) {
            Map.EL.remove(this.f344i, new z.p(str), x0Var);
        }
        return z1Var;
    }

    public final ArrayList d() {
        try {
            String[] cameraIdList = ((CameraManager) this.f338a.get()).getCameraIdList();
            kotlin.jvm.internal.q.f(cameraIdList, "getCameraIdList(...)");
            ArrayList arrayList = new ArrayList();
            for (String str : cameraIdList) {
                kotlin.jvm.internal.q.d(str);
                z.p.a(str);
                arrayList.add(new z.p(str));
            }
            if (arrayList.size() < this.f345j) {
                Log.w("CXCP", "Failed to query camera ID list: Invalid list returned: " + arrayList + '.');
                return arrayList;
            }
            synchronized (this.f) {
                this.f343g = arrayList;
            }
            Log.i("CXCP", "Loaded CameraIdList " + arrayList);
            return arrayList;
        } catch (CameraAccessException e3) {
            Log.w("CXCP", "Failed to query CameraManager#getCameraIdList!", e3);
            return null;
        } catch (ArrayIndexOutOfBoundsException e10) {
            Log.w("CXCP", "Failed to query CameraManager#getCameraIdList!Unexpected ArrayIndexOutOfBoundsException thrown by framework.", e10);
            return null;
        } catch (NullPointerException e11) {
            Log.w("CXCP", "Failed to query CameraManager#getCameraIdList!Null was returned by framework.", e11);
            return null;
        }
    }
}
