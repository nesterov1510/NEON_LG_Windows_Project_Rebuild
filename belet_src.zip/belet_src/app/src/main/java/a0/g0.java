package a0;

import android.hardware.camera2.CameraExtensionCharacteristics;
import android.hardware.camera2.TotalCaptureResult;
import android.hardware.camera2.params.InputConfiguration;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public abstract class g0 {
    public static final Map a(TotalCaptureResult totalCaptureResult) {
        return totalCaptureResult.getPhysicalCameraTotalResults();
    }

    public static final List b(CameraExtensionCharacteristics cameraExtensionCharacteristics) {
        List<Integer> supportedExtensions = cameraExtensionCharacteristics.getSupportedExtensions();
        kotlin.jvm.internal.q.f(supportedExtensions, "getSupportedExtensions(...)");
        return supportedExtensions;
    }

    public static final InputConfiguration c(String cameraId, List inputConfigData) {
        kotlin.jvm.internal.q.g(inputConfigData, "inputConfigData");
        kotlin.jvm.internal.q.g(cameraId, "cameraId");
        if (inputConfigData.isEmpty()) {
            throw new IllegalStateException("Call to create InputConfiguration but list of InputConfigData is empty.");
        }
        if (inputConfigData.size() == 1) {
            p3 p3Var = (p3) ri.m.e0(inputConfigData);
            return new InputConfiguration(p3Var.f270a, p3Var.f271b, p3Var.f272c);
        }
        ArrayList arrayList = new ArrayList(ri.o.S(inputConfigData, 10));
        Iterator it = inputConfigData.iterator();
        while (it.hasNext()) {
            p3 p3Var2 = (p3) it.next();
            f0.e();
            arrayList.add(f0.c(p3Var2.f270a, p3Var2.f271b, cameraId));
        }
        return f0.b(arrayList, ((p3) ri.m.e0(inputConfigData)).f272c);
    }
}
