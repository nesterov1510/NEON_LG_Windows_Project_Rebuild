package a0;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class n2 extends l2 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final z.i f226a;

    public n2(z.i iVar) {
        this.f226a = iVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof n2) && kotlin.jvm.internal.q.c(this.f226a, ((n2) obj).f226a);
    }

    public final int hashCode() {
        z.i iVar = this.f226a;
        if (iVar == null) {
            return 0;
        }
        return iVar.f23344a;
    }

    public final String toString() {
        return "CameraStateClosing(cameraErrorCode=" + this.f226a + ')';
    }
}
