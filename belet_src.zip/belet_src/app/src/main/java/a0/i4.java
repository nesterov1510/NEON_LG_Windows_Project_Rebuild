package a0;

import java.util.Iterator;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class i4 extends wi.c {
    public n4 X;
    public Iterator Y;
    public d Z;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public String f134e;

    /* JADX INFO: renamed from: r0, reason: collision with root package name */
    public /* synthetic */ Object f135r0;

    /* JADX INFO: renamed from: s0, reason: collision with root package name */
    public final /* synthetic */ j4 f136s0;

    /* JADX INFO: renamed from: t0, reason: collision with root package name */
    public int f137t0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public i4(j4 j4Var, wi.c cVar) {
        super(cVar);
        this.f136s0 = j4Var;
    }

    @Override // wi.a
    public final Object invokeSuspend(Object obj) {
        this.f135r0 = obj;
        this.f137t0 |= Integer.MIN_VALUE;
        return this.f136s0.i(null, null, this);
    }
}
