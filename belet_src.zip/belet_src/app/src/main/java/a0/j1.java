package a0;

import android.hardware.camera2.CameraManager;
import android.util.Log;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class j1 extends CameraManager.AvailabilityCallback {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f142a = 1;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ kotlinx.coroutines.channels.y f143b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f144c;

    public j1(kotlinx.coroutines.channels.y yVar, l1 l1Var) {
        this.f143b = yVar;
        this.f144c = l1Var;
    }

    @Override // android.hardware.camera2.CameraManager.AvailabilityCallback
    public void onCameraAccessPrioritiesChanged() {
        switch (this.f142a) {
            case 0:
                Log.d("CXCP", "Camera access priorities have changed");
                Object objTrySendBlocking = kotlinx.coroutines.channels.p.trySendBlocking(this.f143b, e0.i.f7267a);
                if (objTrySendBlocking instanceof kotlinx.coroutines.channels.n.c) {
                    kotlinx.coroutines.channels.n.m31exceptionOrNullimpl(objTrySendBlocking);
                    Log.w("CXCP", "Failed to emit CameraPrioritiesChanged");
                }
                break;
            default:
                super.onCameraAccessPrioritiesChanged();
                break;
        }
    }

    @Override // android.hardware.camera2.CameraManager.AvailabilityCallback
    public final void onCameraAvailable(String cameraId) {
        switch (this.f142a) {
            case 0:
                kotlin.jvm.internal.q.g(cameraId, "cameraId");
                if (cameraId.equals(((l1) this.f144c).X)) {
                    Log.d("CXCP", "Camera " + cameraId + " has become available");
                    z.p.a(cameraId);
                    Object objTrySendBlocking = kotlinx.coroutines.channels.p.trySendBlocking(this.f143b, new e0.h(cameraId));
                    if (objTrySendBlocking instanceof kotlinx.coroutines.channels.n.c) {
                        kotlinx.coroutines.channels.n.m31exceptionOrNullimpl(objTrySendBlocking);
                        Log.w("CXCP", "Failed to emit CameraAvailable(" + cameraId + ')');
                    }
                    break;
                }
                break;
            default:
                kotlin.jvm.internal.q.g(cameraId, "cameraId");
                u1.a((u1) this.f144c, this.f143b, cameraId, true);
                break;
        }
    }

    @Override // android.hardware.camera2.CameraManager.AvailabilityCallback
    public final void onCameraUnavailable(String cameraId) {
        switch (this.f142a) {
            case 0:
                kotlin.jvm.internal.q.g(cameraId, "cameraId");
                if (cameraId.equals(((l1) this.f144c).X)) {
                    Log.d("CXCP", "Camera " + cameraId + " has become unavailable");
                    z.p.a(cameraId);
                    Object objTrySendBlocking = kotlinx.coroutines.channels.p.trySendBlocking(this.f143b, new e0.j(cameraId));
                    if (objTrySendBlocking instanceof kotlinx.coroutines.channels.n.c) {
                        kotlinx.coroutines.channels.n.m31exceptionOrNullimpl(objTrySendBlocking);
                        Log.w("CXCP", "Failed to emit CameraUnavailable(" + cameraId + ')');
                    }
                    break;
                }
                break;
            default:
                kotlin.jvm.internal.q.g(cameraId, "cameraId");
                u1.a((u1) this.f144c, this.f143b, cameraId, false);
                break;
        }
    }

    public j1(u1 u1Var, kotlinx.coroutines.channels.y yVar) {
        this.f144c = u1Var;
        this.f143b = yVar;
    }
}
