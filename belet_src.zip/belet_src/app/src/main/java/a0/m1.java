package a0;

import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CaptureFailure;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.CaptureResult;
import android.hardware.camera2.TotalCaptureResult;
import android.os.Trace;
import android.util.ArrayMap;
import android.util.Log;
import android.view.Surface;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class m1 extends CameraCaptureSession.CaptureCallback implements z.f0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f198a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final boolean f199b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final ArrayList f200c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final ArrayList f201d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final List f202e;
    public final z7.b f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final ArrayMap f203g;
    public final ArrayMap h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final z.l1 f204i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final z.n1 f205j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final long f206k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final kotlinx.coroutines.z f207l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public volatile Integer f208m;

    public m1(String cameraId, boolean z5, ArrayList arrayList, ArrayList arrayList2, List listeners, z7.b sequenceListener, ArrayMap arrayMap, ArrayMap arrayMap2, z.l1 l1Var, z.n1 strictMode) {
        kotlin.jvm.internal.q.g(cameraId, "cameraId");
        kotlin.jvm.internal.q.g(listeners, "listeners");
        kotlin.jvm.internal.q.g(sequenceListener, "sequenceListener");
        kotlin.jvm.internal.q.g(strictMode, "strictMode");
        this.f198a = cameraId;
        this.f199b = z5;
        this.f200c = arrayList;
        this.f201d = arrayList2;
        this.f202e = listeners;
        this.f = sequenceListener;
        this.f203g = arrayMap;
        this.h = arrayMap2;
        this.f204i = l1Var;
        this.f205j = strictMode;
        this.f206k = p1.f264b.incrementAndGet();
        this.f207l = kotlinx.coroutines.b0.CompletableDeferred$default(null, 1, null);
        if (arrayList.size() != arrayList2.size()) {
            throw new IllegalStateException("CaptureRequestList and CaptureMetadataList must have a 1:1 mapping.");
        }
    }

    public final int a() {
        int iIntValue;
        if (this.f208m != null) {
            Integer num = this.f208m;
            if (num != null) {
                return num.intValue();
            }
            throw new IllegalStateException(("SequenceNumber has not been set for " + this + '!').toString());
        }
        synchronized (this) {
            Integer num2 = this.f208m;
            if (num2 == null) {
                throw new IllegalStateException(("SequenceNumber has not been set for " + this + '!').toString());
            }
            iIntValue = num2.intValue();
        }
        return iIntValue;
    }

    public final void b(z.g1 g1Var, long j10, z.f1 f1Var) {
        this.f.w(this);
        Trace.beginSection("InvokeInternalListeners");
        List list = this.f202e;
        int size = list.size();
        for (int i10 = 0; i10 < size; i10++) {
            ((z.d1) list.get(i10)).y(g1Var, j10, f1Var);
        }
        Trace.endSection();
        Trace.beginSection("InvokeRequestListeners");
        int size2 = g1Var.m().f23334d.size();
        for (int i11 = 0; i11 < size2; i11++) {
            ((z.d1) g1Var.m().f23334d.get(i11)).y(g1Var, j10, f1Var);
        }
        Trace.endSection();
    }

    public final void c(CaptureRequest captureRequest, TotalCaptureResult totalCaptureResult, long j10) {
        Trace.beginSection("onCaptureCompleted");
        Trace.beginSection("onCaptureSequenceComplete");
        this.f.w(this);
        Trace.endSection();
        z.g1 g1VarI = i(captureRequest);
        s sVar = new s(totalCaptureResult, this.f198a, g1VarI);
        Trace.beginSection("onTotalCaptureResult");
        Trace.beginSection("InvokeInternalListeners");
        List list = this.f202e;
        int size = list.size();
        for (int i10 = 0; i10 < size; i10++) {
            ((z.d1) list.get(i10)).D(g1VarI, j10, sVar);
        }
        Trace.endSection();
        Trace.beginSection("InvokeRequestListeners");
        int size2 = g1VarI.m().f23334d.size();
        for (int i11 = 0; i11 < size2; i11++) {
            ((z.d1) g1VarI.m().f23334d.get(i11)).D(g1VarI, j10, sVar);
        }
        Trace.endSection();
        Trace.endSection();
        Trace.beginSection("onComplete");
        Trace.beginSection("InvokeInternalListeners");
        int size3 = list.size();
        for (int i12 = 0; i12 < size3; i12++) {
            ((z.d1) list.get(i12)).K(g1VarI, j10, sVar);
        }
        Trace.endSection();
        Trace.beginSection("InvokeRequestListeners");
        int size4 = g1VarI.m().f23334d.size();
        for (int i13 = 0; i13 < size4; i13++) {
            ((z.d1) g1VarI.m().f23334d.get(i13)).K(g1VarI, j10, sVar);
        }
        Trace.endSection();
        Trace.endSection();
        Trace.endSection();
    }

    public final void d(CaptureRequest captureRequest, long j10) {
        Trace.beginSection("onCaptureFailed");
        this.f207l.complete(qi.b0.f17350a);
        z.g1 g1VarI = i(captureRequest);
        b(g1VarI, j10, new m3(g1VarI, j10));
        Trace.endSection();
    }

    public final void e(CaptureRequest captureRequest, int i10) {
        Trace.beginSection("onCaptureProcessProgressed");
        z.g1 g1VarI = i(captureRequest);
        Trace.beginSection("InvokeInternalListeners");
        List list = this.f202e;
        int size = list.size();
        for (int i11 = 0; i11 < size; i11++) {
            ((z.d1) list.get(i11)).v(g1VarI, i10);
        }
        Trace.endSection();
        Trace.beginSection("InvokeRequestListeners");
        int size2 = g1VarI.m().f23334d.size();
        for (int i12 = 0; i12 < size2; i12++) {
            ((z.d1) g1VarI.m().f23334d.get(i12)).v(g1VarI, i10);
        }
        Trace.endSection();
        Trace.endSection();
    }

    public final void f(int i10) {
        Trace.beginSection("onCaptureSequenceAborted");
        this.f207l.complete(qi.b0.f17350a);
        this.f.w(this);
        if (a() != i10) {
            String str = "onCaptureSequenceAborted was invoked on " + a() + ", but expected " + i10 + '!';
            this.f205j.getClass();
            Log.w("CXCP", str);
        }
        Trace.beginSection("InvokeInternalListeners");
        ArrayList arrayList = this.f201d;
        int size = arrayList.size();
        for (int i11 = 0; i11 < size; i11++) {
            z.g1 g1Var = (z.g1) arrayList.get(i11);
            List list = this.f202e;
            int size2 = list.size();
            for (int i12 = 0; i12 < size2; i12++) {
                ((z.d1) list.get(i12)).P(g1Var);
            }
        }
        Trace.endSection();
        Trace.beginSection("InvokeRequestListeners");
        int size3 = arrayList.size();
        for (int i13 = 0; i13 < size3; i13++) {
            z.g1 g1Var2 = (z.g1) arrayList.get(i13);
            int size4 = g1Var2.m().f23334d.size();
            for (int i14 = 0; i14 < size4; i14++) {
                ((z.d1) g1Var2.m().f23334d.get(i14)).P(g1Var2);
            }
        }
        Trace.endSection();
        Trace.endSection();
    }

    public final void g(int i10, long j10) {
        Trace.beginSection("onCaptureSequenceCompleted");
        this.f207l.complete(qi.b0.f17350a);
        this.f.w(this);
        if (a() != i10) {
            String str = "onCaptureSequenceCompleted was invoked on " + a() + ", but expected " + i10 + '!';
            this.f205j.getClass();
            Log.w("CXCP", str);
        }
        Trace.beginSection("InvokeInternalListeners");
        ArrayList arrayList = this.f201d;
        int size = arrayList.size();
        for (int i11 = 0; i11 < size; i11++) {
            z.g1 g1Var = (z.g1) arrayList.get(i11);
            List list = this.f202e;
            int size2 = list.size();
            for (int i12 = 0; i12 < size2; i12++) {
                ((z.d1) list.get(i12)).T(g1Var, j10);
            }
        }
        Trace.endSection();
        Trace.beginSection("InvokeRequestListeners");
        int size3 = arrayList.size();
        for (int i13 = 0; i13 < size3; i13++) {
            z.g1 g1Var2 = (z.g1) arrayList.get(i13);
            int size4 = g1Var2.m().f23334d.size();
            for (int i14 = 0; i14 < size4; i14++) {
                ((z.d1) g1Var2.m().f23334d.get(i14)).T(g1Var2, j10);
            }
        }
        Trace.endSection();
        Trace.endSection();
    }

    public final void h(CaptureRequest captureRequest, long j10, long j11) {
        Trace.beginSection("onCaptureStarted");
        this.f207l.complete(qi.b0.f17350a);
        z.g1 g1VarI = i(captureRequest);
        Trace.beginSection("InvokeInternalListeners");
        List list = this.f202e;
        int size = list.size();
        for (int i10 = 0; i10 < size; i10++) {
            ((z.d1) list.get(i10)).F(g1VarI, j10, j11);
        }
        Trace.endSection();
        Trace.beginSection("InvokeRequestListeners");
        int size2 = g1VarI.m().f23334d.size();
        for (int i11 = 0; i11 < size2; i11++) {
            ((z.d1) g1VarI.m().f23334d.get(i11)).F(g1VarI, j10, j11);
        }
        Trace.endSection();
        Trace.endSection();
    }

    public final z.g1 i(CaptureRequest captureRequest) {
        ArrayList arrayList = this.f200c;
        int size = arrayList.size();
        for (int i10 = 0; i10 < size; i10++) {
            if (arrayList.get(i10) == captureRequest) {
                return (z.g1) this.f201d.get(i10);
            }
        }
        throw new IllegalArgumentException("Failed to find CaptureRequest " + captureRequest + " in " + arrayList);
    }

    @Override // android.hardware.camera2.CameraCaptureSession.CaptureCallback
    public final void onCaptureBufferLost(CameraCaptureSession captureSession, CaptureRequest captureRequest, Surface surface, long j10) {
        d0.d0 d0Var;
        Object obj;
        kotlin.jvm.internal.q.g(captureSession, "captureSession");
        kotlin.jvm.internal.q.g(captureRequest, "captureRequest");
        kotlin.jvm.internal.q.g(surface, "surface");
        Trace.beginSection("onCaptureBufferLost");
        z.m1 m1Var = (z.m1) this.f203g.get(surface);
        ArrayMap arrayMap = this.h;
        if (m1Var == null) {
            z.t0 t0Var = (z.t0) arrayMap.get(surface);
            z.m1 m1Var2 = null;
            if (t0Var != null) {
                int i10 = t0Var.f23392a;
                ArrayList arrayList = ((d0.f0) this.f204i).u0;
                int size = arrayList.size();
                int i11 = 0;
                do {
                    if (i11 >= size) {
                        obj = null;
                        break;
                    } else {
                        obj = arrayList.get(i11);
                        i11++;
                    }
                } while (((d0.d0) obj).f6513a != i10);
                d0Var = (d0.d0) obj;
            } else {
                d0Var = null;
            }
            if (d0Var != null) {
                z.b0 b0Var = d0Var.f6520j;
                if (b0Var == null) {
                    kotlin.jvm.internal.q.n("stream");
                    throw null;
                }
                m1Var2 = new z.m1(b0Var.f23319a);
            }
            m1Var = m1Var2;
        }
        z.t0 t0Var2 = (z.t0) arrayMap.get(surface);
        if (m1Var == null) {
            throw new IllegalStateException(("Unable to find the streamId for " + surface + " on " + ((Object) z.j0.a(j10))).toString());
        }
        int i12 = m1Var.f23375a;
        if (t0Var2 == null) {
            throw new IllegalStateException(("Unable to find the outputId for " + surface + " on " + ((Object) z.j0.a(j10))).toString());
        }
        z.g1 g1VarI = i(captureRequest);
        Trace.beginSection("InvokeInternalListeners");
        List list = this.f202e;
        int size2 = list.size();
        for (int i13 = 0; i13 < size2; i13++) {
            ((z.d1) list.get(i13)).m(g1VarI, j10, i12);
        }
        Trace.endSection();
        Trace.beginSection("InvokeRequestListeners");
        int size3 = g1VarI.m().f23334d.size();
        for (int i14 = 0; i14 < size3; i14++) {
            ((z.d1) g1VarI.m().f23334d.get(i14)).m(g1VarI, j10, i12);
        }
        Trace.endSection();
        Trace.beginSection("InvokeInternalListeners");
        int size4 = list.size();
        for (int i15 = 0; i15 < size4; i15++) {
            ((z.d1) list.get(i15)).H(g1VarI, j10, m1Var.f23375a, t0Var2.f23392a);
        }
        Trace.endSection();
        Trace.beginSection("InvokeRequestListeners");
        int size5 = g1VarI.m().f23334d.size();
        for (int i16 = 0; i16 < size5; i16++) {
            ((z.d1) g1VarI.m().f23334d.get(i16)).H(g1VarI, j10, m1Var.f23375a, t0Var2.f23392a);
        }
        Trace.endSection();
        Trace.endSection();
    }

    @Override // android.hardware.camera2.CameraCaptureSession.CaptureCallback
    public final void onCaptureCompleted(CameraCaptureSession captureSession, CaptureRequest captureRequest, TotalCaptureResult captureResult) {
        kotlin.jvm.internal.q.g(captureSession, "captureSession");
        kotlin.jvm.internal.q.g(captureRequest, "captureRequest");
        kotlin.jvm.internal.q.g(captureResult, "captureResult");
        c(captureRequest, captureResult, captureResult.getFrameNumber());
    }

    @Override // android.hardware.camera2.CameraCaptureSession.CaptureCallback
    public final void onCaptureFailed(CameraCaptureSession captureSession, CaptureRequest captureRequest, CaptureFailure captureFailure) {
        kotlin.jvm.internal.q.g(captureSession, "captureSession");
        kotlin.jvm.internal.q.g(captureRequest, "captureRequest");
        kotlin.jvm.internal.q.g(captureFailure, "captureFailure");
        Trace.beginSection("onCaptureFailed");
        this.f207l.complete(qi.b0.f17350a);
        z.g1 g1VarI = i(captureRequest);
        b(g1VarI, captureFailure.getFrameNumber(), new n(g1VarI, captureFailure));
        Trace.endSection();
    }

    @Override // android.hardware.camera2.CameraCaptureSession.CaptureCallback
    public final void onCaptureProgressed(CameraCaptureSession captureSession, CaptureRequest captureRequest, CaptureResult partialCaptureResult) {
        kotlin.jvm.internal.q.g(captureSession, "captureSession");
        kotlin.jvm.internal.q.g(captureRequest, "captureRequest");
        kotlin.jvm.internal.q.g(partialCaptureResult, "partialCaptureResult");
        Trace.beginSection("onCaptureProgressed");
        long frameNumber = partialCaptureResult.getFrameNumber();
        t tVar = new t(partialCaptureResult, this.f198a);
        z.g1 g1VarI = i(captureRequest);
        Trace.beginSection("InvokeInternalListeners");
        List list = this.f202e;
        int size = list.size();
        for (int i10 = 0; i10 < size; i10++) {
            ((z.d1) list.get(i10)).a(g1VarI, frameNumber, tVar);
        }
        Trace.endSection();
        Trace.beginSection("InvokeRequestListeners");
        int size2 = g1VarI.m().f23334d.size();
        for (int i11 = 0; i11 < size2; i11++) {
            ((z.d1) g1VarI.m().f23334d.get(i11)).a(g1VarI, frameNumber, tVar);
        }
        Trace.endSection();
        Trace.endSection();
    }

    @Override // android.hardware.camera2.CameraCaptureSession.CaptureCallback
    public final void onCaptureSequenceAborted(CameraCaptureSession captureSession, int i10) {
        kotlin.jvm.internal.q.g(captureSession, "captureSession");
        f(i10);
    }

    @Override // android.hardware.camera2.CameraCaptureSession.CaptureCallback
    public final void onCaptureSequenceCompleted(CameraCaptureSession captureSession, int i10, long j10) {
        kotlin.jvm.internal.q.g(captureSession, "captureSession");
        g(i10, j10);
    }

    @Override // android.hardware.camera2.CameraCaptureSession.CaptureCallback
    public final void onCaptureStarted(CameraCaptureSession captureSession, CaptureRequest captureRequest, long j10, long j11) {
        kotlin.jvm.internal.q.g(captureSession, "captureSession");
        kotlin.jvm.internal.q.g(captureRequest, "captureRequest");
        h(captureRequest, j11, j10);
    }

    @Override // android.hardware.camera2.CameraCaptureSession.CaptureCallback
    public void onReadoutStarted(CameraCaptureSession session, CaptureRequest captureRequest, long j10, long j11) {
        kotlin.jvm.internal.q.g(session, "session");
        kotlin.jvm.internal.q.g(captureRequest, "captureRequest");
        Trace.beginSection("onReadoutStarted");
        z.g1 g1VarI = i(captureRequest);
        Trace.beginSection("InvokeInternalListeners");
        List list = this.f202e;
        int size = list.size();
        for (int i10 = 0; i10 < size; i10++) {
            ((z.d1) list.get(i10)).C(g1VarI, j11, j10);
        }
        Trace.endSection();
        Trace.beginSection("InvokeRequestListeners");
        int size2 = g1VarI.m().f23334d.size();
        for (int i11 = 0; i11 < size2; i11++) {
            ((z.d1) g1VarI.m().f23334d.get(i11)).C(g1VarI, j11, j10);
        }
        Trace.endSection();
        Trace.endSection();
    }

    public final String toString() {
        return "Camera2CaptureSequence-" + this.f206k;
    }
}
