package a0;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class d4 extends wi.c {
    public /* synthetic */ Object X;
    public final /* synthetic */ j4 Y;
    public int Z;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public k4 f73e;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public d4(j4 j4Var, wi.c cVar) {
        super(cVar);
        this.Y = j4Var;
    }

    @Override // wi.a
    public final Object invokeSuspend(Object obj) {
        this.X = obj;
        this.Z |= Integer.MIN_VALUE;
        return this.Y.e(null, this);
    }
}
