package a0;

import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraExtensionCharacteristics;
import android.hardware.camera2.params.ExtensionSessionConfiguration;
import android.hardware.camera2.params.OutputConfiguration;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public abstract class i0 {
    public static final boolean a(CameraExtensionCharacteristics cameraExtensionCharacteristics, int i10) {
        return cameraExtensionCharacteristics.isCaptureProcessProgressAvailable(i10);
    }

    public static final boolean b(CameraExtensionCharacteristics cameraExtensionCharacteristics, int i10) {
        return cameraExtensionCharacteristics.isPostviewAvailable(i10);
    }

    public static final boolean c(z.s cameraMetadata) {
        kotlin.jvm.internal.q.g(cameraMetadata, "cameraMetadata");
        CameraCharacteristics.Key CONTROL_AVAILABLE_SETTINGS_OVERRIDES = CameraCharacteristics.CONTROL_AVAILABLE_SETTINGS_OVERRIDES;
        kotlin.jvm.internal.q.f(CONTROL_AVAILABLE_SETTINGS_OVERRIDES, "CONTROL_AVAILABLE_SETTINGS_OVERRIDES");
        int[] iArr = (int[]) ((h1) cameraMetadata).c(CONTROL_AVAILABLE_SETTINGS_OVERRIDES);
        return iArr != null && ri.k.K(iArr, 1);
    }

    public static final void d(ExtensionSessionConfiguration extensionSessionConfiguration, OutputConfiguration outputConfiguration) {
        extensionSessionConfiguration.setPostviewOutputConfiguration(outputConfiguration);
    }
}
