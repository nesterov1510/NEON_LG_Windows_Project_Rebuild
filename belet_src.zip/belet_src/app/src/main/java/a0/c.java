package a0;

import android.content.SharedPreferences;
import android.util.Log;
import android.widget.TextView;
import androidx.media3.session.n5;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import okhttp3.internal.ws.WebSocketProtocol;
import tm.belet.films.R;
import tm.belet.films.domain.background.PlaybackService;
import tm.belet.films.presentation.activities.HomeActivity;
import tm.belet.films.presentation.viewmodel.DownloadSettingsViewModel;
import tm.belet.films.presentation.viewmodel.EventInfoViewModel;
import tm.belet.films.presentation.viewmodel.MovieInfoViewModel;
import tm.belet.films.presentation.viewmodel.MovieVotingViewModel;
import tm.belet.films.presentation.viewmodel.ProfileViewModel;
import tm.belet.films.presentation.viewmodel.SearchPageViewModel;
import tm.belet.films.presentation.viewmodel.TournamentViewModel;
import tm.belet.films.presentation.viewmodel.VCSViewModel;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class c extends wi.i implements ej.p {
    public int X;
    public final /* synthetic */ Object Y;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f30e;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    public c(ej.l lVar, ui.d dVar) {
        super(2, dVar);
        this.f30e = 6;
        this.Y = (wi.i) lVar;
    }

    /* JADX WARN: Type inference failed for: r0v13, types: [ej.l, wi.i] */
    @Override // wi.a
    public final ui.d create(Object obj, ui.d dVar) {
        switch (this.f30e) {
            case 0:
                return new c((d) this.Y, dVar, 0);
            case 1:
                return new c((l1) this.Y, dVar, 1);
            case 2:
                return new c((v2) this.Y, dVar, 2);
            case 3:
                return new c((m) this.Y, dVar, 3);
            case 4:
                return new c((y4) this.Y, dVar, 4);
            case 5:
                return new c((a4.n) this.Y, dVar, 5);
            case 6:
                return new c((wi.i) this.Y, dVar);
            case 7:
                return new c((kotlinx.coroutines.x0) this.Y, dVar, 7);
            case 8:
                return new c((n5) this.Y, dVar, 8);
            case 9:
                return new c((c6.a) this.Y, dVar, 9);
            case 10:
                return new c((d0.l) this.Y, dVar, 10);
            case ue.r.NETWORK_CLIENT_ERROR_REASON_FIELD_NUMBER /* 11 */:
                return new c((e0.a) this.Y, dVar, 11);
            case ue.r.CUSTOM_ATTRIBUTES_FIELD_NUMBER /* 12 */:
                return new c((eo.e) this.Y, dVar, 12);
            case ue.r.PERF_SESSIONS_FIELD_NUMBER /* 13 */:
                return new c((eo.h0) this.Y, dVar, 13);
            case 14:
                return new c((eo.v0) this.Y, dVar, 14);
            case WebSocketProtocol.B0_MASK_OPCODE /* 15 */:
                return new c((eo.f2) this.Y, dVar, 15);
            case WebSocketProtocol.B0_FLAG_RSV3 /* 16 */:
                return new c((eo.i2) this.Y, dVar, 16);
            case 17:
                return new c((eo.p2) this.Y, dVar, 17);
            case 18:
                return new c((PlaybackService) this.Y, dVar, 18);
            case 19:
                return new c((g6.g) this.Y, dVar, 19);
            case 20:
                return new c((g6.r0) this.Y, dVar, 20);
            case 21:
                return new c((go.d) this.Y, dVar, 21);
            case 22:
                return new c((go.t) this.Y, dVar, 22);
            case 23:
                return new c((go.w) this.Y, dVar, 23);
            case 24:
                return new c((go.r0) this.Y, dVar, 24);
            case 25:
                return new c((go.s2) this.Y, dVar, 25);
            case 26:
                return new c((go.z2) this.Y, dVar, 26);
            case 27:
                return new c((go.c3) this.Y, dVar, 27);
            case 28:
                return new c((go.z3) this.Y, dVar, 28);
            default:
                return new c((go.t4) this.Y, dVar, 29);
        }
    }

    @Override // ej.p
    public final Object invoke(Object obj, Object obj2) {
        kotlinx.coroutines.p0 p0Var = (kotlinx.coroutines.p0) obj;
        ui.d dVar = (ui.d) obj2;
        switch (this.f30e) {
            case 0:
                return ((c) create(p0Var, dVar)).invokeSuspend(qi.b0.f17350a);
            case 1:
                return ((c) create(p0Var, dVar)).invokeSuspend(qi.b0.f17350a);
            case 2:
                return ((c) create(p0Var, dVar)).invokeSuspend(qi.b0.f17350a);
            case 3:
                return ((c) create(p0Var, dVar)).invokeSuspend(qi.b0.f17350a);
            case 4:
                return ((c) create(p0Var, dVar)).invokeSuspend(qi.b0.f17350a);
            case 5:
                return ((c) create(p0Var, dVar)).invokeSuspend(qi.b0.f17350a);
            case 6:
                return ((c) create(p0Var, dVar)).invokeSuspend(qi.b0.f17350a);
            case 7:
                return ((c) create(p0Var, dVar)).invokeSuspend(qi.b0.f17350a);
            case 8:
                return ((c) create(p0Var, dVar)).invokeSuspend(qi.b0.f17350a);
            case 9:
                return ((c) create(p0Var, dVar)).invokeSuspend(qi.b0.f17350a);
            case 10:
                return ((c) create(p0Var, dVar)).invokeSuspend(qi.b0.f17350a);
            case ue.r.NETWORK_CLIENT_ERROR_REASON_FIELD_NUMBER /* 11 */:
                return ((c) create(p0Var, dVar)).invokeSuspend(qi.b0.f17350a);
            case ue.r.CUSTOM_ATTRIBUTES_FIELD_NUMBER /* 12 */:
                return ((c) create(p0Var, dVar)).invokeSuspend(qi.b0.f17350a);
            case ue.r.PERF_SESSIONS_FIELD_NUMBER /* 13 */:
                return ((c) create(p0Var, dVar)).invokeSuspend(qi.b0.f17350a);
            case 14:
                ((c) create(p0Var, dVar)).invokeSuspend(qi.b0.f17350a);
                return vi.a.f21252e;
            case WebSocketProtocol.B0_MASK_OPCODE /* 15 */:
                return ((c) create(p0Var, dVar)).invokeSuspend(qi.b0.f17350a);
            case WebSocketProtocol.B0_FLAG_RSV3 /* 16 */:
                return ((c) create(p0Var, dVar)).invokeSuspend(qi.b0.f17350a);
            case 17:
                ((c) create(p0Var, dVar)).invokeSuspend(qi.b0.f17350a);
                return vi.a.f21252e;
            case 18:
                return ((c) create(p0Var, dVar)).invokeSuspend(qi.b0.f17350a);
            case 19:
                return ((c) create(p0Var, dVar)).invokeSuspend(qi.b0.f17350a);
            case 20:
                return ((c) create(p0Var, dVar)).invokeSuspend(qi.b0.f17350a);
            case 21:
                ((c) create(p0Var, dVar)).invokeSuspend(qi.b0.f17350a);
                return vi.a.f21252e;
            case 22:
                return ((c) create(p0Var, dVar)).invokeSuspend(qi.b0.f17350a);
            case 23:
                return ((c) create(p0Var, dVar)).invokeSuspend(qi.b0.f17350a);
            case 24:
                return ((c) create(p0Var, dVar)).invokeSuspend(qi.b0.f17350a);
            case 25:
                ((c) create(p0Var, dVar)).invokeSuspend(qi.b0.f17350a);
                return vi.a.f21252e;
            case 26:
                return ((c) create(p0Var, dVar)).invokeSuspend(qi.b0.f17350a);
            case 27:
                ((c) create(p0Var, dVar)).invokeSuspend(qi.b0.f17350a);
                return vi.a.f21252e;
            case 28:
                return ((c) create(p0Var, dVar)).invokeSuspend(qi.b0.f17350a);
            default:
                return ((c) create(p0Var, dVar)).invokeSuspend(qi.b0.f17350a);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r10v1 */
    /* JADX WARN: Type inference failed for: r10v2, types: [a0.m, z.i] */
    /* JADX WARN: Type inference failed for: r10v3 */
    /* JADX WARN: Type inference failed for: r1v37, types: [ej.l, wi.i] */
    @Override // wi.a
    public final Object invokeSuspend(Object obj) {
        ?? r10;
        Object objFirst;
        Object objL;
        Object objF;
        int i10;
        String strY;
        int i11 = 4;
        int i12 = 11;
        int i13 = 2;
        int i14 = 10;
        int i15 = 0;
        ui.d dVar = null;
        switch (this.f30e) {
            case 0:
                d dVar2 = (d) this.Y;
                vi.a aVar = vi.a.f21252e;
                int i16 = this.X;
                if (i16 == 0) {
                    g6.y.I(obj);
                    kotlinx.coroutines.flow.h0 h0Var = dVar2.f38a.f196u;
                    b bVar = new b(i13, null, i15);
                    this.X = 1;
                    if (kotlinx.coroutines.flow.k.first(h0Var, bVar, this) == aVar) {
                        return aVar;
                    }
                } else {
                    if (i16 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                }
                dVar2.f41d.c();
                return qi.b0.f17350a;
            case 1:
                vi.a aVar2 = vi.a.f21252e;
                int i17 = this.X;
                if (i17 == 0) {
                    g6.y.I(obj);
                    l1 l1Var = (l1) this.Y;
                    kotlinx.coroutines.flow.i iVar = l1Var.f174w0;
                    k1 k1Var = new k1(i15, l1Var);
                    this.X = 1;
                    if (iVar.collect(k1Var, this) == aVar2) {
                        return aVar2;
                    }
                } else {
                    if (i17 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                }
                return qi.b0.f17350a;
            case 2:
                vi.a aVar3 = vi.a.f21252e;
                int i18 = this.X;
                if (i18 != 0) {
                    if (i18 == 1) {
                        g6.y.I(obj);
                    } else {
                        if (i18 != 2) {
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        g6.y.I(obj);
                    }
                    return qi.b0.f17350a;
                }
                g6.y.I(obj);
                kotlinx.coroutines.z zVar = (kotlinx.coroutines.z) ((v2) this.Y).h;
                this.X = 1;
                if (zVar.await(this) == aVar3) {
                    return aVar3;
                }
                this.X = 2;
                if (kotlinx.coroutines.b1.delay(2000L, this) == aVar3) {
                    return aVar3;
                }
                return qi.b0.f17350a;
            case 3:
                m mVar = (m) this.Y;
                vi.a aVar4 = vi.a.f21252e;
                int i19 = this.X;
                if (i19 == 0) {
                    g6.y.I(obj);
                    kotlinx.coroutines.flow.h0 h0Var2 = mVar.f196u;
                    r10 = 0;
                    b bVar2 = new b(i13, 0 == true ? 1 : 0, i13);
                    this.X = 1;
                    objFirst = kotlinx.coroutines.flow.k.first(h0Var2, bVar2, this);
                    if (objFirst == aVar4) {
                        return aVar4;
                    }
                } else {
                    if (i19 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                    objFirst = obj;
                    r10 = 0;
                }
                l2 l2Var = (l2) objFirst;
                if (l2Var instanceof o2) {
                    return new q3(mVar, r10, 2);
                }
                if (l2Var instanceof n2) {
                    mVar.a();
                    return new q3(r10, ((n2) l2Var).f226a, 1);
                }
                if (l2Var instanceof m2) {
                    mVar.a();
                    return new q3(r10, ((m2) l2Var).f215i, 1);
                }
                if (!(l2Var instanceof w2)) {
                    throw new ad.n(11);
                }
                mVar.a();
                throw new IllegalStateException("Unexpected CameraState: " + l2Var);
            case 4:
                vi.a aVar5 = vi.a.f21252e;
                int i20 = this.X;
                if (i20 != 0) {
                    if (i20 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                    return qi.b0.f17350a;
                }
                g6.y.I(obj);
                y4 y4Var = (y4) this.Y;
                this.X = 1;
                y4.l(y4Var, this);
                return aVar5;
            case 5:
                vi.a aVar6 = vi.a.f21252e;
                int i21 = this.X;
                if (i21 == 0) {
                    g6.y.I(obj);
                    a4.n nVar = (a4.n) this.Y;
                    this.X = 1;
                    if (kotlinx.coroutines.d3.supervisorScope(new q0(nVar, (ui.d) null, i11), this) == aVar6) {
                        return aVar6;
                    }
                } else {
                    if (i21 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                }
                return qi.b0.f17350a;
            case 6:
                vi.a aVar7 = vi.a.f21252e;
                int i22 = this.X;
                if (i22 != 0) {
                    if (i22 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                    return obj;
                }
                g6.y.I(obj);
                ?? r4 = (wi.i) this.Y;
                this.X = 1;
                Object objInvoke = r4.invoke(this);
                return objInvoke == aVar7 ? aVar7 : objInvoke;
            case 7:
                vi.a aVar8 = vi.a.f21252e;
                int i23 = this.X;
                if (i23 != 0) {
                    if (i23 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                    return obj;
                }
                g6.y.I(obj);
                kotlinx.coroutines.x0 x0Var = (kotlinx.coroutines.x0) this.Y;
                this.X = 1;
                Object objAwait = x0Var.await(this);
                return objAwait == aVar8 ? aVar8 : objAwait;
            case 8:
                Object obj2 = vi.a.f21252e;
                int i24 = this.X;
                if (i24 == 0) {
                    g6.y.I(obj);
                    this.X = 1;
                    if (kotlinx.coroutines.b1.delay(1000L, this) != obj2) {
                    }
                    return obj2;
                }
                if (i24 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                g6.y.I(obj);
                n5 n5Var = (n5) this.Y;
                synchronized (n5Var.X) {
                    if (n5Var.Z || n5Var.Y != 0) {
                        obj2 = qi.b0.f17350a;
                    } else {
                        n5Var.f2560t0 = null;
                        n5Var.Z = true;
                        ((a) ((n5) this.Y).f2559s0).invoke();
                        obj2 = qi.b0.f17350a;
                    }
                }
                return obj2;
            case 9:
                vi.a aVar9 = vi.a.f21252e;
                int i25 = this.X;
                if (i25 != 0) {
                    if (i25 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                    return obj;
                }
                g6.y.I(obj);
                y6.a aVar10 = ((c6.a) this.Y).f3934a;
                this.X = 1;
                Object objJ = aVar10.j(this);
                return objJ == aVar9 ? aVar9 : objJ;
            case 10:
                qi.b0 b0Var = qi.b0.f17350a;
                d0.l lVar = (d0.l) this.Y;
                vi.a aVar11 = vi.a.f21252e;
                int i26 = this.X;
                if (i26 == 0) {
                    g6.y.I(obj);
                    d0.v vVar = lVar.f6554a;
                    if (vVar != null) {
                        this.X = 1;
                        vVar.l();
                        if (b0Var != aVar11) {
                        }
                    }
                    return aVar11;
                }
                if (i26 != 1) {
                    if (i26 != 2) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                    return b0Var;
                }
                g6.y.I(obj);
                d0.v vVar2 = lVar.f6555b;
                if (vVar2 == null) {
                    return b0Var;
                }
                this.X = 2;
                vVar2.l();
                if (b0Var != aVar11) {
                    return b0Var;
                }
                return aVar11;
            case ue.r.NETWORK_CLIENT_ERROR_REASON_FIELD_NUMBER /* 11 */:
                qi.b0 b0Var2 = qi.b0.f17350a;
                vi.a aVar12 = vi.a.f21252e;
                int i27 = this.X;
                if (i27 != 0) {
                    if (i27 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                    return b0Var2;
                }
                g6.y.I(obj);
                e0.a aVar13 = (e0.a) this.Y;
                this.X = 1;
                Log.d("CXCP", "CameraBackends#shutdown");
                LinkedHashMap linkedHashMap = aVar13.f7253c;
                ArrayList arrayList = new ArrayList(linkedHashMap.size());
                Iterator it = linkedHashMap.entrySet().iterator();
                while (it.hasNext()) {
                    r0 r0Var = (r0) ((z.e) ((Map.Entry) it.next()).getValue());
                    r0Var.getClass();
                    Log.d("CXCP", "Camera2Backend#shutdownAsync");
                    kotlinx.coroutines.q0.cancel$default(r0Var.f300b.f342e, null, 1, null);
                    arrayList.add(kotlinx.coroutines.k.async$default(r0Var.f299a.f3841a, null, null, new q0(r0Var, (ui.d) null, i15), 3, null));
                }
                Object objJoinAll = kotlinx.coroutines.f.joinAll(arrayList, this);
                if (objJoinAll != vi.a.f21252e) {
                    objJoinAll = b0Var2;
                }
                return objJoinAll == aVar12 ? aVar12 : b0Var2;
            case ue.r.CUSTOM_ATTRIBUTES_FIELD_NUMBER /* 12 */:
                eo.e eVar = (eo.e) this.Y;
                go.s3 s3Var = eVar.H1;
                vi.a aVar14 = vi.a.f21252e;
                int i28 = this.X;
                if (i28 == 0) {
                    g6.y.I(obj);
                    DownloadSettingsViewModel downloadSettingsViewModel = (DownloadSettingsViewModel) eVar.O1.getValue();
                    this.X = 1;
                    objL = downloadSettingsViewModel.l(this);
                    if (objL == aVar14) {
                        return aVar14;
                    }
                } else {
                    if (i28 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                    objL = obj;
                }
                Integer num = (Integer) objL;
                if (num != null && num.intValue() == 1 && s3Var != null) {
                    try {
                        ((HomeActivity) s3Var.Z()).a0();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    break;
                }
                if (num != null && num.intValue() == 0 && s3Var != null) {
                    try {
                        ((HomeActivity) s3Var.Z()).Y();
                    } catch (Exception e10) {
                        e10.printStackTrace();
                    }
                    break;
                }
                return qi.b0.f17350a;
            case ue.r.PERF_SESSIONS_FIELD_NUMBER /* 13 */:
                eo.h0 h0Var3 = (eo.h0) this.Y;
                vi.a aVar15 = vi.a.f21252e;
                int i29 = this.X;
                if (i29 == 0) {
                    g6.y.I(obj);
                    kotlinx.coroutines.flow.h0 h0Var4 = ((ProfileViewModel) h0Var3.H1.getValue()).I;
                    m0 m0Var = new m0(h0Var3, null, i12);
                    this.X = 1;
                    if (kotlinx.coroutines.flow.k.collectLatest(h0Var4, m0Var, this) == aVar15) {
                        return aVar15;
                    }
                } else {
                    if (i29 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                }
                return qi.b0.f17350a;
            case 14:
                eo.v0 v0Var = (eo.v0) this.Y;
                vi.a aVar16 = vi.a.f21252e;
                int i30 = this.X;
                if (i30 == 0) {
                    g6.y.I(obj);
                    kotlinx.coroutines.flow.h0 h0Var5 = ((EventInfoViewModel) v0Var.H1.getValue()).f19492i;
                    k1 k1Var2 = new k1(3, v0Var);
                    this.X = 1;
                    if (h0Var5.collect(k1Var2, this) == aVar16) {
                        return aVar16;
                    }
                } else {
                    if (i30 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                }
                throw new ad.n(10);
            case WebSocketProtocol.B0_MASK_OPCODE /* 15 */:
                eo.f2 f2Var = (eo.f2) this.Y;
                vi.a aVar17 = vi.a.f21252e;
                int i31 = this.X;
                if (i31 == 0) {
                    g6.y.I(obj);
                    kotlinx.coroutines.flow.h0 h0Var6 = ((ProfileViewModel) f2Var.H1.getValue()).G;
                    m0 m0Var2 = new m0(f2Var, null, 13);
                    this.X = 1;
                    if (kotlinx.coroutines.flow.k.collectLatest(h0Var6, m0Var2, this) == aVar17) {
                        return aVar17;
                    }
                } else {
                    if (i31 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                }
                return qi.b0.f17350a;
            case WebSocketProtocol.B0_FLAG_RSV3 /* 16 */:
                eo.i2 i2Var = (eo.i2) this.Y;
                vi.a aVar18 = vi.a.f21252e;
                int i32 = this.X;
                if (i32 == 0) {
                    g6.y.I(obj);
                    kotlinx.coroutines.flow.h0 h0Var7 = ((SearchPageViewModel) i2Var.K1.getValue()).f;
                    m0 m0Var3 = new m0(i2Var, null, 14);
                    this.X = 1;
                    if (kotlinx.coroutines.flow.k.collectLatest(h0Var7, m0Var3, this) == aVar18) {
                        return aVar18;
                    }
                } else {
                    if (i32 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                }
                return qi.b0.f17350a;
            case 17:
                eo.p2 p2Var = (eo.p2) this.Y;
                vi.a aVar19 = vi.a.f21252e;
                int i33 = this.X;
                if (i33 == 0) {
                    g6.y.I(obj);
                    kotlinx.coroutines.flow.h0 h0Var8 = ((VCSViewModel) p2Var.I1.getValue()).f19720d;
                    k1 k1Var3 = new k1(i11, p2Var);
                    this.X = 1;
                    if (h0Var8.collect(k1Var3, this) == aVar19) {
                        return aVar19;
                    }
                } else {
                    if (i33 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                }
                throw new ad.n(10);
            case 18:
                vi.a aVar20 = vi.a.f21252e;
                int i34 = this.X;
                if (i34 != 0) {
                    if (i34 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                    return obj;
                }
                g6.y.I(obj);
                sk.c0 c0Var = (sk.c0) ((PlaybackService) this.Y).J0.getValue();
                this.X = 1;
                Object objC = c0Var.c(35, 10, 0, 6, this);
                return objC == aVar20 ? aVar20 : objC;
            case 19:
                vi.a aVar21 = vi.a.f21252e;
                int i35 = this.X;
                if (i35 == 0) {
                    g6.y.I(obj);
                    g6.g gVar = (g6.g) this.Y;
                    this.X = 1;
                    if (gVar.a(this) == aVar21) {
                        return aVar21;
                    }
                } else {
                    if (i35 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                }
                return qi.b0.f17350a;
            case 20:
                vi.a aVar22 = vi.a.f21252e;
                int i36 = this.X;
                if (i36 == 0) {
                    g6.y.I(obj);
                    g6.r0 r0Var2 = (g6.r0) this.Y;
                    this.X = 1;
                    if (r0Var2.f(this) == aVar22) {
                        return aVar22;
                    }
                } else {
                    if (i36 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                }
                return qi.b0.f17350a;
            case 21:
                go.d dVar3 = (go.d) this.Y;
                vi.a aVar23 = vi.a.f21252e;
                int i37 = this.X;
                if (i37 == 0) {
                    g6.y.I(obj);
                    kotlinx.coroutines.flow.h0 h0Var9 = ((tm.belet.films.presentation.viewmodel.k3) dVar3.f9068s1.getValue()).f19838c;
                    k1 k1Var4 = new k1(6, dVar3);
                    this.X = 1;
                    if (h0Var9.collect(k1Var4, this) == aVar23) {
                        return aVar23;
                    }
                } else {
                    if (i37 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                }
                throw new ad.n(10);
            case 22:
                go.t tVar = (go.t) this.Y;
                vi.a aVar24 = vi.a.f21252e;
                int i38 = this.X;
                if (i38 == 0) {
                    g6.y.I(obj);
                    kotlinx.coroutines.flow.h0 h0Var10 = tVar.j0().B;
                    m0 m0Var4 = new m0(tVar, null, 15);
                    this.X = 1;
                    if (kotlinx.coroutines.flow.k.collectLatest(h0Var10, m0Var4, this) == aVar24) {
                        return aVar24;
                    }
                } else {
                    if (i38 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                }
                return qi.b0.f17350a;
            case 23:
                go.w wVar = (go.w) this.Y;
                vi.a aVar25 = vi.a.f21252e;
                int i39 = this.X;
                if (i39 == 0) {
                    g6.y.I(obj);
                    kotlinx.coroutines.flow.h0 h0Var11 = wVar.i0().f19484z;
                    m0 m0Var5 = new m0(wVar, null, 16);
                    this.X = 1;
                    if (kotlinx.coroutines.flow.k.collectLatest(h0Var11, m0Var5, this) == aVar25) {
                        return aVar25;
                    }
                } else {
                    if (i39 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                }
                return qi.b0.f17350a;
            case 24:
                go.r0 r0Var3 = (go.r0) this.Y;
                vi.a aVar26 = vi.a.f21252e;
                int i40 = this.X;
                if (i40 == 0) {
                    g6.y.I(obj);
                    kotlinx.coroutines.flow.h0 h0Var12 = ((tm.belet.films.presentation.viewmodel.c3) r0Var3.f9274t1.getValue()).f19749c;
                    m0 m0Var6 = new m0(r0Var3, dVar, 18);
                    this.X = 1;
                    if (kotlinx.coroutines.flow.k.collectLatest(h0Var12, m0Var6, this) == aVar26) {
                        return aVar26;
                    }
                } else {
                    if (i40 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                }
                return qi.b0.f17350a;
            case 25:
                go.s2 s2Var = (go.s2) this.Y;
                vi.a aVar27 = vi.a.f21252e;
                int i41 = this.X;
                if (i41 == 0) {
                    g6.y.I(obj);
                    kotlinx.coroutines.flow.h0 h0Var13 = ((MovieVotingViewModel) s2Var.f9301r1.getValue()).f19609e;
                    k1 k1Var5 = new k1(i14, s2Var);
                    this.X = 1;
                    if (h0Var13.collect(k1Var5, this) == aVar27) {
                        return aVar27;
                    }
                } else {
                    if (i41 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                }
                throw new ad.n(10);
            case 26:
                go.z2 z2Var = (go.z2) this.Y;
                vi.a aVar28 = vi.a.f21252e;
                int i42 = this.X;
                if (i42 == 0) {
                    g6.y.I(obj);
                    z2Var.j0().f7193o.setVisibility(0);
                    z2Var.j0().h.setVisibility(8);
                    DownloadSettingsViewModel downloadSettingsViewModelK0 = z2Var.k0();
                    this.X = 1;
                    objF = downloadSettingsViewModelK0.f19481w.f(this);
                    if (objF == aVar28) {
                        return aVar28;
                    }
                } else {
                    if (i42 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                    objF = obj;
                }
                long jLongValue = ((Number) objF).longValue();
                hm.u uVarE = z2Var.k0().e();
                long j10 = uVarE != null ? uVarE.f10268b : 0L;
                int i43 = (j10 <= 0 || jLongValue <= 0) ? 0 : (int) ((jLongValue / (j10 + jLongValue)) * 100.0f);
                z2Var.j0().f7189k.setVisibility(j10 < 500000000 ? 0 : 8);
                TextView textView = z2Var.j0().f7190l;
                SharedPreferences sharedPreferences = d7.s.f6708b;
                if (sharedPreferences == null) {
                    kotlin.jvm.internal.q.n("shared");
                    throw null;
                }
                textView.setText(z2Var.x(sharedPreferences.getInt("download_place", 0) == 0 ? R.string.your_internal_storage_is_full : R.string.your_external_storage_is_full));
                z2Var.j0().f7192n.setProgress(i43);
                long jMax = Math.max(0L, j10 - jLongValue);
                z2Var.j0().f7187i.setText(z2Var.y(new Object[]{ro.g.m(jLongValue)}, R.string.downloaded_films));
                SharedPreferences sharedPreferences2 = d7.s.f6708b;
                if (sharedPreferences2 == null) {
                    kotlin.jvm.internal.q.n("shared");
                    throw null;
                }
                if (sharedPreferences2.contains("download_limit")) {
                    SharedPreferences sharedPreferences3 = d7.s.f6708b;
                    if (sharedPreferences3 == null) {
                        kotlin.jvm.internal.q.n("shared");
                        throw null;
                    }
                    i10 = sharedPreferences3.getInt("download_limit", -1);
                } else {
                    i10 = -1;
                }
                TextView textView2 = z2Var.j0().f7188j;
                if (i10 != -1) {
                    long j11 = 1024;
                    strY = z2Var.y(new Object[]{ro.g.m(((long) i10) * j11 * j11)}, R.string.available);
                } else {
                    strY = z2Var.y(new Object[]{ro.g.m(jMax)}, R.string.free_space);
                }
                textView2.setText(strY);
                z2Var.j0().f7193o.setVisibility(8);
                z2Var.j0().h.setVisibility(0);
                return qi.b0.f17350a;
            case 27:
                go.c3 c3Var = (go.c3) this.Y;
                vi.a aVar29 = vi.a.f21252e;
                int i44 = this.X;
                if (i44 == 0) {
                    g6.y.I(obj);
                    kotlinx.coroutines.flow.h0 h0Var14 = ((ProfileViewModel) c3Var.f9056t1.getValue()).f19682w;
                    k1 k1Var6 = new k1(i12, c3Var);
                    this.X = 1;
                    if (h0Var14.collect(k1Var6, this) == aVar29) {
                        return aVar29;
                    }
                } else {
                    if (i44 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                }
                throw new ad.n(10);
            case 28:
                go.z3 z3Var = (go.z3) this.Y;
                vi.a aVar30 = vi.a.f21252e;
                int i45 = this.X;
                if (i45 == 0) {
                    g6.y.I(obj);
                    kotlinx.coroutines.flow.h0 h0Var15 = ((MovieInfoViewModel) z3Var.f9433s1.getValue()).f19601x;
                    m0 m0Var7 = new m0(z3Var, dVar, 20);
                    this.X = 1;
                    if (kotlinx.coroutines.flow.k.collectLatest(h0Var15, m0Var7, this) == aVar30) {
                        return aVar30;
                    }
                } else {
                    if (i45 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                }
                return qi.b0.f17350a;
            default:
                go.t4 t4Var = (go.t4) this.Y;
                vi.a aVar31 = vi.a.f21252e;
                int i46 = this.X;
                if (i46 == 0) {
                    g6.y.I(obj);
                    kotlinx.coroutines.flow.h0 h0Var16 = ((TournamentViewModel) t4Var.f9339r1.getValue()).f19706e;
                    m0 m0Var8 = new m0(t4Var, dVar, 22);
                    this.X = 1;
                    if (kotlinx.coroutines.flow.k.collectLatest(h0Var16, m0Var8, this) == aVar31) {
                        return aVar31;
                    }
                } else {
                    if (i46 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                }
                return qi.b0.f17350a;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ c(Object obj, ui.d dVar, int i10) {
        super(2, dVar);
        this.f30e = i10;
        this.Y = obj;
    }
}
