package a0;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class p0 extends wi.c {
    public b1.d X;
    public Object Y;
    public /* synthetic */ Object Z;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public z.k f260e;

    /* JADX INFO: renamed from: r0, reason: collision with root package name */
    public final /* synthetic */ r0 f261r0;

    /* JADX INFO: renamed from: s0, reason: collision with root package name */
    public int f262s0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public p0(r0 r0Var, wi.c cVar) {
        super(cVar);
        this.f261r0 = r0Var;
    }

    @Override // wi.a
    public final Object invokeSuspend(Object obj) {
        this.Z = obj;
        this.f262s0 |= Integer.MIN_VALUE;
        return this.f261r0.a(null, this);
    }
}
