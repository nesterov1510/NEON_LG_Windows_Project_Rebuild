package a0;

import android.os.Build;
import android.os.Trace;
import android.util.Log;
import java.util.Set;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class e1 implements ej.a {
    public final /* synthetic */ f1 X;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f75e;

    public /* synthetic */ e1(f1 f1Var, int i10) {
        this.f75e = i10;
        this.X = f1Var;
    }

    @Override // ej.a
    public final Object invoke() {
        Set setE0;
        Set setE1;
        switch (this.f75e) {
            case 0:
                ri.u uVar = ri.u.f18052e;
                StringBuilder sb2 = new StringBuilder();
                f1 f1Var = this.X;
                sb2.append((Object) z.p.b(f1Var.f84e));
                sb2.append("#availableCaptureRequestKeys");
                String string = sb2.toString();
                try {
                    try {
                        Trace.beginSection(string);
                        if (Build.VERSION.SDK_INT >= 33) {
                            setE0 = ri.m.E0(h0.a(f1Var.Y, f1Var.X));
                            break;
                        } else {
                            setE0 = uVar;
                        }
                        return setE0;
                    } catch (Throwable th2) {
                        Log.w("CXCP", "Failed to get " + string + "! Caching {} and ignoring exception.", th2);
                        return uVar;
                    }
                } finally {
                    Trace.endSection();
                }
            case 1:
                ri.u uVar2 = ri.u.f18052e;
                StringBuilder sb3 = new StringBuilder();
                f1 f1Var2 = this.X;
                sb3.append((Object) z.p.b(f1Var2.f84e));
                sb3.append("#availableCaptureResultKeys");
                String string2 = sb3.toString();
                try {
                    try {
                        Trace.beginSection(string2);
                        if (Build.VERSION.SDK_INT >= 33) {
                            setE1 = ri.m.E0(h0.b(f1Var2.Y, f1Var2.X));
                            break;
                        } else {
                            setE1 = uVar2;
                        }
                        return setE1;
                    } finally {
                        Trace.endSection();
                    }
                } catch (Throwable th3) {
                    Log.w("CXCP", "Failed to get " + string2 + "! Caching {} and ignoring exception.", th3);
                    return uVar2;
                }
            case 2:
                StringBuilder sb4 = new StringBuilder();
                f1 f1Var3 = this.X;
                sb4.append((Object) z.p.b(f1Var3.f84e));
                sb4.append("#isPostviewSupported");
                String string3 = sb4.toString();
                boolean z5 = false;
                try {
                    try {
                        Trace.beginSection(string3);
                        boolean zB = Build.VERSION.SDK_INT >= 34 ? i0.b(f1Var3.Y, f1Var3.X) : false;
                        Trace.endSection();
                        z5 = zB;
                        break;
                    } catch (Throwable th4) {
                        Log.w("CXCP", "Failed to get " + string3 + "! Caching false and ignoring exception.", th4);
                    }
                    return Boolean.valueOf(z5);
                } catch (Throwable th5) {
                    Trace.endSection();
                    throw th5;
                }
            default:
                StringBuilder sb5 = new StringBuilder();
                f1 f1Var4 = this.X;
                sb5.append((Object) z.p.b(f1Var4.f84e));
                sb5.append("#isCaptureProgressSupported");
                String string4 = sb5.toString();
                boolean z6 = false;
                try {
                    try {
                        Trace.beginSection(string4);
                        boolean zA = Build.VERSION.SDK_INT >= 34 ? i0.a(f1Var4.Y, f1Var4.X) : false;
                        Trace.endSection();
                        z6 = zA;
                    } catch (Throwable th6) {
                        Trace.endSection();
                        throw th6;
                    }
                    break;
                } catch (Throwable th7) {
                    Log.w("CXCP", "Failed to get " + string4 + "! Caching false and ignoring exception.", th7);
                }
                return Boolean.valueOf(z6);
        }
    }
}
