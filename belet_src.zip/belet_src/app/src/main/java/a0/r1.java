package a0;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class r1 extends wi.c {
    public kotlinx.coroutines.x0 X;
    public /* synthetic */ Object Y;
    public final /* synthetic */ u1 Z;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public String f305e;

    /* JADX INFO: renamed from: r0, reason: collision with root package name */
    public int f306r0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public r1(u1 u1Var, wi.c cVar) {
        super(cVar);
        this.Z = u1Var;
    }

    @Override // wi.a
    public final Object invokeSuspend(Object obj) {
        this.Y = obj;
        this.f306r0 |= Integer.MIN_VALUE;
        return this.Z.b(null, this);
    }
}
