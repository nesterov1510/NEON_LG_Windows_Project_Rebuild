package a0;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class g4 extends wi.c {
    public String X;
    public Object Y;
    public /* synthetic */ Object Z;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public n4 f92e;

    /* JADX INFO: renamed from: r0, reason: collision with root package name */
    public final /* synthetic */ j4 f93r0;

    /* JADX INFO: renamed from: s0, reason: collision with root package name */
    public int f94s0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public g4(j4 j4Var, wi.c cVar) {
        super(cVar);
        this.f93r0 = j4Var;
    }

    @Override // wi.a
    public final Object invokeSuspend(Object obj) {
        this.Z = obj;
        this.f94s0 |= Integer.MIN_VALUE;
        return this.f93r0.h(null, this);
    }
}
