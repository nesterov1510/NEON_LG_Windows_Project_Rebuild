package a0;

import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import java.util.Set;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public abstract class e0 {
    public static final Set a(CameraManager cameraManager) {
        Set<Set<String>> concurrentCameraIds = cameraManager.getConcurrentCameraIds();
        kotlin.jvm.internal.q.f(concurrentCameraIds, "getConcurrentCameraIds(...)");
        return concurrentCameraIds;
    }

    public static final void b(CameraDevice cameraDevice, int i10) throws CameraAccessException {
        cameraDevice.setCameraAudioRestriction(i10);
    }
}
