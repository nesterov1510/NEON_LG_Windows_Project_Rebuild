package a0;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class k3 {
    public static final k3 X;
    public static final k3 Y;
    public static final k3 Z;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final k3 f159e;

    /* JADX INFO: renamed from: r0, reason: collision with root package name */
    public static final k3 f160r0;

    /* JADX INFO: renamed from: s0, reason: collision with root package name */
    public static final k3 f161s0;

    /* JADX INFO: renamed from: t0, reason: collision with root package name */
    public static final /* synthetic */ k3[] f162t0;

    static {
        k3 k3Var = new k3("APP_CLOSED", 0);
        f159e = k3Var;
        k3 k3Var2 = new k3("APP_DISCONNECTED", 1);
        X = k3Var2;
        k3 k3Var3 = new k3("CAMERA2_CLOSED", 2);
        Y = k3Var3;
        k3 k3Var4 = new k3("CAMERA2_DISCONNECTED", 3);
        Z = k3Var4;
        k3 k3Var5 = new k3("CAMERA2_ERROR", 4);
        f160r0 = k3Var5;
        k3 k3Var6 = new k3("CAMERA2_EXCEPTION", 5);
        f161s0 = k3Var6;
        k3[] k3VarArr = {k3Var, k3Var2, k3Var3, k3Var4, k3Var5, k3Var6};
        f162t0 = k3VarArr;
        android.support.v4.media.session.b.o(k3VarArr);
    }

    public static k3 valueOf(String str) {
        return (k3) Enum.valueOf(k3.class, str);
    }

    public static k3[] values() {
        return (k3[]) f162t0.clone();
    }
}
