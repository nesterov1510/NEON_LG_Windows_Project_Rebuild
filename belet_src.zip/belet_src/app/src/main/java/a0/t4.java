package a0;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executor;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class t4 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f330a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final List f331b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final ArrayList f332c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Executor f333d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final f2 f334e;
    public final int f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final Map f335g;

    public t4(int i10, ArrayList arrayList, ArrayList arrayList2, Executor executor, i3 stateCallback, int i11, Map sessionParameters) {
        kotlin.jvm.internal.q.g(executor, "executor");
        kotlin.jvm.internal.q.g(stateCallback, "stateCallback");
        kotlin.jvm.internal.q.g(sessionParameters, "sessionParameters");
        this.f330a = i10;
        this.f331b = arrayList;
        this.f332c = arrayList2;
        this.f333d = executor;
        this.f334e = stateCallback;
        this.f = i11;
        this.f335g = sessionParameters;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof t4)) {
            return false;
        }
        t4 t4Var = (t4) obj;
        return this.f330a == t4Var.f330a && kotlin.jvm.internal.q.c(this.f331b, t4Var.f331b) && this.f332c.equals(t4Var.f332c) && kotlin.jvm.internal.q.c(this.f333d, t4Var.f333d) && kotlin.jvm.internal.q.c(this.f334e, t4Var.f334e) && this.f == t4Var.f && kotlin.jvm.internal.q.c(this.f335g, t4Var.f335g);
    }

    public final int hashCode() {
        int i10 = this.f330a * 31;
        List list = this.f331b;
        return (this.f335g.hashCode() + ((((this.f334e.hashCode() + ((this.f333d.hashCode() + ((this.f332c.hashCode() + ((i10 + (list == null ? 0 : list.hashCode())) * 31)) * 31)) * 31)) * 31) + this.f) * 31)) * 31;
    }

    public final String toString() {
        return "SessionConfigData(sessionType=" + this.f330a + ", inputConfiguration=" + this.f331b + ", outputConfigurations=" + this.f332c + ", executor=" + this.f333d + ", stateCallback=" + this.f334e + ", sessionTemplateId=" + this.f + ", sessionParameters=" + this.f335g + ", sessionColorSpace=" + ((Object) kotlinx.serialization.json.internal.b.NULL) + ')';
    }
}
