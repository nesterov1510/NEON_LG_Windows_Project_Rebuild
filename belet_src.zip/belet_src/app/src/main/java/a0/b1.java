package a0;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class b1 extends wi.c {
    public final /* synthetic */ d1 X;
    public int Y;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public /* synthetic */ Object f11e;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public b1(d1 d1Var, wi.c cVar) {
        super(cVar);
        this.X = d1Var;
    }

    @Override // wi.a
    public final Object invokeSuspend(Object obj) {
        this.f11e = obj;
        this.Y |= Integer.MIN_VALUE;
        return this.X.d(this);
    }
}
