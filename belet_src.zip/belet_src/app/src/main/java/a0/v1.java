package a0;

import android.hardware.camera2.CameraDevice;
import android.os.SystemClock;
import android.os.Trace;
import android.util.Log;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class v1 extends wi.i implements ej.l {
    public final /* synthetic */ Object X;
    public final /* synthetic */ Object Y;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f360e;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ v1(Object obj, Object obj2, ui.d dVar, int i10) {
        super(1, dVar);
        this.f360e = i10;
        this.X = obj;
        this.Y = obj2;
    }

    @Override // wi.a
    public final ui.d create(ui.d dVar) {
        switch (this.f360e) {
            case 0:
                return new v1((CameraDevice) this.X, (kotlin.jvm.internal.a0) this.Y, dVar, 0);
            case 1:
                return new v1((i3) this.X, (c3) this.Y, dVar, 1);
            default:
                return new v1((i3) this.X, (d0.v) this.Y, dVar, 2);
        }
    }

    @Override // ej.l
    public final Object invoke(Object obj) {
        ui.d dVar = (ui.d) obj;
        switch (this.f360e) {
            case 0:
                v1 v1Var = (v1) create(dVar);
                qi.b0 b0Var = qi.b0.f17350a;
                v1Var.invokeSuspend(b0Var);
                return b0Var;
            case 1:
                v1 v1Var2 = (v1) create(dVar);
                qi.b0 b0Var2 = qi.b0.f17350a;
                v1Var2.invokeSuspend(b0Var2);
                return b0Var2;
            default:
                v1 v1Var3 = (v1) create(dVar);
                qi.b0 b0Var3 = qi.b0.f17350a;
                v1Var3.invokeSuspend(b0Var3);
                return b0Var3;
        }
    }

    @Override // wi.a
    public final Object invokeSuspend(Object obj) {
        int i10 = this.f360e;
        qi.b0 b0Var = qi.b0.f17350a;
        Object obj2 = this.Y;
        Object obj3 = this.X;
        switch (i10) {
            case 0:
                vi.a aVar = vi.a.f21252e;
                g6.y.I(obj);
                CameraDevice cameraDevice = (CameraDevice) obj3;
                if (cameraDevice != null) {
                    Log.i("CXCP", "Closing Camera " + cameraDevice.getId());
                    String str = "CXCP#CameraDevice-" + cameraDevice.getId() + "#close";
                    long jElapsedRealtimeNanos = SystemClock.elapsedRealtimeNanos();
                    try {
                        Trace.beginSection(str);
                        try {
                            cameraDevice.close();
                        } catch (NullPointerException e3) {
                            Log.w("CXCP", "NPE encountered during CameraDevice.close()", e3);
                        }
                        Log.d("CXCP", f.s(new Object[]{Double.valueOf(f.i(jElapsedRealtimeNanos) / 1000000.0d)}, 1, null, "%.3f ms", f.u(str, " - ")));
                    } catch (Throwable th2) {
                        Log.d("CXCP", f.s(new Object[]{Double.valueOf(f.i(jElapsedRealtimeNanos) / 1000000.0d)}, 1, null, "%.3f ms", f.u(str, " - ")));
                        throw th2;
                    }
                    break;
                }
                ((kotlin.jvm.internal.a0) obj2).f13945e = true;
                return b0Var;
            case 1:
                vi.a aVar2 = vi.a.f21252e;
                g6.y.I(obj);
                StringBuilder sb2 = new StringBuilder();
                i3 i3Var = (i3) obj3;
                sb2.append(i3Var);
                sb2.append(" CameraCaptureSessionWrapper#close");
                c3 c3Var = (c3) obj2;
                try {
                    Trace.beginSection(sb2.toString());
                    Log.d("CXCP", "Closing capture session for " + i3Var);
                    f.x(c3Var.f32a);
                    return b0Var;
                } finally {
                    Trace.endSection();
                }
            default:
                vi.a aVar3 = vi.a.f21252e;
                g6.y.I(obj);
                StringBuilder sb3 = new StringBuilder();
                i3 i3Var2 = (i3) obj3;
                sb3.append(i3Var2);
                sb3.append(" stopRepeating");
                d0.v vVar = (d0.v) obj2;
                try {
                    Trace.beginSection(sb3.toString());
                    vVar.m();
                    Trace.endSection();
                    try {
                        Trace.beginSection(i3Var2 + " abortCaptures");
                        vVar.c();
                        return b0Var;
                    } finally {
                        Trace.endSection();
                    }
                } catch (Throwable th3) {
                    Trace.endSection();
                    throw th3;
                }
        }
    }
}
