package a0;

import android.hardware.camera2.CaptureFailure;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class n implements z.f1 {
    public final int X;
    public final boolean Y;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final CaptureFailure f219e;

    public n(z.g1 requestMetadata, CaptureFailure captureFailure) {
        kotlin.jvm.internal.q.g(requestMetadata, "requestMetadata");
        this.f219e = captureFailure;
        captureFailure.getFrameNumber();
        this.X = captureFailure.getReason();
        this.Y = captureFailure.wasImageCaptured();
    }

    @Override // z.o1
    public final Object D(kotlin.jvm.internal.h hVar) {
        if (hVar.equals(kotlin.jvm.internal.e0.a(CaptureFailure.class))) {
            return this.f219e;
        }
        return null;
    }

    @Override // z.f1
    public final boolean H() {
        return this.Y;
    }

    @Override // z.f1
    public final int M() {
        return this.X;
    }
}
