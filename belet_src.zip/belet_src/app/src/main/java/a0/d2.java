package a0;

import android.os.Build;
import java.util.Map;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class d2 {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final Map f66c = ri.x.X(new qi.i("Google", ri.k.c0(new String[]{"oriole", "raven", "bluejay", "panther", "cheetah", "lynx"})));

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final Object f67d = ri.x.Y(new qi.i("google", ri.k.c0(new String[]{"pixel 4", "pixel 4 xl"})), new qi.i("samsung", m7.f.v("sm-g770f")));

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final c2 f68a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final z.n1 f69b;

    public d2(c2 metadataProvider, z.n1 strictMode) {
        kotlin.jvm.internal.q.g(metadataProvider, "metadataProvider");
        kotlin.jvm.internal.q.g(strictMode, "strictMode");
        this.f68a = metadataProvider;
        this.f69b = strictMode;
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0027  */
    public final boolean a(String cameraId) {
        boolean z5;
        kotlin.jvm.internal.q.g(cameraId, "cameraId");
        this.f69b.getClass();
        if (Build.VERSION.SDK_INT <= 32) {
            z.r rVar = z.s.f23390q0;
            z.s sVarE = ((b2) this.f68a).e(cameraId);
            rVar.getClass();
            if (z.r.c(sVarE)) {
                z5 = true;
            } else {
                z5 = false;
            }
        } else {
            z5 = false;
        }
        return z5 || ("motorola".equalsIgnoreCase(Build.BRAND) && "moto e20".equalsIgnoreCase(Build.MODEL) && cameraId.equals("1"));
    }
}
