package a0;

import android.hardware.camera2.params.OutputConfiguration;
import android.media.MediaCodec;
import android.os.Build;
import android.view.Surface;
import java.io.IOException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public abstract /* synthetic */ class w {
    public static hk.o1 a(hk.c3 c3Var, hk.o1 o1Var) throws IOException {
        try {
            return (hk.o1) c3Var.c(o1Var).toCompletableFuture().get(c3Var.a().toMillis(), TimeUnit.MILLISECONDS);
        } catch (InterruptedException e3) {
            Thread.currentThread().interrupt();
            throw new IOException(e3);
        } catch (ExecutionException e10) {
            if (e10.getCause() instanceof IOException) {
                throw ((IOException) e10.getCause());
            }
            if (e10.getCause() != null) {
                throw new IOException(e10.getCause());
            }
            throw new IOException(e10);
        } catch (TimeoutException e11) {
            throw new IOException("Timed out while trying to resolve " + o1Var.e().f9925e + "/" + hk.l4.f10051a.o(o1Var.e().X) + ", id=" + o1Var.f10072e.f10182e, e11);
        }
    }

    public static /* synthetic */ OutputConfiguration b(int i10, Surface surface) {
        return new OutputConfiguration(i10, surface);
    }

    public static /* synthetic */ OutputConfiguration c(Surface surface) {
        return new OutputConfiguration(surface);
    }

    public static /* synthetic */ MediaCodec.CryptoInfo.Pattern d() {
        return new MediaCodec.CryptoInfo.Pattern(0, 0);
    }

    public static /* synthetic */ void e() {
    }

    public static void f(bd.g gVar) {
        if ((Build.VERSION.SDK_INT <= 23 || gVar != ForkJoinPool.commonPool()) && !gVar.f3482e.isTerminated()) {
            gVar.shutdown();
            throw null;
        }
    }

    public static /* synthetic */ void g(ExecutorService executorService) {
        boolean zIsTerminated;
        if ((Build.VERSION.SDK_INT <= 23 || executorService != ForkJoinPool.commonPool()) && !(zIsTerminated = executorService.isTerminated())) {
            executorService.shutdown();
            boolean z5 = false;
            while (!zIsTerminated) {
                try {
                    zIsTerminated = executorService.awaitTermination(1L, TimeUnit.DAYS);
                } catch (InterruptedException unused) {
                    if (!z5) {
                        executorService.shutdownNow();
                        z5 = true;
                    }
                }
            }
            if (z5) {
                Thread.currentThread().interrupt();
            }
        }
    }

    public static /* synthetic */ void h(n8.e eVar) {
        boolean zIsTerminated;
        if ((Build.VERSION.SDK_INT <= 23 || eVar != ForkJoinPool.commonPool()) && !(zIsTerminated = eVar.isTerminated())) {
            eVar.shutdown();
            boolean z5 = false;
            while (!zIsTerminated) {
                try {
                    zIsTerminated = eVar.awaitTermination(1L, TimeUnit.DAYS);
                } catch (InterruptedException unused) {
                    if (!z5) {
                        eVar.shutdownNow();
                        z5 = true;
                    }
                }
            }
            if (z5) {
                Thread.currentThread().interrupt();
            }
        }
    }

    public static /* synthetic */ void i(q0.c cVar) {
        if (Build.VERSION.SDK_INT <= 23 || cVar != ForkJoinPool.commonPool()) {
            cVar.shutdown();
            throw null;
        }
    }

    public static void j(rc.v0 v0Var) {
        boolean zIsTerminated;
        ExecutorService executorService = v0Var.f18009e;
        if ((Build.VERSION.SDK_INT <= 23 || v0Var != ForkJoinPool.commonPool()) && !(zIsTerminated = executorService.isTerminated())) {
            v0Var.shutdown();
            boolean z5 = false;
            while (!zIsTerminated) {
                try {
                    zIsTerminated = executorService.awaitTermination(1L, TimeUnit.DAYS);
                } catch (InterruptedException unused) {
                    if (!z5) {
                        v0Var.shutdownNow();
                        z5 = true;
                    }
                }
            }
            if (z5) {
                Thread.currentThread().interrupt();
            }
        }
    }

    public static void k(rc.y0 y0Var) {
        boolean zIsTerminated;
        ExecutorService executorService = y0Var.f18009e;
        if ((Build.VERSION.SDK_INT <= 23 || y0Var != ForkJoinPool.commonPool()) && !(zIsTerminated = executorService.isTerminated())) {
            y0Var.shutdown();
            boolean z5 = false;
            while (!zIsTerminated) {
                try {
                    zIsTerminated = executorService.awaitTermination(1L, TimeUnit.DAYS);
                } catch (InterruptedException unused) {
                    if (!z5) {
                        y0Var.shutdownNow();
                        z5 = true;
                    }
                }
            }
            if (z5) {
                Thread.currentThread().interrupt();
            }
        }
    }

    public static /* synthetic */ void l() {
        if (Build.VERSION.SDK_INT <= 23 || ForkJoinPool.commonPool() != null) {
            throw null;
        }
    }
}
