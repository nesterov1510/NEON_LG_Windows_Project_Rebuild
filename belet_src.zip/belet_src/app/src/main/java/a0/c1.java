package a0;

import android.util.Log;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class c1 extends wi.i implements ej.p {
    public final /* synthetic */ long X;
    public final /* synthetic */ d1 Y;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f31e;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public c1(long j10, d1 d1Var, ui.d dVar) {
        super(2, dVar);
        this.X = j10;
        this.Y = d1Var;
    }

    @Override // wi.a
    public final ui.d create(Object obj, ui.d dVar) {
        return new c1(this.X, this.Y, dVar);
    }

    @Override // ej.p
    public final Object invoke(Object obj, Object obj2) {
        return ((c1) create((kotlinx.coroutines.p0) obj, (ui.d) obj2)).invokeSuspend(qi.b0.f17350a);
    }

    @Override // wi.a
    public final Object invokeSuspend(Object obj) {
        vi.a aVar = vi.a.f21252e;
        int i10 = this.f31e;
        if (i10 == 0) {
            g6.y.I(obj);
            long j10 = this.X;
            this.f31e = 1;
            if (kotlinx.coroutines.b1.delay(j10, this) == aVar) {
                return aVar;
            }
        } else {
            if (i10 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            g6.y.I(obj);
        }
        d1 d1Var = this.Y;
        synchronized (d1Var.f56q) {
            if (!d1Var.f() && !d1Var.f58s.equals(z.h.h) && !d1Var.f58s.equals(z.h.f23342g)) {
                Log.d("CXCP", "Restarting " + d1Var + "...");
                d1Var.f.m();
                d1.c(d1Var);
                d1Var.g();
            }
        }
        return qi.b0.f17350a;
    }
}
