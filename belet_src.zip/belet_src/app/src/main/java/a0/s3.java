package a0;

import java.util.ArrayList;
import java.util.LinkedHashMap;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class s3 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ArrayList f320a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final LinkedHashMap f321b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final r3 f322c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final LinkedHashMap f323d;

    public s3(ArrayList arrayList, LinkedHashMap linkedHashMap, x xVar, LinkedHashMap linkedHashMap2) {
        this.f320a = arrayList;
        this.f321b = linkedHashMap;
        this.f322c = xVar;
        this.f323d = linkedHashMap2;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof s3)) {
            return false;
        }
        s3 s3Var = (s3) obj;
        return this.f320a.equals(s3Var.f320a) && this.f321b.equals(s3Var.f321b) && kotlin.jvm.internal.q.c(this.f322c, s3Var.f322c) && this.f323d.equals(s3Var.f323d);
    }

    public final int hashCode() {
        int iHashCode = (this.f321b.hashCode() + (this.f320a.hashCode() * 31)) * 31;
        r3 r3Var = this.f322c;
        return this.f323d.hashCode() + ((iHashCode + (r3Var == null ? 0 : r3Var.hashCode())) * 31);
    }

    public final String toString() {
        return "OutputConfigurations(all=" + this.f320a + ", deferred=" + this.f321b + ", postviewOutput=" + this.f322c + ", outputSurfaceMap=" + this.f323d + ')';
    }
}
