package a0;

import tm.belet.films.presentation.activities.HomeActivity;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class u2 extends wi.i implements ej.p {
    public int X;
    public Object Y;
    public Object Z;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f348e = 0;

    /* JADX INFO: renamed from: r0, reason: collision with root package name */
    public Object f349r0;

    /* JADX INFO: renamed from: s0, reason: collision with root package name */
    public Object f350s0;

    /* JADX INFO: renamed from: t0, reason: collision with root package name */
    public Object f351t0;
    public Object u0;

    /* JADX INFO: renamed from: v0, reason: collision with root package name */
    public Object f352v0;

    /* JADX INFO: renamed from: w0, reason: collision with root package name */
    public final /* synthetic */ Object f353w0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public u2(v2 v2Var, String str, m mVar, ui.d dVar) {
        super(2, dVar);
        this.u0 = v2Var;
        this.f352v0 = str;
        this.f353w0 = mVar;
    }

    @Override // wi.a
    public final ui.d create(Object obj, ui.d dVar) {
        switch (this.f348e) {
            case 0:
                u2 u2Var = new u2((v2) this.u0, (String) this.f352v0, (m) this.f353w0, dVar);
                u2Var.f351t0 = obj;
                return u2Var;
            case 1:
                return new u2((bf.w0) this.f352v0, (bf.r0) this.f353w0, dVar);
            default:
                return new u2((im.a) this.f349r0, (HomeActivity) this.f350s0, (sm.m) this.f351t0, (Integer) this.u0, (String) this.f353w0, dVar);
        }
    }

    @Override // ej.p
    public final Object invoke(Object obj, Object obj2) {
        kotlinx.coroutines.p0 p0Var = (kotlinx.coroutines.p0) obj;
        ui.d dVar = (ui.d) obj2;
        switch (this.f348e) {
            case 0:
                break;
            case 1:
                break;
        }
        return ((u2) create(p0Var, dVar)).invokeSuspend(qi.b0.f17350a);
    }

    /* JADX WARN: Code duplicated, block: B:111:0x02cf A[Catch: all -> 0x025f, TRY_ENTER, TryCatch #1 {all -> 0x025f, blocks: (B:102:0x0254, B:128:0x0343, B:130:0x0347, B:132:0x0361, B:133:0x0364, B:135:0x036a, B:136:0x036d, B:138:0x0373, B:139:0x0376, B:141:0x037c, B:111:0x02cf, B:113:0x02de, B:114:0x02ea, B:116:0x02f0, B:117:0x02fc, B:119:0x0302, B:121:0x031b, B:123:0x0321, B:124:0x032d), top: B:150:0x0254 }] */
    /* JADX WARN: Code duplicated, block: B:113:0x02de A[Catch: all -> 0x025f, TryCatch #1 {all -> 0x025f, blocks: (B:102:0x0254, B:128:0x0343, B:130:0x0347, B:132:0x0361, B:133:0x0364, B:135:0x036a, B:136:0x036d, B:138:0x0373, B:139:0x0376, B:141:0x037c, B:111:0x02cf, B:113:0x02de, B:114:0x02ea, B:116:0x02f0, B:117:0x02fc, B:119:0x0302, B:121:0x031b, B:123:0x0321, B:124:0x032d), top: B:150:0x0254 }] */
    /* JADX WARN: Code duplicated, block: B:116:0x02f0 A[Catch: all -> 0x025f, TryCatch #1 {all -> 0x025f, blocks: (B:102:0x0254, B:128:0x0343, B:130:0x0347, B:132:0x0361, B:133:0x0364, B:135:0x036a, B:136:0x036d, B:138:0x0373, B:139:0x0376, B:141:0x037c, B:111:0x02cf, B:113:0x02de, B:114:0x02ea, B:116:0x02f0, B:117:0x02fc, B:119:0x0302, B:121:0x031b, B:123:0x0321, B:124:0x032d), top: B:150:0x0254 }] */
    /* JADX WARN: Code duplicated, block: B:119:0x0302 A[Catch: all -> 0x025f, TryCatch #1 {all -> 0x025f, blocks: (B:102:0x0254, B:128:0x0343, B:130:0x0347, B:132:0x0361, B:133:0x0364, B:135:0x036a, B:136:0x036d, B:138:0x0373, B:139:0x0376, B:141:0x037c, B:111:0x02cf, B:113:0x02de, B:114:0x02ea, B:116:0x02f0, B:117:0x02fc, B:119:0x0302, B:121:0x031b, B:123:0x0321, B:124:0x032d), top: B:150:0x0254 }] */
    /* JADX WARN: Code duplicated, block: B:120:0x0316  */
    /* JADX WARN: Code duplicated, block: B:123:0x0321 A[Catch: all -> 0x025f, TryCatch #1 {all -> 0x025f, blocks: (B:102:0x0254, B:128:0x0343, B:130:0x0347, B:132:0x0361, B:133:0x0364, B:135:0x036a, B:136:0x036d, B:138:0x0373, B:139:0x0376, B:141:0x037c, B:111:0x02cf, B:113:0x02de, B:114:0x02ea, B:116:0x02f0, B:117:0x02fc, B:119:0x0302, B:121:0x031b, B:123:0x0321, B:124:0x032d), top: B:150:0x0254 }] */
    /* JADX WARN: Code duplicated, block: B:126:0x033f  */
    /* JADX WARN: Code duplicated, block: B:127:0x0340  */
    /* JADX WARN: Code duplicated, block: B:130:0x0347 A[Catch: all -> 0x025f, TryCatch #1 {all -> 0x025f, blocks: (B:102:0x0254, B:128:0x0343, B:130:0x0347, B:132:0x0361, B:133:0x0364, B:135:0x036a, B:136:0x036d, B:138:0x0373, B:139:0x0376, B:141:0x037c, B:111:0x02cf, B:113:0x02de, B:114:0x02ea, B:116:0x02f0, B:117:0x02fc, B:119:0x0302, B:121:0x031b, B:123:0x0321, B:124:0x032d), top: B:150:0x0254 }] */
    /* JADX WARN: Code duplicated, block: B:132:0x0361 A[Catch: all -> 0x025f, TryCatch #1 {all -> 0x025f, blocks: (B:102:0x0254, B:128:0x0343, B:130:0x0347, B:132:0x0361, B:133:0x0364, B:135:0x036a, B:136:0x036d, B:138:0x0373, B:139:0x0376, B:141:0x037c, B:111:0x02cf, B:113:0x02de, B:114:0x02ea, B:116:0x02f0, B:117:0x02fc, B:119:0x0302, B:121:0x031b, B:123:0x0321, B:124:0x032d), top: B:150:0x0254 }] */
    /* JADX WARN: Code duplicated, block: B:135:0x036a A[Catch: all -> 0x025f, TryCatch #1 {all -> 0x025f, blocks: (B:102:0x0254, B:128:0x0343, B:130:0x0347, B:132:0x0361, B:133:0x0364, B:135:0x036a, B:136:0x036d, B:138:0x0373, B:139:0x0376, B:141:0x037c, B:111:0x02cf, B:113:0x02de, B:114:0x02ea, B:116:0x02f0, B:117:0x02fc, B:119:0x0302, B:121:0x031b, B:123:0x0321, B:124:0x032d), top: B:150:0x0254 }] */
    /* JADX WARN: Code duplicated, block: B:138:0x0373 A[Catch: all -> 0x025f, TryCatch #1 {all -> 0x025f, blocks: (B:102:0x0254, B:128:0x0343, B:130:0x0347, B:132:0x0361, B:133:0x0364, B:135:0x036a, B:136:0x036d, B:138:0x0373, B:139:0x0376, B:141:0x037c, B:111:0x02cf, B:113:0x02de, B:114:0x02ea, B:116:0x02f0, B:117:0x02fc, B:119:0x0302, B:121:0x031b, B:123:0x0321, B:124:0x032d), top: B:150:0x0254 }] */
    /* JADX WARN: Code duplicated, block: B:141:0x037c A[Catch: all -> 0x025f, TRY_LEAVE, TryCatch #1 {all -> 0x025f, blocks: (B:102:0x0254, B:128:0x0343, B:130:0x0347, B:132:0x0361, B:133:0x0364, B:135:0x036a, B:136:0x036d, B:138:0x0373, B:139:0x0376, B:141:0x037c, B:111:0x02cf, B:113:0x02de, B:114:0x02ea, B:116:0x02f0, B:117:0x02fc, B:119:0x0302, B:121:0x031b, B:123:0x0321, B:124:0x032d), top: B:150:0x0254 }] */
    /* JADX WARN: Code duplicated, block: B:143:0x0381  */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r13v1, types: [ui.d] */
    /* JADX WARN: Type inference failed for: r13v5 */
    /* JADX WARN: Type inference failed for: r13v7 */
    /* JADX WARN: Type inference failed for: r16v1, types: [ui.d] */
    /* JADX WARN: Type inference failed for: r1v13 */
    /* JADX WARN: Type inference failed for: r1v42 */
    /* JADX WARN: Type inference failed for: r1v5, types: [a0.m] */
    /* JADX WARN: Type inference failed for: r1v6 */
    /* JADX WARN: Type inference failed for: r1v7, types: [ui.d] */
    /* JADX WARN: Type inference failed for: r1v8 */
    /* JADX WARN: Type inference failed for: r1v9, types: [java.lang.Object, java.util.concurrent.CancellationException] */
    /* JADX WARN: Type inference failed for: r23v0 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:127:0x0340 -> B:128:0x0343). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions stack size limit reached
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
        */
    @Override // wi.a
    public final java.lang.Object invokeSuspend(java.lang.Object r25) {
        /*
            Method dump skipped, instruction units count: 932
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: a0.u2.invokeSuspend(java.lang.Object):java.lang.Object");
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public u2(bf.w0 w0Var, bf.r0 r0Var, ui.d dVar) {
        super(2, dVar);
        this.f352v0 = w0Var;
        this.f353w0 = r0Var;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public u2(im.a aVar, HomeActivity homeActivity, sm.m mVar, Integer num, String str, ui.d dVar) {
        super(2, dVar);
        this.f349r0 = aVar;
        this.f350s0 = homeActivity;
        this.f351t0 = mVar;
        this.u0 = num;
        this.f353w0 = str;
    }
}
