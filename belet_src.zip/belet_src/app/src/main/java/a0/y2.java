package a0;

import java.util.Map;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class y2 implements z2 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Object f392a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Object f393b;

    public y2(Map map, Map map2) {
        this.f392a = map;
        this.f393b = map2;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof y2)) {
            return false;
        }
        y2 y2Var = (y2) obj;
        return this.f392a.equals(y2Var.f392a) && this.f393b.equals(y2Var.f393b);
    }

    public final int hashCode() {
        return this.f393b.hashCode() + (this.f392a.hashCode() * 31);
    }

    public final String toString() {
        return "Success(deferred=" + this.f392a + ", outputSurfaceMap=" + this.f393b + ')';
    }
}
