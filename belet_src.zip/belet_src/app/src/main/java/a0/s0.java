package a0;

import android.hardware.camera2.CameraManager;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class s0 extends CameraManager.AvailabilityCallback {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ kotlinx.coroutines.channels.y f316a;

    public s0(kotlinx.coroutines.channels.y yVar) {
        this.f316a = yVar;
    }

    @Override // android.hardware.camera2.CameraManager.AvailabilityCallback
    public final void onCameraAvailable(String cameraIdString) {
        kotlin.jvm.internal.q.g(cameraIdString, "cameraIdString");
        z.p.a(cameraIdString);
        kotlinx.coroutines.channels.p.trySendBlocking(this.f316a, new z.p(cameraIdString));
    }
}
