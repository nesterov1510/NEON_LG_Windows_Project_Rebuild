package a0;

import android.media.ImageWriter;
import android.view.Surface;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public abstract class d0 {
    public static final ImageWriter a(int i10, Surface surface) {
        ImageWriter imageWriterNewInstance = ImageWriter.newInstance(surface, 1, i10);
        kotlin.jvm.internal.q.f(imageWriterNewInstance, "newInstance(...)");
        return imageWriterNewInstance;
    }
}
