package a0;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class o0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final h2 f243a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final m f244b;

    public o0(h2 h2Var, m mVar) {
        this.f243a = h2Var;
        this.f244b = mVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof o0)) {
            return false;
        }
        o0 o0Var = (o0) obj;
        return kotlin.jvm.internal.q.c(this.f243a, o0Var.f243a) && kotlin.jvm.internal.q.c(this.f244b, o0Var.f244b);
    }

    public final int hashCode() {
        h2 h2Var = this.f243a;
        int iHashCode = (h2Var == null ? 0 : h2Var.hashCode()) * 31;
        m mVar = this.f244b;
        return iHashCode + (mVar != null ? mVar.hashCode() : 0);
    }

    public final String toString() {
        return "AwaitOpenCameraResult(cameraDeviceWrapper=" + this.f243a + ", androidCameraState=" + this.f244b + ')';
    }
}
