package a0;

import java.util.Iterator;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class e4 extends wi.c {
    public Iterator X;
    public /* synthetic */ Object Y;
    public final /* synthetic */ j4 Z;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public l4 f82e;

    /* JADX INFO: renamed from: r0, reason: collision with root package name */
    public int f83r0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public e4(j4 j4Var, wi.c cVar) {
        super(cVar);
        this.Z = j4Var;
    }

    @Override // wi.a
    public final Object invokeSuspend(Object obj) {
        this.Y = obj;
        this.f83r0 |= Integer.MIN_VALUE;
        return this.Z.f(null, this);
    }
}
