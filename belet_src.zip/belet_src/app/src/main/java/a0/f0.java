package a0;

import android.content.ClipData;
import android.graphics.fonts.Font;
import android.hardware.camera2.params.InputConfiguration;
import android.hardware.camera2.params.MultiResolutionStreamInfo;
import android.view.ContentInfo;
import java.util.ArrayList;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public abstract /* synthetic */ class f0 {
    public static /* synthetic */ Font.Builder a(Font font) {
        return new Font.Builder(font);
    }

    public static /* synthetic */ InputConfiguration b(ArrayList arrayList, int i10) {
        return new InputConfiguration(arrayList, i10);
    }

    public static /* synthetic */ MultiResolutionStreamInfo c(int i10, int i11, String str) {
        return new MultiResolutionStreamInfo(i10, i11, str);
    }

    public static /* synthetic */ ContentInfo.Builder d(ClipData clipData, int i10) {
        return new ContentInfo.Builder(clipData, i10);
    }

    public static /* synthetic */ void e() {
    }
}
