package a0;

import android.hardware.camera2.CameraExtensionCharacteristics;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.CaptureResult;
import android.hardware.camera2.params.OutputConfiguration;
import java.util.Set;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public abstract class h0 {
    public static final Set a(CameraExtensionCharacteristics cameraExtensionCharacteristics, int i10) {
        Set<CaptureRequest.Key> availableCaptureRequestKeys = cameraExtensionCharacteristics.getAvailableCaptureRequestKeys(i10);
        kotlin.jvm.internal.q.f(availableCaptureRequestKeys, "getAvailableCaptureRequestKeys(...)");
        return availableCaptureRequestKeys;
    }

    public static final Set b(CameraExtensionCharacteristics cameraExtensionCharacteristics, int i10) {
        Set<CaptureResult.Key> availableCaptureResultKeys = cameraExtensionCharacteristics.getAvailableCaptureResultKeys(i10);
        kotlin.jvm.internal.q.f(availableCaptureResultKeys, "getAvailableCaptureResultKeys(...)");
        return availableCaptureResultKeys;
    }

    public static final void c(OutputConfiguration outputConfiguration, long j10) {
        outputConfiguration.setDynamicRangeProfile(j10);
    }

    public static final void d(OutputConfiguration outputConfiguration, int i10) {
        outputConfiguration.setMirrorMode(i10);
    }

    public static final void e(OutputConfiguration outputConfiguration, long j10) {
        outputConfiguration.setStreamUseCase(j10);
    }
}
