package a0;

import android.content.Context;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.concurrent.Executor;
import okhttp3.Handshake;
import okhttp3.internal.connection.ConnectPlan;
import okhttp3.internal.http2.Http2Connection;
import okhttp3.internal.ws.WebSocketProtocol;
import tm.belet.films.domain.background.PlaybackService;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class q1 implements ej.a {
    public final /* synthetic */ Object X;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f283e;

    public /* synthetic */ q1(int i10, Object obj) {
        this.f283e = i10;
        this.X = obj;
    }

    /* JADX WARN: Code duplicated, block: B:45:0x00a4 A[PHI: r2
      0x00a4: PHI (r2v1 int) = (r2v0 int), (r2v2 int), (r2v3 int) binds: [B:34:0x008e, B:36:0x0091, B:38:0x0094] A[DONT_GENERATE, DONT_INLINE]] */
    @Override // ej.a
    public final Object invoke() throws InterruptedException {
        int i10 = this.f283e;
        int i11 = 3;
        int i12 = 0;
        qi.b0 b0Var = qi.b0.f17350a;
        Object obj = this.X;
        switch (i10) {
            case 0:
                return (b1.e) ((u1) obj).f341d.get();
            case 1:
                return androidx.lifecycle.r0.f((androidx.lifecycle.c1) obj);
            case 2:
                ((bf.n1) obj).getClass();
                UUID uuidRandomUUID = UUID.randomUUID();
                kotlin.jvm.internal.q.f(uuidRandomUUID, "randomUUID(...)");
                String string = uuidRandomUUID.toString();
                kotlin.jvm.internal.q.f(string, "toString(...)");
                return string;
            case 3:
                bp.d dVar = (bp.d) obj;
                dVar.post(new bp.a(dVar, i11));
                return b0Var;
            case 4:
                ((androidx.appcompat.app.j) obj).reportFullyDrawn();
                return null;
            case 5:
                return (Executor) ((b0.g) obj).invoke();
            case 6:
                ((cf.a) obj).f4518a.await();
                return b0Var;
            case 7:
                androidx.media3.session.g2 g2Var = PlaybackService.S0;
                Context applicationContext = ((PlaybackService) obj).getApplicationContext();
                kotlin.jvm.internal.q.f(applicationContext, "getApplicationContext(...)");
                return (sk.c0) ((mk.g) ((PlaybackService.a) a.a.k(applicationContext, PlaybackService.a.class))).f15515i.get();
            case 8:
                return ((Callable) obj).call();
            case 9:
                return ((g6.d0) obj).b();
            case 10:
                return ((go.d) obj).c0();
            case ue.r.NETWORK_CLIENT_ERROR_REASON_FIELD_NUMBER /* 11 */:
                return ((go.f0) obj).c0();
            case ue.r.CUSTOM_ATTRIBUTES_FIELD_NUMBER /* 12 */:
                return ((go.s3) obj).q0().f7110p;
            case ue.r.PERF_SESSIONS_FIELD_NUMBER /* 13 */:
                return ((go.x4) obj).c0();
            case 14:
                int iOrdinal = ((h0.a) obj).a().ordinal();
                if (iOrdinal != 0) {
                    i12 = 1;
                    if (iOrdinal != 1) {
                        i12 = 2;
                        if (iOrdinal == 2) {
                            i11 = i12;
                        } else if (iOrdinal != 3) {
                            i11 = 4;
                            if (iOrdinal != 4) {
                                throw new ad.n(11);
                            }
                        }
                    } else {
                        i11 = i12;
                    }
                } else {
                    i11 = i12;
                }
                return Integer.valueOf(i11);
            case WebSocketProtocol.B0_MASK_OPCODE /* 15 */:
                return ((ho.i1) obj).c0();
            case WebSocketProtocol.B0_FLAG_RSV3 /* 16 */:
                return ((m7.e) obj).d(":memory:");
            case 17:
                i6.r rVar = (i6.r) obj;
                return rVar.f11308e.d(rVar.X);
            case 18:
                return ((bi.d) ((bi.e) obj)).e();
            case 19:
                return ((kotlin.jvm.internal.j0) obj).f13958e.findJavaDeclaration();
            case 20:
                return kotlinx.serialization.e.descriptor_delegate$lambda$0((kotlinx.serialization.e) obj);
            case 21:
                return Integer.valueOf(kotlinx.serialization.descriptors.h._hashCode_delegate$lambda$0((kotlinx.serialization.descriptors.h) obj));
            case 22:
                return obj;
            case 23:
                return ((lo.c) obj).c0();
            case 24:
                return ((lo.f) obj).c0();
            case 25:
                return ((lo.i) obj).c0();
            case 26:
                return ((lo.k) obj).c0();
            case 27:
                m6.d dVar2 = (m6.d) obj;
                dVar2.u().a(new m6.a(i12, dVar2));
                return b0Var;
            case 28:
                return ConnectPlan.connectTls$lambda$1((Handshake) obj);
            default:
                return Http2Connection.sendDegradedPingLater$lambda$1((Http2Connection) obj);
        }
    }
}
