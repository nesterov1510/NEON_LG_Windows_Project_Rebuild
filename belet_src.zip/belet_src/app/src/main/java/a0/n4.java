package a0;

import java.util.List;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class n4 extends k2 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final b5 f233a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final List f234b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final d0.u f235c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final y0 f236d;

    public n4(b5 b5Var, List list, d0.u uVar, y0 y0Var) {
        this.f233a = b5Var;
        this.f234b = list;
        this.f235c = uVar;
        this.f236d = y0Var;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof n4)) {
            return false;
        }
        n4 n4Var = (n4) obj;
        return this.f233a.equals(n4Var.f233a) && this.f234b.equals(n4Var.f234b) && this.f235c.equals(n4Var.f235c) && this.f236d.equals(n4Var.f236d);
    }

    public final int hashCode() {
        return this.f236d.hashCode() + ((((this.f235c.hashCode() + ((this.f234b.hashCode() + (this.f233a.hashCode() * 31)) * 31)) * 31) + 1237) * 31);
    }

    public final String toString() {
        return "RequestOpen(virtualCamera=" + this.f233a + ", sharedCameraIds=" + this.f234b + ", graphListener=" + this.f235c + ", isPrewarm=false, isForegroundObserver=" + this.f236d + ')';
    }
}
