package a0;

import androidx.media3.session.n5;
import java.util.Set;
import java.util.concurrent.CancellationException;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final m f38a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Set f39b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public b5 f40c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final n5 f41d;

    public d(m androidCameraState, Set set, kotlinx.coroutines.p0 scope, t3 t3Var) {
        kotlin.jvm.internal.q.g(androidCameraState, "androidCameraState");
        kotlin.jvm.internal.q.g(scope, "scope");
        this.f38a = androidCameraState;
        this.f39b = set;
        this.f41d = new n5(scope, new a(t3Var, this, 0));
        kotlinx.coroutines.k.launch$default(scope, null, null, new c(this, null, 0), 3, null);
    }

    public final c0.f a() {
        n5 n5Var = this.f41d;
        synchronized (n5Var.X) {
            try {
                if (n5Var.Z) {
                    return null;
                }
                int i10 = n5Var.Y + 1;
                n5Var.Y = i10;
                if (i10 == 1) {
                    kotlinx.coroutines.f2 f2Var = (kotlinx.coroutines.f2) n5Var.f2560t0;
                    if (f2Var != null) {
                        kotlinx.coroutines.d2.cancel$default(f2Var, (CancellationException) null, 1, (Object) null);
                    }
                    n5Var.f2560t0 = null;
                }
                return new c0.f(n5Var);
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    public final Object b(wi.c cVar) {
        Object objFirst = kotlinx.coroutines.flow.k.first(this.f38a.f196u, new b(2, null, 1), cVar);
        vi.a aVar = vi.a.f21252e;
        qi.b0 b0Var = qi.b0.f17350a;
        if (objFirst != aVar) {
            objFirst = b0Var;
        }
        return objFirst == aVar ? objFirst : b0Var;
    }

    public final void c() {
        this.f41d.c();
        this.f38a.a();
    }

    public final qi.b0 d(b5 b5Var, c0.f fVar) {
        qi.b0 b0Var = qi.b0.f17350a;
        b5 b5Var2 = this.f40c;
        this.f40c = b5Var;
        ui.d dVar = null;
        if (b5Var2 != null) {
            b5Var2.a(null);
        }
        kotlinx.coroutines.flow.h0 h0Var = this.f38a.f196u;
        synchronized (b5Var.f24e) {
            if (b5Var.f) {
                fVar.b();
            } else {
                b5Var.f28k = kotlinx.coroutines.k.launch$default(b5Var.f22c, null, null, new t0(h0Var, b5Var, dVar, 4), 3, null);
                b5Var.f29l = fVar;
            }
        }
        vi.a aVar = vi.a.f21252e;
        return b0Var;
    }

    public final String toString() {
        StringBuilder sb2 = new StringBuilder("ActiveCamera(cameraId=");
        sb2.append((Object) z.p.b(this.f38a.f178a));
        sb2.append(")@");
        int iHashCode = hashCode();
        tc.b.b(16);
        String string = Integer.toString(iHashCode, 16);
        kotlin.jvm.internal.q.f(string, "toString(...)");
        sb2.append(string);
        return sb2.toString();
    }
}
