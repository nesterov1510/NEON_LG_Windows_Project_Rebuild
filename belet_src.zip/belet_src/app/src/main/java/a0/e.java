package a0;

import android.hardware.camera2.params.OutputConfiguration;
import android.os.Looper;
import android.window.OnBackInvokedDispatcher;
import j$.util.Objects;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class e implements ae.a, l3.n, l3.m, androidx.media3.session.c2, androidx.media3.session.m3 {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f74e;

    public /* synthetic */ e(int i10) {
        this.f74e = i10;
    }

    public static /* bridge */ /* synthetic */ OutputConfiguration e(Object obj) {
        return (OutputConfiguration) obj;
    }

    public static /* bridge */ /* synthetic */ OnBackInvokedDispatcher f(Object obj) {
        return (OnBackInvokedDispatcher) obj;
    }

    public static /* bridge */ /* synthetic */ Class h() {
        return OutputConfiguration.class;
    }

    @Override // l3.n
    public void a(Object obj, i3.r rVar) {
        i3.y0 y0Var = (i3.y0) obj;
        switch (this.f74e) {
            case 21:
                y0Var.x(new i3.x0(rVar));
                break;
            default:
                y0Var.x(new i3.x0(rVar));
                break;
        }
    }

    @Override // androidx.media3.session.m3
    public void b(androidx.media3.session.c3 c3Var, int i10) {
        c3Var.getClass();
    }

    @Override // l3.m
    public void invoke(Object obj) {
        switch (this.f74e) {
            case 22:
                ((i3.y0) obj).q(1);
                break;
            default:
                ((i3.y0) obj).o(0.0f);
                break;
        }
    }

    @Override // androidx.media3.session.c2
    public void k(androidx.media3.session.r1 r1Var) {
        switch (this.f74e) {
            case 25:
                androidx.media3.session.b0 b0Var = r1Var.f2606a;
                if (r1Var.b1()) {
                    b0Var.getClass();
                    ji.k.A(Looper.myLooper() == b0Var.f2187r0.getLooper());
                    b0Var.Z.getClass();
                    return;
                }
                return;
            case 26:
                r1Var.f2612i.f(26, new ge.i(7));
                return;
            case 27:
                androidx.media3.session.b0 b0Var2 = r1Var.f2606a;
                Objects.requireNonNull(b0Var2);
                b0Var2.D0(new l0(6, b0Var2));
                return;
            default:
                throw new ClassCastException();
        }
    }

    @Override // ae.a
    public void g(ae.b bVar) {
    }
}
