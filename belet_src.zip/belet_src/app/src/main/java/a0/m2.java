package a0;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class m2 extends l2 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f209a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final k3 f210b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Integer f211c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final c0.d f212d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final Throwable f213e;
    public final c0.d f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final c0.d f214g;
    public final c0.d h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final z.i f215i;

    public m2(String cameraId, k3 cameraClosedReason, Integer num, c0.d dVar, Throwable th2, c0.d dVar2, c0.d dVar3, c0.d dVar4, z.i iVar) {
        kotlin.jvm.internal.q.g(cameraId, "cameraId");
        kotlin.jvm.internal.q.g(cameraClosedReason, "cameraClosedReason");
        this.f209a = cameraId;
        this.f210b = cameraClosedReason;
        this.f211c = num;
        this.f212d = dVar;
        this.f213e = th2;
        this.f = dVar2;
        this.f214g = dVar3;
        this.h = dVar4;
        this.f215i = iVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof m2)) {
            return false;
        }
        m2 m2Var = (m2) obj;
        return kotlin.jvm.internal.q.c(this.f209a, m2Var.f209a) && this.f210b == m2Var.f210b && kotlin.jvm.internal.q.c(this.f211c, m2Var.f211c) && kotlin.jvm.internal.q.c(this.f212d, m2Var.f212d) && kotlin.jvm.internal.q.c(this.f213e, m2Var.f213e) && kotlin.jvm.internal.q.c(this.f, m2Var.f) && kotlin.jvm.internal.q.c(this.f214g, m2Var.f214g) && kotlin.jvm.internal.q.c(this.h, m2Var.h) && kotlin.jvm.internal.q.c(this.f215i, m2Var.f215i);
    }

    public final int hashCode() {
        int iHashCode = (this.f210b.hashCode() + (this.f209a.hashCode() * 31)) * 31;
        Integer num = this.f211c;
        int iHashCode2 = (iHashCode + (num == null ? 0 : num.hashCode())) * 31;
        c0.d dVar = this.f212d;
        int iB = (iHashCode2 + (dVar == null ? 0 : c0.d.b(dVar.f3831a))) * 31;
        Throwable th2 = this.f213e;
        int iHashCode3 = (iB + (th2 == null ? 0 : th2.hashCode())) * 31;
        c0.d dVar2 = this.f;
        int iB2 = (iHashCode3 + (dVar2 == null ? 0 : c0.d.b(dVar2.f3831a))) * 31;
        c0.d dVar3 = this.f214g;
        int iB3 = (iB2 + (dVar3 == null ? 0 : c0.d.b(dVar3.f3831a))) * 31;
        c0.d dVar4 = this.h;
        int iB4 = (iB3 + (dVar4 == null ? 0 : c0.d.b(dVar4.f3831a))) * 31;
        z.i iVar = this.f215i;
        return iB4 + (iVar != null ? iVar.f23344a : 0);
    }

    public final String toString() {
        return "CameraStateClosed(cameraId=" + ((Object) z.p.b(this.f209a)) + ", cameraClosedReason=" + this.f210b + ", cameraRetryCount=" + this.f211c + ", cameraRetryDurationNs=" + this.f212d + ", cameraException=" + this.f213e + ", cameraOpenDurationNs=" + this.f + ", cameraActiveDurationNs=" + this.f214g + ", cameraClosingDurationNs=" + this.h + ", cameraErrorCode=" + this.f215i + ')';
    }
}
