package a0;

import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.TotalCaptureResult;
import android.hardware.camera2.params.ExtensionSessionConfiguration;
import android.hardware.camera2.params.InputConfiguration;
import android.hardware.camera2.params.OutputConfiguration;
import android.hardware.camera2.params.SessionConfiguration;
import android.os.Build;
import android.os.Handler;
import android.os.SystemClock;
import android.os.Trace;
import android.util.Log;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executor;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class i implements h2 {
    public final CameraDevice X;
    public final String Y;
    public final a2 Z;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final z.s f104e;

    /* JADX INFO: renamed from: r0, reason: collision with root package name */
    public final m7.c f105r0;

    /* JADX INFO: renamed from: s0, reason: collision with root package name */
    public final c0.n f106s0;

    /* JADX INFO: renamed from: t0, reason: collision with root package name */
    public final pj.a f107t0;
    public final pj.e u0;

    public i(z.s cameraMetadata, CameraDevice cameraDevice, String cameraId, a2 cameraErrorListener, m7.c cVar, c0.n threads) {
        kotlin.jvm.internal.q.g(cameraMetadata, "cameraMetadata");
        kotlin.jvm.internal.q.g(cameraId, "cameraId");
        kotlin.jvm.internal.q.g(cameraErrorListener, "cameraErrorListener");
        kotlin.jvm.internal.q.g(threads, "threads");
        this.f104e = cameraMetadata;
        this.X = cameraDevice;
        this.Y = cameraId;
        this.Z = cameraErrorListener;
        this.f105r0 = cVar;
        this.f106s0 = threads;
        this.f107t0 = pj.b.atomic(false);
        this.u0 = pj.b.atomic((Object) null);
    }

    @Override // a0.h2
    public final CaptureRequest.Builder C(TotalCaptureResult totalCaptureResult) throws Throwable {
        double d2;
        CaptureRequest.Builder builderCreateReprocessCaptureRequest;
        StringBuilder sb2 = new StringBuilder("CXCP#createReprocessCaptureRequest-");
        String str = this.Y;
        sb2.append(str);
        String string = sb2.toString();
        long jElapsedRealtimeNanos = SystemClock.elapsedRealtimeNanos();
        try {
            Trace.beginSection(string);
            d2 = 1000000.0d;
            try {
                a2 a2Var = this.Z;
                try {
                    builderCreateReprocessCaptureRequest = this.X.createReprocessCaptureRequest(totalCaptureResult);
                } catch (Exception e3) {
                    if (e3 instanceof CameraAccessException) {
                        Log.w("CXCP", "Failed to execute call: Camera encountered an error: " + e3.getMessage());
                        CameraAccessException cameraAccessException = (CameraAccessException) e3;
                        int reason = cameraAccessException.getReason();
                        int i10 = 3;
                        if (reason != 1) {
                            if (reason == 2) {
                                i10 = 6;
                            } else if (reason == 3) {
                                i10 = 0;
                            } else if (reason == 4) {
                                i10 = 1;
                            } else if (reason != 5) {
                                Log.w("CXCP", "Unexpected CameraAccessException: " + cameraAccessException);
                                i10 = 11;
                            } else {
                                i10 = 2;
                            }
                        }
                        a2Var.a(str, true, i10);
                    } else if ((e3 instanceof IllegalArgumentException) || (e3 instanceof SecurityException) || (e3 instanceof UnsupportedOperationException) || (e3 instanceof NullPointerException)) {
                        Log.w("CXCP", "Failed to execute call: Unexpected exception: " + e3.getMessage());
                        a2Var.a(str, false, 9);
                    } else {
                        if (!(e3 instanceof IllegalStateException)) {
                            throw e3;
                        }
                        Log.d("CXCP", "Failed to execute call: Camera may be closed");
                    }
                    builderCreateReprocessCaptureRequest = null;
                }
                Log.d("CXCP", f.s(new Object[]{Double.valueOf(f.i(jElapsedRealtimeNanos) / 1000000.0d)}, 1, null, "%.3f ms", f.u(string, " - ")));
                return builderCreateReprocessCaptureRequest;
            } catch (Throwable th2) {
                th = th2;
                Log.d("CXCP", f.s(new Object[]{Double.valueOf(f.i(jElapsedRealtimeNanos) / d2)}, 1, null, "%.3f ms", f.u(string, " - ")));
                throw th;
            }
        } catch (Throwable th3) {
            th = th3;
            d2 = 1000000.0d;
        }
    }

    @Override // z.o1
    public final Object D(kotlin.jvm.internal.h hVar) {
        if (hVar.equals(kotlin.jvm.internal.e0.a(CameraDevice.class))) {
            return this.X;
        }
        return null;
    }

    @Override // a0.h2
    public final void E(int i10) {
        try {
            Trace.beginSection("setCameraAudioRestriction");
            String str = this.Y;
            a2 a2Var = this.Z;
            try {
                e0.b(this.X, i10);
            } catch (Exception e3) {
                int i11 = 0;
                if (e3 instanceof CameraAccessException) {
                    Log.w("CXCP", "Failed to execute call: Camera encountered an error: " + e3.getMessage());
                    CameraAccessException cameraAccessException = (CameraAccessException) e3;
                    int reason = cameraAccessException.getReason();
                    if (reason == 1) {
                        i11 = 3;
                    } else if (reason == 2) {
                        i11 = 6;
                    } else if (reason != 3) {
                        if (reason == 4) {
                            i11 = 1;
                        } else if (reason != 5) {
                            Log.w("CXCP", "Unexpected CameraAccessException: " + cameraAccessException);
                            i11 = 11;
                        } else {
                            i11 = 2;
                        }
                    }
                    a2Var.a(str, true, i11);
                } else if ((e3 instanceof IllegalArgumentException) || (e3 instanceof SecurityException) || (e3 instanceof UnsupportedOperationException) || (e3 instanceof NullPointerException)) {
                    Log.w("CXCP", "Failed to execute call: Unexpected exception: " + e3.getMessage());
                    a2Var.a(str, false, 9);
                } else {
                    if (!(e3 instanceof IllegalStateException)) {
                        throw e3;
                    }
                    Log.d("CXCP", "Failed to execute call: Camera may be closed");
                }
            }
            Trace.endSection();
        } catch (Throwable th2) {
            Trace.endSection();
            throw th2;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r9v3 */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    @Override // a0.h2
    public final boolean F(ArrayList arrayList, f2 stateCallback) throws Throwable {
        String str;
        int i10;
        String str2;
        String str3;
        x4 x4Var;
        boolean z5;
        char c10;
        qi.b0 b0Var;
        int i11;
        c0.n nVar = this.f106s0;
        CameraDevice cameraDevice = this.X;
        kotlin.jvm.internal.q.g(stateCallback, "stateCallback");
        qi.i iVarA = a(stateCallback);
        boolean zBooleanValue = ((Boolean) iVarA.f17355e).booleanValue();
        x4 x4Var2 = (x4) iVarA.X;
        if (!zBooleanValue) {
            return false;
        }
        if (x4Var2 != null) {
            b(x4Var2);
        }
        String str4 = this.Y;
        String strU = w.x0.u("CXCP#createConstrainedHighSpeedCaptureSession-", str4);
        long jElapsedRealtimeNanos = SystemClock.elapsedRealtimeNanos();
        try {
            try {
                Trace.beginSection(strU);
                a2 a2Var = this.Z;
                try {
                    x4Var = x4Var2;
                    try {
                        a2 a2Var2 = this.Z;
                        m7.c cVar = this.f105r0;
                        try {
                            Handler handlerA = nVar.a();
                            str3 = strU;
                            z5 = true;
                            try {
                                cameraDevice.createConstrainedHighSpeedCaptureSession(arrayList, new o(this, stateCallback, x4Var, a2Var2, cVar, handlerA), nVar.a());
                                b0Var = qi.b0.f17350a;
                                c10 = 0;
                                i11 = z5;
                            } catch (Exception e3) {
                                e = e3;
                                if (e instanceof CameraAccessException) {
                                    Log.w("CXCP", "Failed to execute call: Camera encountered an error: " + e.getMessage());
                                    CameraAccessException cameraAccessException = (CameraAccessException) e;
                                    int reason = cameraAccessException.getReason();
                                    int i12 = 3;
                                    if (reason != z5) {
                                        if (reason == 2) {
                                            i12 = 6;
                                        } else if (reason == 3) {
                                            i12 = 0;
                                        } else if (reason == 4) {
                                            i12 = z5;
                                        } else if (reason != 5) {
                                            Log.w("CXCP", "Unexpected CameraAccessException: " + cameraAccessException);
                                            i12 = 11;
                                        } else {
                                            i12 = 2;
                                        }
                                    }
                                    a2Var.a(str4, z5, i12);
                                } else {
                                    if ((e instanceof IllegalArgumentException) || (e instanceof SecurityException) || (e instanceof UnsupportedOperationException) || (e instanceof NullPointerException)) {
                                        Log.w("CXCP", "Failed to execute call: Unexpected exception: " + e.getMessage());
                                        c10 = 0;
                                        a2Var.a(str4, false, 9);
                                    } else {
                                        if (!(e instanceof IllegalStateException)) {
                                            throw e;
                                        }
                                        Log.d("CXCP", "Failed to execute call: Camera may be closed");
                                    }
                                    b0Var = null;
                                    i11 = z5;
                                }
                                c10 = 0;
                                b0Var = null;
                                i11 = z5;
                            }
                        } catch (Exception e10) {
                            e = e10;
                            str3 = strU;
                            z5 = true;
                        } catch (Throwable th2) {
                            th = th2;
                            str2 = strU;
                            nVar = 1;
                            str = str2;
                            i10 = nVar;
                            long jI = f.i(jElapsedRealtimeNanos);
                            StringBuilder sbU = f.u(str, " - ");
                            Object[] objArr = new Object[i10];
                            objArr[0] = Double.valueOf(jI / 1000000.0d);
                            Log.d("CXCP", f.s(objArr, i10, null, "%.3f ms", sbU));
                            throw th;
                        }
                    } catch (Exception e11) {
                        e = e11;
                        z5 = true;
                        str3 = strU;
                    } catch (Throwable th3) {
                        th = th3;
                        nVar = 1;
                        str2 = strU;
                    }
                } catch (Exception e12) {
                    e = e12;
                    str3 = strU;
                    x4Var = x4Var2;
                    z5 = true;
                } catch (Throwable th4) {
                    th = th4;
                    str2 = strU;
                    nVar = 1;
                }
                long jI2 = f.i(jElapsedRealtimeNanos);
                StringBuilder sbU2 = f.u(str3, " - ");
                Object[] objArr2 = new Object[i11];
                objArr2[c10] = Double.valueOf(jI2 / 1000000.0d);
                Log.d("CXCP", f.s(objArr2, i11, null, "%.3f ms", sbU2));
                if (b0Var == null) {
                    Log.w("CXCP", "Failed to create capture session from " + cameraDevice + ". Finalizing previous session");
                    if (x4Var != null) {
                        c(x4Var);
                    }
                }
                if (b0Var != null) {
                    return i11;
                }
                return false;
            } catch (Throwable th5) {
                th = th5;
            }
        } catch (Throwable th6) {
            th = th6;
            str = strU;
            i10 = 1;
            long jI3 = f.i(jElapsedRealtimeNanos);
            StringBuilder sbU3 = f.u(str, " - ");
            Object[] objArr3 = new Object[i10];
            objArr3[0] = Double.valueOf(jI3 / 1000000.0d);
            Log.d("CXCP", f.s(objArr3, i10, null, "%.3f ms", sbU3));
            throw th;
        }
    }

    @Override // a0.h2
    public final void K() {
        x4 x4Var;
        if (!this.f107t0.compareAndSet(false, true) || (x4Var = (x4) this.u0.getValue()) == null) {
            return;
        }
        b(x4Var);
    }

    @Override // a0.h2
    public final CaptureRequest.Builder T(int i10) throws Throwable {
        double d2;
        CaptureRequest.Builder builderCreateCaptureRequest;
        StringBuilder sb2 = new StringBuilder("CXCP#createCaptureRequest-");
        String str = this.Y;
        sb2.append(str);
        String string = sb2.toString();
        long jElapsedRealtimeNanos = SystemClock.elapsedRealtimeNanos();
        try {
            Trace.beginSection(string);
            d2 = 1000000.0d;
            try {
                a2 a2Var = this.Z;
                try {
                    builderCreateCaptureRequest = this.X.createCaptureRequest(i10);
                } catch (Exception e3) {
                    if (e3 instanceof CameraAccessException) {
                        Log.w("CXCP", "Failed to execute call: Camera encountered an error: " + e3.getMessage());
                        CameraAccessException cameraAccessException = (CameraAccessException) e3;
                        int reason = cameraAccessException.getReason();
                        int i11 = 3;
                        if (reason != 1) {
                            if (reason == 2) {
                                i11 = 6;
                            } else if (reason == 3) {
                                i11 = 0;
                            } else if (reason == 4) {
                                i11 = 1;
                            } else if (reason != 5) {
                                Log.w("CXCP", "Unexpected CameraAccessException: " + cameraAccessException);
                                i11 = 11;
                            } else {
                                i11 = 2;
                            }
                        }
                        a2Var.a(str, true, i11);
                    } else if ((e3 instanceof IllegalArgumentException) || (e3 instanceof SecurityException) || (e3 instanceof UnsupportedOperationException) || (e3 instanceof NullPointerException)) {
                        Log.w("CXCP", "Failed to execute call: Unexpected exception: " + e3.getMessage());
                        a2Var.a(str, false, 9);
                    } else {
                        if (!(e3 instanceof IllegalStateException)) {
                            throw e3;
                        }
                        Log.d("CXCP", "Failed to execute call: Camera may be closed");
                    }
                    builderCreateCaptureRequest = null;
                }
                Log.d("CXCP", f.s(new Object[]{Double.valueOf(f.i(jElapsedRealtimeNanos) / 1000000.0d)}, 1, null, "%.3f ms", f.u(string, " - ")));
                return builderCreateCaptureRequest;
            } catch (Throwable th2) {
                th = th2;
                Log.d("CXCP", f.s(new Object[]{Double.valueOf(f.i(jElapsedRealtimeNanos) / d2)}, 1, null, "%.3f ms", f.u(string, " - ")));
                throw th;
            }
        } catch (Throwable th3) {
            th = th3;
            d2 = 1000000.0d;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r9v3 */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    @Override // a0.h2
    public final boolean X(List list, f2 stateCallback) throws Throwable {
        String str;
        int i10;
        String str2;
        String str3;
        x4 x4Var;
        boolean z5;
        char c10;
        qi.b0 b0Var;
        int i11;
        c0.n nVar = this.f106s0;
        CameraDevice cameraDevice = this.X;
        kotlin.jvm.internal.q.g(stateCallback, "stateCallback");
        qi.i iVarA = a(stateCallback);
        boolean zBooleanValue = ((Boolean) iVarA.f17355e).booleanValue();
        x4 x4Var2 = (x4) iVarA.X;
        if (!zBooleanValue) {
            return false;
        }
        if (x4Var2 != null) {
            b(x4Var2);
        }
        String str4 = this.Y;
        String strU = w.x0.u("CXCP#createCaptureSession-", str4);
        long jElapsedRealtimeNanos = SystemClock.elapsedRealtimeNanos();
        try {
            try {
                Trace.beginSection(strU);
                a2 a2Var = this.Z;
                try {
                    x4Var = x4Var2;
                    try {
                        a2 a2Var2 = this.Z;
                        m7.c cVar = this.f105r0;
                        try {
                            Handler handlerA = nVar.a();
                            str3 = strU;
                            z5 = true;
                            try {
                                cameraDevice.createCaptureSession(list, new o(this, stateCallback, x4Var, a2Var2, cVar, handlerA), nVar.a());
                                b0Var = qi.b0.f17350a;
                                c10 = 0;
                                i11 = z5;
                            } catch (Exception e3) {
                                e = e3;
                                if (e instanceof CameraAccessException) {
                                    Log.w("CXCP", "Failed to execute call: Camera encountered an error: " + e.getMessage());
                                    CameraAccessException cameraAccessException = (CameraAccessException) e;
                                    int reason = cameraAccessException.getReason();
                                    int i12 = 3;
                                    if (reason != z5) {
                                        if (reason == 2) {
                                            i12 = 6;
                                        } else if (reason == 3) {
                                            i12 = 0;
                                        } else if (reason == 4) {
                                            i12 = z5;
                                        } else if (reason != 5) {
                                            Log.w("CXCP", "Unexpected CameraAccessException: " + cameraAccessException);
                                            i12 = 11;
                                        } else {
                                            i12 = 2;
                                        }
                                    }
                                    a2Var.a(str4, z5, i12);
                                } else {
                                    if ((e instanceof IllegalArgumentException) || (e instanceof SecurityException) || (e instanceof UnsupportedOperationException) || (e instanceof NullPointerException)) {
                                        Log.w("CXCP", "Failed to execute call: Unexpected exception: " + e.getMessage());
                                        c10 = 0;
                                        a2Var.a(str4, false, 9);
                                    } else {
                                        if (!(e instanceof IllegalStateException)) {
                                            throw e;
                                        }
                                        Log.d("CXCP", "Failed to execute call: Camera may be closed");
                                    }
                                    b0Var = null;
                                    i11 = z5;
                                }
                                c10 = 0;
                                b0Var = null;
                                i11 = z5;
                            }
                        } catch (Exception e10) {
                            e = e10;
                            str3 = strU;
                            z5 = true;
                        } catch (Throwable th2) {
                            th = th2;
                            str2 = strU;
                            nVar = 1;
                            str = str2;
                            i10 = nVar;
                            long jI = f.i(jElapsedRealtimeNanos);
                            StringBuilder sbU = f.u(str, " - ");
                            Object[] objArr = new Object[i10];
                            objArr[0] = Double.valueOf(jI / 1000000.0d);
                            Log.d("CXCP", f.s(objArr, i10, null, "%.3f ms", sbU));
                            throw th;
                        }
                    } catch (Exception e11) {
                        e = e11;
                        z5 = true;
                        str3 = strU;
                    } catch (Throwable th3) {
                        th = th3;
                        nVar = 1;
                        str2 = strU;
                    }
                } catch (Exception e12) {
                    e = e12;
                    str3 = strU;
                    x4Var = x4Var2;
                    z5 = true;
                } catch (Throwable th4) {
                    th = th4;
                    str2 = strU;
                    nVar = 1;
                }
                long jI2 = f.i(jElapsedRealtimeNanos);
                StringBuilder sbU2 = f.u(str3, " - ");
                Object[] objArr2 = new Object[i11];
                objArr2[c10] = Double.valueOf(jI2 / 1000000.0d);
                Log.d("CXCP", f.s(objArr2, i11, null, "%.3f ms", sbU2));
                if (b0Var == null) {
                    Log.w("CXCP", "Failed to create capture session from " + cameraDevice + ". Finalizing previous session");
                    if (x4Var != null) {
                        c(x4Var);
                    }
                }
                if (b0Var != null) {
                    return i11;
                }
                return false;
            } catch (Throwable th5) {
                th = th5;
            }
        } catch (Throwable th6) {
            th = th6;
            str = strU;
            i10 = 1;
            long jI3 = f.i(jElapsedRealtimeNanos);
            StringBuilder sbU3 = f.u(str, " - ");
            Object[] objArr3 = new Object[i10];
            objArr3[0] = Double.valueOf(jI3 / 1000000.0d);
            Log.d("CXCP", f.s(objArr3, i10, null, "%.3f ms", sbU3));
            throw th;
        }
    }

    public final qi.i a(x4 x4Var) {
        if (!this.f107t0.getValue()) {
            return new qi.i(Boolean.TRUE, this.u0.getAndSet(x4Var));
        }
        c(x4Var);
        return new qi.i(Boolean.FALSE, null);
    }

    public final void b(x4 x4Var) {
        try {
            Trace.beginSection(this + "#onSessionDisconnected");
            x4Var.c();
        } finally {
            Trace.endSection();
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r9v3 */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    @Override // a0.h2
    public final boolean b0(InputConfiguration inputConfiguration, ArrayList arrayList, f2 stateCallback) throws Throwable {
        String str;
        int i10;
        String str2;
        String str3;
        x4 x4Var;
        boolean z5;
        char c10;
        qi.b0 b0Var;
        int i11;
        c0.n nVar = this.f106s0;
        CameraDevice cameraDevice = this.X;
        kotlin.jvm.internal.q.g(stateCallback, "stateCallback");
        qi.i iVarA = a(stateCallback);
        boolean zBooleanValue = ((Boolean) iVarA.f17355e).booleanValue();
        x4 x4Var2 = (x4) iVarA.X;
        if (!zBooleanValue) {
            return false;
        }
        if (x4Var2 != null) {
            b(x4Var2);
        }
        String str4 = this.Y;
        String strU = w.x0.u("CXCP#createReprocessableCaptureSession-", str4);
        long jElapsedRealtimeNanos = SystemClock.elapsedRealtimeNanos();
        try {
            try {
                Trace.beginSection(strU);
                a2 a2Var = this.Z;
                try {
                    x4Var = x4Var2;
                    try {
                        a2 a2Var2 = this.Z;
                        m7.c cVar = this.f105r0;
                        try {
                            Handler handlerA = nVar.a();
                            str3 = strU;
                            z5 = true;
                            try {
                                cameraDevice.createReprocessableCaptureSession(inputConfiguration, arrayList, new o(this, stateCallback, x4Var, a2Var2, cVar, handlerA), nVar.a());
                                b0Var = qi.b0.f17350a;
                                c10 = 0;
                                i11 = z5;
                            } catch (Exception e3) {
                                e = e3;
                                if (e instanceof CameraAccessException) {
                                    Log.w("CXCP", "Failed to execute call: Camera encountered an error: " + e.getMessage());
                                    CameraAccessException cameraAccessException = (CameraAccessException) e;
                                    int reason = cameraAccessException.getReason();
                                    int i12 = 3;
                                    if (reason != z5) {
                                        if (reason == 2) {
                                            i12 = 6;
                                        } else if (reason == 3) {
                                            i12 = 0;
                                        } else if (reason == 4) {
                                            i12 = z5;
                                        } else if (reason != 5) {
                                            Log.w("CXCP", "Unexpected CameraAccessException: " + cameraAccessException);
                                            i12 = 11;
                                        } else {
                                            i12 = 2;
                                        }
                                    }
                                    a2Var.a(str4, z5, i12);
                                } else {
                                    if ((e instanceof IllegalArgumentException) || (e instanceof SecurityException) || (e instanceof UnsupportedOperationException) || (e instanceof NullPointerException)) {
                                        Log.w("CXCP", "Failed to execute call: Unexpected exception: " + e.getMessage());
                                        c10 = 0;
                                        a2Var.a(str4, false, 9);
                                    } else {
                                        if (!(e instanceof IllegalStateException)) {
                                            throw e;
                                        }
                                        Log.d("CXCP", "Failed to execute call: Camera may be closed");
                                    }
                                    b0Var = null;
                                    i11 = z5;
                                }
                                c10 = 0;
                                b0Var = null;
                                i11 = z5;
                            }
                        } catch (Exception e10) {
                            e = e10;
                            str3 = strU;
                            z5 = true;
                        } catch (Throwable th2) {
                            th = th2;
                            str2 = strU;
                            nVar = 1;
                            str = str2;
                            i10 = nVar;
                            long jI = f.i(jElapsedRealtimeNanos);
                            StringBuilder sbU = f.u(str, " - ");
                            Object[] objArr = new Object[i10];
                            objArr[0] = Double.valueOf(jI / 1000000.0d);
                            Log.d("CXCP", f.s(objArr, i10, null, "%.3f ms", sbU));
                            throw th;
                        }
                    } catch (Exception e11) {
                        e = e11;
                        z5 = true;
                        str3 = strU;
                    } catch (Throwable th3) {
                        th = th3;
                        nVar = 1;
                        str2 = strU;
                    }
                } catch (Exception e12) {
                    e = e12;
                    str3 = strU;
                    x4Var = x4Var2;
                    z5 = true;
                } catch (Throwable th4) {
                    th = th4;
                    str2 = strU;
                    nVar = 1;
                }
                long jI2 = f.i(jElapsedRealtimeNanos);
                StringBuilder sbU2 = f.u(str3, " - ");
                Object[] objArr2 = new Object[i11];
                objArr2[c10] = Double.valueOf(jI2 / 1000000.0d);
                Log.d("CXCP", f.s(objArr2, i11, null, "%.3f ms", sbU2));
                if (b0Var == null) {
                    Log.w("CXCP", "Failed to create reprocess session from " + cameraDevice + ". Finalizing previous session");
                    if (x4Var != null) {
                        c(x4Var);
                    }
                }
                if (b0Var != null) {
                    return i11;
                }
                return false;
            } catch (Throwable th5) {
                th = th5;
            }
        } catch (Throwable th6) {
            th = th6;
            str = strU;
            i10 = 1;
            long jI3 = f.i(jElapsedRealtimeNanos);
            StringBuilder sbU3 = f.u(str, " - ");
            Object[] objArr3 = new Object[i10];
            objArr3[0] = Double.valueOf(jI3 / 1000000.0d);
            Log.d("CXCP", f.s(objArr3, i10, null, "%.3f ms", sbU3));
            throw th;
        }
    }

    public final void c(x4 x4Var) {
        try {
            Trace.beginSection(this + "#onSessionFinalized");
            x4Var.a();
        } finally {
            Trace.endSection();
        }
    }

    /* JADX WARN: Code duplicated, block: B:32:0x00ba A[Catch: all -> 0x00af, TryCatch #4 {all -> 0x00af, blocks: (B:22:0x00a0, B:30:0x00b6, B:32:0x00ba, B:41:0x00e7, B:47:0x0106, B:50:0x010c, B:52:0x0110, B:54:0x0114, B:56:0x0118, B:59:0x011d, B:61:0x0121, B:62:0x0127, B:63:0x0128), top: B:81:0x00a0 }] */
    /* JADX WARN: Code duplicated, block: B:34:0x00dc  */
    /* JADX WARN: Code duplicated, block: B:36:0x00df A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:37:0x00e1  */
    /* JADX WARN: Code duplicated, block: B:39:0x00e4  */
    /* JADX WARN: Code duplicated, block: B:41:0x00e7 A[Catch: all -> 0x00af, TryCatch #4 {all -> 0x00af, blocks: (B:22:0x00a0, B:30:0x00b6, B:32:0x00ba, B:41:0x00e7, B:47:0x0106, B:50:0x010c, B:52:0x0110, B:54:0x0114, B:56:0x0118, B:59:0x011d, B:61:0x0121, B:62:0x0127, B:63:0x0128), top: B:81:0x00a0 }] */
    /* JADX WARN: Code duplicated, block: B:43:0x00fc  */
    /* JADX WARN: Code duplicated, block: B:44:0x00fe  */
    /* JADX WARN: Code duplicated, block: B:45:0x0101  */
    /* JADX WARN: Code duplicated, block: B:46:0x0104  */
    /* JADX WARN: Code duplicated, block: B:50:0x010c A[Catch: all -> 0x00af, TryCatch #4 {all -> 0x00af, blocks: (B:22:0x00a0, B:30:0x00b6, B:32:0x00ba, B:41:0x00e7, B:47:0x0106, B:50:0x010c, B:52:0x0110, B:54:0x0114, B:56:0x0118, B:59:0x011d, B:61:0x0121, B:62:0x0127, B:63:0x0128), top: B:81:0x00a0 }] */
    /* JADX WARN: Code duplicated, block: B:67:0x0165  */
    /* JADX WARN: Code duplicated, block: B:69:0x017d  */
    /* JADX WARN: Code duplicated, block: B:71:0x0182 A[RETURN, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:72:0x0184 A[ORIG_RETURN, RETURN] */
    /* JADX WARN: Instruction removed from duplicated block: B:32:0x00ba, please report this as an issue */
    /* JADX WARN: Instruction removed from duplicated block: B:41:0x00e7, please report this as an issue */
    /* JADX WARN: Instruction removed from duplicated block: B:67:0x0165, please report this as an issue */
    @Override // a0.h2
    public final boolean e0(p3 p3Var, ArrayList arrayList, f2 stateCallback) throws Throwable {
        long j10;
        x4 x4Var;
        char c10;
        qi.b0 b0Var;
        CameraAccessException cameraAccessException;
        int reason;
        int i10;
        boolean z5;
        ArrayList arrayList2 = arrayList;
        c0.n nVar = this.f106s0;
        CameraDevice cameraDevice = this.X;
        kotlin.jvm.internal.q.g(stateCallback, "stateCallback");
        qi.i iVarA = a(stateCallback);
        boolean zBooleanValue = ((Boolean) iVarA.f17355e).booleanValue();
        x4 x4Var2 = (x4) iVarA.X;
        if (!zBooleanValue) {
            return false;
        }
        if (x4Var2 != null) {
            b(x4Var2);
        }
        String str = this.Y;
        String strU = w.x0.u("CXCP#createReprocessableCaptureSessionByConfigurations-", str);
        long jElapsedRealtimeNanos = SystemClock.elapsedRealtimeNanos();
        try {
            Trace.beginSection(strU);
            a2 a2Var = this.Z;
            try {
                InputConfiguration inputConfiguration = new InputConfiguration(p3Var.f270a, p3Var.f271b, p3Var.f272c);
                ArrayList arrayList3 = new ArrayList(ri.o.S(arrayList2, 10));
                int size = arrayList2.size();
                int i11 = 0;
                while (i11 < size) {
                    Object obj = arrayList2.get(i11);
                    i11++;
                    arrayList3.add((OutputConfiguration) ((x) ((r3) obj)).D(kotlin.jvm.internal.e0.a(OutputConfiguration.class)));
                    arrayList2 = arrayList;
                }
                x4Var = x4Var2;
                try {
                    j10 = jElapsedRealtimeNanos;
                    try {
                        try {
                            cameraDevice.createReprocessableCaptureSessionByConfigurations(inputConfiguration, arrayList3, new o(this, stateCallback, x4Var, this.Z, this.f105r0, nVar.a()), nVar.a());
                            b0Var = qi.b0.f17350a;
                            c10 = 0;
                        } catch (Exception e3) {
                            e = e3;
                            if (!(e instanceof CameraAccessException)) {
                                Log.w("CXCP", "Failed to execute call: Camera encountered an error: " + e.getMessage());
                                cameraAccessException = (CameraAccessException) e;
                                reason = cameraAccessException.getReason();
                                i10 = 3;
                                z5 = true;
                                if (reason != 1) {
                                    if (reason != 2) {
                                        i10 = 6;
                                    } else if (reason != 3) {
                                        z5 = true;
                                        i10 = 0;
                                    } else if (reason != 4) {
                                        z5 = true;
                                        i10 = 1;
                                    } else if (reason != 5) {
                                        Log.w("CXCP", "Unexpected CameraAccessException: " + cameraAccessException);
                                        i10 = 11;
                                    } else {
                                        i10 = 2;
                                    }
                                    z5 = true;
                                }
                                a2Var.a(str, z5, i10);
                            } else {
                                if (e instanceof IllegalArgumentException) {
                                }
                                Log.w("CXCP", "Failed to execute call: Unexpected exception: " + e.getMessage());
                                c10 = 0;
                                a2Var.a(str, false, 9);
                                b0Var = null;
                            }
                            c10 = 0;
                            b0Var = null;
                        }
                        long jI = f.i(j10);
                        StringBuilder sbU = f.u(strU, " - ");
                        Object[] objArr = new Object[1];
                        objArr[c10] = Double.valueOf(jI / 1000000.0d);
                        Log.d("CXCP", f.s(objArr, 1, null, "%.3f ms", sbU));
                        if (b0Var == null) {
                            Log.w("CXCP", "Failed to create reprocess session from " + cameraDevice + ". Finalizing previous session");
                            if (x4Var != null) {
                                c(x4Var);
                            }
                        }
                        if (b0Var != null) {
                            return true;
                        }
                        return false;
                    } catch (Throwable th2) {
                        th = th2;
                        Log.d("CXCP", f.s(new Object[]{Double.valueOf(f.i(j10) / 1000000.0d)}, 1, null, "%.3f ms", f.u(strU, " - ")));
                        throw th;
                    }
                } catch (Exception e10) {
                    e = e10;
                    j10 = jElapsedRealtimeNanos;
                    if (!(e instanceof CameraAccessException)) {
                        if (!(e instanceof IllegalArgumentException) || (e instanceof SecurityException) || (e instanceof UnsupportedOperationException) || (e instanceof NullPointerException)) {
                            Log.w("CXCP", "Failed to execute call: Unexpected exception: " + e.getMessage());
                            c10 = 0;
                            a2Var.a(str, false, 9);
                        } else {
                            if (!(e instanceof IllegalStateException)) {
                                throw e;
                            }
                            Log.d("CXCP", "Failed to execute call: Camera may be closed");
                        }
                        b0Var = null;
                        long jI2 = f.i(j10);
                        StringBuilder sbU2 = f.u(strU, " - ");
                        Object[] objArr2 = new Object[1];
                        objArr2[c10] = Double.valueOf(jI2 / 1000000.0d);
                        Log.d("CXCP", f.s(objArr2, 1, null, "%.3f ms", sbU2));
                        if (b0Var == null) {
                            Log.w("CXCP", "Failed to create reprocess session from " + cameraDevice + ". Finalizing previous session");
                            if (x4Var != null) {
                                c(x4Var);
                            }
                        }
                        if (b0Var != null) {
                            return true;
                        }
                        return false;
                    }
                    Log.w("CXCP", "Failed to execute call: Camera encountered an error: " + e.getMessage());
                    cameraAccessException = (CameraAccessException) e;
                    reason = cameraAccessException.getReason();
                    i10 = 3;
                    z5 = true;
                    if (reason != 1) {
                        if (reason != 2) {
                            i10 = 6;
                        } else if (reason != 3) {
                            z5 = true;
                            i10 = 0;
                        } else if (reason != 4) {
                            z5 = true;
                            i10 = 1;
                        } else if (reason != 5) {
                            Log.w("CXCP", "Unexpected CameraAccessException: " + cameraAccessException);
                            i10 = 11;
                        } else {
                            i10 = 2;
                        }
                        z5 = true;
                    }
                    a2Var.a(str, z5, i10);
                    c10 = 0;
                    b0Var = null;
                    long jI3 = f.i(j10);
                    StringBuilder sbU3 = f.u(strU, " - ");
                    Object[] objArr3 = new Object[1];
                    objArr3[c10] = Double.valueOf(jI3 / 1000000.0d);
                    Log.d("CXCP", f.s(objArr3, 1, null, "%.3f ms", sbU3));
                    if (b0Var == null) {
                        Log.w("CXCP", "Failed to create reprocess session from " + cameraDevice + ". Finalizing previous session");
                        if (x4Var != null) {
                            c(x4Var);
                        }
                    }
                    if (b0Var != null) {
                        return true;
                    }
                    return false;
                }
            } catch (Exception e11) {
                e = e11;
                x4Var = x4Var2;
            }
        } catch (Throwable th3) {
            th = th3;
            j10 = jElapsedRealtimeNanos;
        }
    }

    @Override // a0.h2
    public final void i0() {
        if (!this.f107t0.getValue()) {
            throw new IllegalStateException("Check failed.");
        }
        x4 x4Var = (x4) this.u0.getAndSet(null);
        if (x4Var != null) {
            c(x4Var);
        }
    }

    /* JADX WARN: Code duplicated, block: B:32:0x00ae A[Catch: all -> 0x00a1, TryCatch #0 {all -> 0x00a1, blocks: (B:21:0x0091, B:30:0x00aa, B:32:0x00ae, B:41:0x00da, B:47:0x00fa, B:49:0x00ff, B:51:0x0105, B:53:0x0109, B:55:0x010d, B:58:0x0112, B:60:0x0116, B:61:0x011c, B:62:0x011d), top: B:75:0x003f }] */
    /* JADX WARN: Code duplicated, block: B:34:0x00cf  */
    /* JADX WARN: Code duplicated, block: B:36:0x00d2 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:37:0x00d4  */
    /* JADX WARN: Code duplicated, block: B:39:0x00d7  */
    /* JADX WARN: Code duplicated, block: B:41:0x00da A[Catch: all -> 0x00a1, TryCatch #0 {all -> 0x00a1, blocks: (B:21:0x0091, B:30:0x00aa, B:32:0x00ae, B:41:0x00da, B:47:0x00fa, B:49:0x00ff, B:51:0x0105, B:53:0x0109, B:55:0x010d, B:58:0x0112, B:60:0x0116, B:61:0x011c, B:62:0x011d), top: B:75:0x003f }] */
    /* JADX WARN: Code duplicated, block: B:42:0x00ed A[PHI: r5
      0x00ed: PHI (r5v2 int) = (r5v1 int), (r5v4 int), (r5v7 int), (r5v9 int), (r5v10 int) binds: [B:33:0x00cd, B:46:0x00f8, B:44:0x00f2, B:43:0x00f0, B:41:0x00da] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:43:0x00f0  */
    /* JADX WARN: Code duplicated, block: B:44:0x00f2  */
    /* JADX WARN: Code duplicated, block: B:45:0x00f4  */
    /* JADX WARN: Code duplicated, block: B:46:0x00f8  */
    /* JADX WARN: Code duplicated, block: B:49:0x00ff A[Catch: all -> 0x00a1, TryCatch #0 {all -> 0x00a1, blocks: (B:21:0x0091, B:30:0x00aa, B:32:0x00ae, B:41:0x00da, B:47:0x00fa, B:49:0x00ff, B:51:0x0105, B:53:0x0109, B:55:0x010d, B:58:0x0112, B:60:0x0116, B:61:0x011c, B:62:0x011d), top: B:75:0x003f }] */
    /* JADX WARN: Code duplicated, block: B:66:0x0159  */
    /* JADX WARN: Code duplicated, block: B:68:0x0171  */
    /* JADX WARN: Code duplicated, block: B:70:0x0176  */
    /* JADX WARN: Code duplicated, block: B:71:0x0178 A[ORIG_RETURN, RETURN] */
    /* JADX WARN: Instruction removed from duplicated block: B:32:0x00ae, please report this as an issue */
    /* JADX WARN: Instruction removed from duplicated block: B:41:0x00da, please report this as an issue */
    /* JADX WARN: Instruction removed from duplicated block: B:66:0x0159, please report this as an issue */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r9v0, types: [c0.n] */
    /* JADX WARN: Type inference failed for: r9v1 */
    @Override // a0.h2
    public final boolean q0(ArrayList arrayList, f2 stateCallback) throws Throwable {
        a2 a2Var;
        boolean z5;
        char c10;
        qi.b0 b0Var;
        CameraAccessException cameraAccessException;
        int reason;
        int i10;
        int i11;
        int i12;
        boolean z6;
        ArrayList arrayList2 = arrayList;
        int i13 = this.f106s0;
        CameraDevice cameraDevice = this.X;
        kotlin.jvm.internal.q.g(stateCallback, "stateCallback");
        qi.i iVarA = a(stateCallback);
        boolean zBooleanValue = ((Boolean) iVarA.f17355e).booleanValue();
        x4 x4Var = (x4) iVarA.X;
        if (!zBooleanValue) {
            return false;
        }
        if (x4Var != null) {
            b(x4Var);
        }
        String str = this.Y;
        String strU = w.x0.u("CXCP#createCaptureSessionByOutputConfigurations-", str);
        long jElapsedRealtimeNanos = SystemClock.elapsedRealtimeNanos();
        try {
            try {
                Trace.beginSection(strU);
                a2 a2Var2 = this.Z;
                try {
                    ArrayList arrayList3 = new ArrayList(ri.o.S(arrayList2, 10));
                    int size = arrayList2.size();
                    int i14 = 0;
                    while (i14 < size) {
                        Object obj = arrayList2.get(i14);
                        i14++;
                        arrayList3.add((OutputConfiguration) ((x) ((r3) obj)).D(kotlin.jvm.internal.e0.a(OutputConfiguration.class)));
                        arrayList2 = arrayList;
                    }
                    a2 a2Var3 = this.Z;
                    m7.c cVar = this.f105r0;
                    try {
                        Handler handlerA = i13.a();
                        a2Var = a2Var2;
                        z5 = true;
                        z6 = true;
                        try {
                            cameraDevice.createCaptureSessionByOutputConfigurations(arrayList3, new o(this, stateCallback, x4Var, a2Var3, cVar, handlerA), i13.a());
                            b0Var = qi.b0.f17350a;
                        } catch (Exception e3) {
                            e = e3;
                            if (e instanceof CameraAccessException) {
                                a2 a2Var4 = a2Var;
                                if (e instanceof IllegalArgumentException) {
                                }
                                Log.w("CXCP", "Failed to execute call: Unexpected exception: " + e.getMessage());
                                c10 = 0;
                                a2Var4.a(str, false, 9);
                                b0Var = null;
                                i12 = z5;
                                long jI = f.i(jElapsedRealtimeNanos);
                                StringBuilder sbU = f.u(strU, " - ");
                                Object[] objArr = new Object[i12];
                                objArr[c10] = Double.valueOf(jI / 1000000.0d);
                                Log.d("CXCP", f.s(objArr, i12, null, "%.3f ms", sbU));
                                if (b0Var == null) {
                                    Log.w("CXCP", "Failed to create capture session from " + cameraDevice + ". Finalizing previous session");
                                    if (x4Var != null) {
                                        c(x4Var);
                                    }
                                }
                                if (b0Var != null) {
                                    return i12;
                                }
                                return false;
                            }
                            Log.w("CXCP", "Failed to execute call: Camera encountered an error: " + e.getMessage());
                            cameraAccessException = (CameraAccessException) e;
                            reason = cameraAccessException.getReason();
                            i10 = 3;
                            if (reason == z5) {
                                i11 = i10;
                            } else {
                                if (reason != 2) {
                                    i10 = 6;
                                } else if (reason != 3) {
                                    i11 = 0;
                                } else if (reason != 4) {
                                    i10 = z5;
                                } else if (reason != 5) {
                                    Log.w("CXCP", "Unexpected CameraAccessException: " + cameraAccessException);
                                    i10 = 11;
                                } else {
                                    i10 = 2;
                                }
                                i11 = i10;
                            }
                            a2Var.a(str, z5, i11);
                            b0Var = null;
                            z6 = z5;
                        }
                    } catch (Exception e10) {
                        e = e10;
                        a2Var = a2Var2;
                        z5 = true;
                        if (e instanceof CameraAccessException) {
                            a2 a2Var5 = a2Var;
                            if (!(e instanceof IllegalArgumentException) || (e instanceof SecurityException) || (e instanceof UnsupportedOperationException) || (e instanceof NullPointerException)) {
                                Log.w("CXCP", "Failed to execute call: Unexpected exception: " + e.getMessage());
                                c10 = 0;
                                a2Var5.a(str, false, 9);
                                b0Var = null;
                                i12 = z5;
                            } else {
                                if (!(e instanceof IllegalStateException)) {
                                    throw e;
                                }
                                Log.d("CXCP", "Failed to execute call: Camera may be closed");
                            }
                            long jI2 = f.i(jElapsedRealtimeNanos);
                            StringBuilder sbU2 = f.u(strU, " - ");
                            Object[] objArr2 = new Object[i12];
                            objArr2[c10] = Double.valueOf(jI2 / 1000000.0d);
                            Log.d("CXCP", f.s(objArr2, i12, null, "%.3f ms", sbU2));
                            if (b0Var == null) {
                                Log.w("CXCP", "Failed to create capture session from " + cameraDevice + ". Finalizing previous session");
                                if (x4Var != null) {
                                    c(x4Var);
                                }
                            }
                            if (b0Var != null) {
                                return i12;
                            }
                            return false;
                        }
                        Log.w("CXCP", "Failed to execute call: Camera encountered an error: " + e.getMessage());
                        cameraAccessException = (CameraAccessException) e;
                        reason = cameraAccessException.getReason();
                        i10 = 3;
                        if (reason == z5) {
                            i11 = i10;
                        } else {
                            if (reason != 2) {
                                i10 = 6;
                            } else if (reason != 3) {
                                i11 = 0;
                            } else if (reason != 4) {
                                i10 = z5;
                            } else if (reason != 5) {
                                Log.w("CXCP", "Unexpected CameraAccessException: " + cameraAccessException);
                                i10 = 11;
                            } else {
                                i10 = 2;
                            }
                            i11 = i10;
                        }
                        a2Var.a(str, z5, i11);
                        b0Var = null;
                        z6 = z5;
                        c10 = 0;
                        i12 = z6;
                        long jI3 = f.i(jElapsedRealtimeNanos);
                        StringBuilder sbU3 = f.u(strU, " - ");
                        Object[] objArr3 = new Object[i12];
                        objArr3[c10] = Double.valueOf(jI3 / 1000000.0d);
                        Log.d("CXCP", f.s(objArr3, i12, null, "%.3f ms", sbU3));
                        if (b0Var == null) {
                            Log.w("CXCP", "Failed to create capture session from " + cameraDevice + ". Finalizing previous session");
                            if (x4Var != null) {
                                c(x4Var);
                            }
                        }
                        if (b0Var != null) {
                            return i12;
                        }
                        return false;
                    }
                } catch (Exception e11) {
                    e = e11;
                    a2Var = a2Var2;
                }
                c10 = 0;
                i12 = z6;
                long jI4 = f.i(jElapsedRealtimeNanos);
                StringBuilder sbU4 = f.u(strU, " - ");
                Object[] objArr4 = new Object[i12];
                objArr4[c10] = Double.valueOf(jI4 / 1000000.0d);
                Log.d("CXCP", f.s(objArr4, i12, null, "%.3f ms", sbU4));
                if (b0Var == null) {
                    Log.w("CXCP", "Failed to create capture session from " + cameraDevice + ". Finalizing previous session");
                    if (x4Var != null) {
                        c(x4Var);
                    }
                }
                if (b0Var != null) {
                    return i12;
                }
                return false;
            } catch (Throwable th2) {
                th = th2;
                long jI5 = f.i(jElapsedRealtimeNanos);
                StringBuilder sbU5 = f.u(strU, " - ");
                Object[] objArr5 = new Object[i13];
                objArr5[0] = Double.valueOf(jI5 / 1000000.0d);
                Log.d("CXCP", f.s(objArr5, i13, null, "%.3f ms", sbU5));
                throw th;
            }
        } catch (Throwable th3) {
            th = th3;
            i13 = 1;
            long jI6 = f.i(jElapsedRealtimeNanos);
            StringBuilder sbU6 = f.u(strU, " - ");
            Object[] objArr6 = new Object[i13];
            objArr6[0] = Double.valueOf(jI6 / 1000000.0d);
            Log.d("CXCP", f.s(objArr6, i13, null, "%.3f ms", sbU6));
            throw th;
        }
    }

    /* JADX WARN: Code duplicated, block: B:107:0x025a  */
    /* JADX WARN: Code duplicated, block: B:109:0x0272  */
    /* JADX WARN: Code duplicated, block: B:111:0x0277 A[RETURN, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:112:0x0279 A[ORIG_RETURN, RETURN] */
    /* JADX WARN: Code duplicated, block: B:71:0x01a4 A[Catch: all -> 0x00c6, TryCatch #5 {all -> 0x00c6, blocks: (B:27:0x00aa, B:29:0x00b8, B:31:0x00be, B:36:0x00cf, B:39:0x00fa, B:40:0x011d, B:42:0x0123, B:43:0x0131, B:44:0x013b, B:46:0x0141, B:48:0x0153, B:50:0x0160, B:51:0x0164, B:53:0x0178, B:56:0x0182, B:57:0x0185, B:59:0x0187, B:60:0x018a, B:69:0x01a0, B:71:0x01a4, B:80:0x01d1, B:88:0x01f6, B:90:0x01fb, B:92:0x0201, B:94:0x0205, B:96:0x0209, B:99:0x020e, B:101:0x0212, B:102:0x0218, B:103:0x0219), top: B:125:0x003b }] */
    /* JADX WARN: Code duplicated, block: B:73:0x01c6  */
    /* JADX WARN: Code duplicated, block: B:75:0x01c9 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:76:0x01cb  */
    /* JADX WARN: Code duplicated, block: B:78:0x01ce  */
    /* JADX WARN: Code duplicated, block: B:80:0x01d1 A[Catch: all -> 0x00c6, TryCatch #5 {all -> 0x00c6, blocks: (B:27:0x00aa, B:29:0x00b8, B:31:0x00be, B:36:0x00cf, B:39:0x00fa, B:40:0x011d, B:42:0x0123, B:43:0x0131, B:44:0x013b, B:46:0x0141, B:48:0x0153, B:50:0x0160, B:51:0x0164, B:53:0x0178, B:56:0x0182, B:57:0x0185, B:59:0x0187, B:60:0x018a, B:69:0x01a0, B:71:0x01a4, B:80:0x01d1, B:88:0x01f6, B:90:0x01fb, B:92:0x0201, B:94:0x0205, B:96:0x0209, B:99:0x020e, B:101:0x0212, B:102:0x0218, B:103:0x0219), top: B:125:0x003b }] */
    /* JADX WARN: Code duplicated, block: B:83:0x01e8  */
    /* JADX WARN: Code duplicated, block: B:84:0x01ea  */
    /* JADX WARN: Code duplicated, block: B:85:0x01ee  */
    /* JADX WARN: Code duplicated, block: B:86:0x01f2  */
    /* JADX WARN: Code duplicated, block: B:87:0x01f4  */
    /* JADX WARN: Code duplicated, block: B:90:0x01fb A[Catch: all -> 0x00c6, TryCatch #5 {all -> 0x00c6, blocks: (B:27:0x00aa, B:29:0x00b8, B:31:0x00be, B:36:0x00cf, B:39:0x00fa, B:40:0x011d, B:42:0x0123, B:43:0x0131, B:44:0x013b, B:46:0x0141, B:48:0x0153, B:50:0x0160, B:51:0x0164, B:53:0x0178, B:56:0x0182, B:57:0x0185, B:59:0x0187, B:60:0x018a, B:69:0x01a0, B:71:0x01a4, B:80:0x01d1, B:88:0x01f6, B:90:0x01fb, B:92:0x0201, B:94:0x0205, B:96:0x0209, B:99:0x020e, B:101:0x0212, B:102:0x0218, B:103:0x0219), top: B:125:0x003b }] */
    /* JADX WARN: Instruction removed from duplicated block: B:107:0x025a, please report this as an issue */
    /* JADX WARN: Instruction removed from duplicated block: B:71:0x01a4, please report this as an issue */
    /* JADX WARN: Instruction removed from duplicated block: B:80:0x01d1, please report this as an issue */
    /* JADX WARN: Type inference failed for: r4v29, types: [java.lang.Object, qi.f] */
    @Override // a0.h2
    public final boolean t(t4 t4Var) throws Throwable {
        String str;
        String str2;
        String str3;
        a2 a2Var;
        String str4;
        char c10;
        qi.b0 b0Var;
        CameraAccessException cameraAccessException;
        int reason;
        int i10;
        boolean z5;
        CameraDevice cameraDevice = this.X;
        List list = t4Var.f331b;
        qi.i iVarA = a(t4Var.f334e);
        boolean zBooleanValue = ((Boolean) iVarA.f17355e).booleanValue();
        x4 x4Var = (x4) iVarA.X;
        if (!zBooleanValue) {
            return false;
        }
        if (x4Var != null) {
            b(x4Var);
        }
        String str5 = this.Y;
        String strU = w.x0.u("CXCP#createCaptureSession-", str5);
        long jElapsedRealtimeNanos = SystemClock.elapsedRealtimeNanos();
        try {
            try {
                Trace.beginSection(strU);
                a2 a2Var2 = this.Z;
                try {
                    int i11 = t4Var.f330a;
                    ArrayList arrayList = t4Var.f332c;
                    str3 = "%.3f ms";
                    try {
                        try {
                            ArrayList arrayList2 = new ArrayList(ri.o.S(arrayList, 10));
                            int size = arrayList.size();
                            int i12 = 0;
                            while (i12 < size) {
                                try {
                                    Object obj = arrayList.get(i12);
                                    i12++;
                                    int i13 = i11;
                                    arrayList2.add(e.e(((x) ((r3) obj)).D(kotlin.jvm.internal.e0.a(e.h()))));
                                    i11 = i13;
                                } catch (Throwable th2) {
                                    th = th2;
                                    str2 = " - ";
                                    str = str3;
                                    Log.d("CXCP", f.s(new Object[]{Double.valueOf(f.i(jElapsedRealtimeNanos) / 1000000.0d)}, 1, null, str, f.u(strU, str2)));
                                    throw th;
                                }
                            }
                            int i14 = i11;
                            Executor executor = t4Var.f333d;
                            try {
                                a2Var = a2Var2;
                                str4 = " - ";
                                try {
                                    o oVar = new o(this, t4Var.f334e, x4Var, this.Z, this.f105r0, this.f106s0.a());
                                    kotlin.jvm.internal.q.g(executor, "executor");
                                    SessionConfiguration sessionConfigurationA = b0.a(i14, arrayList2, executor, oVar);
                                    if (list != null) {
                                        if (Build.VERSION.SDK_INT >= 31) {
                                            c0.i(sessionConfigurationA, g0.c(str5, list));
                                        } else {
                                            c0.i(sessionConfigurationA, new InputConfiguration(((p3) ri.m.t0(list)).f270a, ((p3) ri.m.t0(list)).f271b, ((p3) ri.m.t0(list)).f272c));
                                        }
                                    }
                                    try {
                                        Trace.beginSection("createCaptureRequest");
                                        CaptureRequest.Builder builderCreateCaptureRequest = cameraDevice.createCaptureRequest(t4Var.f);
                                        Trace.endSection();
                                        kotlin.jvm.internal.q.f(builderCreateCaptureRequest, "trace(...)");
                                        Set set = (Set) ((h1) this.f104e).f100v0.getValue();
                                        ArrayList arrayList3 = new ArrayList(ri.o.S(set, 10));
                                        Iterator it = set.iterator();
                                        while (it.hasNext()) {
                                            arrayList3.add(((CaptureRequest.Key) it.next()).getName());
                                        }
                                        for (Map.Entry entry : t4Var.f335g.entrySet()) {
                                            Object key = entry.getKey();
                                            Object value = entry.getValue();
                                            if ((key instanceof CaptureRequest.Key) && arrayList3.contains(((CaptureRequest.Key) key).getName())) {
                                                com.bumptech.glide.d.N(builderCreateCaptureRequest, key, value);
                                            }
                                        }
                                        CaptureRequest captureRequestBuild = builderCreateCaptureRequest.build();
                                        kotlin.jvm.internal.q.f(captureRequestBuild, "build(...)");
                                        c0.k(sessionConfigurationA, captureRequestBuild);
                                        try {
                                            Trace.beginSection("Api28Compat.createCaptureSession");
                                            c0.a(cameraDevice, sessionConfigurationA);
                                            Trace.endSection();
                                            b0Var = qi.b0.f17350a;
                                        } catch (Throwable th3) {
                                            Trace.endSection();
                                            throw th3;
                                        }
                                    } catch (Throwable th4) {
                                        Trace.endSection();
                                        throw th4;
                                    }
                                } catch (Exception e3) {
                                    e = e3;
                                    if (e instanceof CameraAccessException) {
                                        a2 a2Var3 = a2Var;
                                        if (e instanceof IllegalArgumentException) {
                                        }
                                        Log.w("CXCP", "Failed to execute call: Unexpected exception: " + e.getMessage());
                                        c10 = 0;
                                        a2Var3.a(str5, false, 9);
                                        b0Var = null;
                                        long jI = f.i(jElapsedRealtimeNanos);
                                        StringBuilder sbU = f.u(strU, str4);
                                        Object[] objArr = new Object[1];
                                        objArr[c10] = Double.valueOf(jI / 1000000.0d);
                                        Log.d("CXCP", f.s(objArr, 1, null, str3, sbU));
                                        if (b0Var == null) {
                                            Log.w("CXCP", "Failed to create capture session from " + cameraDevice + ". Finalizing previous session");
                                            if (x4Var != null) {
                                                c(x4Var);
                                            }
                                        }
                                        if (b0Var != null) {
                                            return true;
                                        }
                                        return false;
                                    }
                                    Log.w("CXCP", "Failed to execute call: Camera encountered an error: " + e.getMessage());
                                    cameraAccessException = (CameraAccessException) e;
                                    reason = cameraAccessException.getReason();
                                    i10 = 3;
                                    z5 = true;
                                    if (reason != 1) {
                                        if (reason != 2) {
                                            if (reason != 3) {
                                                i10 = 0;
                                            } else if (reason != 4) {
                                                i10 = 1;
                                            } else if (reason != 5) {
                                                Log.w("CXCP", "Unexpected CameraAccessException: " + cameraAccessException);
                                                i10 = 11;
                                            } else {
                                                i10 = 2;
                                            }
                                            z5 = true;
                                        } else {
                                            i10 = 6;
                                        }
                                        z5 = true;
                                    } else {
                                        a2Var = a2Var;
                                    }
                                    a2Var.a(str5, z5, i10);
                                    b0Var = null;
                                }
                            } catch (Exception e10) {
                                e = e10;
                                a2Var = a2Var2;
                                str4 = " - ";
                                if (e instanceof CameraAccessException) {
                                    a2 a2Var4 = a2Var;
                                    if (!(e instanceof IllegalArgumentException) || (e instanceof SecurityException) || (e instanceof UnsupportedOperationException) || (e instanceof NullPointerException)) {
                                        Log.w("CXCP", "Failed to execute call: Unexpected exception: " + e.getMessage());
                                        c10 = 0;
                                        a2Var4.a(str5, false, 9);
                                        b0Var = null;
                                    } else {
                                        if (!(e instanceof IllegalStateException)) {
                                            throw e;
                                        }
                                        Log.d("CXCP", "Failed to execute call: Camera may be closed");
                                    }
                                    long jI2 = f.i(jElapsedRealtimeNanos);
                                    StringBuilder sbU2 = f.u(strU, str4);
                                    Object[] objArr2 = new Object[1];
                                    objArr2[c10] = Double.valueOf(jI2 / 1000000.0d);
                                    Log.d("CXCP", f.s(objArr2, 1, null, str3, sbU2));
                                    if (b0Var == null) {
                                        Log.w("CXCP", "Failed to create capture session from " + cameraDevice + ". Finalizing previous session");
                                        if (x4Var != null) {
                                            c(x4Var);
                                        }
                                    }
                                    if (b0Var != null) {
                                        return true;
                                    }
                                    return false;
                                }
                                Log.w("CXCP", "Failed to execute call: Camera encountered an error: " + e.getMessage());
                                cameraAccessException = (CameraAccessException) e;
                                reason = cameraAccessException.getReason();
                                i10 = 3;
                                z5 = true;
                                if (reason != 1) {
                                    if (reason != 2) {
                                        if (reason != 3) {
                                            i10 = 0;
                                        } else if (reason != 4) {
                                            i10 = 1;
                                        } else if (reason != 5) {
                                            Log.w("CXCP", "Unexpected CameraAccessException: " + cameraAccessException);
                                            i10 = 11;
                                        } else {
                                            i10 = 2;
                                        }
                                        z5 = true;
                                    } else {
                                        i10 = 6;
                                    }
                                    z5 = true;
                                } else {
                                    a2Var = a2Var;
                                }
                                a2Var.a(str5, z5, i10);
                                b0Var = null;
                                c10 = 0;
                                long jI3 = f.i(jElapsedRealtimeNanos);
                                StringBuilder sbU3 = f.u(strU, str4);
                                Object[] objArr3 = new Object[1];
                                objArr3[c10] = Double.valueOf(jI3 / 1000000.0d);
                                Log.d("CXCP", f.s(objArr3, 1, null, str3, sbU3));
                                if (b0Var == null) {
                                    Log.w("CXCP", "Failed to create capture session from " + cameraDevice + ". Finalizing previous session");
                                    if (x4Var != null) {
                                        c(x4Var);
                                    }
                                }
                                if (b0Var != null) {
                                    return true;
                                }
                                return false;
                            }
                        } catch (Throwable th5) {
                            th = th5;
                            str = str3;
                            str2 = " - ";
                            Log.d("CXCP", f.s(new Object[]{Double.valueOf(f.i(jElapsedRealtimeNanos) / 1000000.0d)}, 1, null, str, f.u(strU, str2)));
                            throw th;
                        }
                    } catch (Exception e11) {
                        e = e11;
                        a2Var = a2Var2;
                    }
                } catch (Exception e12) {
                    e = e12;
                    a2Var = a2Var2;
                    str3 = "%.3f ms";
                } catch (Throwable th6) {
                    th = th6;
                    str3 = "%.3f ms";
                }
                c10 = 0;
                long jI4 = f.i(jElapsedRealtimeNanos);
                StringBuilder sbU4 = f.u(strU, str4);
                Object[] objArr4 = new Object[1];
                objArr4[c10] = Double.valueOf(jI4 / 1000000.0d);
                Log.d("CXCP", f.s(objArr4, 1, null, str3, sbU4));
                if (b0Var == null) {
                    Log.w("CXCP", "Failed to create capture session from " + cameraDevice + ". Finalizing previous session");
                    if (x4Var != null) {
                        c(x4Var);
                    }
                }
                if (b0Var != null) {
                    return true;
                }
                return false;
            } catch (Throwable th7) {
                th = th7;
            }
        } catch (Throwable th8) {
            th = th8;
            str = "%.3f ms";
            str2 = " - ";
        }
    }

    public final String toString() {
        return "AndroidCameraDevice(camera=" + ((Object) z.p.b(this.Y)) + ')';
    }

    /* JADX WARN: Code duplicated, block: B:47:0x00ec A[Catch: all -> 0x00c6, TryCatch #3 {all -> 0x00c6, blocks: (B:24:0x009c, B:26:0x00a8, B:28:0x00ae, B:30:0x00c2, B:35:0x00cc, B:36:0x00d3, B:37:0x00d4, B:45:0x00e8, B:47:0x00ec, B:56:0x0119, B:62:0x0138, B:65:0x013e, B:67:0x0142, B:69:0x0146, B:71:0x014a, B:74:0x014f, B:76:0x0153, B:77:0x0159, B:78:0x015a), top: B:96:0x003c }] */
    /* JADX WARN: Code duplicated, block: B:49:0x010e  */
    /* JADX WARN: Code duplicated, block: B:51:0x0111 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:52:0x0113  */
    /* JADX WARN: Code duplicated, block: B:54:0x0116  */
    /* JADX WARN: Code duplicated, block: B:56:0x0119 A[Catch: all -> 0x00c6, TryCatch #3 {all -> 0x00c6, blocks: (B:24:0x009c, B:26:0x00a8, B:28:0x00ae, B:30:0x00c2, B:35:0x00cc, B:36:0x00d3, B:37:0x00d4, B:45:0x00e8, B:47:0x00ec, B:56:0x0119, B:62:0x0138, B:65:0x013e, B:67:0x0142, B:69:0x0146, B:71:0x014a, B:74:0x014f, B:76:0x0153, B:77:0x0159, B:78:0x015a), top: B:96:0x003c }] */
    /* JADX WARN: Code duplicated, block: B:58:0x012e  */
    /* JADX WARN: Code duplicated, block: B:59:0x0130  */
    /* JADX WARN: Code duplicated, block: B:60:0x0133  */
    /* JADX WARN: Code duplicated, block: B:61:0x0136  */
    /* JADX WARN: Code duplicated, block: B:65:0x013e A[Catch: all -> 0x00c6, TryCatch #3 {all -> 0x00c6, blocks: (B:24:0x009c, B:26:0x00a8, B:28:0x00ae, B:30:0x00c2, B:35:0x00cc, B:36:0x00d3, B:37:0x00d4, B:45:0x00e8, B:47:0x00ec, B:56:0x0119, B:62:0x0138, B:65:0x013e, B:67:0x0142, B:69:0x0146, B:71:0x014a, B:74:0x014f, B:76:0x0153, B:77:0x0159, B:78:0x015a), top: B:96:0x003c }] */
    /* JADX WARN: Code duplicated, block: B:82:0x0199  */
    /* JADX WARN: Code duplicated, block: B:84:0x01b1  */
    /* JADX WARN: Code duplicated, block: B:86:0x01b6 A[RETURN, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:87:0x01b8 A[ORIG_RETURN, RETURN] */
    /* JADX WARN: Instruction removed from duplicated block: B:47:0x00ec, please report this as an issue */
    /* JADX WARN: Instruction removed from duplicated block: B:56:0x0119, please report this as an issue */
    /* JADX WARN: Instruction removed from duplicated block: B:82:0x0199, please report this as an issue */
    @Override // a0.h2
    public final boolean v(n3 n3Var) throws Throwable {
        String str;
        long j10;
        String str2;
        char c10;
        qi.b0 b0Var;
        CameraAccessException cameraAccessException;
        int reason;
        int i10;
        boolean z5;
        c0.e eVar = n3Var.f228b;
        CameraDevice cameraDevice = this.X;
        Integer num = n3Var.f;
        o3 o3Var = n3Var.f232g;
        qi.i iVarA = a(o3Var);
        boolean zBooleanValue = ((Boolean) iVarA.f17355e).booleanValue();
        x4 x4Var = (x4) iVarA.X;
        if (!zBooleanValue) {
            return false;
        }
        if (x4Var != null) {
            b(x4Var);
        }
        String str3 = this.Y;
        String strU = w.x0.u("CXCP#createExtensionSession-", str3);
        long jElapsedRealtimeNanos = SystemClock.elapsedRealtimeNanos();
        try {
            try {
                Trace.beginSection(strU);
                a2 a2Var = this.Z;
                try {
                    int iIntValue = num.intValue();
                    ArrayList arrayList = n3Var.f227a;
                    j10 = jElapsedRealtimeNanos;
                    try {
                        try {
                            ArrayList arrayList2 = new ArrayList(ri.o.S(arrayList, 10));
                            int size = arrayList.size();
                            int i11 = 0;
                            while (i11 < size) {
                                try {
                                    Object obj = arrayList.get(i11);
                                    int i12 = i11 + 1;
                                    o3 o3Var2 = o3Var;
                                    arrayList2.add(e.e(((x) ((r3) obj)).D(kotlin.jvm.internal.e0.a(e.h()))));
                                    o3Var = o3Var2;
                                    i11 = i12;
                                } catch (Throwable th2) {
                                    th = th2;
                                    str = "%.3f ms";
                                    Log.d("CXCP", f.s(new Object[]{Double.valueOf(f.i(j10) / 1000000.0d)}, 1, null, str, f.u(strU, " - ")));
                                    throw th;
                                }
                            }
                            str2 = "%.3f ms";
                            try {
                                ExtensionSessionConfiguration extensionSessionConfiguration = new ExtensionSessionConfiguration(iIntValue, arrayList2, eVar, new r(this, o3Var, x4Var, this.Z, this.f105r0, eVar));
                                r3 r3Var = n3Var.h;
                                if (r3Var != null && Build.VERSION.SDK_INT >= 34) {
                                    OutputConfiguration outputConfigurationE = e.e(((x) r3Var).D(kotlin.jvm.internal.e0.a(e.h())));
                                    if (outputConfigurationE == null) {
                                        throw new IllegalStateException("Failed to unwrap Postview OutputConfiguration");
                                    }
                                    i0.d(extensionSessionConfiguration, outputConfigurationE);
                                }
                                cameraDevice.createExtensionSession(extensionSessionConfiguration);
                                b0Var = qi.b0.f17350a;
                                c10 = 0;
                            } catch (Exception e3) {
                                e = e3;
                                if (!(e instanceof CameraAccessException)) {
                                    Log.w("CXCP", "Failed to execute call: Camera encountered an error: " + e.getMessage());
                                    cameraAccessException = (CameraAccessException) e;
                                    reason = cameraAccessException.getReason();
                                    i10 = 3;
                                    z5 = true;
                                    if (reason != 1) {
                                        if (reason != 2) {
                                            i10 = 6;
                                        } else if (reason != 3) {
                                            z5 = true;
                                            i10 = 0;
                                        } else if (reason != 4) {
                                            z5 = true;
                                            i10 = 1;
                                        } else if (reason != 5) {
                                            Log.w("CXCP", "Unexpected CameraAccessException: " + cameraAccessException);
                                            i10 = 11;
                                        } else {
                                            i10 = 2;
                                        }
                                        z5 = true;
                                    }
                                    a2Var.a(str3, z5, i10);
                                } else {
                                    if (!(e instanceof IllegalArgumentException) || (e instanceof SecurityException) || (e instanceof UnsupportedOperationException) || (e instanceof NullPointerException)) {
                                        Log.w("CXCP", "Failed to execute call: Unexpected exception: " + e.getMessage());
                                        c10 = 0;
                                        a2Var.a(str3, false, 9);
                                    } else {
                                        if (!(e instanceof IllegalStateException)) {
                                            throw e;
                                        }
                                        Log.d("CXCP", "Failed to execute call: Camera may be closed");
                                    }
                                    b0Var = null;
                                }
                                c10 = 0;
                                b0Var = null;
                            }
                        } catch (Exception e10) {
                            e = e10;
                            str2 = "%.3f ms";
                            if (!(e instanceof CameraAccessException)) {
                                if (e instanceof IllegalArgumentException) {
                                }
                                Log.w("CXCP", "Failed to execute call: Unexpected exception: " + e.getMessage());
                                c10 = 0;
                                a2Var.a(str3, false, 9);
                                b0Var = null;
                                long jI = f.i(j10);
                                StringBuilder sbU = f.u(strU, " - ");
                                Object[] objArr = new Object[1];
                                objArr[c10] = Double.valueOf(jI / 1000000.0d);
                                Log.d("CXCP", f.s(objArr, 1, null, str2, sbU));
                                if (b0Var == null) {
                                    Log.w("CXCP", "Failed to create extension session from " + cameraDevice + ". Finalizing previous session");
                                    if (x4Var != null) {
                                        c(x4Var);
                                    }
                                }
                                if (b0Var != null) {
                                    return true;
                                }
                                return false;
                            }
                            Log.w("CXCP", "Failed to execute call: Camera encountered an error: " + e.getMessage());
                            cameraAccessException = (CameraAccessException) e;
                            reason = cameraAccessException.getReason();
                            i10 = 3;
                            z5 = true;
                            if (reason != 1) {
                                if (reason != 2) {
                                    i10 = 6;
                                } else if (reason != 3) {
                                    z5 = true;
                                    i10 = 0;
                                } else if (reason != 4) {
                                    z5 = true;
                                    i10 = 1;
                                } else if (reason != 5) {
                                    Log.w("CXCP", "Unexpected CameraAccessException: " + cameraAccessException);
                                    i10 = 11;
                                } else {
                                    i10 = 2;
                                }
                                z5 = true;
                            }
                            a2Var.a(str3, z5, i10);
                            c10 = 0;
                            b0Var = null;
                            long jI2 = f.i(j10);
                            StringBuilder sbU2 = f.u(strU, " - ");
                            Object[] objArr2 = new Object[1];
                            objArr2[c10] = Double.valueOf(jI2 / 1000000.0d);
                            Log.d("CXCP", f.s(objArr2, 1, null, str2, sbU2));
                            if (b0Var == null) {
                                Log.w("CXCP", "Failed to create extension session from " + cameraDevice + ". Finalizing previous session");
                                if (x4Var != null) {
                                    c(x4Var);
                                }
                            }
                            if (b0Var != null) {
                                return true;
                            }
                            return false;
                        }
                    } catch (Throwable th3) {
                        th = th3;
                        str = "%.3f ms";
                        Log.d("CXCP", f.s(new Object[]{Double.valueOf(f.i(j10) / 1000000.0d)}, 1, null, str, f.u(strU, " - ")));
                        throw th;
                    }
                } catch (Exception e11) {
                    e = e11;
                    j10 = jElapsedRealtimeNanos;
                } catch (Throwable th4) {
                    th = th4;
                    j10 = jElapsedRealtimeNanos;
                }
                long jI3 = f.i(j10);
                StringBuilder sbU3 = f.u(strU, " - ");
                Object[] objArr3 = new Object[1];
                objArr3[c10] = Double.valueOf(jI3 / 1000000.0d);
                Log.d("CXCP", f.s(objArr3, 1, null, str2, sbU3));
                if (b0Var == null) {
                    Log.w("CXCP", "Failed to create extension session from " + cameraDevice + ". Finalizing previous session");
                    if (x4Var != null) {
                        c(x4Var);
                    }
                }
                if (b0Var != null) {
                    return true;
                }
                return false;
            } catch (Throwable th5) {
                th = th5;
            }
        } catch (Throwable th6) {
            th = th6;
            str = "%.3f ms";
            j10 = jElapsedRealtimeNanos;
        }
    }

    @Override // a0.h2
    public final String y() {
        return this.Y;
    }
}
