package a0;

import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CaptureRequest;
import android.util.Log;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class y1 implements z1 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final CameraDevice.CameraDeviceSetup f389a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f390b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final a2 f391c;

    public y1(CameraDevice.CameraDeviceSetup cameraDeviceSetup, String cameraId, a2 cameraErrorListener) {
        kotlin.jvm.internal.q.g(cameraId, "cameraId");
        kotlin.jvm.internal.q.g(cameraErrorListener, "cameraErrorListener");
        this.f389a = cameraDeviceSetup;
        this.f390b = cameraId;
        this.f391c = cameraErrorListener;
    }

    public final CaptureRequest.Builder a(int i10) throws Exception {
        try {
            return this.f389a.createCaptureRequest(i10);
        } catch (Exception e3) {
            boolean z5 = e3 instanceof CameraAccessException;
            int i11 = 0;
            String str = this.f390b;
            a2 a2Var = this.f391c;
            if (!z5) {
                if (!(e3 instanceof IllegalArgumentException) && !(e3 instanceof SecurityException) && !(e3 instanceof UnsupportedOperationException) && !(e3 instanceof NullPointerException)) {
                    if (!(e3 instanceof IllegalStateException)) {
                        throw e3;
                    }
                    Log.d("CXCP", "Failed to execute call: Camera may be closed");
                    return null;
                }
                Log.w("CXCP", "Failed to execute call: Unexpected exception: " + e3.getMessage());
                a2Var.a(str, false, 9);
                return null;
            }
            Log.w("CXCP", "Failed to execute call: Camera encountered an error: " + e3.getMessage());
            CameraAccessException cameraAccessException = (CameraAccessException) e3;
            int reason = cameraAccessException.getReason();
            if (reason == 1) {
                i11 = 3;
            } else if (reason == 2) {
                i11 = 6;
            } else if (reason != 3) {
                if (reason == 4) {
                    i11 = 1;
                } else if (reason != 5) {
                    Log.w("CXCP", "Unexpected CameraAccessException: " + cameraAccessException);
                    i11 = 11;
                } else {
                    i11 = 2;
                }
            }
            a2Var.a(str, true, i11);
            return null;
        }
    }
}
