package a0;

import android.os.SystemClock;
import android.util.Log;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CancellationException;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class d1 {
    public Object A;
    public kotlinx.coroutines.f2 B;
    public kotlinx.coroutines.f2 C;
    public kotlinx.coroutines.f2 D;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final kotlinx.coroutines.p0 f42a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final c0.n f43b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final z.n1 f44c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final z.k f45d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final d0.u f46e;
    public final d0.g0 f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final l1 f47g;
    public final a3 h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final y4 f48i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final j4 f49j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final z.e0 f50k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final d2 f51l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final c0.l f52m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final z.o f53n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final r0 f54o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final d0.f0 f55p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final Object f56q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public boolean f57r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public y6.a f58s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public e0.l f59t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public z.i f60u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public c0.o f61v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public kotlinx.coroutines.f2 f62w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final kotlinx.coroutines.z f63x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public b5 f64y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public i3 f65z;

    public d1(kotlinx.coroutines.p0 scope, c0.n threads, z.n1 strictMode, z.k graphConfig, d0.u uVar, d0.g0 g0Var, l1 cameraStatusMonitor, a3 captureSessionFactory, y4 y4Var, j4 camera2DeviceManager, z.e0 cameraSurfaceManager, d2 camera2Quirks, c0.l timeSource, z.o oVar, r0 r0Var, d0.f0 f0Var, l3 concurrentSessionSequencers) {
        kotlin.jvm.internal.q.g(scope, "scope");
        kotlin.jvm.internal.q.g(threads, "threads");
        kotlin.jvm.internal.q.g(strictMode, "strictMode");
        kotlin.jvm.internal.q.g(graphConfig, "graphConfig");
        kotlin.jvm.internal.q.g(cameraStatusMonitor, "cameraStatusMonitor");
        kotlin.jvm.internal.q.g(captureSessionFactory, "captureSessionFactory");
        kotlin.jvm.internal.q.g(camera2DeviceManager, "camera2DeviceManager");
        kotlin.jvm.internal.q.g(cameraSurfaceManager, "cameraSurfaceManager");
        kotlin.jvm.internal.q.g(camera2Quirks, "camera2Quirks");
        kotlin.jvm.internal.q.g(timeSource, "timeSource");
        kotlin.jvm.internal.q.g(concurrentSessionSequencers, "concurrentSessionSequencers");
        this.f42a = scope;
        this.f43b = threads;
        this.f44c = strictMode;
        this.f45d = graphConfig;
        this.f46e = uVar;
        this.f = g0Var;
        this.f47g = cameraStatusMonitor;
        this.h = captureSessionFactory;
        this.f48i = y4Var;
        this.f49j = camera2DeviceManager;
        this.f50k = cameraSurfaceManager;
        this.f51l = camera2Quirks;
        this.f52m = timeSource;
        this.f53n = oVar;
        this.f54o = r0Var;
        this.f55p = f0Var;
        this.f56q = new Object();
        this.f57r = true;
        this.f58s = z.h.f23342g;
        this.f59t = new e0.j(graphConfig.f23350a);
        ui.d dVar = null;
        this.f63x = kotlinx.coroutines.b0.CompletableDeferred$default(null, 1, null);
        this.C = kotlinx.coroutines.k.launch$default(scope, null, null, new a1(this, dVar, 0), 3, null);
        this.D = kotlinx.coroutines.k.launch$default(scope, null, null, new a1(this, dVar, 1), 3, null);
    }

    public static final void a(d1 d1Var, e0.l lVar) {
        Log.d("CXCP", d1Var + " (" + ((Object) z.p.b(d1Var.f45d.f23350a)) + ") camera status changed: " + lVar);
        synchronized (d1Var.f56q) {
            try {
                if (d1Var.f()) {
                    return;
                }
                if ((lVar instanceof e0.h) || (lVar instanceof e0.j)) {
                    d1Var.f59t = lVar;
                } else if (lVar instanceof e0.i) {
                    d1Var.f52m.getClass();
                    d1Var.f61v = new c0.o(SystemClock.elapsedRealtimeNanos());
                }
                d1Var.h();
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    public static final void b(d1 d1Var, m2 m2Var) {
        synchronized (d1Var.f56q) {
            try {
                if (d1Var.f()) {
                    return;
                }
                z.i iVar = m2Var.f215i;
                if (iVar != null) {
                    d1Var.f60u = iVar;
                    int i10 = iVar.f23344a;
                    if (i10 == 6 || i10 == 1 || i10 == 2) {
                        d1Var.f58s = z.h.f23340d;
                        Log.d("CXCP", d1Var + " is disconnected");
                    } else {
                        d1Var.f58s = z.h.f23341e;
                        Log.d("CXCP", d1Var + " encountered error: " + ((Object) z.i.a(m2Var.f215i.f23344a)));
                    }
                } else {
                    d1Var.f58s = z.h.f23342g;
                }
                d1Var.f.t();
                d1Var.h();
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    public static final void c(d1 d1Var) {
        if (d1Var.f()) {
            Log.w("CXCP", "Ignoring stop(): " + d1Var + " is already closed");
            return;
        }
        y6.a aVar = d1Var.f58s;
        z.h hVar = z.h.h;
        if (aVar.equals(hVar) || d1Var.f58s.equals(z.h.f23342g)) {
            Log.w("CXCP", "Ignoring stop(): " + d1Var + " already stopping or stopped");
            return;
        }
        b5 b5Var = d1Var.f64y;
        i3 i3Var = d1Var.f65z;
        d1Var.f64y = null;
        d1Var.f65z = null;
        d1Var.f58s = hVar;
        Log.d("CXCP", "Stopping " + d1Var);
        d1Var.e(i3Var, b5Var);
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    public final Object d(wi.c cVar) {
        b1 b1Var;
        if (cVar instanceof b1) {
            b1Var = (b1) cVar;
            int i10 = b1Var.Y;
            if ((i10 & Integer.MIN_VALUE) != 0) {
                b1Var.Y = i10 - Integer.MIN_VALUE;
            } else {
                b1Var = new b1(this, cVar);
            }
        } else {
            b1Var = new b1(this, cVar);
        }
        Object obj = b1Var.f11e;
        vi.a aVar = vi.a.f21252e;
        int i11 = b1Var.Y;
        if (i11 == 0) {
            g6.y.I(obj);
            Log.d("CXCP", this + "#awaitClosed");
            synchronized (this.f56q) {
                if (this.f58s.equals(z.h.f23338b)) {
                    Log.d("CXCP", this + "#awaitClosed: Controller is already closed.");
                    return Boolean.TRUE;
                }
                if (!this.f58s.equals(z.h.f23339c)) {
                    Log.w("CXCP", this + "#awaitClosed: Controller isn't closing!");
                    return Boolean.FALSE;
                }
                kotlinx.coroutines.z zVar = this.f63x;
                b1Var.Y = 1;
                if (zVar.await(b1Var) == aVar) {
                    return aVar;
                }
            }
        } else {
            if (i11 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            g6.y.I(obj);
        }
        return Boolean.TRUE;
    }

    public final void e(i3 i3Var, b5 b5Var) {
        kotlinx.coroutines.f2 f2VarLaunch$default = kotlinx.coroutines.k.launch$default(this.f42a, null, null, new m0(i3Var, b5Var, null, 2), 3, null);
        if (this.f58s.equals(z.h.f23339c)) {
            f2VarLaunch$default.invokeOnCompletion(new y0(this, 0));
        }
    }

    public final boolean f() {
        return kotlin.jvm.internal.q.c(this.f58s, z.h.f23339c) || kotlin.jvm.internal.q.c(this.f58s, z.h.f23338b);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r2v3, types: [java.lang.Object, java.util.Map] */
    public final void g() {
        if (f()) {
            Log.i("CXCP", "Ignoring start(): " + this + " is already closed");
            return;
        }
        y6.a aVar = this.f58s;
        z.h hVar = z.h.f;
        if (aVar.equals(hVar)) {
            Log.w("CXCP", "Ignoring start(): " + this + " is already started");
            return;
        }
        ui.d dVar = null;
        this.f60u = null;
        z.k kVar = this.f45d;
        String cameraId = kVar.f23350a;
        Set setV = m7.f.v(new z.p(cameraId));
        z.p pVar = new z.p(cameraId);
        LinkedHashSet linkedHashSet = new LinkedHashSet(ri.x.W(setV.size()));
        boolean z5 = false;
        for (Object obj : setV) {
            boolean z6 = true;
            if (!z5 && kotlin.jvm.internal.q.c(obj, pVar)) {
                z5 = true;
                z6 = false;
            }
            if (z6) {
                linkedHashSet.add(obj);
            }
        }
        List listZ0 = ri.m.z0(linkedHashSet);
        y0 y0Var = new y0(this, 1);
        j4 j4Var = this.f49j;
        j4Var.getClass();
        kotlin.jvm.internal.q.g(cameraId, "cameraId");
        kotlinx.coroutines.p0 p0Var = j4Var.f152d;
        d0.u uVar = this.f46e;
        b5 b5Var = new b5(cameraId, uVar, p0Var);
        if (!kotlinx.coroutines.channels.n.m37isSuccessimpl(((kotlinx.coroutines.channels.i) j4Var.f153e.f519e).mo15trySendJP2dKIU(new n4(b5Var, listZ0, uVar, y0Var)))) {
            Log.e("CXCP", "Camera open request failed for " + ((Object) z.p.b(cameraId)) + '!');
            uVar.a(new z.k0(12, false));
            b5Var = null;
        }
        if (b5Var == null) {
            Log.e("CXCP", "Failed to start " + this + ": Open request submission failed");
            return;
        }
        if (this.f64y != null) {
            throw new IllegalStateException("Check failed.");
        }
        if (this.f65z != null) {
            throw new IllegalStateException("Check failed.");
        }
        this.f64y = b5Var;
        i3 i3Var = new i3(uVar, this.h, this.f48i, this.f50k, this.f52m, kVar.f23362o, null, this.f55p, this.f44c, this.f43b, this.f42a);
        this.f65z = i3Var;
        ?? r4 = this.A;
        if (r4 != 0) {
            i3Var.k(r4);
        }
        this.f58s = hVar;
        Log.d("CXCP", "Started " + this);
        kotlinx.coroutines.f2 f2Var = this.B;
        if (f2Var != null) {
            kotlinx.coroutines.d2.cancel$default(f2Var, (CancellationException) null, 1, (Object) null);
        }
        this.B = kotlinx.coroutines.k.launch$default(this.f42a, null, null, new a1(this, dVar, 2), 3, null);
    }

    /* JADX WARN: Code duplicated, block: B:41:0x0083  */
    /* JADX WARN: Code duplicated, block: B:42:0x0086  */
    /* JADX WARN: Code duplicated, block: B:45:0x008d  */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x0078, code lost:
    
        if (r3.f23344a != 8) goto L39;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void h() {
        /*
            Method dump skipped, instruction units count: 235
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: a0.d1.h():void");
    }

    public final void i(Map map) {
        synchronized (this.f56q) {
            if (f()) {
                return;
            }
            this.A = map;
            i3 i3Var = this.f65z;
            if (i3Var != null) {
                i3Var.k(map);
            }
        }
    }

    public final String toString() {
        return "Camera2CameraController(" + this.f53n + ')';
    }
}
