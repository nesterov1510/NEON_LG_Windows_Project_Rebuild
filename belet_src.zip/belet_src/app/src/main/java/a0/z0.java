package a0;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class z0 implements kotlinx.coroutines.flow.j {
    public final /* synthetic */ d1 X;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f397e;

    public /* synthetic */ z0(d1 d1Var, int i10) {
        this.f397e = i10;
        this.X = d1Var;
    }

    @Override // kotlinx.coroutines.flow.j
    public final Object emit(Object obj, ui.d dVar) {
        switch (this.f397e) {
            case 0:
                e0.l lVar = (e0.l) obj;
                d1 d1Var = this.X;
                z.k kVar = d1Var.f45d;
                if (lVar instanceof e0.h) {
                    if (!((e0.h) lVar).f7266a.equals(kVar.f23350a)) {
                        throw new IllegalStateException("Check failed.");
                    }
                    d1.a(d1Var, lVar);
                } else if (lVar instanceof e0.j) {
                    if (!kotlin.jvm.internal.q.c(((e0.j) lVar).f7268a, kVar.f23350a)) {
                        throw new IllegalStateException("Check failed.");
                    }
                    d1.a(d1Var, lVar);
                }
                return qi.b0.f17350a;
            default:
                d1.a(this.X, e0.i.f7267a);
                return qi.b0.f17350a;
        }
    }
}
