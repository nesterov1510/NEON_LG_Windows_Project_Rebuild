package a0;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public abstract class p1 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final pj.c f263a = pj.b.atomic(0);

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final pj.d f264b = pj.b.atomic(0L);

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final pj.d f265c = pj.b.atomic(0L);
}
