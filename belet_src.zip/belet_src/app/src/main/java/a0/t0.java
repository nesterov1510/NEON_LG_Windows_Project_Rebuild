package a0;

import android.hardware.camera2.CameraManager;
import android.net.Uri;
import android.os.Build;
import android.util.Log;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.gms.internal.measurement.yf;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.Executor;
import okhttp3.internal.ws.WebSocketProtocol;
import org.json.JSONException;
import org.json.JSONObject;
import tm.belet.films.presentation.viewmodel.LoginViewModel;
import tm.belet.films.presentation.viewmodel.MovieInfoViewModel;
import tm.belet.films.presentation.viewmodel.PaymentViewModel;
import tm.belet.films.presentation.viewmodel.ProfileViewModel;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class t0 extends wi.i implements ej.p {
    public int X;
    public /* synthetic */ Object Y;
    public final /* synthetic */ Object Z;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f326e;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public t0(a4.n nVar, Object obj, ui.d dVar) {
        super(2, dVar);
        this.f326e = 8;
        this.Z = nVar;
        this.Y = obj;
    }

    /* JADX WARN: Type inference failed for: r0v47, types: [ej.p, wi.i] */
    @Override // wi.a
    public final ui.d create(Object obj, ui.d dVar) {
        switch (this.f326e) {
            case 0:
                t0 t0Var = new t0((ge.q) this.Z, dVar, 0);
                t0Var.Y = obj;
                return t0Var;
            case 1:
                t0 t0Var2 = new t0((l1) this.Z, dVar, 1);
                t0Var2.Y = obj;
                return t0Var2;
            case 2:
                t0 t0Var3 = new t0((u1) this.Z, dVar, 2);
                t0Var3.Y = obj;
                return t0Var3;
            case 3:
                t0 t0Var4 = new t0((j4) this.Z, dVar, 3);
                t0Var4.Y = obj;
                return t0Var4;
            case 4:
                return new t0((kotlinx.coroutines.flow.i) this.Y, (b5) this.Z, dVar, 4);
            case 5:
                t0 t0Var5 = new t0((ej.p) this.Z, dVar, 5);
                t0Var5.Y = obj;
                return t0Var5;
            case 6:
                return new t0((bf.p) this.Y, (bf.b1) this.Z, dVar, 6);
            case 7:
                return new t0((bf.h1) this.Y, (bf.m0) this.Z, dVar, 7);
            case 8:
                return new t0((a4.n) this.Z, this.Y, dVar);
            case 9:
                return new t0((c6.a) this.Y, (Uri) this.Z, dVar, 9);
            case 10:
                t0 t0Var6 = new t0((ef.c) this.Z, dVar, 10);
                t0Var6.Y = obj;
                return t0Var6;
            case ue.r.NETWORK_CLIENT_ERROR_REASON_FIELD_NUMBER /* 11 */:
                return new t0((sk.a1) this.Y, (kotlin.jvm.internal.b0) this.Z, dVar, 11);
            case ue.r.CUSTOM_ATTRIBUTES_FIELD_NUMBER /* 12 */:
                return new t0((fo.c) this.Y, (z7.c) this.Z, dVar, 12);
            case ue.r.PERF_SESSIONS_FIELD_NUMBER /* 13 */:
                return new t0((fo.f) this.Y, (w4) this.Z, dVar, 13);
            case 14:
                return new t0((fo.i) this.Y, (z7.b) this.Z, dVar, 14);
            case WebSocketProtocol.B0_MASK_OPCODE /* 15 */:
                return new t0((g6.r0) this.Y, (ej.a) this.Z, dVar, 15);
            case WebSocketProtocol.B0_FLAG_RSV3 /* 16 */:
                t0 t0Var7 = new t0((go.b) this.Z, dVar, 16);
                t0Var7.Y = obj;
                return t0Var7;
            case 17:
                return new t0((go.f0) this.Y, (RecyclerView) this.Z, dVar, 17);
            case 18:
                t0 t0Var8 = new t0((go.d1) this.Z, dVar, 18);
                t0Var8.Y = obj;
                return t0Var8;
            case 19:
                t0 t0Var9 = new t0((go.n1) this.Z, dVar, 19);
                t0Var9.Y = obj;
                return t0Var9;
            case 20:
                return new t0((go.w1) this.Y, (ge.a0) this.Z, dVar, 20);
            case 21:
                t0 t0Var10 = new t0((go.k2) this.Z, dVar, 21);
                t0Var10.Y = obj;
                return t0Var10;
            case 22:
                t0 t0Var11 = new t0((go.n2) this.Z, dVar, 22);
                t0Var11.Y = obj;
                return t0Var11;
            case 23:
                t0 t0Var12 = new t0((go.s3) this.Z, dVar, 23);
                t0Var12.Y = obj;
                return t0Var12;
            case 24:
                return new t0((hh.c) this.Y, (md.c) this.Z, dVar, 24);
            case 25:
                t0 t0Var13 = new t0((ho.e0) this.Z, dVar, 25);
                t0Var13.Y = obj;
                return t0Var13;
            case 26:
                return new t0((ho.z0) this.Y, (ge.a0) this.Z, dVar, 26);
            case 27:
                return new t0((ej.p) this.Y, (i6.b0) this.Z, dVar, 27);
            case 28:
                return new t0((ej.p) this.Y, (kotlin.jvm.internal.d0) this.Z, dVar, 28);
            default:
                return new t0((ej.p) this.Y, (i6.p) this.Z, dVar);
        }
    }

    @Override // ej.p
    public final Object invoke(Object obj, Object obj2) throws JSONException {
        switch (this.f326e) {
            case 0:
                return ((t0) create((kotlinx.coroutines.channels.y) obj, (ui.d) obj2)).invokeSuspend(qi.b0.f17350a);
            case 1:
                return ((t0) create((kotlinx.coroutines.channels.y) obj, (ui.d) obj2)).invokeSuspend(qi.b0.f17350a);
            case 2:
                return ((t0) create((kotlinx.coroutines.channels.y) obj, (ui.d) obj2)).invokeSuspend(qi.b0.f17350a);
            case 3:
                return ((t0) create((k2) obj, (ui.d) obj2)).invokeSuspend(qi.b0.f17350a);
            case 4:
                return ((t0) create((kotlinx.coroutines.p0) obj, (ui.d) obj2)).invokeSuspend(qi.b0.f17350a);
            case 5:
                return ((t0) create((kotlinx.coroutines.p0) obj, (ui.d) obj2)).invokeSuspend(qi.b0.f17350a);
            case 6:
                return ((t0) create((kotlinx.coroutines.p0) obj, (ui.d) obj2)).invokeSuspend(qi.b0.f17350a);
            case 7:
                return ((t0) create((kotlinx.coroutines.p0) obj, (ui.d) obj2)).invokeSuspend(qi.b0.f17350a);
            case 8:
                return ((t0) create((kotlinx.coroutines.p0) obj, (ui.d) obj2)).invokeSuspend(qi.b0.f17350a);
            case 9:
                return ((t0) create((kotlinx.coroutines.p0) obj, (ui.d) obj2)).invokeSuspend(qi.b0.f17350a);
            case 10:
                return ((t0) create((JSONObject) obj, (ui.d) obj2)).invokeSuspend(qi.b0.f17350a);
            case ue.r.NETWORK_CLIENT_ERROR_REASON_FIELD_NUMBER /* 11 */:
                return ((t0) create((kotlinx.coroutines.p0) obj, (ui.d) obj2)).invokeSuspend(qi.b0.f17350a);
            case ue.r.CUSTOM_ATTRIBUTES_FIELD_NUMBER /* 12 */:
                ((t0) create((kotlinx.coroutines.p0) obj, (ui.d) obj2)).invokeSuspend(qi.b0.f17350a);
                return vi.a.f21252e;
            case ue.r.PERF_SESSIONS_FIELD_NUMBER /* 13 */:
                ((t0) create((kotlinx.coroutines.p0) obj, (ui.d) obj2)).invokeSuspend(qi.b0.f17350a);
                return vi.a.f21252e;
            case 14:
                return ((t0) create((kotlinx.coroutines.p0) obj, (ui.d) obj2)).invokeSuspend(qi.b0.f17350a);
            case WebSocketProtocol.B0_MASK_OPCODE /* 15 */:
                return ((t0) create((kotlinx.coroutines.p0) obj, (ui.d) obj2)).invokeSuspend(qi.b0.f17350a);
            case WebSocketProtocol.B0_FLAG_RSV3 /* 16 */:
                return ((t0) create((y5.h1) obj, (ui.d) obj2)).invokeSuspend(qi.b0.f17350a);
            case 17:
                return ((t0) create((kotlinx.coroutines.p0) obj, (ui.d) obj2)).invokeSuspend(qi.b0.f17350a);
            case 18:
                return ((t0) create((y5.h1) obj, (ui.d) obj2)).invokeSuspend(qi.b0.f17350a);
            case 19:
                return ((t0) create((y5.h1) obj, (ui.d) obj2)).invokeSuspend(qi.b0.f17350a);
            case 20:
                return ((t0) create((kotlinx.coroutines.p0) obj, (ui.d) obj2)).invokeSuspend(qi.b0.f17350a);
            case 21:
                return ((t0) create((y5.h1) obj, (ui.d) obj2)).invokeSuspend(qi.b0.f17350a);
            case 22:
                return ((t0) create((y5.h1) obj, (ui.d) obj2)).invokeSuspend(qi.b0.f17350a);
            case 23:
                return ((t0) create((kotlinx.coroutines.p0) obj, (ui.d) obj2)).invokeSuspend(qi.b0.f17350a);
            case 24:
                return ((t0) create((kotlinx.coroutines.p0) obj, (ui.d) obj2)).invokeSuspend(qi.b0.f17350a);
            case 25:
                return ((t0) create((y5.h1) obj, (ui.d) obj2)).invokeSuspend(qi.b0.f17350a);
            case 26:
                return ((t0) create((kotlinx.coroutines.p0) obj, (ui.d) obj2)).invokeSuspend(qi.b0.f17350a);
            case 27:
                return ((t0) create((kotlinx.coroutines.p0) obj, (ui.d) obj2)).invokeSuspend(qi.b0.f17350a);
            case 28:
                return ((t0) create((kotlinx.coroutines.p0) obj, (ui.d) obj2)).invokeSuspend(qi.b0.f17350a);
            default:
                return ((t0) create((kotlinx.coroutines.p0) obj, (ui.d) obj2)).invokeSuspend(qi.b0.f17350a);
        }
    }

    /* JADX WARN: Code duplicated, block: B:358:0x06c1  */
    /* JADX WARN: Code duplicated, block: B:359:0x06c6  */
    /* JADX WARN: Code duplicated, block: B:361:0x06ce  */
    /* JADX WARN: Code duplicated, block: B:363:0x06d4  */
    /* JADX WARN: Code duplicated, block: B:364:0x06de  */
    /* JADX WARN: Code duplicated, block: B:416:0x07b1  */
    /* JADX WARN: Type inference failed for: r1v120, types: [ej.p, wi.i] */
    @Override // wi.a
    public final Object invokeSuspend(Object obj) throws JSONException {
        ArrayList arrayList;
        Object objF;
        Object objB;
        Boolean boolA;
        Boolean boolA2;
        Boolean bool;
        Double d2;
        Integer num;
        Integer num2;
        Double d10;
        Boolean bool2;
        Object objB2;
        switch (this.f326e) {
            case 0:
                ge.q qVar = (ge.q) this.Z;
                c0.n nVar = (c0.n) qVar.f8936b;
                vi.a aVar = vi.a.f21252e;
                int i10 = this.X;
                if (i10 == 0) {
                    g6.y.I(obj);
                    kotlinx.coroutines.channels.y yVar = (kotlinx.coroutines.channels.y) this.Y;
                    s0 s0Var = new s0(yVar);
                    CameraManager cameraManager = (CameraManager) ((pi.a) qVar.f8935a).get();
                    if (Build.VERSION.SDK_INT >= 28) {
                        kotlin.jvm.internal.q.d(cameraManager);
                        c0.h(cameraManager, (Executor) nVar.h.getValue(), s0Var);
                    } else {
                        cameraManager.registerAvailabilityCallback(s0Var, nVar.a());
                    }
                    a aVar2 = new a(cameraManager, s0Var, 1);
                    this.X = 1;
                    if (kotlinx.coroutines.channels.w.awaitClose(yVar, aVar2, this) == aVar) {
                        return aVar;
                    }
                } else {
                    if (i10 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                }
                return qi.b0.f17350a;
            case 1:
                l1 l1Var = (l1) this.Z;
                c0.n nVar2 = l1Var.f169e;
                CameraManager cameraManager2 = l1Var.Y;
                vi.a aVar3 = vi.a.f21252e;
                int i11 = this.X;
                if (i11 == 0) {
                    g6.y.I(obj);
                    kotlinx.coroutines.channels.y yVar2 = (kotlinx.coroutines.channels.y) this.Y;
                    j1 j1Var = new j1(yVar2, l1Var);
                    if (Build.VERSION.SDK_INT >= 28) {
                        kotlin.jvm.internal.q.f(cameraManager2, "access$getManager$p(...)");
                        c0.h(cameraManager2, nVar2.f3845e, j1Var);
                    } else {
                        cameraManager2.registerAvailabilityCallback(j1Var, nVar2.a());
                    }
                    a aVar4 = new a(l1Var, j1Var, 2);
                    this.X = 1;
                    if (kotlinx.coroutines.channels.w.awaitClose(yVar2, aVar4, this) == aVar3) {
                        return aVar3;
                    }
                } else {
                    if (i11 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                }
                return qi.b0.f17350a;
            case 2:
                vi.a aVar5 = vi.a.f21252e;
                int i12 = this.X;
                if (i12 == 0) {
                    g6.y.I(obj);
                    kotlinx.coroutines.channels.y yVar3 = (kotlinx.coroutines.channels.y) this.Y;
                    j1 j1Var2 = new j1((u1) this.Z, yVar3);
                    CameraManager cameraManager3 = (CameraManager) ((u1) this.Z).f338a.get();
                    cameraManager3.registerAvailabilityCallback(j1Var2, ((u1) this.Z).f339b.a());
                    u1 u1Var = (u1) this.Z;
                    synchronized (u1Var.f) {
                        arrayList = u1Var.f343g;
                    }
                    if (arrayList != null) {
                        u1.e(yVar3, arrayList);
                    } else {
                        ArrayList arrayListD = ((u1) this.Z).d();
                        if (arrayListD != null) {
                            u1.e(yVar3, arrayListD);
                        }
                    }
                    a aVar6 = new a(cameraManager3, j1Var2, 3);
                    this.X = 1;
                    if (kotlinx.coroutines.channels.w.awaitClose(yVar3, aVar6, this) == aVar5) {
                        return aVar5;
                    }
                } else {
                    if (i12 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                }
                return qi.b0.f17350a;
            case 3:
                qi.b0 b0Var = qi.b0.f17350a;
                vi.a aVar7 = vi.a.f21252e;
                int i13 = this.X;
                if (i13 != 0) {
                    if (i13 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                    return b0Var;
                }
                g6.y.I(obj);
                k2 k2Var = (k2) this.Y;
                j4 j4Var = (j4) this.Z;
                this.X = 1;
                if (k2Var instanceof n4) {
                    objF = j4Var.h((n4) k2Var, this);
                    if (objF != aVar7) {
                        objF = b0Var;
                    }
                } else if (k2Var instanceof k4) {
                    objF = j4Var.e((k4) k2Var, this);
                    if (objF != aVar7) {
                        objF = b0Var;
                    }
                } else if (k2Var instanceof m4) {
                    objF = j4Var.g((m4) k2Var, this);
                    if (objF != aVar7) {
                        objF = b0Var;
                    }
                } else {
                    if (!(k2Var instanceof l4)) {
                        throw new ad.n(11);
                    }
                    objF = j4Var.f((l4) k2Var, this);
                    if (objF != aVar7) {
                        objF = b0Var;
                    }
                }
                return objF == aVar7 ? aVar7 : b0Var;
            case 4:
                vi.a aVar8 = vi.a.f21252e;
                int i14 = this.X;
                if (i14 == 0) {
                    g6.y.I(obj);
                    kotlinx.coroutines.flow.i iVar = (kotlinx.coroutines.flow.i) this.Y;
                    k1 k1Var = new k1(1, (b5) this.Z);
                    this.X = 1;
                    if (iVar.collect(k1Var, this) == aVar8) {
                        return aVar8;
                    }
                } else {
                    if (i14 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                }
                return qi.b0.f17350a;
            case 5:
                vi.a aVar9 = vi.a.f21252e;
                int i15 = this.X;
                if (i15 == 0) {
                    g6.y.I(obj);
                    kotlinx.coroutines.p0 p0Var = (kotlinx.coroutines.p0) this.Y;
                    ej.p pVar = (ej.p) this.Z;
                    this.X = 1;
                    if (pVar.invoke(p0Var, this) == aVar9) {
                        return aVar9;
                    }
                } else {
                    if (i15 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                }
                return qi.b0.f17350a;
            case 6:
                bf.p pVar2 = (bf.p) this.Y;
                ef.j jVar = pVar2.f3636b;
                vi.a aVar10 = vi.a.f21252e;
                int i16 = this.X;
                boolean zBooleanValue = true;
                if (i16 != 0) {
                    if (i16 == 1) {
                        g6.y.I(obj);
                        objB = obj;
                    } else {
                        if (i16 != 2) {
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        g6.y.I(obj);
                    }
                    boolA = jVar.f7780a.a();
                    if (boolA != null) {
                        zBooleanValue = boolA.booleanValue();
                    } else {
                        boolA2 = jVar.f7781b.a();
                        if (boolA2 != null) {
                            zBooleanValue = boolA2.booleanValue();
                        }
                    }
                    if (zBooleanValue) {
                        tc.f fVar = pVar2.f3635a;
                        bf.o oVar = new bf.o(0);
                        fVar.a();
                        fVar.f19192j.add(oVar);
                    } else {
                        wi.f.a(Log.d("FirebaseSessions", "Sessions SDK disabled. Not listening to lifecycle events."));
                    }
                    return qi.b0.f17350a;
                }
                g6.y.I(obj);
                cf.c cVar = cf.c.f4524a;
                this.X = 1;
                objB = cVar.b(this);
                if (objB == aVar10) {
                    return aVar10;
                }
                Collection collectionValues = ((Map) objB).values();
                if (collectionValues == null || !collectionValues.isEmpty()) {
                    Iterator it = collectionValues.iterator();
                    while (true) {
                        if (it.hasNext()) {
                            if (((gd.j) it.next()).f8822a.a()) {
                                this.X = 2;
                                if (jVar.b(this) == aVar10) {
                                    return aVar10;
                                }
                                boolA = jVar.f7780a.a();
                                if (boolA != null) {
                                    zBooleanValue = boolA.booleanValue();
                                } else {
                                    boolA2 = jVar.f7781b.a();
                                    if (boolA2 != null) {
                                        zBooleanValue = boolA2.booleanValue();
                                    }
                                }
                                if (zBooleanValue) {
                                    wi.f.a(Log.d("FirebaseSessions", "Sessions SDK disabled. Not listening to lifecycle events."));
                                } else {
                                    tc.f fVar2 = pVar2.f3635a;
                                    bf.o oVar2 = new bf.o(0);
                                    fVar2.a();
                                    fVar2.f19192j.add(oVar2);
                                }
                                return qi.b0.f17350a;
                            }
                        }
                    }
                }
                wi.f.a(Log.d("FirebaseSessions", "No Sessions subscribers. Not listening to lifecycle events."));
                return qi.b0.f17350a;
            case 7:
                bf.m0 m0Var = (bf.m0) this.Z;
                bf.h1 h1Var = (bf.h1) this.Y;
                vi.a aVar11 = vi.a.f21252e;
                int i17 = this.X;
                ui.d dVar = null;
                try {
                    if (i17 != 0) {
                        if (i17 == 1) {
                            g6.y.I(obj);
                        } else {
                            if (i17 != 2) {
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                            g6.y.I(obj);
                        }
                        return qi.b0.f17350a;
                    }
                    g6.y.I(obj);
                    p2.e eVar = h1Var.f3582e;
                    bf.f1 f1Var = new bf.f1(h1Var, dVar, 1);
                    this.X = 1;
                    if (eVar.b(f1Var, this) == aVar11) {
                        return aVar11;
                    }
                    break;
                } catch (Exception e3) {
                    Log.d("FirebaseSessions", "App foregrounded, failed to update data. Message: " + e3.getMessage());
                    if (h1Var.e(m0Var)) {
                        bf.r0 r0VarA = h1Var.f3579b.a(m0Var.f3625a);
                        h1Var.h = bf.m0.a(m0Var, r0VarA, null, null, 4);
                        bf.w0 w0Var = (bf.w0) h1Var.f3580c;
                        kotlinx.coroutines.k.launch$default(kotlinx.coroutines.q0.CoroutineScope(w0Var.f3663e), null, null, new u2(w0Var, r0VarA, null), 3, null);
                        String str = r0VarA.f3639a;
                        bf.e1 e1Var = bf.e1.X;
                        this.X = 2;
                        if (bf.h1.a(h1Var, str, e1Var, this) == aVar11) {
                            return aVar11;
                        }
                    }
                }
                return qi.b0.f17350a;
            case 8:
                Object obj2 = this.Y;
                vi.a aVar12 = vi.a.f21252e;
                int i18 = this.X;
                if (i18 == 0) {
                    g6.y.I(obj);
                    Log.d("CXCP", "PruningProcessingQueue: Processing " + obj2);
                    t0 t0Var = (t0) ((a4.n) this.Z).f517c;
                    this.X = 1;
                    if (t0Var.invoke(obj2, this) == aVar12) {
                        return aVar12;
                    }
                } else {
                    if (i18 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                }
                return qi.b0.f17350a;
            case 9:
                vi.a aVar13 = vi.a.f21252e;
                int i19 = this.X;
                if (i19 == 0) {
                    g6.y.I(obj);
                    y6.a aVar14 = ((c6.a) this.Y).f3934a;
                    Uri uri = (Uri) this.Z;
                    this.X = 1;
                    if (aVar14.y(uri, this) == aVar13) {
                        return aVar13;
                    }
                } else {
                    if (i19 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                }
                return qi.b0.f17350a;
            case 10:
                ef.c cVar2 = (ef.c) this.Z;
                vi.a aVar15 = vi.a.f21252e;
                int i20 = this.X;
                if (i20 == 0) {
                    g6.y.I(obj);
                    JSONObject jSONObject = (JSONObject) this.Y;
                    Log.d("FirebaseSessions", "Fetched settings: " + jSONObject);
                    Integer num3 = null;
                    if (jSONObject.has("app_quality")) {
                        Object obj3 = jSONObject.get("app_quality");
                        kotlin.jvm.internal.q.e(obj3, "null cannot be cast to non-null type org.json.JSONObject");
                        JSONObject jSONObject2 = (JSONObject) obj3;
                        try {
                            bool2 = jSONObject2.has("sessions_enabled") ? (Boolean) jSONObject2.get("sessions_enabled") : null;
                            try {
                                d10 = jSONObject2.has("sampling_rate") ? (Double) jSONObject2.get("sampling_rate") : null;
                                try {
                                    num2 = jSONObject2.has("session_timeout_seconds") ? (Integer) jSONObject2.get("session_timeout_seconds") : null;
                                    try {
                                        if (jSONObject2.has("cache_duration")) {
                                            num3 = (Integer) jSONObject2.get("cache_duration");
                                        }
                                    } catch (JSONException e10) {
                                        e = e10;
                                        wi.f.a(Log.e("FirebaseSessions", "Error parsing the configs remotely fetched: ", e));
                                    }
                                } catch (JSONException e11) {
                                    e = e11;
                                    num2 = null;
                                }
                            } catch (JSONException e12) {
                                e = e12;
                                num2 = null;
                                d10 = null;
                            }
                        } catch (JSONException e13) {
                            e = e13;
                            num2 = null;
                            d10 = null;
                            bool2 = null;
                        }
                        num = num2;
                        d2 = d10;
                        bool = bool2;
                    } else {
                        bool = null;
                        d2 = null;
                        num = null;
                    }
                    ef.n nVar3 = cVar2.f7768e;
                    ef.g gVar = new ef.g(bool, d2, num, new Integer(num3 != null ? num3.intValue() : ef.c.f7763g), new Long(cVar2.f7764a.a().f3621c));
                    this.X = 1;
                    if (nVar3.c(gVar, this) == aVar15) {
                        return aVar15;
                    }
                    break;
                } else {
                    if (i20 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                }
                return qi.b0.f17350a;
            case ue.r.NETWORK_CLIENT_ERROR_REASON_FIELD_NUMBER /* 11 */:
                vi.a aVar16 = vi.a.f21252e;
                int i21 = this.X;
                if (i21 != 0) {
                    if (i21 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                    return obj;
                }
                g6.y.I(obj);
                sk.a1 a1Var = (sk.a1) this.Y;
                int i22 = ((kotlin.jvm.internal.b0) this.Z).f13947e;
                this.X = 1;
                Object objB3 = a1Var.b(i22, 10, 1, "mid", null, this);
                return objB3 == aVar16 ? aVar16 : objB3;
            case ue.r.CUSTOM_ATTRIBUTES_FIELD_NUMBER /* 12 */:
                fo.c cVar3 = (fo.c) this.Y;
                vi.a aVar17 = vi.a.f21252e;
                int i23 = this.X;
                if (i23 == 0) {
                    g6.y.I(obj);
                    kotlinx.coroutines.flow.h0 h0Var = ((ProfileViewModel) cVar3.H1.getValue()).f19676q;
                    fo.b bVar = new fo.b((z7.c) this.Z, cVar3, 0);
                    this.X = 1;
                    if (h0Var.collect(bVar, this) == aVar17) {
                        return aVar17;
                    }
                } else {
                    if (i23 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                }
                throw new ad.n(10);
            case ue.r.PERF_SESSIONS_FIELD_NUMBER /* 13 */:
                fo.f fVar3 = (fo.f) this.Y;
                vi.a aVar18 = vi.a.f21252e;
                int i24 = this.X;
                if (i24 == 0) {
                    g6.y.I(obj);
                    kotlinx.coroutines.flow.h0 h0Var2 = ((PaymentViewModel) fVar3.H1.getValue()).f19631j;
                    fo.b bVar2 = new fo.b((w4) this.Z, fVar3, 1);
                    this.X = 1;
                    if (h0Var2.collect(bVar2, this) == aVar18) {
                        return aVar18;
                    }
                } else {
                    if (i24 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                }
                throw new ad.n(10);
            case 14:
                fo.i iVar2 = (fo.i) this.Y;
                vi.a aVar19 = vi.a.f21252e;
                int i25 = this.X;
                if (i25 == 0) {
                    g6.y.I(obj);
                    kotlinx.coroutines.flow.h0 h0Var3 = ((ProfileViewModel) iVar2.G1.getValue()).f19678s;
                    ei.b bVar3 = new ei.b((z7.b) this.Z, iVar2, null, 2);
                    this.X = 1;
                    if (kotlinx.coroutines.flow.k.collectLatest(h0Var3, bVar3, this) == aVar19) {
                        return aVar19;
                    }
                } else {
                    if (i25 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                }
                return qi.b0.f17350a;
            case WebSocketProtocol.B0_MASK_OPCODE /* 15 */:
                ej.a aVar20 = (ej.a) this.Z;
                vi.a aVar21 = vi.a.f21252e;
                int i26 = this.X;
                try {
                    if (i26 == 0) {
                        g6.y.I(obj);
                        g6.r0 r0Var = (g6.r0) this.Y;
                        this.X = 1;
                        objB2 = g6.r0.b(r0Var, this);
                        if (objB2 == aVar21) {
                            return aVar21;
                        }
                    } else {
                        if (i26 != 1) {
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        g6.y.I(obj);
                        objB2 = obj;
                    }
                    aVar20.invoke();
                    return qi.b0.f17350a;
                } catch (Throwable th2) {
                    aVar20.invoke();
                    throw th2;
                }
            case WebSocketProtocol.B0_FLAG_RSV3 /* 16 */:
                y5.h1 h1Var2 = (y5.h1) this.Y;
                vi.a aVar22 = vi.a.f21252e;
                int i27 = this.X;
                if (i27 == 0) {
                    g6.y.I(obj);
                    yn.l2 l2Var = ((go.b) this.Z).f9041w1;
                    if (l2Var != null) {
                        this.Y = null;
                        this.X = 1;
                        if (l2Var.E(h1Var2, this) == aVar22) {
                            return aVar22;
                        }
                    }
                } else {
                    if (i27 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                }
                return qi.b0.f17350a;
            case 17:
                qi.b0 b0Var2 = qi.b0.f17350a;
                go.f0 f0Var = (go.f0) this.Y;
                vi.a aVar23 = vi.a.f21252e;
                int i28 = this.X;
                if (i28 != 0) {
                    if (i28 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                    return b0Var2;
                }
                g6.y.I(obj);
                Integer num4 = f0Var.E1;
                if (num4 == null) {
                    return b0Var2;
                }
                kotlinx.coroutines.flow.h0 h0VarE = f0Var.n0().e(num4.intValue(), f0Var.L1, f0Var.O1, "right", null);
                ei.b bVar4 = new ei.b(f0Var, (RecyclerView) this.Z, null, 4);
                this.X = 1;
                return kotlinx.coroutines.flow.k.collectLatest(h0VarE, bVar4, this) == aVar23 ? aVar23 : b0Var2;
            case 18:
                go.d1 d1Var = (go.d1) this.Z;
                y5.h1 h1Var3 = (y5.h1) this.Y;
                vi.a aVar24 = vi.a.f21252e;
                int i29 = this.X;
                if (i29 == 0) {
                    g6.y.I(obj);
                    ((ConstraintLayout) ((w4) d1Var.j0().f8937c).X).setVisibility(8);
                    ((RecyclerView) d1Var.j0().f8936b).setAdapter(d1Var.f9080u1);
                    yn.t0 t0Var2 = d1Var.f9080u1;
                    if (t0Var2 != null) {
                        this.Y = null;
                        this.X = 1;
                        if (t0Var2.E(h1Var3, this) == aVar24) {
                            return aVar24;
                        }
                    }
                } else {
                    if (i29 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                }
                return qi.b0.f17350a;
            case 19:
                go.n1 n1Var = (go.n1) this.Z;
                y5.h1 h1Var4 = (y5.h1) this.Y;
                vi.a aVar25 = vi.a.f21252e;
                int i30 = this.X;
                if (i30 == 0) {
                    g6.y.I(obj);
                    n1Var.l0().f7086o.setAdapter(n1Var.f9211u1);
                    yn.t0 t0Var3 = n1Var.f9211u1;
                    if (t0Var3 != null) {
                        this.Y = null;
                        this.X = 1;
                        if (t0Var3.E(h1Var4, this) == aVar25) {
                            return aVar25;
                        }
                    }
                } else {
                    if (i30 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                }
                return qi.b0.f17350a;
            case 20:
                go.w1 w1Var = (go.w1) this.Y;
                vi.a aVar26 = vi.a.f21252e;
                int i31 = this.X;
                if (i31 == 0) {
                    g6.y.I(obj);
                    kotlinx.coroutines.flow.h0 h0Var4 = ((LoginViewModel) w1Var.f9384r1.getValue()).f19546j;
                    ei.b bVar5 = new ei.b(w1Var, (ge.a0) this.Z, null, 5);
                    this.X = 1;
                    if (kotlinx.coroutines.flow.k.collectLatest(h0Var4, bVar5, this) == aVar26) {
                        return aVar26;
                    }
                } else {
                    if (i31 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                }
                return qi.b0.f17350a;
            case 21:
                y5.h1 h1Var5 = (y5.h1) this.Y;
                vi.a aVar27 = vi.a.f21252e;
                int i32 = this.X;
                if (i32 == 0) {
                    g6.y.I(obj);
                    yn.l2 l2Var2 = ((go.k2) this.Z).f9176v1;
                    if (l2Var2 != null) {
                        this.Y = null;
                        this.X = 1;
                        if (l2Var2.E(h1Var5, this) == aVar27) {
                            return aVar27;
                        }
                    }
                } else {
                    if (i32 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                }
                return qi.b0.f17350a;
            case 22:
                y5.h1 h1Var6 = (y5.h1) this.Y;
                vi.a aVar28 = vi.a.f21252e;
                int i33 = this.X;
                if (i33 == 0) {
                    g6.y.I(obj);
                    yn.l2 l2Var3 = ((go.n2) this.Z).f9226v1;
                    if (l2Var3 != null) {
                        this.Y = null;
                        this.X = 1;
                        if (l2Var3.E(h1Var6, this) == aVar28) {
                            return aVar28;
                        }
                    }
                } else {
                    if (i33 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                }
                return qi.b0.f17350a;
            case 23:
                go.s3 s3Var = (go.s3) this.Z;
                kotlinx.coroutines.p0 p0Var2 = (kotlinx.coroutines.p0) this.Y;
                vi.a aVar29 = vi.a.f21252e;
                int i34 = this.X;
                if (i34 == 0) {
                    g6.y.I(obj);
                    MovieInfoViewModel movieInfoViewModelR0 = s3Var.r0();
                    ui.d dVar2 = null;
                    kotlinx.coroutines.k.launch$default(androidx.lifecycle.r0.g(movieInfoViewModelR0), null, null, new tm.belet.films.presentation.viewmodel.l1(movieInfoViewModelR0, s3Var.f9315x1, dVar2, 4), 3, null);
                    kotlinx.coroutines.flow.h0 h0Var5 = s3Var.r0().C;
                    ei.b bVar6 = new ei.b(s3Var, p0Var2, dVar2, 6);
                    this.Y = null;
                    this.X = 1;
                    if (kotlinx.coroutines.flow.k.collectLatest(h0Var5, bVar6, this) == aVar29) {
                        return aVar29;
                    }
                } else {
                    if (i34 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                }
                return qi.b0.f17350a;
            case 24:
                hh.c cVar4 = (hh.c) this.Y;
                vi.a aVar30 = vi.a.f21252e;
                int i35 = this.X;
                if (i35 != 0) {
                    if (i35 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                    return obj;
                }
                g6.y.I(obj);
                kotlinx.coroutines.f2 f2Var = (kotlinx.coroutines.f2) cVar4.getCoroutineContext().get(kotlinx.coroutines.f2.Key);
                if (!(f2Var != null ? f2Var.isActive() : false)) {
                    throw new yf(3);
                }
                md.c cVar5 = (md.c) this.Z;
                this.X = 1;
                Object objD0 = cVar4.d0(cVar5, this);
                return objD0 == aVar30 ? aVar30 : objD0;
            case 25:
                y5.h1 h1Var7 = (y5.h1) this.Y;
                vi.a aVar31 = vi.a.f21252e;
                int i36 = this.X;
                if (i36 == 0) {
                    g6.y.I(obj);
                    yn.o1 o1Var = ((ho.e0) this.Z).f10324s1;
                    if (o1Var == null) {
                        kotlin.jvm.internal.q.n("adapterNotification");
                        throw null;
                    }
                    this.Y = null;
                    this.X = 1;
                    if (o1Var.E(h1Var7, this) == aVar31) {
                        return aVar31;
                    }
                } else {
                    if (i36 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                }
                return qi.b0.f17350a;
            case 26:
                ho.z0 z0Var = (ho.z0) this.Y;
                vi.a aVar32 = vi.a.f21252e;
                int i37 = this.X;
                if (i37 == 0) {
                    g6.y.I(obj);
                    kotlinx.coroutines.flow.h0 h0Var6 = z0Var.n0().f19680u;
                    ei.b bVar7 = new ei.b(z0Var, (ge.a0) this.Z, null, 7);
                    this.X = 1;
                    if (kotlinx.coroutines.flow.k.collectLatest(h0Var6, bVar7, this) == aVar32) {
                        return aVar32;
                    }
                } else {
                    if (i37 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                }
                return qi.b0.f17350a;
            case 27:
                vi.a aVar33 = vi.a.f21252e;
                int i38 = this.X;
                if (i38 != 0) {
                    if (i38 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                    return obj;
                }
                g6.y.I(obj);
                ej.p pVar3 = (ej.p) this.Y;
                i6.b0 b0Var3 = (i6.b0) this.Z;
                this.X = 1;
                Object objInvoke = pVar3.invoke(b0Var3, this);
                return objInvoke == aVar33 ? aVar33 : objInvoke;
            case 28:
                vi.a aVar34 = vi.a.f21252e;
                int i39 = this.X;
                if (i39 != 0) {
                    if (i39 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                    return obj;
                }
                g6.y.I(obj);
                ej.p pVar4 = (ej.p) this.Y;
                Object obj4 = ((kotlin.jvm.internal.d0) this.Z).f13951e;
                this.X = 1;
                Object objInvoke2 = pVar4.invoke(obj4, this);
                return objInvoke2 == aVar34 ? aVar34 : objInvoke2;
            default:
                vi.a aVar35 = vi.a.f21252e;
                int i40 = this.X;
                if (i40 != 0) {
                    if (i40 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                    return obj;
                }
                g6.y.I(obj);
                ?? r4 = (wi.i) this.Y;
                i6.p pVar5 = (i6.p) this.Z;
                this.X = 1;
                Object objInvoke3 = r4.invoke(pVar5, this);
                return objInvoke3 == aVar35 ? aVar35 : objInvoke3;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    public t0(ej.p pVar, i6.p pVar2, ui.d dVar) {
        super(2, dVar);
        this.f326e = 29;
        this.Y = (wi.i) pVar;
        this.Z = pVar2;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ t0(Object obj, Object obj2, ui.d dVar, int i10) {
        super(2, dVar);
        this.f326e = i10;
        this.Y = obj;
        this.Z = obj2;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ t0(Object obj, ui.d dVar, int i10) {
        super(2, dVar);
        this.f326e = i10;
        this.Z = obj;
    }
}
