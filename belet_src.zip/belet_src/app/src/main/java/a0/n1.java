package a0;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.util.Log;
import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.CancellationException;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class n1 extends wi.i implements ej.l {
    public int X;
    public final /* synthetic */ Object Y;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f225e;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ n1(Object obj, ui.d dVar, int i10) {
        super(1, dVar);
        this.f225e = i10;
        this.Y = obj;
    }

    @Override // wi.a
    public final ui.d create(ui.d dVar) {
        switch (this.f225e) {
            case 0:
                return new n1((m1) this.Y, dVar, 0);
            case 1:
                return new n1((r2.b) this.Y, dVar, 1);
            case 2:
                return new n1((p2.v) this.Y, dVar, 2);
            default:
                return new n1((w.f1) this.Y, dVar, 3);
        }
    }

    @Override // ej.l
    public final Object invoke(Object obj) {
        ui.d dVar = (ui.d) obj;
        switch (this.f225e) {
            case 0:
                break;
            case 1:
                break;
            case 2:
                break;
        }
        return ((n1) create(dVar)).invokeSuspend(qi.b0.f17350a);
    }

    @Override // wi.a
    public final Object invokeSuspend(Object obj) throws Exception {
        Context context;
        String str;
        switch (this.f225e) {
            case 0:
                vi.a aVar = vi.a.f21252e;
                int i10 = this.X;
                qi.b0 b0Var = qi.b0.f17350a;
                if (i10 == 0) {
                    g6.y.I(obj);
                    m1 m1Var = (m1) this.Y;
                    this.X = 1;
                    Object objAwait = m1Var.f207l.await(this);
                    if (objAwait != aVar) {
                        objAwait = b0Var;
                    }
                    if (objAwait == aVar) {
                        return aVar;
                    }
                } else {
                    if (i10 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                }
                return b0Var;
            case 1:
                vi.a aVar2 = vi.a.f21252e;
                int i11 = this.X;
                qi.b0 b0Var2 = qi.b0.f17350a;
                if (i11 == 0) {
                    g6.y.I(obj);
                    r2.b bVar = (r2.b) this.Y;
                    this.X = 1;
                    SharedPreferences.Editor editorEdit = ((SharedPreferences) bVar.f17851e.getValue()).edit();
                    Set set = bVar.f;
                    if (set == null) {
                        editorEdit.clear();
                    } else {
                        Iterator it = set.iterator();
                        while (it.hasNext()) {
                            editorEdit.remove((String) it.next());
                        }
                    }
                    if (!editorEdit.commit()) {
                        throw new IOException("Unable to delete migrated keys from SharedPreferences.");
                    }
                    if (((SharedPreferences) bVar.f17851e.getValue()).getAll().isEmpty() && (context = bVar.f17849c) != null && (str = bVar.f17850d) != null) {
                        if (Build.VERSION.SDK_INT >= 24) {
                            androidx.core.widget.i.e(context, str);
                        } else {
                            File file = new File(new File(context.getApplicationInfo().dataDir, "shared_prefs"), str.concat(".xml"));
                            File file2 = new File(file.getPath() + ".bak");
                            file.delete();
                            file2.delete();
                        }
                    }
                    if (set != null) {
                        set.clear();
                    }
                    if (b0Var2 == aVar2) {
                        return aVar2;
                    }
                } else {
                    if (i11 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                }
                return b0Var2;
            case 2:
                vi.a aVar3 = vi.a.f21252e;
                int i12 = this.X;
                if (i12 != 0) {
                    if (i12 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                    return obj;
                }
                g6.y.I(obj);
                p2.v vVar = (p2.v) this.Y;
                this.X = 1;
                Object objInvoke = vVar.invoke(this);
                return objInvoke == aVar3 ? aVar3 : objInvoke;
            default:
                vi.a aVar4 = vi.a.f21252e;
                int i13 = this.X;
                try {
                    if (i13 == 0) {
                        g6.y.I(obj);
                        if (y6.a.o("CXCP")) {
                            Log.d("CXCP", "UseCaseCameraRequestControlImpl#setTorchOnAsync");
                        }
                        d0.b bVarA = ((w.f1) this.Y).f21328c.a();
                        this.X = 1;
                        obj = bVarA.a(this);
                        if (obj == aVar4) {
                            return aVar4;
                        }
                    } else {
                        if (i13 != 1) {
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        g6.y.I(obj);
                    }
                    AutoCloseable autoCloseable = (AutoCloseable) obj;
                    try {
                        kotlinx.coroutines.z zVarM = ((d0.c) autoCloseable).m();
                        ji.k.B(autoCloseable, null);
                        return zVarM;
                    } catch (Throwable th2) {
                        try {
                            throw th2;
                        } catch (Throwable th3) {
                            ji.k.B(autoCloseable, th2);
                            throw th3;
                        }
                    }
                } catch (CancellationException e3) {
                    if (y6.a.o("CXCP")) {
                        Log.d("CXCP", "Cannot acquire the CameraGraph.Session", e3);
                    }
                    return w.f1.f21324l;
                }
        }
    }
}
