package a0;

import android.util.Log;
import android.view.Surface;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class u implements a3 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final d0.f0 f336a;

    public u(d0.f0 f0Var, c0.n threads) {
        kotlin.jvm.internal.q.g(threads, "threads");
        this.f336a = f0Var;
    }

    @Override // a0.a3
    public final z2 a(h2 cameraDevice, Map surfaces, i3 captureSessionState) {
        kotlin.jvm.internal.q.g(cameraDevice, "cameraDevice");
        kotlin.jvm.internal.q.g(surfaces, "surfaces");
        kotlin.jvm.internal.q.g(captureSessionState, "captureSessionState");
        ArrayList arrayList = new ArrayList(surfaces.size());
        Iterator it = surfaces.entrySet().iterator();
        while (it.hasNext()) {
            arrayList.add((Surface) ((Map.Entry) it.next()).getValue());
        }
        if (cameraDevice.F(arrayList, captureSessionState)) {
            return new y2(ri.t.f18051e, b3.a(surfaces, this.f336a));
        }
        Log.w("CXCP", "Failed to create ConstrainedHighSpeedCaptureSession from " + cameraDevice + " for " + captureSessionState + '!');
        captureSessionState.a();
        return x2.f381a;
    }
}
