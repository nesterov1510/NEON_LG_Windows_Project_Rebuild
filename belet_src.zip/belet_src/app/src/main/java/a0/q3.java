package a0;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class q3 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final m f285a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final z.i f286b;

    public q3(m mVar, z.i iVar, int i10) {
        mVar = (i10 & 1) != 0 ? null : mVar;
        iVar = (i10 & 2) != 0 ? null : iVar;
        this.f285a = mVar;
        this.f286b = iVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof q3)) {
            return false;
        }
        q3 q3Var = (q3) obj;
        return kotlin.jvm.internal.q.c(this.f285a, q3Var.f285a) && kotlin.jvm.internal.q.c(this.f286b, q3Var.f286b);
    }

    public final int hashCode() {
        m mVar = this.f285a;
        int iHashCode = (mVar == null ? 0 : mVar.hashCode()) * 31;
        z.i iVar = this.f286b;
        return iHashCode + (iVar != null ? iVar.f23344a : 0);
    }

    public final String toString() {
        return "OpenCameraResult(cameraState=" + this.f285a + ", errorCode=" + this.f286b + ')';
    }
}
