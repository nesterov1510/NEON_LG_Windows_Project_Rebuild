package a0;

import java.util.LinkedHashMap;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class a2 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Object f6a = new Object();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final LinkedHashMap f7b = new LinkedHashMap();

    public final void a(String cameraId, boolean z5, int i10) {
        b5 b5Var;
        kotlin.jvm.internal.q.g(cameraId, "cameraId");
        synchronized (this.f6a) {
            b5Var = (b5) this.f7b.get(new z.p(cameraId));
        }
        if (b5Var == null) {
            return;
        }
        b5Var.f21b.a(new z.k0(i10, z5));
    }
}
