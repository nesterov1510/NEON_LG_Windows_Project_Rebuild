package a0;

import android.util.Log;
import java.util.ArrayList;
import java.util.Map;
import java.util.concurrent.Executor;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class y implements a3 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final c0.n f385a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final z.k f386b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final d0.f0 f387c;

    public y(c0.n threads, z.k graphConfig, d0.f0 f0Var) {
        kotlin.jvm.internal.q.g(threads, "threads");
        kotlin.jvm.internal.q.g(graphConfig, "graphConfig");
        this.f385a = threads;
        this.f386b = graphConfig;
        this.f387c = f0Var;
    }

    @Override // a0.a3
    public final z2 a(h2 cameraDevice, Map surfaces, i3 captureSessionState) {
        ArrayList arrayList;
        ArrayList arrayList2;
        kotlin.jvm.internal.q.g(cameraDevice, "cameraDevice");
        kotlin.jvm.internal.q.g(surfaces, "surfaces");
        kotlin.jvm.internal.q.g(captureSessionState, "captureSessionState");
        z.k kVar = this.f386b;
        int i10 = kVar.h;
        if (i10 == 0) {
            i10 = 0;
        } else if (i10 == 1) {
            i10 = 1;
        } else if (i10 == 2) {
            throw new IllegalArgumentException("Unsupported session mode: " + ((Object) android.support.v4.media.session.b.I(kVar.h)));
        }
        s3 s3VarB = b3.b(kVar, this.f387c, surfaces);
        ArrayList arrayList3 = s3VarB.f320a;
        boolean zIsEmpty = arrayList3.isEmpty();
        x2 x2Var = x2.f381a;
        if (zIsEmpty) {
            Log.w("CXCP", "Failed to create OutputConfigurations for " + kVar);
            captureSessionState.a();
            return x2Var;
        }
        ArrayList arrayList4 = kVar.f23353d;
        if (arrayList4 != null) {
            arrayList2 = new ArrayList(ri.o.S(arrayList4, 10));
            int size = arrayList4.size();
            int i11 = 0;
            while (i11 < size) {
                Object obj = arrayList4.get(i11);
                i11++;
                z.x0 x0Var = (z.x0) ri.m.t0(((z.p0) obj).f23382a.f23311a);
                arrayList2.add(new p3(x0Var.f23404a.getWidth(), x0Var.f23404a.getHeight(), x0Var.f23405b));
                arrayList3 = arrayList3;
            }
            arrayList = arrayList3;
        } else {
            arrayList = arrayList3;
            arrayList2 = null;
        }
        if (arrayList2 != null && !arrayList2.isEmpty()) {
            int size2 = arrayList2.size();
            int i12 = 0;
            while (i12 < size2) {
                Object obj2 = arrayList2.get(i12);
                i12++;
                if (((p3) obj2).f272c != ((p3) arrayList2.get(0)).f272c) {
                    throw new IllegalStateException("All InputStream.Config objects must have the same format for multi resolution");
                }
            }
        }
        if (cameraDevice.t(new t4(i10, arrayList2, arrayList, (Executor) this.f385a.h.getValue(), captureSessionState, kVar.f, kVar.f23355g))) {
            return new y2(s3VarB.f321b, s3VarB.f323d);
        }
        Log.w("CXCP", "Failed to create capture session from " + cameraDevice + " for " + captureSessionState + '!');
        captureSessionState.a();
        return x2Var;
    }
}
