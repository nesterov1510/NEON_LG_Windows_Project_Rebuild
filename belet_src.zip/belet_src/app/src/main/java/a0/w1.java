package a0;

import android.content.ContentProviderClient;
import android.content.res.TypedArray;
import android.drm.DrmManagerClient;
import android.graphics.SurfaceTexture;
import android.media.MediaDrm;
import android.media.MediaMetadataRetriever;
import android.util.Log;
import android.view.Surface;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class w1 implements f2 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ CountDownLatch f370a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ pj.a f371b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Surface f372c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ SurfaceTexture f373d;

    public w1(CountDownLatch countDownLatch, pj.a aVar, Surface surface, SurfaceTexture surfaceTexture) {
        this.f370a = countDownLatch;
        this.f371b = aVar;
        this.f372c = surface;
        this.f373d = surfaceTexture;
    }

    @Override // a0.f2
    public final void d(g2 g2Var) {
        Log.d("CXCP", "Empty capture session configure failed");
        if (this.f371b.compareAndSet(false, true)) {
            this.f372c.release();
            this.f373d.release();
        }
        this.f370a.countDown();
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // a0.f2
    public final void e(g2 g2Var) throws Exception {
        Log.d("CXCP", "Empty capture session configured. Closing it");
        if (g2Var instanceof AutoCloseable) {
            g2Var.close();
        } else if (g2Var instanceof ExecutorService) {
            w.g((ExecutorService) g2Var);
        } else if (g2Var instanceof TypedArray) {
            ((TypedArray) g2Var).recycle();
        } else if (g2Var instanceof MediaMetadataRetriever) {
            ((MediaMetadataRetriever) g2Var).release();
        } else if (g2Var instanceof MediaDrm) {
            ((MediaDrm) g2Var).release();
        } else if (g2Var instanceof DrmManagerClient) {
            ((DrmManagerClient) g2Var).release();
        } else {
            if (!(g2Var instanceof ContentProviderClient)) {
                throw new IllegalArgumentException();
            }
            ((ContentProviderClient) g2Var).release();
        }
        this.f370a.countDown();
    }

    @Override // a0.f2
    public final void h(g2 g2Var) {
        Log.d("CXCP", "Empty capture session closed");
        if (this.f371b.compareAndSet(false, true)) {
            this.f372c.release();
            this.f373d.release();
        }
    }

    @Override // a0.x4
    public final void a() {
    }

    @Override // a0.x4
    public final void c() {
    }

    @Override // a0.f2
    public final void b(g2 g2Var) {
    }

    @Override // a0.f2
    public final void f(g2 g2Var) {
    }

    @Override // a0.f2
    public final void g(g2 g2Var) {
    }
}
