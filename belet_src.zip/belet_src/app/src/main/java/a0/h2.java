package a0;

import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.TotalCaptureResult;
import android.hardware.camera2.params.InputConfiguration;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public interface h2 extends z.o1 {
    CaptureRequest.Builder C(TotalCaptureResult totalCaptureResult);

    void E(int i10);

    boolean F(ArrayList arrayList, f2 f2Var);

    void K();

    CaptureRequest.Builder T(int i10);

    boolean X(List list, f2 f2Var);

    boolean b0(InputConfiguration inputConfiguration, ArrayList arrayList, f2 f2Var);

    boolean e0(p3 p3Var, ArrayList arrayList, f2 f2Var);

    void i0();

    boolean q0(ArrayList arrayList, f2 f2Var);

    boolean t(t4 t4Var);

    boolean v(n3 n3Var);

    String y();
}
