package a0;

import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.CaptureResult;
import android.os.Build;
import android.os.Trace;
import android.util.ArrayMap;
import android.util.Log;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class h1 implements z.s {
    public final CameraCharacteristics X;
    public final b2 Y;
    public final Set Z;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final String f96e;

    /* JADX INFO: renamed from: r0, reason: collision with root package name */
    public final ArrayMap f97r0;

    /* JADX INFO: renamed from: s0, reason: collision with root package name */
    public final ArrayMap f98s0;

    /* JADX INFO: renamed from: t0, reason: collision with root package name */
    public final Object f99t0;
    public final Object u0;

    /* JADX INFO: renamed from: v0, reason: collision with root package name */
    public final Object f100v0;

    public h1(String camera, CameraCharacteristics cameraCharacteristics, b2 b2Var, Set cacheBlocklist) {
        kotlin.jvm.internal.q.g(camera, "camera");
        kotlin.jvm.internal.q.g(cacheBlocklist, "cacheBlocklist");
        this.f96e = camera;
        this.X = cameraCharacteristics;
        this.Y = b2Var;
        this.Z = cacheBlocklist;
        this.f97r0 = new ArrayMap();
        this.f98s0 = new ArrayMap();
        qi.g gVar = qi.g.f17354e;
        final int i10 = 0;
        this.f99t0 = g0.c.v(gVar, new ej.a(this) { // from class: a0.g1
            public final /* synthetic */ h1 X;

            {
                this.X = this;
            }

            @Override // ej.a
            public final Object invoke() {
                Set setE0;
                switch (i10) {
                    case 0:
                        h1 h1Var = this.X;
                        String cameraId = h1Var.f96e;
                        ri.u uVar = ri.u.f18052e;
                        try {
                            try {
                                Trace.beginSection("Camera-" + ((Object) z.p.b(cameraId)) + "#supportedExtensions");
                                b2 b2Var2 = h1Var.Y;
                                kotlin.jvm.internal.q.g(cameraId, "cameraId");
                                if (Build.VERSION.SDK_INT >= 31) {
                                    setE0 = ri.m.E0(g0.b(b2Var2.f(cameraId)));
                                    break;
                                } else {
                                    setE0 = uVar;
                                }
                                return setE0;
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e3) {
                            Log.w("CXCP", "Failed to getSupportedExtensions from Camera-" + ((Object) z.p.b(cameraId)), e3);
                            return uVar;
                        }
                    case 1:
                        h1 h1Var2 = this.X;
                        String str = h1Var2.f96e;
                        try {
                            try {
                                Trace.beginSection(((Object) z.p.b(str)) + "#keys");
                                List<CameraCharacteristics.Key<?>> keys = h1Var2.X.getKeys();
                                if (keys == null) {
                                    keys = ri.s.f18050e;
                                }
                                return ri.m.E0(keys);
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e10) {
                            Log.w("CXCP", "Failed to getKeys from " + ((Object) z.p.b(str)) + kotlinx.serialization.json.internal.b.END_OBJ, e10);
                            return ri.u.f18052e;
                        }
                    case 2:
                        h1 h1Var3 = this.X;
                        String str2 = h1Var3.f96e;
                        try {
                            try {
                                Trace.beginSection(((Object) z.p.b(str2)) + "#availableCaptureRequestKeys");
                                List<CaptureRequest.Key<?>> availableCaptureRequestKeys = h1Var3.X.getAvailableCaptureRequestKeys();
                                if (availableCaptureRequestKeys == null) {
                                    availableCaptureRequestKeys = ri.s.f18050e;
                                }
                                return ri.m.E0(availableCaptureRequestKeys);
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e11) {
                            Log.w("CXCP", "Failed to getAvailableCaptureRequestKeys from " + ((Object) z.p.b(str2)), e11);
                            return ri.u.f18052e;
                        }
                    case 3:
                        h1 h1Var4 = this.X;
                        String str3 = h1Var4.f96e;
                        try {
                            try {
                                Trace.beginSection(((Object) z.p.b(str3)) + "#availableCaptureResultKeys");
                                List<CaptureResult.Key<?>> availableCaptureResultKeys = h1Var4.X.getAvailableCaptureResultKeys();
                                if (availableCaptureResultKeys == null) {
                                    availableCaptureResultKeys = ri.s.f18050e;
                                }
                                return ri.m.E0(availableCaptureResultKeys);
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e12) {
                            Log.w("CXCP", "Failed to getAvailableCaptureResultKeys from " + ((Object) z.p.b(str3)), e12);
                            return ri.u.f18052e;
                        }
                    case 4:
                        h1 h1Var5 = this.X;
                        String str4 = h1Var5.f96e;
                        if (Build.VERSION.SDK_INT >= 28) {
                            try {
                                try {
                                    Trace.beginSection(((Object) z.p.b(str4)) + "#physicalCameraIds");
                                    Set<String> setE = c0.e(h1Var5.X);
                                    Log.i("CXCP", "Loaded physicalCameraIds from " + ((Object) z.p.b(str4)) + ": " + setE);
                                    ArrayList arrayList = new ArrayList(ri.o.S(setE, 10));
                                    for (String str5 : setE) {
                                        z.p.a(str5);
                                        arrayList.add(new z.p(str5));
                                    }
                                    return ri.m.E0(arrayList);
                                } finally {
                                    Trace.endSection();
                                }
                            } catch (AssertionError e13) {
                                Log.w("CXCP", "Failed to getPhysicalCameraIds from " + ((Object) z.p.b(str4)), e13);
                            } catch (NullPointerException e14) {
                                Log.w("CXCP", "Failed to getPhysicalCameraIds from " + ((Object) z.p.b(str4)), e14);
                            }
                        }
                        return ri.u.f18052e;
                    case 5:
                        h1 h1Var6 = this.X;
                        String str6 = h1Var6.f96e;
                        int i11 = Build.VERSION.SDK_INT;
                        ri.u uVar2 = ri.u.f18052e;
                        if (i11 < 28) {
                            return uVar2;
                        }
                        try {
                            try {
                                Trace.beginSection("Camera-" + str6 + "#availablePhysicalCameraRequestKeys");
                                Iterable iterableB = c0.b(h1Var6.X);
                                if (iterableB == null) {
                                    iterableB = ri.s.f18050e;
                                }
                                return ri.m.E0(iterableB);
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e15) {
                            Log.w("CXCP", "Failed to getAvailablePhysicalCameraRequestKeys from Camera-" + str6, e15);
                            return uVar2;
                        }
                    case 6:
                        h1 h1Var7 = this.X;
                        String str7 = h1Var7.f96e;
                        int i12 = Build.VERSION.SDK_INT;
                        ri.u uVar3 = ri.u.f18052e;
                        if (i12 < 35) {
                            return uVar3;
                        }
                        try {
                            try {
                                Trace.beginSection("Camera-" + str7 + "#getAvailableSessionCharacteristicsKeys");
                                Iterable iterableA = k0.a(h1Var7.X);
                                if (iterableA == null) {
                                    iterableA = ri.s.f18050e;
                                }
                                return ri.m.E0(iterableA);
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e16) {
                            Log.w("CXCP", "Failed to getAvailableSessionCharacteristicsKeys from Camera-" + str7, e16);
                            return uVar3;
                        }
                    default:
                        h1 h1Var8 = this.X;
                        String str8 = h1Var8.f96e;
                        int i13 = Build.VERSION.SDK_INT;
                        ri.u uVar4 = ri.u.f18052e;
                        if (i13 < 28) {
                            return uVar4;
                        }
                        try {
                            try {
                                Trace.beginSection("Camera-" + str8 + "#availableSessionKeys");
                                Iterable iterableC = c0.c(h1Var8.X);
                                if (iterableC == null) {
                                    iterableC = ri.s.f18050e;
                                }
                                return ri.m.E0(iterableC);
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e17) {
                            Log.w("CXCP", "Failed to getAvailableSessionKeys from Camera-" + str8, e17);
                            return uVar4;
                        }
                }
            }
        });
        final int i11 = 1;
        g0.c.v(gVar, new ej.a(this) { // from class: a0.g1
            public final /* synthetic */ h1 X;

            {
                this.X = this;
            }

            @Override // ej.a
            public final Object invoke() {
                Set setE0;
                switch (i11) {
                    case 0:
                        h1 h1Var = this.X;
                        String cameraId = h1Var.f96e;
                        ri.u uVar = ri.u.f18052e;
                        try {
                            try {
                                Trace.beginSection("Camera-" + ((Object) z.p.b(cameraId)) + "#supportedExtensions");
                                b2 b2Var2 = h1Var.Y;
                                kotlin.jvm.internal.q.g(cameraId, "cameraId");
                                if (Build.VERSION.SDK_INT >= 31) {
                                    setE0 = ri.m.E0(g0.b(b2Var2.f(cameraId)));
                                    break;
                                } else {
                                    setE0 = uVar;
                                }
                                return setE0;
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e3) {
                            Log.w("CXCP", "Failed to getSupportedExtensions from Camera-" + ((Object) z.p.b(cameraId)), e3);
                            return uVar;
                        }
                    case 1:
                        h1 h1Var2 = this.X;
                        String str = h1Var2.f96e;
                        try {
                            try {
                                Trace.beginSection(((Object) z.p.b(str)) + "#keys");
                                List<CameraCharacteristics.Key<?>> keys = h1Var2.X.getKeys();
                                if (keys == null) {
                                    keys = ri.s.f18050e;
                                }
                                return ri.m.E0(keys);
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e10) {
                            Log.w("CXCP", "Failed to getKeys from " + ((Object) z.p.b(str)) + kotlinx.serialization.json.internal.b.END_OBJ, e10);
                            return ri.u.f18052e;
                        }
                    case 2:
                        h1 h1Var3 = this.X;
                        String str2 = h1Var3.f96e;
                        try {
                            try {
                                Trace.beginSection(((Object) z.p.b(str2)) + "#availableCaptureRequestKeys");
                                List<CaptureRequest.Key<?>> availableCaptureRequestKeys = h1Var3.X.getAvailableCaptureRequestKeys();
                                if (availableCaptureRequestKeys == null) {
                                    availableCaptureRequestKeys = ri.s.f18050e;
                                }
                                return ri.m.E0(availableCaptureRequestKeys);
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e11) {
                            Log.w("CXCP", "Failed to getAvailableCaptureRequestKeys from " + ((Object) z.p.b(str2)), e11);
                            return ri.u.f18052e;
                        }
                    case 3:
                        h1 h1Var4 = this.X;
                        String str3 = h1Var4.f96e;
                        try {
                            try {
                                Trace.beginSection(((Object) z.p.b(str3)) + "#availableCaptureResultKeys");
                                List<CaptureResult.Key<?>> availableCaptureResultKeys = h1Var4.X.getAvailableCaptureResultKeys();
                                if (availableCaptureResultKeys == null) {
                                    availableCaptureResultKeys = ri.s.f18050e;
                                }
                                return ri.m.E0(availableCaptureResultKeys);
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e12) {
                            Log.w("CXCP", "Failed to getAvailableCaptureResultKeys from " + ((Object) z.p.b(str3)), e12);
                            return ri.u.f18052e;
                        }
                    case 4:
                        h1 h1Var5 = this.X;
                        String str4 = h1Var5.f96e;
                        if (Build.VERSION.SDK_INT >= 28) {
                            try {
                                try {
                                    Trace.beginSection(((Object) z.p.b(str4)) + "#physicalCameraIds");
                                    Set<String> setE = c0.e(h1Var5.X);
                                    Log.i("CXCP", "Loaded physicalCameraIds from " + ((Object) z.p.b(str4)) + ": " + setE);
                                    ArrayList arrayList = new ArrayList(ri.o.S(setE, 10));
                                    for (String str5 : setE) {
                                        z.p.a(str5);
                                        arrayList.add(new z.p(str5));
                                    }
                                    return ri.m.E0(arrayList);
                                } finally {
                                    Trace.endSection();
                                }
                            } catch (AssertionError e13) {
                                Log.w("CXCP", "Failed to getPhysicalCameraIds from " + ((Object) z.p.b(str4)), e13);
                            } catch (NullPointerException e14) {
                                Log.w("CXCP", "Failed to getPhysicalCameraIds from " + ((Object) z.p.b(str4)), e14);
                            }
                        }
                        return ri.u.f18052e;
                    case 5:
                        h1 h1Var6 = this.X;
                        String str6 = h1Var6.f96e;
                        int i12 = Build.VERSION.SDK_INT;
                        ri.u uVar2 = ri.u.f18052e;
                        if (i12 < 28) {
                            return uVar2;
                        }
                        try {
                            try {
                                Trace.beginSection("Camera-" + str6 + "#availablePhysicalCameraRequestKeys");
                                Iterable iterableB = c0.b(h1Var6.X);
                                if (iterableB == null) {
                                    iterableB = ri.s.f18050e;
                                }
                                return ri.m.E0(iterableB);
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e15) {
                            Log.w("CXCP", "Failed to getAvailablePhysicalCameraRequestKeys from Camera-" + str6, e15);
                            return uVar2;
                        }
                    case 6:
                        h1 h1Var7 = this.X;
                        String str7 = h1Var7.f96e;
                        int i13 = Build.VERSION.SDK_INT;
                        ri.u uVar3 = ri.u.f18052e;
                        if (i13 < 35) {
                            return uVar3;
                        }
                        try {
                            try {
                                Trace.beginSection("Camera-" + str7 + "#getAvailableSessionCharacteristicsKeys");
                                Iterable iterableA = k0.a(h1Var7.X);
                                if (iterableA == null) {
                                    iterableA = ri.s.f18050e;
                                }
                                return ri.m.E0(iterableA);
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e16) {
                            Log.w("CXCP", "Failed to getAvailableSessionCharacteristicsKeys from Camera-" + str7, e16);
                            return uVar3;
                        }
                    default:
                        h1 h1Var8 = this.X;
                        String str8 = h1Var8.f96e;
                        int i14 = Build.VERSION.SDK_INT;
                        ri.u uVar4 = ri.u.f18052e;
                        if (i14 < 28) {
                            return uVar4;
                        }
                        try {
                            try {
                                Trace.beginSection("Camera-" + str8 + "#availableSessionKeys");
                                Iterable iterableC = c0.c(h1Var8.X);
                                if (iterableC == null) {
                                    iterableC = ri.s.f18050e;
                                }
                                return ri.m.E0(iterableC);
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e17) {
                            Log.w("CXCP", "Failed to getAvailableSessionKeys from Camera-" + str8, e17);
                            return uVar4;
                        }
                }
            }
        });
        final int i12 = 2;
        g0.c.v(gVar, new ej.a(this) { // from class: a0.g1
            public final /* synthetic */ h1 X;

            {
                this.X = this;
            }

            @Override // ej.a
            public final Object invoke() {
                Set setE0;
                switch (i12) {
                    case 0:
                        h1 h1Var = this.X;
                        String cameraId = h1Var.f96e;
                        ri.u uVar = ri.u.f18052e;
                        try {
                            try {
                                Trace.beginSection("Camera-" + ((Object) z.p.b(cameraId)) + "#supportedExtensions");
                                b2 b2Var2 = h1Var.Y;
                                kotlin.jvm.internal.q.g(cameraId, "cameraId");
                                if (Build.VERSION.SDK_INT >= 31) {
                                    setE0 = ri.m.E0(g0.b(b2Var2.f(cameraId)));
                                    break;
                                } else {
                                    setE0 = uVar;
                                }
                                return setE0;
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e3) {
                            Log.w("CXCP", "Failed to getSupportedExtensions from Camera-" + ((Object) z.p.b(cameraId)), e3);
                            return uVar;
                        }
                    case 1:
                        h1 h1Var2 = this.X;
                        String str = h1Var2.f96e;
                        try {
                            try {
                                Trace.beginSection(((Object) z.p.b(str)) + "#keys");
                                List<CameraCharacteristics.Key<?>> keys = h1Var2.X.getKeys();
                                if (keys == null) {
                                    keys = ri.s.f18050e;
                                }
                                return ri.m.E0(keys);
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e10) {
                            Log.w("CXCP", "Failed to getKeys from " + ((Object) z.p.b(str)) + kotlinx.serialization.json.internal.b.END_OBJ, e10);
                            return ri.u.f18052e;
                        }
                    case 2:
                        h1 h1Var3 = this.X;
                        String str2 = h1Var3.f96e;
                        try {
                            try {
                                Trace.beginSection(((Object) z.p.b(str2)) + "#availableCaptureRequestKeys");
                                List<CaptureRequest.Key<?>> availableCaptureRequestKeys = h1Var3.X.getAvailableCaptureRequestKeys();
                                if (availableCaptureRequestKeys == null) {
                                    availableCaptureRequestKeys = ri.s.f18050e;
                                }
                                return ri.m.E0(availableCaptureRequestKeys);
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e11) {
                            Log.w("CXCP", "Failed to getAvailableCaptureRequestKeys from " + ((Object) z.p.b(str2)), e11);
                            return ri.u.f18052e;
                        }
                    case 3:
                        h1 h1Var4 = this.X;
                        String str3 = h1Var4.f96e;
                        try {
                            try {
                                Trace.beginSection(((Object) z.p.b(str3)) + "#availableCaptureResultKeys");
                                List<CaptureResult.Key<?>> availableCaptureResultKeys = h1Var4.X.getAvailableCaptureResultKeys();
                                if (availableCaptureResultKeys == null) {
                                    availableCaptureResultKeys = ri.s.f18050e;
                                }
                                return ri.m.E0(availableCaptureResultKeys);
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e12) {
                            Log.w("CXCP", "Failed to getAvailableCaptureResultKeys from " + ((Object) z.p.b(str3)), e12);
                            return ri.u.f18052e;
                        }
                    case 4:
                        h1 h1Var5 = this.X;
                        String str4 = h1Var5.f96e;
                        if (Build.VERSION.SDK_INT >= 28) {
                            try {
                                try {
                                    Trace.beginSection(((Object) z.p.b(str4)) + "#physicalCameraIds");
                                    Set<String> setE = c0.e(h1Var5.X);
                                    Log.i("CXCP", "Loaded physicalCameraIds from " + ((Object) z.p.b(str4)) + ": " + setE);
                                    ArrayList arrayList = new ArrayList(ri.o.S(setE, 10));
                                    for (String str5 : setE) {
                                        z.p.a(str5);
                                        arrayList.add(new z.p(str5));
                                    }
                                    return ri.m.E0(arrayList);
                                } finally {
                                    Trace.endSection();
                                }
                            } catch (AssertionError e13) {
                                Log.w("CXCP", "Failed to getPhysicalCameraIds from " + ((Object) z.p.b(str4)), e13);
                            } catch (NullPointerException e14) {
                                Log.w("CXCP", "Failed to getPhysicalCameraIds from " + ((Object) z.p.b(str4)), e14);
                            }
                        }
                        return ri.u.f18052e;
                    case 5:
                        h1 h1Var6 = this.X;
                        String str6 = h1Var6.f96e;
                        int i13 = Build.VERSION.SDK_INT;
                        ri.u uVar2 = ri.u.f18052e;
                        if (i13 < 28) {
                            return uVar2;
                        }
                        try {
                            try {
                                Trace.beginSection("Camera-" + str6 + "#availablePhysicalCameraRequestKeys");
                                Iterable iterableB = c0.b(h1Var6.X);
                                if (iterableB == null) {
                                    iterableB = ri.s.f18050e;
                                }
                                return ri.m.E0(iterableB);
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e15) {
                            Log.w("CXCP", "Failed to getAvailablePhysicalCameraRequestKeys from Camera-" + str6, e15);
                            return uVar2;
                        }
                    case 6:
                        h1 h1Var7 = this.X;
                        String str7 = h1Var7.f96e;
                        int i14 = Build.VERSION.SDK_INT;
                        ri.u uVar3 = ri.u.f18052e;
                        if (i14 < 35) {
                            return uVar3;
                        }
                        try {
                            try {
                                Trace.beginSection("Camera-" + str7 + "#getAvailableSessionCharacteristicsKeys");
                                Iterable iterableA = k0.a(h1Var7.X);
                                if (iterableA == null) {
                                    iterableA = ri.s.f18050e;
                                }
                                return ri.m.E0(iterableA);
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e16) {
                            Log.w("CXCP", "Failed to getAvailableSessionCharacteristicsKeys from Camera-" + str7, e16);
                            return uVar3;
                        }
                    default:
                        h1 h1Var8 = this.X;
                        String str8 = h1Var8.f96e;
                        int i15 = Build.VERSION.SDK_INT;
                        ri.u uVar4 = ri.u.f18052e;
                        if (i15 < 28) {
                            return uVar4;
                        }
                        try {
                            try {
                                Trace.beginSection("Camera-" + str8 + "#availableSessionKeys");
                                Iterable iterableC = c0.c(h1Var8.X);
                                if (iterableC == null) {
                                    iterableC = ri.s.f18050e;
                                }
                                return ri.m.E0(iterableC);
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e17) {
                            Log.w("CXCP", "Failed to getAvailableSessionKeys from Camera-" + str8, e17);
                            return uVar4;
                        }
                }
            }
        });
        final int i13 = 3;
        g0.c.v(gVar, new ej.a(this) { // from class: a0.g1
            public final /* synthetic */ h1 X;

            {
                this.X = this;
            }

            @Override // ej.a
            public final Object invoke() {
                Set setE0;
                switch (i13) {
                    case 0:
                        h1 h1Var = this.X;
                        String cameraId = h1Var.f96e;
                        ri.u uVar = ri.u.f18052e;
                        try {
                            try {
                                Trace.beginSection("Camera-" + ((Object) z.p.b(cameraId)) + "#supportedExtensions");
                                b2 b2Var2 = h1Var.Y;
                                kotlin.jvm.internal.q.g(cameraId, "cameraId");
                                if (Build.VERSION.SDK_INT >= 31) {
                                    setE0 = ri.m.E0(g0.b(b2Var2.f(cameraId)));
                                    break;
                                } else {
                                    setE0 = uVar;
                                }
                                return setE0;
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e3) {
                            Log.w("CXCP", "Failed to getSupportedExtensions from Camera-" + ((Object) z.p.b(cameraId)), e3);
                            return uVar;
                        }
                    case 1:
                        h1 h1Var2 = this.X;
                        String str = h1Var2.f96e;
                        try {
                            try {
                                Trace.beginSection(((Object) z.p.b(str)) + "#keys");
                                List<CameraCharacteristics.Key<?>> keys = h1Var2.X.getKeys();
                                if (keys == null) {
                                    keys = ri.s.f18050e;
                                }
                                return ri.m.E0(keys);
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e10) {
                            Log.w("CXCP", "Failed to getKeys from " + ((Object) z.p.b(str)) + kotlinx.serialization.json.internal.b.END_OBJ, e10);
                            return ri.u.f18052e;
                        }
                    case 2:
                        h1 h1Var3 = this.X;
                        String str2 = h1Var3.f96e;
                        try {
                            try {
                                Trace.beginSection(((Object) z.p.b(str2)) + "#availableCaptureRequestKeys");
                                List<CaptureRequest.Key<?>> availableCaptureRequestKeys = h1Var3.X.getAvailableCaptureRequestKeys();
                                if (availableCaptureRequestKeys == null) {
                                    availableCaptureRequestKeys = ri.s.f18050e;
                                }
                                return ri.m.E0(availableCaptureRequestKeys);
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e11) {
                            Log.w("CXCP", "Failed to getAvailableCaptureRequestKeys from " + ((Object) z.p.b(str2)), e11);
                            return ri.u.f18052e;
                        }
                    case 3:
                        h1 h1Var4 = this.X;
                        String str3 = h1Var4.f96e;
                        try {
                            try {
                                Trace.beginSection(((Object) z.p.b(str3)) + "#availableCaptureResultKeys");
                                List<CaptureResult.Key<?>> availableCaptureResultKeys = h1Var4.X.getAvailableCaptureResultKeys();
                                if (availableCaptureResultKeys == null) {
                                    availableCaptureResultKeys = ri.s.f18050e;
                                }
                                return ri.m.E0(availableCaptureResultKeys);
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e12) {
                            Log.w("CXCP", "Failed to getAvailableCaptureResultKeys from " + ((Object) z.p.b(str3)), e12);
                            return ri.u.f18052e;
                        }
                    case 4:
                        h1 h1Var5 = this.X;
                        String str4 = h1Var5.f96e;
                        if (Build.VERSION.SDK_INT >= 28) {
                            try {
                                try {
                                    Trace.beginSection(((Object) z.p.b(str4)) + "#physicalCameraIds");
                                    Set<String> setE = c0.e(h1Var5.X);
                                    Log.i("CXCP", "Loaded physicalCameraIds from " + ((Object) z.p.b(str4)) + ": " + setE);
                                    ArrayList arrayList = new ArrayList(ri.o.S(setE, 10));
                                    for (String str5 : setE) {
                                        z.p.a(str5);
                                        arrayList.add(new z.p(str5));
                                    }
                                    return ri.m.E0(arrayList);
                                } finally {
                                    Trace.endSection();
                                }
                            } catch (AssertionError e13) {
                                Log.w("CXCP", "Failed to getPhysicalCameraIds from " + ((Object) z.p.b(str4)), e13);
                            } catch (NullPointerException e14) {
                                Log.w("CXCP", "Failed to getPhysicalCameraIds from " + ((Object) z.p.b(str4)), e14);
                            }
                        }
                        return ri.u.f18052e;
                    case 5:
                        h1 h1Var6 = this.X;
                        String str6 = h1Var6.f96e;
                        int i14 = Build.VERSION.SDK_INT;
                        ri.u uVar2 = ri.u.f18052e;
                        if (i14 < 28) {
                            return uVar2;
                        }
                        try {
                            try {
                                Trace.beginSection("Camera-" + str6 + "#availablePhysicalCameraRequestKeys");
                                Iterable iterableB = c0.b(h1Var6.X);
                                if (iterableB == null) {
                                    iterableB = ri.s.f18050e;
                                }
                                return ri.m.E0(iterableB);
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e15) {
                            Log.w("CXCP", "Failed to getAvailablePhysicalCameraRequestKeys from Camera-" + str6, e15);
                            return uVar2;
                        }
                    case 6:
                        h1 h1Var7 = this.X;
                        String str7 = h1Var7.f96e;
                        int i15 = Build.VERSION.SDK_INT;
                        ri.u uVar3 = ri.u.f18052e;
                        if (i15 < 35) {
                            return uVar3;
                        }
                        try {
                            try {
                                Trace.beginSection("Camera-" + str7 + "#getAvailableSessionCharacteristicsKeys");
                                Iterable iterableA = k0.a(h1Var7.X);
                                if (iterableA == null) {
                                    iterableA = ri.s.f18050e;
                                }
                                return ri.m.E0(iterableA);
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e16) {
                            Log.w("CXCP", "Failed to getAvailableSessionCharacteristicsKeys from Camera-" + str7, e16);
                            return uVar3;
                        }
                    default:
                        h1 h1Var8 = this.X;
                        String str8 = h1Var8.f96e;
                        int i16 = Build.VERSION.SDK_INT;
                        ri.u uVar4 = ri.u.f18052e;
                        if (i16 < 28) {
                            return uVar4;
                        }
                        try {
                            try {
                                Trace.beginSection("Camera-" + str8 + "#availableSessionKeys");
                                Iterable iterableC = c0.c(h1Var8.X);
                                if (iterableC == null) {
                                    iterableC = ri.s.f18050e;
                                }
                                return ri.m.E0(iterableC);
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e17) {
                            Log.w("CXCP", "Failed to getAvailableSessionKeys from Camera-" + str8, e17);
                            return uVar4;
                        }
                }
            }
        });
        final int i14 = 4;
        this.u0 = g0.c.v(gVar, new ej.a(this) { // from class: a0.g1
            public final /* synthetic */ h1 X;

            {
                this.X = this;
            }

            @Override // ej.a
            public final Object invoke() {
                Set setE0;
                switch (i14) {
                    case 0:
                        h1 h1Var = this.X;
                        String cameraId = h1Var.f96e;
                        ri.u uVar = ri.u.f18052e;
                        try {
                            try {
                                Trace.beginSection("Camera-" + ((Object) z.p.b(cameraId)) + "#supportedExtensions");
                                b2 b2Var2 = h1Var.Y;
                                kotlin.jvm.internal.q.g(cameraId, "cameraId");
                                if (Build.VERSION.SDK_INT >= 31) {
                                    setE0 = ri.m.E0(g0.b(b2Var2.f(cameraId)));
                                    break;
                                } else {
                                    setE0 = uVar;
                                }
                                return setE0;
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e3) {
                            Log.w("CXCP", "Failed to getSupportedExtensions from Camera-" + ((Object) z.p.b(cameraId)), e3);
                            return uVar;
                        }
                    case 1:
                        h1 h1Var2 = this.X;
                        String str = h1Var2.f96e;
                        try {
                            try {
                                Trace.beginSection(((Object) z.p.b(str)) + "#keys");
                                List<CameraCharacteristics.Key<?>> keys = h1Var2.X.getKeys();
                                if (keys == null) {
                                    keys = ri.s.f18050e;
                                }
                                return ri.m.E0(keys);
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e10) {
                            Log.w("CXCP", "Failed to getKeys from " + ((Object) z.p.b(str)) + kotlinx.serialization.json.internal.b.END_OBJ, e10);
                            return ri.u.f18052e;
                        }
                    case 2:
                        h1 h1Var3 = this.X;
                        String str2 = h1Var3.f96e;
                        try {
                            try {
                                Trace.beginSection(((Object) z.p.b(str2)) + "#availableCaptureRequestKeys");
                                List<CaptureRequest.Key<?>> availableCaptureRequestKeys = h1Var3.X.getAvailableCaptureRequestKeys();
                                if (availableCaptureRequestKeys == null) {
                                    availableCaptureRequestKeys = ri.s.f18050e;
                                }
                                return ri.m.E0(availableCaptureRequestKeys);
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e11) {
                            Log.w("CXCP", "Failed to getAvailableCaptureRequestKeys from " + ((Object) z.p.b(str2)), e11);
                            return ri.u.f18052e;
                        }
                    case 3:
                        h1 h1Var4 = this.X;
                        String str3 = h1Var4.f96e;
                        try {
                            try {
                                Trace.beginSection(((Object) z.p.b(str3)) + "#availableCaptureResultKeys");
                                List<CaptureResult.Key<?>> availableCaptureResultKeys = h1Var4.X.getAvailableCaptureResultKeys();
                                if (availableCaptureResultKeys == null) {
                                    availableCaptureResultKeys = ri.s.f18050e;
                                }
                                return ri.m.E0(availableCaptureResultKeys);
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e12) {
                            Log.w("CXCP", "Failed to getAvailableCaptureResultKeys from " + ((Object) z.p.b(str3)), e12);
                            return ri.u.f18052e;
                        }
                    case 4:
                        h1 h1Var5 = this.X;
                        String str4 = h1Var5.f96e;
                        if (Build.VERSION.SDK_INT >= 28) {
                            try {
                                try {
                                    Trace.beginSection(((Object) z.p.b(str4)) + "#physicalCameraIds");
                                    Set<String> setE = c0.e(h1Var5.X);
                                    Log.i("CXCP", "Loaded physicalCameraIds from " + ((Object) z.p.b(str4)) + ": " + setE);
                                    ArrayList arrayList = new ArrayList(ri.o.S(setE, 10));
                                    for (String str5 : setE) {
                                        z.p.a(str5);
                                        arrayList.add(new z.p(str5));
                                    }
                                    return ri.m.E0(arrayList);
                                } finally {
                                    Trace.endSection();
                                }
                            } catch (AssertionError e13) {
                                Log.w("CXCP", "Failed to getPhysicalCameraIds from " + ((Object) z.p.b(str4)), e13);
                            } catch (NullPointerException e14) {
                                Log.w("CXCP", "Failed to getPhysicalCameraIds from " + ((Object) z.p.b(str4)), e14);
                            }
                        }
                        return ri.u.f18052e;
                    case 5:
                        h1 h1Var6 = this.X;
                        String str6 = h1Var6.f96e;
                        int i15 = Build.VERSION.SDK_INT;
                        ri.u uVar2 = ri.u.f18052e;
                        if (i15 < 28) {
                            return uVar2;
                        }
                        try {
                            try {
                                Trace.beginSection("Camera-" + str6 + "#availablePhysicalCameraRequestKeys");
                                Iterable iterableB = c0.b(h1Var6.X);
                                if (iterableB == null) {
                                    iterableB = ri.s.f18050e;
                                }
                                return ri.m.E0(iterableB);
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e15) {
                            Log.w("CXCP", "Failed to getAvailablePhysicalCameraRequestKeys from Camera-" + str6, e15);
                            return uVar2;
                        }
                    case 6:
                        h1 h1Var7 = this.X;
                        String str7 = h1Var7.f96e;
                        int i16 = Build.VERSION.SDK_INT;
                        ri.u uVar3 = ri.u.f18052e;
                        if (i16 < 35) {
                            return uVar3;
                        }
                        try {
                            try {
                                Trace.beginSection("Camera-" + str7 + "#getAvailableSessionCharacteristicsKeys");
                                Iterable iterableA = k0.a(h1Var7.X);
                                if (iterableA == null) {
                                    iterableA = ri.s.f18050e;
                                }
                                return ri.m.E0(iterableA);
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e16) {
                            Log.w("CXCP", "Failed to getAvailableSessionCharacteristicsKeys from Camera-" + str7, e16);
                            return uVar3;
                        }
                    default:
                        h1 h1Var8 = this.X;
                        String str8 = h1Var8.f96e;
                        int i17 = Build.VERSION.SDK_INT;
                        ri.u uVar4 = ri.u.f18052e;
                        if (i17 < 28) {
                            return uVar4;
                        }
                        try {
                            try {
                                Trace.beginSection("Camera-" + str8 + "#availableSessionKeys");
                                Iterable iterableC = c0.c(h1Var8.X);
                                if (iterableC == null) {
                                    iterableC = ri.s.f18050e;
                                }
                                return ri.m.E0(iterableC);
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e17) {
                            Log.w("CXCP", "Failed to getAvailableSessionKeys from Camera-" + str8, e17);
                            return uVar4;
                        }
                }
            }
        });
        final int i15 = 5;
        g0.c.v(gVar, new ej.a(this) { // from class: a0.g1
            public final /* synthetic */ h1 X;

            {
                this.X = this;
            }

            @Override // ej.a
            public final Object invoke() {
                Set setE0;
                switch (i15) {
                    case 0:
                        h1 h1Var = this.X;
                        String cameraId = h1Var.f96e;
                        ri.u uVar = ri.u.f18052e;
                        try {
                            try {
                                Trace.beginSection("Camera-" + ((Object) z.p.b(cameraId)) + "#supportedExtensions");
                                b2 b2Var2 = h1Var.Y;
                                kotlin.jvm.internal.q.g(cameraId, "cameraId");
                                if (Build.VERSION.SDK_INT >= 31) {
                                    setE0 = ri.m.E0(g0.b(b2Var2.f(cameraId)));
                                    break;
                                } else {
                                    setE0 = uVar;
                                }
                                return setE0;
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e3) {
                            Log.w("CXCP", "Failed to getSupportedExtensions from Camera-" + ((Object) z.p.b(cameraId)), e3);
                            return uVar;
                        }
                    case 1:
                        h1 h1Var2 = this.X;
                        String str = h1Var2.f96e;
                        try {
                            try {
                                Trace.beginSection(((Object) z.p.b(str)) + "#keys");
                                List<CameraCharacteristics.Key<?>> keys = h1Var2.X.getKeys();
                                if (keys == null) {
                                    keys = ri.s.f18050e;
                                }
                                return ri.m.E0(keys);
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e10) {
                            Log.w("CXCP", "Failed to getKeys from " + ((Object) z.p.b(str)) + kotlinx.serialization.json.internal.b.END_OBJ, e10);
                            return ri.u.f18052e;
                        }
                    case 2:
                        h1 h1Var3 = this.X;
                        String str2 = h1Var3.f96e;
                        try {
                            try {
                                Trace.beginSection(((Object) z.p.b(str2)) + "#availableCaptureRequestKeys");
                                List<CaptureRequest.Key<?>> availableCaptureRequestKeys = h1Var3.X.getAvailableCaptureRequestKeys();
                                if (availableCaptureRequestKeys == null) {
                                    availableCaptureRequestKeys = ri.s.f18050e;
                                }
                                return ri.m.E0(availableCaptureRequestKeys);
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e11) {
                            Log.w("CXCP", "Failed to getAvailableCaptureRequestKeys from " + ((Object) z.p.b(str2)), e11);
                            return ri.u.f18052e;
                        }
                    case 3:
                        h1 h1Var4 = this.X;
                        String str3 = h1Var4.f96e;
                        try {
                            try {
                                Trace.beginSection(((Object) z.p.b(str3)) + "#availableCaptureResultKeys");
                                List<CaptureResult.Key<?>> availableCaptureResultKeys = h1Var4.X.getAvailableCaptureResultKeys();
                                if (availableCaptureResultKeys == null) {
                                    availableCaptureResultKeys = ri.s.f18050e;
                                }
                                return ri.m.E0(availableCaptureResultKeys);
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e12) {
                            Log.w("CXCP", "Failed to getAvailableCaptureResultKeys from " + ((Object) z.p.b(str3)), e12);
                            return ri.u.f18052e;
                        }
                    case 4:
                        h1 h1Var5 = this.X;
                        String str4 = h1Var5.f96e;
                        if (Build.VERSION.SDK_INT >= 28) {
                            try {
                                try {
                                    Trace.beginSection(((Object) z.p.b(str4)) + "#physicalCameraIds");
                                    Set<String> setE = c0.e(h1Var5.X);
                                    Log.i("CXCP", "Loaded physicalCameraIds from " + ((Object) z.p.b(str4)) + ": " + setE);
                                    ArrayList arrayList = new ArrayList(ri.o.S(setE, 10));
                                    for (String str5 : setE) {
                                        z.p.a(str5);
                                        arrayList.add(new z.p(str5));
                                    }
                                    return ri.m.E0(arrayList);
                                } finally {
                                    Trace.endSection();
                                }
                            } catch (AssertionError e13) {
                                Log.w("CXCP", "Failed to getPhysicalCameraIds from " + ((Object) z.p.b(str4)), e13);
                            } catch (NullPointerException e14) {
                                Log.w("CXCP", "Failed to getPhysicalCameraIds from " + ((Object) z.p.b(str4)), e14);
                            }
                        }
                        return ri.u.f18052e;
                    case 5:
                        h1 h1Var6 = this.X;
                        String str6 = h1Var6.f96e;
                        int i16 = Build.VERSION.SDK_INT;
                        ri.u uVar2 = ri.u.f18052e;
                        if (i16 < 28) {
                            return uVar2;
                        }
                        try {
                            try {
                                Trace.beginSection("Camera-" + str6 + "#availablePhysicalCameraRequestKeys");
                                Iterable iterableB = c0.b(h1Var6.X);
                                if (iterableB == null) {
                                    iterableB = ri.s.f18050e;
                                }
                                return ri.m.E0(iterableB);
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e15) {
                            Log.w("CXCP", "Failed to getAvailablePhysicalCameraRequestKeys from Camera-" + str6, e15);
                            return uVar2;
                        }
                    case 6:
                        h1 h1Var7 = this.X;
                        String str7 = h1Var7.f96e;
                        int i17 = Build.VERSION.SDK_INT;
                        ri.u uVar3 = ri.u.f18052e;
                        if (i17 < 35) {
                            return uVar3;
                        }
                        try {
                            try {
                                Trace.beginSection("Camera-" + str7 + "#getAvailableSessionCharacteristicsKeys");
                                Iterable iterableA = k0.a(h1Var7.X);
                                if (iterableA == null) {
                                    iterableA = ri.s.f18050e;
                                }
                                return ri.m.E0(iterableA);
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e16) {
                            Log.w("CXCP", "Failed to getAvailableSessionCharacteristicsKeys from Camera-" + str7, e16);
                            return uVar3;
                        }
                    default:
                        h1 h1Var8 = this.X;
                        String str8 = h1Var8.f96e;
                        int i18 = Build.VERSION.SDK_INT;
                        ri.u uVar4 = ri.u.f18052e;
                        if (i18 < 28) {
                            return uVar4;
                        }
                        try {
                            try {
                                Trace.beginSection("Camera-" + str8 + "#availableSessionKeys");
                                Iterable iterableC = c0.c(h1Var8.X);
                                if (iterableC == null) {
                                    iterableC = ri.s.f18050e;
                                }
                                return ri.m.E0(iterableC);
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e17) {
                            Log.w("CXCP", "Failed to getAvailableSessionKeys from Camera-" + str8, e17);
                            return uVar4;
                        }
                }
            }
        });
        final int i16 = 6;
        g0.c.v(gVar, new ej.a(this) { // from class: a0.g1
            public final /* synthetic */ h1 X;

            {
                this.X = this;
            }

            @Override // ej.a
            public final Object invoke() {
                Set setE0;
                switch (i16) {
                    case 0:
                        h1 h1Var = this.X;
                        String cameraId = h1Var.f96e;
                        ri.u uVar = ri.u.f18052e;
                        try {
                            try {
                                Trace.beginSection("Camera-" + ((Object) z.p.b(cameraId)) + "#supportedExtensions");
                                b2 b2Var2 = h1Var.Y;
                                kotlin.jvm.internal.q.g(cameraId, "cameraId");
                                if (Build.VERSION.SDK_INT >= 31) {
                                    setE0 = ri.m.E0(g0.b(b2Var2.f(cameraId)));
                                    break;
                                } else {
                                    setE0 = uVar;
                                }
                                return setE0;
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e3) {
                            Log.w("CXCP", "Failed to getSupportedExtensions from Camera-" + ((Object) z.p.b(cameraId)), e3);
                            return uVar;
                        }
                    case 1:
                        h1 h1Var2 = this.X;
                        String str = h1Var2.f96e;
                        try {
                            try {
                                Trace.beginSection(((Object) z.p.b(str)) + "#keys");
                                List<CameraCharacteristics.Key<?>> keys = h1Var2.X.getKeys();
                                if (keys == null) {
                                    keys = ri.s.f18050e;
                                }
                                return ri.m.E0(keys);
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e10) {
                            Log.w("CXCP", "Failed to getKeys from " + ((Object) z.p.b(str)) + kotlinx.serialization.json.internal.b.END_OBJ, e10);
                            return ri.u.f18052e;
                        }
                    case 2:
                        h1 h1Var3 = this.X;
                        String str2 = h1Var3.f96e;
                        try {
                            try {
                                Trace.beginSection(((Object) z.p.b(str2)) + "#availableCaptureRequestKeys");
                                List<CaptureRequest.Key<?>> availableCaptureRequestKeys = h1Var3.X.getAvailableCaptureRequestKeys();
                                if (availableCaptureRequestKeys == null) {
                                    availableCaptureRequestKeys = ri.s.f18050e;
                                }
                                return ri.m.E0(availableCaptureRequestKeys);
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e11) {
                            Log.w("CXCP", "Failed to getAvailableCaptureRequestKeys from " + ((Object) z.p.b(str2)), e11);
                            return ri.u.f18052e;
                        }
                    case 3:
                        h1 h1Var4 = this.X;
                        String str3 = h1Var4.f96e;
                        try {
                            try {
                                Trace.beginSection(((Object) z.p.b(str3)) + "#availableCaptureResultKeys");
                                List<CaptureResult.Key<?>> availableCaptureResultKeys = h1Var4.X.getAvailableCaptureResultKeys();
                                if (availableCaptureResultKeys == null) {
                                    availableCaptureResultKeys = ri.s.f18050e;
                                }
                                return ri.m.E0(availableCaptureResultKeys);
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e12) {
                            Log.w("CXCP", "Failed to getAvailableCaptureResultKeys from " + ((Object) z.p.b(str3)), e12);
                            return ri.u.f18052e;
                        }
                    case 4:
                        h1 h1Var5 = this.X;
                        String str4 = h1Var5.f96e;
                        if (Build.VERSION.SDK_INT >= 28) {
                            try {
                                try {
                                    Trace.beginSection(((Object) z.p.b(str4)) + "#physicalCameraIds");
                                    Set<String> setE = c0.e(h1Var5.X);
                                    Log.i("CXCP", "Loaded physicalCameraIds from " + ((Object) z.p.b(str4)) + ": " + setE);
                                    ArrayList arrayList = new ArrayList(ri.o.S(setE, 10));
                                    for (String str5 : setE) {
                                        z.p.a(str5);
                                        arrayList.add(new z.p(str5));
                                    }
                                    return ri.m.E0(arrayList);
                                } finally {
                                    Trace.endSection();
                                }
                            } catch (AssertionError e13) {
                                Log.w("CXCP", "Failed to getPhysicalCameraIds from " + ((Object) z.p.b(str4)), e13);
                            } catch (NullPointerException e14) {
                                Log.w("CXCP", "Failed to getPhysicalCameraIds from " + ((Object) z.p.b(str4)), e14);
                            }
                        }
                        return ri.u.f18052e;
                    case 5:
                        h1 h1Var6 = this.X;
                        String str6 = h1Var6.f96e;
                        int i17 = Build.VERSION.SDK_INT;
                        ri.u uVar2 = ri.u.f18052e;
                        if (i17 < 28) {
                            return uVar2;
                        }
                        try {
                            try {
                                Trace.beginSection("Camera-" + str6 + "#availablePhysicalCameraRequestKeys");
                                Iterable iterableB = c0.b(h1Var6.X);
                                if (iterableB == null) {
                                    iterableB = ri.s.f18050e;
                                }
                                return ri.m.E0(iterableB);
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e15) {
                            Log.w("CXCP", "Failed to getAvailablePhysicalCameraRequestKeys from Camera-" + str6, e15);
                            return uVar2;
                        }
                    case 6:
                        h1 h1Var7 = this.X;
                        String str7 = h1Var7.f96e;
                        int i18 = Build.VERSION.SDK_INT;
                        ri.u uVar3 = ri.u.f18052e;
                        if (i18 < 35) {
                            return uVar3;
                        }
                        try {
                            try {
                                Trace.beginSection("Camera-" + str7 + "#getAvailableSessionCharacteristicsKeys");
                                Iterable iterableA = k0.a(h1Var7.X);
                                if (iterableA == null) {
                                    iterableA = ri.s.f18050e;
                                }
                                return ri.m.E0(iterableA);
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e16) {
                            Log.w("CXCP", "Failed to getAvailableSessionCharacteristicsKeys from Camera-" + str7, e16);
                            return uVar3;
                        }
                    default:
                        h1 h1Var8 = this.X;
                        String str8 = h1Var8.f96e;
                        int i19 = Build.VERSION.SDK_INT;
                        ri.u uVar4 = ri.u.f18052e;
                        if (i19 < 28) {
                            return uVar4;
                        }
                        try {
                            try {
                                Trace.beginSection("Camera-" + str8 + "#availableSessionKeys");
                                Iterable iterableC = c0.c(h1Var8.X);
                                if (iterableC == null) {
                                    iterableC = ri.s.f18050e;
                                }
                                return ri.m.E0(iterableC);
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e17) {
                            Log.w("CXCP", "Failed to getAvailableSessionKeys from Camera-" + str8, e17);
                            return uVar4;
                        }
                }
            }
        });
        final int i17 = 7;
        this.f100v0 = g0.c.v(gVar, new ej.a(this) { // from class: a0.g1
            public final /* synthetic */ h1 X;

            {
                this.X = this;
            }

            @Override // ej.a
            public final Object invoke() {
                Set setE0;
                switch (i17) {
                    case 0:
                        h1 h1Var = this.X;
                        String cameraId = h1Var.f96e;
                        ri.u uVar = ri.u.f18052e;
                        try {
                            try {
                                Trace.beginSection("Camera-" + ((Object) z.p.b(cameraId)) + "#supportedExtensions");
                                b2 b2Var2 = h1Var.Y;
                                kotlin.jvm.internal.q.g(cameraId, "cameraId");
                                if (Build.VERSION.SDK_INT >= 31) {
                                    setE0 = ri.m.E0(g0.b(b2Var2.f(cameraId)));
                                    break;
                                } else {
                                    setE0 = uVar;
                                }
                                return setE0;
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e3) {
                            Log.w("CXCP", "Failed to getSupportedExtensions from Camera-" + ((Object) z.p.b(cameraId)), e3);
                            return uVar;
                        }
                    case 1:
                        h1 h1Var2 = this.X;
                        String str = h1Var2.f96e;
                        try {
                            try {
                                Trace.beginSection(((Object) z.p.b(str)) + "#keys");
                                List<CameraCharacteristics.Key<?>> keys = h1Var2.X.getKeys();
                                if (keys == null) {
                                    keys = ri.s.f18050e;
                                }
                                return ri.m.E0(keys);
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e10) {
                            Log.w("CXCP", "Failed to getKeys from " + ((Object) z.p.b(str)) + kotlinx.serialization.json.internal.b.END_OBJ, e10);
                            return ri.u.f18052e;
                        }
                    case 2:
                        h1 h1Var3 = this.X;
                        String str2 = h1Var3.f96e;
                        try {
                            try {
                                Trace.beginSection(((Object) z.p.b(str2)) + "#availableCaptureRequestKeys");
                                List<CaptureRequest.Key<?>> availableCaptureRequestKeys = h1Var3.X.getAvailableCaptureRequestKeys();
                                if (availableCaptureRequestKeys == null) {
                                    availableCaptureRequestKeys = ri.s.f18050e;
                                }
                                return ri.m.E0(availableCaptureRequestKeys);
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e11) {
                            Log.w("CXCP", "Failed to getAvailableCaptureRequestKeys from " + ((Object) z.p.b(str2)), e11);
                            return ri.u.f18052e;
                        }
                    case 3:
                        h1 h1Var4 = this.X;
                        String str3 = h1Var4.f96e;
                        try {
                            try {
                                Trace.beginSection(((Object) z.p.b(str3)) + "#availableCaptureResultKeys");
                                List<CaptureResult.Key<?>> availableCaptureResultKeys = h1Var4.X.getAvailableCaptureResultKeys();
                                if (availableCaptureResultKeys == null) {
                                    availableCaptureResultKeys = ri.s.f18050e;
                                }
                                return ri.m.E0(availableCaptureResultKeys);
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e12) {
                            Log.w("CXCP", "Failed to getAvailableCaptureResultKeys from " + ((Object) z.p.b(str3)), e12);
                            return ri.u.f18052e;
                        }
                    case 4:
                        h1 h1Var5 = this.X;
                        String str4 = h1Var5.f96e;
                        if (Build.VERSION.SDK_INT >= 28) {
                            try {
                                try {
                                    Trace.beginSection(((Object) z.p.b(str4)) + "#physicalCameraIds");
                                    Set<String> setE = c0.e(h1Var5.X);
                                    Log.i("CXCP", "Loaded physicalCameraIds from " + ((Object) z.p.b(str4)) + ": " + setE);
                                    ArrayList arrayList = new ArrayList(ri.o.S(setE, 10));
                                    for (String str5 : setE) {
                                        z.p.a(str5);
                                        arrayList.add(new z.p(str5));
                                    }
                                    return ri.m.E0(arrayList);
                                } finally {
                                    Trace.endSection();
                                }
                            } catch (AssertionError e13) {
                                Log.w("CXCP", "Failed to getPhysicalCameraIds from " + ((Object) z.p.b(str4)), e13);
                            } catch (NullPointerException e14) {
                                Log.w("CXCP", "Failed to getPhysicalCameraIds from " + ((Object) z.p.b(str4)), e14);
                            }
                        }
                        return ri.u.f18052e;
                    case 5:
                        h1 h1Var6 = this.X;
                        String str6 = h1Var6.f96e;
                        int i18 = Build.VERSION.SDK_INT;
                        ri.u uVar2 = ri.u.f18052e;
                        if (i18 < 28) {
                            return uVar2;
                        }
                        try {
                            try {
                                Trace.beginSection("Camera-" + str6 + "#availablePhysicalCameraRequestKeys");
                                Iterable iterableB = c0.b(h1Var6.X);
                                if (iterableB == null) {
                                    iterableB = ri.s.f18050e;
                                }
                                return ri.m.E0(iterableB);
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e15) {
                            Log.w("CXCP", "Failed to getAvailablePhysicalCameraRequestKeys from Camera-" + str6, e15);
                            return uVar2;
                        }
                    case 6:
                        h1 h1Var7 = this.X;
                        String str7 = h1Var7.f96e;
                        int i19 = Build.VERSION.SDK_INT;
                        ri.u uVar3 = ri.u.f18052e;
                        if (i19 < 35) {
                            return uVar3;
                        }
                        try {
                            try {
                                Trace.beginSection("Camera-" + str7 + "#getAvailableSessionCharacteristicsKeys");
                                Iterable iterableA = k0.a(h1Var7.X);
                                if (iterableA == null) {
                                    iterableA = ri.s.f18050e;
                                }
                                return ri.m.E0(iterableA);
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e16) {
                            Log.w("CXCP", "Failed to getAvailableSessionCharacteristicsKeys from Camera-" + str7, e16);
                            return uVar3;
                        }
                    default:
                        h1 h1Var8 = this.X;
                        String str8 = h1Var8.f96e;
                        int i110 = Build.VERSION.SDK_INT;
                        ri.u uVar4 = ri.u.f18052e;
                        if (i110 < 28) {
                            return uVar4;
                        }
                        try {
                            try {
                                Trace.beginSection("Camera-" + str8 + "#availableSessionKeys");
                                Iterable iterableC = c0.c(h1Var8.X);
                                if (iterableC == null) {
                                    iterableC = ri.s.f18050e;
                                }
                                return ri.m.E0(iterableC);
                            } finally {
                                Trace.endSection();
                            }
                        } catch (AssertionError e17) {
                            Log.w("CXCP", "Failed to getAvailableSessionKeys from Camera-" + str8, e17);
                            return uVar4;
                        }
                }
            }
        });
    }

    @Override // z.o1
    public final Object D(kotlin.jvm.internal.h hVar) {
        if (hVar.equals(kotlin.jvm.internal.e0.a(CameraCharacteristics.class))) {
            return this.X;
        }
        return null;
    }

    public final Object c(CameraCharacteristics.Key key) {
        Object obj;
        if (this.Z.contains(key)) {
            try {
                return this.X.get(key);
            } catch (AssertionError unused) {
                throw new IllegalStateException("Failed to get characteristic for " + key + ": Framework throw an AssertionError");
            }
        }
        synchronized (this.f97r0) {
            obj = this.f97r0.get(key);
        }
        if (obj != null) {
            return obj;
        }
        try {
            Object obj2 = this.X.get(key);
            if (obj2 == null) {
                return obj2;
            }
            synchronized (this.f97r0) {
                this.f97r0.put(key, obj2);
            }
            return obj2;
        } catch (AssertionError unused2) {
            throw new IllegalStateException("Failed to get characteristic for " + key + ": Framework throw an AssertionError");
        }
    }
}
