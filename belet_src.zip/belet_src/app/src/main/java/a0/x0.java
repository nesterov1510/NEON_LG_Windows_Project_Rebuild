package a0;

import java.util.concurrent.CopyOnWriteArrayList;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class x0 implements AutoCloseable {
    public final CopyOnWriteArrayList X;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final kotlinx.coroutines.p0 f377e;

    public x0(ge.q qVar, String str) {
        kotlinx.coroutines.p0 p0VarCoroutineScope = kotlinx.coroutines.q0.CoroutineScope(((c0.n) qVar.f8936b).f3844d.plus(kotlinx.coroutines.d3.SupervisorJob((kotlinx.coroutines.f2) qVar.f8937c)));
        this.f377e = p0VarCoroutineScope;
        this.X = new CopyOnWriteArrayList();
        kotlinx.coroutines.k.launch$default(p0VarCoroutineScope, null, null, new q0(qVar, str, this, null, 1), 3, null);
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    public final Object a(long j10, wi.c cVar) {
        v0 v0Var;
        kotlinx.coroutines.z zVar;
        if (cVar instanceof v0) {
            v0Var = (v0) cVar;
            int i10 = v0Var.Z;
            if ((i10 & Integer.MIN_VALUE) != 0) {
                v0Var.Z = i10 - Integer.MIN_VALUE;
            } else {
                v0Var = new v0(this, cVar);
            }
        } else {
            v0Var = new v0(this, cVar);
        }
        Object objWithTimeoutOrNull = v0Var.X;
        vi.a aVar = vi.a.f21252e;
        int i11 = v0Var.Z;
        CopyOnWriteArrayList copyOnWriteArrayList = this.X;
        if (i11 == 0) {
            g6.y.I(objWithTimeoutOrNull);
            kotlinx.coroutines.z zVarCompletableDeferred$default = kotlinx.coroutines.b0.CompletableDeferred$default(null, 1, null);
            copyOnWriteArrayList.add(zVarCompletableDeferred$default);
            w0 w0Var = new w0(zVarCompletableDeferred$default, null, 0);
            v0Var.f359e = zVarCompletableDeferred$default;
            v0Var.Z = 1;
            objWithTimeoutOrNull = kotlinx.coroutines.l3.withTimeoutOrNull(j10, w0Var, v0Var);
            if (objWithTimeoutOrNull == aVar) {
                return aVar;
            }
            zVar = zVarCompletableDeferred$default;
        } else {
            if (i11 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            zVar = v0Var.f359e;
            g6.y.I(objWithTimeoutOrNull);
        }
        boolean z5 = objWithTimeoutOrNull != null;
        copyOnWriteArrayList.remove(zVar);
        return Boolean.valueOf(z5);
    }

    @Override // java.lang.AutoCloseable
    public final void close() {
        kotlinx.coroutines.q0.cancel$default(this.f377e, null, 1, null);
    }
}
