package a0;

import android.graphics.SurfaceTexture;
import android.media.MediaCodec;
import android.media.MediaRecorder;
import android.os.Build;
import android.util.Log;
import android.util.Size;
import android.view.Surface;
import android.view.SurfaceHolder;
import java.util.Iterator;
import java.util.List;
import okhttp3.internal.connection.RealConnection;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class x2 implements z2 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final x2 f381a = new x2();

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v0, types: [android.view.Surface] */
    /* JADX WARN: Type inference failed for: r1v12, types: [android.hardware.camera2.params.OutputConfiguration] */
    /* JADX WARN: Type inference failed for: r1v14, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r1v17 */
    /* JADX WARN: Type inference failed for: r1v20, types: [android.hardware.camera2.params.OutputConfiguration] */
    /* JADX WARN: Type inference failed for: r1v27, types: [android.hardware.camera2.params.OutputConfiguration] */
    /* JADX WARN: Type inference failed for: r1v28 */
    /* JADX WARN: Type inference failed for: r1v29 */
    /* JADX WARN: Type inference failed for: r2v3, types: [java.lang.StringBuilder] */
    public static x a(Surface surface, Integer num, z.a1 a1Var, z.z0 z0Var, z.y0 y0Var, z.b1 b1Var, List list, Size size, boolean z5, int i10, String str, int i11) {
        Class cls;
        ?? A = surface;
        Integer num2 = (i11 & 2) != 0 ? null : num;
        int i12 = i11 & 4;
        z.a1 a1Var2 = z.a1.f23312a;
        z.a1 outputType = i12 != 0 ? a1Var2 : a1Var;
        boolean z6 = (i11 & 512) != 0 ? false : z5;
        int i13 = (i11 & 1024) != 0 ? -1 : i10;
        kotlin.jvm.internal.q.g(outputType, "outputType");
        if (!outputType.equals(z.a1.f23315d) || Build.VERSION.SDK_INT < 35) {
            if (!outputType.equals(a1Var2)) {
                int i14 = Build.VERSION.SDK_INT;
                if (i14 < 26) {
                    throw new IllegalStateException(p0.e.l("Deferred OutputConfigurations are not supported on API ", i14, " (requires API 26)"));
                }
                if (size == null) {
                    throw new IllegalStateException("Size must defined when creating a deferred OutputConfiguration.");
                }
                if (outputType.equals(z.a1.f23314c)) {
                    cls = SurfaceTexture.class;
                } else if (outputType.equals(z.a1.f23313b)) {
                    cls = SurfaceHolder.class;
                } else if (outputType.equals(z.a1.f23316e)) {
                    if (i14 < 35) {
                        throw new IllegalStateException("OutputType.MEDIA_CODEC requires API 35 or higher.");
                    }
                    cls = MediaCodec.class;
                } else {
                    if (!outputType.equals(z.a1.f)) {
                        throw new IllegalStateException("Unsupported OutputType: " + outputType);
                    }
                    if (i14 < 35) {
                        throw new IllegalStateException("OutputType.MEDIA_RECORDER requires API 35 or higher.");
                    }
                    cls = MediaRecorder.class;
                }
                A = z.a(size, cls);
            } else {
                if (A == 0) {
                    throw new IllegalStateException("non-null surface!");
                }
                try {
                    if (i13 != -1) {
                        w.e();
                        A = w.b(i13, A);
                    } else {
                        w.e();
                        A = w.c(A);
                    }
                } catch (Throwable th2) {
                    Log.w("CXCP", "Failed to create an OutputConfiguration for " + A + '!', th2);
                    return null;
                }
            }
        } else {
            if (num2 == null) {
                throw new IllegalStateException("Required value was null.");
            }
            if (size == null) {
                throw new IllegalStateException("Required value was null.");
            }
            A = j0.a(num2.intValue(), size);
        }
        if (z6) {
            int i15 = Build.VERSION.SDK_INT;
            if (i15 < 24) {
                throw new IllegalStateException(p0.e.l("surfaceSharing is not supported on API ", i15, " (requires API 24)").toString());
            }
            if (i15 >= 26) {
                a0.b(A);
            }
        }
        if (str != null) {
            int i16 = Build.VERSION.SDK_INT;
            if (i16 < 28) {
                throw new IllegalStateException(p0.e.l("physicalCameraId is not supported on API ", i16, " (requires API 28)").toString());
            }
            if (i16 >= 28) {
                c0.j(A, str);
            }
        }
        if (z0Var != null) {
            int i17 = z0Var.f23416a;
            int i18 = Build.VERSION.SDK_INT;
            if (i18 >= 33) {
                h0.d(A, i17);
            } else if (i17 != 0) {
                StringBuilder sbP = p0.e.p("Cannot set mirrorMode to a non-default value on API ", i18, ". This may result in unexpected behavior. Requested ");
                sbP.append((Object) z.z0.a(i17));
                Log.w("CXCP", sbP.toString());
            }
        }
        if (y0Var != null) {
            long j10 = y0Var.f23414a;
            int i19 = Build.VERSION.SDK_INT;
            if (i19 >= 33) {
                h0.c(A, j10);
            } else if (j10 != 1) {
                StringBuilder sbP2 = p0.e.p("Cannot set dynamicRangeProfile to a non-default value on API ", i19, ". This may result in unexpected behavior. Requested ");
                sbP2.append((Object) z.y0.a(j10));
                Log.w("CXCP", sbP2.toString());
            }
        }
        if (b1Var != null && Build.VERSION.SDK_INT >= 33) {
            h0.e(A, b1Var.f23321a);
        }
        if (!list.isEmpty()) {
            int i20 = Build.VERSION.SDK_INT;
            if (i20 >= 31) {
                Iterator it = list.iterator();
                if (it.hasNext()) {
                    throw f.m(it);
                }
            } else {
                Log.w("CXCP", "Cannot add sensorPixelModeUsed value on API " + i20 + ". This may result in unexpected behavior. Requested " + list);
            }
        }
        if (Build.VERSION.SDK_INT >= 28) {
            c0.d(A);
        }
        return new x(A);
    }

    public static boolean b(int i10, boolean z5) {
        int i11;
        if (!z5 || 29 > (i11 = Build.VERSION.SDK_INT) || i11 >= 33) {
            return false;
        }
        return i10 == 1 || i10 == 2 || i10 == 6;
    }

    /* JADX WARN: Code duplicated, block: B:13:0x0021 A[PHI: r10
      0x0021: PHI (r10v5 long) = (r10v2 long), (r10v6 long) binds: [B:18:0x0031, B:11:0x001e] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:61:0x007a A[RETURN] */
    public static boolean c(int i10, int i11, long j10, boolean z5, boolean z6, c0.d dVar) {
        long j11;
        long j12;
        boolean zB = b(i10, z6);
        if (zB) {
            Log.d("CXCP", "shouldRetry: Active resume mode is activated");
        }
        if (zB) {
            j11 = 1800000000000L;
            if (dVar != null) {
                j12 = dVar.f3831a;
                if (c0.d.a(1800000000000L, j12) != -1) {
                    j11 = j12;
                }
            }
        } else {
            j11 = RealConnection.IDLE_CONNECTION_HEALTHY_NS;
            if (dVar != null) {
                j12 = dVar.f3831a;
                if (c0.d.a(RealConnection.IDLE_CONNECTION_HEALTHY_NS, j12) != -1) {
                    j11 = j12;
                }
            }
        }
        if (c0.d.a(j10, j11) <= 0) {
            if (i10 == 0) {
                if (i11 <= 1) {
                    return true;
                }
            } else {
                if (i10 != 1) {
                    if (i10 != 2) {
                        if (i10 == 3) {
                            if (!z5 || i11 <= 1) {
                            }
                        } else if (i10 != 4 && i10 != 5 && i10 != 6 && i10 != 7) {
                            if (i10 == 8) {
                                if (i11 <= 1) {
                                }
                            } else if (i10 != 10) {
                                if (i10 != 11) {
                                    Log.e("CXCP", "Unexpected CameraError: " + r4.f308i);
                                    return false;
                                }
                                if (i11 <= 1) {
                                }
                            }
                        }
                    }
                    return true;
                }
                if (Build.VERSION.SDK_INT >= 29 || i11 <= 1) {
                    return true;
                }
            }
        }
        return false;
    }
}
