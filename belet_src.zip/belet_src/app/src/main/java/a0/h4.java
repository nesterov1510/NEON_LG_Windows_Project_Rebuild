package a0;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.ListIterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;
import okhttp3.Dispatcher;
import okhttp3.OkHttpClient;
import tm.belet.films.R;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class h4 extends kotlin.jvm.internal.n implements ej.l {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f103e;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ h4(int i10, Object obj, Class cls, String str, String str2, int i11, int i12) {
        super(i10, obj, cls, str, str2, i11);
        this.f103e = i12;
    }

    /* JADX WARN: Code duplicated, block: B:112:0x0295  */
    @Override // ej.l
    public final Object invoke(Object obj) {
        int iNextIndex;
        Integer numValueOf;
        boolean zContains;
        int i10 = this.f103e;
        int i11 = 1;
        int i12 = 0;
        ui.d dVar = null;
        qi.b0 b0Var = qi.b0.f17350a;
        switch (i10) {
            case 0:
                List<k2> p7 = (List) obj;
                kotlin.jvm.internal.q.g(p7, "p0");
                ((j4) this.receiver).getClass();
                ArrayList arrayList = new ArrayList();
                for (Object obj2 : p7) {
                    if (((k2) obj2) instanceof k4) {
                        arrayList.add(obj2);
                    }
                }
                p7.removeAll(arrayList);
                Iterator it = ri.m.s0(arrayList).iterator();
                while (it.hasNext()) {
                    p7.add(0, (k2) it.next());
                }
                ListIterator listIterator = p7.listIterator(p7.size());
                while (true) {
                    if (!listIterator.hasPrevious()) {
                        iNextIndex = -1;
                    } else if (((k2) listIterator.previous()) instanceof l4) {
                        iNextIndex = listIterator.nextIndex();
                    }
                }
                if (iNextIndex > 0) {
                    Object obj3 = p7.get(iNextIndex);
                    kotlin.jvm.internal.q.e(obj3, "null cannot be cast to non-null type androidx.camera.camera2.pipe.compat.RequestCloseAll");
                    l4 l4Var = (l4) obj3;
                    for (int i13 = 0; i13 < iNextIndex; i13++) {
                        k2 k2Var = (k2) p7.remove(0);
                        kotlinx.coroutines.z zVar = k2Var instanceof m4 ? ((m4) k2Var).f218b : k2Var instanceof l4 ? ((l4) k2Var).f177a : null;
                        if (zVar != null) {
                            l4Var.f177a.invokeOnCompletion(new t3(i12, zVar));
                        }
                        if (k2Var instanceof n4) {
                            ((n4) k2Var).f233a.a(null);
                        }
                    }
                }
                LinkedHashSet linkedHashSet = new LinkedHashSet();
                int i14 = 0;
                for (k2 k2Var2 : p7) {
                    int i15 = i14 + 1;
                    if (k2Var2 instanceof n4) {
                        n4 n4Var = (n4) k2Var2;
                        String str = n4Var.f233a.f20a;
                        Set setE0 = ri.m.E0(ri.m.o0(new z.p(str), n4Var.f234b));
                        int size = p7.size();
                        int i16 = i15;
                        while (true) {
                            if (i16 < size) {
                                k2 k2Var3 = (k2) p7.get(i16);
                                if (k2Var3 instanceof m4) {
                                    zContains = setE0.contains(new z.p(((m4) k2Var3).f217a));
                                } else if (k2Var3 instanceof n4) {
                                    n4 n4Var2 = (n4) k2Var3;
                                    String str2 = n4Var2.f233a.f20a;
                                    Set setE1 = ri.m.E0(ri.m.o0(new z.p(str2), n4Var2.f234b));
                                    if (kotlin.jvm.internal.q.c(str, str2) || !setE0.equals(setE1)) {
                                        zContains = true;
                                    } else {
                                        zContains = false;
                                    }
                                } else {
                                    zContains = false;
                                }
                                if (zContains) {
                                    numValueOf = Integer.valueOf(i16);
                                } else {
                                    i16++;
                                }
                            } else {
                                numValueOf = null;
                            }
                        }
                    } else if (k2Var2 instanceof m4) {
                        int size2 = p7.size();
                        int i17 = i15;
                        while (true) {
                            if (i17 < size2) {
                                k2 k2Var4 = (k2) p7.get(i17);
                                if ((k2Var4 instanceof m4) && kotlin.jvm.internal.q.c(((m4) k2Var4).f217a, ((m4) k2Var2).f217a)) {
                                    numValueOf = Integer.valueOf(i17);
                                } else {
                                    i17++;
                                }
                            } else {
                                numValueOf = null;
                            }
                        }
                    } else {
                        numValueOf = null;
                    }
                    if (numValueOf != null) {
                        k2 k2Var5 = (k2) p7.get(numValueOf.intValue());
                        Log.d("CXCP", k2Var2 + " is pruned by " + k2Var5);
                        linkedHashSet.add(Integer.valueOf(i14));
                        if ((k2Var2 instanceof m4) && (k2Var5 instanceof m4)) {
                            ((m4) k2Var5).f218b.invokeOnCompletion(new t3(i11, (m4) k2Var2));
                        }
                    }
                    i14 = i15;
                }
                ArrayList arrayList2 = new ArrayList();
                Iterator it2 = ri.m.v0(linkedHashSet).iterator();
                while (it2.hasNext()) {
                    arrayList2.add(p7.remove(((Number) it2.next()).intValue() - arrayList2.size()));
                }
                int size3 = arrayList2.size();
                int i18 = 0;
                while (i18 < size3) {
                    Object obj4 = arrayList2.get(i18);
                    i18++;
                    k2 k2Var6 = (k2) obj4;
                    if (k2Var6 instanceof n4) {
                        ((n4) k2Var6).f233a.a(null);
                    }
                }
                return b0Var;
            case 1:
                List<d0.n> p10 = (List) obj;
                kotlin.jvm.internal.q.g(p10, "p0");
                d0.t tVar = (d0.t) this.receiver;
                tVar.getClass();
                for (d0.n nVar : p10) {
                    if (nVar instanceof d0.h) {
                        tVar.a(null);
                    } else if (nVar instanceof d0.l) {
                        kotlinx.coroutines.k.launch$default(tVar.f6571s0, null, kotlinx.coroutines.s0.UNDISPATCHED, new c((d0.l) nVar, dVar, 10), 1, null);
                    }
                }
                return b0Var;
            case 2:
                kotlin.jvm.internal.q.g((Set) obj, "p0");
                g6.g gVar = (g6.g) this.receiver;
                ReentrantLock reentrantLock = gVar.f8594d;
                reentrantLock.lock();
                try {
                    List listZ0 = ri.m.z0(gVar.f8593c.values());
                    reentrantLock.unlock();
                    Iterator it3 = listZ0.iterator();
                    if (!it3.hasNext()) {
                        return b0Var;
                    }
                    ((g6.n) it3.next()).getClass();
                    throw null;
                } catch (Throwable th2) {
                    reentrantLock.unlock();
                    throw th2;
                }
            case 3:
                qm.a p11 = (qm.a) obj;
                kotlin.jvm.internal.q.g(p11, "p0");
                go.n1 n1Var = (go.n1) this.receiver;
                int i19 = n1Var.E1;
                int i20 = p11.f17545d;
                if (i19 != i20) {
                    n1Var.G1 = 0;
                    n1Var.s0(false, true);
                    if (i20 == 0) {
                        String strX = n1Var.x(R.string.title_home);
                        kotlin.jvm.internal.q.f(strX, "getString(...)");
                        n1Var.t0(0, strX);
                        n1Var.k0();
                        so.a.n(n1Var.j(), "HomeCategoryFragment");
                        n1Var.r0();
                        n1Var.o0();
                    } else {
                        n1Var.t0(i20, p11.f17542a);
                        Context contextO = n1Var.o();
                        if (contextO != null) {
                            so.a.m(so.a.o(contextO));
                            go.d1 d1Var = new go.d1();
                            Bundle bundle = new Bundle();
                            bundle.putInt("category_id", i20);
                            d1Var.f0(bundle);
                            androidx.fragment.app.b1 b1VarB = so.a.o(contextO).B();
                            b1VarB.getClass();
                            androidx.fragment.app.a aVar = new androidx.fragment.app.a(b1VarB);
                            aVar.n(R.id.home_container, d1Var, "HomeCategoryFragment");
                            aVar.g();
                        }
                        n1Var.o0();
                    }
                }
                return b0Var;
            case 4:
                return ((io.ktor.utils.io.h0) this.receiver).d((ui.d) obj);
            default:
                mh.h1 h1Var = (mh.h1) obj;
                jh.a aVar2 = ((jh.d) this.receiver).f13270r0;
                OkHttpClient okHttpClient = aVar2.f13264b;
                if (okHttpClient == null) {
                    okHttpClient = (OkHttpClient) jh.d.f13269w0.getValue();
                }
                OkHttpClient.Builder builderNewBuilder = okHttpClient.newBuilder();
                builderNewBuilder.dispatcher(new Dispatcher());
                aVar2.f13263a.invoke(builderNewBuilder);
                if (h1Var != null) {
                    Long l10 = h1Var.f15386b;
                    if (l10 != null) {
                        long jLongValue = l10.longValue();
                        dk.b bVar = mh.j1.f15395a;
                        if (jLongValue == Long.MAX_VALUE) {
                            jLongValue = 0;
                        }
                        builderNewBuilder.connectTimeout(jLongValue, TimeUnit.MILLISECONDS);
                    }
                    Long l11 = h1Var.f15387c;
                    if (l11 != null) {
                        long jLongValue2 = l11.longValue();
                        dk.b bVar2 = mh.j1.f15395a;
                        long j10 = jLongValue2 == Long.MAX_VALUE ? 0L : jLongValue2;
                        TimeUnit timeUnit = TimeUnit.MILLISECONDS;
                        builderNewBuilder.readTimeout(j10, timeUnit);
                        builderNewBuilder.writeTimeout(jLongValue2 != Long.MAX_VALUE ? jLongValue2 : 0L, timeUnit);
                    }
                }
                return builderNewBuilder.build();
        }
    }
}
