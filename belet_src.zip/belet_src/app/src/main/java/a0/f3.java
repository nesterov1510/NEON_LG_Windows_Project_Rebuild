package a0;

import android.content.SharedPreferences;
import android.util.Log;
import androidx.media3.session.n5;
import j$.util.DesugarCollections;
import java.util.List;
import java.util.Map;
import okhttp3.internal.url._UrlKt;
import tm.belet.films.App;
import tm.belet.films.presentation.activities.DeleteDeviceActivity;
import tm.belet.films.presentation.activities.HomeActivity;
import tm.belet.films.presentation.viewmodel.DownloadSettingsViewModel;
import tm.belet.films.presentation.viewmodel.NotificationViewModel;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class f3 extends wi.i implements ej.p {
    public final /* synthetic */ Object X;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f85e;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ f3(Object obj, ui.d dVar, int i10) {
        super(2, dVar);
        this.f85e = i10;
        this.X = obj;
    }

    @Override // wi.a
    public final ui.d create(Object obj, ui.d dVar) {
        switch (this.f85e) {
            case 0:
                return new f3((i3) this.X, dVar, 0);
            case 1:
                return new f3((kotlin.jvm.internal.d0) this.X, dVar, 1);
            case 2:
                return new f3((n5) this.X, dVar, 2);
            case 3:
                return new f3((ef.g) this.X, dVar, 3);
            case 4:
                return new f3((go.z2) this.X, dVar, 4);
            case 5:
                return new f3((App) this.X, dVar, 5);
            case 6:
                return new f3((m0.c2) this.X, dVar, 6);
            case 7:
                return new f3(dVar, (w.w) this.X, 7);
            case 8:
                return new f3(dVar, (w.v0) this.X, 8);
            case 9:
                return new f3((DeleteDeviceActivity) this.X, dVar, 9);
            case 10:
                return new f3((HomeActivity) this.X, dVar, 10);
            default:
                return new f3((y5.c0) this.X, dVar, 11);
        }
    }

    @Override // ej.p
    public final Object invoke(Object obj, Object obj2) {
        switch (this.f85e) {
            case 0:
                f3 f3Var = (f3) create((kotlinx.coroutines.p0) obj, (ui.d) obj2);
                qi.b0 b0Var = qi.b0.f17350a;
                f3Var.invokeSuspend(b0Var);
                return b0Var;
            case 1:
                f3 f3Var2 = (f3) create((qi.b0) obj, (ui.d) obj2);
                qi.b0 b0Var2 = qi.b0.f17350a;
                f3Var2.invokeSuspend(b0Var2);
                return b0Var2;
            case 2:
                f3 f3Var3 = (f3) create((kotlinx.coroutines.p0) obj, (ui.d) obj2);
                qi.b0 b0Var3 = qi.b0.f17350a;
                f3Var3.invokeSuspend(b0Var3);
                return b0Var3;
            case 3:
                return ((f3) create((ef.g) obj, (ui.d) obj2)).invokeSuspend(qi.b0.f17350a);
            case 4:
                f3 f3Var4 = (f3) create((kotlinx.coroutines.p0) obj, (ui.d) obj2);
                qi.b0 b0Var4 = qi.b0.f17350a;
                f3Var4.invokeSuspend(b0Var4);
                return b0Var4;
            case 5:
                f3 f3Var5 = (f3) create((kotlinx.coroutines.p0) obj, (ui.d) obj2);
                qi.b0 b0Var5 = qi.b0.f17350a;
                f3Var5.invokeSuspend(b0Var5);
                return b0Var5;
            case 6:
                f3 f3Var6 = (f3) create((kotlinx.coroutines.p0) obj, (ui.d) obj2);
                qi.b0 b0Var6 = qi.b0.f17350a;
                f3Var6.invokeSuspend(b0Var6);
                return b0Var6;
            case 7:
                f3 f3Var7 = (f3) create((kotlinx.coroutines.p0) obj, (ui.d) obj2);
                qi.b0 b0Var7 = qi.b0.f17350a;
                f3Var7.invokeSuspend(b0Var7);
                return b0Var7;
            case 8:
                f3 f3Var8 = (f3) create((kotlinx.coroutines.p0) obj, (ui.d) obj2);
                qi.b0 b0Var8 = qi.b0.f17350a;
                f3Var8.invokeSuspend(b0Var8);
                return b0Var8;
            case 9:
                f3 f3Var9 = (f3) create((kotlinx.coroutines.p0) obj, (ui.d) obj2);
                qi.b0 b0Var9 = qi.b0.f17350a;
                f3Var9.invokeSuspend(b0Var9);
                return b0Var9;
            case 10:
                f3 f3Var10 = (f3) create((kotlinx.coroutines.p0) obj, (ui.d) obj2);
                qi.b0 b0Var10 = qi.b0.f17350a;
                f3Var10.invokeSuspend(b0Var10);
                return b0Var10;
            default:
                f3 f3Var11 = (f3) create((kotlinx.coroutines.flow.j) obj, (ui.d) obj2);
                qi.b0 b0Var11 = qi.b0.f17350a;
                f3Var11.invokeSuspend(b0Var11);
                return b0Var11;
        }
    }

    /* JADX WARN: Code duplicated, block: B:46:0x0156  */
    /* JADX WARN: Multi-variable type inference failed */
    @Override // wi.a
    public final Object invokeSuspend(Object obj) {
        m0.a2 a2Var;
        m0.u0 u0Var;
        int i10 = 1;
        Object obj2 = null;
        Object[] objArr = 0;
        switch (this.f85e) {
            case 0:
                vi.a aVar = vi.a.f21252e;
                g6.y.I(obj);
                ((i3) this.X).m(true);
                return qi.b0.f17350a;
            case 1:
                vi.a aVar2 = vi.a.f21252e;
                g6.y.I(obj);
                ((kotlin.jvm.internal.d0) this.X).f13951e = null;
                return qi.b0.f17350a;
            case 2:
                vi.a aVar3 = vi.a.f21252e;
                g6.y.I(obj);
                ((a) ((n5) this.X).f2559s0).invoke();
                return qi.b0.f17350a;
            case 3:
                vi.a aVar4 = vi.a.f21252e;
                g6.y.I(obj);
                return (ef.g) this.X;
            case 4:
                go.z2 z2Var = (go.z2) this.X;
                vi.a aVar5 = vi.a.f21252e;
                g6.y.I(obj);
                try {
                    try {
                        DownloadSettingsViewModel downloadSettingsViewModelK0 = z2Var.k0();
                        kotlinx.coroutines.k.launch$default(androidx.lifecycle.r0.g(downloadSettingsViewModelK0), null, null, new tm.belet.films.presentation.viewmodel.i(downloadSettingsViewModelK0, objArr == true ? 1 : 0, i10), 3, null);
                        break;
                    } catch (Exception e3) {
                        oo.c.d(z2Var.o(), oo.l.ERROR, String.valueOf(e3.getMessage()), null, (24 & 16) == 0);
                        break;
                    }
                    return qi.b0.f17350a;
                } finally {
                    z2Var.n0();
                    z2Var.j0().f7191m.setVisibility(0);
                    z2Var.j0().f7186g.setVisibility(8);
                }
            case 5:
                vi.a aVar6 = vi.a.f21252e;
                g6.y.I(obj);
                ((App) this.X).e();
                return qi.b0.f17350a;
            case 6:
                vi.a aVar7 = vi.a.f21252e;
                g6.y.I(obj);
                m0.c2 c2Var = (m0.c2) this.X;
                if (c2Var != null && (a2Var = c2Var.f) != null) {
                    a2Var.a(c2Var);
                }
                return qi.b0.f17350a;
            case 7:
                vi.a aVar8 = vi.a.f21252e;
                g6.y.I(obj);
                w.f1 f1Var = ((w.w) this.X).f21472c;
                if (f1Var != null) {
                    f1Var.close();
                }
                return qi.b0.f17350a;
            case 8:
                vi.a aVar9 = vi.a.f21252e;
                g6.y.I(obj);
                if (!((w.v0) this.X).h.getValue()) {
                    d0.b bVarA = ((w.v0) this.X).f21462a.a();
                    v.g gVar = ((w.v0) this.X).f21462a;
                    gVar.f20895c.f17672b = gVar.a();
                    r.l lVar = gVar.f20894b;
                    d0.b bVarA2 = gVar.a();
                    synchronized (lVar.f17647a) {
                        try {
                            if (y6.a.o("CXCP")) {
                                Log.d("CXCP", "Camera graph updated from " + lVar.f17650d + " to " + bVarA2);
                            }
                            m0.b0 b0Var = lVar.f17651e;
                            m0.b0 b0Var2 = m0.b0.Y;
                            if (b0Var != b0Var2) {
                                lVar.c(m0.b0.f14763r0, null);
                                lVar.c(b0Var2, null);
                            }
                            lVar.f17650d = bVarA2;
                            lVar.f17651e = b0Var2;
                        } catch (Throwable th2) {
                            throw th2;
                        }
                    }
                    bVarA.t();
                    Map map = (Map) ((w.v0) this.X).f21462a.f.getValue();
                    w.v0 v0Var = (w.v0) this.X;
                    r.c0 c0Var = (r.c0) v0Var.f21469j.getValue();
                    m0.c2 c2Var2 = ((m0.b2) c0Var.f17578e.getValue()).c() ? (m0.c2) c0Var.f.getValue() : null;
                    if (c2Var2 != null) {
                        List listUnmodifiableList = DesugarCollections.unmodifiableList(c2Var2.f14779g.f14901a);
                        kotlin.jvm.internal.q.f(listUnmodifiableList, "getSurfaces(...)");
                        List listB = c2Var2.b();
                        kotlin.jvm.internal.q.f(listB, "getSurfaces(...)");
                        for (Object obj3 : listB) {
                            if (!listUnmodifiableList.contains((m0.u0) obj3)) {
                                obj2 = obj3;
                                u0Var = (m0.u0) obj2;
                                if (u0Var != null) {
                                }
                            }
                        }
                        u0Var = (m0.u0) obj2;
                        if (u0Var != null) {
                        }
                    }
                    if (y6.a.o("CXCP")) {
                        Log.d("CXCP", "Setting up Surfaces with UseCaseSurfaceManager");
                    }
                    if (((m0.b2) ((r.c0) ((w.v0) this.X).f21469j.getValue()).f17578e.getValue()).c()) {
                        w.o1 o1Var = (w.o1) ((w.v0) this.X).f21468i.getValue();
                        kotlin.jvm.internal.q.f(o1Var, "access$getUseCaseSurfaceManager(...)");
                        r.c0 c0Var2 = (r.c0) ((w.v0) this.X).f21469j.getValue();
                        kotlin.jvm.internal.q.f(c0Var2, "access$getSessionConfigAdapter(...)");
                        w.o1.f(o1Var, bVarA, c0Var2, map).invokeOnCompletion(w.u0.f21460e);
                    } else if (y6.a.p()) {
                        Log.e("CXCP", "Unable to create capture session due to conflicting configurations");
                    }
                } else if (y6.a.o("CXCP")) {
                    Log.d("CXCP", "UseCaseCamera is closed before starting the CameraGraph, skipping setup.");
                }
                return qi.b0.f17350a;
            case 9:
                vi.a aVar10 = vi.a.f21252e;
                g6.y.I(obj);
                DeleteDeviceActivity deleteDeviceActivity = (DeleteDeviceActivity) this.X;
                int i11 = DeleteDeviceActivity.Y0;
                deleteDeviceActivity.J().e(deleteDeviceActivity.X0, deleteDeviceActivity.U0);
                return qi.b0.f17350a;
            case 10:
                vi.a aVar11 = vi.a.f21252e;
                g6.y.I(obj);
                NotificationViewModel notificationViewModel = (NotificationViewModel) ((HomeActivity) this.X).R0.getValue();
                SharedPreferences sharedPreferences = d7.s.f6708b;
                ui.d dVar = null;
                if (sharedPreferences != null) {
                    kotlinx.coroutines.k.launch$default(androidx.lifecycle.r0.g(notificationViewModel), null, null, new p2.w(notificationViewModel, sharedPreferences.getString("fcm_token", _UrlKt.FRAGMENT_ENCODE_SET), d7.s.f6710d, dVar, 10), 3, null);
                    return qi.b0.f17350a;
                }
                kotlin.jvm.internal.q.n("shared");
                throw null;
            default:
                vi.a aVar12 = vi.a.f21252e;
                g6.y.I(obj);
                ((y5.c0) this.X).getClass();
                return qi.b0.f17350a;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ f3(ui.d dVar, Object obj, int i10) {
        super(2, dVar);
        this.f85e = i10;
        this.X = obj;
    }
}
