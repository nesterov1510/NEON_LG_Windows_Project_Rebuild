package a0;

import android.hardware.camera2.params.OutputConfiguration;
import android.os.Build;
import android.view.Surface;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class x implements r3 {
    public final Surface X;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final OutputConfiguration f376e;

    public x(OutputConfiguration outputConfiguration) {
        this.f376e = outputConfiguration;
        this.X = outputConfiguration.getSurface();
    }

    @Override // z.o1
    public final Object D(kotlin.jvm.internal.h hVar) {
        if (hVar.equals(kotlin.jvm.internal.e0.a(OutputConfiguration.class))) {
            return this.f376e;
        }
        return null;
    }

    public final void a(Surface surface) {
        kotlin.jvm.internal.q.g(surface, "surface");
        int i10 = Build.VERSION.SDK_INT;
        if (i10 < 26) {
            throw new IllegalStateException(p0.e.l("addSurface is not supported on API ", i10, " (requires API 26)").toString());
        }
        if (i10 >= 26) {
            a0.a(this.f376e, surface);
        }
    }

    public final String toString() {
        return this.f376e.toString();
    }
}
