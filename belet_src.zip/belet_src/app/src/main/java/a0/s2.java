package a0;

import android.util.Log;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class s2 extends wi.i implements ej.l {
    public final /* synthetic */ Object X;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f319e;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ s2(Object obj, ui.d dVar, int i10) {
        super(1, dVar);
        this.f319e = i10;
        this.X = obj;
    }

    @Override // wi.a
    public final ui.d create(ui.d dVar) {
        switch (this.f319e) {
            case 0:
                return new s2((kotlin.jvm.internal.d0) this.X, dVar, 0);
            case 1:
                return new s2((i3) this.X, dVar, 1);
            default:
                return new s2((ej.a) this.X, dVar, 2);
        }
    }

    @Override // ej.l
    public final Object invoke(Object obj) throws InterruptedException {
        ui.d dVar = (ui.d) obj;
        switch (this.f319e) {
            case 0:
                return ((s2) create(dVar)).invokeSuspend(qi.b0.f17350a);
            case 1:
                s2 s2Var = (s2) create(dVar);
                qi.b0 b0Var = qi.b0.f17350a;
                s2Var.invokeSuspend(b0Var);
                return b0Var;
            default:
                return ((s2) create(dVar)).invokeSuspend(qi.b0.f17350a);
        }
    }

    @Override // wi.a
    public final Object invokeSuspend(Object obj) throws InterruptedException {
        int i10 = this.f319e;
        Object obj2 = this.X;
        switch (i10) {
            case 0:
                vi.a aVar = vi.a.f21252e;
                g6.y.I(obj);
                Log.d("CXCP", "tryOpenCamera: Camera open cancelled");
                ((kotlin.jvm.internal.d0) obj2).f13951e = null;
                return new q3(null, new z.i(13), 1);
            case 1:
                vi.a aVar2 = vi.a.f21252e;
                g6.y.I(obj);
                ((i3) obj2).f131x.await();
                return qi.b0.f17350a;
            default:
                vi.a aVar3 = vi.a.f21252e;
                g6.y.I(obj);
                return ((ej.a) obj2).invoke();
        }
    }
}
