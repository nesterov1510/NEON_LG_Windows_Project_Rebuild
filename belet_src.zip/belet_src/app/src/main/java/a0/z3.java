package a0;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class z3 implements a4 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final d f398a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final c0.f f399b;

    public z3(d dVar, c0.f fVar) {
        this.f398a = dVar;
        this.f399b = fVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof z3)) {
            return false;
        }
        z3 z3Var = (z3) obj;
        return this.f398a.equals(z3Var.f398a) && this.f399b.equals(z3Var.f399b);
    }

    public final int hashCode() {
        return this.f399b.hashCode() + (this.f398a.hashCode() * 31);
    }

    public final String toString() {
        return "Success(activeCamera=" + this.f398a + ", token=" + this.f399b + ')';
    }
}
