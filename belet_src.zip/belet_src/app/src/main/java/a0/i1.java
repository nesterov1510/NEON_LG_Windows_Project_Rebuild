package a0;

import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.os.Build;
import android.os.Trace;
import java.util.concurrent.Executor;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class i1 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final pi.a f108a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final c0.n f109b;

    public i1(pi.a cameraManager, c0.n threads) {
        kotlin.jvm.internal.q.g(cameraManager, "cameraManager");
        kotlin.jvm.internal.q.g(threads, "threads");
        this.f108a = cameraManager;
        this.f109b = threads;
    }

    public final void a(String str, CameraDevice.StateCallback stateCallback) {
        CameraManager cameraManager = (CameraManager) this.f108a.get();
        try {
            Trace.beginSection(((Object) z.p.b(str)) + "#openCamera");
            int i10 = Build.VERSION.SDK_INT;
            c0.n nVar = this.f109b;
            if (i10 >= 28) {
                kotlin.jvm.internal.q.d(cameraManager);
                c0.g(cameraManager, str, (Executor) nVar.h.getValue(), stateCallback);
            } else {
                cameraManager.openCamera(str, stateCallback, nVar.a());
            }
        } finally {
            Trace.endSection();
        }
    }
}
