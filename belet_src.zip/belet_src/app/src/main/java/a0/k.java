package a0;

import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraExtensionSession;
import android.hardware.camera2.CaptureRequest;
import android.os.Build;
import android.util.Log;
import android.view.Surface;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.concurrent.Executor;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class k implements i2 {
    public final CameraExtensionSession X;
    public final a2 Y;
    public final Executor Z;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final h2 f155e;

    /* JADX INFO: renamed from: r0, reason: collision with root package name */
    public final pj.d f156r0;

    /* JADX INFO: renamed from: s0, reason: collision with root package name */
    public final HashMap f157s0;

    public k(i device, CameraExtensionSession cameraExtensionSession, a2 cameraErrorListener, c0.e callbackExecutor) {
        kotlin.jvm.internal.q.g(device, "device");
        kotlin.jvm.internal.q.g(cameraErrorListener, "cameraErrorListener");
        kotlin.jvm.internal.q.g(callbackExecutor, "callbackExecutor");
        this.f155e = device;
        this.X = cameraExtensionSession;
        this.Y = cameraErrorListener;
        this.Z = callbackExecutor;
        z.q.f23384a.incrementAndGet();
        this.f156r0 = pj.b.atomic(0L);
        this.f157s0 = new HashMap();
    }

    @Override // z.o1
    public final Object D(kotlin.jvm.internal.h hVar) {
        if (hVar.equals(kotlin.jvm.internal.e0.a(CameraExtensionSession.class))) {
            return this.X;
        }
        return null;
    }

    @Override // a0.g2
    public final Integer O(List requests, m1 m1Var) {
        kotlin.jvm.internal.q.g(requests, "requests");
        if (requests.size() == 1) {
            return w((CaptureRequest) ri.m.t0(requests), m1Var);
        }
        throw new IllegalStateException("CameraExtensionSession does not support setRepeatingBurst for more than oneCaptureRequest");
    }

    @Override // a0.g2
    public final Integer Q(List requests, m1 m1Var) throws Exception {
        kotlin.jvm.internal.q.g(requests, "requests");
        Iterator it = requests.iterator();
        while (it.hasNext()) {
            Y((CaptureRequest) it.next(), m1Var);
        }
        return null;
    }

    @Override // a0.g2
    public final boolean S() {
        return false;
    }

    @Override // a0.g2
    public final h2 V() {
        return this.f155e;
    }

    @Override // a0.g2
    public final Integer Y(CaptureRequest request, m1 m1Var) throws Exception {
        kotlin.jvm.internal.q.g(request, "request");
        String strY = this.f155e.y();
        try {
            int i10 = Build.VERSION.SDK_INT;
            Executor executor = this.Z;
            return Integer.valueOf(i10 >= 33 ? this.X.capture(request, executor, new j(this, m1Var)) : this.X.capture(request, executor, new j(this, m1Var, new LinkedHashMap())));
        } catch (Exception e3) {
            boolean z5 = e3 instanceof CameraAccessException;
            int i11 = 0;
            a2 a2Var = this.Y;
            if (!z5) {
                if (!(e3 instanceof IllegalArgumentException) && !(e3 instanceof SecurityException) && !(e3 instanceof UnsupportedOperationException) && !(e3 instanceof NullPointerException)) {
                    if (!(e3 instanceof IllegalStateException)) {
                        throw e3;
                    }
                    Log.d("CXCP", "Failed to execute call: Camera may be closed");
                    return null;
                }
                Log.w("CXCP", "Failed to execute call: Unexpected exception: " + e3.getMessage());
                a2Var.a(strY, false, 9);
                return null;
            }
            Log.w("CXCP", "Failed to execute call: Camera encountered an error: " + e3.getMessage());
            CameraAccessException cameraAccessException = (CameraAccessException) e3;
            int reason = cameraAccessException.getReason();
            if (reason == 1) {
                i11 = 3;
            } else if (reason == 2) {
                i11 = 6;
            } else if (reason != 3) {
                if (reason == 4) {
                    i11 = 1;
                } else if (reason != 5) {
                    Log.w("CXCP", "Unexpected CameraAccessException: " + cameraAccessException);
                    i11 = 11;
                } else {
                    i11 = 2;
                }
            }
            a2Var.a(strY, true, i11);
            return null;
        }
    }

    @Override // java.lang.AutoCloseable
    public final void close() throws CameraAccessException {
        this.X.close();
    }

    @Override // a0.g2
    public final boolean f0(List list) {
        Log.w("CXCP", "CameraExtensionSession does not support finalizeOutputConfigurations()");
        return false;
    }

    @Override // a0.g2
    public final boolean g0() throws Exception {
        qi.b0 b0Var;
        String strY = this.f155e.y();
        try {
            this.X.stopRepeating();
            b0Var = qi.b0.f17350a;
        } catch (Exception e3) {
            boolean z5 = e3 instanceof CameraAccessException;
            a2 a2Var = this.Y;
            if (z5) {
                Log.w("CXCP", "Failed to execute call: Camera encountered an error: " + e3.getMessage());
                CameraAccessException cameraAccessException = (CameraAccessException) e3;
                int reason = cameraAccessException.getReason();
                int i10 = 3;
                if (reason != 1) {
                    if (reason == 2) {
                        i10 = 6;
                    } else if (reason == 3) {
                        i10 = 0;
                    } else if (reason == 4) {
                        i10 = 1;
                    } else if (reason != 5) {
                        Log.w("CXCP", "Unexpected CameraAccessException: " + cameraAccessException);
                        i10 = 11;
                    } else {
                        i10 = 2;
                    }
                }
                a2Var.a(strY, true, i10);
            } else if ((e3 instanceof IllegalArgumentException) || (e3 instanceof SecurityException) || (e3 instanceof UnsupportedOperationException) || (e3 instanceof NullPointerException)) {
                Log.w("CXCP", "Failed to execute call: Unexpected exception: " + e3.getMessage());
                a2Var.a(strY, false, 9);
            } else {
                if (!(e3 instanceof IllegalStateException)) {
                    throw e3;
                }
                Log.d("CXCP", "Failed to execute call: Camera may be closed");
            }
            b0Var = null;
        }
        return b0Var != null;
    }

    @Override // a0.g2
    public final Surface getInputSurface() {
        return null;
    }

    @Override // a0.g2
    public final Integer w(CaptureRequest request, m1 m1Var) throws Exception {
        kotlin.jvm.internal.q.g(request, "request");
        String strY = this.f155e.y();
        try {
            int i10 = Build.VERSION.SDK_INT;
            Executor executor = this.Z;
            return Integer.valueOf(i10 >= 33 ? this.X.setRepeatingRequest(request, executor, new j(this, m1Var)) : this.X.setRepeatingRequest(request, executor, new j(this, m1Var, new LinkedHashMap())));
        } catch (Exception e3) {
            boolean z5 = e3 instanceof CameraAccessException;
            int i11 = 0;
            a2 a2Var = this.Y;
            if (!z5) {
                if (!(e3 instanceof IllegalArgumentException) && !(e3 instanceof SecurityException) && !(e3 instanceof UnsupportedOperationException) && !(e3 instanceof NullPointerException)) {
                    if (!(e3 instanceof IllegalStateException)) {
                        throw e3;
                    }
                    Log.d("CXCP", "Failed to execute call: Camera may be closed");
                    return null;
                }
                Log.w("CXCP", "Failed to execute call: Unexpected exception: " + e3.getMessage());
                a2Var.a(strY, false, 9);
                return null;
            }
            Log.w("CXCP", "Failed to execute call: Camera encountered an error: " + e3.getMessage());
            CameraAccessException cameraAccessException = (CameraAccessException) e3;
            int reason = cameraAccessException.getReason();
            if (reason == 1) {
                i11 = 3;
            } else if (reason == 2) {
                i11 = 6;
            } else if (reason != 3) {
                if (reason == 4) {
                    i11 = 1;
                } else if (reason != 5) {
                    Log.w("CXCP", "Unexpected CameraAccessException: " + cameraAccessException);
                    i11 = 11;
                } else {
                    i11 = 2;
                }
            }
            a2Var.a(strY, true, i11);
            return null;
        }
    }
}
