package a0;

import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CaptureRequest;
import android.os.Build;
import android.os.Handler;
import android.os.SystemClock;
import android.os.Trace;
import android.util.Log;
import android.view.Surface;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public class g implements g2 {
    public final CameraCaptureSession X;
    public final a2 Y;
    public final Handler Z;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final h2 f88e;

    public g(h2 device, CameraCaptureSession cameraCaptureSession, a2 cameraErrorListener, Handler callbackHandler) {
        kotlin.jvm.internal.q.g(device, "device");
        kotlin.jvm.internal.q.g(cameraErrorListener, "cameraErrorListener");
        kotlin.jvm.internal.q.g(callbackHandler, "callbackHandler");
        this.f88e = device;
        this.X = cameraCaptureSession;
        this.Y = cameraErrorListener;
        this.Z = callbackHandler;
        z.q.f23384a.incrementAndGet();
    }

    @Override // z.o1
    public Object D(kotlin.jvm.internal.h hVar) {
        if (hVar.equals(kotlin.jvm.internal.e0.a(CameraCaptureSession.class))) {
            return this.X;
        }
        return null;
    }

    @Override // a0.g2
    public final Integer O(List requests, m1 m1Var) throws Throwable {
        double d2;
        char c10;
        Integer numValueOf;
        int i10;
        kotlin.jvm.internal.q.g(requests, "requests");
        StringBuilder sb2 = new StringBuilder("CXCP#setRepeatingBurst-");
        h2 h2Var = this.f88e;
        sb2.append(h2Var.y());
        String string = sb2.toString();
        long jElapsedRealtimeNanos = SystemClock.elapsedRealtimeNanos();
        try {
            Trace.beginSection(string);
            String strY = h2Var.y();
            d2 = 1000000.0d;
            try {
                a2 a2Var = this.Y;
                try {
                    numValueOf = Integer.valueOf(this.X.setRepeatingBurst(requests, m1Var, this.Z));
                } catch (Exception e3) {
                    if (!(e3 instanceof CameraAccessException)) {
                        if ((e3 instanceof IllegalArgumentException) || (e3 instanceof SecurityException) || (e3 instanceof UnsupportedOperationException) || (e3 instanceof NullPointerException)) {
                            Log.w("CXCP", "Failed to execute call: Unexpected exception: " + e3.getMessage());
                            c10 = 0;
                            a2Var.a(strY, false, 9);
                            numValueOf = null;
                        } else {
                            if (!(e3 instanceof IllegalStateException)) {
                                throw e3;
                            }
                            Log.d("CXCP", "Failed to execute call: Camera may be closed");
                        }
                        long jI = f.i(jElapsedRealtimeNanos);
                        StringBuilder sbU = f.u(string, " - ");
                        Object[] objArr = new Object[1];
                        objArr[c10] = Double.valueOf(jI / 1000000.0d);
                        Log.d("CXCP", f.s(objArr, 1, null, "%.3f ms", sbU));
                        return numValueOf;
                    }
                    Log.w("CXCP", "Failed to execute call: Camera encountered an error: " + e3.getMessage());
                    CameraAccessException cameraAccessException = (CameraAccessException) e3;
                    int reason = cameraAccessException.getReason();
                    if (reason == 1) {
                        i10 = 3;
                    } else if (reason == 2) {
                        i10 = 6;
                    } else if (reason == 3) {
                        i10 = 0;
                    } else if (reason == 4) {
                        i10 = 1;
                    } else if (reason != 5) {
                        Log.w("CXCP", "Unexpected CameraAccessException: " + cameraAccessException);
                        i10 = 11;
                    } else {
                        i10 = 2;
                    }
                    a2Var.a(strY, true, i10);
                    numValueOf = null;
                }
                c10 = 0;
                long jI2 = f.i(jElapsedRealtimeNanos);
                StringBuilder sbU2 = f.u(string, " - ");
                Object[] objArr2 = new Object[1];
                objArr2[c10] = Double.valueOf(jI2 / 1000000.0d);
                Log.d("CXCP", f.s(objArr2, 1, null, "%.3f ms", sbU2));
                return numValueOf;
            } catch (Throwable th2) {
                th = th2;
                Log.d("CXCP", f.s(new Object[]{Double.valueOf(f.i(jElapsedRealtimeNanos) / d2)}, 1, null, "%.3f ms", f.u(string, " - ")));
                throw th;
            }
        } catch (Throwable th3) {
            th = th3;
            d2 = 1000000.0d;
        }
    }

    @Override // a0.g2
    public final Integer Q(List requests, m1 m1Var) throws Throwable {
        double d2;
        char c10;
        Integer numValueOf;
        int i10;
        kotlin.jvm.internal.q.g(requests, "requests");
        StringBuilder sb2 = new StringBuilder("CXCP#captureBurst-");
        h2 h2Var = this.f88e;
        sb2.append(h2Var.y());
        String string = sb2.toString();
        long jElapsedRealtimeNanos = SystemClock.elapsedRealtimeNanos();
        try {
            Trace.beginSection(string);
            String strY = h2Var.y();
            d2 = 1000000.0d;
            try {
                a2 a2Var = this.Y;
                try {
                    numValueOf = Integer.valueOf(this.X.captureBurst(requests, m1Var, this.Z));
                } catch (Exception e3) {
                    if (!(e3 instanceof CameraAccessException)) {
                        if ((e3 instanceof IllegalArgumentException) || (e3 instanceof SecurityException) || (e3 instanceof UnsupportedOperationException) || (e3 instanceof NullPointerException)) {
                            Log.w("CXCP", "Failed to execute call: Unexpected exception: " + e3.getMessage());
                            c10 = 0;
                            a2Var.a(strY, false, 9);
                            numValueOf = null;
                        } else {
                            if (!(e3 instanceof IllegalStateException)) {
                                throw e3;
                            }
                            Log.d("CXCP", "Failed to execute call: Camera may be closed");
                        }
                        long jI = f.i(jElapsedRealtimeNanos);
                        StringBuilder sbU = f.u(string, " - ");
                        Object[] objArr = new Object[1];
                        objArr[c10] = Double.valueOf(jI / 1000000.0d);
                        Log.d("CXCP", f.s(objArr, 1, null, "%.3f ms", sbU));
                        return numValueOf;
                    }
                    Log.w("CXCP", "Failed to execute call: Camera encountered an error: " + e3.getMessage());
                    CameraAccessException cameraAccessException = (CameraAccessException) e3;
                    int reason = cameraAccessException.getReason();
                    if (reason == 1) {
                        i10 = 3;
                    } else if (reason == 2) {
                        i10 = 6;
                    } else if (reason == 3) {
                        i10 = 0;
                    } else if (reason == 4) {
                        i10 = 1;
                    } else if (reason != 5) {
                        Log.w("CXCP", "Unexpected CameraAccessException: " + cameraAccessException);
                        i10 = 11;
                    } else {
                        i10 = 2;
                    }
                    a2Var.a(strY, true, i10);
                    numValueOf = null;
                }
                c10 = 0;
                long jI2 = f.i(jElapsedRealtimeNanos);
                StringBuilder sbU2 = f.u(string, " - ");
                Object[] objArr2 = new Object[1];
                objArr2[c10] = Double.valueOf(jI2 / 1000000.0d);
                Log.d("CXCP", f.s(objArr2, 1, null, "%.3f ms", sbU2));
                return numValueOf;
            } catch (Throwable th2) {
                th = th2;
                Log.d("CXCP", f.s(new Object[]{Double.valueOf(f.i(jElapsedRealtimeNanos) / d2)}, 1, null, "%.3f ms", f.u(string, " - ")));
                throw th;
            }
        } catch (Throwable th3) {
            th = th3;
            d2 = 1000000.0d;
        }
    }

    @Override // a0.g2
    public final boolean S() throws Throwable {
        double d2;
        qi.b0 b0Var;
        StringBuilder sb2 = new StringBuilder("CXCP#abortCaptures-");
        h2 h2Var = this.f88e;
        sb2.append(h2Var.y());
        String string = sb2.toString();
        long jElapsedRealtimeNanos = SystemClock.elapsedRealtimeNanos();
        try {
            Trace.beginSection(string);
            String strY = h2Var.y();
            d2 = 1000000.0d;
            try {
                a2 a2Var = this.Y;
                try {
                    this.X.abortCaptures();
                    b0Var = qi.b0.f17350a;
                } catch (Exception e3) {
                    if (e3 instanceof CameraAccessException) {
                        Log.w("CXCP", "Failed to execute call: Camera encountered an error: " + e3.getMessage());
                        CameraAccessException cameraAccessException = (CameraAccessException) e3;
                        int reason = cameraAccessException.getReason();
                        int i10 = 3;
                        if (reason != 1) {
                            if (reason == 2) {
                                i10 = 6;
                            } else if (reason == 3) {
                                i10 = 0;
                            } else if (reason == 4) {
                                i10 = 1;
                            } else if (reason != 5) {
                                Log.w("CXCP", "Unexpected CameraAccessException: " + cameraAccessException);
                                i10 = 11;
                            } else {
                                i10 = 2;
                            }
                        }
                        a2Var.a(strY, true, i10);
                    } else if ((e3 instanceof IllegalArgumentException) || (e3 instanceof SecurityException) || (e3 instanceof UnsupportedOperationException) || (e3 instanceof NullPointerException)) {
                        Log.w("CXCP", "Failed to execute call: Unexpected exception: " + e3.getMessage());
                        a2Var.a(strY, false, 9);
                    } else {
                        if (!(e3 instanceof IllegalStateException)) {
                            throw e3;
                        }
                        Log.d("CXCP", "Failed to execute call: Camera may be closed");
                    }
                    b0Var = null;
                }
                Log.d("CXCP", f.s(new Object[]{Double.valueOf(f.i(jElapsedRealtimeNanos) / 1000000.0d)}, 1, null, "%.3f ms", f.u(string, " - ")));
                return b0Var != null;
            } catch (Throwable th2) {
                th = th2;
                Log.d("CXCP", f.s(new Object[]{Double.valueOf(f.i(jElapsedRealtimeNanos) / d2)}, 1, null, "%.3f ms", f.u(string, " - ")));
                throw th;
            }
        } catch (Throwable th3) {
            th = th3;
            d2 = 1000000.0d;
        }
    }

    @Override // a0.g2
    public final h2 V() {
        return this.f88e;
    }

    @Override // a0.g2
    public final Integer Y(CaptureRequest request, m1 m1Var) throws Throwable {
        double d2;
        char c10;
        Integer numValueOf;
        int i10;
        kotlin.jvm.internal.q.g(request, "request");
        StringBuilder sb2 = new StringBuilder("CXCP#capture-");
        h2 h2Var = this.f88e;
        sb2.append(h2Var.y());
        String string = sb2.toString();
        long jElapsedRealtimeNanos = SystemClock.elapsedRealtimeNanos();
        try {
            Trace.beginSection(string);
            String strY = h2Var.y();
            d2 = 1000000.0d;
            try {
                a2 a2Var = this.Y;
                try {
                    numValueOf = Integer.valueOf(this.X.capture(request, m1Var, this.Z));
                } catch (Exception e3) {
                    if (!(e3 instanceof CameraAccessException)) {
                        if ((e3 instanceof IllegalArgumentException) || (e3 instanceof SecurityException) || (e3 instanceof UnsupportedOperationException) || (e3 instanceof NullPointerException)) {
                            Log.w("CXCP", "Failed to execute call: Unexpected exception: " + e3.getMessage());
                            c10 = 0;
                            a2Var.a(strY, false, 9);
                            numValueOf = null;
                        } else {
                            if (!(e3 instanceof IllegalStateException)) {
                                throw e3;
                            }
                            Log.d("CXCP", "Failed to execute call: Camera may be closed");
                        }
                        long jI = f.i(jElapsedRealtimeNanos);
                        StringBuilder sbU = f.u(string, " - ");
                        Object[] objArr = new Object[1];
                        objArr[c10] = Double.valueOf(jI / 1000000.0d);
                        Log.d("CXCP", f.s(objArr, 1, null, "%.3f ms", sbU));
                        return numValueOf;
                    }
                    Log.w("CXCP", "Failed to execute call: Camera encountered an error: " + e3.getMessage());
                    CameraAccessException cameraAccessException = (CameraAccessException) e3;
                    int reason = cameraAccessException.getReason();
                    if (reason == 1) {
                        i10 = 3;
                    } else if (reason == 2) {
                        i10 = 6;
                    } else if (reason == 3) {
                        i10 = 0;
                    } else if (reason == 4) {
                        i10 = 1;
                    } else if (reason != 5) {
                        Log.w("CXCP", "Unexpected CameraAccessException: " + cameraAccessException);
                        i10 = 11;
                    } else {
                        i10 = 2;
                    }
                    a2Var.a(strY, true, i10);
                    numValueOf = null;
                }
                c10 = 0;
                long jI2 = f.i(jElapsedRealtimeNanos);
                StringBuilder sbU2 = f.u(string, " - ");
                Object[] objArr2 = new Object[1];
                objArr2[c10] = Double.valueOf(jI2 / 1000000.0d);
                Log.d("CXCP", f.s(objArr2, 1, null, "%.3f ms", sbU2));
                return numValueOf;
            } catch (Throwable th2) {
                th = th2;
                Log.d("CXCP", f.s(new Object[]{Double.valueOf(f.i(jElapsedRealtimeNanos) / d2)}, 1, null, "%.3f ms", f.u(string, " - ")));
                throw th;
            }
        } catch (Throwable th3) {
            th = th3;
            d2 = 1000000.0d;
        }
    }

    @Override // java.lang.AutoCloseable
    public final void close() {
        this.X.close();
    }

    @Override // a0.g2
    public final boolean f0(List list) throws Throwable {
        double d2;
        qi.b0 b0Var;
        if (Build.VERSION.SDK_INT < 26) {
            throw new IllegalStateException("Attempting to call finalizeOutputConfigurations before O is not supported and may lead to to unexpected behavior if an application is expects this call to succeed.");
        }
        StringBuilder sb2 = new StringBuilder("CXCP#finalizeOutputConfigurations-");
        h2 h2Var = this.f88e;
        sb2.append(h2Var.y());
        String string = sb2.toString();
        long jElapsedRealtimeNanos = SystemClock.elapsedRealtimeNanos();
        try {
            Trace.beginSection(string);
            String strY = h2Var.y();
            a2 a2Var = this.Y;
            try {
                CameraCaptureSession cameraCaptureSession = this.X;
                d2 = 1000000.0d;
                try {
                    try {
                        ArrayList arrayList = new ArrayList(ri.o.S(list, 10));
                        Iterator it = list.iterator();
                        while (it.hasNext()) {
                            arrayList.add(e.e(((x) ((r3) it.next())).D(kotlin.jvm.internal.e0.a(e.h()))));
                        }
                        a0.c(cameraCaptureSession, arrayList);
                        b0Var = qi.b0.f17350a;
                    } catch (Exception e3) {
                        e = e3;
                        if (e instanceof CameraAccessException) {
                            Log.w("CXCP", "Failed to execute call: Camera encountered an error: " + e.getMessage());
                            CameraAccessException cameraAccessException = (CameraAccessException) e;
                            int reason = cameraAccessException.getReason();
                            int i10 = 3;
                            if (reason != 1) {
                                if (reason == 2) {
                                    i10 = 6;
                                } else if (reason == 3) {
                                    i10 = 0;
                                } else if (reason == 4) {
                                    i10 = 1;
                                } else if (reason != 5) {
                                    Log.w("CXCP", "Unexpected CameraAccessException: " + cameraAccessException);
                                    i10 = 11;
                                } else {
                                    i10 = 2;
                                }
                            }
                            a2Var.a(strY, true, i10);
                        } else if ((e instanceof IllegalArgumentException) || (e instanceof SecurityException) || (e instanceof UnsupportedOperationException) || (e instanceof NullPointerException)) {
                            Log.w("CXCP", "Failed to execute call: Unexpected exception: " + e.getMessage());
                            a2Var.a(strY, false, 9);
                        } else {
                            if (!(e instanceof IllegalStateException)) {
                                throw e;
                            }
                            Log.d("CXCP", "Failed to execute call: Camera may be closed");
                        }
                        b0Var = null;
                    }
                    Log.d("CXCP", f.s(new Object[]{Double.valueOf(f.i(jElapsedRealtimeNanos) / d2)}, 1, null, "%.3f ms", f.u(string, " - ")));
                    return b0Var != null;
                } catch (Throwable th2) {
                    th = th2;
                    Log.d("CXCP", f.s(new Object[]{Double.valueOf(f.i(jElapsedRealtimeNanos) / d2)}, 1, null, "%.3f ms", f.u(string, " - ")));
                    throw th;
                }
            } catch (Exception e10) {
                e = e10;
                d2 = 1000000.0d;
            }
        } catch (Throwable th3) {
            th = th3;
            d2 = 1000000.0d;
        }
    }

    @Override // a0.g2
    public final boolean g0() throws Throwable {
        double d2;
        qi.b0 b0Var;
        StringBuilder sb2 = new StringBuilder("CXCP#stopRepeating-");
        h2 h2Var = this.f88e;
        sb2.append(h2Var.y());
        String string = sb2.toString();
        long jElapsedRealtimeNanos = SystemClock.elapsedRealtimeNanos();
        try {
            Trace.beginSection(string);
            String strY = h2Var.y();
            d2 = 1000000.0d;
            try {
                a2 a2Var = this.Y;
                try {
                    this.X.stopRepeating();
                    b0Var = qi.b0.f17350a;
                } catch (Exception e3) {
                    if (e3 instanceof CameraAccessException) {
                        Log.w("CXCP", "Failed to execute call: Camera encountered an error: " + e3.getMessage());
                        CameraAccessException cameraAccessException = (CameraAccessException) e3;
                        int reason = cameraAccessException.getReason();
                        int i10 = 3;
                        if (reason != 1) {
                            if (reason == 2) {
                                i10 = 6;
                            } else if (reason == 3) {
                                i10 = 0;
                            } else if (reason == 4) {
                                i10 = 1;
                            } else if (reason != 5) {
                                Log.w("CXCP", "Unexpected CameraAccessException: " + cameraAccessException);
                                i10 = 11;
                            } else {
                                i10 = 2;
                            }
                        }
                        a2Var.a(strY, true, i10);
                    } else if ((e3 instanceof IllegalArgumentException) || (e3 instanceof SecurityException) || (e3 instanceof UnsupportedOperationException) || (e3 instanceof NullPointerException)) {
                        Log.w("CXCP", "Failed to execute call: Unexpected exception: " + e3.getMessage());
                        a2Var.a(strY, false, 9);
                    } else {
                        if (!(e3 instanceof IllegalStateException)) {
                            throw e3;
                        }
                        Log.d("CXCP", "Failed to execute call: Camera may be closed");
                    }
                    b0Var = null;
                }
                Log.d("CXCP", f.s(new Object[]{Double.valueOf(f.i(jElapsedRealtimeNanos) / 1000000.0d)}, 1, null, "%.3f ms", f.u(string, " - ")));
                return b0Var != null;
            } catch (Throwable th2) {
                th = th2;
                Log.d("CXCP", f.s(new Object[]{Double.valueOf(f.i(jElapsedRealtimeNanos) / d2)}, 1, null, "%.3f ms", f.u(string, " - ")));
                throw th;
            }
        } catch (Throwable th3) {
            th = th3;
            d2 = 1000000.0d;
        }
    }

    @Override // a0.g2
    public final Surface getInputSurface() {
        return this.X.getInputSurface();
    }

    @Override // a0.g2
    public final Integer w(CaptureRequest request, m1 m1Var) throws Throwable {
        double d2;
        char c10;
        Integer numValueOf;
        int i10;
        kotlin.jvm.internal.q.g(request, "request");
        StringBuilder sb2 = new StringBuilder("CXCP#setRepeatingRequest-");
        h2 h2Var = this.f88e;
        sb2.append(h2Var.y());
        String string = sb2.toString();
        long jElapsedRealtimeNanos = SystemClock.elapsedRealtimeNanos();
        try {
            Trace.beginSection(string);
            String strY = h2Var.y();
            d2 = 1000000.0d;
            try {
                a2 a2Var = this.Y;
                try {
                    numValueOf = Integer.valueOf(this.X.setRepeatingRequest(request, m1Var, this.Z));
                } catch (Exception e3) {
                    if (!(e3 instanceof CameraAccessException)) {
                        if ((e3 instanceof IllegalArgumentException) || (e3 instanceof SecurityException) || (e3 instanceof UnsupportedOperationException) || (e3 instanceof NullPointerException)) {
                            Log.w("CXCP", "Failed to execute call: Unexpected exception: " + e3.getMessage());
                            c10 = 0;
                            a2Var.a(strY, false, 9);
                            numValueOf = null;
                        } else {
                            if (!(e3 instanceof IllegalStateException)) {
                                throw e3;
                            }
                            Log.d("CXCP", "Failed to execute call: Camera may be closed");
                        }
                        long jI = f.i(jElapsedRealtimeNanos);
                        StringBuilder sbU = f.u(string, " - ");
                        Object[] objArr = new Object[1];
                        objArr[c10] = Double.valueOf(jI / 1000000.0d);
                        Log.d("CXCP", f.s(objArr, 1, null, "%.3f ms", sbU));
                        return numValueOf;
                    }
                    Log.w("CXCP", "Failed to execute call: Camera encountered an error: " + e3.getMessage());
                    CameraAccessException cameraAccessException = (CameraAccessException) e3;
                    int reason = cameraAccessException.getReason();
                    if (reason == 1) {
                        i10 = 3;
                    } else if (reason == 2) {
                        i10 = 6;
                    } else if (reason == 3) {
                        i10 = 0;
                    } else if (reason == 4) {
                        i10 = 1;
                    } else if (reason != 5) {
                        Log.w("CXCP", "Unexpected CameraAccessException: " + cameraAccessException);
                        i10 = 11;
                    } else {
                        i10 = 2;
                    }
                    a2Var.a(strY, true, i10);
                    numValueOf = null;
                }
                c10 = 0;
                long jI2 = f.i(jElapsedRealtimeNanos);
                StringBuilder sbU2 = f.u(string, " - ");
                Object[] objArr2 = new Object[1];
                objArr2[c10] = Double.valueOf(jI2 / 1000000.0d);
                Log.d("CXCP", f.s(objArr2, 1, null, "%.3f ms", sbU2));
                return numValueOf;
            } catch (Throwable th2) {
                th = th2;
                Log.d("CXCP", f.s(new Object[]{Double.valueOf(f.i(jElapsedRealtimeNanos) / d2)}, 1, null, "%.3f ms", f.u(string, " - ")));
                throw th;
            }
        } catch (Throwable th3) {
            th = th3;
            d2 = 1000000.0d;
        }
    }
}
