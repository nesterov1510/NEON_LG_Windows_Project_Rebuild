package a0;

import android.content.ContentProviderClient;
import android.content.res.TypedArray;
import android.drm.DrmManagerClient;
import android.media.MediaDrm;
import android.media.MediaMetadataRetriever;
import android.os.SystemClock;
import android.os.Trace;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.EditText;
import com.google.android.gms.internal.measurement.c6;
import com.google.android.gms.internal.measurement.f6;
import com.google.android.gms.internal.measurement.v5;
import com.google.android.gms.internal.measurement.wg;
import com.google.android.gms.internal.measurement.x7;
import com.google.android.gms.internal.measurement.z5;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Locale;
import java.util.concurrent.ExecutorService;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public abstract /* synthetic */ class f {
    public static /* synthetic */ String A(int i10) {
        if (i10 == 1) {
            return "NONE";
        }
        if (i10 != 2) {
            return i10 != 3 ? kotlinx.serialization.json.internal.b.NULL : "REMOVING";
        }
        return "ADDING";
    }

    public static /* synthetic */ String B(int i10) {
        if (i10 == 1) {
            return "REMOVED";
        }
        if (i10 == 2) {
            return "VISIBLE";
        }
        if (i10 != 3) {
            return i10 != 4 ? kotlinx.serialization.json.internal.b.NULL : "INVISIBLE";
        }
        return "GONE";
    }

    public static /* synthetic */ String C(int i10) {
        switch (i10) {
            case 1:
                return "BEGIN_ARRAY";
            case 2:
                return "END_ARRAY";
            case 3:
                return "BEGIN_OBJECT";
            case 4:
                return "END_OBJECT";
            case 5:
                return "NAME";
            case 6:
                return "STRING";
            case 7:
                return "NUMBER";
            case 8:
                return "BOOLEAN";
            case 9:
                return "NULL";
            case 10:
                return "END_DOCUMENT";
            default:
                return kotlinx.serialization.json.internal.b.NULL;
        }
    }

    public static z5 D(v5 v5Var, c6 c6Var, x7 x7Var, ArrayList arrayList) {
        String str = c6Var.f4984e;
        if (v5Var.e(str)) {
            z5 z5VarA = v5Var.a(str);
            if (z5VarA instanceof com.google.android.gms.internal.measurement.n4) {
                return ((com.google.android.gms.internal.measurement.n4) z5VarA).f(x7Var, arrayList);
            }
            throw new IllegalArgumentException(kotlin.jvm.internal.p.B(str, " is not a function"));
        }
        if (!"hasOwnProperty".equals(str)) {
            throw new IllegalArgumentException(w.x0.u("Object has no function ", str));
        }
        wg.d(1, "hasOwnProperty", arrayList);
        return v5Var.e(((f6) x7Var.Y).e(x7Var, (z5) arrayList.get(0)).j()) ? z5.f5596g : z5.h;
    }

    public static androidx.lifecycle.x0 a(androidx.lifecycle.z0 z0Var, kotlin.jvm.internal.h hVar, f3.c cVar) {
        return z0Var.c(fk.j.q(hVar), cVar);
    }

    public static final void b(int i10, View view, ViewGroup container) {
        kotlin.jvm.internal.q.g(view, "view");
        kotlin.jvm.internal.q.g(container, "container");
        if (androidx.fragment.app.b1.M(2)) {
            Log.v("FragmentManager", "SpecialEffectsController: Calling apply state");
        }
        int iC = g0.t.c(i10);
        if (iC == 0) {
            ViewParent parent = view.getParent();
            ViewGroup viewGroup = parent instanceof ViewGroup ? (ViewGroup) parent : null;
            if (viewGroup != null) {
                if (androidx.fragment.app.b1.M(2)) {
                    Log.v("FragmentManager", "SpecialEffectsController: Removing view " + view + " from container " + viewGroup);
                }
                viewGroup.removeView(view);
                return;
            }
            return;
        }
        if (iC == 1) {
            if (androidx.fragment.app.b1.M(2)) {
                Log.v("FragmentManager", "SpecialEffectsController: Setting view " + view + " to VISIBLE");
            }
            ViewParent parent2 = view.getParent();
            if ((parent2 instanceof ViewGroup ? (ViewGroup) parent2 : null) == null) {
                if (androidx.fragment.app.b1.M(2)) {
                    Log.v("FragmentManager", "SpecialEffectsController: Adding view " + view + " to Container " + container);
                }
                container.addView(view);
            }
            view.setVisibility(0);
            return;
        }
        if (iC == 2) {
            if (androidx.fragment.app.b1.M(2)) {
                Log.v("FragmentManager", "SpecialEffectsController: Setting view " + view + " to GONE");
            }
            view.setVisibility(8);
            return;
        }
        if (iC != 3) {
            return;
        }
        if (androidx.fragment.app.b1.M(2)) {
            Log.v("FragmentManager", "SpecialEffectsController: Setting view " + view + " to INVISIBLE");
        }
        view.setVisibility(4);
    }

    public static /* synthetic */ int c(Object obj) {
        if (obj instanceof String) {
            return 2;
        }
        if (obj instanceof Boolean) {
            return 1;
        }
        if (obj instanceof Long) {
            return 3;
        }
        if (obj instanceof Double) {
            return 4;
        }
        throw new AssertionError("invalid tag type: ".concat(String.valueOf(obj.getClass())));
    }

    public static int d(int i10) {
        switch (i10) {
            case 0:
                return 1;
            case 1:
                return 2;
            case 2:
                return 3;
            case 3:
                return 4;
            case 4:
                return 5;
            case 5:
                return 6;
            case 6:
                return 7;
            case 7:
                return 8;
            case 8:
                return 9;
            default:
                switch (i10) {
                    case 20:
                        return 10;
                    case 21:
                        return 11;
                    case 22:
                        return 12;
                    default:
                        return 0;
                }
        }
    }

    public static /* synthetic */ boolean e(int i10) {
        if (i10 == 1 || i10 == 2 || i10 == 3) {
            return false;
        }
        if (i10 == 4 || i10 == 5) {
            return true;
        }
        throw null;
    }

    public static /* synthetic */ int f(int i10) {
        switch (i10) {
            case 1:
                return 0;
            case 2:
                return 1;
            case 3:
                return 2;
            case 4:
                return 3;
            case 5:
                return 4;
            case 6:
                return 5;
            case 7:
                return 6;
            case 8:
                return 7;
            case 9:
                return 8;
            case 10:
                return 20;
            case ue.r.NETWORK_CLIENT_ERROR_REASON_FIELD_NUMBER /* 11 */:
                return 21;
            case ue.r.CUSTOM_ATTRIBUTES_FIELD_NUMBER /* 12 */:
                return 22;
            default:
                throw null;
        }
    }

    public static int g(int i10, int i11, int i12) {
        return com.google.android.gms.internal.measurement.z0.o(i10) + i11 + i12;
    }

    public static int h(int i10, int i11, int i12, int i13) {
        return com.google.android.gms.internal.measurement.z0.o(i10) + i11 + i12 + i13;
    }

    public static long i(long j10) {
        Trace.endSection();
        return SystemClock.elapsedRealtimeNanos() - j10;
    }

    public static View j(ViewGroup viewGroup, int i10, ViewGroup viewGroup2, boolean z5) {
        return LayoutInflater.from(viewGroup.getContext()).inflate(i10, viewGroup2, z5);
    }

    public static ch.c k(b0.f fVar, int i10) {
        return ch.a.a(new b0.e(i10, 0, fVar));
    }

    public static com.google.android.gms.internal.measurement.s1 l(com.google.android.gms.internal.measurement.s1 s1Var) {
        int size = s1Var.size();
        return s1Var.P(size + size);
    }

    public static ClassCastException m(Iterator it) {
        it.next().getClass();
        return new ClassCastException();
    }

    public static String n(String str, androidx.fragment.app.d0 d0Var, String str2) {
        return str + d0Var + str2;
    }

    public static String o(String str, String str2, int i10, int i11) {
        return str + i10 + str2 + i11;
    }

    public static String p(StringBuilder sb2, int i10, char c10) {
        sb2.append(i10);
        sb2.append(c10);
        return sb2.toString();
    }

    public static String q(StringBuilder sb2, long j10, String str) {
        sb2.append(j10);
        sb2.append(str);
        return sb2.toString();
    }

    public static String r(StringBuilder sb2, String str, String str2) {
        sb2.append(str);
        sb2.append(str2);
        return sb2.toString();
    }

    public static String s(Object[] objArr, int i10, Locale locale, String str, StringBuilder sb2) {
        sb2.append(String.format(locale, str, Arrays.copyOf(objArr, i10)));
        return sb2.toString();
    }

    public static StringBuilder t(String str, Integer num, String str2, String str3, String str4) {
        StringBuilder sb2 = new StringBuilder(str);
        sb2.append(num);
        sb2.append(str2);
        sb2.append(str3);
        sb2.append(str4);
        return sb2;
    }

    public static StringBuilder u(String str, String str2) {
        StringBuilder sb2 = new StringBuilder();
        sb2.append(str);
        sb2.append(str2);
        return sb2;
    }

    public static /* synthetic */ void v(l1 l1Var) throws Exception {
        if (l1Var instanceof AutoCloseable) {
            l1Var.close();
        } else {
            if (!(l1Var instanceof ExecutorService)) {
                throw new IllegalArgumentException();
            }
            w.l();
        }
    }

    public static /* synthetic */ void w(f0.b bVar) throws Exception {
        if (bVar instanceof AutoCloseable) {
            bVar.close();
        } else {
            if (!(bVar instanceof ExecutorService)) {
                throw new IllegalArgumentException();
            }
            w.l();
        }
    }

    public static /* synthetic */ void x(Object obj) throws Exception {
        if (obj instanceof AutoCloseable) {
            ((AutoCloseable) obj).close();
            return;
        }
        if (obj instanceof ExecutorService) {
            w.g((ExecutorService) obj);
            return;
        }
        if (obj instanceof TypedArray) {
            ((TypedArray) obj).recycle();
            return;
        }
        if (obj instanceof MediaMetadataRetriever) {
            ((MediaMetadataRetriever) obj).release();
            return;
        }
        if (obj instanceof MediaDrm) {
            ((MediaDrm) obj).release();
        } else if (obj instanceof DrmManagerClient) {
            ((DrmManagerClient) obj).release();
        } else {
            if (!(obj instanceof ContentProviderClient)) {
                throw new IllegalArgumentException();
            }
            ((ContentProviderClient) obj).release();
        }
    }

    public static /* synthetic */ String y(int i10) {
        switch (i10) {
            case 1:
                return "CLIENT_UPLOAD_ELIGIBILITY_UNKNOWN";
            case 2:
                return "CLIENT_UPLOAD_ELIGIBLE";
            case 3:
                return "MEASUREMENT_SERVICE_NOT_ENABLED";
            case 4:
                return "ANDROID_TOO_OLD";
            case 5:
                return "NON_PLAY_MODE";
            case 6:
                return "SDK_TOO_OLD";
            case 7:
                return "MISSING_JOB_SCHEDULER";
            case 8:
                return "NOT_ENABLED_IN_MANIFEST";
            case 9:
                return "CLIENT_FLAG_OFF";
            case 10:
                return "SERVICE_FLAG_OFF";
            case ue.r.NETWORK_CLIENT_ERROR_REASON_FIELD_NUMBER /* 11 */:
                return "PINNED_TO_SERVICE_UPLOAD";
            case ue.r.CUSTOM_ATTRIBUTES_FIELD_NUMBER /* 12 */:
                return "MISSING_SGTM_SERVER_URL";
            default:
                throw null;
        }
    }

    public static void z(EditText... editTextArr) {
        if (editTextArr.length == 0) {
            return;
        }
        com.google.android.material.datepicker.i iVar = new com.google.android.material.datepicker.i(0, editTextArr);
        for (EditText editText : editTextArr) {
            editText.setOnFocusChangeListener(iVar);
        }
        EditText editText2 = editTextArr[0];
        editText2.postDelayed(new com.google.android.material.datepicker.j(editText2, 0), 100L);
    }
}
