package a0;

import android.animation.ObjectAnimator;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.airbnb.lottie.LottieAnimationView;
import com.google.android.gms.internal.measurement.mf;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import okhttp3.internal.url._UrlKt;
import okhttp3.internal.ws.WebSocketProtocol;
import tm.belet.films.R;
import tm.belet.films.domain.models.events.Group;
import tm.belet.films.domain.models.events.Members;
import tm.belet.films.domain.models.events.Team;
import tm.belet.films.domain.models.events.VoteInfo;
import tm.belet.films.domain.models.profile.ColoredUIComponentModel;
import tm.belet.films.domain.models.profile.ResponseModel;
import tm.belet.films.domain.models.profile.SwitchConfirmModel;
import tm.belet.films.domain.models.profile.SwitchInfoModel;
import tm.belet.films.domain.models.vcs.Version;
import tm.belet.films.domain.models.vote.MovieVoteMemberModel;
import tm.belet.films.presentation.activities.WebViewActivity;
import tm.belet.films.presentation.viewmodel.EventInfoViewModel;
import tm.belet.films.presentation.viewmodel.GiftCardViewModel;
import tm.belet.films.presentation.viewmodel.HomeViewModel;
import tm.belet.films.presentation.viewmodel.ListViewModel;
import tm.belet.films.presentation.viewmodel.SearchPageViewModel;
import tm.belet.films.presentation.widgets.CenterLayoutManager;
import tm.belet.films.presentation.widgets.design_system.PrimaryButton;
import tm.belet.films.presentation.widgets.qr_code_scanner.CodeScannerView;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class k1 implements kotlinx.coroutines.flow.j {
    public final /* synthetic */ Object X;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f158e;

    public /* synthetic */ k1(int i10, Object obj) {
        this.f158e = i10;
        this.X = obj;
    }

    private final Object a(Object obj, ui.d dVar) {
        tm.belet.films.presentation.viewmodel.p1 p1Var = (tm.belet.films.presentation.viewmodel.p1) obj;
        lo.a aVar = (lo.a) this.X;
        boolean z5 = p1Var.f19903a;
        String str = p1Var.f19904b;
        String strX = p1Var.f19906d;
        String str2 = p1Var.f19907e;
        if (z5) {
            dm.k kVar = aVar.f14580q1;
            if (kVar == null) {
                kotlin.jvm.internal.q.n("binding");
                throw null;
            }
            MaterialButton materialButton = kVar.f7034b;
            Context contextB0 = aVar.b0();
            Integer num = new Integer(R.color.dark_background_system);
            yb.k kVar2 = new yb.k(contextB0, null, 0, R.style.CustomCircularIndicator);
            kVar2.f22871e = new int[]{contextB0.getColor(num.intValue())};
            int i10 = yb.r.D0;
            materialButton.setIcon(yb.r.g(contextB0, kVar2, new yb.f(kVar2)));
            materialButton.setText(_UrlKt.FRAGMENT_ENCODE_SET);
            materialButton.setEnabled(false);
        } else if (!mj.l.m0(str2)) {
            dm.k kVar3 = aVar.f14580q1;
            if (kVar3 == null) {
                kotlin.jvm.internal.q.n("binding");
                throw null;
            }
            MaterialButton materialButton2 = kVar3.f7034b;
            materialButton2.setIcon(null);
            materialButton2.setText(aVar.x(R.string.yes));
            materialButton2.setEnabled(true);
            if (strX == null || mj.l.m0(strX)) {
                strX = aVar.x(R.string.live_events_error);
            }
            kotlin.jvm.internal.q.d(strX);
            androidx.fragment.app.a aVar2 = new androidx.fragment.app.a(aVar.v());
            String name = lo.n.class.getName();
            qi.i iVar = new qi.i("vote_id", new Integer(aVar.f14582s1));
            qi.i iVar2 = new qi.i("vote_member", aVar.f14583t1);
            qi.i iVar3 = new qi.i("vote_service", aVar.f14584u1);
            qi.i iVar4 = new qi.i("message_title", strX);
            qi.i iVar5 = new qi.i("server_message", str2);
            Integer num2 = p1Var.f19905c;
            aVar2.o(R.id.movie_vote_container, lo.n.class, ji.k.i(iVar, iVar2, iVar3, iVar4, iVar5, new qi.i("server_response", new Integer(num2 != null ? num2.intValue() : 500))), name);
            aVar2.d(lo.n.class.getName());
            aVar2.g();
        } else if (str != null) {
            dm.k kVar4 = aVar.f14580q1;
            if (kVar4 == null) {
                kotlin.jvm.internal.q.n("binding");
                throw null;
            }
            MaterialButton materialButton3 = kVar4.f7034b;
            materialButton3.setIcon(null);
            materialButton3.setText(aVar.x(R.string.yes));
            materialButton3.setEnabled(true);
            androidx.fragment.app.a aVar3 = new androidx.fragment.app.a(aVar.v());
            aVar3.o(R.id.movie_vote_container, lo.p.class, ji.k.i(new qi.i("vote_member", aVar.f14583t1), new qi.i("server_message", str)), lo.p.class.getName());
            aVar3.d(lo.p.class.getName());
            aVar3.g();
        }
        return qi.b0.f17350a;
    }

    private final Object b(Object obj, ui.d dVar) {
        VoteInfo voteInfo;
        tm.belet.films.presentation.viewmodel.k kVar = (tm.belet.films.presentation.viewmodel.k) obj;
        lo.c cVar = (lo.c) this.X;
        nm.c cVar2 = kVar.f19830b;
        qi.b0 b0Var = qi.b0.f17350a;
        if (cVar2 == null || (voteInfo = cVar2.f15992b) == null) {
            return b0Var;
        }
        List list = voteInfo.X;
        Group group = list != null ? (Group) ri.m.f0(list) : null;
        md.c cVar3 = cVar.f14599q1;
        if (cVar3 == null) {
            kotlin.jvm.internal.q.n("binding");
            throw null;
        }
        ((TextView) cVar3.h).setText(voteInfo.f19343s0);
        md.c cVar4 = cVar.f14599q1;
        if (cVar4 == null) {
            kotlin.jvm.internal.q.n("binding");
            throw null;
        }
        ((TextView) cVar4.f15311g).setText(voteInfo.f19344t0);
        md.c cVar5 = cVar.f14599q1;
        if (cVar5 == null) {
            kotlin.jvm.internal.q.n("binding");
            throw null;
        }
        ((MaterialButton) cVar5.f15309d).setText(voteInfo.f19342r0);
        md.c cVar6 = cVar.f14599q1;
        if (cVar6 == null) {
            kotlin.jvm.internal.q.n("binding");
            throw null;
        }
        ((TextView) cVar6.f15310e).setText(voteInfo.f19341e);
        md.c cVar7 = cVar.f14599q1;
        if (cVar7 == null) {
            kotlin.jvm.internal.q.n("binding");
            throw null;
        }
        TextView textView = (TextView) cVar7.f15307b;
        nm.b bVar = kVar.f19830b.f15991a;
        textView.setText(bVar != null ? bVar.f15981d : null);
        md.c cVar8 = cVar.f14599q1;
        if (cVar8 == null) {
            kotlin.jvm.internal.q.n("binding");
            throw null;
        }
        MaterialButton materialButton = (MaterialButton) cVar8.f15308c;
        String str = group != null ? group.X : null;
        if (str == null) {
            str = _UrlKt.FRAGMENT_ENCODE_SET;
        }
        materialButton.setText(str);
        md.c cVar9 = cVar.f14599q1;
        if (cVar9 == null) {
            kotlin.jvm.internal.q.n("binding");
            throw null;
        }
        ((MaterialButton) cVar9.f15308c).setOnClickListener(new ao.a(cVar, group, 20));
        md.c cVar10 = cVar.f14599q1;
        if (cVar10 != null) {
            ((MaterialButton) cVar10.f15309d).setOnClickListener(new bo.w(26, cVar));
            return b0Var;
        }
        kotlin.jvm.internal.q.n("binding");
        throw null;
    }

    private final Object c(Object obj, ui.d dVar) {
        VoteInfo voteInfo;
        tm.belet.films.presentation.viewmodel.k kVar = (tm.belet.films.presentation.viewmodel.k) obj;
        lo.f fVar = (lo.f) this.X;
        nm.c cVar = kVar.f19830b;
        qi.b0 b0Var = qi.b0.f17350a;
        if (cVar == null || (voteInfo = cVar.f15992b) == null) {
            return b0Var;
        }
        Collection collection = voteInfo.X;
        if (collection == null) {
            collection = ri.s.f18050e;
        }
        a4.n nVar = fVar.f14608q1;
        if (nVar == null) {
            kotlin.jvm.internal.q.n("binding");
            throw null;
        }
        ((TextView) nVar.f).setText(voteInfo.f19343s0);
        a4.n nVar2 = fVar.f14608q1;
        if (nVar2 == null) {
            kotlin.jvm.internal.q.n("binding");
            throw null;
        }
        ((TextView) nVar2.f519e).setText(voteInfo.f19344t0);
        a4.n nVar3 = fVar.f14608q1;
        if (nVar3 == null) {
            kotlin.jvm.internal.q.n("binding");
            throw null;
        }
        ((TextView) nVar3.f517c).setText(voteInfo.f19341e);
        a4.n nVar4 = fVar.f14608q1;
        if (nVar4 == null) {
            kotlin.jvm.internal.q.n("binding");
            throw null;
        }
        TextView textView = (TextView) nVar4.f515a;
        nm.b bVar = kVar.f19830b.f15991a;
        textView.setText(bVar != null ? bVar.f15981d : null);
        a4.n nVar5 = fVar.f14608q1;
        if (nVar5 != null) {
            ((RecyclerView) nVar5.f516b).setAdapter(new ao.c(ri.m.B0(collection), (ej.l) new lo.e(fVar, 1), 8));
            return b0Var;
        }
        kotlin.jvm.internal.q.n("binding");
        throw null;
    }

    private final Object d(Object obj, ui.d dVar) {
        VoteInfo voteInfo = (VoteInfo) obj;
        lo.i iVar = (lo.i) this.X;
        List list = voteInfo != null ? voteInfo.X : null;
        if (list == null) {
            list = ri.s.f18050e;
        }
        y4 y4Var = iVar.f14617q1;
        if (y4Var == null) {
            kotlin.jvm.internal.q.n("binding");
            throw null;
        }
        ((TextView) y4Var.f396r0).setText(voteInfo != null ? voteInfo.f19343s0 : null);
        y4 y4Var2 = iVar.f14617q1;
        if (y4Var2 == null) {
            kotlin.jvm.internal.q.n("binding");
            throw null;
        }
        ((TextView) y4Var2.Z).setText(voteInfo != null ? voteInfo.f19344t0 : null);
        y4 y4Var3 = iVar.f14617q1;
        if (y4Var3 == null) {
            kotlin.jvm.internal.q.n("binding");
            throw null;
        }
        ((TextView) y4Var3.X).setText(voteInfo != null ? voteInfo.f19341e : null);
        y4 y4Var4 = iVar.f14617q1;
        if (y4Var4 != null) {
            ((RecyclerView) y4Var4.f395e).setAdapter(new ao.c(ri.m.B0(list), (ej.l) new lo.h(iVar, 1), 10));
            return qi.b0.f17350a;
        }
        kotlin.jvm.internal.q.n("binding");
        throw null;
    }

    private final Object e(Object obj, ui.d dVar) {
        List list;
        Group group;
        List list2;
        Group group2;
        Long l10;
        VoteInfo voteInfo = (VoteInfo) obj;
        lo.k kVar = (lo.k) this.X;
        a4.n nVar = kVar.f14624q1;
        if (nVar == null) {
            kotlin.jvm.internal.q.n("binding");
            throw null;
        }
        ((TextView) nVar.f).setText(voteInfo != null ? voteInfo.f19343s0 : null);
        a4.n nVar2 = kVar.f14624q1;
        if (nVar2 == null) {
            kotlin.jvm.internal.q.n("binding");
            throw null;
        }
        ((TextView) nVar2.f519e).setText(voteInfo != null ? voteInfo.f19344t0 : null);
        a4.n nVar3 = kVar.f14624q1;
        if (nVar3 == null) {
            kotlin.jvm.internal.q.n("binding");
            throw null;
        }
        ((MaterialButton) nVar3.f516b).setText(voteInfo != null ? voteInfo.f19342r0 : null);
        a4.n nVar4 = kVar.f14624q1;
        if (nVar4 == null) {
            kotlin.jvm.internal.q.n("binding");
            throw null;
        }
        ((TextView) nVar4.f517c).setText(voteInfo != null ? voteInfo.f19341e : null);
        a4.n nVar5 = kVar.f14624q1;
        if (nVar5 == null) {
            kotlin.jvm.internal.q.n("binding");
            throw null;
        }
        MaterialButton materialButton = (MaterialButton) nVar5.f515a;
        Long l11 = new Long((voteInfo == null || (list2 = voteInfo.X) == null || (group2 = (Group) ri.m.f0(list2)) == null || (l10 = group2.Y) == null) ? 1L : l10.longValue());
        String str = (voteInfo == null || (list = voteInfo.X) == null || (group = (Group) ri.m.f0(list)) == null) ? null : group.X;
        if (str == null) {
            str = _UrlKt.FRAGMENT_ENCODE_SET;
        }
        materialButton.setText(kVar.y(new Object[]{l11, str}, R.string.vote_position));
        a4.n nVar6 = kVar.f14624q1;
        if (nVar6 == null) {
            kotlin.jvm.internal.q.n("binding");
            throw null;
        }
        ((MaterialButton) nVar6.f515a).setOnClickListener(new ao.a(kVar, voteInfo, 21));
        a4.n nVar7 = kVar.f14624q1;
        if (nVar7 != null) {
            ((MaterialButton) nVar7.f516b).setOnClickListener(new bo.w(27, kVar));
            return qi.b0.f17350a;
        }
        kotlin.jvm.internal.q.n("binding");
        throw null;
    }

    private final Object f(Object obj, ui.d dVar) {
        tm.belet.films.presentation.viewmodel.w1 w1Var = (tm.belet.films.presentation.viewmodel.w1) obj;
        lo.n nVar = (lo.n) this.X;
        boolean z5 = w1Var.f19977a;
        String str = w1Var.f19979c;
        zm.a aVar = w1Var.f19978b;
        if (z5) {
            dm.k kVar = nVar.f14632q1;
            if (kVar == null) {
                kotlin.jvm.internal.q.n("binding");
                throw null;
            }
            MaterialButton materialButton = kVar.f7034b;
            Context contextB0 = nVar.b0();
            Integer num = new Integer(R.color.dark_background_system);
            yb.k kVar2 = new yb.k(contextB0, null, 0, R.style.CustomCircularIndicator);
            kVar2.f22871e = new int[]{contextB0.getColor(num.intValue())};
            int i10 = yb.r.D0;
            materialButton.setIcon(yb.r.g(contextB0, kVar2, new yb.f(kVar2)));
            materialButton.setText(_UrlKt.FRAGMENT_ENCODE_SET);
            materialButton.setEnabled(false);
        } else if (!mj.l.m0(str)) {
            dm.k kVar3 = nVar.f14632q1;
            if (kVar3 == null) {
                kotlin.jvm.internal.q.n("binding");
                throw null;
            }
            MaterialButton materialButton2 = kVar3.f7034b;
            materialButton2.setIcon(null);
            materialButton2.setText(nVar.x(R.string.top_up_balance));
            materialButton2.setEnabled(true);
            oo.c.d(nVar.b0(), oo.l.ERROR, str, null, (24 & 16) == 0);
        } else if (aVar != null) {
            String str2 = aVar.f23621a;
            dm.k kVar4 = nVar.f14632q1;
            if (kVar4 == null) {
                kotlin.jvm.internal.q.n("binding");
                throw null;
            }
            MaterialButton materialButton3 = kVar4.f7034b;
            materialButton3.setIcon(null);
            materialButton3.setText(nVar.x(R.string.top_up_balance));
            materialButton3.setEnabled(true);
            if (str2.length() > 0) {
                Intent intent = new Intent(nVar.j(), (Class<?>) WebViewActivity.class);
                intent.putExtra("link", str2);
                intent.putExtra("is_profile", true);
                nVar.g0(intent);
                androidx.fragment.app.d0 d0Var = nVar.J0;
                nb.d dVar2 = d0Var instanceof nb.d ? (nb.d) d0Var : null;
                if (dVar2 != null) {
                    dVar2.o0();
                }
            }
        }
        return qi.b0.f17350a;
    }

    private final Object g(Object obj, ui.d dVar) {
        tm.belet.films.presentation.viewmodel.o oVar = (tm.belet.films.presentation.viewmodel.o) obj;
        lo.r rVar = (lo.r) this.X;
        boolean z5 = oVar.f19879a;
        String str = oVar.f19880b;
        String strX = oVar.f19882d;
        String str2 = oVar.f19883e;
        if (z5) {
            dm.k kVar = rVar.f14650q1;
            if (kVar == null) {
                kotlin.jvm.internal.q.n("binding");
                throw null;
            }
            MaterialButton materialButton = kVar.f7034b;
            Context contextB0 = rVar.b0();
            Integer num = new Integer(R.color.dark_background_system);
            yb.k kVar2 = new yb.k(contextB0, null, 0, R.style.CustomCircularIndicator);
            kVar2.f22871e = new int[]{contextB0.getColor(num.intValue())};
            int i10 = yb.r.D0;
            materialButton.setIcon(yb.r.g(contextB0, kVar2, new yb.f(kVar2)));
            materialButton.setText(_UrlKt.FRAGMENT_ENCODE_SET);
            materialButton.setEnabled(false);
        } else if (!mj.l.m0(str2)) {
            dm.k kVar3 = rVar.f14650q1;
            if (kVar3 == null) {
                kotlin.jvm.internal.q.n("binding");
                throw null;
            }
            MaterialButton materialButton2 = kVar3.f7034b;
            materialButton2.setIcon(null);
            materialButton2.setText(rVar.x(R.string.yes));
            materialButton2.setEnabled(true);
            if (strX == null || mj.l.m0(strX)) {
                strX = rVar.x(R.string.live_events_error);
            }
            kotlin.jvm.internal.q.d(strX);
            androidx.fragment.app.a aVar = new androidx.fragment.app.a(rVar.v());
            String name = lo.y.class.getName();
            Bundle bundle = new Bundle();
            bundle.putString("message_title", strX);
            bundle.putString("server_message", str2);
            Integer num2 = oVar.f19881c;
            bundle.putInt("server_response", num2 != null ? num2.intValue() : 500);
            aVar.o(R.id.main_event_container, lo.y.class, bundle, name);
            aVar.d(lo.y.class.getName());
            aVar.g();
        } else if (str != null) {
            dm.k kVar4 = rVar.f14650q1;
            if (kVar4 == null) {
                kotlin.jvm.internal.q.n("binding");
                throw null;
            }
            MaterialButton materialButton3 = kVar4.f7034b;
            materialButton3.setIcon(null);
            materialButton3.setText(rVar.x(R.string.yes));
            materialButton3.setEnabled(true);
            androidx.fragment.app.a aVar2 = new androidx.fragment.app.a(rVar.v());
            String name2 = lo.b0.class.getName();
            Bundle bundle2 = new Bundle();
            bundle2.putParcelable("team_info", rVar.f14654u1);
            bundle2.putString("server_message", str);
            aVar2.o(R.id.main_event_container, lo.b0.class, bundle2, name2);
            aVar2.d(lo.b0.class.getName());
            aVar2.g();
        }
        return qi.b0.f17350a;
    }

    private final Object h(Object obj, ui.d dVar) throws Throwable {
        boolean z5;
        androidx.recyclerview.widget.b1 centerLayoutManager;
        tm.belet.films.presentation.viewmodel.p pVar;
        Float f;
        String str;
        Long l10;
        tm.belet.films.presentation.viewmodel.p pVar2 = (tm.belet.films.presentation.viewmodel.p) obj;
        lo.u uVar = (lo.u) this.X;
        boolean z6 = pVar2.f19897a;
        String str2 = pVar2.f19899c;
        Members members = pVar2.f19898b;
        Throwable th2 = null;
        int i10 = 0;
        if (z6) {
            m7.p pVar3 = uVar.f14662q1;
            if (pVar3 == null) {
                kotlin.jvm.internal.q.n("binding");
                throw null;
            }
            ((dm.u) pVar3.f).f7176a.setVisibility(0);
            ((LinearLayout) pVar3.f15187e).setVisibility(4);
        } else if (!mj.l.m0(str2)) {
            m7.p pVar4 = uVar.f14662q1;
            if (pVar4 == null) {
                kotlin.jvm.internal.q.n("binding");
                throw null;
            }
            ((dm.u) pVar4.f).f7176a.setVisibility(8);
            ((TextView) pVar4.f15190j).setText(str2);
            ((MaterialButton) pVar4.f15184b).setVisibility(4);
            ((LinearLayout) pVar4.f15187e).setVisibility(0);
        } else if (members != null) {
            String str3 = members.f19335r0;
            m7.p pVar5 = uVar.f14662q1;
            if (pVar5 == null) {
                kotlin.jvm.internal.q.n("binding");
                throw null;
            }
            ((dm.u) pVar5.f).f7176a.setVisibility(8);
            m7.p pVar6 = uVar.f14662q1;
            if (pVar6 == null) {
                kotlin.jvm.internal.q.n("binding");
                throw null;
            }
            ((LinearLayout) pVar6.f15187e).setVisibility(0);
            List list = members.X;
            if (list == null) {
                list = ri.s.f18050e;
            }
            List<Team> list2 = list;
            boolean z9 = true;
            boolean z10 = list2.size() == 2;
            if (list2.isEmpty()) {
                z5 = false;
                break;
            }
            Iterator it = list2.iterator();
            while (true) {
                if (!it.hasNext()) {
                    z5 = false;
                    break;
                }
                Team team = (Team) it.next();
                if (team != null ? kotlin.jvm.internal.q.c(team.f19340t0, Boolean.TRUE) : false) {
                    z5 = true;
                    break;
                }
            }
            uVar.f14667v1 = z5 || kotlin.jvm.internal.q.c(members.f19336s0, Boolean.FALSE);
            long jLongValue = 0;
            for (Team team2 : list2) {
                Throwable th3 = th2;
                jLongValue += (team2 == null || (l10 = team2.Z) == null) ? 0L : l10.longValue();
                th2 = th3;
            }
            Throwable th4 = th2;
            if (jLongValue <= 0) {
                Long l11 = members.Y;
                if ((l11 != null ? l11.longValue() : 0L) <= 0) {
                    z9 = false;
                }
            }
            uVar.f14668w1 = z9;
            m7.p pVar7 = uVar.f14662q1;
            if (pVar7 == null) {
                kotlin.jvm.internal.q.n("binding");
                throw th4;
            }
            RecyclerView recyclerView = (RecyclerView) pVar7.f15186d;
            if (z10) {
                uVar.b0();
                centerLayoutManager = new GridLayoutManager(2);
            } else {
                uVar.b0();
                centerLayoutManager = new CenterLayoutManager(0);
            }
            recyclerView.setLayoutManager(centerLayoutManager);
            ArrayList arrayList = new ArrayList(ri.o.S(list2, 10));
            for (Team team3 : list2) {
                arrayList.add(new Integer((team3 == null || (str = team3.u0) == null) ? Color.parseColor("#0057D4") : ta.f.L(str)));
            }
            m7.p pVar8 = uVar.f14662q1;
            if (pVar8 == null) {
                kotlin.jvm.internal.q.n("binding");
                throw th4;
            }
            ((RecyclerView) pVar8.f15186d).setAdapter(new yn.i2(list2, uVar.f14667v1, uVar.f14668w1, z10, new lo.t(uVar, arrayList, list2)));
            m7.p pVar9 = uVar.f14662q1;
            if (pVar9 == null) {
                kotlin.jvm.internal.q.n("binding");
                throw th4;
            }
            TextView textView = (TextView) pVar9.f15191k;
            MaterialButton materialButton = (MaterialButton) pVar9.f15184b;
            MaterialCardView materialCardView = (MaterialCardView) pVar9.f15185c;
            TextView textView2 = (TextView) pVar9.f15188g;
            TextView textView3 = (TextView) pVar9.f15189i;
            ((TextView) pVar9.f15190j).setText(members.f19334e);
            textView3.setText(members.Z);
            textView2.setText(str3);
            if (uVar.f14668w1) {
                materialCardView.setVisibility(0);
                LinearLayout linearLayout = (LinearLayout) pVar9.h;
                ArrayList arrayList2 = new ArrayList(ri.o.S(list2, 10));
                for (Team team4 : list2) {
                    arrayList2.add(new Float((team4 == null || (f = team4.f19339s0) == null) ? 0.0f : f.floatValue()));
                }
                linearLayout.removeAllViews();
                ArrayList arrayList3 = uVar.f14669x1;
                arrayList3.clear();
                int size = arrayList2.size();
                int i11 = 0;
                while (i10 < size) {
                    Object obj2 = arrayList2.get(i10);
                    int i12 = i10 + 1;
                    int i13 = i11 + 1;
                    if (i11 < 0) {
                        ri.n.R();
                        throw th4;
                    }
                    float fFloatValue = ((Number) obj2).floatValue();
                    ArrayList arrayList4 = arrayList2;
                    View view = new View(linearLayout.getContext());
                    int i14 = size;
                    tm.belet.films.presentation.viewmodel.p pVar10 = pVar2;
                    LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(0, -1, fFloatValue);
                    if (i11 != ri.n.N(arrayList4)) {
                        layoutParams.setMarginEnd(ji.k.G(0.0f));
                    }
                    view.setLayoutParams(layoutParams);
                    view.setBackgroundColor(((Number) arrayList.get(i11)).intValue());
                    arrayList3.add(view);
                    linearLayout.addView(view);
                    arrayList2 = arrayList4;
                    i11 = i13;
                    i10 = i12;
                    size = i14;
                    pVar2 = pVar10;
                }
                pVar = pVar2;
                textView3.setTypeface(z1.k.b(uVar.b0(), R.font.belet_sans_bold));
                textView3.setTextColor(((ConstraintLayout) pVar9.f15183a).getContext().getColor(R.color.gray_15));
            } else {
                pVar = pVar2;
                materialCardView.setVisibility(8);
                textView3.setTypeface(z1.k.b(uVar.b0(), R.font.belet_sans_regular));
                textView3.setTextColor(uVar.b0().getColor(R.color.gray_14));
            }
            if (uVar.f14667v1) {
                textView2.setVisibility(8);
                materialButton.setVisibility(8);
                textView.setText(str3);
                textView.setVisibility(0);
            }
            materialButton.setOnClickListener(new ao.a(uVar, pVar, 22));
        }
        return qi.b0.f17350a;
    }

    private final Object i(Object obj, ui.d dVar) {
        Object objG;
        p2.z zVar = (p2.z) this.X;
        return ((zVar.h.p() instanceof p2.i0) || (objG = p2.z.g(zVar, true, dVar)) != vi.a.f21252e) ? qi.b0.f17350a : objG;
    }

    private final Object j(Object obj, ui.d dVar) {
        nk.d dVar2 = (nk.d) obj;
        kotlinx.coroutines.flow.h0 h0Var = ((GiftCardViewModel) this.X).f19506c;
        if (dVar2 instanceof nk.b) {
            h0Var.setValue(new tm.belet.films.presentation.viewmodel.t(null, null, null, 13));
        } else if (dVar2 instanceof nk.a) {
            nk.a aVar = (nk.a) dVar2;
            String str = aVar.f15966b;
            if (str == null) {
                str = "An UnexpectedError";
            }
            h0Var.setValue(new tm.belet.films.presentation.viewmodel.t(null, str, aVar.f15967c, 3));
        } else {
            if (!(dVar2 instanceof nk.c)) {
                throw new ad.n(11);
            }
            h0Var.setValue(new tm.belet.films.presentation.viewmodel.t((bn.a) ((nk.c) dVar2).f15965a, null, null, 14));
        }
        return qi.b0.f17350a;
    }

    private final Object k(Object obj, ui.d dVar) {
        nk.d dVar2 = (nk.d) obj;
        kotlinx.coroutines.flow.h0 h0Var = ((HomeViewModel) this.X).f19518l;
        if (dVar2 instanceof nk.b) {
            h0Var.setValue(new tm.belet.films.presentation.viewmodel.v(null, null, 6));
        } else if (dVar2 instanceof nk.a) {
            String str = ((nk.a) dVar2).f15966b;
            if (str == null) {
                str = "An UnexpectedError";
            }
            h0Var.setValue(new tm.belet.films.presentation.viewmodel.v(null, str, 3));
        } else {
            if (!(dVar2 instanceof nk.c)) {
                throw new ad.n(11);
            }
            h0Var.setValue(new tm.belet.films.presentation.viewmodel.v((qm.b) ((nk.c) dVar2).f15965a, null, 5));
        }
        return qi.b0.f17350a;
    }

    private final Object l(Object obj, ui.d dVar) {
        nk.d dVar2 = (nk.d) obj;
        kotlinx.coroutines.flow.h0 h0Var = ((ListViewModel) this.X).f19536d;
        if (dVar2 instanceof nk.b) {
            h0Var.setValue(new tm.belet.films.presentation.viewmodel.m0(null, null, 5));
        } else if (dVar2 instanceof nk.a) {
            String str = ((nk.a) dVar2).f15966b;
            if (str == null) {
                str = "An UnexpectedError";
            }
            h0Var.setValue(new tm.belet.films.presentation.viewmodel.m0(null, str, 3));
        } else {
            if (!(dVar2 instanceof nk.c)) {
                throw new ad.n(11);
            }
            h0Var.setValue(new tm.belet.films.presentation.viewmodel.m0((lm.b) ((nk.c) dVar2).f15965a, null, 6));
        }
        return qi.b0.f17350a;
    }

    /* JADX WARN: Code duplicated, block: B:142:0x0313  */
    /* JADX WARN: Code duplicated, block: B:144:0x032f  */
    /* JADX WARN: Code duplicated, block: B:146:0x035f  */
    /* JADX WARN: Code duplicated, block: B:147:0x036c  */
    /* JADX WARN: Code duplicated, block: B:149:0x0370  */
    /* JADX WARN: Code duplicated, block: B:151:0x0374  */
    /* JADX WARN: Code duplicated, block: B:153:0x0378  */
    /* JADX WARN: Code duplicated, block: B:155:0x0394  */
    /* JADX WARN: Code duplicated, block: B:156:0x03a1  */
    /* JADX WARN: Code duplicated, block: B:158:0x03a5  */
    /* JADX WARN: Code duplicated, block: B:307:0x086d  */
    /* JADX WARN: Code duplicated, block: B:311:0x0876  */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r16v3, types: [java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r2v33, types: [android.widget.Spinner] */
    /* JADX WARN: Type inference failed for: r3v42, types: [java.lang.Iterable, java.lang.Object, java.util.Collection] */
    /* JADX WARN: Type inference failed for: r5v12, types: [android.widget.Spinner] */
    /* JADX WARN: Type inference failed for: r5v23 */
    /* JADX WARN: Type inference failed for: r5v24, types: [java.lang.Integer] */
    /* JADX WARN: Type inference failed for: r5v87 */
    /* JADX WARN: Type inference failed for: r8v20 */
    /* JADX WARN: Type inference failed for: r8v21 */
    /* JADX WARN: Type inference failed for: r8v3, types: [android.graphics.drawable.Drawable] */
    /* JADX WARN: Type inference failed for: r8v4 */
    /* JADX WARN: Type inference failed for: r8v5 */
    /* JADX WARN: Type inference failed for: r8v6, types: [android.widget.SpinnerAdapter] */
    @Override // kotlinx.coroutines.flow.j
    public final Object emit(Object obj, ui.d dVar) {
        Object objEmit;
        nm.b bVar;
        final Version version;
        String str;
        hm.s sVar;
        hm.s sVar2;
        hm.s sVar3;
        hm.s sVar4;
        ?? r9;
        ?? r10;
        ?? num;
        String str2;
        rm.c cVar;
        rm.c cVar2;
        nm.b bVar2;
        mf mfVar;
        mf mfVar2;
        mf mfVar3;
        mf mfVar4;
        ColoredUIComponentModel coloredUIComponentModel;
        ColoredUIComponentModel coloredUIComponentModel2;
        nb.d dVar2 = null;
        boolean z5 = true;
        z5 = true;
        final int iIntValue = 0;
        switch (this.f158e) {
            case 0:
                e0.l lVar = (e0.l) obj;
                l1 l1Var = (l1) this.X;
                qi.b0 b0Var = qi.b0.f17350a;
                if (lVar instanceof e0.h) {
                    objEmit = l1Var.f171s0.emit(lVar, dVar);
                    if (objEmit != vi.a.f21252e) {
                        return b0Var;
                    }
                } else if (lVar instanceof e0.j) {
                    objEmit = l1Var.f171s0.emit(lVar, dVar);
                    if (objEmit != vi.a.f21252e) {
                        return b0Var;
                    }
                } else if (!(lVar instanceof e0.i) || (objEmit = l1Var.u0.emit(b0Var, dVar)) != vi.a.f21252e) {
                    return b0Var;
                }
                return objEmit;
            case 1:
                l2 l2Var = (l2) obj;
                b5 b5Var = (b5) this.X;
                synchronized (b5Var.f24e) {
                    try {
                        if (l2Var instanceof o2) {
                            z4 z4Var = new z4((i) ((o2) l2Var).f256a);
                            b5Var.f25g = z4Var;
                            b5Var.b(new o2(z4Var));
                        } else {
                            b5Var.b(l2Var);
                        }
                    } catch (Throwable th2) {
                        throw th2;
                    }
                }
                return qi.b0.f17350a;
            case 2:
                bf.m0 m0Var = (bf.m0) obj;
                bf.h1 h1Var = (bf.h1) this.X;
                kotlin.jvm.internal.q.g(m0Var, "<set-?>");
                h1Var.h = m0Var;
                if (h1Var.f3585j) {
                    h1Var.f3585j = false;
                    h1Var.c();
                }
                Object objA = bf.h1.a(h1Var, m0Var.f3625a.f3639a, bf.e1.f3551e, dVar);
                return objA == vi.a.f21252e ? objA : qi.b0.f17350a;
            case 3:
                nm.c cVar3 = ((tm.belet.films.presentation.viewmodel.k) obj).f19830b;
                if (cVar3 != null && (bVar = cVar3.f15991a) != null) {
                    eo.v0 v0Var = (eo.v0) this.X;
                    boolean zC = kotlin.jvm.internal.q.c(bVar.f15982e, Boolean.TRUE);
                    v0Var.K1 = zC;
                    v0Var.L1 = zC;
                }
                return qi.b0.f17350a;
            case 4:
                tm.belet.films.presentation.viewmodel.u3 u3Var = (tm.belet.films.presentation.viewmodel.u3) obj;
                if (!u3Var.f19963a && mj.l.m0(u3Var.f19965c) && (version = u3Var.f19964b) != null) {
                    final eo.p2 p2Var = (eo.p2) this.X;
                    v2 v2Var = p2Var.G1;
                    if (v2Var == null) {
                        kotlin.jvm.internal.q.n("binding");
                        throw null;
                    }
                    ((TextView) v2Var.f365e).setText(p2Var.x(R.string.update_optional));
                    ((TextView) v2Var.f364d).setText(p2Var.y(new Object[]{version.Y}, R.string.update_version));
                    RecyclerView recyclerView = (RecyclerView) v2Var.f363c;
                    List list = version.f19356r0;
                    if (list == null) {
                        list = ri.s.f18050e;
                    }
                    recyclerView.setAdapter(new androidx.recyclerview.widget.d(list));
                    ((MaterialButton) v2Var.h).setOnClickListener(new View.OnClickListener() { // from class: eo.o2
                        @Override // android.view.View.OnClickListener
                        public final void onClick(View view) {
                            switch (iIntValue) {
                                case 0:
                                    Context contextB0 = p2Var.b0();
                                    Version version2 = version;
                                    String str3 = version2 != null ? version2.f19355e : null;
                                    Intent data = new Intent("android.intent.action.VIEW").setData(str3 != null ? Uri.parse(str3) : null);
                                    kotlin.jvm.internal.q.f(data, "setData(...)");
                                    try {
                                        contextB0.startActivity(data);
                                    } catch (Exception unused) {
                                        oo.c.e(contextB0, oo.l.ERROR, R.string.no_browser_available);
                                        return;
                                    }
                                    break;
                                default:
                                    Context contextB1 = p2Var.b0();
                                    Version version3 = version;
                                    String str4 = version3 != null ? version3.X : null;
                                    Intent data2 = new Intent("android.intent.action.VIEW").setData(str4 != null ? Uri.parse(str4) : null);
                                    kotlin.jvm.internal.q.f(data2, "setData(...)");
                                    try {
                                        contextB1.startActivity(data2);
                                    } catch (Exception unused2) {
                                        oo.c.e(contextB1, oo.l.ERROR, R.string.no_browser_available);
                                    }
                                    break;
                            }
                        }
                    });
                    MaterialButton materialButton = (MaterialButton) v2Var.f;
                    final int i10 = z5 ? 1 : 0;
                    materialButton.setOnClickListener(new View.OnClickListener() { // from class: eo.o2
                        @Override // android.view.View.OnClickListener
                        public final void onClick(View view) {
                            switch (i10) {
                                case 0:
                                    Context contextB0 = p2Var.b0();
                                    Version version2 = version;
                                    String str3 = version2 != null ? version2.f19355e : null;
                                    Intent data = new Intent("android.intent.action.VIEW").setData(str3 != null ? Uri.parse(str3) : null);
                                    kotlin.jvm.internal.q.f(data, "setData(...)");
                                    try {
                                        contextB0.startActivity(data);
                                    } catch (Exception unused) {
                                        oo.c.e(contextB0, oo.l.ERROR, R.string.no_browser_available);
                                        return;
                                    }
                                    break;
                                default:
                                    Context contextB1 = p2Var.b0();
                                    Version version3 = version;
                                    String str4 = version3 != null ? version3.X : null;
                                    Intent data2 = new Intent("android.intent.action.VIEW").setData(str4 != null ? Uri.parse(str4) : null);
                                    kotlin.jvm.internal.q.f(data2, "setData(...)");
                                    try {
                                        contextB1.startActivity(data2);
                                    } catch (Exception unused2) {
                                        oo.c.e(contextB1, oo.l.ERROR, R.string.no_browser_available);
                                    }
                                    break;
                            }
                        }
                    });
                }
                return qi.b0.f17350a;
            case 5:
                FrameLayout loader = (FrameLayout) ((go.b) this.X).h0().Y;
                kotlin.jvm.internal.q.f(loader, "loader");
                loader.setVisibility(((y5.h) obj).f22635a instanceof y5.x ? 0 : 8);
                return qi.b0.f17350a;
            case 6:
                Object obj2 = (List) obj;
                ao.c cVar4 = ((go.d) this.X).f9067r1;
                if (cVar4 == null) {
                    kotlin.jvm.internal.q.n("adapter");
                    throw null;
                }
                if (obj2 == null) {
                    obj2 = ri.s.f18050e;
                }
                cVar4.f3289r0 = obj2;
                cVar4.f();
                return qi.b0.f17350a;
            case 7:
                List list2 = (List) obj;
                ArrayList arrayList = new ArrayList();
                kotlin.jvm.internal.d0 d0Var = new kotlin.jvm.internal.d0();
                go.f0 f0Var = (go.f0) this.X;
                Integer num2 = f0Var.f9103v1;
                ArrayList arrayList2 = f0Var.C1;
                if (num2 == null || num2.intValue() == 0) {
                    go.s3 s3Var = oo.k.f16584a;
                    if (s3Var != null) {
                        s3Var.C1 = (list2 == null || (sVar4 = (hm.s) ri.m.h0(0, list2)) == null) ? null : new Integer(sVar4.f10262a);
                    }
                    f0Var.f9103v1 = (list2 == null || (sVar3 = (hm.s) ri.m.h0(0, list2)) == null) ? new Integer(0) : new Integer(sVar3.f10262a);
                    if (list2 == null || (sVar2 = (hm.s) ri.m.h0(0, list2)) == null || (str = sVar2.f10263b) == null) {
                        str = _UrlKt.FRAGMENT_ENCODE_SET;
                    }
                    f0Var.D1 = str;
                    f0Var.f9105x1 = (list2 == null || (sVar = (hm.s) ri.m.f0(list2)) == null) ? new Integer(0) : new Integer(sVar.f10262a);
                }
                Integer num3 = f0Var.f9103v1;
                d0Var.f13951e = num3;
                f0Var.E1 = num3;
                if (list2 != null) {
                    int i11 = 0;
                    for (Object obj3 : list2) {
                        int i12 = i11 + 1;
                        if (i11 < 0) {
                            ?? r16 = dVar2;
                            ri.n.R();
                            throw r16;
                        }
                        hm.s sVar5 = (hm.s) obj3;
                        nb.d dVar3 = dVar2;
                        arrayList.add(sVar5.f10263b);
                        Integer num4 = f0Var.f9103v1;
                        int i13 = sVar5.f10262a;
                        if (num4 != null && num4.intValue() == i13) {
                            f0Var.F1 = i11;
                            f0Var.D1 = sVar5.f10263b;
                        }
                        i11 = i12;
                        dVar2 = dVar3;
                    }
                }
                nb.d dVar4 = dVar2;
                if (list2 == null || list2.size() != 1) {
                    ?? r11 = (Spinner) f0Var.l0().h;
                    Context contextO = f0Var.o();
                    if (contextO == null) {
                        r9 = dVar4;
                    } else {
                        GradientDrawable gradientDrawable = new GradientDrawable();
                        gradientDrawable.setCornerRadius(ji.k.S(6 * contextO.getResources().getDisplayMetrics().density));
                        gradientDrawable.setColor(contextO.getColor(R.color.neutral_900));
                        r9 = gradientDrawable;
                    }
                    r11.setPopupBackgroundDrawable(r9);
                    ((ImageView) f0Var.l0().f366g).setVisibility(0);
                    ((Spinner) f0Var.l0().h).setEnabled(true);
                } else {
                    ((ImageView) f0Var.l0().f366g).setVisibility(8);
                    ((Spinner) f0Var.l0().h).setEnabled(false);
                    Context contextO2 = f0Var.o();
                    if (contextO2 != null) {
                        ((MaterialCardView) f0Var.l0().f).setCardBackgroundColor(contextO2.getColor(R.color.transparent));
                    }
                }
                arrayList2.clear();
                if (list2 != null) {
                    arrayList2.addAll(list2);
                }
                if (list2 != null) {
                    Integer num5 = (Integer) d0Var.f13951e;
                    if (num5 != null) {
                        int iIntValue2 = num5.intValue();
                        int size = list2.size();
                        int i14 = 0;
                        for (int i15 = 0; i15 < size; i15++) {
                            if (((hm.s) list2.get(i15)).f10262a == iIntValue2) {
                                i14 = i15;
                            }
                        }
                        num = new Integer(i14);
                    } else {
                        num = dVar4;
                    }
                    if (num != 0) {
                        iIntValue = num.intValue();
                    }
                }
                Context contextO3 = f0Var.o();
                if (contextO3 != null) {
                    ArrayAdapter arrayAdapter = new ArrayAdapter(contextO3, R.layout.episodes_season_spinner_item, arrayList);
                    arrayAdapter.setDropDownViewResource(R.layout.new_season_spinner_item);
                    r10 = arrayAdapter;
                } else {
                    r10 = dVar4;
                }
                ((Spinner) f0Var.l0().h).setAdapter(r10);
                ((Spinner) f0Var.l0().h).setOnItemSelectedListener(new go.b0(f0Var, list2, d0Var));
                ((Spinner) f0Var.l0().h).post(new androidx.media3.session.k1(iIntValue, 5, f0Var));
                return qi.b0.f17350a;
            case 8:
                FrameLayout loader2 = (FrameLayout) ((go.k2) this.X).h0().f517c;
                kotlin.jvm.internal.q.f(loader2, "loader");
                loader2.setVisibility(((y5.h) obj).f22635a instanceof y5.x ? 0 : 8);
                return qi.b0.f17350a;
            case 9:
                FrameLayout loader3 = (FrameLayout) ((go.n2) this.X).h0().f517c;
                kotlin.jvm.internal.q.f(loader3, "loader");
                loader3.setVisibility(((y5.h) obj).f22635a instanceof y5.x ? 0 : 8);
                return qi.b0.f17350a;
            case 10:
                tm.belet.films.presentation.viewmodel.o1 o1Var = (tm.belet.films.presentation.viewmodel.o1) obj;
                go.s2 s2Var = (go.s2) this.X;
                boolean z6 = o1Var.f19887a;
                String str3 = o1Var.f19889c;
                kn.b bVar3 = o1Var.f19888b;
                if (z6) {
                    dm.b bVar4 = s2Var.f9300q1;
                    kotlin.jvm.internal.q.d(bVar4);
                    bVar4.f6948e.setVisibility(0);
                    dm.b bVar5 = s2Var.f9300q1;
                    kotlin.jvm.internal.q.d(bVar5);
                    ((CoordinatorLayout) bVar5.f6952k).setVisibility(8);
                } else if (!mj.l.m0(str3)) {
                    dm.b bVar6 = s2Var.f9300q1;
                    kotlin.jvm.internal.q.d(bVar6);
                    bVar6.f6948e.setVisibility(8);
                    oo.c.d(s2Var.o(), oo.l.ERROR, str3, null, (24 & 16) == 0);
                    s2Var.h0();
                } else if (bVar3 != null) {
                    String str4 = bVar3.f13916b;
                    dm.b bVar7 = s2Var.f9300q1;
                    kotlin.jvm.internal.q.d(bVar7);
                    bVar7.f6948e.setVisibility(8);
                    dm.b bVar8 = s2Var.f9300q1;
                    kotlin.jvm.internal.q.d(bVar8);
                    ((CoordinatorLayout) bVar8.f6952k).setVisibility(0);
                    String str5 = _UrlKt.FRAGMENT_ENCODE_SET;
                    s2Var.f9306w1 = bVar3;
                    dm.b bVar9 = s2Var.f9300q1;
                    kotlin.jvm.internal.q.d(bVar9);
                    TextView textView = (TextView) bVar9.f6960s;
                    kn.a aVar = bVar3.f13918d;
                    String str6 = bVar3.h;
                    String str7 = bVar3.f13917c;
                    textView.setText(str4 == null ? _UrlKt.FRAGMENT_ENCODE_SET : str4);
                    dm.b bVar10 = s2Var.f9300q1;
                    kotlin.jvm.internal.q.d(bVar10);
                    ((TextView) bVar10.f6960s).setVisibility((str4 == null || mj.l.m0(str4)) ? 8 : 0);
                    dm.b bVar11 = s2Var.f9300q1;
                    kotlin.jvm.internal.q.d(bVar11);
                    TextView textView2 = (TextView) bVar11.f6958q;
                    String str8 = bVar3.f13919e;
                    if (str8 == null) {
                        str8 = _UrlKt.FRAGMENT_ENCODE_SET;
                    }
                    textView2.setText(str8);
                    dm.b bVar12 = s2Var.f9300q1;
                    kotlin.jvm.internal.q.d(bVar12);
                    bVar12.f6945b.setText(str7 == null ? _UrlKt.FRAGMENT_ENCODE_SET : str7);
                    if (str7 == null) {
                        str7 = _UrlKt.FRAGMENT_ENCODE_SET;
                    }
                    s2Var.f9307x1 = str7;
                    dm.b bVar13 = s2Var.f9300q1;
                    kotlin.jvm.internal.q.d(bVar13);
                    bVar13.f6949g.setVisibility(!mj.l.m0(str7) ? 0 : 8);
                    if (mj.l.m0(str7)) {
                        s2Var.j0(false);
                        dm.b bVar14 = s2Var.f9300q1;
                        kotlin.jvm.internal.q.d(bVar14);
                        bVar14.f.setVisibility(8);
                    } else {
                        dm.b bVar15 = s2Var.f9300q1;
                        kotlin.jvm.internal.q.d(bVar15);
                        bVar15.f6945b.post(new go.r2(s2Var, str7, 0));
                    }
                    dm.b bVar16 = s2Var.f9300q1;
                    kotlin.jvm.internal.q.d(bVar16);
                    TextView textView3 = bVar16.f6944a;
                    if (str6 != null) {
                        str5 = str6;
                    }
                    textView3.setText(str5);
                    dm.b bVar17 = s2Var.f9300q1;
                    kotlin.jvm.internal.q.d(bVar17);
                    bVar17.f6944a.setVisibility((str6 == null || mj.l.m0(str6)) ? 8 : 0);
                    if (aVar != null && (cVar2 = aVar.f13914b) != null) {
                        str2 = cVar2.f18084b;
                        if (mj.l.m0(str2)) {
                            str2 = null;
                        }
                        if (str2 == null) {
                            if (aVar != null) {
                                str2 = null;
                            } else {
                                str2 = null;
                            }
                        }
                    } else if (aVar != null || (cVar = aVar.f13914b) == null) {
                        str2 = null;
                    } else {
                        str2 = cVar.f18084b;
                    }
                    Context contextO4 = s2Var.o();
                    dm.b bVar18 = s2Var.f9300q1;
                    kotlin.jvm.internal.q.d(bVar18);
                    ImageView imageView = (ImageView) bVar18.f6959r;
                    if (contextO4 != null && (!(contextO4 instanceof Activity) || !((Activity) contextO4).isDestroyed())) {
                        if (str2 == null || mj.l.m0(str2)) {
                            imageView.setImageResource(R.color.black_second);
                        } else {
                            ((com.bumptech.glide.l) ((com.bumptech.glide.l) w.x0.o(contextO4, contextO4, str2, R.color.black_second)).e(R.color.black_second)).w(imageView);
                        }
                    }
                    s2Var.f9305v1 = null;
                    dm.b bVar19 = s2Var.f9300q1;
                    kotlin.jvm.internal.q.d(bVar19);
                    FrameLayout frameLayout = bVar19.f6947d;
                    frameLayout.animate().cancel();
                    frameLayout.setAlpha(1.0f);
                    frameLayout.setScaleY(1.0f);
                    frameLayout.setVisibility(8);
                    yn.s1 s1Var = s2Var.y1;
                    if (s1Var == null) {
                        kotlin.jvm.internal.q.n("membersAdapter");
                        throw null;
                    }
                    ?? r4 = bVar3.f13920g;
                    boolean z9 = bVar3.f13922j;
                    ArrayList arrayList3 = s1Var.f23266r0;
                    arrayList3.clear();
                    arrayList3.addAll(r4);
                    if (z9) {
                        if (r4.isEmpty()) {
                            z5 = false;
                        } else {
                            Iterator it = r4.iterator();
                            do {
                                if (!it.hasNext()) {
                                    z5 = false;
                                }
                            } while (!((MovieVoteMemberModel) it.next()).f19359s0);
                        }
                    }
                    s1Var.u0 = z5;
                    s1Var.z();
                    s1Var.f();
                }
                return qi.b0.f17350a;
            case ue.r.NETWORK_CLIENT_ERROR_REASON_FIELD_NUMBER /* 11 */:
                hm.v vVar = ((tm.belet.films.presentation.viewmodel.x2) obj).f19996b;
                if (vVar != null) {
                    go.c3 c3Var = (go.c3) this.X;
                    c3Var.f9057u1 = vVar.f10271c;
                    c3Var.f9058v1 = vVar.f10272d;
                    c3Var.f9059w1 = vVar.f10269a;
                }
                return qi.b0.f17350a;
            case ue.r.CUSTOM_ATTRIBUTES_FIELD_NUMBER /* 12 */:
                tm.belet.films.presentation.viewmodel.a aVar2 = (tm.belet.films.presentation.viewmodel.a) obj;
                go.f4 f4Var = (go.f4) this.X;
                boolean z10 = aVar2.f19723a;
                km.a aVar3 = aVar2.f19724b;
                String str9 = aVar2.f19725c;
                if (z10) {
                    dm.q qVar = f4Var.f9115q1;
                    if (qVar != null) {
                        PrimaryButton primaryButton = qVar.f7131m;
                        primaryButton.setButtonIsLoading(true);
                        primaryButton.setState(xo.a.Z);
                        primaryButton.setEnabled(false);
                    }
                    dm.q qVar2 = f4Var.f9115q1;
                    if (qVar2 != null) {
                        qVar2.f7128j.setEnabled(false);
                    }
                } else if (!mj.l.m0(str9)) {
                    dm.q qVar3 = f4Var.f9115q1;
                    if (qVar3 != null) {
                        qVar3.f7131m.setButtonIsLoading(false);
                    }
                    Integer num6 = aVar2.f19726d;
                    if (num6 != null && num6.intValue() == 429) {
                        go.f4.h0(f4Var, str9);
                    } else {
                        dm.q qVar4 = f4Var.f9115q1;
                        if (qVar4 != null) {
                            qVar4.f7128j.setVisibility(0);
                        }
                        dm.q qVar5 = f4Var.f9115q1;
                        if (qVar5 != null) {
                            qVar5.f7128j.setEnabled(true);
                        }
                        dm.q qVar6 = f4Var.f9115q1;
                        if (qVar6 != null) {
                            qVar6.f7131m.setEnabled(true);
                        }
                        dm.q qVar7 = f4Var.f9115q1;
                        if (qVar7 != null) {
                            qVar7.f7131m.setButtonIsButtonEnable(true);
                        }
                        dm.q qVar8 = f4Var.f9115q1;
                        if (qVar8 != null) {
                            qVar8.f7131m.setButtonIsLoading(false);
                        }
                        dm.q qVar9 = f4Var.f9115q1;
                        if (qVar9 != null) {
                            qVar9.f7131m.setButtonText(f4Var.x(R.string.try_again_2));
                        }
                        dm.q qVar10 = f4Var.f9115q1;
                        if (qVar10 != null) {
                            qVar10.f7131m.setButtonIcon(Integer.valueOf(R.drawable.icon_try_again_3));
                        }
                        dm.q qVar11 = f4Var.f9115q1;
                        if (qVar11 != null) {
                            qVar11.f7131m.setState(xo.a.f22341e);
                        }
                    }
                } else if (aVar3 != null) {
                    dm.q qVar12 = f4Var.f9115q1;
                    if (qVar12 != null) {
                        qVar12.f7131m.setButtonIsLoading(false);
                    }
                    dm.q qVar13 = f4Var.f9115q1;
                    if (qVar13 != null) {
                        qVar13.f7131m.setState(xo.a.Y);
                    }
                    if (f4Var.j() != null) {
                        f4Var.l().g0("response_sheet_request_key", f4Var, new gd.y(6, f4Var));
                        String strX = f4Var.x(R.string.your_request_sent);
                        kotlin.jvm.internal.q.f(strX, "getString(...)");
                        String strX2 = f4Var.x(R.string.your_request_sent_description);
                        kotlin.jvm.internal.q.f(strX2, "getString(...)");
                        Log.d("TAG_Content", "Order: ".concat(aVar3.f13912b));
                        eo.a2 a2Var = new eo.a2();
                        Bundle bundle = new Bundle();
                        bundle.putString("message_title", strX);
                        bundle.putString("server_message", strX2);
                        a2Var.f0(bundle);
                        androidx.fragment.app.b1 b1VarL = f4Var.l();
                        kotlin.jvm.internal.q.f(b1VarL, "getChildFragmentManager(...)");
                        jd.t1.E(a2Var, b1VarL, a2Var.getClass().getName());
                    }
                }
                return qi.b0.f17350a;
            case ue.r.PERF_SESSIONS_FIELD_NUMBER /* 13 */:
                List list3 = (List) obj;
                go.x4 x4Var = (go.x4) this.X;
                tm.belet.films.presentation.viewmodel.n3 n3Var = x4Var.f9406n1;
                List list4 = list3 == null ? ri.s.f18050e : list3;
                n3Var.getClass();
                tm.belet.films.presentation.viewmodel.n3.f19878b.setValue(list4);
                ao.c cVar5 = x4Var.f9407o1;
                if (cVar5 == null) {
                    kotlin.jvm.internal.q.n("adapter");
                    throw null;
                }
                cVar5.f3289r0 = list3;
                cVar5.f();
                return qi.b0.f17350a;
            case 14:
                tm.belet.films.presentation.viewmodel.r0 r0Var = (tm.belet.films.presentation.viewmodel.r0) obj;
                ho.p0 p0Var = (ho.p0) this.X;
                if (r0Var.f19927a) {
                    ((LottieAnimationView) p0Var.i0().f1421d).setAnimation(R.raw.device_connect_success);
                    ((CodeScannerView) p0Var.i0().f1422e).setVisibleFrame(false);
                    ((LinearLayout) p0Var.i0().f1420c).setVisibility(0);
                    ((LottieAnimationView) p0Var.i0().f1421d).setVisibility(0);
                    ((LottieAnimationView) p0Var.i0().f1421d).f4583w0.r(30, 104);
                    ((LottieAnimationView) p0Var.i0().f1421d).setRepeatCount(-1);
                    ((LottieAnimationView) p0Var.i0().f1421d).e();
                    ((TextView) p0Var.i0().f1418a).setText(p0Var.x(R.string.device_connecting));
                    ((PrimaryButton) p0Var.i0().f1423g).setVisibility(4);
                    ((PrimaryButton) p0Var.i0().f1423g).setEnabled(false);
                    p0Var.h0();
                } else if (!mj.l.m0(r0Var.f19929c)) {
                    LottieAnimationView lottieAnimationView = (LottieAnimationView) p0Var.i0().f1421d;
                    lottieAnimationView.A0 = false;
                    lottieAnimationView.f4583w0.k();
                    int frame = ((LottieAnimationView) p0Var.i0().f1421d).getFrame();
                    ((CodeScannerView) p0Var.i0().f1422e).setVisibleFrame(false);
                    ((LinearLayout) p0Var.i0().f1420c).setVisibility(0);
                    ((TextView) p0Var.i0().f1418a).setText(p0Var.x(R.string.device_connect_error));
                    ((LottieAnimationView) p0Var.i0().f1421d).setAnimation(R.raw.device_connect_error);
                    ((LottieAnimationView) p0Var.i0().f1421d).setMinFrame(frame);
                    ((LottieAnimationView) p0Var.i0().f1421d).setMaxFrame(241);
                    ((LottieAnimationView) p0Var.i0().f1421d).setRepeatCount(0);
                    ((LottieAnimationView) p0Var.i0().f1421d).e();
                    if (((PrimaryButton) p0Var.i0().f1423g).getVisibility() == 4) {
                        PrimaryButton primaryButton2 = (PrimaryButton) p0Var.i0().f1423g;
                        primaryButton2.setVisibility(0);
                        ObjectAnimator objectAnimatorOfFloat = ObjectAnimator.ofFloat(primaryButton2, "alpha", 0.0f, 1.0f);
                        objectAnimatorOfFloat.setDuration(200L);
                        objectAnimatorOfFloat.start();
                        ((PrimaryButton) p0Var.i0().f1423g).setEnabled(true);
                    }
                    p0Var.h0();
                } else if (r0Var.f19928b != null) {
                    int frame2 = ((LottieAnimationView) p0Var.i0().f1421d).getFrame();
                    ro.g.M(p0Var.o(), 200L);
                    LottieAnimationView lottieAnimationView2 = (LottieAnimationView) p0Var.i0().f1421d;
                    lottieAnimationView2.A0 = false;
                    lottieAnimationView2.f4583w0.k();
                    float duration = (((LottieAnimationView) p0Var.i0().f1421d).getDuration() - (((LottieAnimationView) p0Var.i0().f1421d).getProgress() * ((LottieAnimationView) p0Var.i0().f1421d).getDuration())) - 700;
                    if (((LottieAnimationView) p0Var.i0().f1421d).getComposition() == null) {
                        ((LottieAnimationView) p0Var.i0().f1421d).setAnimation(R.raw.device_connect_success);
                    }
                    ((CodeScannerView) p0Var.i0().f1422e).setVisibleFrame(false);
                    ((LinearLayout) p0Var.i0().f1420c).setVisibility(0);
                    ((LottieAnimationView) p0Var.i0().f1421d).setVisibility(0);
                    ((LottieAnimationView) p0Var.i0().f1421d).setMinFrame(frame2);
                    ((LottieAnimationView) p0Var.i0().f1421d).setMaxFrame(204);
                    ((LottieAnimationView) p0Var.i0().f1421d).setRepeatCount(0);
                    ((LottieAnimationView) p0Var.i0().f1421d).e();
                    new Handler(Looper.getMainLooper()).postDelayed(new ho.n0(p0Var, 1), (long) duration);
                    ((PrimaryButton) p0Var.i0().f1423g).setVisibility(4);
                    ((PrimaryButton) p0Var.i0().f1423g).setEnabled(false);
                    p0Var.h0();
                }
                return qi.b0.f17350a;
            case WebSocketProtocol.B0_MASK_OPCODE /* 15 */:
                tm.belet.films.presentation.viewmodel.k kVar = (tm.belet.films.presentation.viewmodel.k) obj;
                qi.b0 b0Var2 = qi.b0.f17350a;
                final ho.i1 i1Var = (ho.i1) this.X;
                boolean z11 = kVar.f19829a;
                String str10 = kVar.f19831c;
                if (z11) {
                    mf mfVar5 = i1Var.f10358q1;
                    if (mfVar5 == null) {
                        kotlin.jvm.internal.q.n("binding");
                        throw null;
                    }
                    ((dm.u) mfVar5.h).f7176a.setVisibility(0);
                    ((LinearLayout) mfVar5.f5287g).setVisibility(4);
                } else if (mj.l.m0(str10)) {
                    nm.c cVar6 = kVar.f19830b;
                    if (cVar6 != null && (bVar2 = cVar6.f15991a) != null) {
                        VoteInfo voteInfo = cVar6.f15992b;
                        mf mfVar6 = i1Var.f10358q1;
                        if (mfVar6 == null) {
                            kotlin.jvm.internal.q.n("binding");
                            throw null;
                        }
                        LinearLayout linearLayout = (LinearLayout) mfVar6.f5289j;
                        TextView textView4 = (TextView) mfVar6.f5282a;
                        ((dm.u) mfVar6.h).f7176a.setVisibility(8);
                        ((LinearLayout) mfVar6.f5287g).setVisibility(0);
                        ((TextView) mfVar6.f5283b).setText(bVar2.f15979b);
                        ((TextView) mfVar6.f5284c).setText(bVar2.f15981d);
                        i1Var.f10361t1 = kotlin.jvm.internal.q.c(bVar2.f15982e, Boolean.TRUE);
                        ((TextView) mfVar6.f5288i).setText(bVar2.f15990o);
                        if (voteInfo != null) {
                            linearLayout.setVisibility(0);
                            ((MaterialButton) mfVar6.f).setOnClickListener(new ao.a(voteInfo, i1Var, 18));
                        } else {
                            linearLayout.setVisibility(8);
                        }
                        String str11 = bVar2.f;
                        if (str11 == null) {
                            mfVar = i1Var.f10358q1;
                            if (mfVar == null) {
                                kotlin.jvm.internal.q.n("binding");
                                throw null;
                            }
                            p0.f.P((MaterialButton) mfVar.f5285d, i1Var.f10361t1);
                            textView4.setText(ta.f.E(i1Var.b0(), bVar2.f15989n, "d MMMM, HH:mm"));
                            mfVar2 = i1Var.f10358q1;
                            if (mfVar2 == null) {
                                kotlin.jvm.internal.q.n("binding");
                                throw null;
                            }
                            MaterialButton materialButton2 = (MaterialButton) mfVar2.f5285d;
                            final int i16 = z5 ? 1 : 0;
                            materialButton2.setOnClickListener(new View.OnClickListener() { // from class: ho.g1
                                @Override // android.view.View.OnClickListener
                                public final void onClick(View view) {
                                    switch (i16) {
                                        case 0:
                                            androidx.fragment.app.b1 b1VarV = i1Var.v();
                                            Bundle bundle2 = new Bundle();
                                            bundle2.putBoolean("play_event", true);
                                            b1VarV.f0("main_event_sheet_request_key", bundle2);
                                            break;
                                        default:
                                            int i17 = Build.VERSION.SDK_INT;
                                            i1 i1Var2 = i1Var;
                                            if (i17 >= 33 && ji.k.y(i1Var2.Z().getApplicationContext(), "android.permission.POST_NOTIFICATIONS") != 0) {
                                                androidx.fragment.app.b1 b1VarV2 = i1Var2.v();
                                                Bundle bundle3 = new Bundle();
                                                bundle3.putBoolean("ask_permission", true);
                                                b1VarV2.f0("main_event_sheet_request_key", bundle3);
                                            } else {
                                                EventInfoViewModel eventInfoViewModel = (EventInfoViewModel) i1Var2.f10359r1.getValue();
                                                Integer num7 = i1Var2.f10360s1;
                                                kotlinx.coroutines.k.launch$default(androidx.lifecycle.r0.g(eventInfoViewModel), null, null, new nn.a(eventInfoViewModel, num7 != null ? num7.intValue() : 0, i1Var2.f10361t1 ? "disable" : "enable", null, 8), 3, null);
                                            }
                                            break;
                                    }
                                }
                            });
                        } else {
                            int iHashCode = str11.hashCode();
                            if (iHashCode != -673660814) {
                                if (iHashCode != -123173735) {
                                    if (iHashCode == 3322092 && str11.equals("live")) {
                                        textView4.setTextColor(i1Var.b0().getColor(R.color.white));
                                        textView4.setText(i1Var.x(R.string.live_started));
                                        mfVar3 = i1Var.f10358q1;
                                        if (mfVar3 != null) {
                                            kotlin.jvm.internal.q.n("binding");
                                            throw null;
                                        }
                                        MaterialButton materialButton3 = (MaterialButton) mfVar3.f5285d;
                                        materialButton3.setBackgroundColor(materialButton3.getContext().getColor(R.color.red_live));
                                        materialButton3.setIconResource(R.drawable.ic_live);
                                        materialButton3.setIconTintResource(R.color.white);
                                        materialButton3.setTextColor(materialButton3.getContext().getColor(R.color.white));
                                        materialButton3.setText(R.string.watch_live);
                                        mfVar4 = i1Var.f10358q1;
                                        if (mfVar4 != null) {
                                            kotlin.jvm.internal.q.n("binding");
                                            throw null;
                                        }
                                        ((MaterialButton) mfVar4.f5285d).setOnClickListener(new View.OnClickListener() { // from class: ho.g1
                                            @Override // android.view.View.OnClickListener
                                            public final void onClick(View view) {
                                                switch (iIntValue) {
                                                    case 0:
                                                        androidx.fragment.app.b1 b1VarV = i1Var.v();
                                                        Bundle bundle2 = new Bundle();
                                                        bundle2.putBoolean("play_event", true);
                                                        b1VarV.f0("main_event_sheet_request_key", bundle2);
                                                        break;
                                                    default:
                                                        int i17 = Build.VERSION.SDK_INT;
                                                        i1 i1Var2 = i1Var;
                                                        if (i17 >= 33 && ji.k.y(i1Var2.Z().getApplicationContext(), "android.permission.POST_NOTIFICATIONS") != 0) {
                                                            androidx.fragment.app.b1 b1VarV2 = i1Var2.v();
                                                            Bundle bundle3 = new Bundle();
                                                            bundle3.putBoolean("ask_permission", true);
                                                            b1VarV2.f0("main_event_sheet_request_key", bundle3);
                                                        } else {
                                                            EventInfoViewModel eventInfoViewModel = (EventInfoViewModel) i1Var2.f10359r1.getValue();
                                                            Integer num7 = i1Var2.f10360s1;
                                                            kotlinx.coroutines.k.launch$default(androidx.lifecycle.r0.g(eventInfoViewModel), null, null, new nn.a(eventInfoViewModel, num7 != null ? num7.intValue() : 0, i1Var2.f10361t1 ? "disable" : "enable", null, 8), 3, null);
                                                        }
                                                        break;
                                                }
                                            }
                                        });
                                    }
                                } else if (str11.equals("canceled")) {
                                    textView4.setTextColor(i1Var.b0().getColor(R.color.light_red_3));
                                    textView4.setText(i1Var.x(R.string.event_canceled));
                                    mf mfVar7 = i1Var.f10358q1;
                                    if (mfVar7 == null) {
                                        kotlin.jvm.internal.q.n("binding");
                                        throw null;
                                    }
                                    MaterialButton materialButton4 = (MaterialButton) mfVar7.f5285d;
                                    materialButton4.setEnabled(false);
                                    materialButton4.setBackgroundColor(materialButton4.getContext().getColor(R.color.neutral_800));
                                    materialButton4.setIconResource(R.drawable.ic_add_alert);
                                    materialButton4.setIconTintResource(R.color.black_pearl);
                                    materialButton4.setTextColor(materialButton4.getContext().getColor(R.color.like_chinese_black));
                                    materialButton4.setText(R.string.notify_me);
                                }
                                mfVar = i1Var.f10358q1;
                                if (mfVar == null) {
                                    kotlin.jvm.internal.q.n("binding");
                                    throw null;
                                }
                                p0.f.P((MaterialButton) mfVar.f5285d, i1Var.f10361t1);
                                textView4.setText(ta.f.E(i1Var.b0(), bVar2.f15989n, "d MMMM, HH:mm"));
                                mfVar2 = i1Var.f10358q1;
                                if (mfVar2 == null) {
                                    kotlin.jvm.internal.q.n("binding");
                                    throw null;
                                }
                                MaterialButton materialButton5 = (MaterialButton) mfVar2.f5285d;
                                final int i17 = z5 ? 1 : 0;
                                materialButton5.setOnClickListener(new View.OnClickListener() { // from class: ho.g1
                                    @Override // android.view.View.OnClickListener
                                    public final void onClick(View view) {
                                        switch (i17) {
                                            case 0:
                                                androidx.fragment.app.b1 b1VarV = i1Var.v();
                                                Bundle bundle2 = new Bundle();
                                                bundle2.putBoolean("play_event", true);
                                                b1VarV.f0("main_event_sheet_request_key", bundle2);
                                                break;
                                            default:
                                                int i18 = Build.VERSION.SDK_INT;
                                                i1 i1Var2 = i1Var;
                                                if (i18 >= 33 && ji.k.y(i1Var2.Z().getApplicationContext(), "android.permission.POST_NOTIFICATIONS") != 0) {
                                                    androidx.fragment.app.b1 b1VarV2 = i1Var2.v();
                                                    Bundle bundle3 = new Bundle();
                                                    bundle3.putBoolean("ask_permission", true);
                                                    b1VarV2.f0("main_event_sheet_request_key", bundle3);
                                                } else {
                                                    EventInfoViewModel eventInfoViewModel = (EventInfoViewModel) i1Var2.f10359r1.getValue();
                                                    Integer num7 = i1Var2.f10360s1;
                                                    kotlinx.coroutines.k.launch$default(androidx.lifecycle.r0.g(eventInfoViewModel), null, null, new nn.a(eventInfoViewModel, num7 != null ? num7.intValue() : 0, i1Var2.f10361t1 ? "disable" : "enable", null, 8), 3, null);
                                                }
                                                break;
                                        }
                                    }
                                });
                            } else if (str11.equals("finished")) {
                                textView4.setTextColor(i1Var.b0().getColor(R.color.white));
                                textView4.setText(i1Var.x(R.string.live_started));
                                mfVar3 = i1Var.f10358q1;
                                if (mfVar3 != null) {
                                    kotlin.jvm.internal.q.n("binding");
                                    throw null;
                                }
                                MaterialButton materialButton6 = (MaterialButton) mfVar3.f5285d;
                                materialButton6.setBackgroundColor(materialButton6.getContext().getColor(R.color.red_live));
                                materialButton6.setIconResource(R.drawable.ic_live);
                                materialButton6.setIconTintResource(R.color.white);
                                materialButton6.setTextColor(materialButton6.getContext().getColor(R.color.white));
                                materialButton6.setText(R.string.watch_live);
                                mfVar4 = i1Var.f10358q1;
                                if (mfVar4 != null) {
                                    kotlin.jvm.internal.q.n("binding");
                                    throw null;
                                }
                                ((MaterialButton) mfVar4.f5285d).setOnClickListener(new View.OnClickListener() { // from class: ho.g1
                                    @Override // android.view.View.OnClickListener
                                    public final void onClick(View view) {
                                        switch (iIntValue) {
                                            case 0:
                                                androidx.fragment.app.b1 b1VarV = i1Var.v();
                                                Bundle bundle2 = new Bundle();
                                                bundle2.putBoolean("play_event", true);
                                                b1VarV.f0("main_event_sheet_request_key", bundle2);
                                                break;
                                            default:
                                                int i18 = Build.VERSION.SDK_INT;
                                                i1 i1Var2 = i1Var;
                                                if (i18 >= 33 && ji.k.y(i1Var2.Z().getApplicationContext(), "android.permission.POST_NOTIFICATIONS") != 0) {
                                                    androidx.fragment.app.b1 b1VarV2 = i1Var2.v();
                                                    Bundle bundle3 = new Bundle();
                                                    bundle3.putBoolean("ask_permission", true);
                                                    b1VarV2.f0("main_event_sheet_request_key", bundle3);
                                                } else {
                                                    EventInfoViewModel eventInfoViewModel = (EventInfoViewModel) i1Var2.f10359r1.getValue();
                                                    Integer num7 = i1Var2.f10360s1;
                                                    kotlinx.coroutines.k.launch$default(androidx.lifecycle.r0.g(eventInfoViewModel), null, null, new nn.a(eventInfoViewModel, num7 != null ? num7.intValue() : 0, i1Var2.f10361t1 ? "disable" : "enable", null, 8), 3, null);
                                                }
                                                break;
                                        }
                                    }
                                });
                            } else {
                                mfVar = i1Var.f10358q1;
                                if (mfVar == null) {
                                    kotlin.jvm.internal.q.n("binding");
                                    throw null;
                                }
                                p0.f.P((MaterialButton) mfVar.f5285d, i1Var.f10361t1);
                                textView4.setText(ta.f.E(i1Var.b0(), bVar2.f15989n, "d MMMM, HH:mm"));
                                mfVar2 = i1Var.f10358q1;
                                if (mfVar2 == null) {
                                    kotlin.jvm.internal.q.n("binding");
                                    throw null;
                                }
                                MaterialButton materialButton7 = (MaterialButton) mfVar2.f5285d;
                                final int i18 = z5 ? 1 : 0;
                                materialButton7.setOnClickListener(new View.OnClickListener() { // from class: ho.g1
                                    @Override // android.view.View.OnClickListener
                                    public final void onClick(View view) {
                                        switch (i18) {
                                            case 0:
                                                androidx.fragment.app.b1 b1VarV = i1Var.v();
                                                Bundle bundle2 = new Bundle();
                                                bundle2.putBoolean("play_event", true);
                                                b1VarV.f0("main_event_sheet_request_key", bundle2);
                                                break;
                                            default:
                                                int i19 = Build.VERSION.SDK_INT;
                                                i1 i1Var2 = i1Var;
                                                if (i19 >= 33 && ji.k.y(i1Var2.Z().getApplicationContext(), "android.permission.POST_NOTIFICATIONS") != 0) {
                                                    androidx.fragment.app.b1 b1VarV2 = i1Var2.v();
                                                    Bundle bundle3 = new Bundle();
                                                    bundle3.putBoolean("ask_permission", true);
                                                    b1VarV2.f0("main_event_sheet_request_key", bundle3);
                                                } else {
                                                    EventInfoViewModel eventInfoViewModel = (EventInfoViewModel) i1Var2.f10359r1.getValue();
                                                    Integer num7 = i1Var2.f10360s1;
                                                    kotlinx.coroutines.k.launch$default(androidx.lifecycle.r0.g(eventInfoViewModel), null, null, new nn.a(eventInfoViewModel, num7 != null ? num7.intValue() : 0, i1Var2.f10361t1 ? "disable" : "enable", null, 8), 3, null);
                                                }
                                                break;
                                        }
                                    }
                                });
                            }
                        }
                    }
                } else {
                    mf mfVar8 = i1Var.f10358q1;
                    if (mfVar8 == null) {
                        kotlin.jvm.internal.q.n("binding");
                        throw null;
                    }
                    ((dm.u) mfVar8.h).f7176a.setVisibility(8);
                    ((TextView) mfVar8.f5283b).setText(str10);
                    ((MaterialButton) mfVar8.f5285d).setVisibility(4);
                    ((LinearLayout) mfVar8.f5289j).setVisibility(8);
                    ((LinearLayout) mfVar8.f5287g).setVisibility(0);
                }
                return b0Var2;
            case WebSocketProtocol.B0_FLAG_RSV3 /* 16 */:
                tm.belet.films.presentation.viewmodel.z1 z1Var = (tm.belet.films.presentation.viewmodel.z1) obj;
                ko.e eVar = (ko.e) this.X;
                boolean z12 = z1Var.f20015a;
                SwitchConfirmModel switchConfirmModel = z1Var.f20016b;
                Integer num7 = z1Var.f20019e;
                String str12 = z1Var.f20017c;
                if (z12) {
                    md.c cVar7 = eVar.f13938q1;
                    if (cVar7 == null) {
                        kotlin.jvm.internal.q.n("binding");
                        throw null;
                    }
                    MaterialButton materialButton8 = (MaterialButton) cVar7.f15310e;
                    Context contextB0 = eVar.b0();
                    Integer num8 = new Integer(R.color.neutral_100);
                    yb.k kVar2 = new yb.k(contextB0, null, 0, R.style.CustomCircularIndicator);
                    kVar2.f22871e = new int[]{contextB0.getColor(num8.intValue())};
                    int i19 = yb.r.D0;
                    materialButton8.setIcon(yb.r.g(contextB0, kVar2, new yb.f(kVar2)));
                    materialButton8.setText(_UrlKt.FRAGMENT_ENCODE_SET);
                    materialButton8.setEnabled(false);
                } else if (!mj.l.m0(str12) || num7 != null) {
                    md.c cVar8 = eVar.f13938q1;
                    if (cVar8 == null) {
                        kotlin.jvm.internal.q.n("binding");
                        throw null;
                    }
                    MaterialButton materialButton9 = (MaterialButton) cVar8.f15310e;
                    materialButton9.setIcon(null);
                    SwitchInfoModel switchInfoModel = eVar.f13940s1;
                    materialButton9.setText((switchInfoModel == null || (coloredUIComponentModel = switchInfoModel.f19353s0) == null) ? null : coloredUIComponentModel.f19346e);
                    materialButton9.setEnabled(true);
                    int i20 = yh.y.f23088z0.f23089e;
                    if (num7 != null && num7.intValue() == i20) {
                        Bundle bundle2 = new Bundle();
                        bundle2.putParcelable("low_balance", new ResponseModel(z1Var.f20018d, str12));
                        eVar.v().f0("switch_sheet_request_key", bundle2);
                        androidx.fragment.app.d0 d0Var2 = eVar.J0;
                        dVar2 = d0Var2 instanceof nb.d ? (nb.d) d0Var2 : null;
                        if (dVar2 != null) {
                            dVar2.o0();
                        }
                    } else {
                        oo.c.d(eVar.o(), oo.l.ERROR, str12, null, (24 & 16) == 0);
                    }
                } else if (switchConfirmModel != null) {
                    md.c cVar9 = eVar.f13938q1;
                    if (cVar9 == null) {
                        kotlin.jvm.internal.q.n("binding");
                        throw null;
                    }
                    MaterialButton materialButton10 = (MaterialButton) cVar9.f15310e;
                    materialButton10.setIcon(null);
                    SwitchInfoModel switchInfoModel2 = eVar.f13940s1;
                    materialButton10.setText((switchInfoModel2 == null || (coloredUIComponentModel2 = switchInfoModel2.f19353s0) == null) ? null : coloredUIComponentModel2.f19346e);
                    materialButton10.setEnabled(true);
                    Bundle bundle3 = new Bundle();
                    bundle3.putBoolean("profile_update", true);
                    eVar.v().f0("switch_sheet_request_key", bundle3);
                    androidx.fragment.app.a aVar4 = new androidx.fragment.app.a(eVar.v());
                    Bundle bundle4 = new Bundle();
                    bundle4.putParcelable("confirm_info", switchConfirmModel);
                    SwitchInfoModel switchInfoModel3 = eVar.f13940s1;
                    bundle4.putString("subscription_type", switchInfoModel3 != null ? switchInfoModel3.Z : null);
                    aVar4.o(R.id.upgrade_container, ko.a.class, bundle4, null);
                    aVar4.d(null);
                    aVar4.g();
                }
                return qi.b0.f17350a;
            case 17:
                return a(obj, dVar);
            case 18:
                return b(obj, dVar);
            case 19:
                return c(obj, dVar);
            case 20:
                return d(obj, dVar);
            case 21:
                return e(obj, dVar);
            case 22:
                return f(obj, dVar);
            case 23:
                return g(obj, dVar);
            case 24:
                return h(obj, dVar);
            case 25:
                return i(obj, dVar);
            case 26:
                return j(obj, dVar);
            case 27:
                return k(obj, dVar);
            case 28:
                return l(obj, dVar);
            default:
                nk.d dVar5 = (nk.d) obj;
                kotlinx.coroutines.flow.h0 h0Var = ((SearchPageViewModel) this.X).f19691e;
                if (dVar5 instanceof nk.c) {
                    h0Var.setValue(new tm.belet.films.presentation.viewmodel.d3((hm.i) ((nk.c) dVar5).f15965a, null, 5));
                } else if (dVar5 instanceof nk.b) {
                    h0Var.setValue(new tm.belet.films.presentation.viewmodel.d3(null, null, 6));
                } else {
                    if (!(dVar5 instanceof nk.a)) {
                        throw new ad.n(11);
                    }
                    String str13 = ((nk.a) dVar5).f15966b;
                    if (str13 == null) {
                        str13 = "An UnexpectedError";
                    }
                    h0Var.setValue(new tm.belet.films.presentation.viewmodel.d3(null, str13, 3));
                }
                return qi.b0.f17350a;
        }
    }
}
