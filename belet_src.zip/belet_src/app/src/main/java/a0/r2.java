package a0;

import android.util.Log;
import java.io.Serializable;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class r2 extends wi.i implements ej.l {
    public final /* synthetic */ Object X;
    public final /* synthetic */ Serializable Y;
    public final /* synthetic */ Object Z;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f307e;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ r2(Object obj, Serializable serializable, Object obj2, ui.d dVar, int i10) {
        super(1, dVar);
        this.f307e = i10;
        this.X = obj;
        this.Y = serializable;
        this.Z = obj2;
    }

    @Override // wi.a
    public final ui.d create(ui.d dVar) {
        switch (this.f307e) {
            case 0:
                return new r2((kotlin.jvm.internal.d0) this.X, (kotlin.jvm.internal.d0) this.Y, (m) this.Z, dVar, 0);
            default:
                return new r2((i6.p) this.X, (String) this.Y, (ej.l) this.Z, dVar, 1);
        }
    }

    @Override // ej.l
    public final Object invoke(Object obj) {
        ui.d dVar = (ui.d) obj;
        switch (this.f307e) {
            case 0:
                break;
        }
        return ((r2) create(dVar)).invokeSuspend(qi.b0.f17350a);
    }

    @Override // wi.a
    public final Object invokeSuspend(Object obj) throws Exception {
        int i10 = this.f307e;
        Object obj2 = this.Z;
        Serializable serializable = this.Y;
        Object obj3 = this.X;
        switch (i10) {
            case 0:
                vi.a aVar = vi.a.f21252e;
                g6.y.I(obj);
                Log.d("CXCP", "tryOpenCamera: 3000ms elapsed");
                ((kotlin.jvm.internal.d0) obj3).f13951e = null;
                if (((kotlin.jvm.internal.d0) serializable).f13951e == null) {
                    return null;
                }
                Log.e("CXCP", "tryOpenCamera: openCamera() timed out");
                ((m) obj2).a();
                return new q3(null, new z.i(13), 1);
            default:
                vi.a aVar2 = vi.a.f21252e;
                g6.y.I(obj);
                o6.c cVarP0 = ((i6.p) obj3).f11304b.p0((String) serializable);
                try {
                    Object objInvoke = ((ej.l) obj2).invoke(cVarP0);
                    ji.k.B(cVarP0, null);
                    return objInvoke;
                } catch (Throwable th2) {
                    try {
                        throw th2;
                    } catch (Throwable th3) {
                        ji.k.B(cVarP0, th2);
                        throw th3;
                    }
                }
        }
    }
}
