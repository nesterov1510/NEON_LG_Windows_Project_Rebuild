package a0;

import android.hardware.camera2.CameraExtensionSession;
import android.hardware.camera2.CameraExtensionSession$ExtensionCaptureCallback;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.TotalCaptureResult;
import android.util.Log;
import j$.util.Collection;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class j extends CameraExtensionSession$ExtensionCaptureCallback {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f138a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final m1 f139b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ k f140c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Serializable f141d;

    public j(k kVar, m1 m1Var) {
        this.f138a = 0;
        this.f140c = kVar;
        this.f139b = m1Var;
        this.f141d = new ConcurrentLinkedQueue();
    }

    public final void onCaptureFailed(CameraExtensionSession session, CaptureRequest request) {
        switch (this.f138a) {
            case 0:
                kotlin.jvm.internal.q.g(session, "session");
                kotlin.jvm.internal.q.g(request, "request");
                if (((ConcurrentLinkedQueue) this.f141d).isEmpty()) {
                    long jIncrementAndGet = this.f140c.f156r0.incrementAndGet();
                    this.f140c.f157s0.put(session, Long.valueOf(jIncrementAndGet));
                    ((ConcurrentLinkedQueue) this.f141d).add(Long.valueOf(jIncrementAndGet));
                }
                Object objRemove = ((ConcurrentLinkedQueue) this.f141d).remove();
                kotlin.jvm.internal.q.f(objRemove, "remove(...)");
                this.f139b.d(request, ((Number) objRemove).longValue());
                break;
            default:
                kotlin.jvm.internal.q.g(session, "session");
                kotlin.jvm.internal.q.g(request, "request");
                Object obj = ((LinkedHashMap) this.f141d).get(request);
                kotlin.jvm.internal.q.d(obj);
                if (((List) obj).size() != 1) {
                    StringBuilder sb2 = new StringBuilder("onCaptureFailed is not triggered for repeating requests. Request frame numbers: ");
                    Object obj2 = ((LinkedHashMap) this.f141d).get(request);
                    kotlin.jvm.internal.q.d(obj2);
                    sb2.append(Collection.EL.stream((List) obj2));
                    Log.i("CXCP", sb2.toString());
                } else {
                    Object obj3 = ((LinkedHashMap) this.f141d).get(request);
                    kotlin.jvm.internal.q.d(obj3);
                    this.f139b.d(request, ((Number) ((List) obj3).get(0)).longValue());
                }
                break;
        }
    }

    public final void onCaptureProcessProgressed(CameraExtensionSession session, CaptureRequest request, int i10) {
        switch (this.f138a) {
            case 0:
                kotlin.jvm.internal.q.g(session, "session");
                kotlin.jvm.internal.q.g(request, "request");
                this.f139b.e(request, i10);
                break;
            default:
                kotlin.jvm.internal.q.g(session, "session");
                kotlin.jvm.internal.q.g(request, "request");
                this.f139b.e(request, i10);
                break;
        }
    }

    /* JADX WARN: Failed to find 'out' block for switch in B:3:0x0002. Please report as an issue. */
    public final void onCaptureProcessStarted(CameraExtensionSession session, CaptureRequest request) {
        switch (this.f138a) {
        }
        kotlin.jvm.internal.q.g(session, "session");
        kotlin.jvm.internal.q.g(request, "request");
    }

    public void onCaptureResultAvailable(CameraExtensionSession session, CaptureRequest request, TotalCaptureResult result) {
        switch (this.f138a) {
            case 0:
                kotlin.jvm.internal.q.g(session, "session");
                kotlin.jvm.internal.q.g(request, "request");
                kotlin.jvm.internal.q.g(result, "result");
                if (((ConcurrentLinkedQueue) this.f141d).isEmpty()) {
                    long jIncrementAndGet = this.f140c.f156r0.incrementAndGet();
                    this.f140c.f157s0.put(session, Long.valueOf(jIncrementAndGet));
                    ((ConcurrentLinkedQueue) this.f141d).add(Long.valueOf(jIncrementAndGet));
                }
                Object objRemove = ((ConcurrentLinkedQueue) this.f141d).remove();
                kotlin.jvm.internal.q.f(objRemove, "remove(...)");
                this.f139b.c(request, result, ((Number) objRemove).longValue());
                break;
            default:
                super.onCaptureResultAvailable(session, request, result);
                break;
        }
    }

    public final void onCaptureSequenceAborted(CameraExtensionSession session, int i10) {
        switch (this.f138a) {
            case 0:
                kotlin.jvm.internal.q.g(session, "session");
                this.f139b.f(i10);
                break;
            default:
                kotlin.jvm.internal.q.g(session, "session");
                this.f139b.f(i10);
                break;
        }
    }

    public final void onCaptureSequenceCompleted(CameraExtensionSession session, int i10) {
        switch (this.f138a) {
            case 0:
                kotlin.jvm.internal.q.g(session, "session");
                Long l10 = (Long) this.f140c.f157s0.get(session);
                kotlin.jvm.internal.q.d(l10);
                this.f139b.g(i10, l10.longValue());
                break;
            default:
                kotlin.jvm.internal.q.g(session, "session");
                Long l11 = (Long) this.f140c.f157s0.get(session);
                kotlin.jvm.internal.q.d(l11);
                this.f139b.g(i10, l11.longValue());
                break;
        }
    }

    public final void onCaptureStarted(CameraExtensionSession session, CaptureRequest request, long j10) {
        switch (this.f138a) {
            case 0:
                kotlin.jvm.internal.q.g(session, "session");
                kotlin.jvm.internal.q.g(request, "request");
                long jIncrementAndGet = this.f140c.f156r0.incrementAndGet();
                this.f140c.f157s0.put(session, Long.valueOf(jIncrementAndGet));
                ((ConcurrentLinkedQueue) this.f141d).add(Long.valueOf(jIncrementAndGet));
                this.f139b.h(request, jIncrementAndGet, j10);
                break;
            default:
                kotlin.jvm.internal.q.g(session, "session");
                kotlin.jvm.internal.q.g(request, "request");
                long jIncrementAndGet2 = this.f140c.f156r0.incrementAndGet();
                this.f140c.f157s0.put(session, Long.valueOf(jIncrementAndGet2));
                LinkedHashMap linkedHashMap = (LinkedHashMap) this.f141d;
                Object arrayList = linkedHashMap.get(request);
                if (arrayList == null) {
                    arrayList = new ArrayList();
                    linkedHashMap.put(request, arrayList);
                }
                ((List) arrayList).add(Long.valueOf(jIncrementAndGet2));
                this.f139b.h(request, jIncrementAndGet2, j10);
                break;
        }
    }

    public j(k kVar, m1 m1Var, LinkedHashMap linkedHashMap) {
        this.f138a = 1;
        this.f140c = kVar;
        this.f139b = m1Var;
        this.f141d = linkedHashMap;
    }
}
