package a0;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class p2 extends wi.c {
    public x1 X;
    public n0 Y;
    public int Z;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public String f266e;

    /* JADX INFO: renamed from: r0, reason: collision with root package name */
    public long f267r0;

    /* JADX INFO: renamed from: s0, reason: collision with root package name */
    public /* synthetic */ Object f268s0;

    /* JADX INFO: renamed from: t0, reason: collision with root package name */
    public final /* synthetic */ v2 f269t0;
    public int u0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public p2(v2 v2Var, wi.c cVar) {
        super(cVar);
        this.f269t0 = v2Var;
    }

    @Override // wi.a
    public final Object invokeSuspend(Object obj) {
        this.f268s0 = obj;
        this.u0 |= Integer.MIN_VALUE;
        return this.f269t0.f(null, 0, 0L, null, null, this);
    }
}
