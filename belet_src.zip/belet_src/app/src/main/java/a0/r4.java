package a0;

import android.util.Log;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class r4 {

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public static final x2 f308i = new x2();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final v2 f309a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final a2 f310b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final ge.q f311c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final c0.l f312d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final p f313e;
    public final n0 f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final z.u f314g;
    public final c0.n h;

    public r4(v2 v2Var, a2 cameraErrorListener, ge.q qVar, c0.l timeSource, p devicePolicyManager, n0 audioRestrictionController, z.u uVar, c0.n threads) {
        kotlin.jvm.internal.q.g(cameraErrorListener, "cameraErrorListener");
        kotlin.jvm.internal.q.g(timeSource, "timeSource");
        kotlin.jvm.internal.q.g(devicePolicyManager, "devicePolicyManager");
        kotlin.jvm.internal.q.g(audioRestrictionController, "audioRestrictionController");
        kotlin.jvm.internal.q.g(threads, "threads");
        this.f309a = v2Var;
        this.f310b = cameraErrorListener;
        this.f311c = qVar;
        this.f312d = timeSource;
        this.f313e = devicePolicyManager;
        this.f = audioRestrictionController;
        this.f314g = uVar;
        this.h = threads;
    }

    public final o0 a(String cameraId, x1 x1Var) {
        kotlin.jvm.internal.q.g(cameraId, "cameraId");
        Log.d("CXCP", this + "#openAndAwaitCameraWithRetry(" + ((Object) z.p.b(cameraId)) + ')');
        return (o0) kotlinx.coroutines.i.runBlocking(this.h.f3843c, new p4(this, cameraId, x1Var, (ui.d) null, 0));
    }

    /* JADX WARN: Code duplicated, block: B:34:0x00f8  */
    /* JADX WARN: Code duplicated, block: B:40:0x011e A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:41:0x0120 A[Catch: all -> 0x0129, TRY_ENTER, TRY_LEAVE, TryCatch #3 {all -> 0x0129, blocks: (B:35:0x0106, B:41:0x0120, B:46:0x012e, B:48:0x0155, B:50:0x016a, B:54:0x0178, B:57:0x0180, B:60:0x01f7, B:71:0x0227, B:63:0x0204, B:66:0x0213, B:81:0x027a, B:82:0x027d, B:47:0x0149), top: B:95:0x0106, inners: #2 }] */
    /* JADX WARN: Code duplicated, block: B:46:0x012e A[Catch: all -> 0x0129, TRY_ENTER, TRY_LEAVE, TryCatch #3 {all -> 0x0129, blocks: (B:35:0x0106, B:41:0x0120, B:46:0x012e, B:48:0x0155, B:50:0x016a, B:54:0x0178, B:57:0x0180, B:60:0x01f7, B:71:0x0227, B:63:0x0204, B:66:0x0213, B:81:0x027a, B:82:0x027d, B:47:0x0149), top: B:95:0x0106, inners: #2 }] */
    /* JADX WARN: Code duplicated, block: B:50:0x016a A[Catch: all -> 0x0129, TryCatch #3 {all -> 0x0129, blocks: (B:35:0x0106, B:41:0x0120, B:46:0x012e, B:48:0x0155, B:50:0x016a, B:54:0x0178, B:57:0x0180, B:60:0x01f7, B:71:0x0227, B:63:0x0204, B:66:0x0213, B:81:0x027a, B:82:0x027d, B:47:0x0149), top: B:95:0x0106, inners: #2 }] */
    /* JADX WARN: Code duplicated, block: B:52:0x0173  */
    /* JADX WARN: Code duplicated, block: B:55:0x017d A[PHI: r20 r21
      0x017d: PHI (r20v2 c0.l) = (r20v3 c0.l), (r20v4 c0.l) binds: [B:54:0x0178, B:51:0x0171] A[DONT_GENERATE, DONT_INLINE]
      0x017d: PHI (r21v2 vi.a) = (r21v3 vi.a), (r21v4 vi.a) binds: [B:54:0x0178, B:51:0x0171] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:57:0x0180 A[Catch: all -> 0x0129, TRY_LEAVE, TryCatch #3 {all -> 0x0129, blocks: (B:35:0x0106, B:41:0x0120, B:46:0x012e, B:48:0x0155, B:50:0x016a, B:54:0x0178, B:57:0x0180, B:60:0x01f7, B:71:0x0227, B:63:0x0204, B:66:0x0213, B:81:0x027a, B:82:0x027d, B:47:0x0149), top: B:95:0x0106, inners: #2 }] */
    /* JADX WARN: Code duplicated, block: B:60:0x01f7 A[Catch: all -> 0x0129, TRY_ENTER, TryCatch #3 {all -> 0x0129, blocks: (B:35:0x0106, B:41:0x0120, B:46:0x012e, B:48:0x0155, B:50:0x016a, B:54:0x0178, B:57:0x0180, B:60:0x01f7, B:71:0x0227, B:63:0x0204, B:66:0x0213, B:81:0x027a, B:82:0x027d, B:47:0x0149), top: B:95:0x0106, inners: #2 }] */
    /* JADX WARN: Code duplicated, block: B:63:0x0204 A[Catch: all -> 0x0129, TryCatch #3 {all -> 0x0129, blocks: (B:35:0x0106, B:41:0x0120, B:46:0x012e, B:48:0x0155, B:50:0x016a, B:54:0x0178, B:57:0x0180, B:60:0x01f7, B:71:0x0227, B:63:0x0204, B:66:0x0213, B:81:0x027a, B:82:0x027d, B:47:0x0149), top: B:95:0x0106, inners: #2 }] */
    /* JADX WARN: Code duplicated, block: B:65:0x0212  */
    /* JADX WARN: Code duplicated, block: B:66:0x0213 A[Catch: all -> 0x0129, TryCatch #3 {all -> 0x0129, blocks: (B:35:0x0106, B:41:0x0120, B:46:0x012e, B:48:0x0155, B:50:0x016a, B:54:0x0178, B:57:0x0180, B:60:0x01f7, B:71:0x0227, B:63:0x0204, B:66:0x0213, B:81:0x027a, B:82:0x027d, B:47:0x0149), top: B:95:0x0106, inners: #2 }] */
    /* JADX WARN: Code duplicated, block: B:68:0x021f  */
    /* JADX WARN: Code duplicated, block: B:70:0x0224  */
    /* JADX WARN: Code duplicated, block: B:75:0x0243  */
    /* JADX WARN: Code duplicated, block: B:78:0x0252 A[Catch: all -> 0x0051, TRY_LEAVE, TryCatch #0 {all -> 0x0051, blocks: (B:14:0x0041, B:76:0x024a, B:78:0x0252, B:22:0x006b), top: B:89:0x002b }] */
    /* JADX WARN: Code duplicated, block: B:7:0x0019  */
    /* JADX WARN: Code duplicated, block: B:98:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r2v34, types: [java.lang.AutoCloseable] */
    /* JADX WARN: Type inference failed for: r2v38 */
    /* JADX WARN: Type inference failed for: r2v41 */
    /* JADX WARN: Type inference failed for: r2v5, types: [java.lang.AutoCloseable] */
    /* JADX WARN: Type inference failed for: r2v6 */
    /* JADX WARN: Type inference failed for: r5v0, types: [int] */
    /* JADX WARN: Type inference failed for: r5v1 */
    /* JADX WARN: Type inference failed for: r5v14 */
    /* JADX WARN: Type inference failed for: r5v2, types: [java.lang.AutoCloseable] */
    /* JADX WARN: Type inference failed for: r5v21 */
    /* JADX WARN: Type inference failed for: r5v22 */
    /* JADX WARN: Type inference failed for: r5v5 */
    /* JADX WARN: Type inference failed for: r5v7 */
    /* JADX WARN: Type inference failed for: r5v8 */
    /* JADX WARN: Type inference failed for: r6v1, types: [java.lang.AutoCloseable] */
    /* JADX WARN: Type inference failed for: r6v3 */
    /* JADX WARN: Type inference failed for: r6v5 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:75:0x0243 -> B:16:0x004d). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions stack size limit reached
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
        */
    public final java.lang.Object b(java.lang.String r30, a0.x1 r31, ej.l r32, wi.c r33) {
        /*
            Method dump skipped, instruction units count: 647
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: a0.r4.b(java.lang.String, a0.x1, ej.l, wi.c):java.lang.Object");
    }
}
