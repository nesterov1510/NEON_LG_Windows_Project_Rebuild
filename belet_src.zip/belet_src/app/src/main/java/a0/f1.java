package a0;

import android.hardware.camera2.CameraExtensionCharacteristics;
import java.util.LinkedHashMap;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class f1 implements z.j {
    public final int X;
    public final CameraExtensionCharacteristics Y;
    public final Object Z;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final String f84e;

    public f1(String camera, int i10, CameraExtensionCharacteristics cameraExtensionCharacteristics) {
        kotlin.jvm.internal.q.g(camera, "camera");
        this.f84e = camera;
        this.X = i10;
        this.Y = cameraExtensionCharacteristics;
        new LinkedHashMap();
        new LinkedHashMap();
        new LinkedHashMap();
        qi.g gVar = qi.g.f17354e;
        g0.c.v(gVar, new e1(this, 0));
        g0.c.v(gVar, new e1(this, 1));
        this.Z = g0.c.v(gVar, new e1(this, 2));
        g0.c.v(gVar, new e1(this, 3));
    }

    @Override // z.o1
    public final Object D(kotlin.jvm.internal.h hVar) {
        if (hVar.equals(kotlin.jvm.internal.e0.a(CameraExtensionCharacteristics.class))) {
            return this.Y;
        }
        return null;
    }
}
