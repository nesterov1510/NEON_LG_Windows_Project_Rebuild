package a0;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class o3 implements x4 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final i3 f257a;

    public o3(i3 captureSessionState) {
        kotlin.jvm.internal.q.g(captureSessionState, "captureSessionState");
        this.f257a = captureSessionState;
    }

    @Override // a0.x4
    public final void a() {
        this.f257a.a();
    }

    @Override // a0.x4
    public final void c() {
        this.f257a.c();
    }
}
