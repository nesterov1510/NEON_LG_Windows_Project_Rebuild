package a0;

import android.hardware.camera2.CameraExtensionSession;
import android.hardware.camera2.CameraExtensionSession$StateCallback;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class r extends CameraExtensionSession$StateCallback {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final i f293a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final o3 f294b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final a2 f295c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final m7.c f296d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final c0.e f297e;
    public final pj.e f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final pj.e f298g;

    public r(i iVar, o3 o3Var, x4 x4Var, a2 cameraErrorListener, m7.c cVar, c0.e eVar) {
        kotlin.jvm.internal.q.g(cameraErrorListener, "cameraErrorListener");
        this.f293a = iVar;
        this.f294b = o3Var;
        this.f295c = cameraErrorListener;
        this.f296d = cVar;
        this.f297e = eVar;
        this.f = pj.b.atomic(x4Var);
        this.f298g = pj.b.atomic((Object) null);
    }

    public final i2 a(CameraExtensionSession cameraExtensionSession, a2 a2Var) {
        i2 i2Var = (i2) this.f298g.getValue();
        if (i2Var != null) {
            return i2Var;
        }
        k kVar = new k(this.f293a, cameraExtensionSession, a2Var, this.f297e);
        if (this.f298g.compareAndSet(null, kVar)) {
            return kVar;
        }
        Object value = this.f298g.getValue();
        kotlin.jvm.internal.q.d(value);
        return (i2) value;
    }

    public final void onClosed(CameraExtensionSession session) {
        kotlin.jvm.internal.q.g(session, "session");
        a(session, this.f295c);
        i2 i2VarA = a(session, this.f295c);
        o3 o3Var = this.f294b;
        o3Var.getClass();
        o3Var.f257a.h(i2VarA);
        x4 x4Var = (x4) this.f.getAndSet(null);
        if (x4Var != null) {
            x4Var.a();
        }
        this.f294b.a();
        m7.c cVar = this.f296d;
        if (cVar != null) {
            cVar.x(this.f293a.Y);
        }
    }

    public final void onConfigureFailed(CameraExtensionSession session) {
        kotlin.jvm.internal.q.g(session, "session");
        i2 i2VarA = a(session, this.f295c);
        o3 o3Var = this.f294b;
        o3Var.getClass();
        o3Var.f257a.d(i2VarA);
        x4 x4Var = (x4) this.f.getAndSet(null);
        if (x4Var != null) {
            x4Var.a();
        }
        this.f294b.a();
        m7.c cVar = this.f296d;
        if (cVar != null) {
            cVar.y(this.f293a.Y);
        }
    }

    public final void onConfigured(CameraExtensionSession session) {
        kotlin.jvm.internal.q.g(session, "session");
        i2 i2VarA = a(session, this.f295c);
        o3 o3Var = this.f294b;
        o3Var.getClass();
        o3Var.f257a.e(i2VarA);
        x4 x4Var = (x4) this.f.getAndSet(null);
        if (x4Var != null) {
            x4Var.a();
        }
        m7.c cVar = this.f296d;
        if (cVar != null) {
            cVar.z(this.f293a.Y);
        }
    }
}
