package a0;

import android.os.Build;
import android.util.Log;
import okhttp3.internal.ws.WebSocketProtocol;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class b extends wi.i implements ej.p {
    public /* synthetic */ Object X;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f10e;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ b(int i10, ui.d dVar, int i11) {
        super(i10, dVar);
        this.f10e = i11;
    }

    @Override // wi.a
    public final ui.d create(Object obj, ui.d dVar) {
        switch (this.f10e) {
            case 0:
                b bVar = new b(2, dVar, 0);
                bVar.X = obj;
                return bVar;
            case 1:
                b bVar2 = new b(2, dVar, 1);
                bVar2.X = obj;
                return bVar2;
            case 2:
                b bVar3 = new b(2, dVar, 2);
                bVar3.X = obj;
                return bVar3;
            case 3:
                b bVar4 = new b(2, dVar, 3);
                bVar4.X = obj;
                return bVar4;
            case 4:
                b bVar5 = new b(2, dVar, 4);
                bVar5.X = obj;
                return bVar5;
            case 5:
                b bVar6 = new b(2, dVar, 5);
                bVar6.X = obj;
                return bVar6;
            case 6:
                b bVar7 = new b(2, dVar, 6);
                bVar7.X = obj;
                return bVar7;
            case 7:
                b bVar8 = new b(2, dVar, 7);
                bVar8.X = obj;
                return bVar8;
            case 8:
                b bVar9 = new b(2, dVar, 8);
                bVar9.X = obj;
                return bVar9;
            case 9:
                b bVar10 = new b(2, dVar, 9);
                bVar10.X = obj;
                return bVar10;
            case 10:
                b bVar11 = new b(2, dVar, 10);
                bVar11.X = obj;
                return bVar11;
            case ue.r.NETWORK_CLIENT_ERROR_REASON_FIELD_NUMBER /* 11 */:
                b bVar12 = new b(2, dVar, 11);
                bVar12.X = obj;
                return bVar12;
            case ue.r.CUSTOM_ATTRIBUTES_FIELD_NUMBER /* 12 */:
                b bVar13 = new b(2, dVar, 12);
                bVar13.X = obj;
                return bVar13;
            case ue.r.PERF_SESSIONS_FIELD_NUMBER /* 13 */:
                b bVar14 = new b(2, dVar, 13);
                bVar14.X = obj;
                return bVar14;
            case 14:
                b bVar15 = new b(2, dVar, 14);
                bVar15.X = obj;
                return bVar15;
            case WebSocketProtocol.B0_MASK_OPCODE /* 15 */:
                b bVar16 = new b(2, dVar, 15);
                bVar16.X = obj;
                return bVar16;
            case WebSocketProtocol.B0_FLAG_RSV3 /* 16 */:
                b bVar17 = new b(2, dVar, 16);
                bVar17.X = obj;
                return bVar17;
            case 17:
                b bVar18 = new b(2, dVar, 17);
                bVar18.X = obj;
                return bVar18;
            default:
                b bVar19 = new b(2, dVar, 18);
                bVar19.X = obj;
                return bVar19;
        }
    }

    @Override // ej.p
    public final Object invoke(Object obj, Object obj2) {
        switch (this.f10e) {
            case 0:
                return ((b) create((l2) obj, (ui.d) obj2)).invokeSuspend(qi.b0.f17350a);
            case 1:
                return ((b) create((l2) obj, (ui.d) obj2)).invokeSuspend(qi.b0.f17350a);
            case 2:
                return ((b) create((l2) obj, (ui.d) obj2)).invokeSuspend(qi.b0.f17350a);
            case 3:
                return ((b) create((l2) obj, (ui.d) obj2)).invokeSuspend(qi.b0.f17350a);
            case 4:
                return ((b) create((bi.e) obj, (ui.d) obj2)).invokeSuspend(qi.b0.f17350a);
            case 5:
                b bVar = (b) create((String) obj, (ui.d) obj2);
                qi.b0 b0Var = qi.b0.f17350a;
                bVar.invokeSuspend(b0Var);
                return b0Var;
            case 6:
                return ((b) create((nk.d) obj, (ui.d) obj2)).invokeSuspend(qi.b0.f17350a);
            case 7:
                return ((b) create((nk.d) obj, (ui.d) obj2)).invokeSuspend(qi.b0.f17350a);
            case 8:
                return ((b) create((nk.d) obj, (ui.d) obj2)).invokeSuspend(qi.b0.f17350a);
            case 9:
                ((b) create((vh.b) obj, (ui.d) obj2)).invokeSuspend(qi.b0.f17350a);
                return null;
            case 10:
                return ((b) create((p2.e1) obj, (ui.d) obj2)).invokeSuspend(qi.b0.f17350a);
            case ue.r.NETWORK_CLIENT_ERROR_REASON_FIELD_NUMBER /* 11 */:
                return ((b) create((kotlinx.coroutines.flow.i) obj, (ui.d) obj2)).invokeSuspend(qi.b0.f17350a);
            case ue.r.CUSTOM_ATTRIBUTES_FIELD_NUMBER /* 12 */:
                return ((b) create((kotlinx.coroutines.flow.i) obj, (ui.d) obj2)).invokeSuspend(qi.b0.f17350a);
            case ue.r.PERF_SESSIONS_FIELD_NUMBER /* 13 */:
                return ((b) create((kotlinx.coroutines.flow.i) obj, (ui.d) obj2)).invokeSuspend(qi.b0.f17350a);
            case 14:
                return ((b) create((kotlinx.coroutines.flow.i) obj, (ui.d) obj2)).invokeSuspend(qi.b0.f17350a);
            case WebSocketProtocol.B0_MASK_OPCODE /* 15 */:
                return ((b) create((kotlinx.coroutines.flow.i) obj, (ui.d) obj2)).invokeSuspend(qi.b0.f17350a);
            case WebSocketProtocol.B0_FLAG_RSV3 /* 16 */:
                return ((b) create((kotlinx.coroutines.flow.i) obj, (ui.d) obj2)).invokeSuspend(qi.b0.f17350a);
            case 17:
                return ((b) create((ri.w) obj, (ui.d) obj2)).invokeSuspend(qi.b0.f17350a);
            default:
                b bVar2 = (b) create((y5.i0) obj, (ui.d) obj2);
                qi.b0 b0Var2 = qi.b0.f17350a;
                bVar2.invokeSuspend(b0Var2);
                return b0Var2;
        }
    }

    @Override // wi.a
    public final Object invokeSuspend(Object obj) {
        int i10 = this.f10e;
        qi.b0 b0Var = qi.b0.f17350a;
        boolean z5 = false;
        switch (i10) {
            case 0:
                vi.a aVar = vi.a.f21252e;
                g6.y.I(obj);
                l2 l2Var = (l2) this.X;
                return Boolean.valueOf((l2Var instanceof n2) || (l2Var instanceof m2));
            case 1:
                vi.a aVar2 = vi.a.f21252e;
                g6.y.I(obj);
                return Boolean.valueOf(((l2) this.X) instanceof m2);
            case 2:
                vi.a aVar3 = vi.a.f21252e;
                g6.y.I(obj);
                return Boolean.valueOf(!(((l2) this.X) instanceof w2));
            case 3:
                vi.a aVar4 = vi.a.f21252e;
                g6.y.I(obj);
                return Boolean.valueOf(!kotlin.jvm.internal.q.c((l2) this.X, w2.f374a));
            case 4:
                bi.e eVar = (bi.e) this.X;
                vi.a aVar5 = vi.a.f21252e;
                g6.y.I(obj);
                return Boolean.valueOf(eVar != null);
            case 5:
                vi.a aVar6 = vi.a.f21252e;
                g6.y.I(obj);
                com.google.protobuf.m0.q("Error failed to fetch the remote configs: ", (String) this.X, "FirebaseSessions");
                return b0Var;
            case 6:
                nk.d dVar = (nk.d) this.X;
                vi.a aVar7 = vi.a.f21252e;
                g6.y.I(obj);
                return Boolean.valueOf(!(dVar instanceof nk.b));
            case 7:
                nk.d dVar2 = (nk.d) this.X;
                vi.a aVar8 = vi.a.f21252e;
                g6.y.I(obj);
                return Boolean.valueOf(!(dVar2 instanceof nk.b));
            case 8:
                nk.d dVar3 = (nk.d) this.X;
                vi.a aVar9 = vi.a.f21252e;
                g6.y.I(obj);
                return Boolean.valueOf(!(dVar3 instanceof nk.b));
            case 9:
                vh.b bVar = (vh.b) this.X;
                vi.a aVar10 = vi.a.f21252e;
                g6.y.I(obj);
                if (bVar.b().c().getAttributes().e(mh.d.f15359b) == null) {
                    return null;
                }
                throw new ClassCastException();
            case 10:
                vi.a aVar11 = vi.a.f21252e;
                g6.y.I(obj);
                return Boolean.valueOf(!(((p2.e1) this.X) instanceof p2.i0));
            case ue.r.NETWORK_CLIENT_ERROR_REASON_FIELD_NUMBER /* 11 */:
                kotlinx.coroutines.flow.i iVar = (kotlinx.coroutines.flow.i) this.X;
                vi.a aVar12 = vi.a.f21252e;
                g6.y.I(obj);
                return iVar;
            case ue.r.CUSTOM_ATTRIBUTES_FIELD_NUMBER /* 12 */:
                kotlinx.coroutines.flow.i iVar2 = (kotlinx.coroutines.flow.i) this.X;
                vi.a aVar13 = vi.a.f21252e;
                g6.y.I(obj);
                return iVar2;
            case ue.r.PERF_SESSIONS_FIELD_NUMBER /* 13 */:
                kotlinx.coroutines.flow.i iVar3 = (kotlinx.coroutines.flow.i) this.X;
                vi.a aVar14 = vi.a.f21252e;
                g6.y.I(obj);
                return iVar3;
            case 14:
                kotlinx.coroutines.flow.i iVar4 = (kotlinx.coroutines.flow.i) this.X;
                vi.a aVar15 = vi.a.f21252e;
                g6.y.I(obj);
                return iVar4;
            case WebSocketProtocol.B0_MASK_OPCODE /* 15 */:
                kotlinx.coroutines.flow.i iVar5 = (kotlinx.coroutines.flow.i) this.X;
                vi.a aVar16 = vi.a.f21252e;
                g6.y.I(obj);
                return iVar5;
            case WebSocketProtocol.B0_FLAG_RSV3 /* 16 */:
                kotlinx.coroutines.flow.i iVar6 = (kotlinx.coroutines.flow.i) this.X;
                vi.a aVar17 = vi.a.f21252e;
                g6.y.I(obj);
                return iVar6;
            case 17:
                vi.a aVar18 = vi.a.f21252e;
                g6.y.I(obj);
                return Boolean.valueOf(((ri.w) this.X) != null);
            default:
                vi.a aVar19 = vi.a.f21252e;
                g6.y.I(obj);
                y5.i0 i0Var = (y5.i0) this.X;
                if (Build.ID != null && Log.isLoggable("Paging", 2)) {
                    z5 = true;
                }
                if (z5) {
                    String message = "Sent " + i0Var;
                    kotlin.jvm.internal.q.g(message, "message");
                    Log.v("Paging", message, null);
                }
                return b0Var;
        }
    }
}
