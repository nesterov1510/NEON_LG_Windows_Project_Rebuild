package a0;

import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.util.Log;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class t1 extends wi.i implements ej.p {
    public final /* synthetic */ u1 X;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ String f327e;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public t1(String str, u1 u1Var, ui.d dVar) {
        super(2, dVar);
        this.f327e = str;
        this.X = u1Var;
    }

    @Override // wi.a
    public final ui.d create(Object obj, ui.d dVar) {
        return new t1(this.f327e, this.X, dVar);
    }

    @Override // ej.p
    public final Object invoke(Object obj, Object obj2) {
        return ((t1) create((kotlinx.coroutines.p0) obj, (ui.d) obj2)).invokeSuspend(qi.b0.f17350a);
    }

    @Override // wi.a
    public final Object invokeSuspend(Object obj) throws Exception {
        Boolean boolValueOf;
        int i10;
        CameraDevice.CameraDeviceSetup cameraDeviceSetup;
        vi.a aVar = vi.a.f21252e;
        g6.y.I(obj);
        String str = this.f327e;
        u1 u1Var = this.X;
        pi.a aVar2 = u1Var.f338a;
        a2 a2Var = u1Var.f340c;
        int i11 = 3;
        try {
            boolValueOf = Boolean.valueOf(((CameraManager) aVar2.get()).isCameraDeviceSetupSupported(str));
        } catch (Exception e3) {
            if (e3 instanceof CameraAccessException) {
                Log.w("CXCP", "Failed to execute call: Camera encountered an error: " + e3.getMessage());
                CameraAccessException cameraAccessException = (CameraAccessException) e3;
                int reason = cameraAccessException.getReason();
                if (reason == 1) {
                    i10 = 3;
                } else if (reason == 2) {
                    i10 = 6;
                } else if (reason == 3) {
                    i10 = 0;
                } else if (reason == 4) {
                    i10 = 1;
                } else if (reason != 5) {
                    Log.w("CXCP", "Unexpected CameraAccessException: " + cameraAccessException);
                    i10 = 11;
                } else {
                    i10 = 2;
                }
                a2Var.a(str, true, i10);
            } else if ((e3 instanceof IllegalArgumentException) || (e3 instanceof SecurityException) || (e3 instanceof UnsupportedOperationException) || (e3 instanceof NullPointerException)) {
                Log.w("CXCP", "Failed to execute call: Unexpected exception: " + e3.getMessage());
                a2Var.a(str, false, 9);
            } else {
                if (!(e3 instanceof IllegalStateException)) {
                    throw e3;
                }
                Log.d("CXCP", "Failed to execute call: Camera may be closed");
            }
            boolValueOf = null;
        }
        if (!kotlin.jvm.internal.q.c(boolValueOf, Boolean.TRUE)) {
            return null;
        }
        Log.d("CXCP", "Initializing CameraDeviceSetup for " + ((Object) z.p.b(str)));
        try {
            cameraDeviceSetup = ((CameraManager) aVar2.get()).getCameraDeviceSetup(str);
        } catch (Exception e10) {
            if (e10 instanceof CameraAccessException) {
                Log.w("CXCP", "Failed to execute call: Camera encountered an error: " + e10.getMessage());
                CameraAccessException cameraAccessException2 = (CameraAccessException) e10;
                int reason2 = cameraAccessException2.getReason();
                if (reason2 != 1) {
                    if (reason2 == 2) {
                        i11 = 6;
                    } else if (reason2 == 3) {
                        i11 = 0;
                    } else if (reason2 == 4) {
                        i11 = 1;
                    } else if (reason2 != 5) {
                        Log.w("CXCP", "Unexpected CameraAccessException: " + cameraAccessException2);
                        i11 = 11;
                    } else {
                        i11 = 2;
                    }
                }
                a2Var.a(str, true, i11);
            } else if ((e10 instanceof IllegalArgumentException) || (e10 instanceof SecurityException) || (e10 instanceof UnsupportedOperationException) || (e10 instanceof NullPointerException)) {
                Log.w("CXCP", "Failed to execute call: Unexpected exception: " + e10.getMessage());
                a2Var.a(str, false, 9);
            } else {
                if (!(e10 instanceof IllegalStateException)) {
                    throw e10;
                }
                Log.d("CXCP", "Failed to execute call: Camera may be closed");
            }
            cameraDeviceSetup = null;
        }
        if (cameraDeviceSetup != null) {
            return new y1(cameraDeviceSetup, str, a2Var);
        }
        return null;
    }
}
