package a0;

import android.content.SharedPreferences;
import android.os.HandlerThread;
import android.os.Process;
import android.os.Trace;
import androidx.media3.session.n5;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.sidesheet.SideSheetBehavior;
import com.google.android.material.textfield.TextInputLayout;
import java.io.ByteArrayInputStream;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;
import okhttp3.internal.ws.WebSocketProtocol;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class l0 implements Runnable {
    public final /* synthetic */ Object X;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f168e;

    public /* synthetic */ l0(int i10, Object obj) {
        this.f168e = i10;
        this.X = obj;
    }

    private final void a() {
        a4.h hVar = (a4.h) this.X;
        synchronized (hVar.f493a) {
            try {
                if (hVar.f503m) {
                    return;
                }
                long j10 = hVar.f502l - 1;
                hVar.f502l = j10;
                if (j10 > 0) {
                    return;
                }
                if (j10 < 0) {
                    hVar.c(new IllegalStateException());
                } else {
                    hVar.a();
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    private final void b() {
        synchronized (((androidx.media3.session.d4) this.X).X) {
        }
    }

    private final void c() {
        v2 v2Var = (v2) this.X;
        if (((g0.w) v2Var.f364d) != null) {
            g0.c.a("CX:unbindAll");
            try {
                g6.y.b();
                v2.b(v2Var, 0);
                c1.g gVar = (c1.g) v2Var.f365e;
                kotlin.jvm.internal.q.d(gVar);
                gVar.k((HashSet) v2Var.h);
                Trace.endSection();
                c1.g gVar2 = (c1.g) v2Var.f365e;
                kotlin.jvm.internal.q.d(gVar2);
                Set<c1.a> setKeySet = (HashSet) v2Var.h;
                synchronized (gVar2.f3855a) {
                    if (setKeySet == null) {
                        try {
                            setKeySet = gVar2.f3856b.keySet();
                        } catch (Throwable th2) {
                            throw th2;
                        }
                    }
                    for (c1.a aVar : setKeySet) {
                        if (gVar2.f3856b.containsKey(aVar)) {
                            gVar2.l((c1.b) gVar2.f3856b.get(aVar));
                        }
                    }
                }
            } catch (Throwable th3) {
                Trace.endSection();
                throw th3;
            }
        }
    }

    private final void d() {
        g0.r0 r0Var = (g0.r0) this.X;
        synchronized (r0Var.J0) {
            try {
                r0Var.L0 = null;
                g0.d1 d1Var = r0Var.K0;
                if (d1Var != null) {
                    r0Var.K0 = null;
                    r0Var.e(d1Var);
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    @Override // java.lang.Runnable
    public final void run() {
        int i10 = 0;
        ui.d dVar = null;
        switch (this.f168e) {
            case 0:
                kotlinx.coroutines.q0.cancel$default(((n0) this.X).f220a, null, 1, null);
                return;
            case 1:
                kotlinx.coroutines.q0.cancel$default(((u1) this.X).f342e, null, 1, null);
                return;
            case 2:
                a();
                return;
            case 3:
                androidx.fragment.app.d0 d0Var = (androidx.fragment.app.d0) this.X;
                d0Var.f1855d1.f1916s0.C(d0Var.Z);
                d0Var.Z = null;
                return;
            case 4:
                ArrayList arrayList = ((androidx.fragment.app.b1) this.X).f1837o;
                int size = arrayList.size();
                while (i10 < size) {
                    Object obj = arrayList.get(i10);
                    i10++;
                    ((eo.t0) obj).getClass();
                }
                return;
            case 5:
                androidx.lifecycle.i0 i0Var = (androidx.lifecycle.i0) this.X;
                androidx.lifecycle.x xVar = i0Var.f2020s0;
                if (i0Var.X == 0) {
                    i0Var.Y = true;
                    xVar.d(androidx.lifecycle.o.ON_PAUSE);
                }
                if (i0Var.f2018e == 0 && i0Var.Y) {
                    xVar.d(androidx.lifecycle.o.ON_STOP);
                    i0Var.Z = true;
                    return;
                }
                return;
            case 6:
                ((androidx.media3.session.b0) this.X).X();
                return;
            case 7:
                b();
                return;
            case 8:
                ((n5) this.X).c();
                return;
            case 9:
                SwipeRefreshLayout swipeRefreshLayout = (SwipeRefreshLayout) this.X;
                int[] iArr = SwipeRefreshLayout.f3173a1;
                swipeRefreshLayout.l();
                return;
            case 10:
                ArrayList arrayList2 = (ArrayList) this.X;
                int size2 = arrayList2.size();
                int i11 = 0;
                while (i11 < size2) {
                    Object obj2 = arrayList2.get(i11);
                    i11++;
                    ((ExecutorService) obj2).shutdownNow();
                }
                int size3 = arrayList2.size();
                while (i10 < size3) {
                    Object obj3 = arrayList2.get(i10);
                    i10++;
                    ((ExecutorService) obj3).awaitTermination(1L, TimeUnit.SECONDS);
                }
                return;
            case ue.r.NETWORK_CLIENT_ERROR_REASON_FIELD_NUMBER /* 11 */:
                HandlerThread handlerThread = (HandlerThread) this.X;
                handlerThread.quit();
                handlerThread.join(1000L);
                return;
            case ue.r.CUSTOM_ATTRIBUTES_FIELD_NUMBER /* 12 */:
                ExecutorService executorService = (ExecutorService) this.X;
                executorService.shutdownNow();
                executorService.awaitTermination(1L, TimeUnit.SECONDS);
                return;
            case ue.r.PERF_SESSIONS_FIELD_NUMBER /* 13 */:
                ((androidx.appcompat.app.j) this.X).invalidateOptionsMenu();
                return;
            case 14:
                c.h hVar = (c.h) this.X;
                Runnable runnable = hVar.X;
                if (runnable != null) {
                    runnable.run();
                    hVar.X = null;
                    return;
                }
                return;
            case WebSocketProtocol.B0_MASK_OPCODE /* 15 */:
                c.j.a((c.j) this.X);
                return;
            case WebSocketProtocol.B0_FLAG_RSV3 /* 16 */:
                c();
                return;
            case 17:
                c8.k.b((ByteArrayInputStream) this.X);
                return;
            case 18:
                ((com.airbnb.lottie.f0) this.X).d();
                return;
            case 19:
                MaterialButton.a((MaterialButton) this.X);
                return;
            case 20:
                ((com.google.android.material.textfield.c) this.X).s(true);
                return;
            case 21:
                com.google.android.material.textfield.k kVar = (com.google.android.material.textfield.k) this.X;
                boolean zIsPopupShowing = kVar.h.isPopupShowing();
                kVar.s(zIsPopupShowing);
                kVar.f6211m = zIsPopupShowing;
                return;
            case 22:
                ((TextInputLayout) this.X).u0.requestLayout();
                return;
            case 23:
                ((androidx.media3.session.t1) this.X).c();
                return;
            case 24:
                kotlinx.coroutines.j.runBlocking$default(null, new c((e0.a) this.X, dVar, 11), 1, null);
                return;
            case 25:
                androidx.media3.session.o oVar = (androidx.media3.session.o) this.X;
                oVar.X = false;
                SideSheetBehavior sideSheetBehavior = (SideSheetBehavior) oVar.f2562r0;
                n2.d dVar2 = sideSheetBehavior.f6111i;
                if (dVar2 != null && dVar2.f()) {
                    oVar.b(oVar.Y);
                    return;
                } else {
                    if (sideSheetBehavior.h == 2) {
                        sideSheetBehavior.y(oVar.Y);
                        return;
                    }
                    return;
                }
            case 26:
                Runnable runnable2 = (Runnable) this.X;
                Process.setThreadPriority(-3);
                runnable2.run();
                return;
            case 27:
                d();
                return;
            case 28:
                ((g0.k1) this.X).r();
                return;
            default:
                y4 y4Var = (y4) this.X;
                synchronized (((ArrayDeque) y4Var.Z)) {
                    SharedPreferences.Editor editorEdit = ((SharedPreferences) y4Var.f395e).edit();
                    String str = (String) y4Var.X;
                    StringBuilder sb2 = new StringBuilder();
                    Iterator it = ((ArrayDeque) y4Var.Z).iterator();
                    while (it.hasNext()) {
                        sb2.append((String) it.next());
                        sb2.append((String) y4Var.Y);
                    }
                    editorEdit.putString(str, sb2.toString()).apply();
                    break;
                }
                return;
        }
    }
}
