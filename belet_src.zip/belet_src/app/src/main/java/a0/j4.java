package a0;

import android.util.Log;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class j4 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final r4 f149a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final x1 f150b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final a2 f151c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final kotlinx.coroutines.p0 f152d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final a4.n f153e;
    public final LinkedHashSet f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final ArrayList f154g;

    public j4(c0.i permissions, r4 retryingCameraStateOpener, x1 camera2DeviceCloser, a2 camera2ErrorProcessor, c0.n threads) {
        kotlin.jvm.internal.q.g(permissions, "permissions");
        kotlin.jvm.internal.q.g(retryingCameraStateOpener, "retryingCameraStateOpener");
        kotlin.jvm.internal.q.g(camera2DeviceCloser, "camera2DeviceCloser");
        kotlin.jvm.internal.q.g(camera2ErrorProcessor, "camera2ErrorProcessor");
        kotlin.jvm.internal.q.g(threads, "threads");
        this.f149a = retryingCameraStateOpener;
        this.f150b = camera2DeviceCloser;
        this.f151c = camera2ErrorProcessor;
        kotlinx.coroutines.p0 scope = threads.f3841a;
        this.f152d = scope;
        h4 h4Var = new h4(1, this, j4.class, "prune", "prune$camera_camera2_pipe(Ljava/util/List;)V", 0, 0);
        ui.d dVar = null;
        t0 t0Var = new t0(this, dVar, 3);
        o4 o4Var = new o4(5);
        a4.n nVar = new a4.n();
        nVar.f515a = h4Var;
        nVar.f516b = o4Var;
        nVar.f517c = t0Var;
        nVar.f518d = pj.b.atomic(false);
        nVar.f519e = kotlinx.coroutines.channels.m.Channel$default(Integer.MAX_VALUE, null, new t3(5, nVar), 2, null);
        nVar.f = new ri.i();
        kotlin.jvm.internal.q.g(scope, "scope");
        if (!((pj.a) nVar.f518d).compareAndSet(false, true)) {
            throw new IllegalStateException("PruningProcessingQueue cannot be re-started!");
        }
        if (kotlinx.coroutines.k.launch$default(scope, null, null, new c(nVar, dVar, 5), 3, null).isCancelled()) {
            a4.n.c(nVar, null);
        }
        this.f153e = nVar;
        this.f = new LinkedHashSet();
        this.f154g = new ArrayList();
    }

    public final void a(String cameraId) {
        kotlin.jvm.internal.q.g(cameraId, "cameraId");
        m4 m4Var = new m4(cameraId);
        if (kotlinx.coroutines.channels.n.m37isSuccessimpl(((kotlinx.coroutines.channels.i) this.f153e.f519e).mo15trySendJP2dKIU(m4Var))) {
            return;
        }
        Log.e("CXCP", "Camera close by ID request failed for " + ((Object) z.p.b(cameraId)) + '!');
        m4Var.f218b.complete(qi.b0.f17350a);
    }

    /* JADX WARN: Code duplicated, block: B:22:0x0071  */
    /* JADX WARN: Code duplicated, block: B:25:0x0093  */
    /* JADX WARN: Code duplicated, block: B:27:0x009a  */
    /* JADX WARN: Code duplicated, block: B:29:0x00a8  */
    /* JADX WARN: Code duplicated, block: B:31:0x00ae  */
    /* JADX WARN: Code duplicated, block: B:34:0x00b8  */
    /* JADX WARN: Code duplicated, block: B:41:0x00e0 A[RETURN] */
    /* JADX WARN: Code duplicated, block: B:44:0x00c9 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:40:0x00de -> B:42:0x00e1). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions count limit reached at block B:29:0x00a8
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
        */
    public final java.lang.Object b(java.util.Set r14, wi.c r15) {
        /*
            Method dump skipped, instruction units count: 230
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: a0.j4.b(java.util.Set, wi.c):java.lang.Object");
    }

    public final void c(ArrayList arrayList) {
        int size = arrayList.size();
        int i10 = 0;
        while (i10 < size) {
            Object obj = arrayList.get(i10);
            i10++;
            x3 x3Var = (x3) obj;
            x3Var.f384c.b();
            this.f154g.remove(x3Var);
        }
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    public final Object d(String str, List list, y0 y0Var, kotlinx.coroutines.p0 p0Var, wi.c cVar) {
        c4 c4Var;
        if (cVar instanceof c4) {
            c4Var = (c4) cVar;
            int i10 = c4Var.f37s0;
            if ((i10 & Integer.MIN_VALUE) != 0) {
                c4Var.f37s0 = i10 - Integer.MIN_VALUE;
            } else {
                c4Var = new c4(this, cVar);
            }
        } else {
            c4Var = new c4(this, cVar);
        }
        Object objB = c4Var.Z;
        vi.a aVar = vi.a.f21252e;
        int i11 = c4Var.f37s0;
        if (i11 == 0) {
            g6.y.I(objB);
            Log.d("CXCP", "Opening " + ((Object) z.p.b(str)) + " with retries...");
            c4Var.f35e = str;
            c4Var.X = list;
            c4Var.Y = p0Var;
            c4Var.f37s0 = 1;
            objB = this.f149a.b(str, this.f150b, y0Var, c4Var);
            if (objB == aVar) {
                return aVar;
            }
        } else {
            if (i11 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            p0Var = c4Var.Y;
            list = c4Var.X;
            str = c4Var.f35e;
            g6.y.I(objB);
        }
        q3 q3Var = (q3) objB;
        m mVar = q3Var.f285a;
        return mVar == null ? new u3(q3Var.f286b) : new v3(new d(mVar, ri.m.E0(ri.m.o0(new z.p(str), list)), p0Var, new t3(2, this)));
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    public final Object e(k4 k4Var, wi.c cVar) {
        d4 d4Var;
        if (cVar instanceof d4) {
            d4Var = (d4) cVar;
            int i10 = d4Var.Z;
            if ((i10 & Integer.MIN_VALUE) != 0) {
                d4Var.Z = i10 - Integer.MIN_VALUE;
            } else {
                d4Var = new d4(this, cVar);
            }
        } else {
            d4Var = new d4(this, cVar);
        }
        Object obj = d4Var.X;
        vi.a aVar = vi.a.f21252e;
        int i11 = d4Var.Z;
        qi.b0 b0Var = qi.b0.f17350a;
        if (i11 == 0) {
            g6.y.I(obj);
            d dVar = k4Var.f163a;
            Log.i("CXCP", "PruningCamera2DeviceManager#processRequestClose(" + ((Object) z.p.b(dVar.f38a.f178a)) + ')');
            LinkedHashSet linkedHashSet = this.f;
            if (linkedHashSet.contains(dVar)) {
                linkedHashSet.remove(dVar);
            }
            ArrayList arrayList = new ArrayList();
            ArrayList arrayList2 = this.f154g;
            int size = arrayList2.size();
            int i12 = 0;
            while (i12 < size) {
                Object obj2 = arrayList2.get(i12);
                i12++;
                if (((x3) obj2).f383b.equals(dVar)) {
                    arrayList.add(obj2);
                }
            }
            d4Var.f73e = k4Var;
            d4Var.Z = 1;
            c(arrayList);
            if (b0Var != aVar) {
            }
        }
        if (i11 != 1) {
            if (i11 != 2) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            g6.y.I(obj);
            return b0Var;
        }
        k4Var = d4Var.f73e;
        g6.y.I(obj);
        k4Var.f163a.c();
        d dVar2 = k4Var.f163a;
        d4Var.f73e = null;
        d4Var.Z = 2;
        return dVar2.b(d4Var) == aVar ? aVar : b0Var;
    }

    /* JADX WARN: Code duplicated, block: B:26:0x0076  */
    /* JADX WARN: Code duplicated, block: B:32:0x0088 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:34:? A[LOOP:0: B:24:0x0070->B:34:?, LOOP_END, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x0053, code lost:
    
        if (r3 == r1) goto L28;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.Object f(a0.l4 r8, wi.c r9) {
        /*
            r7 = this;
            boolean r0 = r9 instanceof a0.e4
            if (r0 == 0) goto L13
            r0 = r9
            a0.e4 r0 = (a0.e4) r0
            int r1 = r0.f83r0
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.f83r0 = r1
            goto L18
        L13:
            a0.e4 r0 = new a0.e4
            r0.<init>(r7, r9)
        L18:
            java.lang.Object r9 = r0.Y
            vi.a r1 = vi.a.f21252e
            int r2 = r0.f83r0
            qi.b0 r3 = qi.b0.f17350a
            r4 = 2
            r5 = 1
            java.util.LinkedHashSet r6 = r7.f
            if (r2 == 0) goto L40
            if (r2 == r5) goto L3a
            if (r2 != r4) goto L32
            java.util.Iterator r8 = r0.X
            a0.l4 r2 = r0.f82e
            g6.y.I(r9)
            goto L70
        L32:
            java.lang.IllegalStateException r8 = new java.lang.IllegalStateException
            java.lang.String r9 = "call to 'resume' before 'invoke' with coroutine"
            r8.<init>(r9)
            throw r8
        L3a:
            a0.l4 r8 = r0.f82e
            g6.y.I(r9)
            goto L56
        L40:
            g6.y.I(r9)
            java.lang.String r9 = "CXCP"
            java.lang.String r2 = "PruningCamera2DeviceManager#processRequestCloseAll()"
            android.util.Log.i(r9, r2)
            r0.f82e = r8
            r0.f83r0 = r5
            java.util.ArrayList r9 = r7.f154g
            r7.c(r9)
            if (r3 != r1) goto L56
            goto L88
        L56:
            java.util.Iterator r9 = r6.iterator()
        L5a:
            boolean r2 = r9.hasNext()
            if (r2 == 0) goto L6a
            java.lang.Object r2 = r9.next()
            a0.d r2 = (a0.d) r2
            r2.c()
            goto L5a
        L6a:
            java.util.Iterator r9 = r6.iterator()
            r2 = r8
            r8 = r9
        L70:
            boolean r9 = r8.hasNext()
            if (r9 == 0) goto L89
            java.lang.Object r9 = r8.next()
            a0.d r9 = (a0.d) r9
            r0.f82e = r2
            r0.X = r8
            r0.f83r0 = r4
            java.lang.Object r9 = r9.b(r0)
            if (r9 != r1) goto L70
        L88:
            return r1
        L89:
            r6.clear()
            kotlinx.coroutines.z r8 = r2.f177a
            r8.complete(r3)
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: a0.j4.f(a0.l4, wi.c):java.lang.Object");
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    public final Object g(m4 m4Var, wi.c cVar) {
        f4 f4Var;
        m4 m4Var2;
        String str;
        Object next;
        m4 m4Var3;
        if (cVar instanceof f4) {
            f4Var = (f4) cVar;
            int i10 = f4Var.f87r0;
            if ((i10 & Integer.MIN_VALUE) != 0) {
                f4Var.f87r0 = i10 - Integer.MIN_VALUE;
            } else {
                f4Var = new f4(this, cVar);
            }
        } else {
            f4Var = new f4(this, cVar);
        }
        Object obj = f4Var.Y;
        vi.a aVar = vi.a.f21252e;
        int i11 = f4Var.f87r0;
        qi.b0 b0Var = qi.b0.f17350a;
        if (i11 != 0) {
            if (i11 == 1) {
                str = f4Var.X;
                m4Var2 = f4Var.f86e;
                g6.y.I(obj);
            } else {
                if (i11 != 2) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                m4Var3 = f4Var.f86e;
                g6.y.I(obj);
            }
            m4Var2 = m4Var3;
            m4Var2.f218b.complete(b0Var);
            return b0Var;
        }
        g6.y.I(obj);
        String str2 = m4Var.f217a;
        Log.i("CXCP", "PruningCamera2DeviceManager#processRequestCloseById(" + ((Object) z.p.b(m4Var.f217a)) + ')');
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = this.f154g;
        int size = arrayList2.size();
        int i12 = 0;
        while (i12 < size) {
            Object obj2 = arrayList2.get(i12);
            i12++;
            if (kotlin.jvm.internal.q.c(((x3) obj2).f382a.f233a.f20a, str2)) {
                arrayList.add(obj2);
            }
        }
        f4Var.f86e = m4Var;
        f4Var.X = str2;
        f4Var.f87r0 = 1;
        c(arrayList);
        if (b0Var != aVar) {
            m4Var2 = m4Var;
            str = str2;
        }
        return aVar;
        LinkedHashSet linkedHashSet = this.f;
        Iterator it = linkedHashSet.iterator();
        do {
            if (!it.hasNext()) {
                next = null;
                break;
            }
            next = it.next();
        } while (!kotlin.jvm.internal.q.c(((d) next).f38a.f178a, str));
        d dVar = (d) next;
        if (dVar != null) {
            linkedHashSet.remove(dVar);
            dVar.c();
            f4Var.f86e = m4Var2;
            f4Var.X = null;
            f4Var.f87r0 = 2;
            if (dVar.b(f4Var) != aVar) {
                m4Var3 = m4Var2;
                m4Var2 = m4Var3;
            }
            return aVar;
        }
        m4Var2.f218b.complete(b0Var);
        return b0Var;
    }

    /* JADX WARN: Code duplicated, block: B:103:0x0273  */
    /* JADX WARN: Code duplicated, block: B:108:0x0287  */
    /* JADX WARN: Code duplicated, block: B:113:0x0178 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:117:0x023f A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:121:0x0283 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:123:? A[LOOP:2: B:49:0x0148->B:123:?, LOOP_END, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:47:0x013a A[LOOP:3: B:45:0x0134->B:47:0x013a, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:51:0x014e  */
    /* JADX WARN: Code duplicated, block: B:63:0x0194  */
    /* JADX WARN: Code duplicated, block: B:66:0x019e  */
    /* JADX WARN: Code duplicated, block: B:68:0x01a4  */
    /* JADX WARN: Code duplicated, block: B:69:0x01cc  */
    /* JADX WARN: Code duplicated, block: B:72:0x01eb  */
    /* JADX WARN: Code duplicated, block: B:74:0x01ef  */
    /* JADX WARN: Code duplicated, block: B:76:0x01fd  */
    /* JADX WARN: Code duplicated, block: B:79:0x0206  */
    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    /* JADX WARN: Code duplicated, block: B:82:0x0210  */
    /* JADX WARN: Code duplicated, block: B:84:0x021c  */
    /* JADX WARN: Code duplicated, block: B:87:0x0223  */
    /* JADX WARN: Code duplicated, block: B:89:0x022a  */
    /* JADX WARN: Code duplicated, block: B:97:0x025d  */
    /* JADX WARN: Code restructure failed: missing block: B:104:0x0281, code lost:
    
        if (qi.b0.f17350a == r1) goto L105;
     */
    /* JADX WARN: Code restructure failed: missing block: B:99:0x026d, code lost:
    
        if (b(r13, r0) == r1) goto L105;
     */
    /* JADX WARN: Instruction removed from duplicated block: B:68:0x01a4, please report this as an issue */
    /* JADX WARN: Instruction removed from duplicated block: B:69:0x01cc, please report this as an issue */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.Object h(a0.n4 r13, wi.c r14) {
        /*
            Method dump skipped, instruction units count: 676
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: a0.j4.h(a0.n4, wi.c):java.lang.Object");
    }

    /* JADX WARN: Code duplicated, block: B:19:0x0059  */
    /* JADX WARN: Code duplicated, block: B:24:0x0070  */
    /* JADX WARN: Code duplicated, block: B:27:0x0084  */
    /* JADX WARN: Code duplicated, block: B:55:0x0069 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:57:? A[LOOP:0: B:17:0x0053->B:57:?, LOOP_END, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:7:0x0015  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:27:0x0084 -> B:28:0x0088). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions stack size limit reached
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
        */
    public final java.lang.Object i(java.lang.String r14, a0.n4 r15, wi.c r16) {
        /*
            Method dump skipped, instruction units count: 325
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: a0.j4.i(java.lang.String, a0.n4, wi.c):java.lang.Object");
    }
}
