package a0;

import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.params.OutputConfiguration;
import android.view.Surface;
import java.util.ArrayList;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public abstract class a0 {
    public static final void a(OutputConfiguration outputConfiguration, Surface surface) {
        kotlin.jvm.internal.q.g(surface, "surface");
        outputConfiguration.addSurface(surface);
    }

    public static final void b(OutputConfiguration outputConfiguration) {
        outputConfiguration.enableSurfaceSharing();
    }

    public static final void c(CameraCaptureSession cameraCaptureSession, ArrayList arrayList) throws CameraAccessException {
        cameraCaptureSession.finalizeOutputConfigurations(arrayList);
    }
}
