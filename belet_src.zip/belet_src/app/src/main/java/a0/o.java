package a0;

import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraConstrainedHighSpeedCaptureSession;
import android.os.Build;
import android.os.Handler;
import android.util.Log;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class o extends CameraCaptureSession.StateCallback {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final i f237a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final f2 f238b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final a2 f239c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final m7.c f240d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final Handler f241e;
    public final pj.e f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final pj.e f242g;

    public o(i iVar, f2 stateCallback, x4 x4Var, a2 cameraErrorListener, m7.c cVar, Handler callbackHandler) {
        kotlin.jvm.internal.q.g(stateCallback, "stateCallback");
        kotlin.jvm.internal.q.g(cameraErrorListener, "cameraErrorListener");
        kotlin.jvm.internal.q.g(callbackHandler, "callbackHandler");
        this.f237a = iVar;
        this.f238b = stateCallback;
        this.f239c = cameraErrorListener;
        this.f240d = cVar;
        this.f241e = callbackHandler;
        this.f = pj.b.atomic(x4Var);
        this.f242g = pj.b.atomic((Object) null);
    }

    public final g2 a(CameraCaptureSession cameraCaptureSession, a2 a2Var) {
        pj.e eVar = this.f242g;
        g2 g2Var = (g2) eVar.getValue();
        if (g2Var != null) {
            return g2Var;
        }
        boolean z5 = cameraCaptureSession instanceof CameraConstrainedHighSpeedCaptureSession;
        Handler handler = this.f241e;
        i iVar = this.f237a;
        g2 hVar = z5 ? new h(iVar, (CameraConstrainedHighSpeedCaptureSession) cameraCaptureSession, a2Var, handler) : new g(iVar, cameraCaptureSession, a2Var, handler);
        if (eVar.compareAndSet(null, hVar)) {
            return hVar;
        }
        Object value = eVar.getValue();
        kotlin.jvm.internal.q.d(value);
        return (g2) value;
    }

    @Override // android.hardware.camera2.CameraCaptureSession.StateCallback
    public final void onActive(CameraCaptureSession session) {
        kotlin.jvm.internal.q.g(session, "session");
        a2 a2Var = this.f239c;
        a(session, a2Var);
        this.f238b.b(a(session, a2Var));
        m7.c cVar = this.f240d;
        if (cVar != null) {
            String cameraId = this.f237a.Y;
            kotlin.jvm.internal.q.g(cameraId, "cameraId");
            Iterator it = ((List) ((pj.e) cVar.Y).getValue()).iterator();
            while (it.hasNext()) {
                ((CameraCaptureSession.StateCallback) it.next()).onActive((w.k0) cVar.X);
            }
        }
    }

    @Override // android.hardware.camera2.CameraCaptureSession.StateCallback
    public final void onCaptureQueueEmpty(CameraCaptureSession session) {
        kotlin.jvm.internal.q.g(session, "session");
        a2 a2Var = this.f239c;
        a(session, a2Var);
        this.f238b.g(a(session, a2Var));
        m7.c cVar = this.f240d;
        if (cVar != null) {
            String cameraId = this.f237a.Y;
            kotlin.jvm.internal.q.g(cameraId, "cameraId");
            if (Build.VERSION.SDK_INT >= 26) {
                ra.a.j((w.k0) cVar.X, (pj.e) cVar.Y);
            } else if (y6.a.p()) {
                Log.e("CXCP", "onCaptureQueueEmpty called for unsupported OS version.");
            }
        }
    }

    @Override // android.hardware.camera2.CameraCaptureSession.StateCallback
    public final void onClosed(CameraCaptureSession session) {
        kotlin.jvm.internal.q.g(session, "session");
        a2 a2Var = this.f239c;
        a(session, a2Var);
        g2 g2VarA = a(session, a2Var);
        f2 f2Var = this.f238b;
        f2Var.h(g2VarA);
        x4 x4Var = (x4) this.f.getAndSet(null);
        if (x4Var != null) {
            x4Var.a();
        }
        f2Var.a();
        m7.c cVar = this.f240d;
        if (cVar != null) {
            cVar.x(this.f237a.Y);
        }
    }

    @Override // android.hardware.camera2.CameraCaptureSession.StateCallback
    public final void onConfigureFailed(CameraCaptureSession session) {
        kotlin.jvm.internal.q.g(session, "session");
        g2 g2VarA = a(session, this.f239c);
        f2 f2Var = this.f238b;
        f2Var.d(g2VarA);
        x4 x4Var = (x4) this.f.getAndSet(null);
        if (x4Var != null) {
            x4Var.a();
        }
        f2Var.a();
        m7.c cVar = this.f240d;
        if (cVar != null) {
            cVar.y(this.f237a.Y);
        }
    }

    @Override // android.hardware.camera2.CameraCaptureSession.StateCallback
    public final void onConfigured(CameraCaptureSession session) {
        kotlin.jvm.internal.q.g(session, "session");
        this.f238b.e(a(session, this.f239c));
        x4 x4Var = (x4) this.f.getAndSet(null);
        if (x4Var != null) {
            x4Var.a();
        }
        m7.c cVar = this.f240d;
        if (cVar != null) {
            cVar.z(this.f237a.Y);
        }
    }

    @Override // android.hardware.camera2.CameraCaptureSession.StateCallback
    public final void onReady(CameraCaptureSession session) {
        kotlin.jvm.internal.q.g(session, "session");
        a2 a2Var = this.f239c;
        a(session, a2Var);
        this.f238b.f(a(session, a2Var));
        m7.c cVar = this.f240d;
        if (cVar != null) {
            String cameraId = this.f237a.Y;
            kotlin.jvm.internal.q.g(cameraId, "cameraId");
            Iterator it = ((List) ((pj.e) cVar.Y).getValue()).iterator();
            while (it.hasNext()) {
                ((CameraCaptureSession.StateCallback) it.next()).onReady((w.k0) cVar.X);
            }
        }
    }
}
