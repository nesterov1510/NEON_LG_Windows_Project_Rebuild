package a0;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class m3 implements z.f1 {
    public final long X;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final z.g1 f216e;

    public m3(z.g1 requestMetadata, long j10) {
        kotlin.jvm.internal.q.g(requestMetadata, "requestMetadata");
        this.f216e = requestMetadata;
        this.X = j10;
    }

    @Override // z.o1
    public final Object D(kotlin.jvm.internal.h hVar) {
        return null;
    }

    @Override // z.f1
    public final boolean H() {
        return false;
    }

    @Override // z.f1
    public final int M() {
        return 0;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof m3) {
            m3 m3Var = (m3) obj;
            return kotlin.jvm.internal.q.c(this.f216e, m3Var.f216e) && this.X == m3Var.X;
        }
        return false;
    }

    public final int hashCode() {
        int iHashCode = ((this.f216e.hashCode() * 31) + 1237) * 31;
        long j10 = this.X;
        return (((int) (j10 ^ (j10 >>> 32))) + iHashCode) * 31;
    }

    public final String toString() {
        return "ExtensionRequestFailure(requestMetadata=" + this.f216e + ", wasImageCaptured=false, frameNumber=" + ((Object) z.j0.a(this.X)) + ", reason=0)";
    }
}
