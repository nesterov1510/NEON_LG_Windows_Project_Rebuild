package a0;

import android.content.Context;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraExtensionCharacteristics;
import android.hardware.camera2.CameraManager;
import android.os.Build;
import android.os.SystemClock;
import android.os.Trace;
import android.util.ArrayMap;
import android.util.Log;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import okhttp3.internal.url._UrlKt;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class b2 implements c2 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Context f12a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final c0.n f13b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final c0.i f14c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final y5.j f15d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final c0.l f16e;
    public final ArrayMap f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final ArrayMap f17g;
    public final ArrayMap h;

    public b2(Context context, c0.n threads, c0.i permissions, y5.j cameraMetadataConfig, c0.l timeSource) {
        kotlin.jvm.internal.q.g(threads, "threads");
        kotlin.jvm.internal.q.g(permissions, "permissions");
        kotlin.jvm.internal.q.g(cameraMetadataConfig, "cameraMetadataConfig");
        kotlin.jvm.internal.q.g(timeSource, "timeSource");
        this.f12a = context;
        this.f13b = threads;
        this.f14c = permissions;
        this.f15d = cameraMetadataConfig;
        this.f16e = timeSource;
        this.f = new ArrayMap();
        this.f17g = new ArrayMap();
        this.h = new ArrayMap();
    }

    public static final f1 a(b2 b2Var, String str, boolean z5, int i10) {
        String str2;
        b2Var.f16e.getClass();
        long jElapsedRealtimeNanos = SystemClock.elapsedRealtimeNanos();
        try {
            Trace.beginSection(((Object) z.p.b(str)) + "#readCameraExtensionMetadata");
            try {
                Log.d("CXCP", "Loading extension metadata for " + ((Object) z.p.b(str)));
                f1 f1Var = new f1(str, i10, b2Var.f(str));
                long jElapsedRealtimeNanos2 = SystemClock.elapsedRealtimeNanos() - jElapsedRealtimeNanos;
                if (!z5) {
                    str2 = _UrlKt.FRAGMENT_ENCODE_SET;
                } else {
                    if (!z5) {
                        throw new ad.n(11);
                    }
                    str2 = " (redacted)";
                }
                Log.i("CXCP", "Loaded extension metadata for " + ((Object) z.p.b(str)) + " in " + String.format(null, "%.3f ms", Arrays.copyOf(new Object[]{Double.valueOf(jElapsedRealtimeNanos2 / 1000000.0d)}, 1)) + str2);
                Trace.endSection();
                return f1Var;
            } catch (Throwable th2) {
                throw new IllegalStateException("Failed to load extension metadata for " + ((Object) z.p.b(str)) + '!', th2);
            }
        } catch (Throwable th3) {
            Trace.endSection();
            throw th3;
        }
    }

    /* JADX WARN: Code duplicated, block: B:45:0x0143  */
    public static final h1 b(b2 b2Var, String str, boolean z5) {
        boolean z6;
        boolean zC;
        char c10;
        Iterable iterable;
        String str2;
        y5.j jVar = b2Var.f15d;
        b2Var.f16e.getClass();
        long jElapsedRealtimeNanos = SystemClock.elapsedRealtimeNanos();
        try {
            Trace.beginSection(((Object) z.p.b(str)) + "#readCameraMetadata");
            String methodName = null;
            try {
                Log.d("CXCP", "Loading metadata for " + ((Object) z.p.b(str)));
                Object systemService = b2Var.f12a.getSystemService("camera");
                kotlin.jvm.internal.q.e(systemService, "null cannot be cast to non-null type android.hardware.camera2.CameraManager");
                CameraCharacteristics cameraCharacteristics = ((CameraManager) systemService).getCameraCharacteristics(str);
                kotlin.jvm.internal.q.f(cameraCharacteristics, "getCameraCharacteristics(...)");
                try {
                    if (Build.VERSION.SDK_INT < 32 || cameraCharacteristics.get(CameraCharacteristics.INFO_DEVICE_STATE_SENSOR_ORIENTATION_MAP) == null) {
                        c10 = 0;
                        iterable = (Set) ((Map) jVar.f22651b).get(new z.p(str));
                    } else {
                        Set set = (Set) ((Map) jVar.f22651b).get(new z.p(str));
                        if (set == null) {
                            set = ri.u.f18052e;
                        }
                        CameraCharacteristics.Key key = CameraCharacteristics.SENSOR_ORIENTATION;
                        c10 = 0;
                        LinkedHashSet linkedHashSet = new LinkedHashSet(ri.x.W(set.size() + 1));
                        linkedHashSet.addAll(set);
                        linkedHashSet.add(key);
                        iterable = linkedHashSet;
                    }
                    h1 h1Var = new h1(str, cameraCharacteristics, b2Var, iterable == null ? (Set) jVar.f22650a : m7.f.t((Set) jVar.f22650a, iterable));
                    long jElapsedRealtimeNanos2 = SystemClock.elapsedRealtimeNanos() - jElapsedRealtimeNanos;
                    if (!z5) {
                        str2 = _UrlKt.FRAGMENT_ENCODE_SET;
                    } else {
                        if (!z5) {
                            throw new ad.n(11);
                        }
                        str2 = " (redacted)";
                    }
                    StringBuilder sb2 = new StringBuilder("Loaded metadata for ");
                    sb2.append((Object) z.p.b(str));
                    sb2.append(" in ");
                    Object[] objArr = new Object[1];
                    objArr[c10] = Double.valueOf(jElapsedRealtimeNanos2 / 1000000.0d);
                    sb2.append(String.format(null, "%.3f ms", Arrays.copyOf(objArr, 1)));
                    sb2.append(str2);
                    Log.i("CXCP", sb2.toString());
                    Trace.endSection();
                    return h1Var;
                } catch (Throwable th2) {
                    th = th2;
                    if (Build.VERSION.SDK_INT != 28) {
                        z6 = false;
                    } else {
                        if (th instanceof RuntimeException) {
                            StackTraceElement[] stackTrace = th.getStackTrace();
                            kotlin.jvm.internal.q.d(stackTrace);
                            if (stackTrace.length != 0) {
                                methodName = stackTrace[0].getMethodName();
                            }
                            zC = kotlin.jvm.internal.q.c(methodName, "_enableShutterSound");
                        } else {
                            zC = false;
                        }
                        if (zC) {
                            z6 = true;
                        } else {
                            z6 = false;
                        }
                    }
                    if (z6) {
                        throw new z.h0("Failed to load metadata: Do Not Disturb mode is on!");
                    }
                    throw new IllegalStateException("Failed to load metadata for " + ((Object) z.p.b(str)) + '!', th);
                }
            } catch (Throwable th3) {
                th = th3;
            }
        } catch (Throwable th4) {
            Trace.endSection();
            throw th4;
        }
    }

    public static final boolean c(b2 b2Var) {
        boolean z5;
        c0.i iVar = b2Var.f14c;
        iVar.getClass();
        if (kotlin.jvm.internal.q.c(Build.FINGERPRINT, "robolectric")) {
            z5 = true;
        } else {
            if (!iVar.f3838b) {
                Trace.beginSection("CXCP#checkCameraPermission");
                if (iVar.f3837a.checkSelfPermission("android.permission.CAMERA") == 0) {
                    iVar.f3838b = true;
                }
                Trace.endSection();
            }
            z5 = iVar.f3838b;
        }
        return !z5;
    }

    public final z.j d(int i10, String cameraId) throws Exception {
        z.j jVarA;
        kotlin.jvm.internal.q.g(cameraId, "cameraId");
        int i11 = Build.VERSION.SDK_INT;
        if (i11 < 31) {
            throw new Exception(kotlin.jvm.internal.p.z(i11, "Extension sessions are only supported on Android S or higher. Device SDK is "));
        }
        try {
            Trace.beginSection(((Object) z.p.b(cameraId)) + "#awaitExtensionMetadata");
            synchronized (this.f17g) {
                jVarA = (z.j) this.f17g.get(cameraId);
                if (jVarA == null) {
                    if (c(this)) {
                        jVarA = a(this, cameraId, true, i10);
                    } else {
                        jVarA = a(this, cameraId, false, i10);
                        this.f17g.put(cameraId, jVarA);
                    }
                }
            }
            Trace.endSection();
            return jVarA;
        } catch (Throwable th2) {
            Trace.endSection();
            throw th2;
        }
    }

    public final z.s e(String cameraId) {
        z.s sVarB;
        kotlin.jvm.internal.q.g(cameraId, "cameraId");
        try {
            Trace.beginSection(((Object) z.p.b(cameraId)) + "#awaitMetadata");
            synchronized (this.f) {
                sVarB = (z.s) this.f.get(cameraId);
                if (sVarB == null) {
                    if (c(this)) {
                        sVarB = b(this, cameraId, true);
                    } else {
                        sVarB = b(this, cameraId, false);
                        this.f.put(cameraId, sVarB);
                    }
                }
            }
            Trace.endSection();
            return sVarB;
        } catch (Throwable th2) {
            Trace.endSection();
            throw th2;
        }
    }

    public final CameraExtensionCharacteristics f(String cameraId) throws CameraAccessException {
        synchronized (this.h) {
            CameraExtensionCharacteristics cameraExtensionCharacteristics = (CameraExtensionCharacteristics) this.h.get(cameraId);
            if (cameraExtensionCharacteristics != null) {
                return cameraExtensionCharacteristics;
            }
            Log.d("CXCP", "Retrieving CameraExtensionCharacteristics for " + ((Object) z.p.b(cameraId)));
            Object systemService = this.f12a.getSystemService("camera");
            kotlin.jvm.internal.q.e(systemService, "null cannot be cast to non-null type android.hardware.camera2.CameraManager");
            kotlin.jvm.internal.q.g(cameraId, "cameraId");
            CameraExtensionCharacteristics cameraExtensionCharacteristics2 = ((CameraManager) systemService).getCameraExtensionCharacteristics(cameraId);
            kotlin.jvm.internal.q.f(cameraExtensionCharacteristics2, "getCameraExtensionCharacteristics(...)");
            return cameraExtensionCharacteristics2;
        }
    }
}
