package a0;

import android.util.Log;
import java.util.Collections;
import java.util.List;
import okhttp3.internal.url._UrlKt;
import tm.belet.films.domain.background.PlaybackService;
import tm.belet.films.presentation.activities.PlayerActivity;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class g3 extends wi.i implements ej.p {
    public int X;
    public final /* synthetic */ long Y;
    public /* synthetic */ Object Z;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f90e = 0;

    /* JADX INFO: renamed from: r0, reason: collision with root package name */
    public final /* synthetic */ Object f91r0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public g3(long j10, i3 i3Var, ui.d dVar) {
        super(2, dVar);
        this.Y = j10;
        this.f91r0 = i3Var;
    }

    /* JADX WARN: Type inference failed for: r4v1, types: [ej.l, wi.i] */
    @Override // wi.a
    public final ui.d create(Object obj, ui.d dVar) {
        switch (this.f90e) {
            case 0:
                g3 g3Var = new g3(this.Y, (i3) this.f91r0, dVar);
                g3Var.Z = obj;
                return g3Var;
            case 1:
                return new g3((c0.n) this.Z, (wi.i) this.f91r0, this.Y, dVar);
            default:
                return new g3((PlaybackService) this.Z, this.X, (w3.k) this.f91r0, this.Y, dVar);
        }
    }

    @Override // ej.p
    public final Object invoke(Object obj, Object obj2) {
        kotlinx.coroutines.p0 p0Var = (kotlinx.coroutines.p0) obj;
        ui.d dVar = (ui.d) obj2;
        switch (this.f90e) {
            case 0:
                return ((g3) create(p0Var, dVar)).invokeSuspend(qi.b0.f17350a);
            case 1:
                return ((g3) create(p0Var, dVar)).invokeSuspend(qi.b0.f17350a);
            default:
                g3 g3Var = (g3) create(p0Var, dVar);
                qi.b0 b0Var = qi.b0.f17350a;
                g3Var.invokeSuspend(b0Var);
                return b0Var;
        }
    }

    /* JADX WARN: Type inference failed for: r5v2, types: [ej.l, wi.i] */
    @Override // wi.a
    public final Object invokeSuspend(Object obj) {
        s3.y yVar;
        int i10 = this.f90e;
        long j10 = this.Y;
        qi.b0 b0Var = qi.b0.f17350a;
        Object obj2 = this.f91r0;
        switch (i10) {
            case 0:
                vi.a aVar = vi.a.f21252e;
                int i11 = this.X;
                if (i11 == 0) {
                    g6.y.I(obj);
                    Log.d("CXCP", "Finalizing " + ((kotlinx.coroutines.p0) this.Z) + " in " + j10 + " ms");
                    this.X = 1;
                    if (kotlinx.coroutines.b1.delay(j10, this) == aVar) {
                        return aVar;
                    }
                } else {
                    if (i11 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                }
                ((i3) obj2).n(0L);
                return b0Var;
            case 1:
                vi.a aVar2 = vi.a.f21252e;
                int i12 = this.X;
                if (i12 != 0) {
                    if (i12 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                    return obj;
                }
                g6.y.I(obj);
                c0.n nVar = (c0.n) this.Z;
                c cVar = new c(kotlinx.coroutines.k.async$default(nVar.f3842b, nVar.f3844d, null, new c((wi.i) obj2, null), 2, null), null, 7);
                this.X = 1;
                Object objWithTimeoutOrNull = kotlinx.coroutines.l3.withTimeoutOrNull(j10, cVar, this);
                return objWithTimeoutOrNull == aVar2 ? aVar2 : objWithTimeoutOrNull;
            default:
                vi.a aVar3 = vi.a.f21252e;
                g6.y.I(obj);
                PlaybackService playbackService = (PlaybackService) this.Z;
                androidx.media3.session.g2 g2Var = PlaybackService.S0;
                playbackService.B();
                int i13 = this.X;
                playbackService.f19319z0 = i13;
                playbackService.A0 = 0;
                playbackService.B0 = _UrlKt.FRAGMENT_ENCODE_SET;
                playbackService.C0 = System.currentTimeMillis();
                playbackService.D0 = true;
                playbackService.E0 = i13;
                playbackService.F0 = 0;
                androidx.media3.session.g2 g2Var2 = PlaybackService.S0;
                if (g2Var2 != null && playbackService.f19316w0 != null && !kotlin.jvm.internal.q.c(g2Var2.a(), playbackService.f19316w0)) {
                    fm.b bVar = playbackService.f19316w0;
                    kotlin.jvm.internal.q.d(bVar);
                    g2Var2.b(bVar);
                }
                try {
                    PlayerActivity playerActivity = oo.k.f;
                    if (playerActivity != null && (yVar = playerActivity.f19379b1) != null) {
                        yVar.e0(false);
                    }
                    break;
                } catch (Exception e3) {
                    Log.w("PlaybackService", "Error pausing activity player: " + e3.getMessage());
                }
                s3.y yVar2 = playbackService.f19315v0;
                if (yVar2 != null) {
                    yVar2.h2();
                    List listSingletonList = Collections.singletonList((w3.k) obj2);
                    yVar2.h2();
                    long j11 = this.Y;
                    yVar2.Z1(listSingletonList, 0, j11, false);
                    yVar2.o(0, j11);
                    yVar2.b();
                    yVar2.e0(true);
                }
                return b0Var;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    public g3(c0.n nVar, ej.l lVar, long j10, ui.d dVar) {
        super(2, dVar);
        this.Z = nVar;
        this.f91r0 = (wi.i) lVar;
        this.Y = j10;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public g3(PlaybackService playbackService, int i10, w3.k kVar, long j10, ui.d dVar) {
        super(2, dVar);
        this.Z = playbackService;
        this.X = i10;
        this.f91r0 = kVar;
        this.Y = j10;
    }
}
