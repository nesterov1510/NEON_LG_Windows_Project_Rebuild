package a0;

import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraExtensionSession;
import android.hardware.camera2.CaptureRequest;
import android.os.Build;
import android.util.ArrayMap;
import java.util.Map;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class e2 implements z.g1 {
    public final CaptureRequest X;
    public final Map Y;
    public final Map Z;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final g2 f76e;

    /* JADX INFO: renamed from: r0, reason: collision with root package name */
    public final Map f77r0;

    /* JADX INFO: renamed from: s0, reason: collision with root package name */
    public final ArrayMap f78s0;

    /* JADX INFO: renamed from: t0, reason: collision with root package name */
    public final boolean f79t0;
    public final z.e1 u0;

    /* JADX INFO: renamed from: v0, reason: collision with root package name */
    public final long f80v0;

    public e2(g2 cameraCaptureSessionWrapper, CaptureRequest captureRequest, Map defaultParameters, Map graphParameters, Map requiredParameters, ArrayMap arrayMap, boolean z5, z.e1 e1Var, long j10) {
        kotlin.jvm.internal.q.g(cameraCaptureSessionWrapper, "cameraCaptureSessionWrapper");
        kotlin.jvm.internal.q.g(captureRequest, "captureRequest");
        kotlin.jvm.internal.q.g(defaultParameters, "defaultParameters");
        kotlin.jvm.internal.q.g(graphParameters, "graphParameters");
        kotlin.jvm.internal.q.g(requiredParameters, "requiredParameters");
        this.f76e = cameraCaptureSessionWrapper;
        this.X = captureRequest;
        this.Y = defaultParameters;
        this.Z = graphParameters;
        this.f77r0 = requiredParameters;
        this.f78s0 = arrayMap;
        this.f79t0 = z5;
        this.u0 = e1Var;
        this.f80v0 = j10;
    }

    @Override // z.o1
    public final Object D(kotlin.jvm.internal.h hVar) {
        if (hVar.equals(kotlin.jvm.internal.e0.a(CaptureRequest.class))) {
            CaptureRequest captureRequest = this.X;
            kotlin.jvm.internal.q.e(captureRequest, "null cannot be cast to non-null type T of androidx.camera.camera2.pipe.compat.Camera2RequestMetadata.unwrapAs");
            return captureRequest;
        }
        boolean zEquals = hVar.equals(kotlin.jvm.internal.e0.a(CameraCaptureSession.class));
        g2 g2Var = this.f76e;
        if (zEquals) {
            Object objD = g2Var.D(kotlin.jvm.internal.e0.a(CameraCaptureSession.class));
            if (objD == null) {
                return null;
            }
            return objD;
        }
        if (!hVar.equals(kotlin.jvm.internal.e0.a(CameraExtensionSession.class))) {
            return null;
        }
        if (Build.VERSION.SDK_INT < 31) {
            throw new IllegalStateException("Check failed.");
        }
        Object objD2 = g2Var.D(kotlin.jvm.internal.e0.a(CameraExtensionSession.class));
        if (objD2 == null) {
            return null;
        }
        return objD2;
    }

    @Override // z.g1
    public final Map P() {
        return this.f78s0;
    }

    @Override // z.g1
    public final boolean U() {
        return this.f79t0;
    }

    @Override // z.r0
    public final Object a(z.q0 key) {
        kotlin.jvm.internal.q.g(key, "key");
        Map map = this.f77r0;
        if (map.containsKey(key)) {
            return map.get(key);
        }
        z.e1 e1Var = this.u0;
        if (e1Var.f23333c.containsKey(key)) {
            return e1Var.f23333c.get(key);
        }
        Map map2 = this.Z;
        return map2.containsKey(key) ? map2.get(key) : this.Y.get(key);
    }

    @Override // z.r0
    public final Object b(z.q0 key, m0.m2 m2Var) {
        kotlin.jvm.internal.q.g(key, "key");
        Object objA = a(key);
        return objA == null ? m2Var : objA;
    }

    @Override // z.g1
    public final long h0() {
        return this.f80v0;
    }

    @Override // z.g1
    public final z.e1 m() {
        return this.u0;
    }
}
