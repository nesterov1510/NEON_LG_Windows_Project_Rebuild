package a0;

import android.hardware.camera2.CameraManager;
import java.util.concurrent.CancellationException;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class l1 implements AutoCloseable {
    public final String X;
    public final CameraManager Y;
    public final kotlinx.coroutines.p0 Z;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final c0.n f169e;

    /* JADX INFO: renamed from: r0, reason: collision with root package name */
    public final pj.a f170r0;

    /* JADX INFO: renamed from: s0, reason: collision with root package name */
    public final kotlinx.coroutines.flow.h0 f171s0;

    /* JADX INFO: renamed from: t0, reason: collision with root package name */
    public final kotlinx.coroutines.flow.x0 f172t0;
    public final kotlinx.coroutines.flow.g0 u0;

    /* JADX INFO: renamed from: v0, reason: collision with root package name */
    public final kotlinx.coroutines.flow.l0 f173v0;

    /* JADX INFO: renamed from: w0, reason: collision with root package name */
    public final kotlinx.coroutines.flow.i f174w0;

    /* JADX INFO: renamed from: x0, reason: collision with root package name */
    public final kotlinx.coroutines.f2 f175x0;

    public l1(pi.a cameraManager, c0.n nVar, String cameraId, kotlinx.coroutines.f2 f2Var) {
        kotlin.jvm.internal.q.g(cameraManager, "cameraManager");
        kotlin.jvm.internal.q.g(cameraId, "cameraId");
        this.f169e = nVar;
        this.X = cameraId;
        this.Y = (CameraManager) cameraManager.get();
        kotlinx.coroutines.p0 p0VarCoroutineScope = kotlinx.coroutines.q0.CoroutineScope(kotlinx.coroutines.d3.SupervisorJob(f2Var).plus(nVar.f.plus(new kotlinx.coroutines.o0("CXCP-CameraStatusMonitor"))));
        this.Z = p0VarCoroutineScope;
        this.f170r0 = pj.b.atomic(false);
        kotlinx.coroutines.flow.h0 h0VarMutableStateFlow = kotlinx.coroutines.flow.z0.MutableStateFlow(e0.k.f7269a);
        this.f171s0 = h0VarMutableStateFlow;
        this.f172t0 = kotlinx.coroutines.flow.k.asStateFlow(h0VarMutableStateFlow);
        ui.d dVar = null;
        kotlinx.coroutines.flow.g0 g0VarMutableSharedFlow$default = kotlinx.coroutines.flow.o0.MutableSharedFlow$default(0, 0, null, 7, null);
        this.u0 = g0VarMutableSharedFlow$default;
        this.f173v0 = kotlinx.coroutines.flow.k.asSharedFlow(g0VarMutableSharedFlow$default);
        this.f174w0 = kotlinx.coroutines.flow.k.callbackFlow(new t0(this, dVar, 1));
        this.f175x0 = kotlinx.coroutines.k.launch$default(p0VarCoroutineScope, null, null, new c(this, dVar, 1), 3, null);
    }

    @Override // java.lang.AutoCloseable
    public final void close() {
        if (this.f170r0.compareAndSet(false, true)) {
            kotlinx.coroutines.d2.cancel$default(this.f175x0, (CancellationException) null, 1, (Object) null);
            kotlinx.coroutines.q0.cancel$default(this.Z, null, 1, null);
        }
    }
}
