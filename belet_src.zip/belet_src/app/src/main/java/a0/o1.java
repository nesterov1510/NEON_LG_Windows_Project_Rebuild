package a0;

import android.hardware.camera2.CaptureRequest;
import android.os.Trace;
import android.util.ArrayMap;
import android.util.Log;
import android.view.Surface;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class o1 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final g2 f245a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final c0.n f246b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f247c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Map f248d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final Map f249e;
    public final z.l1 f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final z.n1 f250g;
    public final boolean h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final int f251i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final Object f252j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public boolean f253k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public m1 f254l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final f0.b f255m;

    /* JADX WARN: Type inference failed for: r5v4, types: [java.lang.Object, java.util.Collection, java.util.List] */
    public o1(g2 session, c0.n threads, int i10, Map streamToSurfaceMap, Map outputToSurfaceMap, z.l1 l1Var, z.n1 strictMode, boolean z5) {
        kotlin.jvm.internal.q.g(session, "session");
        kotlin.jvm.internal.q.g(threads, "threads");
        kotlin.jvm.internal.q.g(streamToSurfaceMap, "streamToSurfaceMap");
        kotlin.jvm.internal.q.g(outputToSurfaceMap, "outputToSurfaceMap");
        kotlin.jvm.internal.q.g(strictMode, "strictMode");
        this.f245a = session;
        this.f246b = threads;
        this.f247c = i10;
        this.f248d = streamToSurfaceMap;
        this.f249e = outputToSurfaceMap;
        this.f = l1Var;
        this.f250g = strictMode;
        this.h = z5;
        this.f251i = p1.f263a.incrementAndGet();
        this.f252j = new Object();
        ?? r9 = ((d0.f0) l1Var).f6540s0;
        f0.b bVarG = null;
        if (!r9.isEmpty()) {
            d0.b0 b0Var = (d0.b0) ri.m.e0(r9);
            Surface inputSurface = session.getInputSurface();
            if (inputSurface == null) {
                throw new IllegalStateException("inputSurface is required to create instance of imageWriter.");
            }
            try {
                bVarG = c0.h.g(inputSurface, b0Var.f6497a, new z.k1(b0Var.f6498b), threads.a());
            } catch (RuntimeException e3) {
                Log.e("CXCP", "Failed to create ImageWriter for session " + this.f245a + "! Reprocessing will not be supported!", e3);
            }
            if (bVarG != null) {
                Log.d("CXCP", "Created ImageWriter " + bVarG + " for session " + this.f245a);
            }
        }
        this.f255m = bVarG;
    }

    public static final void b(o1 o1Var, m1 m1Var) {
        Log.d("CXCP", "Waiting for the last repeating request sequence: " + m1Var);
        if (((qi.b0) o1Var.f246b.b(2000L, new n1(m1Var, null, 0))) == null) {
            Log.e("CXCP", o1Var + "#close: awaitStarted on last repeating request timed out, lastSingleRepeatingRequestSequence = " + m1Var);
        }
    }

    public final void a() {
        synchronized (this.f252j) {
            Log.d("CXCP", this + "#abortCaptures");
            this.f245a.S();
        }
    }

    /* JADX WARN: Code duplicated, block: B:220:0x04da A[LOOP:8: B:203:0x0496->B:220:0x04da, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:276:0x04d7 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:285:0x010a A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:37:0x00f4  */
    /* JADX WARN: Code duplicated, block: B:43:0x010d A[LOOP:12: B:15:0x0086->B:43:0x010d, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:82:0x01c1  */
    public final m1 c(boolean z5, List list, Map defaultParameters, Map graphParameters, Map map, z7.b sequenceListener, List listeners) {
        ArrayList arrayList;
        boolean z6;
        char c10;
        boolean z9;
        long j10;
        boolean z10;
        Iterator it;
        boolean z11;
        boolean z12;
        boolean zA;
        z.l1 l1Var;
        Iterator it2;
        boolean z13;
        boolean z14;
        boolean z15;
        boolean z16;
        boolean z17;
        boolean z18;
        boolean z19;
        Map requiredParameters = map;
        kotlin.jvm.internal.q.g(defaultParameters, "defaultParameters");
        kotlin.jvm.internal.q.g(graphParameters, "graphParameters");
        kotlin.jvm.internal.q.g(requiredParameters, "requiredParameters");
        kotlin.jvm.internal.q.g(sequenceListener, "sequenceListener");
        kotlin.jvm.internal.q.g(listeners, "listeners");
        ArrayList arrayList2 = new ArrayList(list.size());
        ArrayList arrayList3 = new ArrayList(list.size());
        ArrayMap arrayMap = new ArrayMap();
        ArrayMap arrayMap2 = new ArrayMap();
        ArrayMap arrayMap3 = new ArrayMap();
        if (list.isEmpty()) {
            throw new IllegalStateException("build(...) should never be called with an empty request list!");
        }
        if (!(this.f245a instanceof h)) {
            arrayList = arrayList3;
            arrayList2 = arrayList2;
            z6 = true;
            break;
        }
        Iterator it3 = list.iterator();
        Boolean bool = null;
        Boolean bool2 = null;
        while (true) {
            if (!it3.hasNext()) {
                arrayList = arrayList3;
                arrayList2 = arrayList2;
                z6 = true;
                break;
            }
            z.e1 e1Var = (z.e1) it3.next();
            List list2 = e1Var.f23331a;
            Iterator it4 = it3;
            z.l1 l1Var2 = this.f;
            if (list2 != null && list2.isEmpty()) {
                l1Var = l1Var2;
                arrayList = arrayList3;
                arrayList2 = arrayList2;
                z15 = false;
                break;
            }
            Iterator it5 = list2.iterator();
            while (true) {
                if (!it5.hasNext()) {
                    l1Var = l1Var2;
                    arrayList = arrayList3;
                    arrayList2 = arrayList2;
                    z15 = false;
                    break;
                }
                ((z.m1) it5.next()).getClass();
                l1Var = l1Var2;
                ArrayList arrayList4 = ((d0.f0) l1Var).u0;
                if (arrayList4 == null || !arrayList4.isEmpty()) {
                    arrayList = arrayList3;
                    int size = arrayList4.size();
                    it2 = it5;
                    int i10 = 0;
                    while (true) {
                        if (i10 < size) {
                            Object obj = arrayList4.get(i10);
                            int i11 = i10 + 1;
                            ArrayList arrayList5 = arrayList4;
                            d0.d0 d0Var = (d0.d0) obj;
                            int i12 = size;
                            z.b1 b1Var = d0Var.f6518g;
                            z.c1 c1Var = d0Var.f6519i;
                            if (b1Var == null ? false : z.b1.a(b1Var.f23321a, 1L)) {
                                z13 = true;
                            } else if ((c1Var == null ? false : z.c1.a(c1Var.f23323a, 0L)) || c1Var == null) {
                                z13 = true;
                            } else {
                                z13 = false;
                            }
                            if (z13) {
                                z14 = true;
                                break;
                            }
                            size = i12;
                            arrayList4 = arrayList5;
                            i10 = i11;
                            arrayList2 = arrayList2;
                        }
                    }
                    if (z14) {
                        z15 = true;
                        break;
                    }
                    l1Var2 = l1Var;
                    arrayList3 = arrayList;
                    it5 = it2;
                    arrayList2 = arrayList2;
                } else {
                    arrayList = arrayList3;
                    it2 = it5;
                }
                arrayList2 = arrayList2;
                z14 = false;
                if (z14) {
                    z15 = true;
                    break;
                }
                l1Var2 = l1Var;
                arrayList3 = arrayList;
                it5 = it2;
                arrayList2 = arrayList2;
            }
            Boolean boolValueOf = Boolean.valueOf(z15);
            if (bool2 != null && !bool2.equals(boolValueOf)) {
                Log.e("CXCP", "The previous high speed request and the current high speed request must both have a preview stream use case or hint. Previous request contains preview stream use case or hint: " + bool2.booleanValue() + ". Current request contains preview stream use case or hint: " + z15 + '.');
            }
            List list3 = e1Var.f23331a;
            if (!(list3 != null) || !list3.isEmpty()) {
                Iterator it6 = list3.iterator();
                while (true) {
                    if (!it6.hasNext()) {
                        z18 = false;
                        break;
                    }
                    ((z.m1) it6.next()).getClass();
                    ArrayList arrayList6 = ((d0.f0) l1Var).u0;
                    if ((arrayList6 != null) && arrayList6.isEmpty()) {
                        z17 = false;
                        break;
                    }
                    int size2 = arrayList6.size();
                    int i13 = 0;
                    while (true) {
                        if (i13 >= size2) {
                            z17 = false;
                            break;
                        }
                        Object obj2 = arrayList6.get(i13);
                        i13++;
                        d0.d0 d0Var2 = (d0.d0) obj2;
                        z.b1 b1Var2 = d0Var2.f6518g;
                        if (b1Var2 == null ? false : z.b1.a(b1Var2.f23321a, 3L)) {
                            z16 = true;
                        } else {
                            z.c1 c1Var2 = d0Var2.f6519i;
                            if (c1Var2 == null ? false : z.c1.a(c1Var2.f23323a, 1L)) {
                                z16 = true;
                            } else {
                                z16 = false;
                            }
                        }
                        if (z16) {
                            z17 = true;
                            break;
                        }
                        arrayList6 = arrayList6;
                        size2 = size2;
                    }
                    if (z17) {
                        z18 = true;
                        break;
                    }
                }
            } else {
                z18 = false;
                break;
            }
            Boolean boolValueOf2 = Boolean.valueOf(z18);
            if (bool != null && !bool.equals(boolValueOf2)) {
                Log.e("CXCP", "The previous high speed request and the current high speed request do not have the same video stream use case. Previous request contains video stream use case: " + bool.booleanValue() + ". Current request contains video stream use case: " + z18 + '.');
            }
            d0.f0 f0Var = (d0.f0) l1Var;
            ArrayList arrayList7 = f0Var.u0;
            if (!(arrayList7 != null) || !arrayList7.isEmpty()) {
                int size3 = arrayList7.size();
                int i14 = 0;
                while (true) {
                    if (i14 >= size3) {
                        z19 = true;
                        break;
                    }
                    Object obj3 = arrayList7.get(i14);
                    i14++;
                    if (!((d0.d0) obj3).a()) {
                        z19 = false;
                        break;
                    }
                }
            } else {
                z19 = true;
                break;
            }
            if (!z19) {
                Log.e("CXCP", "HIGH_SPEED CameraGraph must only contain Preview and/or Video streams. Configured outputs are " + f0Var.u0);
                z6 = false;
                break;
            }
            bool2 = boolValueOf;
            bool = boolValueOf2;
            it3 = it4;
            arrayList3 = arrayList;
            arrayList2 = arrayList2;
        }
        if (z6) {
            if (list.isEmpty()) {
                throw new IllegalStateException("build(...) should never be called with an empty request list!");
            }
            Iterator it7 = list.iterator();
            while (true) {
                c10 = '!';
                if (!it7.hasNext()) {
                    z9 = true;
                    break;
                }
                z.e1 e1Var2 = (z.e1) it7.next();
                Iterator it8 = e1Var2.f23331a.iterator();
                boolean z20 = false;
                while (it8.hasNext()) {
                    int i15 = ((z.m1) it8.next()).f23375a;
                    if (!arrayMap3.containsKey(new z.m1(i15))) {
                        Surface surface = (Surface) this.f248d.get(new z.m1(i15));
                        if (surface != null) {
                            arrayMap.put(surface, new z.m1(i15));
                            arrayMap3.put(new z.m1(i15), surface);
                            z.b0 b0VarA = ((d0.f0) this.f).a(i15);
                            if (b0VarA == null) {
                                throw new IllegalStateException("Required value was null.");
                            }
                            ArrayList arrayList8 = b0VarA.f23320b;
                            int size4 = arrayList8.size();
                            int i16 = 0;
                            while (i16 < size4) {
                                Object obj4 = arrayList8.get(i16);
                                i16++;
                                d0.d0 d0Var3 = (d0.d0) obj4;
                                Object obj5 = this.f249e.get(new z.t0(d0Var3.f6513a));
                                if (obj5 == null) {
                                    throw new IllegalStateException("Required value was null.");
                                }
                                arrayMap2.put((Surface) obj5, new z.t0(d0Var3.f6513a));
                            }
                        } else {
                            continue;
                        }
                    }
                    z20 = true;
                }
                if (!z20) {
                    Log.i("CXCP", "  Failed to bind any surfaces for " + e1Var2 + '!');
                    z9 = false;
                    break;
                }
                if (!z20) {
                    throw new IllegalStateException("Check failed.");
                }
            }
            if (z9) {
                Iterator it9 = list.iterator();
                while (it9.hasNext()) {
                    z.e1 e1Var3 = (z.e1) it9.next();
                    Log.d("CXCP", "Building CaptureRequest for " + e1Var3);
                    z.i1 i1Var = e1Var3.f23335e;
                    int i17 = i1Var != null ? i1Var.f23346a : this.f247c;
                    CaptureRequest.Builder builderT = this.f245a.V().T(i17);
                    if (builderT == null) {
                        Log.i("CXCP", "Failed to create a CaptureRequest.Builder from " + ((Object) z.i1.b(i17)) + c10);
                        builderT = null;
                    }
                    if (builderT == null) {
                        return null;
                    }
                    z.q0 q0Var = j2.f146b;
                    Object obj6 = requiredParameters.get(q0Var);
                    if (obj6 == null) {
                        obj6 = defaultParameters.get(q0Var);
                    }
                    builderT.setTag(obj6);
                    int size5 = e1Var3.f23331a.size();
                    boolean z21 = false;
                    for (int i18 = 0; i18 < size5; i18++) {
                        Surface surface2 = (Surface) arrayMap3.get(e1Var3.f23331a.get(i18));
                        if (surface2 != null) {
                            builderT.addTarget(surface2);
                            z21 = true;
                        }
                    }
                    if (!z21) {
                        throw new IllegalStateException("Check failed.");
                    }
                    com.bumptech.glide.d.O(builderT, defaultParameters);
                    com.bumptech.glide.d.O(builderT, graphParameters);
                    com.bumptech.glide.d.O(builderT, e1Var3.f23332b);
                    com.bumptech.glide.d.O(builderT, requiredParameters);
                    long jIncrementAndGet = p1.f265c.incrementAndGet();
                    CaptureRequest captureRequestBuild = builderT.build();
                    kotlin.jvm.internal.q.f(captureRequestBuild, "build(...)");
                    ArrayMap arrayMap4 = arrayMap;
                    g2 g2Var = this.f245a;
                    if (g2Var instanceof h) {
                        h hVar = (h) g2Var;
                        h2 h2Var = hVar.f88e;
                        try {
                            Trace.beginSection("CXCP#createHighSpeedRequestList");
                            List<CaptureRequest> listCreateHighSpeedRequestList = hVar.f95r0.createHighSpeedRequestList(captureRequestBuild);
                            try {
                                Trace.endSection();
                            } catch (IllegalArgumentException unused) {
                                Log.w("CXCP", "Failed to createHighSpeedRequestList from " + h2Var + " because the output surface was destroyed before calling createHighSpeedRequestList.");
                                listCreateHighSpeedRequestList = null;
                            } catch (IllegalStateException unused2) {
                                Log.w("CXCP", "Failed to createHighSpeedRequestList. " + h2Var + " may be closed.");
                                listCreateHighSpeedRequestList = null;
                            } catch (UnsupportedOperationException unused3) {
                                Log.w("CXCP", "Failed to createHighSpeedRequestList from " + h2Var + " because the output surface was not available.");
                                listCreateHighSpeedRequestList = null;
                            }
                            if (listCreateHighSpeedRequestList == null) {
                                return null;
                            }
                            List list4 = e1Var3.f23331a;
                            if ((list4 != null) && list4.isEmpty()) {
                                arrayMap2 = arrayMap2;
                                z10 = false;
                                j10 = 1;
                            } else {
                                Iterator it10 = list4.iterator();
                                while (true) {
                                    if (!it10.hasNext()) {
                                        arrayMap2 = arrayMap2;
                                        j10 = 1;
                                        z10 = false;
                                        break;
                                    }
                                    ((z.m1) it10.next()).getClass();
                                    ArrayList arrayList9 = ((d0.f0) this.f).u0;
                                    if ((arrayList9 != null) && arrayList9.isEmpty()) {
                                        it = it10;
                                        arrayMap2 = arrayMap2;
                                        z11 = false;
                                        j10 = 1;
                                    } else {
                                        int size6 = arrayList9.size();
                                        int i19 = 0;
                                        while (true) {
                                            if (i19 >= size6) {
                                                it = it10;
                                                arrayMap2 = arrayMap2;
                                                j10 = 1;
                                                z11 = false;
                                                break;
                                            }
                                            Object obj7 = arrayList9.get(i19);
                                            i19++;
                                            it = it10;
                                            d0.d0 d0Var4 = (d0.d0) obj7;
                                            ArrayList arrayList10 = arrayList9;
                                            z.b1 b1Var3 = d0Var4.f6518g;
                                            if (b1Var3 == null ? false : z.b1.a(b1Var3.f23321a, 3L)) {
                                                j10 = 1;
                                            } else {
                                                z.c1 c1Var3 = d0Var4.f6519i;
                                                if (c1Var3 == null) {
                                                    zA = false;
                                                    j10 = 1;
                                                } else {
                                                    j10 = 1;
                                                    zA = z.c1.a(c1Var3.f23323a, 1L);
                                                }
                                                if (!zA) {
                                                    z12 = false;
                                                }
                                                if (z12) {
                                                    z11 = true;
                                                    break;
                                                }
                                                it10 = it;
                                                arrayList9 = arrayList10;
                                                arrayMap2 = arrayMap2;
                                            }
                                            z12 = true;
                                            if (z12) {
                                                z11 = true;
                                                break;
                                            }
                                            it10 = it;
                                            arrayList9 = arrayList10;
                                            arrayMap2 = arrayMap2;
                                        }
                                    }
                                    if (z11) {
                                        z10 = true;
                                        break;
                                    }
                                    it10 = it;
                                    arrayMap2 = arrayMap2;
                                }
                            }
                            if (z10) {
                                ArrayList arrayList11 = arrayList;
                                ArrayList arrayList12 = arrayList2;
                                int size7 = listCreateHighSpeedRequestList.size();
                                int i20 = 0;
                                while (i20 < size7) {
                                    int i21 = size7;
                                    ArrayList arrayList13 = arrayList12;
                                    Iterator it11 = it9;
                                    int i22 = i20;
                                    e2 e2Var = new e2(this.f245a, listCreateHighSpeedRequestList.get(i20), defaultParameters, graphParameters, map, arrayMap3, z5, e1Var3, jIncrementAndGet);
                                    arrayList11.add(listCreateHighSpeedRequestList.get(i22));
                                    arrayList13.add(e2Var);
                                    i20 = i22 + 1;
                                    it9 = it11;
                                    arrayList12 = arrayList13;
                                    size7 = i21;
                                }
                                requiredParameters = map;
                                arrayList2 = arrayList12;
                                arrayList = arrayList11;
                            } else {
                                e2 e2Var2 = new e2(this.f245a, listCreateHighSpeedRequestList.get(0), defaultParameters, graphParameters, requiredParameters, arrayMap3, z5, e1Var3, jIncrementAndGet);
                                arrayList.add(listCreateHighSpeedRequestList.get(0));
                                arrayList2.add(e2Var2);
                                requiredParameters = map;
                            }
                        } catch (Throwable th2) {
                            Trace.endSection();
                            throw th2;
                        }
                    } else {
                        arrayMap2 = arrayMap2;
                        requiredParameters = map;
                        e2 e2Var3 = new e2(g2Var, captureRequestBuild, defaultParameters, graphParameters, requiredParameters, arrayMap3, z5, e1Var3, jIncrementAndGet);
                        arrayList.add(captureRequestBuild);
                        arrayList2.add(e2Var3);
                    }
                    arrayMap = arrayMap4;
                    arrayMap2 = arrayMap2;
                    c10 = '!';
                }
                return new m1(this.f245a.V().y(), z5, arrayList, arrayList2, listeners, sequenceListener, arrayMap, arrayMap2, this.f, this.f250g);
            }
        }
        return null;
    }

    public final void d() {
        m1 m1Var;
        try {
            Trace.beginSection(this + "#disconnect");
            synchronized (this.f252j) {
                try {
                    if (this.f253k) {
                        m1Var = null;
                    } else {
                        this.f253k = true;
                        f0.b bVar = this.f255m;
                        if (bVar != null) {
                            f.w(bVar);
                        }
                        Surface inputSurface = this.f245a.getInputSurface();
                        if (inputSurface != null) {
                            inputSurface.release();
                        }
                        m1Var = this.f254l;
                    }
                } catch (Throwable th2) {
                    throw th2;
                }
            }
            if (this.h && m1Var != null) {
                b(this, m1Var);
            }
            Trace.endSection();
        } catch (Throwable th3) {
            Trace.endSection();
            throw th3;
        }
    }

    /* JADX WARN: Code duplicated, block: B:23:0x005e A[Catch: all -> 0x0028, TryCatch #0 {, blocks: (B:4:0x0003, B:6:0x0007, B:12:0x002a, B:14:0x0033, B:16:0x0039, B:18:0x003e, B:20:0x0042, B:21:0x0044, B:22:0x0051, B:23:0x005e, B:25:0x0062, B:26:0x006b), top: B:31:0x0003 }] */
    /* JADX WARN: Code duplicated, block: B:25:0x0062 A[Catch: all -> 0x0028, TryCatch #0 {, blocks: (B:4:0x0003, B:6:0x0007, B:12:0x002a, B:14:0x0033, B:16:0x0039, B:18:0x003e, B:20:0x0042, B:21:0x0044, B:22:0x0051, B:23:0x005e, B:25:0x0062, B:26:0x006b), top: B:31:0x0003 }] */
    /* JADX WARN: Code duplicated, block: B:26:0x006b A[Catch: all -> 0x0028, TRY_LEAVE, TryCatch #0 {, blocks: (B:4:0x0003, B:6:0x0007, B:12:0x002a, B:14:0x0033, B:16:0x0039, B:18:0x003e, B:20:0x0042, B:21:0x0044, B:22:0x0051, B:23:0x005e, B:25:0x0062, B:26:0x006b), top: B:31:0x0003 }] */
    public final Integer e(m1 m1Var) {
        Integer numQ;
        synchronized (this.f252j) {
            if (this.f253k) {
                Log.w("CXCP", this + " disconnected. " + m1Var + " won't be submitted");
                return null;
            }
            if (m1Var.f200c.size() == 1) {
                g2 g2Var = this.f245a;
                if (g2Var instanceof h) {
                    if (m1Var.f199b) {
                        numQ = this.f245a.O(m1Var.f200c, m1Var);
                    } else {
                        numQ = this.f245a.Q(m1Var.f200c, m1Var);
                    }
                } else if (m1Var.f199b) {
                    if (this.h) {
                        this.f254l = m1Var;
                    }
                    numQ = g2Var.w((CaptureRequest) m1Var.f200c.get(0), m1Var);
                } else {
                    numQ = g2Var.Y((CaptureRequest) m1Var.f200c.get(0), m1Var);
                }
            } else if (m1Var.f199b) {
                numQ = this.f245a.O(m1Var.f200c, m1Var);
            } else {
                numQ = this.f245a.Q(m1Var.f200c, m1Var);
            }
            return numQ;
        }
    }

    public final String toString() {
        return "Camera2CaptureSequenceProcessor-" + this.f251i;
    }
}
