package a0;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class h3 extends wi.c {
    public kotlin.jvm.internal.d0 X;
    public /* synthetic */ Object Y;
    public final /* synthetic */ i3 Z;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public kotlin.jvm.internal.d0 f101e;

    /* JADX INFO: renamed from: r0, reason: collision with root package name */
    public int f102r0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public h3(i3 i3Var, wi.c cVar) {
        super(cVar);
        this.Z = i3Var;
    }

    @Override // wi.a
    public final Object invokeSuspend(Object obj) {
        this.Y = obj;
        this.f102r0 |= Integer.MIN_VALUE;
        return i3.i(this.Z, this);
    }
}
