package a0;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class p3 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f270a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f271b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f272c;

    public p3(int i10, int i11, int i12) {
        this.f270a = i10;
        this.f271b = i11;
        this.f272c = i12;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof p3)) {
            return false;
        }
        p3 p3Var = (p3) obj;
        return this.f270a == p3Var.f270a && this.f271b == p3Var.f271b && this.f272c == p3Var.f272c;
    }

    public final int hashCode() {
        return (((this.f270a * 31) + this.f271b) * 31) + this.f272c;
    }

    public final String toString() {
        StringBuilder sb2 = new StringBuilder("InputConfigData(width=");
        sb2.append(this.f270a);
        sb2.append(", height=");
        sb2.append(this.f271b);
        sb2.append(", format=");
        return f.p(sb2, this.f272c, ')');
    }
}
