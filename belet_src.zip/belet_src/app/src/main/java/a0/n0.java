package a0;

import android.os.Build;
import java.util.LinkedHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class n0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final kotlinx.coroutines.p0 f220a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final z7.c f221b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Object f222c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final LinkedHashMap f223d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final CopyOnWriteArrayList f224e;

    public n0(c0.n threads, e0.g cameraPipeLifetime, kotlinx.coroutines.f2 cameraPipeJob) {
        kotlin.jvm.internal.q.g(threads, "threads");
        kotlin.jvm.internal.q.g(cameraPipeLifetime, "cameraPipeLifetime");
        kotlin.jvm.internal.q.g(cameraPipeJob, "cameraPipeJob");
        this.f220a = kotlinx.coroutines.q0.CoroutineScope(kotlinx.coroutines.d3.SupervisorJob(cameraPipeJob).plus(threads.f.plus(new kotlinx.coroutines.o0("CXCP-AudioRestrictionControllerImpl"))));
        this.f221b = new z7.c(10);
        this.f222c = new Object();
        this.f223d = new LinkedHashMap();
        this.f224e = new CopyOnWriteArrayList();
        cameraPipeLifetime.c(e0.e.X, new l0(0, this));
    }

    public final void a(i iVar) {
        if (Build.VERSION.SDK_INT < 30) {
            return;
        }
        synchronized (this.f222c) {
            this.f224e.add(iVar);
            z.c cVarB = b();
            if (cVarB != null) {
                c0.h.K(this.f221b, this.f220a, new m0(iVar, cVarB, null, 0));
            }
        }
    }

    public final z.c b() {
        LinkedHashMap linkedHashMap = this.f223d;
        if (linkedHashMap.containsValue(new z.c(3))) {
            return new z.c(3);
        }
        synchronized (this.f222c) {
        }
        if (linkedHashMap.containsValue(new z.c(1))) {
            return new z.c(1);
        }
        c();
        if (linkedHashMap.containsValue(new z.c(0))) {
            return new z.c(0);
        }
        c();
        return null;
    }

    public final void c() {
        synchronized (this.f222c) {
        }
    }

    public final void d(d0.b bVar) {
        synchronized (this.f222c) {
            z.c cVarB = b();
            this.f223d.remove(bVar);
            z.c cVarB2 = b();
            if (cVarB2 != null && !cVarB2.equals(cVarB)) {
                c0.h.K(this.f221b, this.f220a, new m0(this, cVarB2, null, 1));
            }
        }
    }
}
