package a0;

import java.util.HashMap;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public abstract class j2 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final z.q0 f145a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final z.q0 f146b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final z.q0 f147c;

    static {
        HashMap map = z.q0.f23385c;
        f145a = com.bumptech.glide.c.k("androidx.camera.camera2.pipe.extensionMode", kotlin.jvm.internal.e0.a(Integer.class));
        f146b = com.bumptech.glide.c.k("androidx.camera.camera2.pipe.captureRequestTag", kotlin.jvm.internal.e0.a(Object.class));
        f147c = com.bumptech.glide.c.k("androidx.camera.camera2.pipe.ignore3ARequiredParameters", kotlin.jvm.internal.e0.a(Boolean.class));
    }
}
