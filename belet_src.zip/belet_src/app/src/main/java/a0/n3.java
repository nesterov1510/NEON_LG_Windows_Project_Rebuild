package a0;

import java.util.ArrayList;
import java.util.Map;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class n3 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ArrayList f227a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final c0.e f228b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final f2 f229c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f230d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final Map f231e;
    public final Integer f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final o3 f232g;
    public final r3 h;

    public n3(ArrayList arrayList, c0.e eVar, i3 stateCallback, int i10, Map sessionParameters, Integer num, o3 o3Var, r3 r3Var) {
        kotlin.jvm.internal.q.g(stateCallback, "stateCallback");
        kotlin.jvm.internal.q.g(sessionParameters, "sessionParameters");
        this.f227a = arrayList;
        this.f228b = eVar;
        this.f229c = stateCallback;
        this.f230d = i10;
        this.f231e = sessionParameters;
        this.f = num;
        this.f232g = o3Var;
        this.h = r3Var;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof n3)) {
            return false;
        }
        n3 n3Var = (n3) obj;
        return this.f227a.equals(n3Var.f227a) && this.f228b.equals(n3Var.f228b) && kotlin.jvm.internal.q.c(this.f229c, n3Var.f229c) && this.f230d == n3Var.f230d && kotlin.jvm.internal.q.c(this.f231e, n3Var.f231e) && this.f.equals(n3Var.f) && this.f232g.equals(n3Var.f232g) && kotlin.jvm.internal.q.c(this.h, n3Var.h);
    }

    public final int hashCode() {
        int iHashCode = (this.f232g.hashCode() + ((this.f.hashCode() + ((this.f231e.hashCode() + ((((this.f229c.hashCode() + ((this.f228b.hashCode() + ((this.f227a.hashCode() + 62) * 31)) * 31)) * 31) + this.f230d) * 31)) * 31)) * 31)) * 31;
        r3 r3Var = this.h;
        return iHashCode + (r3Var == null ? 0 : r3Var.hashCode());
    }

    public final String toString() {
        return "ExtensionSessionConfigData(sessionType=2, outputConfigurations=" + this.f227a + ", executor=" + this.f228b + ", stateCallback=" + this.f229c + ", sessionTemplateId=" + this.f230d + ", sessionParameters=" + this.f231e + ", extensionMode=" + this.f + ", extensionStateCallback=" + this.f232g + ", postviewOutputConfiguration=" + this.h + ')';
    }
}
