package a0;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class q4 extends wi.c {
    public x1 X;
    public ej.l Y;
    public kotlin.jvm.internal.b0 Z;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public String f287e;

    /* JADX INFO: renamed from: r0, reason: collision with root package name */
    public AutoCloseable f288r0;

    /* JADX INFO: renamed from: s0, reason: collision with root package name */
    public x0 f289s0;

    /* JADX INFO: renamed from: t0, reason: collision with root package name */
    public long f290t0;
    public /* synthetic */ Object u0;

    /* JADX INFO: renamed from: v0, reason: collision with root package name */
    public final /* synthetic */ r4 f291v0;

    /* JADX INFO: renamed from: w0, reason: collision with root package name */
    public int f292w0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public q4(r4 r4Var, wi.c cVar) {
        super(cVar);
        this.f291v0 = r4Var;
    }

    @Override // wi.a
    public final Object invokeSuspend(Object obj) {
        this.u0 = obj;
        this.f292w0 |= Integer.MIN_VALUE;
        return this.f291v0.b(null, null, null, this);
    }
}
