package a0;

import android.hardware.camera2.CaptureResult;
import android.util.Log;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.card.MaterialCardView;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import okhttp3.internal.ws.WebSocketProtocol;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class t3 implements ej.l {
    public final /* synthetic */ Object X;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f329e;

    public /* synthetic */ t3(int i10, Object obj) {
        this.f329e = i10;
        this.X = obj;
    }

    @Override // ej.l
    public final Object invoke(Object obj) {
        boolean z5;
        switch (this.f329e) {
            case 0:
                kotlinx.coroutines.z zVar = (kotlinx.coroutines.z) this.X;
                qi.b0 b0Var = qi.b0.f17350a;
                zVar.complete(b0Var);
                return b0Var;
            case 1:
                kotlinx.coroutines.z zVar2 = ((m4) this.X).f218b;
                qi.b0 b0Var2 = qi.b0.f17350a;
                zVar2.complete(b0Var2);
                return b0Var2;
            case 2:
                j4 j4Var = (j4) this.X;
                d activeCamera = (d) obj;
                kotlin.jvm.internal.q.g(activeCamera, "activeCamera");
                kotlinx.coroutines.channels.n.m37isSuccessimpl(((kotlinx.coroutines.channels.i) j4Var.f153e.f519e).mo15trySendJP2dKIU(new k4(activeCamera)));
                return qi.b0.f17350a;
            case 3:
                bf.n0 n0Var = (bf.n0) this.X;
                p2.b ex = (p2.b) obj;
                kotlin.jvm.internal.q.g(ex, "ex");
                Log.w("FirebaseSessions", "CorruptionException in session data DataStore", ex);
                return new bf.m0(n0Var.f3630a.a(null), null, null);
            case 4:
                ((ri.i) ((y4) this.X).f396r0).addLast(obj);
                return qi.b0.f17350a;
            case 5:
                ((ri.i) ((a4.n) this.X).f).addLast(obj);
                return qi.b0.f17350a;
            case 6:
                return ((g0.w) this.X).f8449m;
            case 7:
                Map map = (Map) this.X;
                t frameMetadata = (t) obj;
                kotlin.jvm.internal.q.g(frameMetadata, "frameMetadata");
                for (Map.Entry entry : map.entrySet()) {
                    if (!ri.m.X((List) entry.getValue(), frameMetadata.c((CaptureResult.Key) entry.getKey()))) {
                        z5 = false;
                        return Boolean.valueOf(z5);
                    }
                }
                z5 = true;
                return Boolean.valueOf(z5);
            case 8:
                mh.c0 c0Var = (mh.c0) this.X;
                eh.d scope = (eh.d) obj;
                kotlin.jvm.internal.q.g(scope, "scope");
                fi.f fVar = (fi.f) scope.f7799v0.a(mh.d0.f15361a, new al.j(21));
                Object obj2 = scope.f7801x0.f7804b.get(c0Var.getKey());
                kotlin.jvm.internal.q.d(obj2);
                Object objG = c0Var.g((ej.l) obj2);
                c0Var.d(objG, scope);
                fVar.f(c0Var.getKey(), objG);
                return qi.b0.f17350a;
            case 9:
                ((hh.c) this.X).close();
                return qi.b0.f17350a;
            case 10:
                eo.q qVar = (eo.q) this.X;
                int iIntValue = ((Integer) obj).intValue();
                md.c cVar = qVar.L1;
                if (cVar != null) {
                    ro.g.H((LinearLayout) cVar.f15310e, null, Integer.valueOf(ro.g.c(qVar.o(), 36) + iIntValue), 14);
                    return qi.b0.f17350a;
                }
                kotlin.jvm.internal.q.n("binding");
                throw null;
            case ue.r.NETWORK_CLIENT_ERROR_REASON_FIELD_NUMBER /* 11 */:
                dm.e eVar = (dm.e) this.X;
                Integer num = (Integer) obj;
                num.getClass();
                ro.g.H(eVar.f6990d, null, num, 14);
                return qi.b0.f17350a;
            case ue.r.CUSTOM_ATTRIBUTES_FIELD_NUMBER /* 12 */:
                eo.r1 r1Var = (eo.r1) this.X;
                Integer num2 = (Integer) obj;
                num2.getClass();
                m7.i iVar = r1Var.G1;
                if (iVar != null) {
                    ro.g.H((MaterialCardView) iVar.Z, null, num2, 14);
                    return qi.b0.f17350a;
                }
                kotlin.jvm.internal.q.n("binding");
                throw null;
            case ue.r.PERF_SESSIONS_FIELD_NUMBER /* 13 */:
                eo.t1 t1Var = (eo.t1) this.X;
                Integer num3 = (Integer) obj;
                num3.getClass();
                ge.q qVar2 = t1Var.G1;
                if (qVar2 != null) {
                    ro.g.H((ConstraintLayout) qVar2.f8937c, null, num3, 14);
                    return qi.b0.f17350a;
                }
                kotlin.jvm.internal.q.n("binding");
                throw null;
            case 14:
                eo.y1 y1Var = (eo.y1) this.X;
                Integer num4 = (Integer) obj;
                num4.getClass();
                a4.n nVar = y1Var.G1;
                if (nVar != null) {
                    ro.g.H((ConstraintLayout) nVar.f519e, null, num4, 14);
                    return qi.b0.f17350a;
                }
                kotlin.jvm.internal.q.n("binding");
                throw null;
            case WebSocketProtocol.B0_MASK_OPCODE /* 15 */:
                dm.e eVar2 = (dm.e) this.X;
                Integer num5 = (Integer) obj;
                num5.getClass();
                ro.g.H(eVar2.f6990d, null, num5, 14);
                return qi.b0.f17350a;
            case WebSocketProtocol.B0_FLAG_RSV3 /* 16 */:
                eo.f2 f2Var = (eo.f2) this.X;
                Integer num6 = (Integer) obj;
                num6.getClass();
                v2 v2Var = f2Var.G1;
                if (v2Var != null) {
                    ro.g.H((ConstraintLayout) v2Var.f366g, null, num6, 14);
                    return qi.b0.f17350a;
                }
                kotlin.jvm.internal.q.n("binding");
                throw null;
            case 17:
                a4.n nVar2 = (a4.n) this.X;
                Integer num7 = (Integer) obj;
                num7.getClass();
                ro.g.H((ConstraintLayout) nVar2.f517c, null, num7, 14);
                return qi.b0.f17350a;
            case 18:
                eo.p2 p2Var = (eo.p2) this.X;
                Integer num8 = (Integer) obj;
                num8.getClass();
                v2 v2Var2 = p2Var.G1;
                if (v2Var2 != null) {
                    ro.g.H((ConstraintLayout) v2Var2.f366g, null, num8, 14);
                    return qi.b0.f17350a;
                }
                kotlin.jvm.internal.q.n("binding");
                throw null;
            case 19:
                eo.r2 r2Var = (eo.r2) this.X;
                Integer num9 = (Integer) obj;
                num9.getClass();
                dm.j jVar = r2Var.G1;
                if (jVar != null) {
                    ro.g.H(jVar.f7030c, null, num9, 14);
                    return qi.b0.f17350a;
                }
                kotlin.jvm.internal.q.n("binding");
                throw null;
            case 20:
                eo.t2 t2Var = (eo.t2) this.X;
                Integer num10 = (Integer) obj;
                num10.getClass();
                m7.l lVar = t2Var.G1;
                if (lVar != null) {
                    ro.g.H((FrameLayout) lVar.Y, null, num10, 14);
                    return qi.b0.f17350a;
                }
                kotlin.jvm.internal.q.n("binding");
                throw null;
            case 21:
                eo.v2 v2Var3 = (eo.v2) this.X;
                Integer num11 = (Integer) obj;
                num11.getClass();
                m7.m mVar = v2Var3.G1;
                if (mVar != null) {
                    ro.g.H((LinearLayout) mVar.Z, null, num11, 14);
                    return qi.b0.f17350a;
                }
                kotlin.jvm.internal.q.n("binding");
                throw null;
            case 22:
                g6.s sVar = (g6.s) this.X;
                p6.a db2 = (p6.a) obj;
                kotlin.jvm.internal.q.g(db2, "db");
                sVar.h = db2;
                return qi.b0.f17350a;
            case 23:
                g6.w wVar = (g6.w) this.X;
                g6.a config = (g6.a) obj;
                kotlin.jvm.internal.q.g(config, "config");
                return wVar.g(config);
            case 24:
                q1 q1Var = (q1) this.X;
                o6.a it = (o6.a) obj;
                kotlin.jvm.internal.q.g(it, "it");
                return ((Callable) q1Var.X).call();
            case 25:
                go.b bVar = (go.b) this.X;
                ro.g.H((RecyclerView) bVar.h0().X, null, Integer.valueOf(ro.g.c(bVar.o(), 20) + ((Integer) obj).intValue()), 14);
                return qi.b0.f17350a;
            case 26:
                go.d dVar = (go.d) this.X;
                Integer num12 = (Integer) obj;
                num12.getClass();
                androidx.recyclerview.widget.s0 s0Var = dVar.f9066q1;
                if (s0Var != null) {
                    ro.g.H(s0Var.f3110a, null, num12, 14);
                    return qi.b0.f17350a;
                }
                kotlin.jvm.internal.q.n("binding");
                throw null;
            case 27:
                go.w wVar2 = (go.w) this.X;
                int iIntValue2 = ((Integer) obj).intValue();
                dm.f fVar2 = wVar2.f9364q1;
                ro.g.H(fVar2 != null ? (RecyclerView) fVar2.h : null, null, Integer.valueOf(ro.g.c(wVar2.o(), 60) + iIntValue2), 14);
                return qi.b0.f17350a;
            case 28:
                go.f0 f0Var = (go.f0) this.X;
                Integer num13 = (Integer) obj;
                num13.getClass();
                ro.g.H((RecyclerView) f0Var.l0().f363c, null, num13, 14);
                return qi.b0.f17350a;
            default:
                go.m0 m0Var = (go.m0) this.X;
                Integer num14 = (Integer) obj;
                num14.getClass();
                ro.g.H(m0Var.i0().f6975d, null, num14, 14);
                return qi.b0.f17350a;
        }
    }
}
