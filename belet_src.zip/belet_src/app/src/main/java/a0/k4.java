package a0;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class k4 extends k2 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final d f163a;

    public k4(d activeCamera) {
        kotlin.jvm.internal.q.g(activeCamera, "activeCamera");
        this.f163a = activeCamera;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof k4) && kotlin.jvm.internal.q.c(this.f163a, ((k4) obj).f163a);
    }

    public final int hashCode() {
        return this.f163a.hashCode();
    }

    public final String toString() {
        return "RequestClose(activeCamera=" + this.f163a + ')';
    }
}
