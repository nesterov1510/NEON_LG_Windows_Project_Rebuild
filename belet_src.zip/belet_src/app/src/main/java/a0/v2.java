package a0;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Paint;
import android.os.Trace;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.work.impl.WorkDatabase;
import com.google.android.gms.internal.measurement.mf;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.imageview.ShapeableImageView;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import tm.belet.films.R;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class v2 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Object f361a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public Object f362b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Object f363c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Object f364d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public Object f365e;
    public Object f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public Object f366g;
    public final Object h;

    public /* synthetic */ v2(ViewGroup viewGroup, Object obj, Object obj2, Object obj3, Object obj4, Object obj5, Object obj6, Object obj7) {
        this.f361a = viewGroup;
        this.f362b = obj;
        this.f363c = obj2;
        this.f364d = obj3;
        this.f365e = obj4;
        this.f = obj5;
        this.f366g = obj6;
        this.h = obj7;
    }

    public static final ga.e a(v2 v2Var, g0.s sVar) {
        Iterator it = sVar.f8424a.iterator();
        kotlin.jvm.internal.q.f(it, "iterator(...)");
        while (it.hasNext()) {
            Object next = it.next();
            kotlin.jvm.internal.q.f(next, "next(...)");
            m0.j jVar = g0.p.f8410a;
            if (!kotlin.jvm.internal.q.c(jVar, jVar)) {
                synchronized (m0.w0.f14957a) {
                }
                kotlin.jvm.internal.q.d((Context) v2Var.f);
            }
        }
        return m0.x.f14959a;
    }

    public static final void b(v2 v2Var, int i10) {
        m0.l0 l0Var;
        g0.w wVar = (g0.w) v2Var.f364d;
        if (wVar != null) {
            kotlin.jvm.internal.q.d(wVar);
            mf mfVar = wVar.f8444g;
            if (mfVar == null) {
                throw new IllegalStateException("CameraX not initialized yet.");
            }
            r.c cVar = (r.c) mfVar.f5286e;
            synchronized (cVar.f17570b) {
                cVar.f17573e = i10;
                l0Var = cVar.f17571c;
            }
            if (l0Var == null) {
                return;
            }
            cVar.f = i10 == 2;
            Iterator it = l0Var.d().iterator();
            kotlin.jvm.internal.q.f(it, "iterator(...)");
            while (it.hasNext()) {
                m0.c0 c0Var = (m0.c0) it.next();
                r.i iVar = c0Var instanceof r.i ? (r.i) c0Var : null;
                if (iVar != null) {
                    if (i10 == 1) {
                        iVar.s(true);
                    } else if (i10 == 2) {
                        iVar.s(false);
                    }
                }
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:22:0x007a A[Catch: all -> 0x0077, DONT_GENERATE, TRY_LEAVE, TryCatch #0 {all -> 0x0077, blocks: (B:5:0x003f, B:7:0x0053, B:9:0x005f, B:11:0x0063, B:17:0x0071, B:18:0x0074, B:22:0x007a), top: B:58:0x003f, outer: #1 }] */
    /* JADX WARN: Type inference failed for: r18v1, types: [m0.b, m0.c0] */
    public static c1.b c(v2 v2Var, androidx.lifecycle.v vVar, g0.s sVar, e6.b bVar) {
        c1.b bVarB;
        m0.c cVar;
        g0.z zVar = g0.z.Z;
        g0.c.a("CX:bindToLifecycle-internal");
        try {
            g6.y.b();
            g0.w wVar = (g0.w) v2Var.f364d;
            kotlin.jvm.internal.q.d(wVar);
            m0.c0 c0VarC = sVar.c(wVar.f8439a.d());
            kotlin.jvm.internal.q.f(c0VarC, "select(...)");
            c0VarC.q(true);
            m0.b bVarD = v2Var.d(sVar);
            Object obj = null;
            g0.q qVarP = ta.f.p(bVarD, null);
            c1.g gVar = (c1.g) v2Var.f365e;
            kotlin.jvm.internal.q.d(gVar);
            synchronized (gVar.f3855a) {
                try {
                    bVarB = (c1.b) gVar.f3856b.get(new c1.a(System.identityHashCode(vVar), qVarP));
                    if (bVarB != null) {
                        s0.f fVar = bVarB.Y;
                        if (fVar.f18133e.f14772e.j() || ((cVar = fVar.X) != null && cVar.f14772e.j())) {
                            gVar.l(bVarB);
                            bVarB = null;
                        }
                    }
                } catch (Throwable th2) {
                    throw th2;
                }
            }
            c1.g gVar2 = (c1.g) v2Var.f365e;
            kotlin.jvm.internal.q.d(gVar2);
            Collection collectionD = gVar2.d();
            for (g0.b2 b2Var : (List) bVar.f7572g) {
                for (Object obj2 : collectionD) {
                    Object obj3 = obj;
                    kotlin.jvm.internal.q.f(obj2, "next(...)");
                    c1.b bVar2 = (c1.b) obj2;
                    if (bVar2.s(b2Var) && !kotlin.jvm.internal.q.c(bVar2.i(), vVar)) {
                        throw new IllegalStateException(String.format("Use case %s already bound to a different lifecycle.", Arrays.copyOf(new Object[]{b2Var}, 1)));
                    }
                    obj = obj3;
                }
            }
            ?? r18 = obj;
            if (bVarB == null) {
                c1.g gVar3 = (c1.g) v2Var.f365e;
                kotlin.jvm.internal.q.d(gVar3);
                g0.w wVar2 = (g0.w) v2Var.f364d;
                kotlin.jvm.internal.q.d(wVar2);
                ge.q qVar = wVar2.f8447k;
                if (qVar == null) {
                    throw new IllegalStateException("CameraX not initialized yet.");
                }
                s0.f fVar2 = new s0.f(c0VarC, r18, bVarD, r18, zVar, zVar, (r.c) qVar.f8936b, (androidx.media3.session.legacy.r0) qVar.f8938d, (m0.t2) qVar.f8937c);
                g0.w wVar3 = (g0.w) v2Var.f364d;
                kotlin.jvm.internal.q.d(wVar3);
                bVarB = gVar3.b(vVar, fVar2, (g0.q1) wVar3.f8451o.getValue());
            }
            if (!((List) bVar.f7572g).isEmpty()) {
                c1.g gVar4 = (c1.g) v2Var.f365e;
                kotlin.jvm.internal.q.d(gVar4);
                g0.w wVar4 = (g0.w) v2Var.f364d;
                kotlin.jvm.internal.q.d(wVar4);
                mf mfVar = wVar4.f8444g;
                if (mfVar == null) {
                    throw new IllegalStateException("CameraX not initialized yet.");
                }
                gVar4.a(bVarB, bVar, (r.c) mfVar.f5286e);
                ((HashSet) v2Var.h).add(new c1.a(System.identityHashCode(vVar), qVarP));
            }
            Trace.endSection();
            return bVarB;
        } catch (Throwable th3) {
            Trace.endSection();
            throw th3;
        }
    }

    public m0.b d(g0.s cameraSelector) {
        Object bVar;
        kotlin.jvm.internal.q.g(cameraSelector, "cameraSelector");
        g0.c.a("CX:getCameraInfo");
        try {
            g0.w wVar = (g0.w) this.f364d;
            kotlin.jvm.internal.q.d(wVar);
            m0.a0 a0VarR = cameraSelector.c(wVar.f8439a.d()).r();
            kotlin.jvm.internal.q.f(a0VarR, "getCameraInfoInternal(...)");
            ga.e eVarA = a(this, cameraSelector);
            String strE = a0VarR.e();
            kotlin.jvm.internal.q.f(strE, "getCameraId(...)");
            g0.q qVarJ = ta.f.j(strE, null, (m0.j) eVarA.f8722e);
            synchronized (this.f361a) {
                bVar = ((HashMap) this.f366g).get(qVarJ);
                if (bVar == null) {
                    bVar = new m0.b(a0VarR, eVarA);
                    ((HashMap) this.f366g).put(qVarJ, bVar);
                }
            }
            m0.b bVar2 = (m0.b) bVar;
            Trace.endSection();
            return bVar2;
        } catch (Throwable th2) {
            Trace.endSection();
            throw th2;
        }
    }

    public void e(g0.w wVar, Context context) {
        m0.i0 i0Var;
        synchronized (this.f361a) {
            this.f364d = wVar;
            this.f = context;
            if (wVar != null && (i0Var = wVar.f8450n) != null) {
                q0.c cVarG = tc.b.G();
                kotlin.jvm.internal.q.f(cVarG, "mainThreadExecutor(...)");
                i0Var.f14850n.add(new m0.g0(this, cVarG));
                cVarG.execute(new m0.d0(i0Var, this));
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0019  */
    public Object f(String str, int i10, long j10, x1 x1Var, n0 n0Var, wi.c cVar) {
        p2 p2Var;
        x1 x1Var2;
        n0 n0Var2;
        long j11;
        int i11;
        String str2;
        if (cVar instanceof p2) {
            p2Var = (p2) cVar;
            int i12 = p2Var.u0;
            if ((i12 & Integer.MIN_VALUE) != 0) {
                p2Var.u0 = i12 - Integer.MIN_VALUE;
            } else {
                p2Var = new p2(this, cVar);
            }
        } else {
            p2Var = new p2(this, cVar);
        }
        Object objWithContext = p2Var.f268s0;
        vi.a aVar = vi.a.f21252e;
        int i13 = p2Var.u0;
        ui.d dVar = null;
        if (i13 == 0) {
            g6.y.I(objWithContext);
            c2 c2Var = (c2) this.f362b;
            p2Var.f266e = str;
            p2Var.X = x1Var;
            p2Var.Y = n0Var;
            p2Var.Z = i10;
            p2Var.f267r0 = j10;
            p2Var.u0 = 1;
            b2 b2Var = (b2) c2Var;
            synchronized (b2Var.f) {
                z.s sVar = (z.s) b2Var.f.get(str);
                objWithContext = sVar != null ? sVar : kotlinx.coroutines.i.withContext(b2Var.f13b.f3844d, new m0(b2Var, str, dVar, 4), p2Var);
            }
            if (objWithContext != aVar) {
                x1Var2 = x1Var;
                n0Var2 = n0Var;
                j11 = j10;
                i11 = i10;
                str2 = str;
            }
        }
        if (i13 != 1) {
            if (i13 != 2) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            g6.y.I(objWithContext);
            return objWithContext;
        }
        long j12 = p2Var.f267r0;
        int i14 = p2Var.Z;
        n0 n0Var3 = p2Var.Y;
        x1 x1Var3 = p2Var.X;
        String str3 = p2Var.f266e;
        g6.y.I(objWithContext);
        i11 = i14;
        n0Var2 = n0Var3;
        x1Var2 = x1Var3;
        j11 = j12;
        str2 = str3;
        c0.l lVar = (c0.l) this.f365e;
        a2 a2Var = (a2) this.f363c;
        d2 d2Var = (d2) this.f364d;
        c0.n nVar = (c0.n) this.f366g;
        z.u uVar = (z.u) this.f;
        u2 u2Var = new u2(this, str2, new m(str2, (z.s) objWithContext, i11, j11, lVar, a2Var, x1Var2, d2Var, nVar, n0Var2, uVar.f23393a, uVar.f23394b), null);
        p2Var.f266e = null;
        p2Var.X = null;
        p2Var.Y = null;
        p2Var.u0 = 2;
        Object objSupervisorScope = kotlinx.coroutines.d3.supervisorScope(u2Var, p2Var);
        return objSupervisorScope == aVar ? aVar : objSupervisorScope;
    }

    public v2(ConstraintLayout constraintLayout, ShapeableImageView shapeableImageView, ShapeableImageView shapeableImageView2, ShapeableImageView shapeableImageView3, TextView textView, MaterialButton materialButton, TextView textView2, ConstraintLayout constraintLayout2, MaterialButton materialButton2) {
        this.f361a = shapeableImageView;
        this.f362b = shapeableImageView2;
        this.f363c = shapeableImageView3;
        this.f364d = textView;
        this.f365e = materialButton;
        this.f = textView2;
        this.f366g = constraintLayout2;
        this.h = materialButton2;
    }

    public v2() {
        this.f361a = new Object();
        this.f363c = r0.i.Y;
        this.f366g = new HashMap();
        this.h = new HashSet();
    }

    public v2(Context context) {
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(fk.j.D(R.attr.materialCalendarStyle, context, com.google.android.material.datepicker.r.class.getCanonicalName()).data, hb.a.f9802w);
        this.f361a = androidx.appcompat.widget.t.f(context, typedArrayObtainStyledAttributes.getResourceId(4, 0));
        this.f366g = androidx.appcompat.widget.t.f(context, typedArrayObtainStyledAttributes.getResourceId(2, 0));
        this.f362b = androidx.appcompat.widget.t.f(context, typedArrayObtainStyledAttributes.getResourceId(3, 0));
        this.f363c = androidx.appcompat.widget.t.f(context, typedArrayObtainStyledAttributes.getResourceId(5, 0));
        ColorStateList colorStateListI = g0.c.i(context, typedArrayObtainStyledAttributes, 7);
        this.f364d = androidx.appcompat.widget.t.f(context, typedArrayObtainStyledAttributes.getResourceId(9, 0));
        this.f365e = androidx.appcompat.widget.t.f(context, typedArrayObtainStyledAttributes.getResourceId(8, 0));
        this.f = androidx.appcompat.widget.t.f(context, typedArrayObtainStyledAttributes.getResourceId(10, 0));
        Paint paint = new Paint();
        this.h = paint;
        paint.setColor(colorStateListI.getDefaultColor());
        typedArrayObtainStyledAttributes.recycle();
    }

    public v2(i1 i1Var, c2 camera2MetadataProvider, a2 cameraErrorListener, d2 camera2Quirks, c0.l timeSource, z.u uVar, c0.n threads) {
        kotlin.jvm.internal.q.g(camera2MetadataProvider, "camera2MetadataProvider");
        kotlin.jvm.internal.q.g(cameraErrorListener, "cameraErrorListener");
        kotlin.jvm.internal.q.g(camera2Quirks, "camera2Quirks");
        kotlin.jvm.internal.q.g(timeSource, "timeSource");
        kotlin.jvm.internal.q.g(threads, "threads");
        this.f361a = i1Var;
        this.f362b = camera2MetadataProvider;
        this.f363c = cameraErrorListener;
        this.f364d = camera2Quirks;
        this.f365e = timeSource;
        this.f = uVar;
        this.f366g = threads;
        this.h = kotlinx.coroutines.b0.CompletableDeferred$default(null, 1, null);
    }

    public v2(Context context, d7.b bVar, k8.k kVar, e7.e eVar, WorkDatabase workDatabase, m7.o oVar, ArrayList arrayList) {
        new cb.u();
        this.f361a = context.getApplicationContext();
        this.f363c = kVar;
        this.f362b = eVar;
        this.f364d = bVar;
        this.f365e = workDatabase;
        this.f = oVar;
        this.h = arrayList;
    }
}
