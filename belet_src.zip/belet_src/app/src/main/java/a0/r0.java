package a0;

import android.content.Context;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.OutputConfiguration;
import android.hardware.camera2.params.SessionConfiguration;
import android.os.Build;
import android.util.Log;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Map;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class r0 implements z.e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final c0.n f299a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final u1 f300b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final b2 f301c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final j4 f302d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final z7.b f303e;
    public final Object f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final LinkedHashSet f304g;

    public r0(c0.n threads, u1 camera2DeviceCache, b2 camera2MetadataCache, j4 camera2DeviceManager, z7.b bVar, Context context) {
        kotlin.jvm.internal.q.g(threads, "threads");
        kotlin.jvm.internal.q.g(camera2DeviceCache, "camera2DeviceCache");
        kotlin.jvm.internal.q.g(camera2MetadataCache, "camera2MetadataCache");
        kotlin.jvm.internal.q.g(camera2DeviceManager, "camera2DeviceManager");
        this.f299a = threads;
        this.f300b = camera2DeviceCache;
        this.f301c = camera2MetadataCache;
        this.f302d = camera2DeviceManager;
        this.f303e = bVar;
        this.f = new Object();
        this.f304g = new LinkedHashSet();
    }

    /* JADX WARN: Code duplicated, block: B:58:0x0134  */
    /* JADX WARN: Code duplicated, block: B:59:0x013d  */
    /* JADX WARN: Code duplicated, block: B:61:0x0140  */
    /* JADX WARN: Code duplicated, block: B:64:0x0150  */
    /* JADX WARN: Code duplicated, block: B:66:0x0162  */
    /* JADX WARN: Code duplicated, block: B:67:0x0165  */
    /* JADX WARN: Code duplicated, block: B:72:0x017a  */
    /* JADX WARN: Code duplicated, block: B:73:0x0186  */
    /* JADX WARN: Code duplicated, block: B:75:0x0189  */
    /* JADX WARN: Code duplicated, block: B:77:0x0193  */
    /* JADX WARN: Code duplicated, block: B:79:0x0168 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:7:0x0019  */
    /* JADX WARN: Code duplicated, block: B:82:0x014a A[SYNTHETIC] */
    public final Object a(z.k kVar, wi.c cVar) {
        p0 p0Var;
        b1.d dVar;
        z.k kVar2;
        SessionConfiguration sessionConfiguration;
        OutputConfiguration outputConfiguration;
        z1 z1Var;
        CaptureRequest.Builder builderA;
        Integer num;
        Object key;
        Object value;
        CaptureRequest.Key key2;
        z.k kVar3 = kVar;
        if (cVar instanceof p0) {
            p0Var = (p0) cVar;
            int i10 = p0Var.f262s0;
            if ((i10 & Integer.MIN_VALUE) != 0) {
                p0Var.f262s0 = i10 - Integer.MIN_VALUE;
            } else {
                p0Var = new p0(this, cVar);
            }
        } else {
            p0Var = new p0(this, cVar);
        }
        Object objB = p0Var.Z;
        vi.a aVar = vi.a.f21252e;
        int i11 = p0Var.f262s0;
        u1 u1Var = this.f300b;
        int i12 = 1;
        if (i11 == 0) {
            g6.y.I(objB);
            if (Build.VERSION.SDK_INT < 35) {
                return new z.g0(0);
            }
            String str = kVar3.f23350a;
            p0Var.f260e = kVar3;
            p0Var.f262s0 = 1;
            objB = u1Var.b(str, p0Var);
            if (objB != aVar) {
            }
            return aVar;
        }
        if (i11 == 1) {
            kVar3 = p0Var.f260e;
            g6.y.I(objB);
        } else {
            if (i11 != 2) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            sessionConfiguration = (SessionConfiguration) p0Var.Y;
            dVar = p0Var.X;
            kVar2 = p0Var.f260e;
            g6.y.I(objB);
        }
        z1Var = (z1) objB;
        if (z1Var != null) {
            builderA = ((y1) z1Var).a(kVar2.f);
        } else {
            builderA = null;
        }
        if (builderA != null) {
            for (Map.Entry entry : kVar2.f23355g.entrySet()) {
                key = entry.getKey();
                value = entry.getValue();
                if (key instanceof CaptureRequest.Key) {
                    key2 = (CaptureRequest.Key) key;
                } else {
                    key2 = null;
                }
                if (key2 != null) {
                    builderA.set(key2, value);
                }
            }
            CaptureRequest captureRequestBuild = builderA.build();
            kotlin.jvm.internal.q.f(captureRequestBuild, "build(...)");
            c0.k(sessionConfiguration, captureRequestBuild);
        }
        if (dVar != null) {
            num = new Integer(dVar.a(sessionConfiguration).f619e);
        } else {
            num = null;
        }
        return num != null ? new z.g0(num.intValue()) : new z.g0(0);
        b1.d dVar2 = (b1.d) objB;
        int i13 = kVar3.h;
        String str2 = kVar3.f23350a;
        if (i13 == 0) {
            i12 = 0;
        } else if (i13 != 1) {
            if (i13 == 2) {
                Log.i("CXCP", "Unsupported session mode: " + ((Object) android.support.v4.media.session.b.I(kVar3.h)));
                return new z.g0(0);
            }
            i12 = i13;
        }
        LinkedHashSet linkedHashSet = new LinkedHashSet();
        Iterator it = kVar3.f23351b.iterator();
        while (it.hasNext()) {
            for (z.x0 x0Var : ((z.a0) it.next()).f23311a) {
                int i14 = x0Var.f23405b;
                String str3 = x0Var.f23406c;
                x xVarA = x2.a(null, Integer.valueOf(i14), z.a1.f23315d, x0Var.f23407d, x0Var.f23408e, x0Var.f, x0Var.h, x0Var.f23404a, false, 0, !(str3 == null ? false : str3.equals(str2)) ? str3 : null, 1536);
                if (xVarA != null && (outputConfiguration = (OutputConfiguration) xVarA.D(kotlin.jvm.internal.e0.a(OutputConfiguration.class))) != null) {
                    linkedHashSet.add(outputConfiguration);
                }
            }
        }
        SessionConfiguration sessionConfigurationB = j0.b(i12, ri.m.z0(linkedHashSet));
        p0Var.f260e = kVar3;
        p0Var.X = dVar2;
        p0Var.Y = sessionConfigurationB;
        p0Var.f262s0 = 2;
        Object objC = u1Var.c(str2, p0Var);
        if (objC != aVar) {
            dVar = dVar2;
            objB = objC;
            kVar2 = kVar3;
            sessionConfiguration = sessionConfigurationB;
            z1Var = (z1) objB;
            if (z1Var != null) {
                builderA = ((y1) z1Var).a(kVar2.f);
            } else {
                builderA = null;
            }
            if (builderA != null) {
                while (r2.hasNext()) {
                    key = entry.getKey();
                    value = entry.getValue();
                    if (key instanceof CaptureRequest.Key) {
                        key2 = (CaptureRequest.Key) key;
                    } else {
                        key2 = null;
                    }
                    if (key2 != null) {
                        builderA.set(key2, value);
                    }
                }
                CaptureRequest captureRequestBuild2 = builderA.build();
                kotlin.jvm.internal.q.f(captureRequestBuild2, "build(...)");
                c0.k(sessionConfiguration, captureRequestBuild2);
            }
            if (dVar != null) {
                num = new Integer(dVar.a(sessionConfiguration).f619e);
            } else {
                num = null;
            }
            if (num != null) {
            }
        }
        return aVar;
    }

    public final void b(d1 d1Var) {
        Log.d("CXCP", d1Var + " finalized");
        synchronized (this.f) {
            this.f304g.remove(d1Var);
        }
    }
}
