package a0;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class x3 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final n4 f382a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final d f383b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final c0.f f384c;

    public x3(n4 n4Var, d dVar, c0.f fVar) {
        this.f382a = n4Var;
        this.f383b = dVar;
        this.f384c = fVar;
    }
}
