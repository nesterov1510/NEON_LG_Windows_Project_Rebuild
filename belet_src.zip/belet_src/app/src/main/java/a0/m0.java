package a0;

import android.animation.ObjectAnimator;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.hardware.camera2.CameraAccessException;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;
import com.airbnb.lottie.LottieAnimationView;
import com.google.android.gms.internal.measurement.mf;
import com.google.android.gms.internal.measurement.zd;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.imageview.ShapeableImageView;
import com.google.android.material.tabs.TabLayout;
import com.mammet.downloadstateview.DownloadStateView;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CancellationException;
import okhttp3.internal.url._UrlKt;
import okhttp3.internal.ws.WebSocketProtocol;
import tm.belet.films.R;
import tm.belet.films.domain.models.profile.ColorModel;
import tm.belet.films.domain.models.profile.ColoredUIComponentModel;
import tm.belet.films.presentation.activities.ActivityLoginRegister;
import tm.belet.films.presentation.activities.SplashScreenActivity;
import tm.belet.films.presentation.viewmodel.LoginViewModel;
import tm.belet.films.presentation.viewmodel.MovieInfoViewModel;
import tm.belet.films.presentation.widgets.AnimatedBorderCardView;
import tm.belet.films.presentation.widgets.ButtonLarge;
import tm.belet.films.presentation.widgets.design_system.PrimaryButton;
import tm.belet.films.presentation.widgets.qr_code_scanner.CodeScannerView;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class m0 extends wi.i implements ej.p {
    public final /* synthetic */ Object X;
    public /* synthetic */ Object Y;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f197e;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ m0(Object obj, Object obj2, ui.d dVar, int i10) {
        super(2, dVar);
        this.f197e = i10;
        this.Y = obj;
        this.X = obj2;
    }

    private final Object b(Object obj) {
        String str;
        String str2;
        ColorModel colorModel;
        String str3;
        ColorModel colorModel2;
        ColorModel colorModel3;
        eo.f2 f2Var = (eo.f2) this.X;
        tm.belet.films.presentation.viewmodel.y2 y2Var = (tm.belet.films.presentation.viewmodel.y2) this.Y;
        vi.a aVar = vi.a.f21252e;
        g6.y.I(obj);
        boolean z5 = y2Var.f20008a;
        String str4 = y2Var.f20010c;
        qi.b0 b0Var = qi.b0.f17350a;
        if (!z5) {
            if (str4.length() > 0) {
                Log.e("TAG_Prompt", "Pr: ".concat(str4));
                v2 v2Var = f2Var.G1;
                if (v2Var == null) {
                    kotlin.jvm.internal.q.n("binding");
                    throw null;
                }
                ((TextView) v2Var.f).setText(f2Var.x(R.string.setup_profile_title));
                v2 v2Var2 = f2Var.G1;
                if (v2Var2 == null) {
                    kotlin.jvm.internal.q.n("binding");
                    throw null;
                }
                ((TextView) v2Var2.f364d).setText(f2Var.x(R.string.setup_profile_desc));
                v2 v2Var3 = f2Var.G1;
                if (v2Var3 == null) {
                    kotlin.jvm.internal.q.n("binding");
                    throw null;
                }
                ((MaterialButton) v2Var3.f365e).setText(f2Var.x(R.string.continue_text));
                v2 v2Var4 = f2Var.G1;
                if (v2Var4 != null) {
                    ((MaterialButton) v2Var4.h).setText(f2Var.x(R.string.not_now));
                    return b0Var;
                }
                kotlin.jvm.internal.q.n("binding");
                throw null;
            }
            an.c cVar = y2Var.f20009b;
            if (cVar != null) {
                List list = cVar.f910c;
                ColoredUIComponentModel coloredUIComponentModel = cVar.f912e;
                ColoredUIComponentModel coloredUIComponentModel2 = cVar.f911d;
                ArrayList arrayList = new ArrayList(ri.o.S(list, 10));
                int i10 = 0;
                for (Object obj2 : list) {
                    int i11 = i10 + 1;
                    if (i10 < 0) {
                        ri.n.R();
                        throw null;
                    }
                    String str5 = (String) obj2;
                    if (i10 == 0) {
                        Context contextO = f2Var.o();
                        v2 v2Var5 = f2Var.G1;
                        if (v2Var5 == null) {
                            kotlin.jvm.internal.q.n("binding");
                            throw null;
                        }
                        ShapeableImageView shapeableImageView = (ShapeableImageView) v2Var5.f361a;
                        if (contextO != null && (!(contextO instanceof Activity) || !((Activity) contextO).isDestroyed())) {
                            if (str5 == null || mj.l.m0(str5)) {
                                shapeableImageView.setImageResource(R.drawable.ic_default_mode);
                            } else {
                                ((com.bumptech.glide.l) ((com.bumptech.glide.l) w.x0.o(contextO, contextO, str5, R.color.black_second)).e(R.drawable.ic_default_mode)).w(shapeableImageView);
                            }
                        }
                    } else if (i10 == 1) {
                        Context contextO2 = f2Var.o();
                        v2 v2Var6 = f2Var.G1;
                        if (v2Var6 == null) {
                            kotlin.jvm.internal.q.n("binding");
                            throw null;
                        }
                        ShapeableImageView shapeableImageView2 = (ShapeableImageView) v2Var6.f363c;
                        if (contextO2 != null && (!(contextO2 instanceof Activity) || !((Activity) contextO2).isDestroyed())) {
                            if (str5 == null || mj.l.m0(str5)) {
                                shapeableImageView2.setImageResource(R.color.black_second);
                            } else {
                                ((com.bumptech.glide.l) ((com.bumptech.glide.l) w.x0.o(contextO2, contextO2, str5, R.color.black_second)).e(R.color.black_second)).w(shapeableImageView2);
                            }
                        }
                    } else if (i10 != 2) {
                        continue;
                    } else {
                        Context contextO3 = f2Var.o();
                        v2 v2Var7 = f2Var.G1;
                        if (v2Var7 == null) {
                            kotlin.jvm.internal.q.n("binding");
                            throw null;
                        }
                        ShapeableImageView shapeableImageView3 = (ShapeableImageView) v2Var7.f362b;
                        if (contextO3 != null && (!(contextO3 instanceof Activity) || !((Activity) contextO3).isDestroyed())) {
                            if (str5 == null || mj.l.m0(str5)) {
                                shapeableImageView3.setImageResource(R.color.black_second);
                            } else {
                                ((com.bumptech.glide.l) ((com.bumptech.glide.l) w.x0.o(contextO3, contextO3, str5, R.color.black_second)).e(R.color.black_second)).w(shapeableImageView3);
                            }
                        }
                    }
                    arrayList.add(b0Var);
                    i10 = i11;
                }
                v2 v2Var8 = f2Var.G1;
                if (v2Var8 == null) {
                    kotlin.jvm.internal.q.n("binding");
                    throw null;
                }
                ((TextView) v2Var8.f).setText(cVar.f908a);
                v2 v2Var9 = f2Var.G1;
                if (v2Var9 == null) {
                    kotlin.jvm.internal.q.n("binding");
                    throw null;
                }
                ((TextView) v2Var9.f364d).setText(cVar.f909b);
                v2 v2Var10 = f2Var.G1;
                if (v2Var10 == null) {
                    kotlin.jvm.internal.q.n("binding");
                    throw null;
                }
                MaterialButton materialButton = (MaterialButton) v2Var10.f365e;
                materialButton.setText(coloredUIComponentModel2 != null ? coloredUIComponentModel2.f19346e : null);
                if (coloredUIComponentModel2 == null || (colorModel3 = coloredUIComponentModel2.Z) == null || (str = colorModel3.X) == null) {
                    str = "#000000";
                }
                materialButton.setBackgroundColor(ta.f.L(str));
                String str6 = "#F5F5F5";
                if (coloredUIComponentModel2 == null || (colorModel2 = coloredUIComponentModel2.Y) == null || (str2 = colorModel2.X) == null) {
                    str2 = "#F5F5F5";
                }
                materialButton.setTextColor(ta.f.L(str2));
                v2 v2Var11 = f2Var.G1;
                if (v2Var11 == null) {
                    kotlin.jvm.internal.q.n("binding");
                    throw null;
                }
                MaterialButton materialButton2 = (MaterialButton) v2Var11.h;
                materialButton2.setText(coloredUIComponentModel != null ? coloredUIComponentModel.f19346e : null);
                if (coloredUIComponentModel != null && (colorModel = coloredUIComponentModel.Y) != null && (str3 = colorModel.X) != null) {
                    str6 = str3;
                }
                materialButton2.setTextColor(ta.f.L(str6));
                return b0Var;
            }
        }
        return b0Var;
    }

    private final Object c(Object obj) {
        Integer numE;
        List list = (List) this.Y;
        vi.a aVar = vi.a.f21252e;
        g6.y.I(obj);
        go.w wVar = (go.w) this.X;
        if (kotlin.jvm.internal.q.c(wVar.i0().f(), Boolean.FALSE) && (numE = com.bumptech.glide.d.e(wVar.b0())) != null) {
            oo.c.e(wVar.o(), oo.l.ERROR, numE.intValue());
            wVar.i0().h();
        }
        if (list == null || list.isEmpty()) {
            yn.o oVar = wVar.f9365r1;
            if (oVar != null) {
                oVar.z(ri.s.f18050e);
            }
            dm.f fVar = wVar.f9364q1;
            if (fVar != null) {
                ((dm.i) fVar.f6997i).f7027a.setVisibility(0);
            }
            dm.f fVar2 = wVar.f9364q1;
            if (fVar2 != null) {
                ((NestedScrollView) fVar2.f6996g).setVisibility(8);
            }
        } else {
            dm.f fVar3 = wVar.f9364q1;
            if (fVar3 != null) {
                ((dm.i) fVar3.f6997i).f7027a.setVisibility(8);
            }
            dm.f fVar4 = wVar.f9364q1;
            if (fVar4 != null) {
                ((NestedScrollView) fVar4.f6996g).setVisibility(0);
            }
            wVar.f9370w1 = list;
            yn.o oVar2 = wVar.f9365r1;
            if (oVar2 != null) {
                oVar2.z(list);
            }
        }
        return qi.b0.f17350a;
    }

    private final Object d(Object obj) {
        go.f0 f0Var = (go.f0) this.X;
        vi.a aVar = vi.a.f21252e;
        g6.y.I(obj);
        List<qk.b> list = (List) this.Y;
        float size = 0.0f;
        int i10 = 0;
        if (!list.isEmpty()) {
            float fFloatValue = 0.0f;
            for (qk.b bVar : list) {
                Float f = bVar.f17389e;
                fFloatValue += f != null ? f.floatValue() : 0.0f;
                Integer num = bVar.f17388d;
                if (num != null && num.intValue() == 2) {
                    i10 = 2;
                }
            }
            if (fFloatValue > 0.0f && i10 != 2) {
                i10 = 1;
            }
            size = fFloatValue / list.size();
            if (size == 100.0f) {
                i10 = 3;
            }
        }
        MovieInfoViewModel movieInfoViewModelN0 = f0Var.n0();
        kotlinx.coroutines.k.launch$default(androidx.lifecycle.r0.g(movieInfoViewModelN0), null, null, new tm.belet.films.presentation.viewmodel.n1(movieInfoViewModelN0, f0Var.G1, size, i10, null), 3, null);
        return qi.b0.f17350a;
    }

    private final Object e(Object obj) {
        String str;
        hm.t tVarB;
        go.r0 r0Var = (go.r0) this.X;
        ArrayList filterData = r0Var.f9277w1;
        hm.i iVar = (hm.i) this.Y;
        vi.a aVar = vi.a.f21252e;
        g6.y.I(obj);
        if (iVar != null) {
            hm.e eVar = iVar.f10228b;
            List<hm.d> list = iVar.f10227a;
            if (list != null) {
                for (hm.d dVar : list) {
                    if (dVar.f10211c.equals("tag")) {
                        r0Var.y1 = dVar;
                        dVar.f10212d = dVar.b();
                    } else {
                        filterData.add(dVar);
                        int size = filterData.size();
                        int i10 = 0;
                        while (i10 < size) {
                            Object obj2 = filterData.get(i10);
                            i10++;
                            hm.d dVar2 = (hm.d) obj2;
                            dVar2.f10212d = dVar2.b();
                        }
                    }
                }
            }
            if (eVar != null) {
                r0Var.f9278x1 = eVar;
                if (eVar.b() == null) {
                    ((ButtonLarge) r0Var.i0().f5286e).setButtonText(r0Var.x(R.string.by_default));
                } else {
                    ButtonLarge buttonLarge = (ButtonLarge) r0Var.i0().f5286e;
                    hm.e eVar2 = r0Var.f9278x1;
                    if (eVar2 == null || (tVarB = eVar2.b()) == null || (str = tVarB.f10265b) == null) {
                        str = _UrlKt.FRAGMENT_ENCODE_SET;
                    }
                    buttonLarge.setButtonText(str);
                }
                hm.e eVar3 = r0Var.f9278x1;
                if (eVar3 != null) {
                    eVar3.f10216d = eVar.b();
                }
                ((LinearLayout) r0Var.i0().f5287g).setVisibility(0);
            } else {
                ((LinearLayout) r0Var.i0().f5287g).setVisibility(8);
            }
            ((ButtonLarge) r0Var.i0().f5285d).setVisibility(0);
            if (r0Var.y1 != null) {
                ((LinearLayout) r0Var.i0().f).setVisibility(0);
                bo.r rVar = r0Var.f9276v1;
                if (rVar != null) {
                    rVar.f3759r0 = r0Var.y1;
                    rVar.f();
                }
            }
            ao.h hVar = r0Var.f9275u1;
            if (hVar != null) {
                kotlin.jvm.internal.q.g(filterData, "filterData");
                ArrayList arrayList = (ArrayList) hVar.f3295s0;
                arrayList.clear();
                arrayList.addAll(filterData);
                hVar.f();
            }
        }
        return qi.b0.f17350a;
    }

    /* JADX WARN: Code restructure failed: missing block: B:86:0x014e, code lost:
    
        if (kotlin.jvm.internal.q.c(r2 != null ? r2.f : null, "finished") != false) goto L87;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private final java.lang.Object f(java.lang.Object r21) {
        /*
            Method dump skipped, instruction units count: 450
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: a0.m0.f(java.lang.Object):java.lang.Object");
    }

    private final Object g(Object obj) {
        en.b bVar;
        go.z3 z3Var = (go.z3) this.X;
        tm.belet.films.presentation.viewmodel.h1 h1Var = (tm.belet.films.presentation.viewmodel.h1) this.Y;
        vi.a aVar = vi.a.f21252e;
        g6.y.I(obj);
        if (h1Var.f19795a) {
            ((RecyclerView) z3Var.h0().Z).setVisibility(0);
            ((RecyclerView) z3Var.h0().Y).setVisibility(8);
        } else if (mj.l.m0(h1Var.f19797c) && (bVar = h1Var.f19796b) != null) {
            List list = bVar.f7844a;
            if (list != null && !list.isEmpty()) {
                ao.c cVar = new ao.c(2, z3Var);
                RecyclerView recyclerView = (RecyclerView) z3Var.h0().Y;
                z3Var.o();
                recyclerView.setLayoutManager(new GridLayoutManager(z3Var.i0()));
                ((RecyclerView) z3Var.h0().Y).setAdapter(cVar);
                cVar.f3289r0 = list;
            }
            ((RecyclerView) z3Var.h0().Z).setVisibility(8);
            ((RecyclerView) z3Var.h0().Y).setVisibility(0);
        }
        return qi.b0.f17350a;
    }

    private final Object h(Object obj) {
        go.f4 f4Var = (go.f4) this.X;
        tm.belet.films.presentation.viewmodel.a aVar = (tm.belet.films.presentation.viewmodel.a) this.Y;
        vi.a aVar2 = vi.a.f21252e;
        g6.y.I(obj);
        boolean z5 = aVar.f19723a;
        String str = aVar.f19725c;
        if (z5) {
            dm.q qVar = f4Var.f9115q1;
            if (qVar != null) {
                qVar.f7126g.setVisibility(8);
                ((FrameLayout) qVar.h.Y).setVisibility(8);
                qVar.f7127i.setVisibility(0);
            }
        } else if (!mj.l.m0(str)) {
            dm.q qVar2 = f4Var.f9115q1;
            if (qVar2 != null) {
                qVar2.f7131m.setButtonIsLoading(false);
            }
            Integer num = aVar.f19726d;
            if (num != null && num.intValue() == 429) {
                go.f4.h0(f4Var, str);
            } else {
                dm.q qVar3 = f4Var.f9115q1;
                if (qVar3 != null) {
                    qVar3.f7126g.setVisibility(8);
                    qVar3.f7127i.setVisibility(8);
                    ((FrameLayout) qVar3.h.Y).setVisibility(0);
                }
            }
        } else if (aVar.f19724b != null) {
            dm.q qVar4 = f4Var.f9115q1;
            if (qVar4 != null) {
                ((FrameLayout) qVar4.h.Y).setVisibility(8);
                qVar4.f7127i.setVisibility(8);
                qVar4.f7126g.setVisibility(0);
            }
            if (f4Var.F()) {
                Context contextO = f4Var.o();
                Object systemService = contextO != null ? contextO.getSystemService("input_method") : null;
                kotlin.jvm.internal.q.e(systemService, "null cannot be cast to non-null type android.view.inputmethod.InputMethodManager");
                InputMethodManager inputMethodManager = (InputMethodManager) systemService;
                dm.q qVar5 = f4Var.f9115q1;
                if (qVar5 != null) {
                    qVar5.f7128j.setFocusable(true);
                }
                dm.q qVar6 = f4Var.f9115q1;
                if (qVar6 != null) {
                    qVar6.f7128j.setFocusableInTouchMode(true);
                }
                dm.q qVar7 = f4Var.f9115q1;
                if (qVar7 != null) {
                    qVar7.f7128j.requestFocus();
                }
                new Handler(Looper.getMainLooper()).postDelayed(new e7.o(inputMethodManager, f4Var, 18), 400L);
            }
        }
        return qi.b0.f17350a;
    }

    /* JADX WARN: Code duplicated, block: B:24:0x0078  */
    /* JADX WARN: Code duplicated, block: B:79:0x01d6  */
    private final Object i(Object obj) {
        sm.j jVar;
        sm.i iVar;
        sm.h hVar;
        String str;
        com.bumptech.glide.n nVarU;
        sm.j jVar2;
        sm.i iVar2;
        sm.h hVar2;
        go.t4 t4Var = (go.t4) this.X;
        tm.belet.films.presentation.viewmodel.q3 q3Var = (tm.belet.films.presentation.viewmodel.q3) this.Y;
        vi.a aVar = vi.a.f21252e;
        g6.y.I(obj);
        boolean z5 = q3Var.f19923a;
        String str2 = q3Var.f19925c;
        int i10 = 8;
        if (z5) {
            ((FrameLayout) t4Var.i0().f7139i).setVisibility(0);
            ((CoordinatorLayout) t4Var.i0().f7140j).setVisibility(8);
        } else if (mj.l.m0(str2)) {
            nm.f fVar = q3Var.f19924b;
            if (fVar != null) {
                nm.e eVar = fVar.f16003a;
                androidx.appcompat.app.j jVarJ = t4Var.j();
                Context applicationContext = jVarJ != null ? jVarJ.getApplicationContext() : null;
                ImageView imageView = t4Var.i0().f7136d;
                if (ro.g.s(t4Var.o())) {
                    if (eVar == null || (jVar2 = eVar.f16000c) == null || (iVar2 = jVar2.f18839c) == null || (hVar2 = iVar2.f18834b) == null) {
                        str = null;
                    } else {
                        str = hVar2.f18831b;
                    }
                } else if (eVar == null || (jVar = eVar.f16000c) == null || (iVar = jVar.f18840d) == null || (hVar = iVar.f18834b) == null) {
                    str = null;
                } else {
                    str = hVar.f18831b;
                }
                ro.g.B(applicationContext, imageView, str);
                String str3 = eVar != null ? eVar.f : null;
                if (str3 == null || mj.l.m0(str3)) {
                    t4Var.i0().f7134b.setVisibility(8);
                } else {
                    t4Var.i0().f7134b.setVisibility(0);
                    x8.l lVarB = com.bumptech.glide.b.b(t4Var.o());
                    lVarB.getClass();
                    e9.g.c(t4Var.o(), "You cannot start a load on a fragment before it is attached or after it is destroyed");
                    char[] cArr = e9.o.f7695a;
                    if (Looper.myLooper() == Looper.getMainLooper()) {
                        if (t4Var.j() != null) {
                            lVarB.X.c(t4Var.j());
                        }
                        androidx.fragment.app.b1 b1VarL = t4Var.l();
                        Context contextO = t4Var.o();
                        nVarU = lVarB.Y.u(contextO, com.bumptech.glide.b.a(contextO.getApplicationContext()), t4Var.f1854c1, b1VarL, t4Var.F());
                    } else {
                        nVarU = lVarB.b(t4Var.o().getApplicationContext());
                    }
                    ((com.bumptech.glide.l) ((com.bumptech.glide.l) nVarU.a().A(eVar.f).j(R.drawable.placeholder_image)).e(R.drawable.ic_setanta_sports)).w(t4Var.i0().f7135c);
                }
                ((TextView) t4Var.i0().f7145o).setText(eVar != null ? eVar.f15999b : null);
                ((LinearLayout) ((nh.c) t4Var.i0().f7142l).Z).setOnClickListener(new ao.a(t4Var, eVar, 14));
                go.h2 h2Var = new go.h2();
                Bundle bundle = new Bundle();
                Integer num = t4Var.f9340s1;
                if (num != null) {
                    bundle.putInt("tournament_id", num.intValue());
                }
                h2Var.f0(bundle);
                co.a aVar2 = t4Var.f9341t1;
                if (aVar2 == null) {
                    kotlin.jvm.internal.q.n("viewPagerAdapter");
                    throw null;
                }
                String strX = t4Var.x(R.string.matches);
                kotlin.jvm.internal.q.f(strX, "getString(...)");
                aVar2.z(h2Var, strX);
                ViewPager2 viewPager2 = (ViewPager2) t4Var.i0().f7146p;
                co.a aVar3 = t4Var.f9341t1;
                if (aVar3 == null) {
                    kotlin.jvm.internal.q.n("viewPagerAdapter");
                    throw null;
                }
                viewPager2.setAdapter(aVar3);
                ((ViewPager2) t4Var.i0().f7146p).setOffscreenPageLimit(4);
                androidx.recyclerview.widget.t0 adapter = viewPager2.getAdapter();
                co.a aVar4 = adapter instanceof co.a ? (co.a) adapter : null;
                if (aVar4 != null && aVar4.f4579y0.size() == 3) {
                    Context contextO2 = t4Var.o();
                    if (contextO2 == null) {
                        TabLayout tabLayout = (TabLayout) t4Var.i0().f7143m;
                        tabLayout.setTabGravity(0);
                        tabLayout.setTabMode(1);
                    } else {
                        Configuration configuration = contextO2.getResources().getConfiguration();
                        if ((configuration.screenLayout & 15) < 3 || configuration.smallestScreenWidthDp < 600) {
                            TabLayout tabLayout2 = (TabLayout) t4Var.i0().f7143m;
                            tabLayout2.setTabGravity(0);
                            tabLayout2.setTabMode(1);
                        }
                    }
                }
                new zd((TabLayout) t4Var.i0().f7143m, (ViewPager2) t4Var.i0().f7146p, new gd.y(i10, t4Var)).i();
                ((FrameLayout) t4Var.i0().f7139i).setVisibility(8);
                ((CoordinatorLayout) t4Var.i0().f7140j).startAnimation(AnimationUtils.loadAnimation(t4Var.o(), R.anim.alpha_anim_in_film));
                ((CoordinatorLayout) t4Var.i0().f7140j).setVisibility(0);
            }
        } else {
            oo.c.d(t4Var.o(), oo.l.ERROR, str2, null, (24 & 16) == 0);
            t4Var.h0();
        }
        return qi.b0.f17350a;
    }

    private final Object j(Object obj) {
        ho.e eVar = (ho.e) this.X;
        tm.belet.films.presentation.viewmodel.t2 t2Var = (tm.belet.films.presentation.viewmodel.t2) this.Y;
        vi.a aVar = vi.a.f21252e;
        g6.y.I(obj);
        Integer num = t2Var.f19956a;
        if (num != null && num.intValue() == 200) {
            SharedPreferences.Editor editor = d7.s.f6709c;
            if (editor == null) {
                kotlin.jvm.internal.q.n("editor");
                throw null;
            }
            editor.clear().apply();
            Context contextO = eVar.o();
            if (contextO != null) {
                contextO.startActivity(new Intent(contextO, (Class<?>) ActivityLoginRegister.class));
            }
            androidx.appcompat.app.j jVarJ = eVar.j();
            if (jVarJ != null) {
                jVarJ.finishAffinity();
            }
            androidx.appcompat.app.j jVarJ2 = eVar.j();
            if (jVarJ2 != null) {
                jVarJ2.finish();
            }
        } else if (num != null && num.intValue() == 0) {
            Toast.makeText(eVar.b0(), R.string.network_error, 0).show();
        }
        return qi.b0.f17350a;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r4v2 */
    /* JADX WARN: Type inference failed for: r4v3, types: [java.util.Collection] */
    /* JADX WARN: Type inference failed for: r4v5, types: [java.lang.Object, java.util.Collection] */
    /* JADX WARN: Type inference failed for: r4v9 */
    private final Object k(Object obj) {
        ho.q qVar = (ho.q) this.X;
        ArrayList arrayList = qVar.f10424z1;
        tm.belet.films.presentation.viewmodel.m0 m0Var = (tm.belet.films.presentation.viewmodel.m0) this.Y;
        vi.a aVar = vi.a.f21252e;
        g6.y.I(obj);
        boolean z5 = m0Var.f19853b;
        lm.b bVar = m0Var.f19852a;
        if (!z5 && mj.l.m0(m0Var.f19854c)) {
            Object obj2 = null;
            ?? r4 = bVar != null ? bVar.f14545a : 0;
            if (r4 != 0 && !r4.isEmpty()) {
                ArrayList arrayListB0 = ri.m.B0(bVar.f14545a);
                arrayList.clear();
                arrayList.add(new no.e());
                String strX = qVar.x(R.string.this_device);
                kotlin.jvm.internal.q.f(strX, "getString(...)");
                arrayList.add(new no.j(strX));
                int size = arrayListB0.size();
                int i10 = 0;
                while (i10 < size) {
                    Object obj3 = arrayListB0.get(i10);
                    i10++;
                    lm.a aVar2 = (lm.a) obj3;
                    if (kotlin.jvm.internal.q.c(aVar2 != null ? aVar2.f14541e : null, d7.s.f6710d)) {
                        obj2 = obj3;
                        break;
                    }
                }
                lm.a aVar3 = (lm.a) obj2;
                if (aVar3 != null) {
                    String str = aVar3.f14542g;
                    arrayList.add(new no.a(aVar3.f14539c, ro.g.g(aVar3.f14540d), aVar3.f14541e, ro.g.k(str), ro.g.l(str), ro.g.j(str), true, aVar3.f14544j));
                    arrayListB0.remove(aVar3);
                }
                if (!arrayListB0.isEmpty()) {
                    String strX2 = qVar.x(R.string.other_devices);
                    kotlin.jvm.internal.q.f(strX2, "getString(...)");
                    arrayList.add(new no.j(strX2));
                }
                ArrayList arrayList2 = new ArrayList();
                int size2 = arrayListB0.size();
                int i11 = 0;
                while (i11 < size2) {
                    Object obj4 = arrayListB0.get(i11);
                    i11++;
                    lm.a aVar4 = (lm.a) obj4;
                    if (aVar4 != null && aVar4.f14544j) {
                        arrayList2.add(obj4);
                    }
                }
                int size3 = arrayList2.size();
                int i12 = 0;
                while (i12 < size3) {
                    Object obj5 = arrayList2.get(i12);
                    i12++;
                    lm.a aVar5 = (lm.a) obj5;
                    if (aVar5 != null) {
                        String str2 = aVar5.f14542g;
                        arrayList.add(new no.a(aVar5.f14539c, ro.g.g(aVar5.f14540d), aVar5.f14541e, ro.g.k(str2), ro.g.l(str2), ro.g.j(str2), false, aVar5.f14544j));
                        arrayListB0.remove(aVar5);
                    }
                }
                int size4 = arrayListB0.size();
                int i13 = 0;
                while (i13 < size4) {
                    Object obj6 = arrayListB0.get(i13);
                    i13++;
                    lm.a aVar6 = (lm.a) obj6;
                    if (aVar6 != null) {
                        String str3 = aVar6.f14542g;
                        arrayList.add(new no.a(aVar6.f14539c, ro.g.g(aVar6.f14540d), aVar6.f14541e, ro.g.k(str3), ro.g.l(str3), ro.g.j(str3), false, aVar6.f14544j));
                    }
                }
                ((RecyclerView) qVar.i0().Y).setAdapter(new ao.h(qVar, arrayList, qVar.b0()));
                qVar.f10420u1 = bVar.f14547c;
            }
        }
        return qi.b0.f17350a;
    }

    private final Object l(Object obj) {
        ho.u uVar = (ho.u) this.X;
        y5.h hVar = (y5.h) this.Y;
        vi.a aVar = vi.a.f21252e;
        g6.y.I(obj);
        y5.z zVar = hVar.f22635a;
        if (((zVar instanceof y5.w) || (zVar instanceof y5.y)) && uVar.f10446s1 != null) {
            TextView emptyListText = (TextView) uVar.h0().X;
            kotlin.jvm.internal.q.f(emptyListText, "emptyListText");
            yn.o1 o1Var = uVar.f10446s1;
            kotlin.jvm.internal.q.d(o1Var);
            emptyListText.setVisibility(o1Var.c() < 1 ? 0 : 8);
        }
        FrameLayout loader = (FrameLayout) uVar.h0().Z;
        kotlin.jvm.internal.q.f(loader, "loader");
        loader.setVisibility(hVar.f22635a instanceof y5.x ? 0 : 8);
        return qi.b0.f17350a;
    }

    private final Object m(Object obj) {
        ho.e0 e0Var = (ho.e0) this.X;
        y5.h hVar = (y5.h) this.Y;
        vi.a aVar = vi.a.f21252e;
        g6.y.I(obj);
        y5.z zVar = hVar.f22635a;
        y5.z zVar2 = hVar.f22635a;
        if (zVar instanceof y5.y) {
            LinearLayout emptyListContainer = (LinearLayout) e0Var.h0().f516b;
            kotlin.jvm.internal.q.f(emptyListContainer, "emptyListContainer");
            yn.o1 o1Var = e0Var.f10324s1;
            if (o1Var == null) {
                kotlin.jvm.internal.q.n("adapterNotification");
                throw null;
            }
            emptyListContainer.setVisibility(o1Var.c() < 1 ? 0 : 8);
        }
        FrameLayout mainContainer = (FrameLayout) ((m7.e) e0Var.h0().f517c).Y;
        kotlin.jvm.internal.q.f(mainContainer, "mainContainer");
        mainContainer.setVisibility(zVar2 instanceof y5.w ? 0 : 8);
        LinearLayout notificationShimmer = (LinearLayout) e0Var.h0().f518d;
        kotlin.jvm.internal.q.f(notificationShimmer, "notificationShimmer");
        notificationShimmer.setVisibility(zVar2 instanceof y5.x ? 0 : 8);
        RecyclerView notificationsRv = (RecyclerView) e0Var.h0().f519e;
        kotlin.jvm.internal.q.f(notificationsRv, "notificationsRv");
        notificationsRv.setVisibility(zVar2 instanceof y5.x ? 8 : 0);
        return qi.b0.f17350a;
    }

    private final Object n(Object obj) {
        ho.i0 i0Var = (ho.i0) this.X;
        tm.belet.films.presentation.viewmodel.t tVar = (tm.belet.films.presentation.viewmodel.t) this.Y;
        vi.a aVar = vi.a.f21252e;
        g6.y.I(obj);
        boolean z5 = tVar.f19951b;
        bn.a aVar2 = tVar.f19950a;
        String str = tVar.f19952c;
        int i10 = 1;
        if (z5) {
            dm.l lVar = i0Var.f10348q1;
            if (lVar != null) {
                a4.n nVar = ((PrimaryButton) lVar.h).E0;
                ((TextView) nVar.f517c).setText(((TextView) nVar.f516b).getText());
            }
            dm.l lVar2 = i0Var.f10348q1;
            if (lVar2 != null) {
                ((PrimaryButton) lVar2.h).setState(xo.a.Z);
            }
            dm.l lVar3 = i0Var.f10348q1;
            if (lVar3 != null) {
                ((PrimaryButton) lVar3.h).setButtonIsLoading(true);
            }
            dm.l lVar4 = i0Var.f10348q1;
            if (lVar4 != null) {
                ((PrimaryButton) lVar4.h).setEnabled(false);
            }
            dm.l lVar5 = i0Var.f10348q1;
            if (lVar5 != null) {
                ((TextView) lVar5.f7039b).setVisibility(8);
            }
        } else if (!mj.l.m0(str)) {
            Integer num = tVar.f19953d;
            int iIntValue = num != null ? num.intValue() : 0;
            if (iIntValue == 1 || iIntValue == 2 || iIntValue == 5) {
                dm.l lVar6 = i0Var.f10348q1;
                if (lVar6 != null) {
                    ((TextView) lVar6.f7039b).setTextColor(i0Var.b0().getColor(R.color.dark_negative));
                }
                ho.i0.h0(i0Var);
            } else if (iIntValue == 21 || iIntValue == 24) {
                dm.l lVar7 = i0Var.f10348q1;
                if (lVar7 != null) {
                    ((TextView) lVar7.f7039b).setTextColor(i0Var.b0().getColor(R.color.dark_waiting));
                }
                ho.i0.h0(i0Var);
                dm.l lVar8 = i0Var.f10348q1;
                if (lVar8 != null) {
                    ((EditText) lVar8.f7040c).setEnabled(false);
                }
                androidx.appcompat.app.j jVarJ = i0Var.j();
                nb.d dVar = com.bumptech.glide.c.f4723a;
                View view = dVar != null ? dVar.T0 : null;
                if (jVarJ != null && view != null) {
                    Object systemService = jVarJ.getSystemService("input_method");
                    kotlin.jvm.internal.q.e(systemService, "null cannot be cast to non-null type android.view.inputmethod.InputMethodManager");
                    ((InputMethodManager) systemService).hideSoftInputFromWindow(view.getWindowToken(), 0);
                }
                dm.l lVar9 = i0Var.f10348q1;
                if (lVar9 != null) {
                    ((PrimaryButton) lVar9.f7043g).setEnabled(false);
                }
                dm.l lVar10 = i0Var.f10348q1;
                if (lVar10 != null) {
                    ((PrimaryButton) lVar10.f7043g).setButtonIsButtonEnable(false);
                }
            } else {
                dm.l lVar11 = i0Var.f10348q1;
                if (lVar11 != null) {
                    ((PrimaryButton) lVar11.h).setEnabled(true);
                }
                dm.l lVar12 = i0Var.f10348q1;
                if (lVar12 != null) {
                    a4.n nVar2 = ((PrimaryButton) lVar12.h).E0;
                    ((TextView) nVar2.f517c).setText(((TextView) nVar2.f516b).getText());
                }
                dm.l lVar13 = i0Var.f10348q1;
                if (lVar13 != null) {
                    ((PrimaryButton) lVar13.h).setState(xo.a.X);
                }
                dm.l lVar14 = i0Var.f10348q1;
                if (lVar14 != null) {
                    ((PrimaryButton) lVar14.h).setButtonIcon(Integer.valueOf(R.drawable.icon_try_again_3));
                }
                dm.l lVar15 = i0Var.f10348q1;
                if (lVar15 != null) {
                    ((PrimaryButton) lVar15.h).setButtonIsLoading(false);
                }
                dm.l lVar16 = i0Var.f10348q1;
                if (lVar16 != null) {
                    ((PrimaryButton) lVar16.h).setButtonBackgroundColor(i0Var.b0().getColor(R.color.dark_white));
                }
            }
            dm.l lVar17 = i0Var.f10348q1;
            if (lVar17 != null) {
                ((TextView) lVar17.f7039b).setText(str);
            }
            dm.l lVar18 = i0Var.f10348q1;
            if (lVar18 != null) {
                ((TextView) lVar18.f7039b).setVisibility(0);
            }
        } else if (aVar2 != null) {
            dm.l lVar19 = i0Var.f10348q1;
            if (lVar19 != null) {
                ((TextView) lVar19.f7039b).setVisibility(8);
            }
            if (i0Var.j() != null) {
                i0Var.l().g0("response_sheet_request_key", i0Var, new ho.g0(i0Var, i10));
                String strX = aVar2.f3735c;
                if (mj.l.m0(strX)) {
                    strX = i0Var.x(R.string.activated_title);
                    kotlin.jvm.internal.q.f(strX, "getString(...)");
                }
                String strX2 = aVar2.f3734b;
                if (mj.l.m0(strX2)) {
                    strX2 = i0Var.x(R.string.activated_subtitle);
                    kotlin.jvm.internal.q.f(strX2, "getString(...)");
                }
                eo.a2 a2Var = new eo.a2();
                Bundle bundle = new Bundle();
                bundle.putString("message_title", strX);
                bundle.putString("server_message", strX2);
                a2Var.f0(bundle);
                androidx.fragment.app.b1 b1VarL = i0Var.l();
                kotlin.jvm.internal.q.f(b1VarL, "getChildFragmentManager(...)");
                jd.t1.E(a2Var, b1VarL, a2Var.getClass().getName());
            }
        }
        return qi.b0.f17350a;
    }

    private final Object o(Object obj) {
        ho.p0 p0Var = (ho.p0) this.X;
        y4 y4Var = p0Var.f10408s1;
        vi.a aVar = vi.a.f21252e;
        g6.y.I(obj);
        String str = ((vf.l) this.Y).f21222a;
        kotlin.jvm.internal.q.f(str, "getText(...)");
        int i10 = 0;
        ui.d dVar = null;
        if (mj.l.c0(str, "film.belet.me", false)) {
            LoginViewModel loginViewModel = (LoginViewModel) y4Var.getValue();
            kotlin.jvm.internal.q.f(str, "getText(...)");
            kotlinx.coroutines.k.launch$default(androidx.lifecycle.r0.g(loginViewModel), null, null, new tm.belet.films.presentation.viewmodel.w0(loginViewModel, mj.t.W(str, "https://film.belet.me/register/", _UrlKt.FRAGMENT_ENCODE_SET, false), dVar, i10), 3, null);
        } else {
            kotlin.jvm.internal.q.f(str, "getText(...)");
            String strX = p0Var.x(R.string.belet_web_domain);
            kotlin.jvm.internal.q.f(strX, "getString(...)");
            if (mj.l.c0(str, strX, false)) {
                LoginViewModel loginViewModel2 = (LoginViewModel) y4Var.getValue();
                kotlin.jvm.internal.q.f(str, "getText(...)");
                kotlinx.coroutines.k.launch$default(androidx.lifecycle.r0.g(loginViewModel2), null, null, new tm.belet.films.presentation.viewmodel.w0(loginViewModel2, mj.t.W(str, p0.e.x("https://", p0Var.x(R.string.belet_web_domain), "/register/"), _UrlKt.FRAGMENT_ENCODE_SET, false), dVar, i10), 3, null);
            } else {
                ((CodeScannerView) p0Var.i0().f1422e).setVisibleFrame(false);
                ((LinearLayout) p0Var.i0().f1420c).setVisibility(0);
                ((TextView) p0Var.i0().f1418a).setText(p0Var.x(R.string.wrong_qr_code));
                ((LottieAnimationView) p0Var.i0().f1421d).setAnimation(R.raw.device_connect_error);
                ((LottieAnimationView) p0Var.i0().f1421d).setMinFrame(160);
                ((LottieAnimationView) p0Var.i0().f1421d).setMaxFrame(241);
                ((LottieAnimationView) p0Var.i0().f1421d).setRepeatCount(0);
                ((LottieAnimationView) p0Var.i0().f1421d).e();
                if (((PrimaryButton) p0Var.i0().f1423g).getVisibility() == 4) {
                    PrimaryButton primaryButton = (PrimaryButton) p0Var.i0().f1423g;
                    primaryButton.setVisibility(0);
                    ObjectAnimator objectAnimatorOfFloat = ObjectAnimator.ofFloat(primaryButton, "alpha", 0.0f, 1.0f);
                    objectAnimatorOfFloat.setDuration(200L);
                    objectAnimatorOfFloat.start();
                    ((PrimaryButton) p0Var.i0().f1423g).setEnabled(true);
                }
                p0Var.h0();
            }
        }
        return qi.b0.f17350a;
    }

    @Override // wi.a
    public final ui.d create(Object obj, ui.d dVar) {
        switch (this.f197e) {
            case 0:
                return new m0((i) this.Y, (z.c) this.X, dVar, 0);
            case 1:
                return new m0((n0) this.Y, (z.c) this.X, dVar, 1);
            case 2:
                return new m0((i3) this.Y, (b5) this.X, dVar, 2);
            case 3:
                return new m0((String) this.Y, (u1) this.X, dVar, 3);
            case 4:
                return new m0((b2) this.Y, (String) this.X, dVar, 4);
            case 5:
                m0 m0Var = new m0((androidx.lifecycle.q) this.X, dVar, 5);
                m0Var.Y = obj;
                return m0Var;
            case 6:
                return new m0((androidx.recyclerview.widget.q1) this.Y, (Bitmap) this.X, dVar, 6);
            case 7:
                m0 m0Var2 = new m0((a4.n) this.X, dVar, 7);
                m0Var2.Y = obj;
                return m0Var2;
            case 8:
                m0 m0Var3 = new m0((d6.d) this.X, dVar, 8);
                m0Var3.Y = obj;
                return m0Var3;
            case 9:
                m0 m0Var4 = new m0((eo.u) this.X, dVar, 9);
                m0Var4.Y = obj;
                return m0Var4;
            case 10:
                m0 m0Var5 = new m0((eo.d0) this.X, dVar, 10);
                m0Var5.Y = obj;
                return m0Var5;
            case ue.r.NETWORK_CLIENT_ERROR_REASON_FIELD_NUMBER /* 11 */:
                m0 m0Var6 = new m0((eo.h0) this.X, dVar, 11);
                m0Var6.Y = obj;
                return m0Var6;
            case ue.r.CUSTOM_ATTRIBUTES_FIELD_NUMBER /* 12 */:
                m0 m0Var7 = new m0((eo.r1) this.X, dVar, 12);
                m0Var7.Y = obj;
                return m0Var7;
            case ue.r.PERF_SESSIONS_FIELD_NUMBER /* 13 */:
                m0 m0Var8 = new m0((eo.f2) this.X, dVar, 13);
                m0Var8.Y = obj;
                return m0Var8;
            case 14:
                m0 m0Var9 = new m0((eo.i2) this.X, dVar, 14);
                m0Var9.Y = obj;
                return m0Var9;
            case WebSocketProtocol.B0_MASK_OPCODE /* 15 */:
                m0 m0Var10 = new m0((go.t) this.X, dVar, 15);
                m0Var10.Y = obj;
                return m0Var10;
            case WebSocketProtocol.B0_FLAG_RSV3 /* 16 */:
                m0 m0Var11 = new m0((go.w) this.X, dVar, 16);
                m0Var11.Y = obj;
                return m0Var11;
            case 17:
                return new m0((List) this.Y, (go.f0) this.X, dVar, 17);
            case 18:
                m0 m0Var12 = new m0((go.r0) this.X, dVar, 18);
                m0Var12.Y = obj;
                return m0Var12;
            case 19:
                m0 m0Var13 = new m0((go.h2) this.X, dVar, 19);
                m0Var13.Y = obj;
                return m0Var13;
            case 20:
                m0 m0Var14 = new m0((go.z3) this.X, dVar, 20);
                m0Var14.Y = obj;
                return m0Var14;
            case 21:
                m0 m0Var15 = new m0((go.f4) this.X, dVar, 21);
                m0Var15.Y = obj;
                return m0Var15;
            case 22:
                m0 m0Var16 = new m0((go.t4) this.X, dVar, 22);
                m0Var16.Y = obj;
                return m0Var16;
            case 23:
                m0 m0Var17 = new m0((ho.e) this.X, dVar, 23);
                m0Var17.Y = obj;
                return m0Var17;
            case 24:
                m0 m0Var18 = new m0((ho.q) this.X, dVar, 24);
                m0Var18.Y = obj;
                return m0Var18;
            case 25:
                m0 m0Var19 = new m0((ho.u) this.X, dVar, 25);
                m0Var19.Y = obj;
                return m0Var19;
            case 26:
                m0 m0Var20 = new m0((ho.e0) this.X, dVar, 26);
                m0Var20.Y = obj;
                return m0Var20;
            case 27:
                m0 m0Var21 = new m0((ho.i0) this.X, dVar, 27);
                m0Var21.Y = obj;
                return m0Var21;
            case 28:
                return new m0((vf.l) this.Y, (ho.p0) this.X, dVar, 28);
            default:
                m0 m0Var22 = new m0((ho.i1) this.X, dVar, 29);
                m0Var22.Y = obj;
                return m0Var22;
        }
    }

    @Override // ej.p
    public final Object invoke(Object obj, Object obj2) throws Exception {
        switch (this.f197e) {
            case 0:
                m0 m0Var = (m0) create((kotlinx.coroutines.p0) obj, (ui.d) obj2);
                qi.b0 b0Var = qi.b0.f17350a;
                m0Var.invokeSuspend(b0Var);
                return b0Var;
            case 1:
                m0 m0Var2 = (m0) create((kotlinx.coroutines.p0) obj, (ui.d) obj2);
                qi.b0 b0Var2 = qi.b0.f17350a;
                m0Var2.invokeSuspend(b0Var2);
                return b0Var2;
            case 2:
                m0 m0Var3 = (m0) create((kotlinx.coroutines.p0) obj, (ui.d) obj2);
                qi.b0 b0Var3 = qi.b0.f17350a;
                m0Var3.invokeSuspend(b0Var3);
                return b0Var3;
            case 3:
                return ((m0) create((kotlinx.coroutines.p0) obj, (ui.d) obj2)).invokeSuspend(qi.b0.f17350a);
            case 4:
                return ((m0) create((kotlinx.coroutines.p0) obj, (ui.d) obj2)).invokeSuspend(qi.b0.f17350a);
            case 5:
                m0 m0Var4 = (m0) create((kotlinx.coroutines.p0) obj, (ui.d) obj2);
                qi.b0 b0Var4 = qi.b0.f17350a;
                m0Var4.invokeSuspend(b0Var4);
                return b0Var4;
            case 6:
                m0 m0Var5 = (m0) create((kotlinx.coroutines.p0) obj, (ui.d) obj2);
                qi.b0 b0Var5 = qi.b0.f17350a;
                m0Var5.invokeSuspend(b0Var5);
                return b0Var5;
            case 7:
                m0 m0Var6 = (m0) create(obj, (ui.d) obj2);
                qi.b0 b0Var6 = qi.b0.f17350a;
                m0Var6.invokeSuspend(b0Var6);
                return b0Var6;
            case 8:
                ((m0) create((kotlinx.coroutines.p0) obj, (ui.d) obj2)).invokeSuspend(qi.b0.f17350a);
                throw null;
            case 9:
                m0 m0Var7 = (m0) create((qk.b) obj, (ui.d) obj2);
                qi.b0 b0Var7 = qi.b0.f17350a;
                m0Var7.invokeSuspend(b0Var7);
                return b0Var7;
            case 10:
                m0 m0Var8 = (m0) create((qk.a) obj, (ui.d) obj2);
                qi.b0 b0Var8 = qi.b0.f17350a;
                m0Var8.invokeSuspend(b0Var8);
                return b0Var8;
            case ue.r.NETWORK_CLIENT_ERROR_REASON_FIELD_NUMBER /* 11 */:
                m0 m0Var9 = (m0) create((tm.belet.films.presentation.viewmodel.r2) obj, (ui.d) obj2);
                qi.b0 b0Var9 = qi.b0.f17350a;
                m0Var9.invokeSuspend(b0Var9);
                return b0Var9;
            case ue.r.CUSTOM_ATTRIBUTES_FIELD_NUMBER /* 12 */:
                m0 m0Var10 = (m0) create((tm.belet.films.presentation.viewmodel.s0) obj, (ui.d) obj2);
                qi.b0 b0Var10 = qi.b0.f17350a;
                m0Var10.invokeSuspend(b0Var10);
                return b0Var10;
            case ue.r.PERF_SESSIONS_FIELD_NUMBER /* 13 */:
                m0 m0Var11 = (m0) create((tm.belet.films.presentation.viewmodel.y2) obj, (ui.d) obj2);
                qi.b0 b0Var11 = qi.b0.f17350a;
                m0Var11.invokeSuspend(b0Var11);
                return b0Var11;
            case 14:
                m0 m0Var12 = (m0) create((tm.belet.films.presentation.viewmodel.d3) obj, (ui.d) obj2);
                qi.b0 b0Var12 = qi.b0.f17350a;
                m0Var12.invokeSuspend(b0Var12);
                return b0Var12;
            case WebSocketProtocol.B0_MASK_OPCODE /* 15 */:
                m0 m0Var13 = (m0) create((List) obj, (ui.d) obj2);
                qi.b0 b0Var13 = qi.b0.f17350a;
                m0Var13.invokeSuspend(b0Var13);
                return b0Var13;
            case WebSocketProtocol.B0_FLAG_RSV3 /* 16 */:
                m0 m0Var14 = (m0) create((List) obj, (ui.d) obj2);
                qi.b0 b0Var14 = qi.b0.f17350a;
                m0Var14.invokeSuspend(b0Var14);
                return b0Var14;
            case 17:
                m0 m0Var15 = (m0) create((kotlinx.coroutines.p0) obj, (ui.d) obj2);
                qi.b0 b0Var15 = qi.b0.f17350a;
                m0Var15.invokeSuspend(b0Var15);
                return b0Var15;
            case 18:
                m0 m0Var16 = (m0) create((hm.i) obj, (ui.d) obj2);
                qi.b0 b0Var16 = qi.b0.f17350a;
                m0Var16.invokeSuspend(b0Var16);
                return b0Var16;
            case 19:
                m0 m0Var17 = (m0) create((tm.belet.films.presentation.viewmodel.k) obj, (ui.d) obj2);
                qi.b0 b0Var17 = qi.b0.f17350a;
                m0Var17.invokeSuspend(b0Var17);
                return b0Var17;
            case 20:
                m0 m0Var18 = (m0) create((tm.belet.films.presentation.viewmodel.h1) obj, (ui.d) obj2);
                qi.b0 b0Var18 = qi.b0.f17350a;
                m0Var18.invokeSuspend(b0Var18);
                return b0Var18;
            case 21:
                m0 m0Var19 = (m0) create((tm.belet.films.presentation.viewmodel.a) obj, (ui.d) obj2);
                qi.b0 b0Var19 = qi.b0.f17350a;
                m0Var19.invokeSuspend(b0Var19);
                return b0Var19;
            case 22:
                m0 m0Var20 = (m0) create((tm.belet.films.presentation.viewmodel.q3) obj, (ui.d) obj2);
                qi.b0 b0Var20 = qi.b0.f17350a;
                m0Var20.invokeSuspend(b0Var20);
                return b0Var20;
            case 23:
                m0 m0Var21 = (m0) create((tm.belet.films.presentation.viewmodel.t2) obj, (ui.d) obj2);
                qi.b0 b0Var21 = qi.b0.f17350a;
                m0Var21.invokeSuspend(b0Var21);
                return b0Var21;
            case 24:
                m0 m0Var22 = (m0) create((tm.belet.films.presentation.viewmodel.m0) obj, (ui.d) obj2);
                qi.b0 b0Var22 = qi.b0.f17350a;
                m0Var22.invokeSuspend(b0Var22);
                return b0Var22;
            case 25:
                m0 m0Var23 = (m0) create((y5.h) obj, (ui.d) obj2);
                qi.b0 b0Var23 = qi.b0.f17350a;
                m0Var23.invokeSuspend(b0Var23);
                return b0Var23;
            case 26:
                m0 m0Var24 = (m0) create((y5.h) obj, (ui.d) obj2);
                qi.b0 b0Var24 = qi.b0.f17350a;
                m0Var24.invokeSuspend(b0Var24);
                return b0Var24;
            case 27:
                m0 m0Var25 = (m0) create((tm.belet.films.presentation.viewmodel.t) obj, (ui.d) obj2);
                qi.b0 b0Var25 = qi.b0.f17350a;
                m0Var25.invokeSuspend(b0Var25);
                return b0Var25;
            case 28:
                m0 m0Var26 = (m0) create((kotlinx.coroutines.p0) obj, (ui.d) obj2);
                qi.b0 b0Var26 = qi.b0.f17350a;
                m0Var26.invokeSuspend(b0Var26);
                return b0Var26;
            default:
                m0 m0Var27 = (m0) create((tm.belet.films.presentation.viewmodel.l) obj, (ui.d) obj2);
                qi.b0 b0Var27 = qi.b0.f17350a;
                m0Var27.invokeSuspend(b0Var27);
                return b0Var27;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v208, types: [kotlinx.coroutines.flow.h0] */
    /* JADX WARN: Type inference failed for: r2v147 */
    /* JADX WARN: Type inference failed for: r2v148, types: [java.lang.CharSequence] */
    /* JADX WARN: Type inference failed for: r2v173, types: [java.lang.Object, java.util.List] */
    /* JADX WARN: Type inference failed for: r2v225 */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    @Override // wi.a
    public final Object invokeSuspend(Object obj) throws Exception {
        int i10;
        Throwable th2;
        int i11;
        String strX;
        String str;
        String str2;
        ColorModel colorModel;
        ColorModel colorModel2;
        um.c cVar;
        List<hm.d> list;
        Integer numE;
        int i12 = this.f197e;
        int i13 = 5;
        int i14 = 0;
        int iIntValue = 1;
        qi.b0 b0Var = qi.b0.f17350a;
        Object obj2 = this.X;
        switch (i12) {
            case 0:
                vi.a aVar = vi.a.f21252e;
                g6.y.I(obj);
                ((i) this.Y).E(((z.c) obj2).f23322a);
                return b0Var;
            case 1:
                vi.a aVar2 = vi.a.f21252e;
                g6.y.I(obj);
                Iterator it = ((n0) this.Y).f224e.iterator();
                kotlin.jvm.internal.q.f(it, "iterator(...)");
                while (it.hasNext()) {
                    ((h2) it.next()).E(((z.c) obj2).f23322a);
                }
                return b0Var;
            case 2:
                vi.a aVar3 = vi.a.f21252e;
                g6.y.I(obj);
                i3 i3Var = (i3) this.Y;
                if (i3Var != null) {
                    i3Var.o();
                }
                b5 b5Var = (b5) obj2;
                if (b5Var != null) {
                    b5Var.a(null);
                }
                return b0Var;
            case 3:
                vi.a aVar4 = vi.a.f21252e;
                g6.y.I(obj);
                String str3 = (String) this.Y;
                Log.d("CXCP", "Initializing CameraDeviceSetupCompat for " + ((Object) z.p.b(str3)));
                u1 u1Var = (u1) obj2;
                a2 a2Var = u1Var.f340c;
                try {
                    b1.e eVar = (b1.e) u1Var.f347l.getValue();
                    eVar.getClass();
                    ArrayList arrayList = new ArrayList();
                    b1.c cVar2 = eVar.f3367a;
                    if (cVar2 != null) {
                        arrayList.add(new b1.b(cVar2.f3366a, str3));
                    }
                    b1.c cVar3 = eVar.f3368b;
                    if (cVar3 != null) {
                        try {
                            arrayList.add(new b1.b(cVar3.f3366a, str3));
                            break;
                        } catch (UnsupportedOperationException unused) {
                        }
                    }
                    return new b1.a(arrayList);
                } catch (Exception e3) {
                    if (e3 instanceof CameraAccessException) {
                        Log.w("CXCP", "Failed to execute call: Camera encountered an error: " + e3.getMessage());
                        CameraAccessException cameraAccessException = (CameraAccessException) e3;
                        int reason = cameraAccessException.getReason();
                        if (reason == 1) {
                            i10 = 3;
                        } else if (reason == 2) {
                            i10 = 6;
                        } else if (reason == 3) {
                            i10 = 0;
                        } else if (reason == 4) {
                            i10 = 1;
                        } else if (reason != 5) {
                            Log.w("CXCP", "Unexpected CameraAccessException: " + cameraAccessException);
                            i10 = 11;
                        } else {
                            i10 = 2;
                        }
                        a2Var.a(str3, true, i10);
                    } else if ((e3 instanceof IllegalArgumentException) || (e3 instanceof SecurityException) || (e3 instanceof UnsupportedOperationException) || (e3 instanceof NullPointerException)) {
                        Log.w("CXCP", "Failed to execute call: Unexpected exception: " + e3.getMessage());
                        a2Var.a(str3, false, 9);
                    } else {
                        if (!(e3 instanceof IllegalStateException)) {
                            throw e3;
                        }
                        Log.d("CXCP", "Failed to execute call: Camera may be closed");
                    }
                    return null;
                }
            case 4:
                vi.a aVar5 = vi.a.f21252e;
                g6.y.I(obj);
                return ((b2) this.Y).e((String) obj2);
            case 5:
                vi.a aVar6 = vi.a.f21252e;
                g6.y.I(obj);
                kotlinx.coroutines.p0 p0Var = (kotlinx.coroutines.p0) this.Y;
                androidx.lifecycle.q qVar = (androidx.lifecycle.q) obj2;
                androidx.lifecycle.x xVar = qVar.f2037e;
                if (xVar.f2063d.compareTo(androidx.lifecycle.p.X) >= 0) {
                    xVar.a(qVar);
                } else {
                    kotlinx.coroutines.k2.cancel$default(p0Var.getCoroutineContext(), (CancellationException) null, 1, (Object) null);
                }
                return b0Var;
            case 6:
                vi.a aVar7 = vi.a.f21252e;
                g6.y.I(obj);
                ((ImageView) ((bo.c) ((androidx.recyclerview.widget.q1) this.Y)).f3740u.f15310e).setImageBitmap((Bitmap) obj2);
                return b0Var;
            case 7:
                vi.a aVar8 = vi.a.f21252e;
                g6.y.I(obj);
                a4.n nVar = (a4.n) obj2;
                ((ri.i) nVar.f).addLast(this.Y);
                for (Object objMo14tryReceivePtdJZtk = ((kotlinx.coroutines.channels.i) nVar.f519e).mo14tryReceivePtdJZtk(); kotlinx.coroutines.channels.n.m37isSuccessimpl(objMo14tryReceivePtdJZtk); objMo14tryReceivePtdJZtk = ((kotlinx.coroutines.channels.i) nVar.f519e).mo14tryReceivePtdJZtk()) {
                    ((ri.i) nVar.f).addLast(kotlinx.coroutines.channels.n.m33getOrThrowimpl(objMo14tryReceivePtdJZtk));
                }
                Log.d("CXCP", "PruningProcessingQueue: Pruning " + ((ri.i) nVar.f));
                ((ej.l) nVar.f515a).invoke((ri.i) nVar.f);
                return b0Var;
            case 8:
                vi.a aVar9 = vi.a.f21252e;
                g6.y.I(obj);
                throw null;
            case 9:
                qk.b bVar = (qk.b) this.Y;
                vi.a aVar10 = vi.a.f21252e;
                g6.y.I(obj);
                if (bVar != null) {
                    eo.u uVar = (eo.u) obj2;
                    dm.d dVar = uVar.G1;
                    if (dVar == null) {
                        kotlin.jvm.internal.q.n("binding");
                        throw null;
                    }
                    dVar.f6977g.setVisibility(8);
                    dm.d dVar2 = uVar.G1;
                    if (dVar2 == null) {
                        kotlin.jvm.internal.q.n("binding");
                        throw null;
                    }
                    ((LinearLayout) dVar2.f6978i).setVisibility(8);
                    dm.d dVar3 = uVar.G1;
                    if (dVar3 == null) {
                        kotlin.jvm.internal.q.n("binding");
                        throw null;
                    }
                    ((LinearLayout) dVar3.f6979j).setVisibility(8);
                    dm.d dVar4 = uVar.G1;
                    if (dVar4 == null) {
                        kotlin.jvm.internal.q.n("binding");
                        throw null;
                    }
                    ((LinearLayout) dVar4.f6981l).setVisibility(8);
                    dm.d dVar5 = uVar.G1;
                    if (dVar5 == null) {
                        kotlin.jvm.internal.q.n("binding");
                        throw null;
                    }
                    ((LinearLayout) dVar5.f6980k).setVisibility(8);
                    dm.d dVar6 = uVar.G1;
                    if (dVar6 == null) {
                        kotlin.jvm.internal.q.n("binding");
                        throw null;
                    }
                    ((LinearLayout) dVar6.f6982m).setVisibility(8);
                    dm.d dVar7 = uVar.G1;
                    if (dVar7 == null) {
                        kotlin.jvm.internal.q.n("binding");
                        throw null;
                    }
                    dVar7.f6973b.setVisibility(8);
                    dm.d dVar8 = uVar.G1;
                    if (dVar8 == null) {
                        kotlin.jvm.internal.q.n("binding");
                        throw null;
                    }
                    dVar8.f6975d.setVisibility(8);
                    dm.d dVar9 = uVar.G1;
                    if (dVar9 == null) {
                        kotlin.jvm.internal.q.n("binding");
                        throw null;
                    }
                    ((LinearLayout) dVar9.f6983n).setVisibility(8);
                    Integer num = bVar.f17388d;
                    Float f = bVar.f17389e;
                    if (num != null && num.intValue() == 0) {
                        float fFloatValue = f != null ? f.floatValue() : 0.0f;
                        if (fFloatValue > 0.0f) {
                            dm.d dVar10 = uVar.G1;
                            if (dVar10 == null) {
                                kotlin.jvm.internal.q.n("binding");
                                throw null;
                            }
                            ((DownloadStateView) dVar10.f6984o).setState(1);
                            dm.d dVar11 = uVar.G1;
                            if (dVar11 == null) {
                                kotlin.jvm.internal.q.n("binding");
                                throw null;
                            }
                            ((DownloadStateView) dVar11.f6984o).setProgress((int) fFloatValue);
                            dm.d dVar12 = uVar.G1;
                            if (dVar12 == null) {
                                kotlin.jvm.internal.q.n("binding");
                                throw null;
                            }
                            dVar12.h.setText(uVar.x(R.string.download_stopped));
                            dm.d dVar13 = uVar.G1;
                            if (dVar13 == null) {
                                kotlin.jvm.internal.q.n("binding");
                                throw null;
                            }
                            ((LinearLayout) dVar13.f6981l).setVisibility(0);
                        } else {
                            dm.d dVar14 = uVar.G1;
                            if (dVar14 == null) {
                                kotlin.jvm.internal.q.n("binding");
                                throw null;
                            }
                            dVar14.h.setText(uVar.x(R.string.download_on_queue));
                            dm.d dVar15 = uVar.G1;
                            if (dVar15 == null) {
                                kotlin.jvm.internal.q.n("binding");
                                throw null;
                            }
                            ((DownloadStateView) dVar15.f6984o).setState(6);
                        }
                        dm.d dVar16 = uVar.G1;
                        if (dVar16 == null) {
                            kotlin.jvm.internal.q.n("binding");
                            throw null;
                        }
                        dVar16.f6973b.setVisibility(0);
                    } else if (num != null && num.intValue() == 2) {
                        dm.d dVar17 = uVar.G1;
                        if (dVar17 == null) {
                            kotlin.jvm.internal.q.n("binding");
                            throw null;
                        }
                        ((DownloadStateView) dVar17.f6984o).setProgress(f != null ? (int) f.floatValue() : 0);
                        dm.d dVar18 = uVar.G1;
                        if (dVar18 == null) {
                            kotlin.jvm.internal.q.n("binding");
                            throw null;
                        }
                        ((DownloadStateView) dVar18.f6984o).setText((f != null ? Integer.valueOf((int) f.floatValue()) : null) + "%");
                        dm.d dVar19 = uVar.G1;
                        if (dVar19 == null) {
                            kotlin.jvm.internal.q.n("binding");
                            throw null;
                        }
                        ((DownloadStateView) dVar19.f6984o).setState(2);
                        dm.d dVar20 = uVar.G1;
                        if (dVar20 == null) {
                            kotlin.jvm.internal.q.n("binding");
                            throw null;
                        }
                        dVar20.h.setText(uVar.y(new Object[]{ro.g.e(bVar.f17396n + bVar.f17390g)}, R.string.downloading));
                        dm.d dVar21 = uVar.G1;
                        if (dVar21 == null) {
                            kotlin.jvm.internal.q.n("binding");
                            throw null;
                        }
                        ((LinearLayout) dVar21.f6980k).setVisibility(0);
                        dm.d dVar22 = uVar.G1;
                        if (dVar22 == null) {
                            kotlin.jvm.internal.q.n("binding");
                            throw null;
                        }
                        dVar22.f6973b.setVisibility(0);
                    } else if (num != null && num.intValue() == 3) {
                        dm.d dVar23 = uVar.G1;
                        if (dVar23 == null) {
                            kotlin.jvm.internal.q.n("binding");
                            throw null;
                        }
                        ((DownloadStateView) dVar23.f6984o).setState(3);
                        dm.d dVar24 = uVar.G1;
                        if (dVar24 == null) {
                            kotlin.jvm.internal.q.n("binding");
                            throw null;
                        }
                        dVar24.h.setText(uVar.x(R.string.exo_download_completed));
                        dm.d dVar25 = uVar.G1;
                        if (dVar25 == null) {
                            kotlin.jvm.internal.q.n("binding");
                            throw null;
                        }
                        dVar25.f6975d.setVisibility(0);
                    } else if (num != null && num.intValue() == 4) {
                        dm.d dVar26 = uVar.G1;
                        if (dVar26 == null) {
                            kotlin.jvm.internal.q.n("binding");
                            throw null;
                        }
                        ((DownloadStateView) dVar26.f6984o).setState(4);
                        dm.d dVar27 = uVar.G1;
                        if (dVar27 == null) {
                            kotlin.jvm.internal.q.n("binding");
                            throw null;
                        }
                        dVar27.h.setText(uVar.x(R.string.exo_download_failed));
                        dm.d dVar28 = uVar.G1;
                        if (dVar28 == null) {
                            kotlin.jvm.internal.q.n("binding");
                            throw null;
                        }
                        ((LinearLayout) dVar28.f6982m).setVisibility(0);
                        dm.d dVar29 = uVar.G1;
                        if (dVar29 == null) {
                            kotlin.jvm.internal.q.n("binding");
                            throw null;
                        }
                        dVar29.f6973b.setVisibility(0);
                    }
                }
                return b0Var;
            case 10:
                qk.a aVar11 = (qk.a) this.Y;
                vi.a aVar12 = vi.a.f21252e;
                g6.y.I(obj);
                if (aVar11 != null) {
                    eo.d0 d0Var = (eo.d0) obj2;
                    dm.d dVar30 = d0Var.G1;
                    if (dVar30 == null) {
                        kotlin.jvm.internal.q.n("binding");
                        throw null;
                    }
                    LinearLayout downloadFilmBtn = dVar30.f6977g;
                    kotlin.jvm.internal.q.f(downloadFilmBtn, "downloadFilmBtn");
                    downloadFilmBtn.setVisibility(8);
                    dm.d dVar31 = d0Var.G1;
                    if (dVar31 == null) {
                        kotlin.jvm.internal.q.n("binding");
                        throw null;
                    }
                    LinearLayout downloadLastEpisode = (LinearLayout) dVar31.f6978i;
                    kotlin.jvm.internal.q.f(downloadLastEpisode, "downloadLastEpisode");
                    downloadLastEpisode.setVisibility(8);
                    dm.d dVar32 = d0Var.G1;
                    if (dVar32 == null) {
                        kotlin.jvm.internal.q.n("binding");
                        throw null;
                    }
                    LinearLayout downloadSeasonBtn = (LinearLayout) dVar32.f6979j;
                    kotlin.jvm.internal.q.f(downloadSeasonBtn, "downloadSeasonBtn");
                    downloadSeasonBtn.setVisibility(8);
                    dm.d dVar33 = d0Var.G1;
                    if (dVar33 == null) {
                        kotlin.jvm.internal.q.n("binding");
                        throw null;
                    }
                    LinearLayout resumeDownloadsBtn = (LinearLayout) dVar33.f6981l;
                    kotlin.jvm.internal.q.f(resumeDownloadsBtn, "resumeDownloadsBtn");
                    resumeDownloadsBtn.setVisibility(8);
                    dm.d dVar34 = d0Var.G1;
                    if (dVar34 == null) {
                        kotlin.jvm.internal.q.n("binding");
                        throw null;
                    }
                    LinearLayout pauseDownloadsBtn = (LinearLayout) dVar34.f6980k;
                    kotlin.jvm.internal.q.f(pauseDownloadsBtn, "pauseDownloadsBtn");
                    pauseDownloadsBtn.setVisibility(8);
                    dm.d dVar35 = d0Var.G1;
                    if (dVar35 == null) {
                        kotlin.jvm.internal.q.n("binding");
                        throw null;
                    }
                    LinearLayout retryDownloadsBtn = (LinearLayout) dVar35.f6982m;
                    kotlin.jvm.internal.q.f(retryDownloadsBtn, "retryDownloadsBtn");
                    retryDownloadsBtn.setVisibility(8);
                    dm.d dVar36 = d0Var.G1;
                    if (dVar36 == null) {
                        kotlin.jvm.internal.q.n("binding");
                        throw null;
                    }
                    LinearLayout cancelDownloads = dVar36.f6973b;
                    kotlin.jvm.internal.q.f(cancelDownloads, "cancelDownloads");
                    cancelDownloads.setVisibility(8);
                    dm.d dVar37 = d0Var.G1;
                    if (dVar37 == null) {
                        kotlin.jvm.internal.q.n("binding");
                        throw null;
                    }
                    LinearLayout deleteDownload = dVar37.f6975d;
                    kotlin.jvm.internal.q.f(deleteDownload, "deleteDownload");
                    deleteDownload.setVisibility(8);
                    dm.d dVar38 = d0Var.G1;
                    if (dVar38 == null) {
                        kotlin.jvm.internal.q.n("binding");
                        throw null;
                    }
                    LinearLayout viewMyDownloadsBtn = (LinearLayout) dVar38.f6983n;
                    kotlin.jvm.internal.q.f(viewMyDownloadsBtn, "viewMyDownloadsBtn");
                    viewMyDownloadsBtn.setVisibility(8);
                    Integer num2 = aVar11.f17372d;
                    Float f10 = aVar11.f17373e;
                    if (num2 != null && num2.intValue() == 0) {
                        float fFloatValue2 = f10 != null ? f10.floatValue() : 0.0f;
                        if (fFloatValue2 > 0.0f) {
                            dm.d dVar39 = d0Var.G1;
                            if (dVar39 == null) {
                                kotlin.jvm.internal.q.n("binding");
                                throw null;
                            }
                            ((DownloadStateView) dVar39.f6984o).setState(1);
                            dm.d dVar40 = d0Var.G1;
                            if (dVar40 == null) {
                                kotlin.jvm.internal.q.n("binding");
                                throw null;
                            }
                            ((DownloadStateView) dVar40.f6984o).setProgress((int) fFloatValue2);
                            dm.d dVar41 = d0Var.G1;
                            if (dVar41 == null) {
                                kotlin.jvm.internal.q.n("binding");
                                throw null;
                            }
                            dVar41.h.setText(d0Var.x(R.string.download_stopped));
                            dm.d dVar42 = d0Var.G1;
                            if (dVar42 == null) {
                                kotlin.jvm.internal.q.n("binding");
                                throw null;
                            }
                            LinearLayout resumeDownloadsBtn2 = (LinearLayout) dVar42.f6981l;
                            kotlin.jvm.internal.q.f(resumeDownloadsBtn2, "resumeDownloadsBtn");
                            resumeDownloadsBtn2.setVisibility(0);
                        } else {
                            dm.d dVar43 = d0Var.G1;
                            if (dVar43 == null) {
                                kotlin.jvm.internal.q.n("binding");
                                throw null;
                            }
                            dVar43.h.setText(d0Var.x(R.string.download_on_queue));
                            dm.d dVar44 = d0Var.G1;
                            if (dVar44 == null) {
                                kotlin.jvm.internal.q.n("binding");
                                throw null;
                            }
                            ((DownloadStateView) dVar44.f6984o).setState(6);
                        }
                        dm.d dVar45 = d0Var.G1;
                        if (dVar45 == null) {
                            kotlin.jvm.internal.q.n("binding");
                            throw null;
                        }
                        LinearLayout cancelDownloads2 = dVar45.f6973b;
                        kotlin.jvm.internal.q.f(cancelDownloads2, "cancelDownloads");
                        cancelDownloads2.setVisibility(0);
                    } else if (num2 != null && num2.intValue() == 2) {
                        dm.d dVar46 = d0Var.G1;
                        if (dVar46 == null) {
                            kotlin.jvm.internal.q.n("binding");
                            throw null;
                        }
                        ((DownloadStateView) dVar46.f6984o).setProgress(f10 != null ? (int) f10.floatValue() : 0);
                        dm.d dVar47 = d0Var.G1;
                        if (dVar47 == null) {
                            kotlin.jvm.internal.q.n("binding");
                            throw null;
                        }
                        ((DownloadStateView) dVar47.f6984o).setText((f10 != null ? Integer.valueOf((int) f10.floatValue()) : null) + "%");
                        dm.d dVar48 = d0Var.G1;
                        if (dVar48 == null) {
                            kotlin.jvm.internal.q.n("binding");
                            throw null;
                        }
                        ((DownloadStateView) dVar48.f6984o).setState(2);
                        dm.d dVar49 = d0Var.G1;
                        if (dVar49 == null) {
                            kotlin.jvm.internal.q.n("binding");
                            throw null;
                        }
                        dVar49.h.setText(d0Var.x(R.string.exo_download_downloading));
                        dm.d dVar50 = d0Var.G1;
                        if (dVar50 == null) {
                            kotlin.jvm.internal.q.n("binding");
                            throw null;
                        }
                        LinearLayout pauseDownloadsBtn2 = (LinearLayout) dVar50.f6980k;
                        kotlin.jvm.internal.q.f(pauseDownloadsBtn2, "pauseDownloadsBtn");
                        pauseDownloadsBtn2.setVisibility(0);
                        dm.d dVar51 = d0Var.G1;
                        if (dVar51 == null) {
                            kotlin.jvm.internal.q.n("binding");
                            throw null;
                        }
                        LinearLayout cancelDownloads3 = dVar51.f6973b;
                        kotlin.jvm.internal.q.f(cancelDownloads3, "cancelDownloads");
                        cancelDownloads3.setVisibility(0);
                    } else if (num2 != null && num2.intValue() == 3) {
                        dm.d dVar52 = d0Var.G1;
                        if (dVar52 == null) {
                            kotlin.jvm.internal.q.n("binding");
                            throw null;
                        }
                        ((DownloadStateView) dVar52.f6984o).setState(3);
                        dm.d dVar53 = d0Var.G1;
                        if (dVar53 == null) {
                            kotlin.jvm.internal.q.n("binding");
                            throw null;
                        }
                        dVar53.h.setText(d0Var.x(R.string.exo_download_completed));
                        dm.d dVar54 = d0Var.G1;
                        if (dVar54 == null) {
                            kotlin.jvm.internal.q.n("binding");
                            throw null;
                        }
                        LinearLayout deleteDownload2 = dVar54.f6975d;
                        kotlin.jvm.internal.q.f(deleteDownload2, "deleteDownload");
                        deleteDownload2.setVisibility(0);
                    } else if (num2 != null && num2.intValue() == 4) {
                        dm.d dVar55 = d0Var.G1;
                        if (dVar55 == null) {
                            kotlin.jvm.internal.q.n("binding");
                            throw null;
                        }
                        ((DownloadStateView) dVar55.f6984o).setState(4);
                        dm.d dVar56 = d0Var.G1;
                        if (dVar56 == null) {
                            kotlin.jvm.internal.q.n("binding");
                            throw null;
                        }
                        dVar56.h.setText(d0Var.x(R.string.exo_download_failed));
                        dm.d dVar57 = d0Var.G1;
                        if (dVar57 == null) {
                            kotlin.jvm.internal.q.n("binding");
                            throw null;
                        }
                        LinearLayout retryDownloadsBtn2 = (LinearLayout) dVar57.f6982m;
                        kotlin.jvm.internal.q.f(retryDownloadsBtn2, "retryDownloadsBtn");
                        retryDownloadsBtn2.setVisibility(0);
                        dm.d dVar58 = d0Var.G1;
                        if (dVar58 == null) {
                            kotlin.jvm.internal.q.n("binding");
                            throw null;
                        }
                        LinearLayout cancelDownloads4 = dVar58.f6973b;
                        kotlin.jvm.internal.q.f(cancelDownloads4, "cancelDownloads");
                        cancelDownloads4.setVisibility(0);
                    }
                }
                return b0Var;
            case ue.r.NETWORK_CLIENT_ERROR_REASON_FIELD_NUMBER /* 11 */:
                eo.h0 h0Var = (eo.h0) obj2;
                tm.belet.films.presentation.viewmodel.r2 r2Var = (tm.belet.films.presentation.viewmodel.r2) this.Y;
                vi.a aVar13 = vi.a.f21252e;
                g6.y.I(obj);
                boolean z5 = r2Var.f19933a;
                an.g gVar = r2Var.f19934b;
                if (!z5) {
                    if (mj.l.m0(r2Var.f19935c)) {
                        if (gVar != null) {
                            String str4 = gVar.f925a;
                            Log.d("TAG_Prompts", "Pr: ".concat(str4));
                            Context contextO = h0Var.o();
                            dm.f fVar = h0Var.G1;
                            if (fVar == null) {
                                kotlin.jvm.internal.q.n("binding");
                                throw null;
                            }
                            ShapeableImageView shapeableImageView = (ShapeableImageView) fVar.f6998j;
                            String str5 = gVar.f927c;
                            String str6 = gVar.f;
                            ColoredUIComponentModel coloredUIComponentModel = gVar.f931i;
                            hm.m mVar = gVar.f930g;
                            if (contextO == null) {
                                th2 = null;
                            } else {
                                th2 = null;
                                if (!(contextO instanceof Activity) || !((Activity) contextO).isDestroyed()) {
                                    if (mj.l.m0(str5)) {
                                        shapeableImageView.setImageResource(R.color.black_second);
                                    } else {
                                        ((com.bumptech.glide.l) ((com.bumptech.glide.l) w.x0.o(contextO, contextO, str5, R.color.black_second)).e(R.color.black_second)).w(shapeableImageView);
                                    }
                                }
                            }
                            dm.f fVar2 = h0Var.G1;
                            if (fVar2 == null) {
                                kotlin.jvm.internal.q.n("binding");
                                throw th2;
                            }
                            AnimatedBorderCardView animatedBorderCardView = (AnimatedBorderCardView) fVar2.f6997i;
                            animatedBorderCardView.setCustomBorderWidth(1.0f);
                            animatedBorderCardView.setGradientColors(new int[]{Color.parseColor("#101011"), Color.parseColor("#D49BFF"), Color.parseColor("#FFDD8D"), Color.parseColor("#9BB8FF"), Color.parseColor("#101011")});
                            animatedBorderCardView.setGradientPositions(new float[]{0.0f, 0.3f, 0.59f, 0.72f, 1.0f});
                            animatedBorderCardView.setBorderAnimationEnabled(true);
                            dm.f fVar3 = h0Var.G1;
                            if (fVar3 == null) {
                                kotlin.jvm.internal.q.n("binding");
                                throw th2;
                            }
                            ((TextView) fVar3.f6992b).setText(str4);
                            dm.f fVar4 = h0Var.G1;
                            if (fVar4 == null) {
                                kotlin.jvm.internal.q.n("binding");
                                throw th2;
                            }
                            ((TextView) fVar4.f6999k).setText(gVar.f926b);
                            dm.f fVar5 = h0Var.G1;
                            if (fVar5 == null) {
                                kotlin.jvm.internal.q.n("binding");
                                throw th2;
                            }
                            nh.c cVar4 = (nh.c) fVar5.f;
                            ((TextView) cVar4.Z).setText(h0Var.x(R.string.gift_amount_text));
                            ((TextView) cVar4.X).setText(h0Var.y(new Object[]{gVar.f928d}, R.string.gift_amount));
                            dm.f fVar6 = h0Var.G1;
                            if (fVar6 == null) {
                                kotlin.jvm.internal.q.n("binding");
                                throw th2;
                            }
                            nh.c cVar5 = (nh.c) fVar6.h;
                            ((TextView) cVar5.Z).setText(h0Var.x(R.string.gift_sent_date));
                            ((TextView) cVar5.X).setText(gVar.f929e);
                            dm.f fVar7 = h0Var.G1;
                            if (fVar7 == null) {
                                kotlin.jvm.internal.q.n("binding");
                                throw th2;
                            }
                            nh.c cVar6 = (nh.c) fVar7.f6996g;
                            TextView textView = (TextView) cVar6.Z;
                            TextView textView2 = (TextView) cVar6.Y;
                            TextView textView3 = (TextView) cVar6.X;
                            textView.setText(h0Var.x(R.string.gift_sender));
                            ?? r4 = mVar != null ? mVar.f10238a : th2;
                            if (r4 == 0 || mj.l.m0(r4)) {
                                i11 = 0;
                                textView3.setVisibility(8);
                            } else {
                                i11 = 0;
                                textView3.setVisibility(0);
                                textView3.setText(mVar.f10238a);
                            }
                            textView2.setVisibility(i11);
                            textView2.setText(String.valueOf(mVar != null ? mVar.f10239b : th2));
                            if (mj.l.m0(str6)) {
                                dm.f fVar8 = h0Var.G1;
                                if (fVar8 == null) {
                                    kotlin.jvm.internal.q.n("binding");
                                    throw th2;
                                }
                                ((LinearLayout) fVar8.f6991a).setVisibility(8);
                            } else {
                                dm.f fVar9 = h0Var.G1;
                                if (fVar9 == null) {
                                    kotlin.jvm.internal.q.n("binding");
                                    throw th2;
                                }
                                ((LinearLayout) fVar9.f6991a).setVisibility(0);
                                dm.f fVar10 = h0Var.G1;
                                if (fVar10 == null) {
                                    kotlin.jvm.internal.q.n("binding");
                                    throw th2;
                                }
                                ((TextView) fVar10.f6993c).setText(str6);
                            }
                            dm.f fVar11 = h0Var.G1;
                            if (fVar11 == null) {
                                kotlin.jvm.internal.q.n("binding");
                                throw th2;
                            }
                            MaterialButton materialButton = (MaterialButton) fVar11.f7001m;
                            if (coloredUIComponentModel == null || (strX = coloredUIComponentModel.f19346e) == null) {
                                strX = h0Var.x(R.string.gift_done);
                                kotlin.jvm.internal.q.f(strX, "getString(...)");
                            }
                            materialButton.setText(strX);
                            if (coloredUIComponentModel == null || (colorModel2 = coloredUIComponentModel.Z) == null || (str = colorModel2.X) == null) {
                                str = "#F5F5F5";
                            }
                            materialButton.setBackgroundColor(ta.f.L(str));
                            if (coloredUIComponentModel == null || (colorModel = coloredUIComponentModel.Y) == null || (str2 = colorModel.X) == null) {
                                str2 = "#000000";
                            }
                            materialButton.setTextColor(ta.f.L(str2));
                        }
                    } else if (jd.t1.e(h0Var)) {
                        h0Var.o0();
                    }
                }
                return b0Var;
            case ue.r.CUSTOM_ATTRIBUTES_FIELD_NUMBER /* 12 */:
                eo.r1 r1Var = (eo.r1) obj2;
                tm.belet.films.presentation.viewmodel.s0 s0Var = (tm.belet.films.presentation.viewmodel.s0) this.Y;
                vi.a aVar14 = vi.a.f21252e;
                g6.y.I(obj);
                if (!s0Var.f19940a && mj.l.m0(s0Var.f19942c) && (cVar = s0Var.f19941b) != null) {
                    ?? r9 = cVar.f20846d;
                    Integer num3 = cVar.f20845c;
                    String str7 = cVar.f20844b;
                    String str8 = cVar.f20843a;
                    if (r9.isEmpty()) {
                        SharedPreferences.Editor editor = d7.s.f6709c;
                        if (editor == null) {
                            kotlin.jvm.internal.q.n("editor");
                            throw null;
                        }
                        editor.putString("token", str8).commit();
                        SharedPreferences.Editor editor2 = d7.s.f6709c;
                        if (editor2 == null) {
                            kotlin.jvm.internal.q.n("editor");
                            throw null;
                        }
                        editor2.putString("refresh_token", str7).commit();
                        iIntValue = num3 != null ? num3.intValue() : 1;
                        SharedPreferences.Editor editor3 = d7.s.f6709c;
                        if (editor3 == null) {
                            kotlin.jvm.internal.q.n("editor");
                            throw null;
                        }
                        editor3.putInt("current_app_mode", iIntValue).commit();
                        if (jd.t1.e(r1Var)) {
                            r1Var.o0();
                            r1Var.g0(new Intent(r1Var.j(), (Class<?>) SplashScreenActivity.class));
                            androidx.appcompat.app.j jVarJ = r1Var.j();
                            if (jVarJ != null) {
                                jVarJ.finish();
                            }
                        }
                    } else {
                        jd.t1.l(r1Var);
                        y6.a.t((zg.j) r1Var.o(), str8, str7, num3 != null ? num3.intValue() : 1);
                        r1Var.I1.getClass();
                        tm.belet.films.presentation.viewmodel.l3.f19848b.setValue(r9);
                    }
                }
                return b0Var;
            case ue.r.PERF_SESSIONS_FIELD_NUMBER /* 13 */:
                return b(obj);
            case 14:
                eo.i2 i2Var = (eo.i2) obj2;
                mo.f fVar12 = i2Var.I1;
                String str9 = i2Var.G1;
                tm.belet.films.presentation.viewmodel.d3 d3Var = (tm.belet.films.presentation.viewmodel.d3) this.Y;
                vi.a aVar15 = vi.a.f21252e;
                g6.y.I(obj);
                hm.i iVar = d3Var.f19759b;
                if (iVar != null && (list = iVar.f10227a) != null) {
                    for (hm.d dVar59 : list) {
                        if (dVar59.f10211c.equals(str9) && dVar59.f10209a != null) {
                            ((TextView) i2Var.q0().f8937c).setText(dVar59.f10210b);
                            i2Var.L1 = new yn.c(i2Var, dVar59, fVar12, i14);
                            RecyclerView recyclerView = (RecyclerView) i2Var.q0().f8936b;
                            yn.c cVar7 = i2Var.L1;
                            if (cVar7 == null) {
                                kotlin.jvm.internal.q.n("adapterBottomFilter");
                                throw null;
                            }
                            recyclerView.setAdapter(cVar7);
                        }
                    }
                }
                hm.i iVar2 = d3Var.f19759b;
                hm.e eVar2 = iVar2 != null ? iVar2.f10228b : null;
                if (kotlin.jvm.internal.q.c(eVar2 != null ? eVar2.f10215c : null, str9) && eVar2.f10213a != null) {
                    ((TextView) i2Var.q0().f8937c).setText(eVar2.f10214b);
                    i2Var.M1 = new yn.c(i2Var, eVar2, fVar12, iIntValue);
                    RecyclerView recyclerView2 = (RecyclerView) i2Var.q0().f8936b;
                    yn.c cVar8 = i2Var.M1;
                    if (cVar8 == null) {
                        kotlin.jvm.internal.q.n("adapterBottomSort");
                        throw null;
                    }
                    recyclerView2.setAdapter(cVar8);
                }
                return b0Var;
            case WebSocketProtocol.B0_MASK_OPCODE /* 15 */:
                List list2 = (List) this.Y;
                vi.a aVar16 = vi.a.f21252e;
                g6.y.I(obj);
                go.t tVar = (go.t) obj2;
                if (kotlin.jvm.internal.q.c(tVar.j0().f(), Boolean.FALSE) && (numE = com.bumptech.glide.d.e(tVar.b0())) != null) {
                    oo.c.e(tVar.o(), oo.l.ERROR, numE.intValue());
                    tVar.j0().h();
                }
                if (list2.isEmpty()) {
                    ((TextView) tVar.i0().f6802g).setVisibility(0);
                    ((ConstraintLayout) tVar.i0().f6801e).setVisibility(8);
                    if (tVar.y1 != 0) {
                        tVar.j0().i(String.valueOf(tVar.y1), String.valueOf(tVar.y1));
                    }
                } else {
                    ((TextView) tVar.i0().f6802g).setVisibility(8);
                    ((ConstraintLayout) tVar.i0().f6801e).setVisibility(0);
                    yn.h hVar = tVar.f9324r1;
                    if (hVar != null) {
                        if (hVar.f23172s0.isEmpty()) {
                            hVar.f23172s0 = ri.m.B0(list2);
                            hVar.f();
                        } else {
                            androidx.recyclerview.widget.o oVarE = androidx.recyclerview.widget.s.e(new po.a(hVar.f23172s0, list2, 0));
                            hVar.f23172s0 = ri.m.B0(list2);
                            oVarE.b(new w4(i13, hVar));
                        }
                    }
                    Integer num4 = ((qk.b) list2.get(0)).f17386b;
                    tVar.y1 = num4 != null ? num4.intValue() : 0;
                }
                tVar.f9329w1 = list2;
                return b0Var;
            case WebSocketProtocol.B0_FLAG_RSV3 /* 16 */:
                return c(obj);
            case 17:
                return d(obj);
            case 18:
                return e(obj);
            case 19:
                return f(obj);
            case 20:
                return g(obj);
            case 21:
                return h(obj);
            case 22:
                return i(obj);
            case 23:
                return j(obj);
            case 24:
                return k(obj);
            case 25:
                return l(obj);
            case 26:
                return m(obj);
            case 27:
                return n(obj);
            case 28:
                return o(obj);
            default:
                ho.i1 i1Var = (ho.i1) obj2;
                tm.belet.films.presentation.viewmodel.l lVar = (tm.belet.films.presentation.viewmodel.l) this.Y;
                vi.a aVar17 = vi.a.f21252e;
                g6.y.I(obj);
                boolean z6 = lVar.f19839a;
                String str10 = lVar.f19843e;
                if (z6) {
                    mf mfVar = i1Var.f10358q1;
                    if (mfVar == null) {
                        kotlin.jvm.internal.q.n("binding");
                        throw null;
                    }
                    MaterialButton materialButton2 = (MaterialButton) mfVar.f5285d;
                    Context contextB0 = i1Var.b0();
                    Integer num5 = new Integer(i1Var.f10361t1 ? R.color.neutral_100 : R.color.like_chinese_black);
                    yb.k kVar = new yb.k(contextB0, null, 0, R.style.CustomCircularIndicator);
                    kVar.f22871e = new int[]{contextB0.getColor(num5.intValue())};
                    int i15 = yb.r.D0;
                    materialButton2.setIcon(yb.r.g(contextB0, kVar, new yb.f(kVar)));
                    materialButton2.setText(_UrlKt.FRAGMENT_ENCODE_SET);
                    materialButton2.setEnabled(false);
                } else if (!mj.l.m0(str10)) {
                    mf mfVar2 = i1Var.f10358q1;
                    if (mfVar2 == null) {
                        kotlin.jvm.internal.q.n("binding");
                        throw null;
                    }
                    MaterialButton materialButton3 = (MaterialButton) mfVar2.f5285d;
                    p0.f.P(materialButton3, i1Var.f10361t1);
                    materialButton3.setEnabled(true);
                    oo.c.d(i1Var.b0(), oo.l.ERROR, str10, null, (24 & 16) == 0);
                } else if (lVar.f19841c != null) {
                    boolean z9 = lVar.f19840b;
                    i1Var.f10361t1 = z9;
                    mf mfVar3 = i1Var.f10358q1;
                    if (mfVar3 == null) {
                        kotlin.jvm.internal.q.n("binding");
                        throw null;
                    }
                    MaterialButton materialButton4 = (MaterialButton) mfVar3.f5285d;
                    p0.f.P(materialButton4, z9);
                    materialButton4.setEnabled(true);
                    androidx.fragment.app.b1 b1VarV = i1Var.v();
                    Bundle bundle = new Bundle();
                    bundle.putBoolean("notify_state", i1Var.f10361t1);
                    b1VarV.f0("main_event_sheet_request_key", bundle);
                }
                return b0Var;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ m0(Object obj, ui.d dVar, int i10) {
        super(2, dVar);
        this.f197e = i10;
        this.X = obj;
    }
}
