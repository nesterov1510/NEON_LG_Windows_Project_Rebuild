package a0;

import android.hardware.camera2.params.InputConfiguration;
import android.util.Log;
import android.view.Surface;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class v implements a3 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f356a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final d0.f0 f357b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final z.k f358c;

    public v(c0.n threads, d0.f0 f0Var, z.k graphConfig, int i10) {
        this.f356a = i10;
        switch (i10) {
            case 1:
                kotlin.jvm.internal.q.g(threads, "threads");
                kotlin.jvm.internal.q.g(graphConfig, "graphConfig");
                this.f357b = f0Var;
                this.f358c = graphConfig;
                break;
            default:
                kotlin.jvm.internal.q.g(threads, "threads");
                kotlin.jvm.internal.q.g(graphConfig, "graphConfig");
                this.f357b = f0Var;
                this.f358c = graphConfig;
                break;
        }
    }

    @Override // a0.a3
    public final z2 a(h2 cameraDevice, Map surfaces, i3 captureSessionState) {
        boolean zE0;
        switch (this.f356a) {
            case 0:
                kotlin.jvm.internal.q.g(cameraDevice, "cameraDevice");
                kotlin.jvm.internal.q.g(surfaces, "surfaces");
                kotlin.jvm.internal.q.g(captureSessionState, "captureSessionState");
                ArrayList arrayList = this.f358c.f23353d;
                x2 x2Var = x2.f381a;
                if (arrayList != null) {
                    z.x0 x0Var = (z.x0) ri.m.t0(((z.p0) ri.m.t0(arrayList)).f23382a.f23311a);
                    InputConfiguration inputConfiguration = new InputConfiguration(x0Var.f23404a.getWidth(), x0Var.f23404a.getHeight(), x0Var.f23405b);
                    ArrayList arrayList2 = new ArrayList(surfaces.size());
                    Iterator it = surfaces.entrySet().iterator();
                    while (it.hasNext()) {
                        arrayList2.add((Surface) ((Map.Entry) it.next()).getValue());
                    }
                    if (!cameraDevice.b0(inputConfiguration, arrayList2, captureSessionState)) {
                        Log.w("CXCP", "Failed to create reprocessable captures session from " + cameraDevice + " for " + captureSessionState + '!');
                        captureSessionState.a();
                        return x2Var;
                    }
                } else {
                    ArrayList arrayList3 = new ArrayList(surfaces.size());
                    Iterator it2 = surfaces.entrySet().iterator();
                    while (it2.hasNext()) {
                        arrayList3.add((Surface) ((Map.Entry) it2.next()).getValue());
                    }
                    if (!cameraDevice.X(arrayList3, captureSessionState)) {
                        Log.w("CXCP", "Failed to create captures session from " + cameraDevice + " for " + captureSessionState + '!');
                        captureSessionState.a();
                        return x2Var;
                    }
                }
                return new y2(ri.t.f18051e, b3.a(surfaces, this.f357b));
            default:
                kotlin.jvm.internal.q.g(cameraDevice, "cameraDevice");
                kotlin.jvm.internal.q.g(surfaces, "surfaces");
                kotlin.jvm.internal.q.g(captureSessionState, "captureSessionState");
                d0.f0 f0Var = this.f357b;
                z.k kVar = this.f358c;
                s3 s3VarB = b3.b(kVar, f0Var, surfaces);
                ArrayList arrayList4 = s3VarB.f320a;
                boolean zIsEmpty = arrayList4.isEmpty();
                x2 x2Var2 = x2.f381a;
                if (zIsEmpty) {
                    Log.w("CXCP", "Failed to create OutputConfigurations for " + kVar);
                    captureSessionState.a();
                    return x2Var2;
                }
                ArrayList arrayList5 = kVar.f23353d;
                if (arrayList5 == null) {
                    zE0 = cameraDevice.q0(arrayList4, captureSessionState);
                } else {
                    z.x0 x0Var2 = (z.x0) ri.m.t0(((z.p0) ri.m.t0(arrayList5)).f23382a.f23311a);
                    zE0 = cameraDevice.e0(new p3(x0Var2.f23404a.getWidth(), x0Var2.f23404a.getHeight(), x0Var2.f23405b), arrayList4, captureSessionState);
                }
                if (zE0) {
                    return new y2(ri.t.f18051e, s3VarB.f323d);
                }
                Log.w("CXCP", "Failed to create capture session from " + cameraDevice + " for " + captureSessionState + '!');
                captureSessionState.a();
                return x2Var2;
        }
    }
}
