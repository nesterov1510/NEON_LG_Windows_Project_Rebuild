package a0;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class v3 implements w3 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final d f367a;

    public v3(d dVar) {
        this.f367a = dVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof v3) && kotlin.jvm.internal.q.c(this.f367a, ((v3) obj).f367a);
    }

    public final int hashCode() {
        return this.f367a.hashCode();
    }

    public final String toString() {
        return "Success(activeCamera=" + this.f367a + ')';
    }
}
