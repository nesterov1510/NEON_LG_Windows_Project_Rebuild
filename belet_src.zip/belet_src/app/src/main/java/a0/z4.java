package a0;

import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.TotalCaptureResult;
import android.hardware.camera2.params.InputConfiguration;
import android.util.Log;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class z4 implements h2 {
    public final Object X = new Object();
    public boolean Y;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final i f400e;

    public z4(i iVar) {
        this.f400e = iVar;
    }

    @Override // a0.h2
    public final CaptureRequest.Builder C(TotalCaptureResult totalCaptureResult) {
        CaptureRequest.Builder builderC;
        synchronized (this.X) {
            try {
                if (this.Y) {
                    Log.w("CXCP", "createReprocessCaptureRequest failed: Virtual device disconnected");
                    builderC = null;
                } else {
                    builderC = this.f400e.C(totalCaptureResult);
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
        return builderC;
    }

    @Override // z.o1
    public final Object D(kotlin.jvm.internal.h hVar) {
        return this.f400e.D(hVar);
    }

    @Override // a0.h2
    public final void E(int i10) {
        this.f400e.E(i10);
    }

    @Override // a0.h2
    public final boolean F(ArrayList arrayList, f2 stateCallback) {
        boolean zF;
        kotlin.jvm.internal.q.g(stateCallback, "stateCallback");
        synchronized (this.X) {
            try {
                if (this.Y) {
                    Log.w("CXCP", "createConstrainedHighSpeedCaptureSession failed: Virtual device disconnected");
                    ((i3) stateCallback).a();
                    zF = false;
                } else {
                    zF = this.f400e.F(arrayList, stateCallback);
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
        return zF;
    }

    @Override // a0.h2
    public final void K() {
        this.f400e.K();
    }

    @Override // a0.h2
    public final CaptureRequest.Builder T(int i10) {
        CaptureRequest.Builder builderT;
        synchronized (this.X) {
            try {
                if (this.Y) {
                    Log.w("CXCP", "createCaptureRequest failed: Virtual device disconnected");
                    builderT = null;
                } else {
                    builderT = this.f400e.T(i10);
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
        return builderT;
    }

    @Override // a0.h2
    public final boolean X(List list, f2 stateCallback) {
        boolean zX;
        kotlin.jvm.internal.q.g(stateCallback, "stateCallback");
        synchronized (this.X) {
            try {
                if (this.Y) {
                    Log.w("CXCP", "createCaptureSession failed: Virtual device disconnected");
                    stateCallback.a();
                    zX = false;
                } else {
                    zX = this.f400e.X(list, stateCallback);
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
        return zX;
    }

    public final void a() {
        synchronized (this.X) {
            this.Y = true;
        }
    }

    @Override // a0.h2
    public final boolean b0(InputConfiguration inputConfiguration, ArrayList arrayList, f2 stateCallback) {
        boolean zB0;
        kotlin.jvm.internal.q.g(stateCallback, "stateCallback");
        synchronized (this.X) {
            try {
                if (this.Y) {
                    Log.w("CXCP", "createReprocessableCaptureSession failed: Virtual device disconnected");
                    ((i3) stateCallback).a();
                    zB0 = false;
                } else {
                    zB0 = this.f400e.b0(inputConfiguration, arrayList, stateCallback);
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
        return zB0;
    }

    @Override // a0.h2
    public final boolean e0(p3 p3Var, ArrayList arrayList, f2 stateCallback) {
        boolean zE0;
        kotlin.jvm.internal.q.g(stateCallback, "stateCallback");
        synchronized (this.X) {
            try {
                if (this.Y) {
                    Log.w("CXCP", "createReprocessableCaptureSessionByConfigurations failed: Virtual device disconnected");
                    ((i3) stateCallback).a();
                    zE0 = false;
                } else {
                    zE0 = this.f400e.e0(p3Var, arrayList, stateCallback);
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
        return zE0;
    }

    @Override // a0.h2
    public final void i0() {
        this.f400e.i0();
    }

    @Override // a0.h2
    public final boolean q0(ArrayList arrayList, f2 stateCallback) {
        boolean zQ0;
        kotlin.jvm.internal.q.g(stateCallback, "stateCallback");
        synchronized (this.X) {
            try {
                if (this.Y) {
                    Log.w("CXCP", "createCaptureSessionByOutputConfigurations failed: Virtual device disconnected");
                    ((i3) stateCallback).a();
                    zQ0 = false;
                } else {
                    zQ0 = this.f400e.q0(arrayList, stateCallback);
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
        return zQ0;
    }

    @Override // a0.h2
    public final boolean t(t4 t4Var) {
        boolean zT;
        synchronized (this.X) {
            try {
                if (this.Y) {
                    Log.w("CXCP", "createCaptureSession failed: Virtual device disconnected");
                    t4Var.f334e.a();
                    zT = false;
                } else {
                    zT = this.f400e.t(t4Var);
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
        return zT;
    }

    @Override // a0.h2
    public final boolean v(n3 n3Var) {
        boolean zV;
        synchronized (this.X) {
            try {
                if (this.Y) {
                    Log.w("CXCP", "createExtensionSession failed: Virtual device disconnected");
                    n3Var.f232g.a();
                    zV = false;
                } else {
                    zV = this.f400e.v(n3Var);
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
        return zV;
    }

    @Override // a0.h2
    public final String y() {
        return this.f400e.Y;
    }
}
