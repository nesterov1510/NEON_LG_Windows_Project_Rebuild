package a0;

import java.util.Map;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public interface a3 {
    z2 a(h2 h2Var, Map map, i3 i3Var);
}
