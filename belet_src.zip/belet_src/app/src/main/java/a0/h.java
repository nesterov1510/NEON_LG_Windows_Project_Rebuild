package a0;

import android.hardware.camera2.CameraConstrainedHighSpeedCaptureSession;
import android.os.Handler;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class h extends g {

    /* JADX INFO: renamed from: r0, reason: collision with root package name */
    public final CameraConstrainedHighSpeedCaptureSession f95r0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public h(i device, CameraConstrainedHighSpeedCaptureSession cameraConstrainedHighSpeedCaptureSession, a2 cameraErrorListener, Handler callbackHandler) {
        super(device, cameraConstrainedHighSpeedCaptureSession, cameraErrorListener, callbackHandler);
        kotlin.jvm.internal.q.g(device, "device");
        kotlin.jvm.internal.q.g(cameraErrorListener, "cameraErrorListener");
        kotlin.jvm.internal.q.g(callbackHandler, "callbackHandler");
        this.f95r0 = cameraConstrainedHighSpeedCaptureSession;
    }

    @Override // a0.g, z.o1
    public final Object D(kotlin.jvm.internal.h hVar) {
        return hVar.equals(kotlin.jvm.internal.e0.a(CameraConstrainedHighSpeedCaptureSession.class)) ? this.f95r0 : super.D(hVar);
    }
}
