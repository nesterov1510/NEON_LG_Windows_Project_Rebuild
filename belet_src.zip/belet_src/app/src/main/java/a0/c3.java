package a0;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class c3 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final g2 f32a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final d0.v f33b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final o1 f34c;

    public c3(g2 session, d0.v vVar, o1 o1Var) {
        kotlin.jvm.internal.q.g(session, "session");
        this.f32a = session;
        this.f33b = vVar;
        this.f34c = o1Var;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof c3)) {
            return false;
        }
        c3 c3Var = (c3) obj;
        return kotlin.jvm.internal.q.c(this.f32a, c3Var.f32a) && kotlin.jvm.internal.q.c(this.f33b, c3Var.f33b) && kotlin.jvm.internal.q.c(this.f34c, c3Var.f34c);
    }

    public final int hashCode() {
        int iHashCode = (this.f33b.hashCode() + (this.f32a.hashCode() * 31)) * 31;
        o1 o1Var = this.f34c;
        return iHashCode + (o1Var == null ? 0 : o1Var.hashCode());
    }

    public final String toString() {
        return "ConfiguredCameraCaptureSession(session=" + this.f32a + ", processor=" + this.f33b + ", captureSequenceProcessor=" + this.f34c + ')';
    }
}
