package a0;

import android.hardware.camera2.CaptureResult;
import android.hardware.camera2.TotalCaptureResult;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class t implements z.r0, z.o1 {
    public final String X;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final CaptureResult f325e;

    public t(CaptureResult captureResult, String camera) {
        kotlin.jvm.internal.q.g(captureResult, "captureResult");
        kotlin.jvm.internal.q.g(camera, "camera");
        this.f325e = captureResult;
        this.X = camera;
    }

    @Override // z.o1
    public final Object D(kotlin.jvm.internal.h hVar) {
        boolean zEquals = hVar.equals(kotlin.jvm.internal.e0.a(CaptureResult.class));
        CaptureResult captureResult = this.f325e;
        if (zEquals) {
            kotlin.jvm.internal.q.e(captureResult, "null cannot be cast to non-null type T of androidx.camera.camera2.pipe.compat.AndroidFrameMetadata.unwrapAs");
            return captureResult;
        }
        if (!hVar.equals(kotlin.jvm.internal.e0.a(TotalCaptureResult.class)) || captureResult == null) {
            return null;
        }
        return captureResult;
    }

    public final Object c(CaptureResult.Key key) {
        kotlin.jvm.internal.q.g(key, "key");
        return this.f325e.get(key);
    }

    public final String toString() {
        return "FrameMetadata(camera: " + ((Object) z.p.b(this.X)) + ", frameNumber: " + this.f325e.getFrameNumber() + ')';
    }
}
