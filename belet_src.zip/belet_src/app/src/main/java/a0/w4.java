package a0;

import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.internal.measurement.zd;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.google.common.util.concurrent.ListenableFuture;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.RandomAccess;
import java.util.TreeMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import tm.belet.films.R;
import tm.belet.films.domain.background.PlaybackService;
import tm.belet.films.presentation.widgets.RippleFrameLayout;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class w4 implements m.u, androidx.appcompat.widget.r, androidx.recyclerview.widget.i0, androidx.recyclerview.widget.b2, r0.c, cb.r0, ac.a, androidx.media3.session.t2, ga.c {
    public Object X;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f375e;

    public w4(int i10) {
        this.f375e = i10;
        switch (i10) {
            case 27:
                this.X = new LinkedHashMap();
                break;
            case 29:
                this.X = new gb.p();
                break;
        }
    }

    public static void w(q6.c cVar) {
        cVar.r("CREATE TABLE IF NOT EXISTS `Dependency` (`work_spec_id` TEXT NOT NULL, `prerequisite_id` TEXT NOT NULL, PRIMARY KEY(`work_spec_id`, `prerequisite_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE , FOREIGN KEY(`prerequisite_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
        cVar.r("CREATE INDEX IF NOT EXISTS `index_Dependency_work_spec_id` ON `Dependency` (`work_spec_id`)");
        cVar.r("CREATE INDEX IF NOT EXISTS `index_Dependency_prerequisite_id` ON `Dependency` (`prerequisite_id`)");
        cVar.r("CREATE TABLE IF NOT EXISTS `WorkSpec` (`id` TEXT NOT NULL, `state` INTEGER NOT NULL, `worker_class_name` TEXT NOT NULL, `input_merger_class_name` TEXT, `input` BLOB NOT NULL, `output` BLOB NOT NULL, `initial_delay` INTEGER NOT NULL, `interval_duration` INTEGER NOT NULL, `flex_duration` INTEGER NOT NULL, `run_attempt_count` INTEGER NOT NULL, `backoff_policy` INTEGER NOT NULL, `backoff_delay_duration` INTEGER NOT NULL, `last_enqueue_time` INTEGER NOT NULL, `minimum_retention_duration` INTEGER NOT NULL, `schedule_requested_at` INTEGER NOT NULL, `run_in_foreground` INTEGER NOT NULL, `out_of_quota_policy` INTEGER NOT NULL, `period_count` INTEGER NOT NULL DEFAULT 0, `generation` INTEGER NOT NULL DEFAULT 0, `required_network_type` INTEGER NOT NULL, `requires_charging` INTEGER NOT NULL, `requires_device_idle` INTEGER NOT NULL, `requires_battery_not_low` INTEGER NOT NULL, `requires_storage_not_low` INTEGER NOT NULL, `trigger_content_update_delay` INTEGER NOT NULL, `trigger_max_content_delay` INTEGER NOT NULL, `content_uri_triggers` BLOB NOT NULL, PRIMARY KEY(`id`))");
        cVar.r("CREATE INDEX IF NOT EXISTS `index_WorkSpec_schedule_requested_at` ON `WorkSpec` (`schedule_requested_at`)");
        cVar.r("CREATE INDEX IF NOT EXISTS `index_WorkSpec_last_enqueue_time` ON `WorkSpec` (`last_enqueue_time`)");
        cVar.r("CREATE TABLE IF NOT EXISTS `WorkTag` (`tag` TEXT NOT NULL, `work_spec_id` TEXT NOT NULL, PRIMARY KEY(`tag`, `work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
        cVar.r("CREATE INDEX IF NOT EXISTS `index_WorkTag_work_spec_id` ON `WorkTag` (`work_spec_id`)");
        cVar.r("CREATE TABLE IF NOT EXISTS `SystemIdInfo` (`work_spec_id` TEXT NOT NULL, `generation` INTEGER NOT NULL DEFAULT 0, `system_id` INTEGER NOT NULL, PRIMARY KEY(`work_spec_id`, `generation`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
        cVar.r("CREATE TABLE IF NOT EXISTS `WorkName` (`name` TEXT NOT NULL, `work_spec_id` TEXT NOT NULL, PRIMARY KEY(`name`, `work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
        cVar.r("CREATE INDEX IF NOT EXISTS `index_WorkName_work_spec_id` ON `WorkName` (`work_spec_id`)");
        cVar.r("CREATE TABLE IF NOT EXISTS `WorkProgress` (`work_spec_id` TEXT NOT NULL, `progress` BLOB NOT NULL, PRIMARY KEY(`work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
        cVar.r("CREATE TABLE IF NOT EXISTS `Preference` (`key` TEXT NOT NULL, `long_value` INTEGER, PRIMARY KEY(`key`))");
        cVar.r("CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)");
        cVar.r("INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, '5181942b9ebc31ce68dacb56c16fd79f')");
    }

    public static w4 x(LayoutInflater layoutInflater, ViewGroup viewGroup) {
        View viewInflate = layoutInflater.inflate(R.layout.item_film_loader, viewGroup, false);
        int i10 = R.id.image;
        if (((ImageView) fk.j.l(viewInflate, R.id.image)) != null) {
            i10 = R.id.progress;
            if (((ProgressBar) fk.j.l(viewInflate, R.id.progress)) != null) {
                return new w4(19, (MaterialCardView) viewInflate);
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i10)));
    }

    public static g6.a0 z(q6.c cVar) {
        HashMap map = new HashMap(2);
        map.put("work_spec_id", new l6.k(1, 1, "work_spec_id", "TEXT", null, true));
        map.put("prerequisite_id", new l6.k(2, 1, "prerequisite_id", "TEXT", null, true));
        HashSet hashSet = new HashSet(2);
        hashSet.add(new l6.l("WorkSpec", "CASCADE", "CASCADE", Arrays.asList("work_spec_id"), Arrays.asList("id")));
        hashSet.add(new l6.l("WorkSpec", "CASCADE", "CASCADE", Arrays.asList("prerequisite_id"), Arrays.asList("id")));
        HashSet hashSet2 = new HashSet(2);
        hashSet2.add(new l6.m("index_Dependency_work_spec_id", false, Arrays.asList("work_spec_id"), Arrays.asList("ASC")));
        hashSet2.add(new l6.m("index_Dependency_prerequisite_id", false, Arrays.asList("prerequisite_id"), Arrays.asList("ASC")));
        l6.n nVar = new l6.n("Dependency", map, hashSet, hashSet2);
        l6.n nVarA = l6.n.a(cVar, "Dependency");
        if (!nVar.equals(nVarA)) {
            return new g6.a0(false, "Dependency(androidx.work.impl.model.Dependency).\n Expected:\n" + nVar + "\n Found:\n" + nVarA, 1);
        }
        HashMap map2 = new HashMap(27);
        map2.put("id", new l6.k(1, 1, "id", "TEXT", null, true));
        map2.put("state", new l6.k(0, 1, "state", "INTEGER", null, true));
        map2.put("worker_class_name", new l6.k(0, 1, "worker_class_name", "TEXT", null, true));
        map2.put("input_merger_class_name", new l6.k(0, 1, "input_merger_class_name", "TEXT", null, false));
        map2.put("input", new l6.k(0, 1, "input", "BLOB", null, true));
        map2.put("output", new l6.k(0, 1, "output", "BLOB", null, true));
        map2.put("initial_delay", new l6.k(0, 1, "initial_delay", "INTEGER", null, true));
        map2.put("interval_duration", new l6.k(0, 1, "interval_duration", "INTEGER", null, true));
        map2.put("flex_duration", new l6.k(0, 1, "flex_duration", "INTEGER", null, true));
        map2.put("run_attempt_count", new l6.k(0, 1, "run_attempt_count", "INTEGER", null, true));
        map2.put("backoff_policy", new l6.k(0, 1, "backoff_policy", "INTEGER", null, true));
        map2.put("backoff_delay_duration", new l6.k(0, 1, "backoff_delay_duration", "INTEGER", null, true));
        map2.put("last_enqueue_time", new l6.k(0, 1, "last_enqueue_time", "INTEGER", null, true));
        map2.put("minimum_retention_duration", new l6.k(0, 1, "minimum_retention_duration", "INTEGER", null, true));
        map2.put("schedule_requested_at", new l6.k(0, 1, "schedule_requested_at", "INTEGER", null, true));
        map2.put("run_in_foreground", new l6.k(0, 1, "run_in_foreground", "INTEGER", null, true));
        map2.put("out_of_quota_policy", new l6.k(0, 1, "out_of_quota_policy", "INTEGER", null, true));
        map2.put("period_count", new l6.k(0, 1, "period_count", "INTEGER", "0", true));
        map2.put("generation", new l6.k(0, 1, "generation", "INTEGER", "0", true));
        map2.put("required_network_type", new l6.k(0, 1, "required_network_type", "INTEGER", null, true));
        map2.put("requires_charging", new l6.k(0, 1, "requires_charging", "INTEGER", null, true));
        map2.put("requires_device_idle", new l6.k(0, 1, "requires_device_idle", "INTEGER", null, true));
        map2.put("requires_battery_not_low", new l6.k(0, 1, "requires_battery_not_low", "INTEGER", null, true));
        map2.put("requires_storage_not_low", new l6.k(0, 1, "requires_storage_not_low", "INTEGER", null, true));
        map2.put("trigger_content_update_delay", new l6.k(0, 1, "trigger_content_update_delay", "INTEGER", null, true));
        map2.put("trigger_max_content_delay", new l6.k(0, 1, "trigger_max_content_delay", "INTEGER", null, true));
        map2.put("content_uri_triggers", new l6.k(0, 1, "content_uri_triggers", "BLOB", null, true));
        HashSet hashSet3 = new HashSet(0);
        HashSet hashSet4 = new HashSet(2);
        hashSet4.add(new l6.m("index_WorkSpec_schedule_requested_at", false, Arrays.asList("schedule_requested_at"), Arrays.asList("ASC")));
        hashSet4.add(new l6.m("index_WorkSpec_last_enqueue_time", false, Arrays.asList("last_enqueue_time"), Arrays.asList("ASC")));
        l6.n nVar2 = new l6.n("WorkSpec", map2, hashSet3, hashSet4);
        l6.n nVarA2 = l6.n.a(cVar, "WorkSpec");
        if (!nVar2.equals(nVarA2)) {
            return new g6.a0(false, "WorkSpec(androidx.work.impl.model.WorkSpec).\n Expected:\n" + nVar2 + "\n Found:\n" + nVarA2, 1);
        }
        HashMap map3 = new HashMap(2);
        map3.put("tag", new l6.k(1, 1, "tag", "TEXT", null, true));
        map3.put("work_spec_id", new l6.k(2, 1, "work_spec_id", "TEXT", null, true));
        HashSet hashSet5 = new HashSet(1);
        hashSet5.add(new l6.l("WorkSpec", "CASCADE", "CASCADE", Arrays.asList("work_spec_id"), Arrays.asList("id")));
        HashSet hashSet6 = new HashSet(1);
        hashSet6.add(new l6.m("index_WorkTag_work_spec_id", false, Arrays.asList("work_spec_id"), Arrays.asList("ASC")));
        l6.n nVar3 = new l6.n("WorkTag", map3, hashSet5, hashSet6);
        l6.n nVarA3 = l6.n.a(cVar, "WorkTag");
        if (!nVar3.equals(nVarA3)) {
            return new g6.a0(false, "WorkTag(androidx.work.impl.model.WorkTag).\n Expected:\n" + nVar3 + "\n Found:\n" + nVarA3, 1);
        }
        HashMap map4 = new HashMap(3);
        map4.put("work_spec_id", new l6.k(1, 1, "work_spec_id", "TEXT", null, true));
        map4.put("generation", new l6.k(2, 1, "generation", "INTEGER", "0", true));
        map4.put("system_id", new l6.k(0, 1, "system_id", "INTEGER", null, true));
        HashSet hashSet7 = new HashSet(1);
        hashSet7.add(new l6.l("WorkSpec", "CASCADE", "CASCADE", Arrays.asList("work_spec_id"), Arrays.asList("id")));
        l6.n nVar4 = new l6.n("SystemIdInfo", map4, hashSet7, new HashSet(0));
        l6.n nVarA4 = l6.n.a(cVar, "SystemIdInfo");
        if (!nVar4.equals(nVarA4)) {
            return new g6.a0(false, "SystemIdInfo(androidx.work.impl.model.SystemIdInfo).\n Expected:\n" + nVar4 + "\n Found:\n" + nVarA4, 1);
        }
        HashMap map5 = new HashMap(2);
        map5.put("name", new l6.k(1, 1, "name", "TEXT", null, true));
        map5.put("work_spec_id", new l6.k(2, 1, "work_spec_id", "TEXT", null, true));
        HashSet hashSet8 = new HashSet(1);
        hashSet8.add(new l6.l("WorkSpec", "CASCADE", "CASCADE", Arrays.asList("work_spec_id"), Arrays.asList("id")));
        HashSet hashSet9 = new HashSet(1);
        hashSet9.add(new l6.m("index_WorkName_work_spec_id", false, Arrays.asList("work_spec_id"), Arrays.asList("ASC")));
        l6.n nVar5 = new l6.n("WorkName", map5, hashSet8, hashSet9);
        l6.n nVarA5 = l6.n.a(cVar, "WorkName");
        if (!nVar5.equals(nVarA5)) {
            return new g6.a0(false, "WorkName(androidx.work.impl.model.WorkName).\n Expected:\n" + nVar5 + "\n Found:\n" + nVarA5, 1);
        }
        HashMap map6 = new HashMap(2);
        map6.put("work_spec_id", new l6.k(1, 1, "work_spec_id", "TEXT", null, true));
        map6.put("progress", new l6.k(0, 1, "progress", "BLOB", null, true));
        HashSet hashSet10 = new HashSet(1);
        hashSet10.add(new l6.l("WorkSpec", "CASCADE", "CASCADE", Arrays.asList("work_spec_id"), Arrays.asList("id")));
        l6.n nVar6 = new l6.n("WorkProgress", map6, hashSet10, new HashSet(0));
        l6.n nVarA6 = l6.n.a(cVar, "WorkProgress");
        if (!nVar6.equals(nVarA6)) {
            return new g6.a0(false, "WorkProgress(androidx.work.impl.model.WorkProgress).\n Expected:\n" + nVar6 + "\n Found:\n" + nVarA6, 1);
        }
        HashMap map7 = new HashMap(2);
        map7.put("key", new l6.k(1, 1, "key", "TEXT", null, true));
        map7.put("long_value", new l6.k(0, 1, "long_value", "INTEGER", null, false));
        l6.n nVar7 = new l6.n("Preference", map7, new HashSet(0), new HashSet(0));
        l6.n nVarA7 = l6.n.a(cVar, "Preference");
        if (nVar7.equals(nVarA7)) {
            return new g6.a0(true, (String) null, 1);
        }
        return new g6.a0(false, "Preference(androidx.work.impl.model.Preference).\n Expected:\n" + nVar7 + "\n Found:\n" + nVarA7, 1);
    }

    public void A() {
        if (((pj.e) this.X).getAndSet(u4.Y) == u4.X) {
            throw null;
        }
    }

    public void B(int i10) {
        RecyclerView recyclerView = (RecyclerView) this.X;
        View childAt = recyclerView.getChildAt(i10);
        if (childAt != null) {
            recyclerView.p(childAt);
            childAt.clearAnimation();
        }
        recyclerView.removeViewAt(i10);
    }

    public void C(long j10, long j11, int i10) throws i3.r0 {
        f5.f fVar = (f5.f) this.X;
        fVar.f8002j0.getClass();
        if (i10 == 160) {
            fVar.Y = false;
            fVar.Z = 0L;
            return;
        }
        if (i10 == 174) {
            f5.e eVar = new f5.e();
            eVar.f7967n = -1;
            eVar.f7968o = -1;
            eVar.f7969p = -1;
            eVar.f7970q = -1;
            eVar.f7971r = -1;
            eVar.f7972s = 0;
            eVar.f7973t = -1;
            eVar.f7974u = 0.0f;
            eVar.f7975v = 0.0f;
            eVar.f7976w = 0.0f;
            eVar.f7977x = null;
            eVar.f7978y = -1;
            eVar.f7979z = false;
            eVar.A = -1;
            eVar.B = -1;
            eVar.C = -1;
            eVar.D = 1000;
            eVar.E = 200;
            eVar.F = -1.0f;
            eVar.G = -1.0f;
            eVar.H = -1.0f;
            eVar.I = -1.0f;
            eVar.J = -1.0f;
            eVar.K = -1.0f;
            eVar.L = -1.0f;
            eVar.M = -1.0f;
            eVar.N = -1.0f;
            eVar.O = -1.0f;
            eVar.Q = 1;
            eVar.R = -1;
            eVar.S = 8000;
            eVar.T = 0L;
            eVar.U = 0L;
            eVar.W = false;
            eVar.Y = true;
            eVar.Z = "eng";
            fVar.f8017y = eVar;
            eVar.f7953a = fVar.f8015w;
            return;
        }
        if (i10 == 183) {
            if (fVar.f8018z) {
                return;
            }
            fVar.g(i10);
            fVar.F = -1;
            fVar.G = -1L;
            fVar.H = -1L;
            return;
        }
        if (i10 == 187) {
            if (fVar.f8018z) {
                return;
            }
            fVar.g(i10);
            fVar.E = -9223372036854775807L;
            return;
        }
        if (i10 == 19899) {
            fVar.A = -1;
            fVar.B = -1L;
            return;
        }
        if (i10 == 20533) {
            fVar.h(i10);
            fVar.f8017y.f7962i = true;
            return;
        }
        if (i10 == 21968) {
            fVar.h(i10);
            fVar.f8017y.f7979z = true;
            return;
        }
        if (i10 == 408125543) {
            long j12 = fVar.f8011s;
            if (j12 != -1 && j12 != j10) {
                throw i3.r0.a(null, "Multiple Segment elements not supported");
            }
            fVar.f8011s = j10;
            fVar.f8010r = j11;
            return;
        }
        if (i10 == 475249515) {
            if (fVar.f8018z) {
                return;
            }
            fVar.D = true;
        } else if (i10 == 524531317 && !fVar.f8018z) {
            if (fVar.f7991d && fVar.K != -1) {
                fVar.J = true;
            } else {
                fVar.f8002j0.i(new n4.s(fVar.f8014v));
                fVar.f8018z = true;
            }
        }
    }

    public void D(int i10, String str) throws i3.r0 {
        f5.f fVar = (f5.f) this.X;
        if (i10 == 134) {
            fVar.h(i10);
            fVar.f8017y.f7957c = str;
            return;
        }
        if (i10 == 17026) {
            if ("webm".equals(str) || "matroska".equals(str)) {
                fVar.f8015w = str.equals("webm");
                return;
            }
            throw i3.r0.a(null, "DocType " + str + " not supported");
        }
        if (i10 == 21358) {
            fVar.h(i10);
            fVar.f8017y.f7955b = str;
        } else {
            if (i10 != 2274716) {
                return;
            }
            fVar.h(i10);
            fVar.f8017y.Z = str;
        }
    }

    @Override // r0.c
    public /* bridge */ /* synthetic */ void a(Object obj) {
    }

    @Override // m.u
    public void b(m.j jVar, boolean z5) {
        switch (this.f375e) {
            case 1:
                ((androidx.appcompat.app.e0) this.X).q(jVar);
                break;
            default:
                if (jVar instanceof m.b0) {
                    ((m.b0) jVar).M0.k().c(false);
                }
                m.u uVar = ((androidx.appcompat.widget.n) this.X).f1373r0;
                if (uVar != null) {
                    uVar.b(jVar, z5);
                }
                break;
        }
    }

    @Override // cb.r0
    public /* synthetic */ void c(String str, int i10, Throwable th2, byte[] bArr, Map map) {
        ((cb.e4) this.X).w(str, i10, th2, bArr, map);
    }

    @Override // androidx.recyclerview.widget.i0
    public void d(int i10, int i11) {
        ((androidx.recyclerview.widget.t0) this.X).i(i10, i11);
    }

    @Override // androidx.media3.session.t2
    public a4.c0 e(androidx.media3.session.g2 mediaSession, lc.u0 customLayout, w4 actionFactory, androidx.media3.session.f0 f0Var) {
        kotlin.jvm.internal.q.g(mediaSession, "mediaSession");
        kotlin.jvm.internal.q.g(customLayout, "customLayout");
        kotlin.jvm.internal.q.g(actionFactory, "actionFactory");
        androidx.media3.session.p pVar = (androidx.media3.session.p) this.X;
        pVar.a();
        return pVar.e(mediaSession, customLayout, actionFactory, f0Var);
    }

    @Override // r0.c
    public void f(Throwable th2) {
        ListenableFuture listenableFutureE;
        int iN;
        v2 v2Var = (v2) this.X;
        l0 l0Var = new l0(16, v2Var);
        if (g6.y.t()) {
            l0Var.run();
        } else {
            CountDownLatch countDownLatch = new CountDownLatch(1);
            d7.s.k("Unable to post to main thread", new Handler(Looper.getMainLooper()).post(new k4.d0(l0Var, countDownLatch, 24)));
            try {
                if (!countDownLatch.await(30000L, TimeUnit.MILLISECONDS)) {
                    throw new IllegalStateException("Timeout to wait main thread execution");
                }
            } catch (InterruptedException e3) {
                throw new ad.n(e3, 9);
            }
        }
        g0.w wVar = (g0.w) v2Var.f364d;
        if (wVar != null) {
            kotlin.jvm.internal.q.d(wVar);
            m0.i0 i0Var = wVar.f8450n;
            i0Var.getClass();
            CopyOnWriteArrayList copyOnWriteArrayList = i0Var.f14850n;
            ko.c cVar = new ko.c(21, v2Var);
            kotlin.jvm.internal.q.g(copyOnWriteArrayList, "<this>");
            if (copyOnWriteArrayList instanceof RandomAccess) {
                int iN2 = ri.n.N(copyOnWriteArrayList);
                int i10 = 0;
                if (iN2 >= 0) {
                    int i11 = 0;
                    while (true) {
                        Object obj = copyOnWriteArrayList.get(i10);
                        if (!((Boolean) cVar.invoke(obj)).booleanValue()) {
                            if (i11 != i10) {
                                copyOnWriteArrayList.set(i11, obj);
                            }
                            i11++;
                        }
                        if (i10 == iN2) {
                            break;
                        } else {
                            i10++;
                        }
                    }
                    i10 = i11;
                }
                if (i10 < copyOnWriteArrayList.size() && i10 <= (iN = ri.n.N(copyOnWriteArrayList))) {
                    while (true) {
                        copyOnWriteArrayList.remove(iN);
                        if (iN == i10) {
                            break;
                        } else {
                            iN--;
                        }
                    }
                }
            } else {
                if ((copyOnWriteArrayList instanceof fj.a) && !(copyOnWriteArrayList instanceof fj.b)) {
                    kotlin.jvm.internal.i0.g(copyOnWriteArrayList, "kotlin.collections.MutableIterable");
                    throw null;
                }
                Iterator it = copyOnWriteArrayList.iterator();
                while (it.hasNext()) {
                    if (((Boolean) cVar.invoke(it.next())).booleanValue()) {
                        it.remove();
                    }
                }
            }
            g0.w wVar2 = (g0.w) v2Var.f364d;
            kotlin.jvm.internal.q.d(wVar2);
            listenableFutureE = wVar2.e();
        } else {
            listenableFutureE = r0.i.Y;
        }
        kotlin.jvm.internal.q.d(listenableFutureE);
        synchronized (v2Var.f361a) {
            v2Var.f362b = null;
            v2Var.f363c = listenableFutureE;
            ((HashMap) v2Var.f366g).clear();
            ((HashSet) v2Var.h).clear();
        }
        v2Var.e(null, null);
    }

    @Override // androidx.recyclerview.widget.b2
    public int g(View view) {
        return (view.getLeft() - ((androidx.recyclerview.widget.c1) view.getLayoutParams()).f2931b.left) - ((ViewGroup.MarginLayoutParams) ((androidx.recyclerview.widget.c1) view.getLayoutParams())).leftMargin;
    }

    @Override // m.u
    public boolean h(m.j jVar) {
        switch (this.f375e) {
            case 1:
                Window.Callback callback = ((androidx.appcompat.app.e0) this.X).f1084y0.getCallback();
                if (callback == null) {
                    return true;
                }
                callback.onMenuOpened(108, jVar);
                return true;
            default:
                androidx.appcompat.widget.n nVar = (androidx.appcompat.widget.n) this.X;
                if (jVar == nVar.Y) {
                    return false;
                }
                nVar.L0 = ((m.b0) jVar).N0.f14729e;
                m.u uVar = nVar.f1373r0;
                if (uVar != null) {
                    return uVar.h(jVar);
                }
                return false;
        }
    }

    @Override // androidx.media3.session.t2
    public m7.c i() {
        String str = "player_mode";
        return new m7.c(2, str, str, false);
    }

    @Override // androidx.recyclerview.widget.i0
    public void j(int i10, int i11) {
        ((androidx.recyclerview.widget.t0) this.X).k(i10, i11);
    }

    @Override // androidx.recyclerview.widget.i0
    public void k(int i10, int i11) {
        ((androidx.recyclerview.widget.t0) this.X).l(i10, i11);
    }

    @Override // androidx.recyclerview.widget.b2
    public int l() {
        return ((androidx.recyclerview.widget.b1) this.X).E();
    }

    @Override // ga.c
    public void m(ConnectionResult connectionResult) {
        ((da.i) this.X).m(connectionResult);
    }

    @Override // ac.a
    public void n(Typeface typeface) {
        com.google.android.material.internal.b bVar = (com.google.android.material.internal.b) this.X;
        if (bVar.t(typeface)) {
            bVar.l(false);
        }
    }

    @Override // androidx.recyclerview.widget.b2
    public int o() {
        androidx.recyclerview.widget.b1 b1Var = (androidx.recyclerview.widget.b1) this.X;
        return b1Var.f2920n - b1Var.F();
    }

    @Override // androidx.recyclerview.widget.b2
    public View p(int i10) {
        return ((androidx.recyclerview.widget.b1) this.X).u(i10);
    }

    @Override // androidx.recyclerview.widget.i0
    public void q(int i10, int i11, Object obj) {
        ((androidx.recyclerview.widget.t0) this.X).j(i10, i11, obj);
    }

    @Override // androidx.recyclerview.widget.b2
    public int r(View view) {
        return view.getRight() + ((androidx.recyclerview.widget.c1) view.getLayoutParams()).f2931b.right + ((ViewGroup.MarginLayoutParams) ((androidx.recyclerview.widget.c1) view.getLayoutParams())).rightMargin;
    }

    @Override // androidx.media3.session.t2
    public void s(androidx.media3.session.g2 g2Var, String str, Bundle extras) {
        kotlin.jvm.internal.q.g(extras, "extras");
    }

    public void t(j6.a migration) {
        kotlin.jvm.internal.q.g(migration, "migration");
        int i10 = migration.f12818a;
        int i11 = migration.f12819b;
        LinkedHashMap linkedHashMap = (LinkedHashMap) this.X;
        Integer numValueOf = Integer.valueOf(i10);
        Object treeMap = linkedHashMap.get(numValueOf);
        if (treeMap == null) {
            treeMap = new TreeMap();
            linkedHashMap.put(numValueOf, treeMap);
        }
        TreeMap treeMap2 = (TreeMap) treeMap;
        if (treeMap2.containsKey(Integer.valueOf(i11))) {
            Log.w("ROOM", "Overriding migration " + treeMap2.get(Integer.valueOf(i11)) + " with " + migration);
        }
        treeMap2.put(Integer.valueOf(i11), migration);
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    public Object u(wi.c cVar) {
        v4 v4Var;
        if (cVar instanceof v4) {
            v4Var = (v4) cVar;
            int i10 = v4Var.Y;
            if ((i10 & Integer.MIN_VALUE) != 0) {
                v4Var.Y = i10 - Integer.MIN_VALUE;
            } else {
                v4Var = new v4(this, cVar);
            }
        } else {
            v4Var = new v4(this, cVar);
        }
        Object obj = v4Var.f368e;
        vi.a aVar = vi.a.f21252e;
        int i11 = v4Var.Y;
        if (i11 == 0) {
            g6.y.I(obj);
            throw null;
        }
        if (i11 != 1) {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        g6.y.I(obj);
        if (((pj.e) this.X).compareAndSet(u4.f355e, u4.X)) {
            return qi.b0.f17350a;
        }
        throw null;
    }

    /* JADX WARN: Code duplicated, block: B:132:0x02ab  */
    public void v(int i10, int i11, n4.o oVar) throws i3.r0 {
        int i12;
        int i13;
        int i14;
        int i15;
        int i16;
        long j10;
        int i17;
        int i18;
        int i19;
        int i20;
        int i21;
        f5.f fVar = (f5.f) this.X;
        f5.g gVar = fVar.f7987b;
        SparseArray sparseArray = fVar.f7989c;
        l3.v vVar = fVar.f8003k;
        l3.v vVar2 = fVar.f7999i;
        int i22 = 2;
        int i23 = 0;
        int i24 = 1;
        if (i10 != 161 && i10 != 163) {
            if (i10 == 165) {
                if (fVar.O != 2) {
                    return;
                }
                f5.e eVar = (f5.e) sparseArray.get(fVar.U);
                int i25 = fVar.X;
                l3.v vVar3 = fVar.f8008p;
                if (i25 != 4 || !"V_VP9".equals(eVar.f7957c)) {
                    oVar.n(i11);
                    return;
                } else {
                    vVar3.K(i11);
                    oVar.readFully(vVar3.f14157a, 0, i11);
                    return;
                }
            }
            if (i10 == 16877) {
                fVar.h(i10);
                f5.e eVar2 = fVar.f8017y;
                int i26 = eVar2.h;
                if (i26 != 1685485123 && i26 != 1685480259) {
                    oVar.n(i11);
                    return;
                }
                byte[] bArr = new byte[i11];
                eVar2.P = bArr;
                oVar.readFully(bArr, 0, i11);
                return;
            }
            if (i10 == 16981) {
                fVar.h(i10);
                byte[] bArr2 = new byte[i11];
                fVar.f8017y.f7963j = bArr2;
                oVar.readFully(bArr2, 0, i11);
                return;
            }
            if (i10 == 18402) {
                byte[] bArr3 = new byte[i11];
                oVar.readFully(bArr3, 0, i11);
                fVar.h(i10);
                fVar.f8017y.f7964k = new n4.f0(1, bArr3, 0, 0);
                return;
            }
            if (i10 == 21419) {
                Arrays.fill(vVar.f14157a, (byte) 0);
                oVar.readFully(vVar.f14157a, 4 - i11, i11);
                vVar.N(0);
                fVar.A = (int) vVar.C();
                return;
            }
            if (i10 == 25506) {
                fVar.h(i10);
                byte[] bArr4 = new byte[i11];
                fVar.f8017y.f7965l = bArr4;
                oVar.readFully(bArr4, 0, i11);
                return;
            }
            if (i10 != 30322) {
                throw i3.r0.a(null, "Unexpected id: " + i10);
            }
            fVar.h(i10);
            byte[] bArr5 = new byte[i11];
            fVar.f8017y.f7977x = bArr5;
            oVar.readFully(bArr5, 0, i11);
            return;
        }
        if (fVar.O == 0) {
            fVar.U = (int) gVar.b(oVar, false, true, 8);
            fVar.V = gVar.f8022c;
            fVar.Q = -9223372036854775807L;
            fVar.O = 1;
            vVar2.K(0);
        }
        f5.e eVar3 = (f5.e) sparseArray.get(fVar.U);
        if (eVar3 == null) {
            oVar.n(i11 - fVar.V);
            fVar.O = 0;
            return;
        }
        eVar3.f7954a0.getClass();
        if (fVar.O == 1) {
            fVar.l(oVar, 3);
            int i27 = (vVar2.f14157a[2] & 6) >> 1;
            byte b10 = 255;
            if (i27 == 0) {
                fVar.S = 1;
                int[] iArr = fVar.T;
                if (iArr == null) {
                    iArr = new int[1];
                } else if (iArr.length < 1) {
                    iArr = new int[Math.max(iArr.length * 2, 1)];
                }
                fVar.T = iArr;
                iArr[0] = (i11 - fVar.V) - 3;
            } else {
                fVar.l(oVar, 4);
                int i28 = (vVar2.f14157a[3] & 255) + 1;
                fVar.S = i28;
                int[] iArr2 = fVar.T;
                if (iArr2 == null) {
                    iArr2 = new int[i28];
                } else if (iArr2.length < i28) {
                    iArr2 = new int[Math.max(iArr2.length * 2, i28)];
                }
                fVar.T = iArr2;
                if (i27 == 2) {
                    int i29 = (i11 - fVar.V) - 4;
                    int i30 = fVar.S;
                    Arrays.fill(iArr2, 0, i30, i29 / i30);
                } else {
                    if (i27 == 1) {
                        int i31 = 0;
                        int i32 = 0;
                        int i33 = 4;
                        while (true) {
                            i18 = fVar.S - 1;
                            if (i31 >= i18) {
                                break;
                            }
                            fVar.T[i31] = 0;
                            while (true) {
                                i19 = i33 + 1;
                                fVar.l(oVar, i19);
                                int i34 = vVar2.f14157a[i33] & 255;
                                int[] iArr3 = fVar.T;
                                i20 = iArr3[i31] + i34;
                                iArr3[i31] = i20;
                                if (i34 != 255) {
                                    break;
                                } else {
                                    i33 = i19;
                                }
                            }
                            i32 += i20;
                            i31++;
                            i33 = i19;
                        }
                        fVar.T[i18] = ((i11 - fVar.V) - i33) - i32;
                    } else {
                        if (i27 != 3) {
                            throw i3.r0.a(null, "Unexpected lacing value: " + i27);
                        }
                        int i35 = 0;
                        int i36 = 0;
                        int i37 = 4;
                        while (true) {
                            int i38 = fVar.S - i24;
                            if (i35 >= i38) {
                                i12 = i22;
                                i13 = i23;
                                i14 = i24;
                                fVar.T[i38] = ((i11 - fVar.V) - i37) - i36;
                                break;
                            }
                            fVar.T[i35] = i23;
                            int i39 = i37 + 1;
                            fVar.l(oVar, i39);
                            if (vVar2.f14157a[i37] == 0) {
                                throw i3.r0.a(null, "No valid varint length mask found");
                            }
                            int i40 = i23;
                            while (true) {
                                if (i40 >= 8) {
                                    i15 = i22;
                                    i16 = i24;
                                    j10 = 0;
                                    i17 = i39;
                                    break;
                                }
                                int i41 = i24 << (7 - i40);
                                i15 = i22;
                                if ((vVar2.f14157a[i37] & i41) != 0) {
                                    int i42 = i39 + i40;
                                    fVar.l(oVar, i42);
                                    i16 = i24;
                                    j10 = vVar2.f14157a[i37] & b10 & (~i41);
                                    while (i39 < i42) {
                                        j10 = (j10 << 8) | ((long) (vVar2.f14157a[i39] & b10));
                                        i39++;
                                        i42 = i42;
                                        b10 = 255;
                                    }
                                    i17 = i42;
                                    if (i35 <= 0) {
                                        break;
                                    }
                                    j10 -= (1 << ((i40 * 7) + 6)) - 1;
                                    break;
                                }
                                i40++;
                                i22 = i15;
                                b10 = 255;
                            }
                            if (j10 < -2147483648L || j10 > 2147483647L) {
                                throw i3.r0.a(null, "EBML lacing sample size out of range.");
                            }
                            int i43 = (int) j10;
                            int[] iArr4 = fVar.T;
                            if (i35 != 0) {
                                i43 += iArr4[i35 - 1];
                            }
                            iArr4[i35] = i43;
                            i36 += i43;
                            i35++;
                            i23 = i40;
                            i22 = i15;
                            i24 = i16;
                            i37 = i17;
                            b10 = 255;
                        }
                    }
                    byte[] bArr6 = vVar2.f14157a;
                    fVar.P = fVar.n((bArr6[i14] & 255) | (bArr6[i13] << 8)) + fVar.M;
                    if (eVar3.f7960e != i14 || (i10 == 163 && (vVar2.f14157a[i12] & 128) == 128)) {
                        i21 = 1;
                    } else {
                        i21 = i13;
                    }
                    fVar.W = i21;
                    fVar.O = i12;
                    fVar.R = i13;
                }
            }
            i12 = 2;
            i13 = 0;
            i14 = 1;
            byte[] bArr7 = vVar2.f14157a;
            fVar.P = fVar.n((bArr7[i14] & 255) | (bArr7[i13] << 8)) + fVar.M;
            if (eVar3.f7960e != i14) {
                i21 = 1;
            } else {
                i21 = 1;
            }
            fVar.W = i21;
            fVar.O = i12;
            fVar.R = i13;
        }
        if (i10 == 163) {
            while (true) {
                int i44 = fVar.R;
                if (i44 >= fVar.S) {
                    fVar.O = 0;
                    return;
                }
                fVar.i(eVar3, ((long) ((fVar.R * eVar3.f) / 1000)) + fVar.P, fVar.W, fVar.o(oVar, eVar3, fVar.T[i44], false), 0);
                fVar.R++;
            }
        } else {
            while (true) {
                int i45 = fVar.R;
                if (i45 >= fVar.S) {
                    return;
                }
                int[] iArr5 = fVar.T;
                iArr5[i45] = fVar.o(oVar, eVar3, iArr5[i45], true);
                fVar.R++;
            }
        }
    }

    public void y(int i10, long j10) throws i3.r0 {
        f5.f fVar = (f5.f) this.X;
        if (i10 == 240) {
            if (fVar.f8018z) {
                return;
            }
            fVar.g(i10);
            if (fVar.H == -1) {
                fVar.H = j10;
                return;
            }
            return;
        }
        if (i10 == 241) {
            if (fVar.f8018z) {
                return;
            }
            fVar.g(i10);
            if (fVar.G == -1) {
                fVar.G = j10;
                return;
            }
            return;
        }
        if (i10 == 20529) {
            if (j10 == 0) {
                return;
            }
            throw i3.r0.a(null, "ContentEncodingOrder " + j10 + " not supported");
        }
        if (i10 == 20530) {
            if (j10 == 1) {
                return;
            }
            throw i3.r0.a(null, "ContentEncodingScope " + j10 + " not supported");
        }
        switch (i10) {
            case 131:
                int i11 = (int) j10;
                if (i11 == 1) {
                    fVar.h(i10);
                    fVar.f8017y.f7960e = 2;
                    return;
                }
                if (i11 == 2) {
                    fVar.h(i10);
                    fVar.f8017y.f7960e = 1;
                    return;
                } else if (i11 == 17) {
                    fVar.h(i10);
                    fVar.f8017y.f7960e = 3;
                    return;
                } else if (i11 != 33) {
                    fVar.h(i10);
                    fVar.f8017y.f7960e = -1;
                    return;
                } else {
                    fVar.h(i10);
                    fVar.f8017y.f7960e = 5;
                    return;
                }
            case 136:
                fVar.h(i10);
                fVar.f8017y.Y = j10 == 1;
                return;
            case 155:
                fVar.Q = fVar.n(j10);
                return;
            case 159:
                fVar.h(i10);
                fVar.f8017y.Q = (int) j10;
                return;
            case 176:
                fVar.h(i10);
                fVar.f8017y.f7967n = (int) j10;
                return;
            case 179:
                if (fVar.f8018z) {
                    return;
                }
                fVar.g(i10);
                fVar.E = fVar.n(j10);
                return;
            case 186:
                fVar.h(i10);
                fVar.f8017y.f7968o = (int) j10;
                return;
            case 215:
                fVar.h(i10);
                fVar.f8017y.f7959d = (int) j10;
                return;
            case 231:
                fVar.M = fVar.n(j10);
                return;
            case 238:
                fVar.X = (int) j10;
                return;
            case 247:
                if (fVar.f8018z) {
                    return;
                }
                fVar.g(i10);
                fVar.F = (int) j10;
                return;
            case 251:
                fVar.Y = true;
                return;
            case 16871:
                fVar.h(i10);
                fVar.f8017y.h = (int) j10;
                return;
            case 16980:
                if (j10 == 3) {
                    return;
                }
                throw i3.r0.a(null, "ContentCompAlgo " + j10 + " not supported");
            case 17029:
                if (j10 < 1 || j10 > 2) {
                    throw i3.r0.a(null, "DocTypeReadVersion " + j10 + " not supported");
                }
                return;
            case 17143:
                if (j10 == 1) {
                    return;
                }
                throw i3.r0.a(null, "EBMLReadVersion " + j10 + " not supported");
            case 18401:
                if (j10 == 5) {
                    return;
                }
                throw i3.r0.a(null, "ContentEncAlgo " + j10 + " not supported");
            case 18408:
                if (j10 == 1) {
                    return;
                }
                throw i3.r0.a(null, "AESSettingsCipherMode " + j10 + " not supported");
            case 21420:
                fVar.B = j10 + fVar.f8011s;
                return;
            case 21432:
                int i12 = (int) j10;
                fVar.h(i10);
                if (i12 == 0) {
                    fVar.f8017y.f7978y = 0;
                    return;
                }
                if (i12 == 1) {
                    fVar.f8017y.f7978y = 2;
                    return;
                } else if (i12 == 3) {
                    fVar.f8017y.f7978y = 1;
                    return;
                } else {
                    if (i12 != 15) {
                        return;
                    }
                    fVar.f8017y.f7978y = 3;
                    return;
                }
            case 21680:
                fVar.h(i10);
                fVar.f8017y.f7970q = (int) j10;
                return;
            case 21682:
                fVar.h(i10);
                fVar.f8017y.f7972s = (int) j10;
                return;
            case 21690:
                fVar.h(i10);
                fVar.f8017y.f7971r = (int) j10;
                return;
            case 21930:
                fVar.h(i10);
                fVar.f8017y.X = j10 == 1;
                return;
            case 21938:
                fVar.h(i10);
                f5.e eVar = fVar.f8017y;
                eVar.f7979z = true;
                eVar.f7969p = (int) j10;
                return;
            case 21998:
                fVar.h(i10);
                fVar.f8017y.f7961g = (int) j10;
                return;
            case 22186:
                fVar.h(i10);
                fVar.f8017y.T = j10;
                return;
            case 22203:
                fVar.h(i10);
                fVar.f8017y.U = j10;
                return;
            case 25188:
                fVar.h(i10);
                fVar.f8017y.R = (int) j10;
                return;
            case 30114:
                fVar.Z = j10;
                return;
            case 30321:
                fVar.h(i10);
                int i13 = (int) j10;
                if (i13 == 0) {
                    fVar.f8017y.f7973t = 0;
                    return;
                }
                if (i13 == 1) {
                    fVar.f8017y.f7973t = 1;
                    return;
                } else if (i13 == 2) {
                    fVar.f8017y.f7973t = 2;
                    return;
                } else {
                    if (i13 != 3) {
                        return;
                    }
                    fVar.f8017y.f7973t = 3;
                    return;
                }
            case 2352003:
                fVar.h(i10);
                fVar.f8017y.f = (int) j10;
                return;
            case 2807729:
                fVar.f8012t = j10;
                return;
            default:
                switch (i10) {
                    case 21945:
                        fVar.h(i10);
                        int i14 = (int) j10;
                        if (i14 == 1) {
                            fVar.f8017y.C = 2;
                            return;
                        } else {
                            if (i14 != 2) {
                                return;
                            }
                            fVar.f8017y.C = 1;
                            return;
                        }
                    case 21946:
                        fVar.h(i10);
                        int iG = i3.m.g((int) j10);
                        if (iG != -1) {
                            fVar.f8017y.B = iG;
                            return;
                        }
                        return;
                    case 21947:
                        fVar.h(i10);
                        fVar.f8017y.f7979z = true;
                        int iF = i3.m.f((int) j10);
                        if (iF != -1) {
                            fVar.f8017y.A = iF;
                            return;
                        }
                        return;
                    case 21948:
                        fVar.h(i10);
                        fVar.f8017y.D = (int) j10;
                        return;
                    case 21949:
                        fVar.h(i10);
                        fVar.f8017y.E = (int) j10;
                        return;
                    default:
                        return;
                }
        }
    }

    public /* synthetic */ w4(int i10, Object obj) {
        this.f375e = i10;
        this.X = obj;
    }

    public w4(zd zdVar, ea.f fVar) {
        this.f375e = 23;
        this.X = zdVar;
    }

    public w4(PlaybackService playbackService) {
        this.f375e = 26;
        l3.t tVar = new l3.t(playbackService, 1);
        tVar.f14152d = new e(20);
        tVar.f14153e = "player_mode";
        tVar.f14149a = R.string.player_channel_name;
        ji.k.A(!tVar.f14150b);
        androidx.media3.session.p pVar = new androidx.media3.session.p(tVar);
        tVar.f14150b = true;
        this.X = pVar;
    }

    public w4(FrameLayout frameLayout, RippleFrameLayout rippleFrameLayout) {
        this.f375e = 16;
        this.X = rippleFrameLayout;
    }

    public w4(FrameLayout frameLayout, MaterialButton materialButton, MaterialCardView materialCardView, TextView textView, TextView textView2, MaterialButton materialButton2) {
        this.f375e = 17;
        this.X = materialButton2;
    }

    public w4(s4 concurrentSequencer) {
        this.f375e = 0;
        kotlin.jvm.internal.q.g(concurrentSequencer, "concurrentSequencer");
        this.X = pj.b.atomic(u4.f355e);
    }
}
