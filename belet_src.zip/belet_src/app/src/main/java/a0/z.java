package a0;

import android.hardware.camera2.params.OutputConfiguration;
import android.util.Size;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public abstract /* synthetic */ class z {
    public static /* synthetic */ OutputConfiguration a(Size size, Class cls) {
        return new OutputConfiguration(size, cls);
    }
}
