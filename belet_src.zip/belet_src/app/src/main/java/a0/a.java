package a0;

import android.content.Context;
import android.content.SharedPreferences;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.util.Range;
import androidx.camera.camera2.compat.quirk.AeFpsRangeLegacyQuirk;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import okhttp3.internal.http2.Http2Connection;
import okhttp3.internal.http2.Http2Stream;
import okhttp3.internal.url._UrlKt;
import okhttp3.internal.ws.WebSocketProtocol;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class a implements ej.a {
    public final /* synthetic */ Object X;
    public final /* synthetic */ Object Y;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f4e;

    public /* synthetic */ a(Object obj, Object obj2, int i10) {
        this.f4e = i10;
        this.X = obj;
        this.Y = obj2;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v0, types: [ui.d] */
    /* JADX WARN: Type inference failed for: r1v16 */
    /* JADX WARN: Type inference failed for: r1v17 */
    /* JADX WARN: Type inference failed for: r1v18 */
    /* JADX WARN: Type inference failed for: r1v6, types: [android.util.Range] */
    /* JADX WARN: Type inference failed for: r1v7 */
    /* JADX WARN: Type inference failed for: r1v8 */
    @Override // ej.a
    public final Object invoke() {
        int iJ0;
        int i10 = this.f4e;
        Object obj = 0;
        obj = 0;
        obj = 0;
        qi.b0 b0Var = qi.b0.f17350a;
        int i11 = 0;
        Object obj2 = this.Y;
        Object obj3 = this.X;
        switch (i10) {
            case 0:
                ((t3) obj3).invoke((d) obj2);
                return b0Var;
            case 1:
                ((CameraManager) obj3).unregisterAvailabilityCallback((s0) obj2);
                return b0Var;
            case 2:
                ((l1) obj3).Y.unregisterAvailabilityCallback((j1) obj2);
                return b0Var;
            case 3:
                ((CameraManager) obj3).unregisterAvailabilityCallback((j1) obj2);
                return b0Var;
            case 4:
                return (io.ktor.utils.io.m) io.ktor.utils.io.k0.x(kotlinx.coroutines.w1.INSTANCE, (ui.i) obj3, 2, new ih.f((bi.e) obj2, obj, 1)).X;
            case 5:
                return kotlinx.serialization.h.descriptor_delegate$lambda$0((String) obj3, (kotlinx.serialization.h) obj2);
            case 6:
                return kotlinx.serialization.internal.g0.descriptor_delegate$lambda$0((kotlinx.serialization.internal.g0) obj3, (String) obj2);
            case 7:
                return kotlinx.serialization.internal.v1.descriptor_delegate$lambda$0((String) obj3, (kotlinx.serialization.internal.v1) obj2);
            case 8:
                return kotlinx.serialization.json.internal.g0.buildDeserializationNamesMap((kotlinx.serialization.descriptors.g) obj3, (kotlinx.serialization.json.c) obj2);
            case 9:
                return kotlinx.serialization.json.internal.g0.serializationNamesIndices$lambda$0((kotlinx.serialization.descriptors.g) obj3, (kotlinx.serialization.json.a0) obj2);
            case 10:
                CharSequence input = (CharSequence) obj2;
                kotlin.jvm.internal.q.g(input, "input");
                Matcher matcher = ((mj.k) obj3).f15498e.matcher(input);
                kotlin.jvm.internal.q.f(matcher, "matcher(...)");
                return y6.a.a(matcher, 0, input);
            case ue.r.NETWORK_CLIENT_ERROR_REASON_FIELD_NUMBER /* 11 */:
                return Http2Connection.ReaderRunnable.headers$lambda$0$0((Http2Connection) obj3, (Http2Stream) obj2);
            case ue.r.CUSTOM_ATTRIBUTES_FIELD_NUMBER /* 12 */:
                return Http2Connection.ReaderRunnable.applyAndAckSettings$lambda$0$0$1((Http2Connection) obj3, (kotlin.jvm.internal.d0) obj2);
            case ue.r.PERF_SESSIONS_FIELD_NUMBER /* 13 */:
                m0.f fVar = x.e.f21923a;
                return Boolean.valueOf(x.e.a(((r.h0) obj3).f17607a, (List) obj2));
            case 14:
                SharedPreferences sharedPreferences = ((Context) obj3).getSharedPreferences((String) obj2, 0);
                kotlin.jvm.internal.q.f(sharedPreferences, "getSharedPreferences(...)");
                return sharedPreferences;
            case WebSocketProtocol.B0_MASK_OPCODE /* 15 */:
                Context context = (Context) obj3;
                kotlin.jvm.internal.q.d(context);
                String name = ((rc.s0) obj2).f18001a;
                kotlin.jvm.internal.q.g(name, "name");
                return jd.t1.h(context, name.concat(".preferences_pb"));
            case WebSocketProtocol.B0_FLAG_RSV3 /* 16 */:
                CameraCharacteristics.Key CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES = CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES;
                kotlin.jvm.internal.q.f(CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES, "CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES");
                Range[] rangeArr = (Range[]) ((h1) ((z.s) obj3)).c(CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES);
                ((AeFpsRangeLegacyQuirk) obj2).getClass();
                if (rangeArr != null && rangeArr.length != 0) {
                    int length = rangeArr.length;
                    while (i11 < length) {
                        Range range = rangeArr[i11];
                        Integer numValueOf = (Integer) range.getUpper();
                        Integer numValueOf2 = (Integer) range.getLower();
                        if (((Number) range.getUpper()).intValue() >= 1000) {
                            numValueOf = Integer.valueOf(((Number) range.getUpper()).intValue() / 1000);
                        }
                        if (((Number) range.getLower()).intValue() >= 1000) {
                            numValueOf2 = Integer.valueOf(((Number) range.getLower()).intValue() / 1000);
                        }
                        Range range2 = new Range(numValueOf2, numValueOf);
                        Integer num = (Integer) range2.getUpper();
                        if (num != null && num.intValue() == 30 && (obj == 0 || ((Number) range2.getLower()).intValue() < ((Number) obj.getLower()).intValue())) {
                            obj = range2;
                        }
                        i11++;
                        obj = obj;
                    }
                }
                return obj;
            case 17:
                return new tk.n(((uk.e0) obj3).f20791a, (HashMap) obj2);
            default:
                yh.h0 h0Var = (yh.h0) obj2;
                String str = h0Var.f23044s0;
                if (((ArrayList) obj3).isEmpty() || (iJ0 = mj.l.j0(str, '/', h0Var.u0.f23037e.length() + 3, 4)) == -1) {
                    return _UrlKt.FRAGMENT_ENCODE_SET;
                }
                int iL0 = mj.l.l0(str, new char[]{'?', '#'}, iJ0, false);
                if (iL0 == -1) {
                    String strSubstring = str.substring(iJ0);
                    kotlin.jvm.internal.q.f(strSubstring, "substring(...)");
                    return strSubstring;
                }
                String strSubstring2 = str.substring(iJ0, iL0);
                kotlin.jvm.internal.q.f(strSubstring2, "substring(...)");
                return strSubstring2;
        }
    }
}
