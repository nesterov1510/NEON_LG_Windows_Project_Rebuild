package a0;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class m4 extends k2 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f217a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final kotlinx.coroutines.z f218b;

    public m4(String activeCameraId) {
        kotlin.jvm.internal.q.g(activeCameraId, "activeCameraId");
        this.f217a = activeCameraId;
        this.f218b = kotlinx.coroutines.b0.CompletableDeferred$default(null, 1, null);
    }

    public final String toString() {
        return "RequestCloseById(" + ((Object) z.p.b(this.f217a)) + ')';
    }
}
