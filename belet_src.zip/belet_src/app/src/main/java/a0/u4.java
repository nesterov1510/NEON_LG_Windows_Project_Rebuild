package a0;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class u4 {
    public static final u4 X;
    public static final u4 Y;
    public static final /* synthetic */ u4[] Z;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final u4 f355e;

    static {
        u4 u4Var = new u4("PENDING", 0);
        f355e = u4Var;
        u4 u4Var2 = new u4("CREATING", 1);
        X = u4Var2;
        u4 u4Var3 = new u4("CREATED", 2);
        Y = u4Var3;
        u4[] u4VarArr = {u4Var, u4Var2, u4Var3};
        Z = u4VarArr;
        android.support.v4.media.session.b.o(u4VarArr);
    }

    public static u4 valueOf(String str) {
        return (u4) Enum.valueOf(u4.class, str);
    }

    public static u4[] values() {
        return (u4[]) Z.clone();
    }
}
