package a0;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public interface f2 extends x4 {
    void b(g2 g2Var);

    void d(g2 g2Var);

    void e(g2 g2Var);

    void f(g2 g2Var);

    void g(g2 g2Var);

    void h(g2 g2Var);
}
