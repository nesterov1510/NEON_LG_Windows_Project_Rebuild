package a0;

import android.util.Log;
import java.util.concurrent.CancellationException;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class b5 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f20a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final d0.u f21b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final kotlinx.coroutines.p0 f22c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f23d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final Object f24e;
    public boolean f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public z4 f25g;
    public final kotlinx.coroutines.flow.g0 h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final kotlinx.coroutines.flow.i f26i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public l2 f27j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public kotlinx.coroutines.f2 f28k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public c0.f f29l;

    public b5(String cameraId, d0.u uVar, kotlinx.coroutines.p0 scope) {
        kotlin.jvm.internal.q.g(cameraId, "cameraId");
        kotlin.jvm.internal.q.g(scope, "scope");
        this.f20a = cameraId;
        this.f21b = uVar;
        this.f22c = scope;
        this.f23d = a5.f8a.incrementAndGet();
        this.f24e = new Object();
        kotlinx.coroutines.flow.g0 g0VarMutableSharedFlow$default = kotlinx.coroutines.flow.o0.MutableSharedFlow$default(1, 3, null, 4, null);
        this.h = g0VarMutableSharedFlow$default;
        this.f26i = kotlinx.coroutines.flow.k.distinctUntilChanged(g0VarMutableSharedFlow$default);
        w2 w2Var = w2.f374a;
        this.f27j = w2Var;
        if (!g0VarMutableSharedFlow$default.tryEmit(w2Var)) {
            throw new IllegalStateException("Check failed.");
        }
    }

    public final void a(z.i iVar) {
        synchronized (this.f24e) {
            try {
                if (this.f) {
                    return;
                }
                this.f = true;
                Log.i("CXCP", "Disconnecting " + this);
                z4 z4Var = this.f25g;
                if (z4Var != null) {
                    z4Var.a();
                }
                kotlinx.coroutines.f2 f2Var = this.f28k;
                if (f2Var != null) {
                    kotlinx.coroutines.d2.cancel$default(f2Var, (CancellationException) null, 1, (Object) null);
                }
                c0.f fVar = this.f29l;
                if (fVar != null) {
                    fVar.b();
                }
                if (!(c() instanceof m2)) {
                    if (!(this.f27j instanceof n2)) {
                        b(new n2(null));
                    }
                    b(new m2(this.f20a, k3.X, null, null, null, null, null, null, iVar));
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    public final void b(l2 l2Var) {
        this.f27j = l2Var;
        if (this.h.tryEmit(l2Var)) {
            return;
        }
        throw new IllegalStateException(("Failed to emit " + l2Var + " in " + this).toString());
    }

    public final l2 c() {
        l2 l2Var;
        synchronized (this.f24e) {
            l2Var = this.f27j;
        }
        return l2Var;
    }

    public final String toString() {
        return "VirtualCamera-" + this.f23d;
    }
}
