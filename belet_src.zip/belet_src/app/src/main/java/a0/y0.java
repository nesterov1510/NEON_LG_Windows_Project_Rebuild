package a0;

import android.util.Log;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class y0 implements ej.l {
    public final /* synthetic */ d1 X;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f388e;

    public /* synthetic */ y0(d1 d1Var, int i10) {
        this.f388e = i10;
        this.X = d1Var;
    }

    private final Object b(Object obj) {
        d1 d1Var = this.X;
        synchronized (d1Var.f56q) {
            d1Var.f58s = z.h.f23338b;
            Log.d("CXCP", d1Var + " is closed");
        }
        d1Var.f54o.b(d1Var);
        kotlinx.coroutines.z zVar = d1Var.f63x;
        qi.b0 b0Var = qi.b0.f17350a;
        zVar.complete(b0Var);
        kotlinx.coroutines.q0.cancel$default(d1Var.f42a, null, 1, null);
        return b0Var;
    }

    @Override // ej.l
    public final Object invoke(Object obj) {
        boolean z5;
        switch (this.f388e) {
            case 0:
                return b(obj);
            default:
                d1 d1Var = this.X;
                kotlin.jvm.internal.q.g((qi.b0) obj, "<unused var>");
                synchronized (d1Var.f56q) {
                    z5 = d1Var.f57r;
                }
                return Boolean.valueOf(z5);
        }
    }
}
