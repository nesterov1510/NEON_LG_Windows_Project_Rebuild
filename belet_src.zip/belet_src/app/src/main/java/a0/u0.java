package a0;

import android.util.Log;
import java.io.Serializable;
import java.util.Iterator;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class u0 implements kotlinx.coroutines.flow.j {
    public final /* synthetic */ Serializable X;
    public final /* synthetic */ Object Y;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f337e;

    public /* synthetic */ u0(Serializable serializable, Object obj, int i10) {
        this.f337e = i10;
        this.X = serializable;
        this.Y = obj;
    }

    @Override // kotlinx.coroutines.flow.j
    public final Object emit(Object obj, ui.d dVar) {
        switch (this.f337e) {
            case 0:
                String str = ((z.p) obj).f23381a;
                qi.b0 b0Var = qi.b0.f17350a;
                if (kotlin.jvm.internal.q.c(str, (String) this.X)) {
                    Log.d("CXCP", ((Object) z.p.b(str)) + " has become available! Notifying listeners...");
                    Iterator it = ((x0) this.Y).X.iterator();
                    kotlin.jvm.internal.q.f(it, "iterator(...)");
                    while (it.hasNext()) {
                        ((kotlinx.coroutines.z) it.next()).complete(b0Var);
                    }
                }
                return b0Var;
            default:
                l2 l2Var = (l2) obj;
                if (l2Var instanceof o2) {
                    i3 i3Var = (i3) ((kotlin.jvm.internal.d0) this.X).f13951e;
                    h2 h2Var = ((o2) l2Var).f256a;
                    synchronized (i3Var.f118k) {
                        d3 d3Var = i3Var.f128u;
                        if (d3Var != d3.Z && d3Var != d3.f71r0) {
                            i3Var.f124q = h2Var;
                            kotlinx.coroutines.k.launch$default(i3Var.f116i, null, null, new e3(i3Var, null, 0), 3, null);
                        }
                        break;
                    }
                } else if (l2Var instanceof n2) {
                    ((i3) ((kotlin.jvm.internal.d0) this.X).f13951e).o();
                } else if (l2Var instanceof m2) {
                    ((i3) ((kotlin.jvm.internal.d0) this.X).f13951e).o();
                    d1.b((d1) this.Y, (m2) l2Var);
                }
                return qi.b0.f17350a;
        }
    }
}
