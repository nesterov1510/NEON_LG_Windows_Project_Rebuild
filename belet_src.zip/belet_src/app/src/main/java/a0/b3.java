package a0;

import android.hardware.camera2.params.OutputConfiguration;
import android.os.Build;
import android.util.Log;
import android.util.Size;
import android.view.Surface;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public abstract class b3 {
    public static final si.f a(Map map, d0.f0 f0Var) {
        si.f fVar = new si.f();
        ArrayList arrayList = f0Var.f6541t0;
        int size = arrayList.size();
        int i10 = 0;
        while (i10 < size) {
            Object obj = arrayList.get(i10);
            i10++;
            z.b0 b0Var = (z.b0) obj;
            Surface surface = (Surface) map.get(new z.m1(b0Var.f23319a));
            if (surface != null) {
                ArrayList arrayList2 = b0Var.f23320b;
                int size2 = arrayList2.size();
                int i11 = 0;
                while (i11 < size2) {
                    Object obj2 = arrayList2.get(i11);
                    i11++;
                    fVar.put(new z.t0(((d0.d0) obj2).f6513a), surface);
                }
            }
        }
        return fVar.b();
    }

    public static final s3 b(z.k graphConfig, d0.f0 f0Var, Map surfaces) {
        LinkedHashMap linkedHashMap;
        f0.f fVar;
        z.b0 b0VarA;
        kotlin.jvm.internal.q.g(graphConfig, "graphConfig");
        String str = graphConfig.f23350a;
        LinkedHashMap linkedHashMap2 = f0Var.Z;
        kotlin.jvm.internal.q.g(surfaces, "surfaces");
        ArrayList arrayList = new ArrayList();
        LinkedHashMap linkedHashMap3 = new LinkedHashMap();
        LinkedHashMap linkedHashMap4 = new LinkedHashMap();
        LinkedHashMap linkedHashMap5 = new LinkedHashMap();
        Iterator it = ((si.g) f0Var.f6539r0.entrySet()).iterator();
        do {
            int i10 = 1;
            if (!it.hasNext()) {
                ArrayList arrayList2 = f0Var.f6541t0;
                int size = arrayList2.size();
                int i11 = 0;
                while (i11 < size) {
                    Object obj = arrayList2.get(i11);
                    i11++;
                    z.b0 b0Var = (z.b0) obj;
                    ArrayList arrayList3 = b0Var.f23320b;
                    int i12 = b0Var.f23319a;
                    arrayList2 = arrayList2;
                    if (arrayList3.size() == i10) {
                        Surface surface = (Surface) surfaces.get(new z.m1(i12));
                        if (surface != null) {
                            linkedHashMap4.put(new z.t0(((d0.d0) ri.m.t0(arrayList3)).f6513a), surface);
                        }
                    } else {
                        int size2 = arrayList3.size();
                        int i13 = 0;
                        while (i13 < size2) {
                            Object obj2 = arrayList3.get(i13);
                            i13++;
                            int i14 = size2;
                            d0.d0 d0Var = (d0.d0) obj2;
                            Object obj3 = linkedHashMap2.get(d0Var);
                            if (obj3 == null) {
                                throw new IllegalStateException("Required value was null.");
                            }
                            LinkedHashMap linkedHashMap6 = linkedHashMap2;
                            OutputConfiguration outputConfigurationE = e.e(linkedHashMap5.get((d0.c0) obj3));
                            Surface surface2 = outputConfigurationE != null ? outputConfigurationE.getSurface() : (Surface) surfaces.get(new z.m1(i12));
                            if (surface2 != null) {
                                linkedHashMap4.put(new z.t0(d0Var.f6513a), surface2);
                                size = size;
                            }
                            size2 = i14;
                            linkedHashMap2 = linkedHashMap6;
                        }
                        i10 = 1;
                    }
                }
                Iterator it2 = f0Var.Y.iterator();
                x xVar = null;
                while (it2.hasNext()) {
                    d0.c0 c0Var = (d0.c0) it2.next();
                    ArrayList arrayList4 = c0Var.f6511l;
                    ArrayList arrayList5 = c0Var.f6511l;
                    List list = c0Var.f6510k;
                    z.a1 a1Var = c0Var.f;
                    Integer num = c0Var.f6506e;
                    Iterator it3 = it2;
                    String str2 = c0Var.f6505d;
                    ArrayList arrayList6 = new ArrayList();
                    int size3 = arrayList4.size();
                    int i15 = 0;
                    while (i15 < size3) {
                        Object obj4 = arrayList4.get(i15);
                        int i16 = i15 + 1;
                        int i17 = size3;
                        Surface surface3 = (Surface) surfaces.get(new z.m1(((z.b0) obj4).f23319a));
                        if (surface3 != null) {
                            arrayList6.add(surface3);
                        }
                        i15 = i16;
                        size3 = i17;
                    }
                    OutputConfiguration outputConfigurationE2 = e.e(linkedHashMap5.get(c0Var));
                    LinkedHashMap linkedHashMap7 = linkedHashMap5;
                    if (outputConfigurationE2 == null) {
                        if (a1Var != null) {
                            linkedHashMap = linkedHashMap4;
                            if (arrayList6.size() != arrayList4.size()) {
                                Size size4 = c0Var.f6503b;
                                kotlin.jvm.internal.q.d(a1Var);
                                x xVarA = x2.a(null, null, a1Var, c0Var.f6507g, c0Var.h, c0Var.f6508i, list, size4, arrayList5.size() > 1, num != null ? num.intValue() : -1, !kotlin.jvm.internal.q.c(str2, str) ? str2 : null, 2);
                                if (xVarA == null) {
                                    Log.w("CXCP", "Failed to create AndroidOutputConfiguration for " + c0Var);
                                } else {
                                    arrayList.add(xVarA);
                                    int size5 = arrayList4.size();
                                    int i18 = 0;
                                    while (i18 < size5) {
                                        Object obj5 = arrayList4.get(i18);
                                        i18++;
                                        linkedHashMap3.put(new z.m1(((z.b0) obj5).f23319a), xVarA);
                                    }
                                }
                            }
                            it2 = it3;
                            linkedHashMap5 = linkedHashMap7;
                            linkedHashMap4 = linkedHashMap;
                        } else {
                            linkedHashMap = linkedHashMap4;
                        }
                        if (arrayList6.size() != arrayList4.size()) {
                            ArrayList arrayList7 = new ArrayList();
                            int size6 = arrayList4.size();
                            int i19 = 0;
                            while (i19 < size6) {
                                Object obj6 = arrayList4.get(i19);
                                i19++;
                                if (!surfaces.containsKey(new z.m1(((z.b0) obj6).f23319a))) {
                                    arrayList7.add(obj6);
                                }
                            }
                            throw new IllegalStateException(("Surfaces are not yet available for " + c0Var + "! Missing surfaces for " + arrayList7 + '!').toString());
                        }
                        x xVarA2 = x2.a((Surface) ri.m.e0(arrayList6), null, null, c0Var.f6507g, c0Var.h, c0Var.f6508i, list, c0Var.f6503b, arrayList5.size() > 1, num != null ? num.intValue() : -1, !kotlin.jvm.internal.q.c(str2, str) ? str2 : null, 6);
                        if (xVarA2 == null) {
                            Log.w("CXCP", "Failed to create AndroidOutputConfiguration for " + c0Var);
                        } else {
                            Iterator it4 = ri.m.Z(arrayList6).iterator();
                            while (it4.hasNext()) {
                                xVarA2.a((Surface) it4.next());
                            }
                            z.a0 a0Var = graphConfig.f23354e;
                            if (a0Var != null) {
                                z.b0 b0Var2 = (z.b0) f0Var.X.get(a0Var);
                                if (b0Var2 == null) {
                                    throw new IllegalStateException("Postview Stream in StreamGraph cannot be null for reprocessing request");
                                }
                                if (xVar == null && arrayList4.contains(b0Var2)) {
                                    xVar = xVarA2;
                                } else {
                                    arrayList.add(xVarA2);
                                }
                            } else {
                                arrayList.add(xVarA2);
                            }
                        }
                        it2 = it3;
                        linkedHashMap5 = linkedHashMap7;
                        linkedHashMap4 = linkedHashMap;
                    } else {
                        if (arrayList6.size() != arrayList4.size()) {
                            ArrayList arrayList8 = new ArrayList();
                            int size7 = arrayList4.size();
                            int i20 = 0;
                            while (i20 < size7) {
                                Object obj7 = arrayList4.get(i20);
                                i20++;
                                if (!surfaces.containsKey(new z.m1(((z.b0) obj7).f23319a))) {
                                    arrayList8.add(obj7);
                                }
                            }
                            throw new IllegalStateException(("Surfaces are not yet available for " + c0Var + "! Missing surfaces for " + arrayList8 + '!').toString());
                        }
                        arrayList.add(new x(outputConfigurationE2));
                        linkedHashMap = linkedHashMap4;
                    }
                    it2 = it3;
                    linkedHashMap5 = linkedHashMap7;
                    linkedHashMap4 = linkedHashMap;
                }
                return new s3(arrayList, linkedHashMap3, xVar, linkedHashMap4);
            }
            Map.Entry entry = (Map.Entry) it.next();
            int i21 = ((z.m1) entry.getKey()).f23375a;
            fVar = (f0.f) entry.getValue();
            b0VarA = f0Var.a(i21);
            if (b0VarA == null) {
                throw new IllegalStateException("Required value was null.");
            }
        } while (b0VarA.f23320b.size() == 1);
        if (Build.VERSION.SDK_INT < 31) {
            throw new IllegalArgumentException("Cannot configure multiple outputs pre-S!");
        }
        kotlin.jvm.internal.e0.a(f0.c.class);
        fVar.getClass();
        throw null;
    }
}
