package a0;

import android.content.ContentProviderClient;
import android.content.res.TypedArray;
import android.drm.DrmManagerClient;
import android.media.MediaDrm;
import android.media.MediaMetadataRetriever;
import android.os.SystemClock;
import android.os.Trace;
import android.util.Log;
import android.view.Surface;
import j$.util.DesugarCollections;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class i3 implements f2 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final d0.u f110a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final a3 f111b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final y4 f112c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final z.e0 f113d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final c0.l f114e;
    public final z.m f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final z.l1 f115g;
    public final c0.n h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final kotlinx.coroutines.p0 f116i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final int f117j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final Object f118k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final pj.e f119l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final Map f120m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final Map f121n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public c0.o f122o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final w4 f123p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public h2 f124q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public c3 f125r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public Object f126s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public LinkedHashMap f127t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public d3 f128u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final CountDownLatch f129v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public boolean f130w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final CountDownLatch f131x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public Map f132y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public final LinkedHashMap f133z;

    public i3(d0.u uVar, a3 captureSessionFactory, y4 y4Var, z.e0 cameraSurfaceManager, c0.l timeSource, z.m cameraGraphFlags, s4 s4Var, z.l1 l1Var, z.n1 strictMode, c0.n threads, kotlinx.coroutines.p0 scope) {
        kotlin.jvm.internal.q.g(captureSessionFactory, "captureSessionFactory");
        kotlin.jvm.internal.q.g(cameraSurfaceManager, "cameraSurfaceManager");
        kotlin.jvm.internal.q.g(timeSource, "timeSource");
        kotlin.jvm.internal.q.g(cameraGraphFlags, "cameraGraphFlags");
        kotlin.jvm.internal.q.g(strictMode, "strictMode");
        kotlin.jvm.internal.q.g(threads, "threads");
        kotlin.jvm.internal.q.g(scope, "scope");
        this.f110a = uVar;
        this.f111b = captureSessionFactory;
        this.f112c = y4Var;
        this.f113d = cameraSurfaceManager;
        this.f114e = timeSource;
        this.f = cameraGraphFlags;
        this.f115g = l1Var;
        this.h = threads;
        this.f116i = scope;
        this.f117j = j3.f148a.incrementAndGet();
        this.f118k = new Object();
        this.f119l = pj.b.atomic(Boolean.FALSE);
        this.f120m = DesugarCollections.synchronizedMap(new HashMap());
        this.f121n = DesugarCollections.synchronizedMap(new HashMap());
        this.f123p = null;
        this.f128u = d3.f70e;
        this.f129v = new CountDownLatch(1);
        this.f131x = new CountDownLatch(1);
        this.f133z = new LinkedHashMap();
    }

    /* JADX WARN: Code duplicated, block: B:100:0x012c A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:102:0x01be A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:104:0x01a8 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:38:0x00ac  */
    /* JADX WARN: Code duplicated, block: B:39:0x00b1  */
    /* JADX WARN: Code duplicated, block: B:41:0x00b4  */
    /* JADX WARN: Code duplicated, block: B:42:0x00b7  */
    /* JADX WARN: Code duplicated, block: B:45:0x00e4  */
    /* JADX WARN: Code duplicated, block: B:46:0x00e9  */
    /* JADX WARN: Code duplicated, block: B:51:0x010e  */
    /* JADX WARN: Code duplicated, block: B:53:0x0129  */
    /* JADX WARN: Code duplicated, block: B:62:0x013c A[Catch: all -> 0x01ca, TryCatch #2 {all -> 0x01ca, blocks: (B:55:0x012c, B:57:0x0132, B:60:0x0138, B:62:0x013c, B:64:0x0160, B:66:0x019b, B:67:0x01a8, B:69:0x01ae, B:71:0x01be, B:76:0x01cf, B:78:0x01d9, B:82:0x01e2, B:83:0x01f9, B:84:0x01fa), top: B:100:0x012c }] */
    /* JADX WARN: Code duplicated, block: B:64:0x0160 A[Catch: all -> 0x01ca, TryCatch #2 {all -> 0x01ca, blocks: (B:55:0x012c, B:57:0x0132, B:60:0x0138, B:62:0x013c, B:64:0x0160, B:66:0x019b, B:67:0x01a8, B:69:0x01ae, B:71:0x01be, B:76:0x01cf, B:78:0x01d9, B:82:0x01e2, B:83:0x01f9, B:84:0x01fa), top: B:100:0x012c }] */
    /* JADX WARN: Code duplicated, block: B:66:0x019b A[Catch: all -> 0x01ca, TryCatch #2 {all -> 0x01ca, blocks: (B:55:0x012c, B:57:0x0132, B:60:0x0138, B:62:0x013c, B:64:0x0160, B:66:0x019b, B:67:0x01a8, B:69:0x01ae, B:71:0x01be, B:76:0x01cf, B:78:0x01d9, B:82:0x01e2, B:83:0x01f9, B:84:0x01fa), top: B:100:0x012c }] */
    /* JADX WARN: Code duplicated, block: B:69:0x01ae A[Catch: all -> 0x01ca, TryCatch #2 {all -> 0x01ca, blocks: (B:55:0x012c, B:57:0x0132, B:60:0x0138, B:62:0x013c, B:64:0x0160, B:66:0x019b, B:67:0x01a8, B:69:0x01ae, B:71:0x01be, B:76:0x01cf, B:78:0x01d9, B:82:0x01e2, B:83:0x01f9, B:84:0x01fa), top: B:100:0x012c }] */
    /* JADX WARN: Code duplicated, block: B:74:0x01cc  */
    /* JADX WARN: Code duplicated, block: B:7:0x001c  */
    /* JADX WARN: Code duplicated, block: B:82:0x01e2 A[Catch: all -> 0x01ca, TRY_ENTER, TryCatch #2 {all -> 0x01ca, blocks: (B:55:0x012c, B:57:0x0132, B:60:0x0138, B:62:0x013c, B:64:0x0160, B:66:0x019b, B:67:0x01a8, B:69:0x01ae, B:71:0x01be, B:76:0x01cf, B:78:0x01d9, B:82:0x01e2, B:83:0x01f9, B:84:0x01fa), top: B:100:0x012c }] */
    /* JADX WARN: Instruction removed from duplicated block: B:51:0x010e, please report this as an issue */
    /* JADX WARN: Instruction removed from duplicated block: B:64:0x0160, please report this as an issue */
    /* JADX WARN: Instruction removed from duplicated block: B:82:0x01e2, please report this as an issue */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.Object, java.util.Map] */
    public static final Object i(i3 i3Var, wi.c cVar) {
        h3 h3Var;
        kotlin.jvm.internal.d0 d0Var;
        kotlin.jvm.internal.d0 d0Var2;
        kotlin.jvm.internal.d0 d0Var3;
        kotlin.jvm.internal.d0 d0Var4;
        h2 h2Var;
        String strY;
        String strB;
        h2 h2Var2;
        String strY2;
        z2 z2VarA;
        d3 d3Var;
        ?? r4;
        Map map;
        LinkedHashMap linkedHashMap;
        i3Var.getClass();
        if (cVar instanceof h3) {
            h3Var = (h3) cVar;
            int i10 = h3Var.f102r0;
            if ((i10 & Integer.MIN_VALUE) != 0) {
                h3Var.f102r0 = i10 - Integer.MIN_VALUE;
            } else {
                h3Var = new h3(i3Var, cVar);
            }
        } else {
            h3Var = new h3(i3Var, cVar);
        }
        Object obj = h3Var.Y;
        vi.a aVar = vi.a.f21252e;
        int i11 = h3Var.f102r0;
        try {
            if (i11 == 0) {
                g6.y.I(obj);
                d0Var = new kotlin.jvm.internal.d0();
                d0Var2 = new kotlin.jvm.internal.d0();
                synchronized (i3Var.f118k) {
                    if (i3Var.f128u != d3.f70e) {
                        return qi.b0.f17350a;
                    }
                    d0Var.f13951e = i3Var.f132y;
                    h2 h2Var3 = i3Var.f124q;
                    d0Var2.f13951e = h2Var3;
                    if (d0Var.f13951e != null && h2Var3 != null) {
                        i3Var.f128u = d3.X;
                        i3Var.f130w = true;
                        i3Var.f114e.getClass();
                        i3Var.f122o = new c0.o(SystemClock.elapsedRealtimeNanos());
                        w4 w4Var = i3Var.f123p;
                        if (w4Var != null) {
                            Log.d("CXCP", "Awaiting session lock");
                            h3Var.f101e = d0Var;
                            h3Var.X = d0Var2;
                            h3Var.f102r0 = 1;
                            if (w4Var.u(h3Var) == aVar) {
                                return aVar;
                            }
                            d0Var3 = d0Var;
                            d0Var4 = d0Var2;
                        }
                        StringBuilder sb2 = new StringBuilder("Creating CameraCaptureSession from ");
                        h2Var = (h2) d0Var2.f13951e;
                        if (h2Var != null) {
                            strY = h2Var.y();
                        } else {
                            strY = null;
                        }
                        if (strY == null) {
                            strB = kotlinx.serialization.json.internal.b.NULL;
                        } else {
                            strB = z.p.b(strY);
                        }
                        sb2.append((Object) strB);
                        sb2.append(" using ");
                        sb2.append(i3Var);
                        sb2.append(" with ");
                        sb2.append(d0Var.f13951e);
                        Log.i("CXCP", sb2.toString());
                        StringBuilder sb3 = new StringBuilder("CameraDevice-");
                        h2Var2 = (h2) d0Var2.f13951e;
                        if (h2Var2 != null) {
                            strY2 = h2Var2.y();
                        } else {
                            strY2 = null;
                        }
                        Trace.beginSection(f.r(sb3, strY2, "#createCaptureSession"));
                        a3 a3Var = i3Var.f111b;
                        Object obj2 = d0Var2.f13951e;
                        kotlin.jvm.internal.q.d(obj2);
                        Object obj3 = d0Var.f13951e;
                        kotlin.jvm.internal.q.d(obj3);
                        z2VarA = a3Var.a((h2) obj2, (Map) obj3, i3Var);
                        Trace.endSection();
                        if (!(z2VarA instanceof y2)) {
                            Log.e("CXCP", "Failed to create capture session for " + i3Var + '!');
                            return qi.b0.f17350a;
                        }
                        synchronized (i3Var.f118k) {
                            try {
                                d3Var = i3Var.f128u;
                                if (d3Var != d3.Z && d3Var != d3.f71r0) {
                                    if (d3Var == d3.X) {
                                        throw new IllegalStateException(("Unexpected state: " + i3Var.f128u).toString());
                                    }
                                    i3Var.f128u = d3.Y;
                                    Map map2 = i3Var.f120m;
                                    Object obj4 = d0Var.f13951e;
                                    kotlin.jvm.internal.q.d(obj4);
                                    map2.putAll((Map) obj4);
                                    i3Var.f121n.putAll(((y2) z2VarA).f393b);
                                    r4 = ((y2) z2VarA).f392a;
                                    if (!r4.isEmpty()) {
                                        Log.i("CXCP", "Created " + i3Var + " with " + ri.m.z0(((Map) d0Var.f13951e).keySet()) + ". Waiting to finalize " + ri.m.z0(r4.keySet()));
                                        i3Var.f126s = r4;
                                        map = i3Var.f132y;
                                        if (map != null) {
                                            linkedHashMap = new LinkedHashMap();
                                            for (Map.Entry entry : map.entrySet()) {
                                                if (r4.containsKey(entry.getKey())) {
                                                    linkedHashMap.put(entry.getKey(), entry.getValue());
                                                }
                                            }
                                        } else {
                                            linkedHashMap = null;
                                        }
                                        if (linkedHashMap != null && linkedHashMap.size() == r4.size()) {
                                            i3Var.f127t = linkedHashMap;
                                        }
                                    }
                                    i3Var.j(null);
                                    return qi.b0.f17350a;
                                }
                                Log.i("CXCP", "Warning: " + i3Var + " was " + i3Var.f128u + " while configuration was in progress.");
                                return qi.b0.f17350a;
                            } catch (Throwable th2) {
                                throw th2;
                            }
                        }
                    }
                    return qi.b0.f17350a;
                }
            }
            if (i11 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            d0Var4 = h3Var.X;
            d0Var3 = h3Var.f101e;
            g6.y.I(obj);
            Trace.beginSection(f.r(sb3, strY2, "#createCaptureSession"));
            a3 a3Var2 = i3Var.f111b;
            Object obj5 = d0Var2.f13951e;
            kotlin.jvm.internal.q.d(obj5);
            Object obj6 = d0Var.f13951e;
            kotlin.jvm.internal.q.d(obj6);
            z2VarA = a3Var2.a((h2) obj5, (Map) obj6, i3Var);
            Trace.endSection();
            if (!(z2VarA instanceof y2)) {
                Log.e("CXCP", "Failed to create capture session for " + i3Var + '!');
                return qi.b0.f17350a;
            }
            synchronized (i3Var.f118k) {
                d3Var = i3Var.f128u;
                if (d3Var != d3.Z) {
                    if (d3Var == d3.X) {
                        throw new IllegalStateException(("Unexpected state: " + i3Var.f128u).toString());
                    }
                    i3Var.f128u = d3.Y;
                    Map map3 = i3Var.f120m;
                    Object obj7 = d0Var.f13951e;
                    kotlin.jvm.internal.q.d(obj7);
                    map3.putAll((Map) obj7);
                    i3Var.f121n.putAll(((y2) z2VarA).f393b);
                    r4 = ((y2) z2VarA).f392a;
                    if (!r4.isEmpty()) {
                        Log.i("CXCP", "Created " + i3Var + " with " + ri.m.z0(((Map) d0Var.f13951e).keySet()) + ". Waiting to finalize " + ri.m.z0(r4.keySet()));
                        i3Var.f126s = r4;
                        map = i3Var.f132y;
                        if (map != null) {
                            linkedHashMap = new LinkedHashMap();
                            while (r12.hasNext()) {
                                if (r4.containsKey(entry.getKey())) {
                                    linkedHashMap.put(entry.getKey(), entry.getValue());
                                }
                            }
                        } else {
                            linkedHashMap = null;
                        }
                        if (linkedHashMap != null) {
                            i3Var.f127t = linkedHashMap;
                        }
                    }
                    i3Var.j(null);
                    return qi.b0.f17350a;
                }
                Log.i("CXCP", "Warning: " + i3Var + " was " + i3Var.f128u + " while configuration was in progress.");
                return qi.b0.f17350a;
            }
        } catch (Throwable th3) {
            Trace.endSection();
            throw th3;
        }
        d0Var = d0Var3;
        d0Var2 = d0Var4;
        StringBuilder sb4 = new StringBuilder("Creating CameraCaptureSession from ");
        h2Var = (h2) d0Var2.f13951e;
        if (h2Var != null) {
            strY = h2Var.y();
        } else {
            strY = null;
        }
        if (strY == null) {
            strB = kotlinx.serialization.json.internal.b.NULL;
        } else {
            strB = z.p.b(strY);
        }
        sb4.append((Object) strB);
        sb4.append(" using ");
        sb4.append(i3Var);
        sb4.append(" with ");
        sb4.append(d0Var.f13951e);
        Log.i("CXCP", sb4.toString());
        StringBuilder sb5 = new StringBuilder("CameraDevice-");
        h2Var2 = (h2) d0Var2.f13951e;
        if (h2Var2 != null) {
            strY2 = h2Var2.y();
        } else {
            strY2 = null;
        }
    }

    @Override // a0.x4
    public final void a() {
        if (this.f119l.compareAndSet(Boolean.FALSE, Boolean.TRUE)) {
            Log.d("CXCP", this + " session finalizing");
            Trace.beginSection(this + "#onSessionFinalized");
            o();
            n(0L);
            Trace.endSection();
        }
    }

    @Override // a0.f2
    public final void b(g2 g2Var) {
        Log.d("CXCP", this + " Active");
    }

    @Override // a0.x4
    public final void c() {
        Log.d("CXCP", this + " session disconnecting");
        Trace.beginSection(this + "#onSessionDisconnected");
        l();
        try {
            Trace.beginSection(this + "#onSessionDisconnected Await");
            this.f129v.await();
            Trace.endSection();
        } finally {
            Trace.endSection();
        }
    }

    @Override // a0.f2
    public final void d(g2 g2Var) {
        Log.w("CXCP", this + " Configuration Failed");
        Trace.beginSection(this + "#onConfigureFailed");
        this.f110a.a(new z.k0(9, false));
        o();
        this.f131x.countDown();
        w4 w4Var = this.f123p;
        if (w4Var != null) {
            w4Var.A();
        }
        Trace.endSection();
    }

    @Override // a0.f2
    public final void e(g2 g2Var) {
        Log.d("CXCP", this + " Configured");
        Trace.beginSection(this + "#configure");
        j(g2Var);
        this.f131x.countDown();
        w4 w4Var = this.f123p;
        if (w4Var != null) {
            w4Var.A();
        }
        Trace.endSection();
    }

    @Override // a0.f2
    public final void f(g2 g2Var) {
        Log.d("CXCP", this + " Ready");
    }

    @Override // a0.f2
    public final void g(g2 g2Var) {
        Log.d("CXCP", this + " CaptureQueueEmpty");
    }

    @Override // a0.f2
    public final void h(g2 g2Var) {
        Log.d("CXCP", this + " Closed");
        Trace.beginSection(this + "#onClosed");
        o();
        this.f131x.countDown();
        w4 w4Var = this.f123p;
        if (w4Var != null) {
            w4Var.A();
        }
        Trace.endSection();
    }

    public final void j(g2 g2Var) {
        synchronized (this.f118k) {
            try {
                c3 c3Var = this.f125r;
                if (c3Var == null && g2Var != null) {
                    y4 y4Var = this.f112c;
                    Map activeStreamSurfaceMap = this.f120m;
                    kotlin.jvm.internal.q.f(activeStreamSurfaceMap, "activeStreamSurfaceMap");
                    Map activeOutputSurfaceMap = this.f121n;
                    kotlin.jvm.internal.q.f(activeOutputSurfaceMap, "activeOutputSurfaceMap");
                    o1 o1VarN = y4Var.n(g2Var, activeStreamSurfaceMap, activeOutputSurfaceMap);
                    c3 c3Var2 = new c3(g2Var, new d0.v(o1VarN), o1VarN);
                    this.f125r = c3Var2;
                    c3Var = c3Var2;
                }
                if (this.f128u == d3.Y && c3Var != null) {
                    boolean z5 = (this.f126s == null || this.f127t == null) ? false : true;
                    if (z5) {
                        m(false);
                    }
                    synchronized (this.f118k) {
                        this.f114e.getClass();
                        long jElapsedRealtimeNanos = SystemClock.elapsedRealtimeNanos();
                        c0.o oVar = this.f122o;
                        kotlin.jvm.internal.q.d(oVar);
                        Log.i("CXCP", "Configured " + this + " in " + String.format(null, "%.3f ms", Arrays.copyOf(new Object[]{Double.valueOf((jElapsedRealtimeNanos - oVar.f3847a) / 1000000.0d)}, 1)));
                        this.f110a.b(c3Var.f33b);
                    }
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.Object, java.util.Map] */
    public final void k(Map surfaces) {
        kotlin.jvm.internal.q.g(surfaces, "surfaces");
        synchronized (this.f118k) {
            try {
                d3 d3Var = this.f128u;
                if (d3Var != d3.Z && d3Var != d3.f71r0) {
                    Map map = this.f132y;
                    if (map == null) {
                        map = ri.t.f18051e;
                    }
                    p(map, surfaces);
                    this.f132y = surfaces;
                    ?? r4 = this.f126s;
                    ui.d dVar = null;
                    if (r4 != 0 && this.f127t == null) {
                        LinkedHashMap linkedHashMap = new LinkedHashMap();
                        for (Map.Entry entry : surfaces.entrySet()) {
                            if (r4.containsKey(entry.getKey())) {
                                linkedHashMap.put(entry.getKey(), entry.getValue());
                            }
                        }
                        if (linkedHashMap.size() == r4.size()) {
                            this.f127t = linkedHashMap;
                            kotlinx.coroutines.k.launch$default(this.f116i, null, null, new f3(this, dVar, 0), 3, null);
                        }
                    }
                    kotlinx.coroutines.k.launch$default(this.f116i, null, null, new e3(this, dVar, 1), 3, null);
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    public final void l() {
        synchronized (this.f118k) {
            try {
                d3 d3Var = this.f128u;
                d3 d3Var2 = d3.Z;
                if (d3Var != d3Var2 && d3Var != d3.f71r0) {
                    this.f128u = d3Var2;
                    c3 c3Var = this.f125r;
                    ui.d dVar = null;
                    boolean z5 = false;
                    if (c3Var != null) {
                        this.f125r = null;
                    } else {
                        if (this.f.f23372d && this.f130w) {
                            z5 = true;
                        }
                        c3Var = null;
                    }
                    w4 w4Var = this.f123p;
                    if (w4Var != null) {
                        w4Var.A();
                    }
                    if (z5) {
                        Log.d("CXCP", "Waiting for CameraCaptureSession configuration");
                        if (((qi.b0) this.h.b(3000L, new s2(this, dVar, 1))) == null) {
                            Log.e("CXCP", "Waiting for CameraCaptureSession configuration timed out");
                        }
                        synchronized (this.f118k) {
                            c3Var = this.f125r;
                            this.f125r = null;
                        }
                    }
                    Trace.beginSection(this.f110a + "#onGraphStopping");
                    d0.u uVar = this.f110a;
                    Log.d("CXCP", uVar + " onGraphStopping");
                    uVar.f6581d.setValue(z.n0.f23377b);
                    uVar.f6579b.H(null);
                    for (r.w wVar : uVar.f6580c) {
                        wVar.f17671a.b(wVar.a(), z.n0.f23377b);
                    }
                    Trace.endSection();
                    if (c3Var != null) {
                        d0.v vVar = c3Var.f33b;
                        Log.d("CXCP", this + " Shutdown");
                        Trace.beginSection(this + "#shutdown");
                        if (this.f.f23369a && ((qi.b0) this.h.b(2000L, new v1(this, vVar, dVar, 2))) == null) {
                            Log.e("CXCP", "Failed to abort captures in 2000ms");
                        }
                        Trace.beginSection(this + "#disconnect");
                        c3Var.f34c.d();
                        Trace.endSection();
                        if (this.f.f23372d && ((qi.b0) this.h.b(3000L, new v1(this, c3Var, dVar, 1))) == null) {
                            Log.e("CXCP", "Failed to close the capture session in 3000ms");
                        }
                        Trace.beginSection(this.f110a + "#onGraphStopped");
                        this.f110a.c();
                        Trace.endSection();
                        Trace.endSection();
                    } else {
                        Trace.beginSection(this.f110a + "#onGraphStopped");
                        this.f110a.c();
                        Trace.endSection();
                    }
                    this.f129v.countDown();
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    /* JADX WARN: Type inference failed for: r2v0, types: [java.lang.Object, java.util.Map] */
    public final void m(boolean z5) {
        c3 c3Var;
        ?? r4;
        LinkedHashMap linkedHashMap;
        boolean z6;
        synchronized (this.f118k) {
            c3Var = this.f125r;
            r4 = this.f126s;
            linkedHashMap = this.f127t;
        }
        if (c3Var == null || r4 == 0 || linkedHashMap == null) {
            return;
        }
        Trace.beginSection(this + "#finalizeOutputConfigurations");
        this.f114e.getClass();
        long jElapsedRealtimeNanos = SystemClock.elapsedRealtimeNanos();
        for (Map.Entry entry : r4.entrySet()) {
            int i10 = ((z.m1) entry.getKey()).f23375a;
            r3 r3Var = (r3) entry.getValue();
            Object obj = linkedHashMap.get(new z.m1(i10));
            if (obj == null) {
                throw new IllegalStateException("Required value was null.");
            }
            ((x) r3Var).a((Surface) obj);
        }
        LinkedHashSet linkedHashSet = new LinkedHashSet();
        Iterator it = r4.entrySet().iterator();
        while (it.hasNext()) {
            linkedHashSet.add((r3) ((Map.Entry) it.next()).getValue());
        }
        c3Var.f32a.f0(ri.m.z0(linkedHashSet));
        synchronized (this.f118k) {
            try {
                z6 = false;
                if (this.f128u == d3.Y) {
                    this.f120m.putAll(linkedHashMap);
                    for (Map.Entry entry2 : linkedHashMap.entrySet()) {
                        int i11 = ((z.m1) entry2.getKey()).f23375a;
                        Surface surface = (Surface) entry2.getValue();
                        z.b0 b0VarA = ((d0.f0) this.f115g).a(i11);
                        if (b0VarA == null) {
                            throw new IllegalStateException("Required value was null.");
                        }
                        if (b0VarA.f23320b.size() != 1) {
                            throw new IllegalStateException("Cannot finalize a multi-output stream!");
                        }
                        Map activeOutputSurfaceMap = this.f121n;
                        kotlin.jvm.internal.q.f(activeOutputSurfaceMap, "activeOutputSurfaceMap");
                        activeOutputSurfaceMap.put(new z.t0(((d0.d0) ri.m.t0(b0VarA.f23320b)).f6513a), surface);
                    }
                    this.f114e.getClass();
                    long jElapsedRealtimeNanos2 = SystemClock.elapsedRealtimeNanos() - jElapsedRealtimeNanos;
                    StringBuilder sb2 = new StringBuilder();
                    sb2.append("Finalized ");
                    ArrayList arrayList = new ArrayList(r4.size());
                    Iterator it2 = r4.entrySet().iterator();
                    while (it2.hasNext()) {
                        arrayList.add(new z.m1(((z.m1) ((Map.Entry) it2.next()).getKey()).f23375a));
                    }
                    sb2.append(arrayList);
                    sb2.append(" for ");
                    sb2.append(this);
                    sb2.append(" in ");
                    sb2.append(String.format(null, "%.3f ms", Arrays.copyOf(new Object[]{Double.valueOf(jElapsedRealtimeNanos2 / 1000000.0d)}, 1)));
                    Log.i("CXCP", sb2.toString());
                    z6 = true;
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
        if (z6 && z5) {
            d0.u uVar = this.f110a;
            Log.d("CXCP", uVar + " onGraphModified");
            uVar.f6579b.u0.y(d0.g.f6543b);
        }
        Trace.endSection();
    }

    public final void n(long j10) {
        List<AutoCloseable> listZ0;
        if (j10 != 0) {
            kotlinx.coroutines.k.launch$default(this.f116i, null, null, new g3(j10, this, null), 3, null);
            return;
        }
        Log.d("CXCP", "Finalizing " + this);
        synchronized (this.f118k) {
            listZ0 = ri.m.z0(this.f133z.values());
            this.f133z.clear();
        }
        for (AutoCloseable autoCloseable : listZ0) {
            if (autoCloseable instanceof AutoCloseable) {
                autoCloseable.close();
            } else if (autoCloseable instanceof ExecutorService) {
                w.g((ExecutorService) autoCloseable);
            } else if (autoCloseable instanceof TypedArray) {
                ((TypedArray) autoCloseable).recycle();
            } else if (autoCloseable instanceof MediaMetadataRetriever) {
                ((MediaMetadataRetriever) autoCloseable).release();
            } else if (autoCloseable instanceof MediaDrm) {
                ((MediaDrm) autoCloseable).release();
            } else if (autoCloseable instanceof DrmManagerClient) {
                ((DrmManagerClient) autoCloseable).release();
            } else {
                if (!(autoCloseable instanceof ContentProviderClient)) {
                    throw new IllegalArgumentException();
                }
                ((ContentProviderClient) autoCloseable).release();
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:19:0x0027  */
    public final void o() {
        long j10;
        boolean z5;
        int i10;
        l();
        synchronized (this.f118k) {
            try {
                d3 d3Var = this.f128u;
                d3 d3Var2 = d3.f71r0;
                j10 = 0;
                if (d3Var != d3Var2) {
                    z5 = true;
                    if (this.f124q != null && this.f130w && (i10 = this.f.f23371c) != 1) {
                        if (i10 == 2) {
                            j10 = 2000;
                        } else {
                            z5 = false;
                        }
                    }
                } else {
                    z5 = false;
                }
                this.f124q = null;
                this.f128u = d3Var2;
            } catch (Throwable th2) {
                throw th2;
            }
        }
        if (z5) {
            n(j10);
        }
    }

    public final void p(Map map, Map map2) throws Exception {
        Surface surface;
        AutoCloseable autoCloseable;
        Set setE0 = ri.m.E0(map.values());
        Set setE1 = ri.m.E0(map2.values());
        Iterator it = m7.f.o(setE0, setE1).iterator();
        do {
            boolean zHasNext = it.hasNext();
            LinkedHashMap linkedHashMap = this.f133z;
            if (!zHasNext) {
                for (Surface surface2 : m7.f.o(setE1, setE0)) {
                    linkedHashMap.put(surface2, this.f113d.a(surface2));
                }
                return;
            }
            surface = (Surface) it.next();
            autoCloseable = (AutoCloseable) linkedHashMap.remove(surface);
            if (autoCloseable == null) {
                autoCloseable = null;
            } else if (autoCloseable instanceof AutoCloseable) {
                autoCloseable.close();
            } else if (autoCloseable instanceof ExecutorService) {
                w.g((ExecutorService) autoCloseable);
            } else if (autoCloseable instanceof TypedArray) {
                ((TypedArray) autoCloseable).recycle();
            } else if (autoCloseable instanceof MediaMetadataRetriever) {
                ((MediaMetadataRetriever) autoCloseable).release();
            } else if (autoCloseable instanceof MediaDrm) {
                ((MediaDrm) autoCloseable).release();
            } else if (autoCloseable instanceof DrmManagerClient) {
                ((DrmManagerClient) autoCloseable).release();
            } else {
                if (!(autoCloseable instanceof ContentProviderClient)) {
                    throw new IllegalArgumentException();
                }
                ((ContentProviderClient) autoCloseable).release();
            }
        } while (autoCloseable != null);
        throw new IllegalStateException(("Surface " + surface + " doesn't have a matching surface token!").toString());
    }

    public final String toString() {
        return "CaptureSessionState-" + this.f117j;
    }
}
