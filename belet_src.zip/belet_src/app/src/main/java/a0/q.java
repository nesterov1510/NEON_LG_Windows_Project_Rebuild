package a0;

import android.util.Log;
import java.util.ArrayList;
import java.util.Map;
import java.util.Set;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class q implements a3 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final c0.n f276a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final z.k f277b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final d0.f0 f278c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final c2 f279d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final z.n1 f280e;

    public q(c0.n threads, z.k graphConfig, d0.f0 f0Var, c2 camera2MetadataProvider, z.n1 strictMode) {
        kotlin.jvm.internal.q.g(threads, "threads");
        kotlin.jvm.internal.q.g(graphConfig, "graphConfig");
        kotlin.jvm.internal.q.g(camera2MetadataProvider, "camera2MetadataProvider");
        kotlin.jvm.internal.q.g(strictMode, "strictMode");
        this.f276a = threads;
        this.f277b = graphConfig;
        this.f278c = f0Var;
        this.f279d = camera2MetadataProvider;
        this.f280e = strictMode;
    }

    /* JADX WARN: Type inference failed for: r2v10, types: [java.lang.Object, qi.f] */
    /* JADX WARN: Type inference failed for: r2v2, types: [java.lang.Object, qi.f] */
    @Override // a0.a3
    public final z2 a(h2 cameraDevice, Map surfaces, i3 captureSessionState) throws Exception {
        z.j jVarD;
        kotlin.jvm.internal.q.g(cameraDevice, "cameraDevice");
        kotlin.jvm.internal.q.g(surfaces, "surfaces");
        kotlin.jvm.internal.q.g(captureSessionState, "captureSessionState");
        z.k kVar = this.f277b;
        if (kVar.h != 2) {
            throw new IllegalArgumentException("Unsupported session mode: " + ((Object) android.support.v4.media.session.b.I(this.f277b.h)) + " for Extension CameraGraph");
        }
        Object obj = kVar.f23355g.get(j2.f145a);
        Integer num = obj instanceof Integer ? (Integer) obj : null;
        if (num == null) {
            throw new IllegalStateException("The CameraPipeKeys.camera2ExtensionMode must be set in the sessionParameters of the CameraGraph.Config when creating an Extension CameraGraph.");
        }
        int iIntValue = num.intValue();
        if (this.f277b.f23353d != null) {
            throw new IllegalStateException("Reprocessing is not supported for Extensions");
        }
        h1 h1Var = (h1) ((b2) this.f279d).e(cameraDevice.y());
        Set set = (Set) h1Var.f99t0.getValue();
        z.n1 n1Var = this.f280e;
        if (!set.contains(Integer.valueOf(iIntValue))) {
            n1Var.getClass();
            Log.w("CXCP", cameraDevice + " does not support extension mode " + iIntValue + ". Supported extensions are " + set);
        }
        if (this.f277b.f23354e != null) {
            synchronized (h1Var.f98s0) {
                jVarD = (z.j) h1Var.f98s0.get(Integer.valueOf(iIntValue));
            }
            if (jVarD == null) {
                jVarD = h1Var.Y.d(iIntValue, h1Var.f96e);
                synchronized (h1Var.f98s0) {
                    h1Var.f98s0.put(Integer.valueOf(iIntValue), jVarD);
                }
            }
            z.n1 n1Var2 = this.f280e;
            if (!((Boolean) ((f1) jVarD).Z.getValue()).booleanValue()) {
                n1Var2.getClass();
                Log.w("CXCP", cameraDevice + " does not support Postview streams");
            }
            if (this.f277b.f23354e.f23311a.size() != 1) {
                throw new IllegalStateException("Postview streams can only have one OutputStream.config object");
            }
        }
        s3 s3VarB = b3.b(this.f277b, this.f278c, surfaces);
        if (s3VarB.f320a.isEmpty()) {
            Log.w("CXCP", "Failed to create OutputConfigurations for " + this.f277b);
            captureSessionState.a();
            return x2.f381a;
        }
        if (!s3VarB.f321b.isEmpty()) {
            throw new IllegalStateException("Deferred output is not supported for Extensions");
        }
        o3 o3Var = new o3(captureSessionState);
        ArrayList arrayList = s3VarB.f320a;
        c0.e eVar = new c0.e(this.f276a.a(), 0);
        z.k kVar2 = this.f277b;
        if (cameraDevice.v(new n3(arrayList, eVar, captureSessionState, kVar2.f, kVar2.f23355g, Integer.valueOf(iIntValue), o3Var, s3VarB.f322c))) {
            return new y2(s3VarB.f321b, s3VarB.f323d);
        }
        Log.w("CXCP", "Failed to create ExtensionCaptureSession from " + cameraDevice + " for " + captureSessionState + '!');
        captureSessionState.a();
        return x2.f381a;
    }
}
