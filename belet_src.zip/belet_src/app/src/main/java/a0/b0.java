package a0;

import android.hardware.camera2.params.SessionConfiguration;
import java.util.ArrayList;
import java.util.concurrent.Executor;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public abstract /* synthetic */ class b0 {
    public static /* synthetic */ SessionConfiguration a(int i10, ArrayList arrayList, Executor executor, o oVar) {
        return new SessionConfiguration(i10, arrayList, executor, oVar);
    }
}
