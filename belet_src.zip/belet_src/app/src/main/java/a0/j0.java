package a0;

import android.hardware.camera2.params.OutputConfiguration;
import android.hardware.camera2.params.SessionConfiguration;
import android.util.Size;
import java.util.List;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public abstract /* synthetic */ class j0 {
    public static /* synthetic */ OutputConfiguration a(int i10, Size size) {
        return new OutputConfiguration(i10, size);
    }

    public static /* synthetic */ SessionConfiguration b(int i10, List list) {
        return new SessionConfiguration(i10, list);
    }
}
