package a0;

import android.hardware.camera2.CameraDevice;
import android.os.Build;
import android.os.SystemClock;
import android.os.Trace;
import android.util.Log;
import java.util.Arrays;
import java.util.concurrent.CountDownLatch;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class m extends CameraDevice.StateCallback {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f178a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final z.s f179b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f180c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final long f181d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final c0.l f182e;
    public final a2 f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final x1 f183g;
    public final d2 h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final c0.n f184i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final n0 f185j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final CameraDevice.StateCallback f186k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final m7.c f187l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final int f188m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final Object f189n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public boolean f190o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public l f191p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public boolean f192q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final CountDownLatch f193r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final long f194s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public c0.o f195t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final kotlinx.coroutines.flow.h0 f196u;

    public m(String cameraId, z.s metadata, int i10, long j10, c0.l timeSource, a2 cameraErrorListener, x1 camera2DeviceCloser, d2 camera2Quirks, c0.n threads, n0 audioRestrictionController, CameraDevice.StateCallback stateCallback, m7.c cVar) {
        kotlin.jvm.internal.q.g(cameraId, "cameraId");
        kotlin.jvm.internal.q.g(metadata, "metadata");
        kotlin.jvm.internal.q.g(timeSource, "timeSource");
        kotlin.jvm.internal.q.g(cameraErrorListener, "cameraErrorListener");
        kotlin.jvm.internal.q.g(camera2DeviceCloser, "camera2DeviceCloser");
        kotlin.jvm.internal.q.g(camera2Quirks, "camera2Quirks");
        kotlin.jvm.internal.q.g(threads, "threads");
        kotlin.jvm.internal.q.g(audioRestrictionController, "audioRestrictionController");
        this.f178a = cameraId;
        this.f179b = metadata;
        this.f180c = i10;
        this.f181d = j10;
        this.f182e = timeSource;
        this.f = cameraErrorListener;
        this.f183g = camera2DeviceCloser;
        this.h = camera2Quirks;
        this.f184i = threads;
        this.f185j = audioRestrictionController;
        this.f186k = stateCallback;
        this.f187l = cVar;
        this.f188m = a5.f9b.incrementAndGet();
        this.f189n = new Object();
        this.f193r = new CountDownLatch(1);
        this.f196u = kotlinx.coroutines.flow.z0.MutableStateFlow(w2.f374a);
        Log.i("CXCP", "Opening " + ((Object) z.p.b(cameraId)));
        this.f194s = i10 != 1 ? SystemClock.elapsedRealtimeNanos() : j10;
    }

    public static boolean e(d2 d2Var, String cameraId, z.i iVar) {
        d2Var.getClass();
        kotlin.jvm.internal.q.g(cameraId, "cameraId");
        d2Var.f69b.getClass();
        int i10 = Build.VERSION.SDK_INT;
        if (24 > i10 || i10 >= 29) {
            return false;
        }
        z.r rVar = z.s.f23390q0;
        z.s sVarE = ((b2) d2Var.f68a).e(cameraId);
        rVar.getClass();
        return z.r.c(sVarE) && iVar == null;
    }

    public final void a() {
        l2 l2Var = (l2) this.f196u.getValue();
        h2 h2Var = l2Var instanceof o2 ? ((o2) l2Var).f256a : null;
        b(h2Var != null ? (CameraDevice) h2Var.D(kotlin.jvm.internal.e0.a(CameraDevice.class)) : null, new l(k3.f159e, null, null, 14));
    }

    /* JADX WARN: Code duplicated, block: B:15:0x0027  */
    public final void b(CameraDevice cameraDevice, l lVar) throws Throwable {
        Throwable th2;
        m mVar;
        l2 l2Var = (l2) this.f196u.getValue();
        h2 h2Var = l2Var instanceof o2 ? ((o2) l2Var).f256a : null;
        synchronized (this.f189n) {
            try {
                if (this.f191p == null) {
                    try {
                        this.f191p = lVar;
                        if (this.f190o) {
                            lVar = null;
                        }
                    } catch (Throwable th3) {
                        th2 = th3;
                        throw th2;
                    }
                } else {
                    lVar = null;
                }
                if (lVar != null) {
                    z.i iVar = lVar.f166c;
                    if (iVar != null && lVar.f164a != k3.f161s0) {
                        this.f.a(this.f178a, false, iVar.f23344a);
                    }
                    this.f196u.setValue(new n2(lVar.f166c));
                    if (lVar.f164a != k3.Y) {
                        d2 d2Var = this.h;
                        String str = this.f178a;
                        boolean z5 = e(d2Var, str, lVar.f166c) && d2Var.a(str);
                        if (z5) {
                            synchronized (this.f189n) {
                                this.f192q = true;
                            }
                        }
                        mVar = this;
                        this.f183g.b(h2Var, cameraDevice, mVar, this.f185j, z5, e(this.h, this.f178a, lVar.f166c));
                    } else {
                        mVar = this;
                    }
                    mVar.f196u.setValue(c(lVar));
                }
            } catch (Throwable th4) {
                th2 = th4;
            }
        }
    }

    public final m2 c(l lVar) {
        this.f182e.getClass();
        long jElapsedRealtimeNanos = SystemClock.elapsedRealtimeNanos();
        c0.o oVar = this.f195t;
        long j10 = lVar.f165b;
        c0.d dVar = oVar != null ? new c0.d(oVar.f3847a - this.f181d) : null;
        c0.d dVar2 = oVar != null ? new c0.d(oVar.f3847a - this.f194s) : null;
        c0.d dVar3 = oVar == null ? null : new c0.d(j10 - oVar.f3847a);
        long j11 = jElapsedRealtimeNanos - j10;
        k3 k3Var = lVar.f164a;
        int i10 = this.f180c - 1;
        return new m2(this.f178a, k3Var, Integer.valueOf(i10), dVar, lVar.f167d, dVar2, dVar3, new c0.d(j11), lVar.f166c);
    }

    public final void d(CameraDevice cameraDevice) throws Throwable {
        Trace.beginSection(((Object) z.p.b(this.f178a)) + "#onFinalized");
        Log.d("CXCP", this + ": onFinalized");
        b(cameraDevice, new l(k3.Y, null, null, 14));
        CameraDevice.StateCallback stateCallback = this.f186k;
        if (stateCallback != null) {
            stateCallback.onClosed(cameraDevice);
        }
        Trace.endSection();
    }

    @Override // android.hardware.camera2.CameraDevice.StateCallback
    public final void onClosed(CameraDevice cameraDevice) throws Throwable {
        kotlin.jvm.internal.q.g(cameraDevice, "cameraDevice");
        if (!kotlin.jvm.internal.q.c(cameraDevice.getId(), this.f178a)) {
            throw new IllegalStateException("Check failed.");
        }
        Log.d("CXCP", ((Object) z.p.b(this.f178a)) + ": onClosed");
        this.f193r.countDown();
        synchronized (this.f189n) {
            if (!this.f192q) {
                d(cameraDevice);
                return;
            }
            Log.i("CXCP", this + "#onClosed: Delaying finalizing.");
        }
    }

    @Override // android.hardware.camera2.CameraDevice.StateCallback
    public final void onDisconnected(CameraDevice cameraDevice) throws Throwable {
        kotlin.jvm.internal.q.g(cameraDevice, "cameraDevice");
        String id2 = cameraDevice.getId();
        String str = this.f178a;
        if (!kotlin.jvm.internal.q.c(id2, str)) {
            throw new IllegalStateException("Check failed.");
        }
        Trace.beginSection(((Object) z.p.b(str)) + "#onDisconnected");
        Log.d("CXCP", ((Object) z.p.b(str)) + ": onDisconnected");
        this.f193r.countDown();
        b(cameraDevice, new l(k3.Z, new z.i(6), null, 10));
        CameraDevice.StateCallback stateCallback = this.f186k;
        if (stateCallback != null) {
            stateCallback.onDisconnected(cameraDevice);
        }
        Trace.endSection();
    }

    @Override // android.hardware.camera2.CameraDevice.StateCallback
    public final void onError(CameraDevice cameraDevice, int i10) throws Throwable {
        kotlin.jvm.internal.q.g(cameraDevice, "cameraDevice");
        String id2 = cameraDevice.getId();
        String str = this.f178a;
        if (!kotlin.jvm.internal.q.c(id2, str)) {
            throw new IllegalStateException("Check failed.");
        }
        Trace.beginSection(((Object) z.p.b(str)) + "#onError-" + i10);
        Log.d("CXCP", ((Object) z.p.b(str)) + ": onError " + i10);
        this.f193r.countDown();
        k3 k3Var = k3.f160r0;
        int i11 = 1;
        if (i10 != 1) {
            i11 = 2;
            if (i10 != 2) {
                i11 = 3;
                if (i10 != 3) {
                    i11 = 4;
                    if (i10 != 4) {
                        i11 = 5;
                        if (i10 != 5) {
                            throw new IllegalArgumentException(kotlin.jvm.internal.p.z(i10, "Unexpected StateCallback error code: "));
                        }
                    }
                }
            }
        }
        b(cameraDevice, new l(k3Var, new z.i(i11), null, 10));
        CameraDevice.StateCallback stateCallback = this.f186k;
        if (stateCallback != null) {
            stateCallback.onError(cameraDevice, i10);
        }
        Trace.endSection();
    }

    @Override // android.hardware.camera2.CameraDevice.StateCallback
    public final void onOpened(CameraDevice cameraDevice) {
        String strI;
        l lVar;
        l lVar2;
        kotlin.jvm.internal.q.g(cameraDevice, "cameraDevice");
        if (!kotlin.jvm.internal.q.c(cameraDevice.getId(), this.f178a)) {
            throw new IllegalStateException("Check failed.");
        }
        this.f182e.getClass();
        long jElapsedRealtimeNanos = SystemClock.elapsedRealtimeNanos();
        this.f195t = new c0.o(jElapsedRealtimeNanos);
        Trace.beginSection(((Object) z.p.b(this.f178a)) + "#onOpened");
        long j10 = jElapsedRealtimeNanos - this.f194s;
        long j11 = jElapsedRealtimeNanos - this.f181d;
        if (this.f180c == 1) {
            StringBuilder sb2 = new StringBuilder("Opened ");
            sb2.append((Object) z.p.b(this.f178a));
            sb2.append(" in ");
            strI = f.s(new Object[]{Double.valueOf(j10 / 1000000.0d)}, 1, null, "%.3f ms", sb2);
        } else {
            StringBuilder sb3 = new StringBuilder("Opened ");
            sb3.append((Object) z.p.b(this.f178a));
            sb3.append(" in ");
            sb3.append(String.format(null, "%.3f ms", Arrays.copyOf(new Object[]{Double.valueOf(j10 / 1000000.0d)}, 1)));
            sb3.append(" (");
            sb3.append(String.format(null, "%.3f ms", Arrays.copyOf(new Object[]{Double.valueOf(j11 / 1000000.0d)}, 1)));
            sb3.append(" total) after ");
            strI = p0.e.i(this.f180c, " attempts.", sb3);
        }
        Log.i("CXCP", strI);
        synchronized (this.f189n) {
            lVar = this.f191p;
            if (lVar == null) {
                this.f190o = true;
            }
        }
        CameraDevice.StateCallback stateCallback = this.f186k;
        if (stateCallback != null) {
            stateCallback.onOpened(cameraDevice);
        }
        if (lVar != null) {
            x1 x1Var = this.f183g;
            n0 n0Var = this.f185j;
            d2 d2Var = this.h;
            String str = this.f178a;
            x1Var.b(null, cameraDevice, this, n0Var, e(d2Var, str, lVar.f166c) && d2Var.a(str), e(this.h, this.f178a, lVar.f166c));
            return;
        }
        i iVar = new i(this.f179b, cameraDevice, this.f178a, this.f, this.f187l, this.f184i);
        this.f185j.a(iVar);
        this.f196u.setValue(new o2(iVar));
        synchronized (this.f189n) {
            this.f190o = false;
            lVar2 = this.f191p;
        }
        if (lVar2 != null) {
            this.f196u.setValue(new n2(lVar2.f166c));
            x1 x1Var2 = this.f183g;
            n0 n0Var2 = this.f185j;
            d2 d2Var2 = this.h;
            String str2 = this.f178a;
            x1Var2.b(iVar, cameraDevice, this, n0Var2, e(d2Var2, str2, lVar2.f166c) && d2Var2.a(str2), e(this.h, this.f178a, lVar2.f166c));
            this.f196u.setValue(c(lVar2));
        }
        Trace.endSection();
    }

    public final String toString() {
        return "CameraState-" + this.f188m;
    }
}
