package a0;

import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraDevice;
import android.os.Build;
import android.os.Trace;
import android.util.Log;
import android.view.Surface;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class x1 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final c0.n f378a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final d2 f379b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final r4 f380c;

    public x1(c0.n threads, d2 camera2Quirks, r4 retryingCameraStateOpener) {
        kotlin.jvm.internal.q.g(threads, "threads");
        kotlin.jvm.internal.q.g(camera2Quirks, "camera2Quirks");
        kotlin.jvm.internal.q.g(retryingCameraStateOpener, "retryingCameraStateOpener");
        this.f378a = threads;
        this.f379b = camera2Quirks;
        this.f380c = retryingCameraStateOpener;
    }

    public static final void a(x1 x1Var, h2 h2Var) throws InterruptedException {
        SurfaceTexture surfaceTexture = new SurfaceTexture(0);
        surfaceTexture.setDefaultBufferSize(640, 480);
        Surface surface = new Surface(surfaceTexture);
        pj.a aVarAtomic = pj.b.atomic(false);
        CountDownLatch countDownLatch = new CountDownLatch(1);
        if (h2Var.X(jd.t1.z(surface), new w1(countDownLatch, aVarAtomic, surface, surfaceTexture))) {
            countDownLatch.await();
            return;
        }
        Log.e("CXCP", "Failed to create a blank capture session! Surfaces may not be disconnected properly.");
        if (aVarAtomic.compareAndSet(false, true)) {
            surface.release();
            surfaceTexture.release();
        }
    }

    public final void b(h2 listener, CameraDevice cameraDevice, m mVar, n0 audioRestrictionController, boolean z5, boolean z6) {
        o0 o0Var;
        kotlin.jvm.internal.q.g(audioRestrictionController, "audioRestrictionController");
        qi.i iVar = null;
        CameraDevice cameraDevice2 = listener != null ? (CameraDevice) listener.D(kotlin.jvm.internal.e0.a(CameraDevice.class)) : null;
        if (cameraDevice2 == null) {
            if (cameraDevice != null) {
                c(cameraDevice, mVar);
                return;
            }
            return;
        }
        String id2 = cameraDevice2.getId();
        kotlin.jvm.internal.q.f(id2, "getId(...)");
        z.p.a(id2);
        if (cameraDevice != null && !id2.equals(cameraDevice.getId())) {
            StringBuilder sbM = com.google.protobuf.m0.m("Unwrapped camera device has camera ID ", id2, ", but the wrapped camera device has camera ID ");
            sbM.append(cameraDevice.getId());
            sbM.append('!');
            throw new IllegalStateException(sbM.toString().toString());
        }
        int i10 = Build.VERSION.SDK_INT;
        if (i10 >= 30) {
            kotlin.jvm.internal.q.g(listener, "listener");
            if (i10 >= 30) {
                audioRestrictionController.f224e.remove(listener);
            }
        }
        Log.d("CXCP", "handleQuirksBeforeClosing(" + cameraDevice2 + ')');
        String strY = listener.y();
        if (z5) {
            try {
                Trace.beginSection("Camera2DeviceCloserImpl#reopenCameraDevice");
                Log.d("CXCP", "Reopening camera device");
                c(cameraDevice2, mVar);
                o0Var = this.f380c.a(strY, this);
                Trace.endSection();
            } catch (Throwable th2) {
                Trace.endSection();
                throw th2;
            }
        } else {
            o0Var = new o0(listener, mVar);
        }
        h2 h2Var = o0Var.f243a;
        m mVar2 = o0Var.f244b;
        if (h2Var == null || mVar2 == null) {
            Log.e("CXCP", "Failed to retain an opened camera device!");
        } else {
            if (z6) {
                try {
                    Trace.beginSection("Camera2DeviceCloserImpl#createCaptureSession");
                    Log.d("CXCP", "Creating an empty capture session before closing " + ((Object) z.p.b(strY)));
                    a(this, h2Var);
                    Log.d("CXCP", "Created an empty capture session.");
                    Trace.endSection();
                } catch (Throwable th3) {
                    Trace.endSection();
                    throw th3;
                }
            }
            iVar = new qi.i(h2Var, mVar2);
        }
        if (iVar == null) {
            Log.e("CXCP", "Failed to handle quirks before closing the camera device!");
            listener.K();
            listener.i0();
            mVar.d(cameraDevice2);
            return;
        }
        h2 h2Var2 = (h2) iVar.f17355e;
        m mVar3 = (m) iVar.X;
        Object objD = h2Var2.D(kotlin.jvm.internal.e0.a(CameraDevice.class));
        if (objD == null) {
            throw new IllegalStateException("Required value was null.");
        }
        listener.K();
        c((CameraDevice) objD, mVar3);
        listener.i0();
        if (z5) {
            mVar.d(cameraDevice2);
        }
    }

    public final void c(CameraDevice cameraDevice, m mVar) {
        String id2 = cameraDevice.getId();
        kotlin.jvm.internal.q.f(id2, "getId(...)");
        Log.d("CXCP", "closeCameraDevice(" + id2 + ')');
        kotlin.jvm.internal.a0 a0Var = new kotlin.jvm.internal.a0();
        if (((qi.b0) this.f378a.b(7000L, new v1(cameraDevice, a0Var, null, 0))) == null) {
            Log.e("CXCP", "Failed to close CameraDevice(" + id2 + ") after 7000ms. The camera is likely in a bad state.");
        }
        String id3 = cameraDevice.getId();
        kotlin.jvm.internal.q.f(id3, "getId(...)");
        z.p.a(id3);
        d2 d2Var = this.f379b;
        d2Var.getClass();
        d2Var.f69b.getClass();
        z.r rVar = z.s.f23390q0;
        z.s sVarE = ((b2) d2Var.f68a).e(id3);
        rVar.getClass();
        if (z.r.c(sVarE) && a0Var.f13945e) {
            Log.d("CXCP", "Waiting for OnClosed from " + ((Object) z.p.b(id3)));
            if (mVar.f193r.await(2000L, TimeUnit.MILLISECONDS)) {
                Log.d("CXCP", "Received OnClosed for " + ((Object) z.p.b(id3)));
            } else {
                Log.w("CXCP", "Failed to close " + ((Object) z.p.b(id3)) + " after 2000ms!");
            }
        }
    }
}
