package a0;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class t2 extends wi.i implements ej.p {
    public int X;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f328e;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ t2(int i10, ui.d dVar, int i11) {
        super(i10, dVar);
        this.f328e = i11;
    }

    @Override // wi.a
    public final ui.d create(Object obj, ui.d dVar) {
        switch (this.f328e) {
            case 0:
                return new t2(2, dVar, 0);
            default:
                return new t2(2, dVar, 1);
        }
    }

    @Override // ej.p
    public final Object invoke(Object obj, Object obj2) {
        kotlinx.coroutines.p0 p0Var = (kotlinx.coroutines.p0) obj;
        ui.d dVar = (ui.d) obj2;
        switch (this.f328e) {
            case 0:
                break;
        }
        return ((t2) create(p0Var, dVar)).invokeSuspend(qi.b0.f17350a);
    }

    @Override // wi.a
    public final Object invokeSuspend(Object obj) {
        switch (this.f328e) {
            case 0:
                vi.a aVar = vi.a.f21252e;
                int i10 = this.X;
                if (i10 == 0) {
                    g6.y.I(obj);
                    this.X = 1;
                    if (kotlinx.coroutines.b1.delay(3000L, this) == aVar) {
                        return aVar;
                    }
                } else {
                    if (i10 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                }
                return qi.b0.f17350a;
            default:
                vi.a aVar2 = vi.a.f21252e;
                int i11 = this.X;
                if (i11 == 0) {
                    g6.y.I(obj);
                    uk.o oVarA = ln.f.a();
                    this.X = 1;
                    obj = oVarA.a(this);
                    if (obj == aVar2) {
                        return aVar2;
                    }
                } else {
                    if (i11 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    g6.y.I(obj);
                }
                if (((Boolean) obj).booleanValue()) {
                    ln.f.a().g();
                } else {
                    ln.f.a().k();
                }
                return qi.b0.f17350a;
        }
    }
}
