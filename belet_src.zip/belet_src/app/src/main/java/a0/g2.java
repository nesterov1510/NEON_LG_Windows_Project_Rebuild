package a0;

import android.hardware.camera2.CaptureRequest;
import android.view.Surface;
import java.util.List;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public interface g2 extends z.o1, AutoCloseable {
    Integer O(List list, m1 m1Var);

    Integer Q(List list, m1 m1Var);

    boolean S();

    h2 V();

    Integer Y(CaptureRequest captureRequest, m1 m1Var);

    boolean f0(List list);

    boolean g0();

    Surface getInputSurface();

    Integer w(CaptureRequest captureRequest, m1 m1Var);
}
