package a0;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class d3 {
    public static final d3 X;
    public static final d3 Y;
    public static final d3 Z;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final d3 f70e;

    /* JADX INFO: renamed from: r0, reason: collision with root package name */
    public static final d3 f71r0;

    /* JADX INFO: renamed from: s0, reason: collision with root package name */
    public static final /* synthetic */ d3[] f72s0;

    static {
        d3 d3Var = new d3("PENDING", 0);
        f70e = d3Var;
        d3 d3Var2 = new d3("CREATING", 1);
        X = d3Var2;
        d3 d3Var3 = new d3("CREATED", 2);
        Y = d3Var3;
        d3 d3Var4 = new d3("CLOSING", 3);
        Z = d3Var4;
        d3 d3Var5 = new d3("CLOSED", 4);
        f71r0 = d3Var5;
        d3[] d3VarArr = {d3Var, d3Var2, d3Var3, d3Var4, d3Var5};
        f72s0 = d3VarArr;
        android.support.v4.media.session.b.o(d3VarArr);
    }

    public static d3 valueOf(String str) {
        return (d3) Enum.valueOf(d3.class, str);
    }

    public static d3[] values() {
        return (d3[]) f72s0.clone();
    }
}
