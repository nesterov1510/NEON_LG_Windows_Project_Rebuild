package a0;

import android.os.SystemClock;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class l {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final k3 f164a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final long f165b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final z.i f166c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Throwable f167d;

    public l(k3 k3Var, z.i iVar, Exception exc, int i10) {
        long jElapsedRealtimeNanos = SystemClock.elapsedRealtimeNanos();
        iVar = (i10 & 4) != 0 ? null : iVar;
        exc = (i10 & 8) != 0 ? null : exc;
        this.f164a = k3Var;
        this.f165b = jElapsedRealtimeNanos;
        this.f166c = iVar;
        this.f167d = exc;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof l)) {
            return false;
        }
        l lVar = (l) obj;
        return this.f164a == lVar.f164a && this.f165b == lVar.f165b && kotlin.jvm.internal.q.c(this.f166c, lVar.f166c) && kotlin.jvm.internal.q.c(this.f167d, lVar.f167d);
    }

    public final int hashCode() {
        int iHashCode = this.f164a.hashCode() * 31;
        long j10 = this.f165b;
        int i10 = (((int) (j10 ^ (j10 >>> 32))) + iHashCode) * 31;
        z.i iVar = this.f166c;
        int i11 = (i10 + (iVar == null ? 0 : iVar.f23344a)) * 31;
        Throwable th2 = this.f167d;
        return i11 + (th2 != null ? th2.hashCode() : 0);
    }

    public final String toString() {
        return "ClosingInfo(reason=" + this.f164a + ", closingTimestamp=" + ((Object) c0.o.a(this.f165b)) + ", errorCode=" + this.f166c + ", exception=" + this.f167d + ')';
    }
}
