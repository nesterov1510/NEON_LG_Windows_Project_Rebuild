package a0;

import android.util.Log;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class q2 extends wi.i implements ej.p {
    public /* synthetic */ Object X;
    public final /* synthetic */ kotlin.jvm.internal.d0 Y;
    public final /* synthetic */ String Z;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f284e;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ q2(kotlin.jvm.internal.d0 d0Var, String str, ui.d dVar, int i10) {
        super(2, dVar);
        this.f284e = i10;
        this.Y = d0Var;
        this.Z = str;
    }

    @Override // wi.a
    public final ui.d create(Object obj, ui.d dVar) {
        switch (this.f284e) {
            case 0:
                q2 q2Var = new q2(this.Y, this.Z, dVar, 0);
                q2Var.X = obj;
                return q2Var;
            default:
                q2 q2Var2 = new q2(this.Y, this.Z, dVar, 1);
                q2Var2.X = obj;
                return q2Var2;
        }
    }

    @Override // ej.p
    public final Object invoke(Object obj, Object obj2) {
        q3 q3Var = (q3) obj;
        ui.d dVar = (ui.d) obj2;
        switch (this.f284e) {
            case 0:
                break;
        }
        return ((q2) create(q3Var, dVar)).invokeSuspend(qi.b0.f17350a);
    }

    @Override // wi.a
    public final Object invokeSuspend(Object obj) {
        int i10 = this.f284e;
        kotlin.jvm.internal.d0 d0Var = this.Y;
        String str = this.Z;
        switch (i10) {
            case 0:
                vi.a aVar = vi.a.f21252e;
                g6.y.I(obj);
                q3 q3Var = (q3) this.X;
                Log.d("CXCP", "tryOpenCamera: openCamera() for " + ((Object) z.p.b(str)) + " returned");
                d0Var.f13951e = null;
                return q3Var;
            default:
                vi.a aVar2 = vi.a.f21252e;
                g6.y.I(obj);
                q3 q3Var2 = (q3) this.X;
                Log.d("CXCP", "tryOpenCamera: " + ((Object) z.p.b(str)) + " opened");
                d0Var.f13951e = null;
                return q3Var2;
        }
    }
}
