package a0;

import android.util.Log;
import java.net.HttpURLConnection;
import java.util.List;
import java.util.Map;
import javax.net.ssl.HttpsURLConnection;
import okhttp3.OkHttpClient;
import okhttp3.internal.ws.WebSocketProtocol;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class o4 implements ej.l {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f258e;

    public /* synthetic */ o4(int i10) {
        this.f258e = i10;
    }

    @Override // ej.l
    public final Object invoke(Object obj) {
        int i10 = this.f258e;
        int i11 = 1;
        qi.b0 b0Var = qi.b0.f17350a;
        switch (i10) {
            case 0:
                kotlin.jvm.internal.q.g((qi.b0) obj, "<unused var>");
                return Boolean.TRUE;
            case 1:
                CharSequence it = (CharSequence) obj;
                kotlin.jvm.internal.q.g(it, "it");
                return Integer.valueOf(it.length());
            case 2:
                yh.v it2 = (yh.v) obj;
                kotlin.jvm.internal.q.g(it2, "it");
                return Integer.valueOf(it2.f23072a.length());
            case 3:
                p2.b ex = (p2.b) obj;
                kotlin.jvm.internal.q.g(ex, "ex");
                Log.w("FirebaseSessions", "CorruptionException in session configs DataStore", ex);
                return ef.h.f7778b;
            case 4:
                return obj instanceof Object[] ? ri.k.a0((Object[]) obj, new o4(4), 25) : String.valueOf(obj);
            case 5:
                kotlin.jvm.internal.q.g((List) obj, "it");
                return b0Var;
            case 6:
                return c1.h.f3860b;
            case 7:
                eh.d install = (eh.d) obj;
                kotlin.jvm.internal.q.g(install, "$this$install");
                dk.b bVar = mh.p.f15425a;
                int i12 = 3;
                ui.d dVar = null;
                install.f7796r0.g(th.e.f19225j, new eh.b(i12, dVar, i11));
                vh.a aVar = install.f7797s0;
                androidx.media3.session.x2 x2Var = vh.a.f21239k;
                aVar.g(x2Var, new mh.o(install, null));
                aVar.g(x2Var, new eh.b(i12, dVar, 2));
                return b0Var;
            case 8:
                kotlin.jvm.internal.q.g(obj, "<this>");
                return b0Var;
            case 9:
                kotlin.jvm.internal.q.g((hh.h) obj, "<this>");
                return b0Var;
            case 10:
                kotlinx.serialization.json.f Json = (kotlinx.serialization.json.f) obj;
                kotlin.jvm.internal.q.g(Json, "$this$Json");
                Json.setEncodeDefaults(true);
                Json.setLenient(true);
                Json.setAllowSpecialFloatingPointValues(true);
                Json.setAllowStructuredMapKeys(true);
                Json.setPrettyPrint(false);
                Json.setUseArrayPolymorphism(false);
                return b0Var;
            case ue.r.NETWORK_CLIENT_ERROR_REASON_FIELD_NUMBER /* 11 */:
                Map.Entry DelegatingMutableSet = (Map.Entry) obj;
                kotlin.jvm.internal.q.g(DelegatingMutableSet, "$this$DelegatingMutableSet");
                return new fi.j(((fi.e) DelegatingMutableSet.getKey()).f8131a, DelegatingMutableSet.getValue());
            case ue.r.CUSTOM_ATTRIBUTES_FIELD_NUMBER /* 12 */:
                Map.Entry DelegatingMutableSet2 = (Map.Entry) obj;
                kotlin.jvm.internal.q.g(DelegatingMutableSet2, "$this$DelegatingMutableSet");
                return new fi.j(m7.f.d((String) DelegatingMutableSet2.getKey()), DelegatingMutableSet2.getValue());
            case ue.r.PERF_SESSIONS_FIELD_NUMBER /* 13 */:
                fi.e DelegatingMutableSet3 = (fi.e) obj;
                kotlin.jvm.internal.q.g(DelegatingMutableSet3, "$this$DelegatingMutableSet");
                return DelegatingMutableSet3.f8131a;
            case 14:
                String DelegatingMutableSet4 = (String) obj;
                kotlin.jvm.internal.q.g(DelegatingMutableSet4, "$this$DelegatingMutableSet");
                return m7.f.d(DelegatingMutableSet4);
            case WebSocketProtocol.B0_MASK_OPCODE /* 15 */:
                o6.c it3 = (o6.c) obj;
                kotlin.jvm.internal.q.g(it3, "it");
                return Boolean.valueOf(it3.m0());
            case WebSocketProtocol.B0_FLAG_RSV3 /* 16 */:
                o6.c statement = (o6.c) obj;
                kotlin.jvm.internal.q.g(statement, "statement");
                si.i iVar = new si.i();
                while (statement.m0()) {
                    iVar.add(Integer.valueOf((int) statement.getLong(0)));
                }
                return m7.f.c(iVar);
            case 17:
                kotlin.jvm.internal.q.g((HttpsURLConnection) obj, "it");
                return b0Var;
            case 18:
                kotlin.jvm.internal.q.g((HttpURLConnection) obj, "<this>");
                return b0Var;
            case 19:
                OkHttpClient.Builder builder = (OkHttpClient.Builder) obj;
                kotlin.jvm.internal.q.g(builder, "<this>");
                builder.followRedirects(false);
                builder.followSslRedirects(false);
                builder.retryOnConnectionFailure(true);
                return b0Var;
            case 20:
                kotlin.jvm.internal.q.g((OkHttpClient) obj, "it");
                return b0Var;
            case 21:
                return kotlinx.coroutines.k0.a._init_$lambda$0((ui.g) obj);
            case 22:
                return kotlinx.coroutines.t1.a._init_$lambda$0((ui.g) obj);
            case 23:
                return kotlinx.coroutines.flow.u.defaultKeySelector$lambda$0$FlowKt__DistinctKt(obj);
            case 24:
                return Boolean.valueOf(kotlinx.coroutines.flow.a0.onErrorReturn$lambda$0$FlowKt__MigrationKt((Throwable) obj));
            case 25:
                return kotlinx.serialization.n.SERIALIZERS_CACHE$lambda$0((kj.c) obj);
            case 26:
                return kotlinx.serialization.n.SERIALIZERS_CACHE_NULLABLE$lambda$0((kj.c) obj);
            case 27:
                return kotlinx.serialization.descriptors.j.buildClassSerialDescriptor$lambda$0((kotlinx.serialization.descriptors.a) obj);
            case 28:
                return kotlinx.serialization.descriptors.j.buildSerialDescriptor$lambda$0((kotlinx.serialization.descriptors.a) obj);
            default:
                return kotlinx.serialization.json.n.descriptor$lambda$0((kotlinx.serialization.descriptors.a) obj);
        }
    }
}
