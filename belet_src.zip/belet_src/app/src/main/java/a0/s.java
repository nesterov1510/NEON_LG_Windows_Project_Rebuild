package a0;

import android.hardware.camera2.CaptureResult;
import android.hardware.camera2.TotalCaptureResult;
import android.os.Build;
import android.os.Trace;
import android.util.ArrayMap;
import java.util.Map;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class s implements z.o1 {
    public final t X;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final TotalCaptureResult f315e;

    public s(TotalCaptureResult totalCaptureResult, String camera, z.g1 requestMetadata) {
        Map mapF;
        kotlin.jvm.internal.q.g(camera, "camera");
        kotlin.jvm.internal.q.g(requestMetadata, "requestMetadata");
        this.f315e = totalCaptureResult;
        this.X = new t(totalCaptureResult, camera);
        try {
            Trace.beginSection("physicalCaptureResults");
            int i10 = Build.VERSION.SDK_INT;
            if (i10 >= 31) {
                mapF = g0.a(totalCaptureResult);
                kotlin.jvm.internal.q.e(mapF, "null cannot be cast to non-null type kotlin.collections.Map<kotlin.String, android.hardware.camera2.CaptureResult>");
            } else {
                mapF = i10 >= 28 ? c0.f(totalCaptureResult) : ri.t.f18051e;
            }
            if (mapF != null && !mapF.isEmpty()) {
                ArrayMap arrayMap = new ArrayMap(mapF.size());
                for (Map.Entry entry : mapF.entrySet()) {
                    String str = (String) entry.getKey();
                    z.p.a(str);
                    arrayMap.put(new z.p(str), new t((CaptureResult) entry.getValue(), str));
                }
            }
        } finally {
            Trace.endSection();
        }
    }

    @Override // z.o1
    public final Object D(kotlin.jvm.internal.h hVar) {
        boolean zEquals = hVar.equals(kotlin.jvm.internal.e0.a(CaptureResult.class));
        TotalCaptureResult totalCaptureResult = this.f315e;
        if (zEquals || hVar.equals(kotlin.jvm.internal.e0.a(TotalCaptureResult.class))) {
            return totalCaptureResult;
        }
        return null;
    }

    public final t a() {
        return this.X;
    }

    public final String toString() {
        StringBuilder sb2 = new StringBuilder("FrameInfo(camera: ");
        t tVar = this.X;
        sb2.append((Object) z.p.b(tVar.X));
        sb2.append(", frameNumber: ");
        sb2.append(tVar.f325e.getFrameNumber());
        sb2.append(')');
        return sb2.toString();
    }
}
