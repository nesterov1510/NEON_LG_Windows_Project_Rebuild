package a2;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.net.Uri;
import android.util.Log;
import j$.nio.channels.DesugarChannels;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.util.List;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class g extends c0.h {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final Class f458a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final Constructor f459b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final Method f460c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final Method f461d;

    static {
        Class<?> cls;
        Method method;
        Method method2;
        Constructor<?> constructor = null;
        try {
            cls = Class.forName("android.graphics.FontFamily");
            Constructor<?> constructor2 = cls.getConstructor(null);
            Class<?> cls2 = Integer.TYPE;
            method2 = cls.getMethod("addFontWeightStyle", ByteBuffer.class, cls2, List.class, cls2, Boolean.TYPE);
            method = Typeface.class.getMethod("createFromFamiliesWithDefault", Array.newInstance(cls, 1).getClass());
            constructor = constructor2;
        } catch (ClassNotFoundException | NoSuchMethodException e3) {
            Log.e("TypefaceCompatApi24Impl", e3.getClass().getName(), e3);
            cls = null;
            method = null;
            method2 = null;
        }
        f459b = constructor;
        f458a = cls;
        f460c = method2;
        f461d = method;
    }

    public static boolean N(Object obj, ByteBuffer byteBuffer, int i10, int i11, boolean z5) {
        try {
            return ((Boolean) f460c.invoke(obj, byteBuffer, Integer.valueOf(i10), null, Integer.valueOf(i11), Boolean.valueOf(z5))).booleanValue();
        } catch (IllegalAccessException | InvocationTargetException unused) {
            return false;
        }
    }

    public static Typeface O(Object obj) {
        try {
            Object objNewInstance = Array.newInstance((Class<?>) f458a, 1);
            Array.set(objNewInstance, 0, obj);
            return (Typeface) f461d.invoke(null, objNewInstance);
        } catch (IllegalAccessException | InvocationTargetException unused) {
            return null;
        }
    }

    @Override // c0.h
    public final Typeface i(Context context, z1.e eVar, Resources resources, int i10) throws IllegalAccessException, InstantiationException, InvocationTargetException {
        Object objNewInstance;
        MappedByteBuffer map;
        try {
            objNewInstance = f459b.newInstance(null);
        } catch (IllegalAccessException | InstantiationException | InvocationTargetException unused) {
            objNewInstance = null;
        }
        if (objNewInstance != null) {
            for (z1.f fVar : eVar.f23435a) {
                int i11 = fVar.f;
                File fileT = com.bumptech.glide.c.t(context);
                if (fileT != null) {
                    try {
                        if (com.bumptech.glide.c.i(fileT, resources, i11)) {
                            try {
                                FileInputStream fileInputStream = new FileInputStream(fileT);
                                try {
                                    FileChannel fileChannelConvertMaybeLegacyFileChannelFromLibrary = DesugarChannels.convertMaybeLegacyFileChannelFromLibrary(fileInputStream.getChannel());
                                    map = fileChannelConvertMaybeLegacyFileChannelFromLibrary.map(FileChannel.MapMode.READ_ONLY, 0L, fileChannelConvertMaybeLegacyFileChannelFromLibrary.size());
                                    fileInputStream.close();
                                    fileT.delete();
                                } catch (Throwable th2) {
                                    try {
                                        fileInputStream.close();
                                    } catch (Throwable th3) {
                                        th2.addSuppressed(th3);
                                    }
                                    throw th2;
                                }
                            } catch (IOException unused2) {
                                map = null;
                            }
                        } else {
                            fileT.delete();
                        }
                        if (map != null && N(objNewInstance, map, fVar.f23440e, fVar.f23437b, fVar.f23438c)) {
                        }
                    } catch (Throwable th4) {
                        fileT.delete();
                        throw th4;
                    }
                }
                map = null;
                if (map != null) {
                }
            }
            return O(objNewInstance);
        }
        return null;
    }

    @Override // c0.h
    public final Typeface j(Context context, f2.j[] jVarArr, int i10) {
        Object objNewInstance;
        try {
            objNewInstance = f459b.newInstance(null);
        } catch (IllegalAccessException | InstantiationException | InvocationTargetException unused) {
            objNewInstance = null;
        }
        if (objNewInstance != null) {
            j1.i iVar = new j1.i(0);
            for (f2.j jVar : jVarArr) {
                Uri uri = jVar.f7922a;
                ByteBuffer byteBufferW = (ByteBuffer) iVar.get(uri);
                if (byteBufferW == null) {
                    byteBufferW = com.bumptech.glide.c.w(context, uri);
                    iVar.put(uri, byteBufferW);
                }
                if (byteBufferW != null && N(objNewInstance, byteBufferW, jVar.f7923b, jVar.f7924c, jVar.f7925d)) {
                }
            }
            Typeface typefaceO = O(objNewInstance);
            if (typefaceO != null) {
                return Typeface.create(typefaceO, i10);
            }
        }
        return null;
    }
}
