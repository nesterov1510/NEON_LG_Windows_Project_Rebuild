package a2;

import android.graphics.Insets;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class c {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final c f443e = new c(0, 0, 0, 0);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f444a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f445b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f446c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f447d;

    public c(int i10, int i11, int i12, int i13) {
        this.f444a = i10;
        this.f445b = i11;
        this.f446c = i12;
        this.f447d = i13;
    }

    public static c a(c cVar, c cVar2) {
        return b(Math.max(cVar.f444a, cVar2.f444a), Math.max(cVar.f445b, cVar2.f445b), Math.max(cVar.f446c, cVar2.f446c), Math.max(cVar.f447d, cVar2.f447d));
    }

    public static c b(int i10, int i11, int i12, int i13) {
        return (i10 == 0 && i11 == 0 && i12 == 0 && i13 == 0) ? f443e : new c(i10, i11, i12, i13);
    }

    public static c c(Insets insets) {
        return b(insets.left, insets.top, insets.right, insets.bottom);
    }

    public final Insets d() {
        return a.k(this.f444a, this.f445b, this.f446c, this.f447d);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || c.class != obj.getClass()) {
            return false;
        }
        c cVar = (c) obj;
        return this.f447d == cVar.f447d && this.f444a == cVar.f444a && this.f446c == cVar.f446c && this.f445b == cVar.f445b;
    }

    public final int hashCode() {
        return (((((this.f444a * 31) + this.f445b) * 31) + this.f446c) * 31) + this.f447d;
    }

    public final String toString() {
        StringBuilder sb2 = new StringBuilder("Insets{left=");
        sb2.append(this.f444a);
        sb2.append(", top=");
        sb2.append(this.f445b);
        sb2.append(", right=");
        sb2.append(this.f446c);
        sb2.append(", bottom=");
        return a0.f.p(sb2, this.f447d, kotlinx.serialization.json.internal.b.END_OBJ);
    }
}
