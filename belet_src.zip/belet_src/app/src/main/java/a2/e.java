package a2;

import a0.f0;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.fonts.Font;
import android.graphics.fonts.FontFamily;
import android.graphics.text.PositionedGlyphs;
import android.graphics.text.TextRunShaper;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.Trace;
import android.text.TextUtils;
import android.util.Log;
import androidx.media3.session.legacy.d0;
import androidx.media3.session.legacy.n;
import androidx.media3.session.legacy.r0;
import androidx.viewpager2.widget.o;
import j$.util.DesugarCollections;
import j$.util.Objects;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import rc.k0;
import s3.r;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public abstract class e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final c0.h f450a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final d0 f451b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static Paint f452c;

    /* JADX WARN: Code duplicated, block: B:21:0x0050  */
    static {
        g0.c.a("TypefaceCompat static init");
        int i10 = Build.VERSION.SDK_INT;
        if (i10 >= 31) {
            f450a = new k();
        } else if (i10 >= 29) {
            f450a = new j();
        } else if (i10 >= 28) {
            f450a = new i();
        } else if (i10 >= 26) {
            f450a = new h();
        } else if (i10 < 24) {
            f450a = new f();
        } else {
            Method method = g.f460c;
            if (method == null) {
                Log.w("TypefaceCompatApi24Impl", "Unable to collect necessary private methods.Fallback to legacy implementation.");
            }
            if (method != null) {
                f450a = new g();
            } else {
                f450a = new f();
            }
        }
        f451b = new d0(16);
        f452c = null;
        Trace.endSection();
    }

    public static Typeface a(Context context, z1.d dVar, Resources resources, int i10, String str, int i11, int i12, z1.b bVar, boolean z5) {
        Typeface typefaceI;
        Typeface typefaceBuild;
        FontFamily fontFamilyBuild;
        int i13 = 25;
        int i14 = -3;
        if (dVar instanceof z1.g) {
            z1.g gVar = (z1.g) dVar;
            String str2 = gVar.f23444d;
            typefaceI = null;
            if (TextUtils.isEmpty(str2) || (typefaceBuild = c(str2)) == null) {
                ArrayList arrayList = gVar.f23441a;
                if (arrayList.size() != 1) {
                    if (Build.VERSION.SDK_INT >= 31) {
                        int i15 = 0;
                        while (true) {
                            if (i15 >= arrayList.size()) {
                                Typeface.CustomFallbackBuilder customFallbackBuilder = null;
                                int i16 = 0;
                                while (true) {
                                    if (i16 < arrayList.size()) {
                                        f2.d dVar2 = (f2.d) arrayList.get(i16);
                                        if (i16 == arrayList.size() - 1 && TextUtils.isEmpty(dVar2.f)) {
                                            customFallbackBuilder.setSystemFallback(dVar2.f7905e);
                                        } else {
                                            String str3 = dVar2.f7905e;
                                            String str4 = dVar2.f;
                                            Font fontD = d(c(str3));
                                            if (fontD == null) {
                                                Log.w("TypefaceCompat", "Unable identify the primary font for " + dVar2.f7905e + ". Falling back to provider font.");
                                            } else {
                                                if (TextUtils.isEmpty(str4)) {
                                                    fontFamilyBuild = new FontFamily.Builder(fontD).build();
                                                } else {
                                                    try {
                                                        fontFamilyBuild = new FontFamily.Builder(f0.a(fontD).setFontVariationSettings(str4).build()).build();
                                                    } catch (IOException unused) {
                                                        Log.e("TypefaceCompat", "Failed to clone Font instance. Fall back to provider font.");
                                                    }
                                                }
                                                if (customFallbackBuilder == null) {
                                                    customFallbackBuilder = new Typeface.CustomFallbackBuilder(fontFamilyBuild);
                                                } else {
                                                    customFallbackBuilder.addCustomFallback(fontFamilyBuild);
                                                }
                                                i16++;
                                            }
                                        }
                                    }
                                    typefaceBuild = customFallbackBuilder.build();
                                    break;
                                }
                            }
                            if (c(((f2.d) arrayList.get(i15)).f7905e) != null) {
                                i15++;
                            }
                            typefaceBuild = null;
                            break;
                        }
                    }
                    typefaceBuild = null;
                    break;
                }
                typefaceBuild = c(((f2.d) arrayList.get(0)).f7905e);
            }
            if (typefaceBuild != null) {
                if (bVar != null) {
                    new Handler(Looper.getMainLooper()).post(new r(bVar, typefaceBuild, i13));
                }
                f451b.l(b(resources, i10, str, i11, i12), typefaceBuild);
                return typefaceBuild;
            }
            boolean z6 = !z5 ? bVar != null : gVar.f23443c != 0;
            int i17 = z5 ? gVar.f23442b : -1;
            Handler handler = new Handler(Looper.getMainLooper());
            z7.c cVar = new z7.c(1);
            cVar.X = bVar;
            ArrayList arrayList2 = gVar.f23441a;
            q0.e eVar = new q0.e(2, handler);
            r0 r0Var = new r0(cVar, eVar, 13);
            int i18 = 15;
            if (!z6) {
                String strA = f2.h.a(i12, arrayList2);
                Typeface typeface = (Typeface) f2.h.f7916a.h(strA);
                if (typeface != null) {
                    eVar.execute(new k0(cVar, typeface, i18));
                    typefaceI = typeface;
                } else {
                    f2.f fVar = new f2.f(0, r0Var);
                    synchronized (f2.h.f7918c) {
                        try {
                            j1.i iVar = f2.h.f7919d;
                            ArrayList arrayList3 = (ArrayList) iVar.get(strA);
                            if (arrayList3 != null) {
                                arrayList3.add(fVar);
                            } else {
                                ArrayList arrayList4 = new ArrayList();
                                arrayList4.add(fVar);
                                iVar.put(strA, arrayList4);
                                f2.e eVar2 = new f2.e(strA, context, arrayList2, i12, 1);
                                ThreadPoolExecutor threadPoolExecutor = f2.h.f7917b;
                                f2.f fVar2 = new f2.f(1, strA);
                                Handler handler2 = Looper.myLooper() == null ? new Handler(Looper.getMainLooper()) : new Handler();
                                n nVar = new n(14);
                                nVar.X = eVar2;
                                nVar.Y = fVar2;
                                nVar.Z = handler2;
                                threadPoolExecutor.execute(nVar);
                            }
                        } catch (Throwable th2) {
                            throw th2;
                        }
                    }
                }
            } else {
                if (arrayList2.size() > 1) {
                    throw new IllegalArgumentException("Fallbacks with blocking fetches are not supported for performance reasons");
                }
                f2.d dVar3 = (f2.d) arrayList2.get(0);
                d0 d0Var = f2.h.f7916a;
                ArrayList arrayList5 = new ArrayList(1);
                Object obj = new Object[]{dVar3}[0];
                Objects.requireNonNull(obj);
                arrayList5.add(obj);
                String strA2 = f2.h.a(i12, DesugarCollections.unmodifiableList(arrayList5));
                Typeface typeface2 = (Typeface) f2.h.f7916a.h(strA2);
                if (typeface2 != null) {
                    eVar.execute(new k0(cVar, typeface2, i18));
                    typefaceI = typeface2;
                } else if (i17 == -1) {
                    Object[] objArr = {dVar3};
                    ArrayList arrayList6 = new ArrayList(1);
                    Object obj2 = objArr[0];
                    Objects.requireNonNull(obj2);
                    arrayList6.add(obj2);
                    f2.g gVarB = f2.h.b(strA2, context, DesugarCollections.unmodifiableList(arrayList6), i12);
                    r0Var.x(gVarB);
                    typefaceI = gVarB.f7914a;
                } else {
                    try {
                        try {
                            try {
                                try {
                                    f2.g gVar2 = (f2.g) f2.h.f7917b.submit(new f2.e(strA2, context, dVar3, i12, 0)).get(i17, TimeUnit.MILLISECONDS);
                                    r0Var.x(gVar2);
                                    typefaceI = gVar2.f7914a;
                                } catch (TimeoutException unused2) {
                                    throw new InterruptedException("timeout");
                                }
                            } catch (InterruptedException e3) {
                                throw e3;
                            }
                        } catch (ExecutionException e10) {
                            throw new RuntimeException(e10);
                        }
                    } catch (InterruptedException unused3) {
                        ((q0.e) r0Var.Y).execute(new o(i14, 3, (z7.c) r0Var.X));
                    }
                }
            }
        } else {
            typefaceI = f450a.i(context, (z1.e) dVar, resources, i12);
            if (bVar != null) {
                if (typefaceI != null) {
                    new Handler(Looper.getMainLooper()).post(new r(bVar, typefaceI, i13));
                } else {
                    bVar.a(-3);
                }
            }
        }
        if (typefaceI != null) {
            f451b.l(b(resources, i10, str, i11, i12), typefaceI);
        }
        return typefaceI;
    }

    public static String b(Resources resources, int i10, String str, int i11, int i12) {
        return resources.getResourcePackageName(i10) + '-' + str + '-' + i11 + '-' + i10 + '-' + i12;
    }

    public static Typeface c(String str) {
        if (str != null && !str.isEmpty()) {
            Typeface typefaceCreate = Typeface.create(str, 0);
            Typeface typefaceCreate2 = Typeface.create(Typeface.DEFAULT, 0);
            if (typefaceCreate != null && !typefaceCreate.equals(typefaceCreate2)) {
                return typefaceCreate;
            }
        }
        return null;
    }

    public static Font d(Typeface typeface) {
        if (f452c == null) {
            f452c = new Paint();
        }
        f452c.setTextSize(10.0f);
        f452c.setTypeface(typeface);
        PositionedGlyphs positionedGlyphsShapeTextRun = TextRunShaper.shapeTextRun((CharSequence) " ", 0, 1, 0, 1, 0.0f, 0.0f, false, f452c);
        if (positionedGlyphsShapeTextRun.glyphCount() == 0) {
            return null;
        }
        return positionedGlyphsShapeTextRun.getFont(0);
    }
}
