package a2;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.ParcelFileDescriptor;
import android.system.ErrnoException;
import android.system.Os;
import android.system.OsConstants;
import android.util.Log;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public class f extends c0.h {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static Class f453a = null;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static Constructor f454b = null;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static Method f455c = null;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static Method f456d = null;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static boolean f457e = false;

    public static boolean N(Object obj, String str, int i10, boolean z5) throws NoSuchMethodException {
        O();
        try {
            try {
                return ((Boolean) f455c.invoke(obj, str, Integer.valueOf(i10), Boolean.valueOf(z5))).booleanValue();
            } catch (InvocationTargetException e3) {
                e = e3;
                throw new RuntimeException(e);
            }
        } catch (IllegalAccessException | InvocationTargetException e10) {
            e = e10;
        }
    }

    public static void O() throws NoSuchMethodException {
        Method method;
        Class<?> cls;
        Method method2;
        if (f457e) {
            return;
        }
        f457e = true;
        Constructor<?> constructor = null;
        try {
            cls = Class.forName("android.graphics.FontFamily");
            Constructor<?> constructor2 = cls.getConstructor(null);
            method2 = cls.getMethod("addFontWeightStyle", String.class, Integer.TYPE, Boolean.TYPE);
            method = Typeface.class.getMethod("createFromFamiliesWithDefault", Array.newInstance(cls, 1).getClass());
            constructor = constructor2;
        } catch (ClassNotFoundException | NoSuchMethodException e3) {
            Log.e("TypefaceCompatApi21Impl", e3.getClass().getName(), e3);
            method = null;
            cls = null;
            method2 = null;
        }
        f454b = constructor;
        f453a = cls;
        f455c = method2;
        f456d = method;
    }

    @Override // c0.h
    public Typeface i(Context context, z1.e eVar, Resources resources, int i10) throws NoSuchMethodException {
        O();
        try {
            Object objNewInstance = f454b.newInstance(null);
            for (z1.f fVar : eVar.f23435a) {
                File fileT = com.bumptech.glide.c.t(context);
                if (fileT == null) {
                    return null;
                }
                try {
                    if (!com.bumptech.glide.c.i(fileT, resources, fVar.f)) {
                        return null;
                    }
                    if (!N(objNewInstance, fileT.getPath(), fVar.f23437b, fVar.f23438c)) {
                        return null;
                    }
                    fileT.delete();
                } catch (RuntimeException unused) {
                    return null;
                } finally {
                    fileT.delete();
                }
            }
            O();
            try {
                Object objNewInstance2 = Array.newInstance((Class<?>) f453a, 1);
                Array.set(objNewInstance2, 0, objNewInstance);
                return (Typeface) f456d.invoke(null, objNewInstance2);
            } catch (IllegalAccessException | InvocationTargetException e3) {
                throw new RuntimeException(e3);
            }
        } catch (IllegalAccessException | InstantiationException | InvocationTargetException e10) {
            throw new RuntimeException(e10);
        }
    }

    @Override // c0.h
    public Typeface j(Context context, f2.j[] jVarArr, int i10) {
        File file;
        Typeface typefaceCreateFromFile;
        if (jVarArr.length >= 1) {
            try {
                ParcelFileDescriptor parcelFileDescriptorOpenFileDescriptor = context.getContentResolver().openFileDescriptor(c0.h.n(jVarArr, i10).f7922a, "r", null);
                if (parcelFileDescriptorOpenFileDescriptor != null) {
                    try {
                        try {
                            String str = Os.readlink("/proc/self/fd/" + parcelFileDescriptorOpenFileDescriptor.getFd());
                            file = OsConstants.S_ISREG(Os.stat(str).st_mode) ? new File(str) : null;
                        } catch (Throwable th2) {
                            try {
                                parcelFileDescriptorOpenFileDescriptor.close();
                            } catch (Throwable th3) {
                                th2.addSuppressed(th3);
                            }
                            throw th2;
                        }
                    } catch (ErrnoException unused) {
                    }
                    if (file != null && file.canRead()) {
                        Typeface typefaceCreateFromFile2 = Typeface.createFromFile(file);
                        parcelFileDescriptorOpenFileDescriptor.close();
                        return typefaceCreateFromFile2;
                    }
                    FileInputStream fileInputStream = new FileInputStream(parcelFileDescriptorOpenFileDescriptor.getFileDescriptor());
                    try {
                        File fileT = com.bumptech.glide.c.t(context);
                        if (fileT == null) {
                            typefaceCreateFromFile = null;
                        } else {
                            try {
                                if (com.bumptech.glide.c.j(fileT, fileInputStream)) {
                                    typefaceCreateFromFile = Typeface.createFromFile(fileT.getPath());
                                    fileT.delete();
                                } else {
                                    fileT.delete();
                                    typefaceCreateFromFile = null;
                                }
                            } catch (RuntimeException unused2) {
                            } catch (Throwable th4) {
                                fileT.delete();
                                throw th4;
                            }
                        }
                        fileInputStream.close();
                        parcelFileDescriptorOpenFileDescriptor.close();
                        return typefaceCreateFromFile;
                    } catch (Throwable th5) {
                        try {
                            fileInputStream.close();
                        } catch (Throwable th6) {
                            th5.addSuppressed(th6);
                        }
                        throw th5;
                    }
                }
                if (parcelFileDescriptorOpenFileDescriptor != null) {
                    parcelFileDescriptorOpenFileDescriptor.close();
                    return null;
                }
            } catch (IOException unused3) {
            }
        }
        return null;
    }
}
