package a2;

import a4.a0;
import a4.e0;
import a4.l;
import android.app.NotificationManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.BlendMode;
import android.graphics.Insets;
import android.graphics.Paint;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.ColorStateListDrawable;
import android.graphics.drawable.Drawable;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.media.MediaCodecInfo;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.Trace;
import android.util.Log;
import g0.t;
import gb.p;
import i3.q0;
import i3.s;
import java.util.List;
import jd.t1;
import l3.l0;
import lc.c3;
import lc.l2;
import lc.u0;
import okhttp3.internal.ws.WebSocketProtocol;
import ue.r;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public abstract class a {
    public static void a(AudioAttributes.Builder builder, boolean z5) {
        builder.setHapticChannelsMuted(z5);
    }

    /* JADX WARN: Code duplicated, block: B:20:0x003f  */
    public static int b(MediaCodecInfo.VideoCapabilities videoCapabilities, int i10, int i11, double d2) {
        boolean z5;
        int i12;
        List<MediaCodecInfo.VideoCapabilities.PerformancePoint> supportedPerformancePoints = videoCapabilities.getSupportedPerformancePoints();
        if (supportedPerformancePoints != null && !supportedPerformancePoints.isEmpty()) {
            MediaCodecInfo.VideoCapabilities.PerformancePoint performancePoint = new MediaCodecInfo.VideoCapabilities.PerformancePoint(i10, i11, (int) d2);
            int i13 = 0;
            while (true) {
                z5 = true;
                if (i13 >= supportedPerformancePoints.size()) {
                    i12 = 1;
                    break;
                }
                if (l.c(supportedPerformancePoints.get(i13)).covers(performancePoint)) {
                    i12 = 2;
                    break;
                }
                i13++;
            }
            if (i12 == 1 && com.bumptech.glide.d.f4726e == null) {
                int i14 = Build.VERSION.SDK_INT;
                if (i14 >= 37) {
                    z5 = false;
                } else {
                    int iC = c(true);
                    if (i14 < 35 ? !(c(false) != 2 || iC == 1) : iC != 1) {
                        z5 = false;
                    }
                }
                com.bumptech.glide.d.f4726e = Boolean.valueOf(z5);
                if (z5) {
                }
            }
            return i12;
        }
        return 0;
    }

    public static int c(boolean z5) {
        MediaCodecInfo.VideoCapabilities videoCapabilities;
        List<MediaCodecInfo.VideoCapabilities.PerformancePoint> supportedPerformancePoints;
        try {
            s sVar = new s();
            sVar.f11036n = q0.n("video/avc");
            androidx.media3.common.b bVar = new androidx.media3.common.b(sVar);
            String str = bVar.f2125o;
            if (str != null) {
                List listE = e0.e(str, z5, false);
                String strC = e0.c(bVar);
                Iterable iterableE = strC == null ? l2.f14447r0 : e0.e(strC, z5, false);
                lc.q0 q0VarI = u0.i();
                q0VarI.d(listE);
                q0VarI.d(iterableE);
                l2 l2VarG = q0VarI.g();
                for (int i10 = 0; i10 < l2VarG.Z; i10++) {
                    if (((a4.s) l2VarG.get(i10)).f524d != null && (videoCapabilities = ((a4.s) l2VarG.get(i10)).f524d.getVideoCapabilities()) != null && (supportedPerformancePoints = videoCapabilities.getSupportedPerformancePoints()) != null && !supportedPerformancePoints.isEmpty()) {
                        MediaCodecInfo.VideoCapabilities.PerformancePoint performancePoint = new MediaCodecInfo.VideoCapabilities.PerformancePoint(1280, 720, 60);
                        for (int i11 = 0; i11 < supportedPerformancePoints.size(); i11++) {
                            if (l.c(supportedPerformancePoints.get(i11)).covers(performancePoint)) {
                                return 2;
                            }
                        }
                        return 1;
                    }
                }
            }
        } catch (a0 unused) {
        }
        return 0;
    }

    public static ColorStateList d(Drawable drawable) {
        if (drawable instanceof ColorDrawable) {
            return ColorStateList.valueOf(((ColorDrawable) drawable).getColor());
        }
        if (Build.VERSION.SDK_INT < 29 || !(drawable instanceof ColorStateListDrawable)) {
            return null;
        }
        return ((ColorStateListDrawable) drawable).getColorStateList();
    }

    public static l2 e(i3.e eVar) {
        lc.q0 q0VarI = u0.i();
        c3 c3VarG = u3.b.h.keySet().iterator();
        while (c3VarG.hasNext()) {
            Integer num = (Integer) c3VarG.next();
            int iIntValue = num.intValue();
            if (Build.VERSION.SDK_INT >= l0.v(iIntValue) && AudioTrack.isDirectPlaybackSupported(new AudioFormat.Builder().setChannelMask(12).setEncoding(iIntValue).setSampleRate(48000).build(), eVar.c())) {
                q0VarI.c(num);
            }
        }
        q0VarI.c(2);
        return q0VarI.g();
    }

    public static int f(int i10, int i11, i3.e eVar) {
        for (int i12 = 10; i12 > 0; i12--) {
            int iW = l0.w(i12);
            if (iW != 0 && AudioTrack.isDirectPlaybackSupported(new AudioFormat.Builder().setEncoding(i10).setSampleRate(i11).setChannelMask(iW).build(), eVar.c())) {
                return i12;
            }
        }
        return 0;
    }

    public static void g(Context context) {
        boolean z5;
        ApplicationInfo applicationInfo;
        Bundle bundle;
        if (t1.p(context).getBoolean("proxy_notification_initialized", false)) {
            return;
        }
        try {
            Context applicationContext = context.getApplicationContext();
            PackageManager packageManager = applicationContext.getPackageManager();
            z5 = (packageManager == null || (applicationInfo = packageManager.getApplicationInfo(applicationContext.getPackageName(), 128)) == null || (bundle = applicationInfo.metaData) == null || !bundle.containsKey("firebase_messaging_notification_delegation_enabled")) ? true : applicationInfo.metaData.getBoolean("firebase_messaging_notification_delegation_enabled");
        } catch (PackageManager.NameNotFoundException unused) {
        }
        if (Build.VERSION.SDK_INT < 29) {
            fk.j.o(null);
            return;
        }
        p pVar = new p();
        try {
            if (Binder.getCallingUid() == context.getApplicationInfo().uid) {
                SharedPreferences.Editor editorEdit = t1.p(context).edit();
                editorEdit.putBoolean("proxy_notification_initialized", true);
                editorEdit.apply();
                NotificationManager notificationManager = (NotificationManager) context.getSystemService(NotificationManager.class);
                if (z5) {
                    notificationManager.setNotificationDelegate("com.google.android.gms");
                } else if ("com.google.android.gms".equals(notificationManager.getNotificationDelegate())) {
                    notificationManager.setNotificationDelegate(null);
                }
            } else {
                Log.e("FirebaseMessaging", "error configuring notification delegate for package " + context.getPackageName());
            }
        } finally {
            pVar.m(null);
        }
    }

    public static boolean h() {
        return Trace.isEnabled();
    }

    public static boolean i(Context context) {
        if (Build.VERSION.SDK_INT >= 29) {
            if (Binder.getCallingUid() != context.getApplicationInfo().uid) {
                Log.e("FirebaseMessaging", "error retrieving notification delegate for package " + context.getPackageName());
                return false;
            }
            if ("com.google.android.gms".equals(((NotificationManager) context.getSystemService(NotificationManager.class)).getNotificationDelegate())) {
                if (!Log.isLoggable("FirebaseMessaging", 3)) {
                    return true;
                }
                Log.d("FirebaseMessaging", "GMS core is set for proxying");
                return true;
            }
        } else if (Log.isLoggable("FirebaseMessaging", 3)) {
            Log.d("FirebaseMessaging", "Platform doesn't support proxying.");
        }
        return false;
    }

    public static Object j(int i10) {
        switch (t.c(i10)) {
            case 0:
                return BlendMode.CLEAR;
            case 1:
                return BlendMode.SRC;
            case 2:
                return BlendMode.DST;
            case 3:
                return BlendMode.SRC_OVER;
            case 4:
                return BlendMode.DST_OVER;
            case 5:
                return BlendMode.SRC_IN;
            case 6:
                return BlendMode.DST_IN;
            case 7:
                return BlendMode.SRC_OUT;
            case 8:
                return BlendMode.DST_OUT;
            case 9:
                return BlendMode.SRC_ATOP;
            case 10:
                return BlendMode.DST_ATOP;
            case r.NETWORK_CLIENT_ERROR_REASON_FIELD_NUMBER /* 11 */:
                return BlendMode.XOR;
            case r.CUSTOM_ATTRIBUTES_FIELD_NUMBER /* 12 */:
                return BlendMode.PLUS;
            case r.PERF_SESSIONS_FIELD_NUMBER /* 13 */:
                return BlendMode.MODULATE;
            case 14:
                return BlendMode.SCREEN;
            case WebSocketProtocol.B0_MASK_OPCODE /* 15 */:
                return BlendMode.OVERLAY;
            case WebSocketProtocol.B0_FLAG_RSV3 /* 16 */:
                return BlendMode.DARKEN;
            case 17:
                return BlendMode.LIGHTEN;
            case 18:
                return BlendMode.COLOR_DODGE;
            case 19:
                return BlendMode.COLOR_BURN;
            case 20:
                return BlendMode.HARD_LIGHT;
            case 21:
                return BlendMode.SOFT_LIGHT;
            case 22:
                return BlendMode.DIFFERENCE;
            case 23:
                return BlendMode.EXCLUSION;
            case 24:
                return BlendMode.MULTIPLY;
            case 25:
                return BlendMode.HUE;
            case 26:
                return BlendMode.SATURATION;
            case 27:
                return BlendMode.COLOR;
            case 28:
                return BlendMode.LUMINOSITY;
            default:
                return null;
        }
    }

    public static Insets k(int i10, int i11, int i12, int i13) {
        return Insets.of(i10, i11, i12, i13);
    }

    public static void l(AudioAttributes.Builder builder, int i10) {
        builder.setAllowedCapturePolicy(i10);
    }

    public static void m(Paint paint, Object obj) {
        paint.setBlendMode((BlendMode) obj);
    }

    public static void n(int i10, String str) {
        Trace.setCounter(str, i10);
    }
}
