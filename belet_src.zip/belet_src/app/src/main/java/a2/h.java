package a2;

import android.content.Context;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.graphics.fonts.FontVariationAxis;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.util.Log;
import j$.util.DesugarCollections;
import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.Map;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public class h extends f {
    public final Class f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final Constructor f462g;
    public final Method h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final Method f463i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final Method f464j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final Method f465k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final Method f466l;

    public h() throws NoSuchMethodException {
        Method methodT;
        Constructor<?> constructor;
        Method methodS;
        Method method;
        Method method2;
        Method method3;
        Class<?> cls = null;
        try {
            Class<?> cls2 = Class.forName("android.graphics.FontFamily");
            constructor = cls2.getConstructor(null);
            methodS = S(cls2);
            Class<?> cls3 = Integer.TYPE;
            method = cls2.getMethod("addFontFromBuffer", ByteBuffer.class, cls3, FontVariationAxis[].class, cls3, cls3);
            method2 = cls2.getMethod("freeze", null);
            method3 = cls2.getMethod("abortCreation", null);
            methodT = T(cls2);
            cls = cls2;
        } catch (ClassNotFoundException | NoSuchMethodException e3) {
            Log.e("TypefaceCompatApi26Impl", "Unable to collect necessary methods for class ".concat(e3.getClass().getName()), e3);
            methodT = null;
            constructor = null;
            methodS = null;
            method = null;
            method2 = null;
            method3 = null;
        }
        this.f = cls;
        this.f462g = constructor;
        this.h = methodS;
        this.f463i = method;
        this.f464j = method2;
        this.f465k = method3;
        this.f466l = methodT;
    }

    public static Method S(Class cls) {
        Class<?> cls2 = Integer.TYPE;
        return cls.getMethod("addFontFromAssetManager", AssetManager.class, String.class, cls2, Boolean.TYPE, cls2, cls2, cls2, FontVariationAxis[].class);
    }

    public final boolean P(Context context, Object obj, String str, int i10, int i11, int i12, FontVariationAxis[] fontVariationAxisArr) {
        try {
            return ((Boolean) this.h.invoke(obj, context.getAssets(), str, 0, Boolean.FALSE, Integer.valueOf(i10), Integer.valueOf(i11), Integer.valueOf(i12), fontVariationAxisArr)).booleanValue();
        } catch (IllegalAccessException | InvocationTargetException unused) {
            return false;
        }
    }

    public Typeface Q(Object obj) {
        try {
            Object objNewInstance = Array.newInstance((Class<?>) this.f, 1);
            Array.set(objNewInstance, 0, obj);
            return (Typeface) this.f466l.invoke(null, objNewInstance, -1, -1);
        } catch (IllegalAccessException | InvocationTargetException unused) {
            return null;
        }
    }

    public final boolean R(Object obj) {
        try {
            return ((Boolean) this.f464j.invoke(obj, null)).booleanValue();
        } catch (IllegalAccessException | InvocationTargetException unused) {
            return false;
        }
    }

    public Method T(Class cls) throws NoSuchMethodException {
        Class cls2 = Integer.TYPE;
        Method declaredMethod = Typeface.class.getDeclaredMethod("createFromFamiliesWithDefault", Array.newInstance((Class<?>) cls, 1).getClass(), cls2, cls2);
        declaredMethod.setAccessible(true);
        return declaredMethod;
    }

    @Override // a2.f, c0.h
    public final Typeface i(Context context, z1.e eVar, Resources resources, int i10) throws IllegalAccessException, InstantiationException, InvocationTargetException {
        Object objNewInstance;
        Method method = this.h;
        if (method == null) {
            Log.w("TypefaceCompatApi26Impl", "Unable to collect necessary private methods. Fallback to legacy implementation.");
        }
        if (method == null) {
            return super.i(context, eVar, resources, i10);
        }
        try {
            objNewInstance = this.f462g.newInstance(null);
        } catch (IllegalAccessException | InstantiationException | InvocationTargetException unused) {
            objNewInstance = null;
        }
        if (objNewInstance != null) {
            z1.f[] fVarArr = eVar.f23435a;
            int length = fVarArr.length;
            int i11 = 0;
            while (i11 < length) {
                z1.f fVar = fVarArr[i11];
                Context context2 = context;
                if (P(context2, objNewInstance, fVar.f23436a, fVar.f23440e, fVar.f23437b, fVar.f23438c ? 1 : 0, FontVariationAxis.fromFontVariationSettings(fVar.f23439d))) {
                    i11++;
                    context = context2;
                } else {
                    try {
                        this.f465k.invoke(objNewInstance, null);
                    } catch (IllegalAccessException | InvocationTargetException unused2) {
                    }
                }
            }
            if (R(objNewInstance)) {
                return Q(objNewInstance);
            }
        }
        return null;
    }

    /* JADX WARN: Code duplicated, block: B:13:0x0028  */
    @Override // a2.f, c0.h
    public final Typeface j(Context context, f2.j[] jVarArr, int i10) throws IOException {
        Object objNewInstance;
        Typeface typefaceQ;
        boolean zBooleanValue;
        if (jVarArr.length >= 1) {
            Method method = this.h;
            if (method == null) {
                Log.w("TypefaceCompatApi26Impl", "Unable to collect necessary private methods. Fallback to legacy implementation.");
            }
            try {
                if (method != null) {
                    HashMap map = new HashMap();
                    for (f2.j jVar : jVarArr) {
                        if (jVar.f == 0) {
                            Uri uri = jVar.f7922a;
                            if (!map.containsKey(uri)) {
                                map.put(uri, com.bumptech.glide.c.w(context, uri));
                            }
                        }
                    }
                    Map mapUnmodifiableMap = DesugarCollections.unmodifiableMap(map);
                    try {
                        objNewInstance = this.f462g.newInstance(null);
                    } catch (IllegalAccessException | InstantiationException | InvocationTargetException unused) {
                        objNewInstance = null;
                    }
                    if (objNewInstance != null) {
                        int length = jVarArr.length;
                        int i11 = 0;
                        boolean z5 = false;
                        while (true) {
                            Method method2 = this.f465k;
                            if (i11 >= length) {
                                if (!z5) {
                                    method2.invoke(objNewInstance, null);
                                    break;
                                }
                                if (!R(objNewInstance) || (typefaceQ = Q(objNewInstance)) == null) {
                                    break;
                                    break;
                                }
                                return Typeface.create(typefaceQ, i10);
                            }
                            f2.j jVar2 = jVarArr[i11];
                            ByteBuffer byteBuffer = (ByteBuffer) mapUnmodifiableMap.get(jVar2.f7922a);
                            if (byteBuffer != null) {
                                try {
                                    zBooleanValue = ((Boolean) this.f463i.invoke(objNewInstance, byteBuffer, Integer.valueOf(jVar2.f7923b), null, Integer.valueOf(jVar2.f7924c), Integer.valueOf(jVar2.f7925d ? 1 : 0))).booleanValue();
                                } catch (IllegalAccessException | InvocationTargetException unused2) {
                                    zBooleanValue = false;
                                }
                                if (!zBooleanValue) {
                                    method2.invoke(objNewInstance, null);
                                    break;
                                }
                                z5 = true;
                            }
                            i11++;
                            z5 = z5;
                        }
                    }
                } else {
                    f2.j jVarN = c0.h.n(jVarArr, i10);
                    ParcelFileDescriptor parcelFileDescriptorOpenFileDescriptor = context.getContentResolver().openFileDescriptor(jVarN.f7922a, "r", null);
                    if (parcelFileDescriptorOpenFileDescriptor != null) {
                        try {
                            Typeface typefaceBuild = new Typeface.Builder(parcelFileDescriptorOpenFileDescriptor.getFileDescriptor()).setWeight(jVarN.f7924c).setItalic(jVarN.f7925d).build();
                            parcelFileDescriptorOpenFileDescriptor.close();
                            return typefaceBuild;
                        } catch (Throwable th2) {
                            try {
                                parcelFileDescriptorOpenFileDescriptor.close();
                                throw th2;
                            } catch (Throwable th3) {
                                th2.addSuppressed(th3);
                                throw th2;
                            }
                        }
                    }
                    if (parcelFileDescriptorOpenFileDescriptor != null) {
                        parcelFileDescriptorOpenFileDescriptor.close();
                        return null;
                    }
                }
            } catch (IOException | IllegalAccessException | InvocationTargetException unused3) {
            }
        }
        return null;
    }

    @Override // c0.h
    public final Typeface l(Context context, Resources resources, int i10, String str, int i11) throws IllegalAccessException, InstantiationException, InvocationTargetException {
        Object objNewInstance;
        Method method = this.h;
        if (method == null) {
            Log.w("TypefaceCompatApi26Impl", "Unable to collect necessary private methods. Fallback to legacy implementation.");
        }
        if (method == null) {
            return super.l(context, resources, i10, str, i11);
        }
        try {
            objNewInstance = this.f462g.newInstance(null);
        } catch (IllegalAccessException | InstantiationException | InvocationTargetException unused) {
            objNewInstance = null;
        }
        if (objNewInstance != null) {
            if (!P(context, objNewInstance, str, 0, -1, -1, null)) {
                try {
                    this.f465k.invoke(objNewInstance, null);
                } catch (IllegalAccessException | InvocationTargetException unused2) {
                }
            } else if (R(objNewInstance)) {
                return Q(objNewInstance);
            }
        }
        return null;
    }
}
