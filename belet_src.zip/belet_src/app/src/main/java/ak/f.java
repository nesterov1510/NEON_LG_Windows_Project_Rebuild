package ak;

import j$.nio.file.Files;
import j$.nio.file.LinkOption;
import j$.nio.file.Path;
import j$.nio.file.StandardOpenOption;
import j$.nio.file.attribute.BasicFileAttributes;
import j$.nio.file.attribute.DosFileAttributeView;
import j$.nio.file.attribute.PosixFileAttributes;
import j$.nio.file.attribute.PosixFilePermission;
import j$.util.stream.Stream;
import java.io.IOException;
import java.nio.file.AccessDeniedException;
import java.nio.file.NoSuchFileException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public abstract class f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final LinkOption[] f812a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final LinkOption[] f813b;

    static {
        StandardOpenOption standardOpenOption = StandardOpenOption.CREATE;
        StandardOpenOption standardOpenOption2 = StandardOpenOption.TRUNCATE_EXISTING;
        StandardOpenOption standardOpenOption3 = StandardOpenOption.APPEND;
        f812a = new LinkOption[0];
        f813b = new LinkOption[]{LinkOption.NOFOLLOW_LINKS};
    }

    public static b a(Path path, LinkOption[] linkOptionArr, h... hVarArr) {
        BasicFileAttributes attributes;
        if (Files.isDirectory(path, linkOptionArr)) {
            d dVar = new d(new b(), linkOptionArr, hVarArr, new String[0]);
            Files.walkFileTree(path, dVar);
            return dVar.f806b;
        }
        if (Files.isDirectory(path, linkOptionArr)) {
            throw new NoSuchFileException(path.toString());
        }
        b bVar = new b();
        a aVar = bVar.f801a;
        a aVar2 = bVar.f803c;
        long size = 0;
        long size2 = (!b(path, linkOptionArr) || Files.isSymbolicLink(path)) ? 0L : Files.size(path);
        try {
            if (Files.deleteIfExists(path)) {
                aVar2.f800a++;
                aVar.f800a += size2;
                return bVar;
            }
        } catch (AccessDeniedException unused) {
        }
        PosixFileAttributes posixFileAttributes = null;
        Path parent = path == null ? null : path.getParent();
        try {
            if (Stream.CC.of(hVarArr).anyMatch(new e(0))) {
                if (parent == null) {
                    attributes = null;
                } else {
                    try {
                        attributes = Files.readAttributes(parent, PosixFileAttributes.class, linkOptionArr);
                    } catch (IOException | UnsupportedOperationException unused2) {
                        attributes = null;
                    }
                }
                PosixFileAttributes posixFileAttributes2 = (PosixFileAttributes) attributes;
                try {
                    c(path, linkOptionArr);
                    posixFileAttributes = posixFileAttributes2;
                } catch (Throwable th2) {
                    th = th2;
                    posixFileAttributes = posixFileAttributes2;
                    if (posixFileAttributes != null) {
                        Files.setPosixFilePermissions(parent, posixFileAttributes.permissions());
                    }
                    throw th;
                }
            }
            if (b(path, linkOptionArr) && !Files.isSymbolicLink(path)) {
                size = Files.size(path);
            }
            if (Files.deleteIfExists(path)) {
                aVar2.f800a++;
                aVar.f800a += size;
            }
            if (posixFileAttributes != null) {
                Files.setPosixFilePermissions(parent, posixFileAttributes.permissions());
            }
            return bVar;
        } catch (Throwable th3) {
            th = th3;
        }
    }

    public static boolean b(Path path, LinkOption... linkOptionArr) {
        if (path != null) {
            if (linkOptionArr != null) {
                if (Files.exists(path, linkOptionArr)) {
                    return true;
                }
            } else if (Files.exists(path, new LinkOption[0])) {
                return true;
            }
        }
        return false;
    }

    public static void c(Path path, LinkOption... linkOptionArr) {
        try {
            DosFileAttributeView dosFileAttributeView = (DosFileAttributeView) Files.getFileAttributeView(path, DosFileAttributeView.class, linkOptionArr);
            if (dosFileAttributeView != null) {
                dosFileAttributeView.setReadOnly(false);
                return;
            }
        } catch (IOException unused) {
        }
        BasicFileAttributes attributes = null;
        Path parent = path == null ? null : path.getParent();
        if (b(parent, linkOptionArr)) {
            if (parent != null) {
                try {
                    attributes = Files.readAttributes(parent, PosixFileAttributes.class, linkOptionArr);
                } catch (IOException | UnsupportedOperationException unused2) {
                }
            }
            if (((PosixFileAttributes) attributes) != null) {
                List listAsList = Arrays.asList(PosixFilePermission.OWNER_WRITE, PosixFilePermission.OWNER_EXECUTE);
                if (parent != null) {
                    Set<PosixFilePermission> posixFilePermissions = Files.getPosixFilePermissions(parent, linkOptionArr);
                    HashSet hashSet = new HashSet(posixFilePermissions);
                    hashSet.addAll(listAsList);
                    if (hashSet.equals(posixFilePermissions)) {
                        return;
                    }
                    Files.setPosixFilePermissions(parent, hashSet);
                    return;
                }
                return;
            }
        }
        throw new IOException(String.format("DOS or POSIX file operations not available for '%s', linkOptions %s", path, Arrays.toString(linkOptionArr)));
    }
}
