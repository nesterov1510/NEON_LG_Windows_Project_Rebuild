package ak;

import jd.t1;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class c extends t1 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public b f804a;
}
