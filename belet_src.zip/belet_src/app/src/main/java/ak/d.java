package ak;

import j$.nio.file.FileVisitResult;
import j$.nio.file.FileVisitor;
import j$.nio.file.Files;
import j$.nio.file.LinkOption;
import j$.nio.file.Path;
import j$.nio.file.SimpleFileVisitor;
import j$.nio.file.attribute.BasicFileAttributes;
import j$.util.Objects;
import j$.util.function.UnaryOperator$CC;
import j$.util.stream.Stream;
import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.NoSuchFileException;
import java.util.Arrays;
import java.util.function.UnaryOperator;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class d extends SimpleFileVisitor implements FileVisitor {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final g f805a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final b f806b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final bk.a f807c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final UnaryOperator f808d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final String[] f809e;
    public final boolean f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final LinkOption[] f810g;

    /* JADX WARN: Multi-variable type inference failed */
    public d(b bVar, LinkOption[] linkOptionArr, h[] hVarArr, String... strArr) {
        c cVar = new c();
        cVar.f804a = new b();
        bk.a aVar = bk.a.X;
        UnaryOperator unaryOperatorIdentity = UnaryOperator$CC.identity();
        cVar.f804a = bVar;
        this.f805a = new g(0 == true ? 1 : 0, this);
        this.f806b = cVar.f804a;
        this.f807c = aVar;
        this.f808d = unaryOperatorIdentity;
        String[] strArr2 = (String[]) strArr.clone();
        Arrays.sort(strArr2);
        this.f809e = strArr2;
        int i10 = yj.c.f23093a;
        this.f = hVarArr.length != 0 ? Stream.CC.of(hVarArr).anyMatch(new e(1)) : false;
        this.f810g = linkOptionArr == null ? (LinkOption[]) f.f813b.clone() : (LinkOption[]) linkOptionArr.clone();
    }

    public final boolean a(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof d) {
            return Objects.equals(this.f806b, ((d) obj).f806b);
        }
        return false;
    }

    public final int b() {
        return Objects.hash(this.f806b);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!a(obj) || d.class != obj.getClass()) {
            return false;
        }
        d dVar = (d) obj;
        return this.f == dVar.f && Arrays.equals(this.f809e, dVar.f809e);
    }

    public final int hashCode() {
        return Objects.hash(Boolean.valueOf(this.f)) + (((b() * 31) + Arrays.hashCode(this.f809e)) * 31);
    }

    @Override // j$.nio.file.SimpleFileVisitor, j$.nio.file.FileVisitor
    public final FileVisitResult postVisitDirectory(Object obj, IOException iOException) throws IOException {
        Path path = (Path) obj;
        DirectoryStream<Path> directoryStreamNewDirectoryStream = Files.newDirectoryStream(path);
        try {
            boolean zHasNext = directoryStreamNewDirectoryStream.iterator().hasNext();
            directoryStreamNewDirectoryStream.close();
            if (!zHasNext) {
                Files.deleteIfExists(path);
            }
            this.f806b.f802b.f800a++;
            return FileVisitResult.CONTINUE;
        } catch (Throwable th2) {
            if (directoryStreamNewDirectoryStream != null) {
                try {
                    directoryStreamNewDirectoryStream.close();
                } catch (Throwable th3) {
                    th2.addSuppressed(th3);
                }
            }
            throw th2;
        }
    }

    @Override // j$.nio.file.SimpleFileVisitor, j$.nio.file.FileVisitor
    public final FileVisitResult preVisitDirectory(Object obj, BasicFileAttributes basicFileAttributes) {
        Path path = (Path) obj;
        this.f807c.getClass();
        FileVisitResult fileVisitResult = FileVisitResult.CONTINUE;
        Path fileName = path != null ? path.getFileName() : null;
        return Arrays.binarySearch(this.f809e, fileName != null ? fileName.toString() : null) < 0 ? fileVisitResult : FileVisitResult.SKIP_SUBTREE;
    }

    public final String toString() {
        return this.f806b.toString();
    }

    @Override // j$.nio.file.SimpleFileVisitor, j$.nio.file.FileVisitor
    public final FileVisitResult visitFile(Object obj, BasicFileAttributes basicFileAttributes) {
        Path path = (Path) obj;
        Path fileName = path != null ? path.getFileName() : null;
        if (Arrays.binarySearch(this.f809e, fileName != null ? fileName.toString() : null) < 0) {
            LinkOption[] linkOptionArr = this.f810g;
            if (Files.exists(path, linkOptionArr)) {
                if (this.f) {
                    f.c(path, linkOptionArr);
                }
                Files.deleteIfExists(path);
            }
            if (Files.isSymbolicLink(path)) {
                try {
                    Files.delete(path);
                } catch (NoSuchFileException unused) {
                }
            }
        }
        b bVar = this.f806b;
        bVar.f803c.f800a++;
        bVar.f801a.f800a += basicFileAttributes.size();
        return FileVisitResult.CONTINUE;
    }

    @Override // j$.nio.file.SimpleFileVisitor, j$.nio.file.FileVisitor
    public final FileVisitResult visitFileFailed(Object obj, IOException iOException) {
        return super.visitFileFailed((Path) obj, iOException);
    }
}
