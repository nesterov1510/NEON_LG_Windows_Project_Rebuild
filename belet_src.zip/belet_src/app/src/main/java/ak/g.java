package ak;

import a0.t3;
import a0.y4;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.media.session.MediaController;
import android.media.session.MediaSession;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.os.Parcelable;
import android.os.RemoteException;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import androidx.appcompat.widget.c0;
import androidx.appcompat.widget.r3;
import androidx.fragment.app.f1;
import androidx.media3.session.b0;
import androidx.media3.session.b5;
import androidx.media3.session.c2;
import androidx.media3.session.c3;
import androidx.media3.session.d3;
import androidx.media3.session.d5;
import androidx.media3.session.e2;
import androidx.media3.session.h5;
import androidx.media3.session.j5;
import androidx.media3.session.m3;
import androidx.media3.session.o5;
import androidx.media3.session.q5;
import androidx.media3.session.r5;
import androidx.media3.session.s2;
import androidx.media3.session.s5;
import androidx.media3.session.t;
import androidx.media3.session.u5;
import androidx.media3.session.x4;
import androidx.media3.session.y1;
import androidx.media3.session.z2;
import androidx.media3.session.z4;
import bf.o;
import cb.v;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.firebase.crashlytics.CrashlyticsRegistrar;
import com.google.protobuf.m0;
import eo.a1;
import eo.h0;
import eo.k2;
import eo.t2;
import eo.v0;
import g0.f0;
import g0.g1;
import g0.q1;
import g0.r1;
import g0.w;
import gb.p;
import gd.k;
import gd.n;
import gd.s;
import gd.u;
import gd.x;
import gd.y;
import i3.w0;
import i3.y0;
import j2.q;
import j2.z1;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import jd.t1;
import l1.i;
import l3.l0;
import l3.m;
import lc.l2;
import lc.u0;
import m0.d1;
import m0.e1;
import okhttp3.internal.url._UrlKt;
import p3.l;
import rc.p0;
import tm.belet.films.domain.models.profile.ResponseModel;
import w.x0;
import we.j;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class g implements m, c2, m3, z4, x4, i, r0.a, p.a, l, ad.f, com.google.android.material.internal.h, ae.a, q, f1, f0, d1 {
    public final /* synthetic */ Object X;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f814e;

    public /* synthetic */ g(int i10, Object obj) {
        this.f814e = i10;
        this.X = obj;
    }

    @Override // p3.l
    public void a(long j10, long j11, long j12) {
        c4.m mVar = (c4.m) this.X;
        if (mVar.f3918e == null) {
            return;
        }
        float fA0 = (j10 == -1 || j10 == 0) ? -1.0f : l0.a0(j11, j10);
        c4.h hVar = mVar.f3918e;
        hVar.getClass();
        hVar.b(j10, j11, fA0);
    }

    @Override // r0.a, p.a
    public ListenableFuture apply(Object obj) {
        return (ListenableFuture) ((t3) this.X).invoke(obj);
    }

    @Override // androidx.media3.session.m3
    public void b(c3 c3Var, int i10) {
        c3Var.o(i10, (q5) this.X);
    }

    @Override // androidx.fragment.app.f1
    public void c(String str, Bundle bundle) {
        switch (this.f814e) {
            case 23:
                v0 v0Var = (v0) this.X;
                if (bundle.getBoolean("play_event")) {
                    Bundle bundle2 = new Bundle();
                    bundle2.putBoolean("play_event", true);
                    v0Var.v().f0("main_event_sheet_request_key", bundle2);
                    v0Var.o0();
                } else if (bundle.getBoolean("ask_permission")) {
                    Bundle bundle3 = new Bundle();
                    bundle3.putBoolean("ask_permission", true);
                    v0Var.v().f0("main_event_sheet_request_key", bundle3);
                }
                if (bundle.containsKey("notify_state")) {
                    v0Var.K1 = bundle.getBoolean("notify_state");
                }
                break;
            case 24:
                ((a1) this.X).I1 = bundle.getBoolean("profile_update", false);
                break;
            case 25:
                k2 k2Var = (k2) this.X;
                ResponseModel responseModel = (ResponseModel) ((Parcelable) t1.o(bundle, "low_balance", ResponseModel.class));
                if (responseModel != null) {
                    Bundle bundle4 = new Bundle();
                    bundle4.putParcelable("low_balance", responseModel);
                    k2Var.v().f0("switch_sheet_request_key", bundle4);
                } else if (bundle.getBoolean("profile_update")) {
                    k2Var.I1 = true;
                }
                break;
            default:
                ((t2) this.X).J1 = bundle.getBoolean("profile_update", false);
                break;
        }
    }

    @Override // j2.q
    public z1 d(View view, z1 z1Var) {
        h0 h0Var = (h0) this.X;
        kotlin.jvm.internal.q.g(view, "view");
        a2.c cVarH = z1Var.f12739a.h(519);
        kotlin.jvm.internal.q.f(cVarH, "getInsets(...)");
        view.setPadding(view.getPaddingLeft(), cVarH.f445b, view.getPaddingRight(), view.getPaddingBottom());
        dm.f fVar = h0Var.G1;
        if (fVar != null) {
            ro.g.F((LinearLayout) fVar.f7000l, null, null, null, Integer.valueOf(cVarH.f447d / 2));
            return z1.f12738b;
        }
        kotlin.jvm.internal.q.n("binding");
        throw null;
    }

    @Override // g0.f0
    public void e(r1 r1Var) {
        ((y) this.X).e(r1Var);
    }

    @Override // androidx.media3.session.x4
    public void f(j5 j5Var, d3 d3Var) {
        ((l3.i) this.X).accept(j5Var);
    }

    @Override // ae.a
    public void g(ae.b bVar) {
        switch (this.f814e) {
            case 19:
                dd.a aVar = (dd.a) this.X;
                if (Log.isLoggable("FirebaseCrashlytics", 3)) {
                    Log.d("FirebaseCrashlytics", "Crashlytics native component now available.", null);
                }
                aVar.f6858b.set((dd.a) bVar.get());
                break;
            default:
                dd.b bVar2 = (dd.b) this.X;
                m7.i iVar = ((j) ((ze.a) bVar.get())).a("firebase").f21802i;
                ((Set) iVar.Z).add(bVar2);
                gb.i iVarB = ((xe.c) iVar.f15154e).b();
                iVarB.d((Executor) iVar.Y, new androidx.media3.session.t1(iVar, iVarB, bVar2, 14));
                if (Log.isLoggable("FirebaseCrashlytics", 3)) {
                    Log.d("FirebaseCrashlytics", "Registering RemoteConfig Rollouts subscriber", null);
                }
                break;
        }
    }

    /* JADX WARN: Code duplicated, block: B:99:0x0435  */
    @Override // ad.f
    public Object h(y4 y4Var) {
        s sVar;
        String str;
        int i10;
        int i11;
        int i12;
        Throwable th2;
        cd.d dVar;
        p pVar;
        p pVarJ;
        boolean z5;
        NetworkInfo activeNetworkInfo;
        Resources resources;
        od.a aVarA;
        CrashlyticsRegistrar crashlyticsRegistrar = (CrashlyticsRegistrar) this.X;
        int i13 = CrashlyticsRegistrar.f6315d;
        long jCurrentTimeMillis = System.currentTimeMillis();
        tc.f fVar = (tc.f) y4Var.a(tc.f.class);
        be.d dVar2 = (be.d) y4Var.a(be.d.class);
        ad.s sVarQ = y4Var.q(dd.a.class);
        ad.s sVarQ2 = y4Var.q(xc.b.class);
        ad.s sVarQ3 = y4Var.q(ze.a.class);
        ExecutorService executorService = (ExecutorService) y4Var.d(crashlyticsRegistrar.f6316a);
        ExecutorService executorService2 = (ExecutorService) y4Var.d(crashlyticsRegistrar.f6317b);
        ExecutorService executorService3 = (ExecutorService) y4Var.d(crashlyticsRegistrar.f6318c);
        fVar.a();
        Context context = fVar.f19185a;
        String packageName = context.getPackageName();
        Log.i("FirebaseCrashlytics", "Initializing Firebase Crashlytics 20.0.6 for " + packageName, null);
        hd.d dVar3 = new hd.d(executorService, executorService2);
        md.c cVar = new md.c(context);
        ea.l lVar = new ea.l(fVar);
        x xVar = new x(context, packageName, dVar2, lVar);
        dd.a aVar = new dd.a(sVarQ);
        cd.b bVar = new cd.b(sVarQ2);
        gd.j jVar = new gd.j(lVar, cVar);
        cf.c cVar2 = cf.c.f4524a;
        cf.d dVar4 = cf.d.f4526e;
        cf.c cVar3 = cf.c.f4524a;
        cf.a aVarA2 = cf.c.a(dVar4);
        if (aVarA2.f4519b != null) {
            Log.d("FirebaseSessions", "Subscriber " + dVar4 + " already registered.");
        } else {
            aVarA2.f4519b = jVar;
            Log.d("FirebaseSessions", "Subscriber " + dVar4 + " registered.");
            aVarA2.f4518a.countDown();
        }
        String str2 = "FirebaseCrashlytics";
        s sVar2 = new s(fVar, xVar, aVar, lVar, new cd.a(bVar), new cd.a(bVar), cVar, jVar, new z7.b(18, sVarQ3), dVar3);
        hd.d dVar5 = sVar2.f8867o;
        fVar.a();
        String str3 = fVar.f19187c.f19196b;
        int iD = gd.g.d(context, "com.google.firebase.crashlytics.mapping_file_id", "string");
        if (iD == 0) {
            iD = gd.g.d(context, "com.crashlytics.android.build_id", "string");
        }
        String string = iD != 0 ? context.getResources().getString(iD) : null;
        ArrayList arrayList = new ArrayList();
        int iD2 = gd.g.d(context, "com.google.firebase.crashlytics.build_ids_lib", "array");
        int iD3 = gd.g.d(context, "com.google.firebase.crashlytics.build_ids_arch", "array");
        int iD4 = gd.g.d(context, "com.google.firebase.crashlytics.build_ids_build_id", "array");
        if (iD2 == 0 || iD3 == 0 || iD4 == 0) {
            sVar = sVar2;
            str = str3;
            i10 = 0;
            i11 = 1;
            i12 = 3;
            String str4 = String.format("Could not find resources: %d %d %d", Integer.valueOf(iD2), Integer.valueOf(iD3), Integer.valueOf(iD4));
            if (Log.isLoggable(str2, 3)) {
                th2 = null;
                Log.d(str2, str4, null);
            } else {
                th2 = null;
            }
        } else {
            i10 = 0;
            String[] stringArray = context.getResources().getStringArray(iD2);
            String[] stringArray2 = context.getResources().getStringArray(iD3);
            String[] stringArray3 = context.getResources().getStringArray(iD4);
            i11 = 1;
            if (stringArray.length == stringArray3.length && stringArray2.length == stringArray3.length) {
                int i14 = 0;
                while (i14 < stringArray3.length) {
                    int i15 = i14;
                    arrayList.add(new gd.d(stringArray[i15], stringArray2[i15], stringArray3[i15]));
                    i14 = i15 + 1;
                    str3 = str3;
                    sVar2 = sVar2;
                }
                sVar = sVar2;
                str = str3;
            } else {
                sVar = sVar2;
                str = str3;
                String str5 = String.format("Lengths did not match: %d %d %d", Integer.valueOf(stringArray.length), Integer.valueOf(stringArray2.length), Integer.valueOf(stringArray3.length));
                if (Log.isLoggable(str2, 3)) {
                    Log.d(str2, str5, null);
                }
            }
            th2 = null;
            i12 = 3;
        }
        String strU = x0.u("Mapping file ID is: ", string);
        if (Log.isLoggable(str2, i12)) {
            Log.d(str2, strU, th2);
        }
        int size = arrayList.size();
        int i16 = i10;
        while (i16 < size) {
            Object obj = arrayList.get(i16);
            i16++;
            gd.d dVar6 = (gd.d) obj;
            String str6 = dVar6.f8808a;
            String str7 = dVar6.f8809b;
            String str8 = dVar6.f8810c;
            int i17 = size;
            StringBuilder sbN = m0.n("Build id for ", str6, " on ", str7, ": ");
            sbN.append(str8);
            String string2 = sbN.toString();
            if (Log.isLoggable(str2, 3)) {
                Log.d(str2, string2, null);
            }
            size = i17;
        }
        String str9 = str;
        try {
            gd.a aVarA3 = gd.a.a(context, xVar, str9, string, arrayList, new m7.c(context));
            String str10 = "Installer package name is: " + aVarA3.f8799d;
            if (Log.isLoggable(str2, 2)) {
                Log.v(str2, str10, null);
            }
            new cb.x(21);
            String str11 = aVarA3.f;
            String str12 = aVarA3.f8801g;
            String strD = xVar.d();
            v vVar = new v(11);
            ga.e eVar = new ga.e(vVar);
            g6.m mVar = new g6.m(cVar);
            Locale locale = Locale.US;
            String strX = p0.e.x("https://firebase-settings.crashlytics.com/spi/v2/platforms/android/gmp/", str9, "/settings");
            cp.c cVar4 = new cp.c();
            if (strX == null) {
                throw new IllegalArgumentException("url must not be null.");
            }
            cVar4.f6478e = strX;
            String str13 = Build.MANUFACTURER;
            String str14 = x.h;
            String strM = p0.e.m(str13.replaceAll(str14, _UrlKt.FRAGMENT_ENCODE_SET), "/", Build.MODEL.replaceAll(str14, _UrlKt.FRAGMENT_ENCODE_SET));
            String strReplaceAll = Build.VERSION.INCREMENTAL.replaceAll(str14, _UrlKt.FRAGMENT_ENCODE_SET);
            String strReplaceAll2 = Build.VERSION.RELEASE.replaceAll(str14, _UrlKt.FRAGMENT_ENCODE_SET);
            int iD5 = gd.g.d(context, "com.google.firebase.crashlytics.mapping_file_id", "string");
            if (iD5 == 0) {
                iD5 = gd.g.d(context, "com.crashlytics.android.build_id", "string");
            }
            String[] strArr = {iD5 != 0 ? context.getResources().getString(iD5) : null, str9, str12, str11};
            ArrayList arrayList2 = new ArrayList();
            int i18 = 0;
            while (i18 < 4) {
                String str15 = strArr[i18];
                String[] strArr2 = strArr;
                if (str15 != null) {
                    arrayList2.add(str15.replace("-", _UrlKt.FRAGMENT_ENCODE_SET).toLowerCase(Locale.US));
                }
                i18++;
                strArr = strArr2;
            }
            Collections.sort(arrayList2);
            StringBuilder sb2 = new StringBuilder();
            int size2 = arrayList2.size();
            int i19 = 0;
            while (i19 < size2) {
                Object obj2 = arrayList2.get(i19);
                i19++;
                sb2.append((String) obj2);
                arrayList2 = arrayList2;
            }
            String string3 = sb2.toString();
            od.c cVar5 = new od.c(str9, strM, strReplaceAll, strReplaceAll2, xVar, string3.length() > 0 ? gd.g.h(string3) : null, str12, str11, m0.f(strD != null ? 4 : i11));
            dm.l lVar2 = new dm.l();
            AtomicReference atomicReference = new AtomicReference();
            lVar2.h = atomicReference;
            lVar2.f7044i = new AtomicReference(new gb.j());
            lVar2.f7042e = context;
            lVar2.f = cVar5;
            lVar2.f7040c = vVar;
            lVar2.f7039b = eVar;
            lVar2.f7041d = mVar;
            lVar2.f7038a = cVar4;
            lVar2.f7043g = lVar;
            atomicReference.set(cb.x.s(vVar));
            AtomicReference atomicReference2 = (AtomicReference) lVar2.f7044i;
            AtomicReference atomicReference3 = (AtomicReference) lVar2.h;
            if (!((Context) lVar2.f7042e).getSharedPreferences("com.google.firebase.crashlytics", 0).getString("existing_instance_identifier", _UrlKt.FRAGMENT_ENCODE_SET).equals(((od.c) lVar2.f).f) || (aVarA = lVar2.a(i11)) == null) {
                od.a aVarA4 = lVar2.a(3);
                if (aVarA4 != null) {
                    atomicReference3.set(aVarA4);
                    ((gb.j) atomicReference2.get()).d(aVarA4);
                }
                ea.l lVar3 = (ea.l) lVar2.f7043g;
                p pVar2 = ((gb.j) lVar3.f7730s0).f8781a;
                synchronized (lVar3.Y) {
                    pVar = ((gb.j) lVar3.Z).f8781a;
                }
                pVarJ = hd.a.a(pVar2, pVar).j(dVar3.f9838a, new m7.c(lVar2, dVar3, 22));
            } else {
                atomicReference3.set(aVarA);
                ((gb.j) atomicReference2.get()).d(aVarA);
                pVarJ = fk.j.o(null);
            }
            pVarJ.c(executorService3, new o(5));
            s sVar3 = sVar;
            md.c cVar6 = sVar3.f8861i;
            Context context2 = sVar3.f8855a;
            if (context2 == null || (resources = context2.getResources()) == null) {
                z5 = true;
            } else {
                int iD6 = gd.g.d(context2, "com.crashlytics.RequireBuildId", "bool");
                if (iD6 > 0) {
                    z5 = resources.getBoolean(iD6);
                } else {
                    int iD7 = gd.g.d(context2, "com.crashlytics.RequireBuildId", "string");
                    if (iD7 > 0) {
                        z5 = Boolean.parseBoolean(context2.getString(iD7));
                    } else {
                        z5 = true;
                    }
                }
            }
            String str16 = r35.f8797b;
            if (z5) {
                str2 = str2;
                if (TextUtils.isEmpty(str16)) {
                    Log.e(str2, ".");
                    Log.e(str2, ".     |  | ");
                    Log.e(str2, ".     |  |");
                    Log.e(str2, ".     |  |");
                    Log.e(str2, ".   \\ |  | /");
                    Log.e(str2, ".    \\    /");
                    Log.e(str2, ".     \\  /");
                    Log.e(str2, ".      \\/");
                    Log.e(str2, ".");
                    Log.e(str2, "The Crashlytics build ID is missing. This occurs when the Crashlytics Gradle plugin is missing from your app's build configuration. Please review the Firebase Crashlytics onboarding instructions at https://firebase.google.com/docs/crashlytics/get-started?platform=android#add-plugin");
                    Log.e(str2, ".");
                    Log.e(str2, ".      /\\");
                    Log.e(str2, ".     /  \\");
                    Log.e(str2, ".    /    \\");
                    Log.e(str2, ".   / |  | \\");
                    Log.e(str2, ".     |  |");
                    Log.e(str2, ".     |  |");
                    Log.e(str2, ".     |  |");
                    Log.e(str2, ".");
                    throw new IllegalStateException("The Crashlytics build ID is missing. This occurs when the Crashlytics Gradle plugin is missing from your app's build configuration. Please review the Firebase Crashlytics onboarding instructions at https://firebase.google.com/docs/crashlytics/get-started?platform=android#add-plugin");
                }
            } else {
                str2 = str2;
                if (Log.isLoggable(str2, 2)) {
                    Log.v(str2, "Configured not to require a build ID.", null);
                }
            }
            String str17 = new gd.e().f8813a;
            try {
                int i20 = 14;
                sVar3.f = new m7.e("crash_marker", cVar6, i20);
                sVar3.f8859e = new m7.e("initialization_marker", cVar6, i20);
                r3 r3Var = new r3(str17, cVar6, dVar5);
                id.f fVar2 = new id.f(cVar6);
                m7.e eVar2 = new m7.e(new pd.a[]{new cb.x(26)});
                z7.b bVar2 = sVar3.f8866n;
                bVar2.getClass();
                ((ad.s) bVar2.X).a(new g(20, new dd.b(r3Var)));
                sVar3.f8860g = new n(sVar3.f8855a, sVar3.h, sVar3.f8856b, sVar3.f8861i, sVar3.f, aVarA3, r3Var, fVar2, md.c.e(sVar3.f8855a, sVar3.h, sVar3.f8861i, aVarA3, fVar2, r3Var, eVar2, lVar2, sVar3.f8857c, sVar3.f8864l, sVar3.f8867o), sVar3.f8865m, sVar3.f8863k, sVar3.f8864l, sVar3.f8867o);
                m7.e eVar3 = sVar3.f8859e;
                md.c cVar7 = (md.c) eVar3.Y;
                String str18 = (String) eVar3.X;
                cVar7.getClass();
                boolean zExists = new File((File) cVar7.f15309d, str18).exists();
                try {
                    Boolean.TRUE.equals((Boolean) dVar5.f9838a.f9836e.submit(new com.airbnb.lottie.m(1, sVar3)).get(3L, TimeUnit.SECONDS));
                } catch (Exception unused) {
                }
                n nVar = sVar3.f8860g;
                Thread.UncaughtExceptionHandler defaultUncaughtExceptionHandler = Thread.getDefaultUncaughtExceptionHandler();
                nVar.f8838e.f9838a.a(new e7.o(nVar, str17, 9));
                u uVar = new u(new k(nVar), lVar2, defaultUncaughtExceptionHandler, nVar.f8841j);
                nVar.f8845n = uVar;
                Thread.setDefaultUncaughtExceptionHandler(uVar);
                if (!zExists || (context2.checkCallingOrSelfPermission("android.permission.ACCESS_NETWORK_STATE") == 0 && ((activeNetworkInfo = ((ConnectivityManager) context2.getSystemService("connectivity")).getActiveNetworkInfo()) == null || !activeNetworkInfo.isConnectedOrConnecting()))) {
                    if (Log.isLoggable(str2, 3)) {
                        Log.d(str2, "Successfully configured exception handler.", null);
                    }
                    dVar5.f9838a.a(new gd.o(sVar3, lVar2, 0));
                } else {
                    if (Log.isLoggable(str2, 3)) {
                        Log.d(str2, "Crashlytics did not finish previous background initialization. Initializing synchronously.", null);
                    }
                    sVar3.b(lVar2);
                }
            } catch (Exception e3) {
                Log.e(str2, "Crashlytics was not started due to an exception during initialization", e3);
                sVar3.f8860g = null;
            }
            dVar = new cd.d(sVar3);
            long jCurrentTimeMillis2 = System.currentTimeMillis() - jCurrentTimeMillis;
            if (jCurrentTimeMillis2 > 16) {
                String strJ = p0.e.j(jCurrentTimeMillis2, "Initializing Crashlytics blocked main for ", " ms");
                if (Log.isLoggable(str2, 3)) {
                    Log.d(str2, strJ, null);
                }
            }
            return dVar;
        } catch (PackageManager.NameNotFoundException e10) {
            Log.e(str2, "Error retrieving app package info.", e10);
            dVar = null;
        }
    }

    @Override // l1.i
    public Object i(l1.h hVar) {
        switch (this.f814e) {
            case 10:
                kotlinx.coroutines.x0 this_asListenableFuture = (kotlinx.coroutines.x0) this.X;
                kotlin.jvm.internal.q.g(this_asListenableFuture, "$this_asListenableFuture");
                this_asListenableFuture.invokeOnCompletion(new b6.a(hVar, this_asListenableFuture));
                return "Deferred.asListenableFuture";
            case 18:
                ((d1.u) this.X).f6645k.set(hVar);
                return "textureViewImpl_waitForNextFrame";
            default:
                w wVar = (w) this.X;
                wVar.f8450n.g();
                if (wVar.f8451o.b()) {
                    q1 q1Var = (q1) wVar.f8451o.getValue();
                    synchronized (q1Var.f8415a) {
                        q1Var.f8416b.disable();
                        q1Var.f8417c.clear();
                        q1Var.f8418d = -1;
                    }
                }
                wVar.f8439a.b().a(new e7.o(wVar, hVar, 4), wVar.f8442d);
                return "CameraX shutdownInternal";
        }
    }

    @Override // l3.m
    public void invoke(Object obj) {
        ((y0) obj).t(((h5) ((y1) this.X).f2790p.f515a).B);
    }

    @Override // androidx.media3.session.z4
    public Object j(s2 s2Var, d3 d3Var, int i10) {
        int i11 = this.f814e;
        Object obj = this.X;
        switch (i11) {
            case 6:
                return s2Var.r(d3Var, (u0) obj);
            case 7:
                return s2Var.w(d3Var, (e2) obj);
            default:
                x4 x4Var = (x4) obj;
                p0 p0Var = p0.X;
                if (!s2Var.o()) {
                    x4Var.f(s2Var.f2675t, d3Var);
                    b5.s1(s2Var, d3Var, i10, new s5(0));
                }
                return p0.X;
        }
    }

    @Override // androidx.media3.session.c2
    public void k(androidx.media3.session.r1 r1Var) {
        switch (this.f814e) {
            case 2:
                androidx.media3.session.m mVar = (androidx.media3.session.m) this.X;
                r1Var.getClass();
                t tVar = mVar.f2525c;
                u5 u5Var = r1Var.f2610e;
                b0 b0Var = r1Var.f2606a;
                if (r1Var.E != null) {
                    l3.b.d("MCImplBase", "Cannot be notified about the connection result many times. Probably a bug or malicious app.");
                    b0Var.X();
                } else {
                    u0 u0Var = mVar.f2534n;
                    Bundle bundle = mVar.f2529i;
                    r1Var.E = tVar;
                    r1Var.f2620q = mVar.f2530j;
                    r1Var.f2621r = mVar.f2526d;
                    r1Var.f2626w = mVar.f2527e;
                    w0 w0Var = mVar.f;
                    r1Var.f2627x = w0Var;
                    w0 w0Var2 = mVar.f2528g;
                    r1Var.f2628y = w0Var2;
                    w0 w0VarD0 = r1Var.D0(w0Var, w0Var2);
                    r1Var.f2629z = w0VarD0;
                    u0 u0Var2 = mVar.f2531k;
                    r1Var.f2622s = u0Var2;
                    u0 u0Var3 = mVar.f2532l;
                    r1Var.f2623t = u0Var3;
                    l2 l2VarB1 = androidx.media3.session.r1.B1(u0Var3, u0Var2, r1Var.f2626w, w0VarD0, bundle);
                    r1Var.f2624u = l2VarB1;
                    r1Var.f2625v = androidx.media3.session.r1.A1(l2VarB1, r1Var.f2622s, mVar.f2529i, r1Var.f2626w, r1Var.f2629z, mVar.f2524b);
                    c0 c0Var = new c0(4);
                    for (int i10 = 0; i10 < u0Var.size(); i10++) {
                        androidx.media3.session.d dVar = (androidx.media3.session.d) u0Var.get(i10);
                        o5 o5Var = dVar.f2225a;
                        if (o5Var != null && o5Var.f2575a == 0) {
                            c0Var.u(o5Var.f2576b, dVar);
                        }
                    }
                    c0Var.e(true);
                    MediaSession.Token tokenJ = mVar.f2533m;
                    if (tokenJ == null) {
                        tokenJ = u5Var.f2712a.j();
                    }
                    if (tokenJ != null) {
                        r1Var.F = new MediaController(r1Var.f2609d, tokenJ);
                    }
                    try {
                        tVar.asBinder().linkToDeath(r1Var.f2611g, 0);
                        r1Var.f2617n = new u5(u5Var.f2712a.b(), mVar.f2523a, mVar.f2524b, u5Var.f2712a.h(), mVar.f2525c, mVar.h, tokenJ);
                        r1Var.J = bundle;
                        b0Var.a();
                    } catch (RemoteException unused) {
                        b0Var.X();
                        return;
                    }
                }
                break;
            case 3:
                r5 r5Var = (r5) this.X;
                if (r1Var.b1() && r1Var.f2614k.isEmpty()) {
                    r5 r5Var2 = r1Var.f2620q.f2326c;
                    if (r5Var2.f2649c < r5Var.f2649c && d5.a(r5Var, r5Var2)) {
                        r1Var.f2620q = r1Var.f2620q.j(r5Var);
                        break;
                    }
                }
                break;
            default:
                Bundle bundle2 = (Bundle) this.X;
                if (r1Var.b1()) {
                    l2 l2Var = r1Var.f2624u;
                    l2 l2Var2 = r1Var.f2625v;
                    r1Var.J = bundle2;
                    l2 l2VarB2 = androidx.media3.session.r1.B1(r1Var.f2623t, r1Var.f2622s, r1Var.f2626w, r1Var.f2629z, bundle2);
                    r1Var.f2624u = l2VarB2;
                    r1Var.f2625v = androidx.media3.session.r1.A1(l2VarB2, r1Var.f2622s, r1Var.J, r1Var.f2626w, r1Var.f2629z, r1Var.n1());
                    boolean zEquals = r1Var.f2624u.equals(l2Var);
                    r1Var.f2625v.equals(l2Var2);
                    b0 b0Var2 = r1Var.f2606a;
                    b0Var2.getClass();
                    ji.k.A(Looper.myLooper() == b0Var2.f2187r0.getLooper());
                    z2 z2Var = b0Var2.Z;
                    z2Var.getClass();
                    if (!zEquals) {
                        z2Var.h();
                    }
                    break;
                }
                break;
        }
    }

    @Override // m0.d1
    public void l(e1 e1Var) {
        g1 g1Var = (g1) this.X;
        synchronized (g1Var.f8342e) {
            g1Var.Y++;
        }
        g1Var.j(e1Var);
    }

    @Override // p.a
    public Object apply(Object obj) {
        return (Void) ((c1.c) this.X).invoke(obj);
    }
}
