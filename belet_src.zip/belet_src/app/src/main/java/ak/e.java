package ak;

import hk.b2;
import hk.y2;
import j$.util.Objects;
import j$.util.function.Predicate$CC;
import java.net.Inet4Address;
import java.net.InetSocketAddress;
import java.util.function.Predicate;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class e implements Predicate {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f811a;

    public /* synthetic */ e(int i10) {
        this.f811a = i10;
    }

    public /* synthetic */ Predicate and(Predicate predicate) {
        int i10 = this.f811a;
        return Predicate$CC.$default$and(this, predicate);
    }

    public /* synthetic */ Predicate negate() {
        switch (this.f811a) {
            case 0:
                break;
            case 1:
                break;
            case 2:
                break;
            case 3:
                break;
        }
        return Predicate$CC.$default$negate(this);
    }

    public /* synthetic */ Predicate or(Predicate predicate) {
        int i10 = this.f811a;
        return Predicate$CC.$default$or(this, predicate);
    }

    @Override // java.util.function.Predicate
    public final boolean test(Object obj) {
        switch (this.f811a) {
            case 0:
                return ((h) obj) == h.f815e;
            case 1:
                return h.f815e == ((h) obj);
            case 2:
                return ((y2) obj).a() == 6;
            case 3:
                return ((InetSocketAddress) obj).getAddress() instanceof Inet4Address;
            default:
                return Objects.nonNull((b2) obj);
        }
    }
}
