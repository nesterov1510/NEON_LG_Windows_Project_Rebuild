package ak;

import j$.util.Objects;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final a f801a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final a f802b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final a f803c;

    public b() {
        a aVar = new a();
        a aVar2 = new a();
        a aVar3 = new a();
        this.f801a = aVar;
        this.f802b = aVar2;
        this.f803c = aVar3;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof b)) {
            return false;
        }
        b bVar = (b) obj;
        return Objects.equals(this.f801a, bVar.f801a) && Objects.equals(this.f802b, bVar.f802b) && Objects.equals(this.f803c, bVar.f803c);
    }

    public final int hashCode() {
        return Objects.hash(this.f801a, this.f802b, this.f803c);
    }

    public final String toString() {
        return String.format("%,d files, %,d directories, %,d bytes", Long.valueOf(this.f803c.f800a), Long.valueOf(this.f802b.f800a), Long.valueOf(this.f801a.f800a));
    }
}
