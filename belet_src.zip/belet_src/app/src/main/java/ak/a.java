package ak;

import j$.util.Objects;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public long f800a;

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof a) && this.f800a == ((a) obj).f800a;
    }

    public final int hashCode() {
        return Objects.hash(Long.valueOf(this.f800a));
    }

    public final String toString() {
        return Long.toString(this.f800a);
    }
}
