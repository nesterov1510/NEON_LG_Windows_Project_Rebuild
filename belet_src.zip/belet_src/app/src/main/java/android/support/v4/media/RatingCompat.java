package android.support.v4.media;

import android.annotation.SuppressLint;
import android.os.Parcel;
import android.os.Parcelable;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
@SuppressLint({"BanParcelableUsage"})
public final class RatingCompat implements Parcelable {
    public static final Parcelable.Creator<RatingCompat> CREATOR = new aa.b(10);
    public final float X;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int f981e;

    public RatingCompat(int i10, float f) {
        this.f981e = i10;
        this.X = f;
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return this.f981e;
    }

    public final String toString() {
        StringBuilder sb2 = new StringBuilder("Rating:style=");
        sb2.append(this.f981e);
        sb2.append(" rating=");
        float f = this.X;
        sb2.append(f < 0.0f ? "unrated" : String.valueOf(f));
        return sb2.toString();
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i10) {
        parcel.writeInt(this.f981e);
        parcel.writeFloat(this.X);
    }
}
