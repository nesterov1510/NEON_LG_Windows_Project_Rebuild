package android.support.v4.media;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.media.MediaDescription;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
@SuppressLint({"BanParcelableUsage"})
public final class MediaDescriptionCompat implements Parcelable {
    public static final Parcelable.Creator<MediaDescriptionCompat> CREATOR = new aa.b(8);
    public final CharSequence X;
    public final CharSequence Y;
    public final CharSequence Z;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final String f975e;

    /* JADX INFO: renamed from: r0, reason: collision with root package name */
    public final Bitmap f976r0;

    /* JADX INFO: renamed from: s0, reason: collision with root package name */
    public final Uri f977s0;

    /* JADX INFO: renamed from: t0, reason: collision with root package name */
    public final Bundle f978t0;
    public final Uri u0;

    /* JADX INFO: renamed from: v0, reason: collision with root package name */
    public MediaDescription f979v0;

    public MediaDescriptionCompat(String str, CharSequence charSequence, CharSequence charSequence2, CharSequence charSequence3, Bitmap bitmap, Uri uri, Bundle bundle, Uri uri2) {
        this.f975e = str;
        this.X = charSequence;
        this.Y = charSequence2;
        this.Z = charSequence3;
        this.f976r0 = bitmap;
        this.f977s0 = uri;
        this.f978t0 = bundle;
        this.u0 = uri2;
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    public final String toString() {
        return ((Object) this.X) + ", " + ((Object) this.Y) + ", " + ((Object) this.Z);
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i10) {
        MediaDescription mediaDescriptionA = this.f979v0;
        if (mediaDescriptionA == null) {
            MediaDescription.Builder builderB = a.b();
            a.n(builderB, this.f975e);
            a.p(builderB, this.X);
            a.o(builderB, this.Y);
            a.j(builderB, this.Z);
            a.l(builderB, this.f976r0);
            a.m(builderB, this.f977s0);
            a.k(builderB, this.f978t0);
            b.b(builderB, this.u0);
            mediaDescriptionA = a.a(builderB);
            this.f979v0 = mediaDescriptionA;
        }
        mediaDescriptionA.writeToParcel(parcel, i10);
    }
}
