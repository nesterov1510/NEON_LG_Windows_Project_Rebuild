package android.support.v4.media.session;

import a0.w4;
import android.content.Intent;
import android.graphics.Path;
import android.net.Uri;
import android.os.BadParcelableException;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.util.Range;
import android.widget.EdgeEffect;
import android.widget.ImageView;
import androidx.appcompat.app.j;
import androidx.camera.camera2.compat.quirk.ExtraCroppingQuirk;
import androidx.media3.session.legacy.r0;
import eh.d;
import ej.l;
import g0.e;
import hk.b1;
import i3.p0;
import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import ji.k;
import kotlin.jvm.internal.q;
import kotlinx.coroutines.internal.x;
import l1.h;
import l1.m;
import qi.s;
import tm.belet.films.data.local.AppDatabase;
import w.x0;
import yh.v;
import yh.z;
import z.i;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public abstract class b {
    public static float A(EdgeEffect edgeEffect, float f, float f10) {
        if (Build.VERSION.SDK_INT >= 31) {
            return androidx.core.widget.c.c(edgeEffect, f, f10);
        }
        edgeEffect.onPull(f, f10);
        return f;
    }

    public static int C(long j10) {
        if (j10 > 2147483647L) {
            return Integer.MAX_VALUE;
        }
        if (j10 < -2147483648L) {
            return Integer.MIN_VALUE;
        }
        return (int) j10;
    }

    public static final void D(ImageView imageView, int i10) {
        q.g(imageView, "<this>");
        imageView.getLayoutParams().width = i10;
        imageView.requestLayout();
    }

    public static Object E(d dVar, String str, z zVar, l lVar, wi.c cVar, int i10) {
        if ((i10 & 8) != 0) {
            lVar = new pk.l(20);
        }
        th.c cVar2 = new th.c();
        cVar2.c(v.f23066c);
        cVar2.f19220d = new mh.l(zVar);
        cVar2.b(null);
        th.d.a(cVar2, str);
        lVar.invoke(cVar2);
        return new r0(cVar2, dVar).n(cVar);
    }

    public static int[] F(Collection collection) {
        if (collection instanceof qc.b) {
            qc.b bVar = (qc.b) collection;
            return Arrays.copyOfRange(bVar.f17249e, bVar.X, bVar.Y);
        }
        Object[] array = collection.toArray();
        int length = array.length;
        int[] iArr = new int[length];
        for (int i10 = 0; i10 < length; i10++) {
            Object obj = array[i10];
            obj.getClass();
            iArr[i10] = ((Number) obj).intValue();
        }
        return iArr;
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0008  */
    /* JADX WARN: Code duplicated, block: B:9:0x000c A[PHI: r1
      0x000c: PHI (r1v7 int) = (r1v0 int), (r1v1 int), (r1v2 int) binds: [B:8:0x000a, B:11:0x0010, B:30:0x002f] A[DONT_GENERATE, DONT_INLINE]] */
    public static e G(int i10) {
        int i11 = 6;
        if (i10 != 0) {
            int i12 = 1;
            if (i10 == 1) {
                i11 = 2;
            } else if (i10 == 2) {
                i11 = i12;
            } else {
                i12 = 5;
                if (i10 == 3) {
                    i11 = i12;
                } else if (i10 == 4) {
                    i11 = 3;
                } else if (i10 != 5) {
                    if (i10 == 6) {
                        i11 = 2;
                    } else {
                        i12 = 7;
                        if (i10 != 7 && i10 != 8) {
                            if (i10 == 9) {
                                i11 = 4;
                            } else if (i10 == 10) {
                                i11 = i12;
                            } else if (i10 != 11 && i10 != 12 && i10 != 13) {
                                throw new IllegalArgumentException("Unexpected CameraError: " + ((Object) i.a(i10)));
                            }
                        }
                    }
                }
            }
        }
        return new e(i11);
    }

    public static String H(byte[] bArr) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        for (int i10 = 0; i10 < (bArr.length + 2) / 3; i10++) {
            short[] sArr = new short[3];
            short[] sArr2 = new short[4];
            for (int i11 = 0; i11 < 3; i11++) {
                int i12 = (i10 * 3) + i11;
                if (i12 < bArr.length) {
                    sArr[i11] = (short) (bArr[i12] & 255);
                } else {
                    sArr[i11] = -1;
                }
            }
            sArr2[0] = (short) (sArr[0] >> 2);
            short s8 = sArr[1];
            if (s8 == -1) {
                sArr2[1] = (short) ((sArr[0] & 3) << 4);
            } else {
                sArr2[1] = (short) (((sArr[0] & 3) << 4) + (s8 >> 4));
            }
            short s10 = sArr[1];
            if (s10 == -1) {
                sArr2[3] = 64;
                sArr2[2] = 64;
            } else {
                short s11 = sArr[2];
                if (s11 == -1) {
                    sArr2[2] = (short) ((s10 & 15) << 2);
                    sArr2[3] = 64;
                } else {
                    sArr2[2] = (short) (((s10 & 15) << 2) + (s11 >> 6));
                    sArr2[3] = (short) (sArr[2] & 63);
                }
            }
            for (int i13 = 0; i13 < 4; i13++) {
                byteArrayOutputStream.write("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=".charAt(sArr2[i13]));
            }
        }
        return byteArrayOutputStream.toString();
    }

    public static String I(int i10) {
        return p0.e.k("OperatingMode(mode=", i10, ')');
    }

    public static final s J(String str) {
        int i10;
        tc.b.b(10);
        int length = str.length();
        if (length == 0) {
            return null;
        }
        int i11 = 0;
        char cCharAt = str.charAt(0);
        if (q.i(cCharAt, 48) < 0) {
            i10 = 1;
            if (length == 1 || cCharAt != '+') {
                return null;
            }
        } else {
            i10 = 0;
        }
        int i12 = 119304647;
        while (i10 < length) {
            int iDigit = Character.digit((int) str.charAt(i10), 10);
            if (iDigit < 0) {
                return null;
            }
            int i13 = i11 ^ Integer.MIN_VALUE;
            if (Integer.compare(i13, i12 ^ Integer.MIN_VALUE) > 0) {
                if (i12 != 119304647) {
                    return null;
                }
                i12 = (int) ((((long) (-1)) & 4294967295L) / (4294967295L & ((long) 10)));
                if (Integer.compare(i13, i12 ^ Integer.MIN_VALUE) > 0) {
                    return null;
                }
            }
            int i14 = i11 * 10;
            int i15 = iDigit + i14;
            if (Integer.compare(i15 ^ Integer.MIN_VALUE, i14 ^ Integer.MIN_VALUE) < 0) {
                return null;
            }
            i10++;
            i11 = i15;
        }
        return new s(i11);
    }

    public static final qi.v K(String str) {
        int i10;
        q.g(str, "<this>");
        int i11 = 10;
        tc.b.b(10);
        int length = str.length();
        if (length == 0) {
            return null;
        }
        char cCharAt = str.charAt(0);
        int i12 = 1;
        if (q.i(cCharAt, 48) >= 0) {
            i10 = 0;
        } else {
            if (length == 1 || cCharAt != '+') {
                return null;
            }
            i10 = 1;
        }
        long j10 = 10;
        long j11 = 0;
        long j12 = 512409557603043100L;
        while (i10 < length) {
            int iDigit = Character.digit((int) str.charAt(i10), i11);
            if (iDigit < 0) {
                return null;
            }
            int i13 = length;
            long j13 = j11 ^ Long.MIN_VALUE;
            int i14 = i10;
            if (Long.compare(j13, j12 ^ Long.MIN_VALUE) <= 0) {
                j10 = j10;
            } else {
                if (j12 != 512409557603043100L) {
                    return null;
                }
                if (j10 < 0) {
                    j12 = Long.MAX_VALUE < (j10 ^ Long.MIN_VALUE) ? 0L : 1L;
                } else {
                    long j14 = (Long.MAX_VALUE / j10) << i12;
                    j12 = j14 + ((long) ((((-1) - (j14 * j10)) ^ Long.MIN_VALUE) >= (j10 ^ Long.MIN_VALUE) ? i12 : 0));
                }
                if (Long.compare(j13, j12 ^ Long.MIN_VALUE) > 0) {
                    return null;
                }
            }
            long j15 = j11 * j10;
            long j16 = (((long) iDigit) & 4294967295L) + j15;
            if (Long.compare(j16 ^ Long.MIN_VALUE, j15 ^ Long.MIN_VALUE) < 0) {
                return null;
            }
            i10 = i14 + 1;
            j11 = j16;
            length = i13;
            j10 = j10;
            i11 = 10;
            i12 = 1;
        }
        return new qi.v(j11);
    }

    /* JADX WARN: Code duplicated, block: B:4:0x000b  */
    /* JADX WARN: Multi-variable type inference failed */
    public static Integer L(String str) {
        byte b10;
        Integer num;
        Long lValueOf;
        byte b11;
        str.getClass();
        if (str.isEmpty()) {
            lValueOf = 0;
            num = null;
        } else {
            int i10 = str.charAt(0) == '-' ? 1 : 0;
            if (i10 == str.length()) {
                lValueOf = 0;
                num = null;
            } else {
                int i11 = i10 + 1;
                char cCharAt = str.charAt(i10);
                if (cCharAt < 128) {
                    b10 = qc.c.f17250a[cCharAt];
                } else {
                    byte[] bArr = qc.c.f17250a;
                    b10 = -1;
                }
                if (b10 < 0 || b10 >= 10) {
                    num = null;
                    lValueOf = num;
                } else {
                    long j10 = -b10;
                    long j11 = 10;
                    long j12 = Long.MIN_VALUE / j11;
                    while (true) {
                        if (i11 < str.length()) {
                            int i12 = i11 + 1;
                            char cCharAt2 = str.charAt(i11);
                            if (cCharAt2 < 128) {
                                b11 = qc.c.f17250a[cCharAt2];
                            } else {
                                byte[] bArr2 = qc.c.f17250a;
                                b11 = -1;
                            }
                            if (b11 < 0 || b11 >= 10 || j10 < j12) {
                                num = null;
                            } else {
                                long j13 = j10 * j11;
                                num = null;
                                long j14 = b11;
                                if (j13 >= j14 - Long.MIN_VALUE) {
                                    j10 = j13 - j14;
                                    i11 = i12;
                                }
                            }
                        } else {
                            num = null;
                            if (i10 != 0) {
                                lValueOf = Long.valueOf(j10);
                            } else if (j10 != Long.MIN_VALUE) {
                                lValueOf = Long.valueOf(-j10);
                            }
                        }
                        lValueOf = num;
                    }
                }
            }
        }
        return (lValueOf == 0 || lValueOf.longValue() != ((long) lValueOf.intValue())) ? num : Integer.valueOf(lValueOf.intValue());
    }

    public static Bundle M(Bundle bundle) {
        if (bundle == null) {
            return null;
        }
        bundle.setClassLoader(b.class.getClassLoader());
        try {
            bundle.isEmpty();
            return bundle;
        } catch (BadParcelableException unused) {
            Log.e("MediaSessionCompat", "Could not unparcel the data.");
            return null;
        }
    }

    public static List a(int... iArr) {
        return iArr.length == 0 ? Collections.EMPTY_LIST : new qc.b(0, iArr.length, iArr);
    }

    public static boolean c(a2.d[] dVarArr, a2.d[] dVarArr2) {
        if (dVarArr == null || dVarArr2 == null || dVarArr.length != dVarArr2.length) {
            return false;
        }
        for (int i10 = 0; i10 < dVarArr.length; i10++) {
            a2.d dVar = dVarArr[i10];
            char c10 = dVar.f448a;
            a2.d dVar2 = dVarArr2[i10];
            if (c10 != dVar2.f448a || dVar.f449b.length != dVar2.f449b.length) {
                return false;
            }
        }
        return true;
    }

    public static void d(long j10) {
        if (j10 < 0 || j10 > 2147483647L) {
            throw new b1(x0.t("Invalid DNS TTL: ", j10));
        }
    }

    public static int e(long j10) {
        int i10 = (int) j10;
        k.j(j10, "Out of range: %s", ((long) i10) == j10);
        return i10;
    }

    public static int f(int i10, int i11) {
        k.k("min (%s) must be less than or equal to max (%s)", i11, x.MAX_CAPACITY_MASK, i11 <= 1073741823);
        return Math.min(Math.max(i10, i11), x.MAX_CAPACITY_MASK);
    }

    public static float[] g(float[] fArr, int i10) {
        if (i10 < 0) {
            throw new IllegalArgumentException();
        }
        int length = fArr.length;
        if (length < 0) {
            throw new ArrayIndexOutOfBoundsException();
        }
        int iMin = Math.min(i10, length);
        float[] fArr2 = new float[i10];
        System.arraycopy(fArr, 0, fArr2, 0, iMin);
        return fArr2;
    }

    /* JADX WARN: Code duplicated, block: B:11:0x002c  */
    /* JADX WARN: Code duplicated, block: B:17:0x0042  */
    /* JADX WARN: Code duplicated, block: B:41:0x0091  */
    /* JADX WARN: Code duplicated, block: B:46:0x009c A[Catch: NumberFormatException -> 0x00aa, TryCatch #0 {NumberFormatException -> 0x00aa, blocks: (B:22:0x0054, B:25:0x0068, B:27:0x006e, B:31:0x007a, B:44:0x0096, B:46:0x009c, B:52:0x00b1, B:53:0x00b4), top: B:68:0x0054 }] */
    /* JADX WARN: Code duplicated, block: B:50:0x00ae  */
    /* JADX WARN: Code duplicated, block: B:52:0x00b1 A[Catch: NumberFormatException -> 0x00aa, TryCatch #0 {NumberFormatException -> 0x00aa, blocks: (B:22:0x0054, B:25:0x0068, B:27:0x006e, B:31:0x007a, B:44:0x0096, B:46:0x009c, B:52:0x00b1, B:53:0x00b4), top: B:68:0x0054 }] */
    /* JADX WARN: Code duplicated, block: B:57:0x00c9  */
    /* JADX WARN: Code duplicated, block: B:72:0x00d7 A[SYNTHETIC] */
    public static a2.d[] i(String str) {
        int i10;
        String strTrim;
        float[] fArrG;
        ArrayList arrayList = new ArrayList();
        int i11 = 0;
        int i12 = 0;
        int i13 = 1;
        while (i13 < str.length()) {
            while (i13 < str.length()) {
                char cCharAt = str.charAt(i13);
                if ((cCharAt - 'Z') * (cCharAt - 'A') > 0) {
                    if ((cCharAt - 'z') * (cCharAt - 'a') > 0) {
                        continue;
                    } else if (cCharAt != 'e' && cCharAt != 'E') {
                        strTrim = str.substring(i12, i13).trim();
                        if (strTrim.isEmpty()) {
                            if (strTrim.charAt(i11) != 'z' || strTrim.charAt(i11) == 'Z') {
                                fArrG = new float[i11];
                            } else {
                                try {
                                    float[] fArr = new float[strTrim.length()];
                                    int length = strTrim.length();
                                    int i14 = i11;
                                    int i15 = 1;
                                    while (i15 < length) {
                                        int i16 = i11;
                                        int i17 = i16;
                                        int i18 = i17;
                                        int i19 = i18;
                                        for (int i20 = i15; i20 < strTrim.length(); i20++) {
                                            char cCharAt2 = strTrim.charAt(i20);
                                            if (cCharAt2 == ' ') {
                                                i16 = 0;
                                                i18 = 1;
                                            } else if (cCharAt2 != 'E' && cCharAt2 != 'e') {
                                                switch (cCharAt2) {
                                                    case ',':
                                                        i16 = 0;
                                                        i18 = 1;
                                                        break;
                                                    case '-':
                                                        if (i20 == i15 || i16 != 0) {
                                                            i16 = 0;
                                                        } else {
                                                            i16 = 0;
                                                            i18 = 1;
                                                            i19 = 1;
                                                        }
                                                        break;
                                                    case '.':
                                                        if (i17 == 0) {
                                                            i16 = 0;
                                                            i17 = 1;
                                                        } else {
                                                            i16 = 0;
                                                            i18 = 1;
                                                            i19 = 1;
                                                        }
                                                        break;
                                                    default:
                                                        i16 = 0;
                                                        break;
                                                }
                                            } else {
                                                i16 = 1;
                                            }
                                            if (i18 != 0) {
                                                if (i15 < i20) {
                                                    fArr[i14] = Float.parseFloat(strTrim.substring(i15, i20));
                                                    i14++;
                                                }
                                                if (i19 != 0) {
                                                    i15 = i20;
                                                } else {
                                                    i15 = i20 + 1;
                                                }
                                                i11 = 0;
                                            }
                                        }
                                        if (i15 < i20) {
                                            fArr[i14] = Float.parseFloat(strTrim.substring(i15, i20));
                                            i14++;
                                        }
                                        if (i19 != 0) {
                                            i15 = i20;
                                        } else {
                                            i15 = i20 + 1;
                                        }
                                        i11 = 0;
                                    }
                                    fArrG = g(fArr, i14);
                                    i11 = 0;
                                } catch (NumberFormatException e3) {
                                    throw new RuntimeException(p0.e.x("error in parsing \"", strTrim, "\""), e3);
                                }
                            }
                            arrayList.add(new a2.d(strTrim.charAt(i11), fArrG));
                        }
                        i12 = i13;
                        i13++;
                        i11 = 0;
                    }
                } else if (cCharAt != 'e') {
                    continue;
                }
                i13++;
            }
            strTrim = str.substring(i12, i13).trim();
            if (strTrim.isEmpty()) {
                if (strTrim.charAt(i11) != 'z') {
                    fArrG = new float[i11];
                } else {
                    fArrG = new float[i11];
                }
                arrayList.add(new a2.d(strTrim.charAt(i11), fArrG));
            }
            i12 = i13;
            i13++;
            i11 = 0;
        }
        if (i13 - i12 != 1 || i12 >= str.length()) {
            i10 = 0;
        } else {
            i10 = 0;
            arrayList.add(new a2.d(str.charAt(i12), new float[0]));
        }
        return (a2.d[]) arrayList.toArray(new a2.d[i10]);
    }

    public static Path j(String str) {
        Path path = new Path();
        try {
            a2.d.b(i(str), path);
            return path;
        } catch (RuntimeException e3) {
            throw new RuntimeException("Error in parsing ".concat(str), e3);
        }
    }

    public static a2.d[] n(a2.d[] dVarArr) {
        a2.d[] dVarArr2 = new a2.d[dVarArr.length];
        for (int i10 = 0; i10 < dVarArr.length; i10++) {
            dVarArr2[i10] = new a2.d(dVarArr[i10]);
        }
        return dVarArr2;
    }

    public static final xi.b o(Enum[] entries) {
        q.g(entries, "entries");
        return new xi.b(entries);
    }

    public static String p(byte[] bArr, boolean z5) {
        return y6.a.F(H(bArr), z5, 64);
    }

    public static int q(byte b10, byte b11, byte b12, byte b13) {
        return (b10 << 24) | ((b11 & 255) << 16) | ((b12 & 255) << 8) | (b13 & 255);
    }

    public static float r(EdgeEffect edgeEffect) {
        if (Build.VERSION.SDK_INT >= 31) {
            return androidx.core.widget.c.b(edgeEffect);
        }
        return 0.0f;
    }

    public static l1.k s(l1.i iVar) {
        h hVar = new h();
        hVar.f14067c = new m();
        l1.k kVar = new l1.k(hVar);
        hVar.f14066b = kVar;
        hVar.f14065a = iVar.getClass();
        try {
            Object objI = iVar.i(hVar);
            if (objI == null) {
                return kVar;
            }
            hVar.f14065a = objI;
            return kVar;
        } catch (Exception e3) {
            kVar.X.k(e3);
            return kVar;
        }
    }

    public static AppDatabase t() {
        return (AppDatabase) AppDatabase.f19302l.getValue();
    }

    public static int w(int[] iArr, int i10, int i11, int i12) {
        while (i11 < i12) {
            if (iArr[i11] == i10) {
                return i11;
            }
            i11++;
        }
        return -1;
    }

    public static boolean x(Uri uri) {
        return uri != null && "content".equals(uri.getScheme()) && "media".equals(uri.getAuthority());
    }

    public static boolean y(int i10) {
        return i10 == 6 || i10 == 1 || i10 == 2 || i10 == 4;
    }

    public static boolean z() {
        String MANUFACTURER = Build.MANUFACTURER;
        q.f(MANUFACTURER, "MANUFACTURER");
        if (!MANUFACTURER.equalsIgnoreCase("Samsung")) {
            String BRAND = Build.BRAND;
            q.f(BRAND, "BRAND");
            if (!BRAND.equalsIgnoreCase("Samsung")) {
                return false;
            }
        }
        LinkedHashMap linkedHashMap = ExtraCroppingQuirk.f1515a;
        String MODEL = Build.MODEL;
        q.f(MODEL, "MODEL");
        Locale locale = Locale.ROOT;
        String upperCase = MODEL.toUpperCase(locale);
        q.f(upperCase, "toUpperCase(...)");
        if (!linkedHashMap.containsKey(upperCase)) {
            return false;
        }
        String upperCase2 = MODEL.toUpperCase(locale);
        q.f(upperCase2, "toUpperCase(...)");
        Range range = (Range) linkedHashMap.get(upperCase2);
        if (range != null) {
            return range.contains(Integer.valueOf(Build.VERSION.SDK_INT));
        }
        return true;
    }

    public abstract Object B(Intent intent, int i10);

    public abstract void b(o6.c cVar, Object obj);

    public abstract Intent h(j jVar, Object obj);

    public abstract String k();

    public p0 l(w4.a aVar) {
        ByteBuffer byteBuffer = aVar.f17865r0;
        byteBuffer.getClass();
        k.n(byteBuffer.position() == 0 && byteBuffer.hasArray() && byteBuffer.arrayOffset() == 0);
        return m(aVar, byteBuffer);
    }

    public abstract p0 m(w4.a aVar, ByteBuffer byteBuffer);

    public w4 u(j jVar, Object obj) {
        return null;
    }

    public void v(o6.a connection, Object obj) throws Exception {
        q.g(connection, "connection");
        o6.c cVarP0 = connection.p0(k());
        try {
            b(cVarP0, obj);
            cVarP0.m0();
            k.B(cVarP0, null);
            o6.c cVarP1 = connection.p0("SELECT changes()");
            try {
                cVarP1.m0();
                cVarP1.getLong(0);
                k.B(cVarP1, null);
            } catch (Throwable th2) {
                try {
                    throw th2;
                } catch (Throwable th3) {
                    k.B(cVarP1, th2);
                    throw th3;
                }
            }
        } catch (Throwable th4) {
            try {
                throw th4;
            } catch (Throwable th5) {
                k.B(cVarP0, th4);
                throw th5;
            }
        }
    }
}
