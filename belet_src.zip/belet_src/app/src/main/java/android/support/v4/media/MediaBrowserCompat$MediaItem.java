package android.support.v4.media;

import android.annotation.SuppressLint;
import android.os.Parcel;
import android.os.Parcelable;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
@SuppressLint({"BanParcelableUsage"})
public class MediaBrowserCompat$MediaItem implements Parcelable {
    public static final Parcelable.Creator<MediaBrowserCompat$MediaItem> CREATOR = new aa.b(7);
    public final MediaDescriptionCompat X;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int f974e;

    public MediaBrowserCompat$MediaItem(Parcel parcel) {
        this.f974e = parcel.readInt();
        this.X = MediaDescriptionCompat.CREATOR.createFromParcel(parcel);
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    public final String toString() {
        return "MediaItem{mFlags=" + this.f974e + ", mDescription=" + this.X + kotlinx.serialization.json.internal.b.END_OBJ;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i10) {
        parcel.writeInt(this.f974e);
        this.X.writeToParcel(parcel, i10);
    }
}
