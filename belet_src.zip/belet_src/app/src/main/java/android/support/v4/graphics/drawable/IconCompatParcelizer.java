package android.support.v4.graphics.drawable;

import androidx.core.graphics.drawable.IconCompat;
import y6.b;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class IconCompatParcelizer extends androidx.core.graphics.drawable.IconCompatParcelizer {
    public static IconCompat read(b bVar) {
        return androidx.core.graphics.drawable.IconCompatParcelizer.read(bVar);
    }

    public static void write(IconCompat iconCompat, b bVar) {
        androidx.core.graphics.drawable.IconCompatParcelizer.write(iconCompat, bVar);
    }
}
