package android.support.v4.media.session;

import a0.f;
import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import java.util.ArrayList;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
@SuppressLint({"BanParcelableUsage"})
public final class PlaybackStateCompat implements Parcelable {
    public static final Parcelable.Creator<PlaybackStateCompat> CREATOR = new a(4);
    public final long X;
    public final long Y;
    public final float Z;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int f987e;

    /* JADX INFO: renamed from: r0, reason: collision with root package name */
    public final long f988r0;

    /* JADX INFO: renamed from: s0, reason: collision with root package name */
    public final int f989s0;

    /* JADX INFO: renamed from: t0, reason: collision with root package name */
    public final CharSequence f990t0;
    public final long u0;

    /* JADX INFO: renamed from: v0, reason: collision with root package name */
    public final ArrayList f991v0;

    /* JADX INFO: renamed from: w0, reason: collision with root package name */
    public final long f992w0;

    /* JADX INFO: renamed from: x0, reason: collision with root package name */
    public final Bundle f993x0;

    /* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
    public static final class CustomAction implements Parcelable {
        public static final Parcelable.Creator<CustomAction> CREATOR = new c();
        public final CharSequence X;
        public final int Y;
        public final Bundle Z;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        public final String f994e;

        public CustomAction(Parcel parcel) {
            this.f994e = parcel.readString();
            this.X = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
            this.Y = parcel.readInt();
            this.Z = parcel.readBundle(b.class.getClassLoader());
        }

        @Override // android.os.Parcelable
        public final int describeContents() {
            return 0;
        }

        public final String toString() {
            return "Action:mName='" + ((Object) this.X) + ", mIcon=" + this.Y + ", mExtras=" + this.Z;
        }

        @Override // android.os.Parcelable
        public final void writeToParcel(Parcel parcel, int i10) {
            parcel.writeString(this.f994e);
            TextUtils.writeToParcel(this.X, parcel, i10);
            parcel.writeInt(this.Y);
            parcel.writeBundle(this.Z);
        }
    }

    public PlaybackStateCompat(Parcel parcel) {
        this.f987e = parcel.readInt();
        this.X = parcel.readLong();
        this.Z = parcel.readFloat();
        this.u0 = parcel.readLong();
        this.Y = parcel.readLong();
        this.f988r0 = parcel.readLong();
        this.f990t0 = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        this.f991v0 = parcel.createTypedArrayList(CustomAction.CREATOR);
        this.f992w0 = parcel.readLong();
        this.f993x0 = parcel.readBundle(b.class.getClassLoader());
        this.f989s0 = parcel.readInt();
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    public final String toString() {
        StringBuilder sb2 = new StringBuilder("PlaybackState {state=");
        sb2.append(this.f987e);
        sb2.append(", position=");
        sb2.append(this.X);
        sb2.append(", buffered position=");
        sb2.append(this.Y);
        sb2.append(", speed=");
        sb2.append(this.Z);
        sb2.append(", updated=");
        sb2.append(this.u0);
        sb2.append(", actions=");
        sb2.append(this.f988r0);
        sb2.append(", error code=");
        sb2.append(this.f989s0);
        sb2.append(", error message=");
        sb2.append(this.f990t0);
        sb2.append(", custom actions=");
        sb2.append(this.f991v0);
        sb2.append(", active item id=");
        return f.q(sb2, this.f992w0, "}");
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i10) {
        parcel.writeInt(this.f987e);
        parcel.writeLong(this.X);
        parcel.writeFloat(this.Z);
        parcel.writeLong(this.u0);
        parcel.writeLong(this.Y);
        parcel.writeLong(this.f988r0);
        TextUtils.writeToParcel(this.f990t0, parcel, i10);
        parcel.writeTypedList(this.f991v0);
        parcel.writeLong(this.f992w0);
        parcel.writeBundle(this.f993x0);
        parcel.writeInt(this.f989s0);
    }
}
