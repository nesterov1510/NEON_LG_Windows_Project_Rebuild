package android.support.v4.media;

import androidx.media.AudioAttributesImplApi26;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class AudioAttributesImplApi26Parcelizer extends androidx.media.AudioAttributesImplApi26Parcelizer {
    public static AudioAttributesImplApi26 read(y6.b bVar) {
        return androidx.media.AudioAttributesImplApi26Parcelizer.read(bVar);
    }

    public static void write(AudioAttributesImplApi26 audioAttributesImplApi26, y6.b bVar) {
        androidx.media.AudioAttributesImplApi26Parcelizer.write(audioAttributesImplApi26, bVar);
    }
}
