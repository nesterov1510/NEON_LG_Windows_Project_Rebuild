package android.support.v4.media;

import android.os.Bundle;
import android.support.v4.os.ResultReceiver;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
class MediaBrowserCompat$CustomActionResultReceiver extends ResultReceiver {
    @Override // android.support.v4.os.ResultReceiver
    public final void b(int i10, Bundle bundle) {
    }
}
