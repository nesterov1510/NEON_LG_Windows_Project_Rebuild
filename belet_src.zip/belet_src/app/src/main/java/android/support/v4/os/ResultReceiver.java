package android.support.v4.os;

import aa.b;
import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import b.c;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
@SuppressLint({"BanParcelableUsage"})
public class ResultReceiver implements Parcelable {
    public static final Parcelable.Creator<ResultReceiver> CREATOR = new b(11);

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public b.b f996e;

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i10) {
        synchronized (this) {
            try {
                if (this.f996e == null) {
                    this.f996e = new c(this);
                }
                parcel.writeStrongBinder(this.f996e.asBinder());
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    public void b(int i10, Bundle bundle) {
    }
}
