package ac;

import android.graphics.Typeface;
import g6.y;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class b extends y {
    public final Typeface X;
    public final a Y;
    public boolean Z;

    public b(a aVar, Typeface typeface) {
        this.X = typeface;
        this.Y = aVar;
    }

    @Override // g6.y
    public final void A(Typeface typeface, boolean z5) {
        if (this.Z) {
            return;
        }
        this.Y.n(typeface);
    }

    @Override // g6.y
    public final void z(int i10) {
        if (this.Z) {
            return;
        }
        this.Y.n(this.X);
    }
}
