package ac;

import a4.t;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.Typeface;
import android.os.Build;
import android.text.TextPaint;
import android.util.Log;
import android.util.TypedValue;
import android.util.Xml;
import g6.y;
import z1.k;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ColorStateList f702a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f703b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final String f704c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f705d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int f706e;
    public final float f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final float f707g;
    public final float h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final boolean f708i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final float f709j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final ColorStateList f710k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public float f711l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final int f712m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public boolean f713n = false;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public boolean f714o = false;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public Typeface f715p;

    public e(Context context, int i10) {
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(i10, g.a.f8290w);
        this.f711l = typedArrayObtainStyledAttributes.getDimension(0, 0.0f);
        this.f710k = g0.c.i(context, typedArrayObtainStyledAttributes, 3);
        g0.c.i(context, typedArrayObtainStyledAttributes, 4);
        g0.c.i(context, typedArrayObtainStyledAttributes, 5);
        this.f705d = typedArrayObtainStyledAttributes.getInt(2, 0);
        this.f706e = typedArrayObtainStyledAttributes.getInt(1, 1);
        int i11 = typedArrayObtainStyledAttributes.hasValue(12) ? 12 : 10;
        this.f712m = typedArrayObtainStyledAttributes.getResourceId(i11, 0);
        this.f703b = typedArrayObtainStyledAttributes.getString(i11);
        typedArrayObtainStyledAttributes.getBoolean(14, false);
        this.f702a = g0.c.i(context, typedArrayObtainStyledAttributes, 6);
        this.f = typedArrayObtainStyledAttributes.getFloat(7, 0.0f);
        this.f707g = typedArrayObtainStyledAttributes.getFloat(8, 0.0f);
        this.h = typedArrayObtainStyledAttributes.getFloat(9, 0.0f);
        typedArrayObtainStyledAttributes.recycle();
        TypedArray typedArrayObtainStyledAttributes2 = context.obtainStyledAttributes(i10, hb.a.E);
        this.f708i = typedArrayObtainStyledAttributes2.hasValue(0);
        this.f709j = typedArrayObtainStyledAttributes2.getFloat(0, 0.0f);
        if (Build.VERSION.SDK_INT >= 26) {
            this.f704c = typedArrayObtainStyledAttributes2.getString(typedArrayObtainStyledAttributes2.hasValue(3) ? 3 : 1);
        }
        typedArrayObtainStyledAttributes2.recycle();
    }

    public final void a() {
        String str;
        Typeface typeface = this.f715p;
        int i10 = this.f705d;
        if (typeface == null && (str = this.f703b) != null) {
            this.f715p = Typeface.create(str, i10);
        }
        if (this.f715p == null) {
            int i11 = this.f706e;
            if (i11 == 1) {
                this.f715p = Typeface.SANS_SERIF;
            } else if (i11 == 2) {
                this.f715p = Typeface.SERIF;
            } else if (i11 != 3) {
                this.f715p = Typeface.DEFAULT;
            } else {
                this.f715p = Typeface.MONOSPACE;
            }
            this.f715p = Typeface.create(this.f715p, i10);
        }
    }

    public final void b(Context context, y yVar) {
        if (!c(context)) {
            a();
        }
        int i10 = this.f712m;
        if (i10 == 0) {
            this.f713n = true;
        }
        if (this.f713n) {
            yVar.A(this.f715p, true);
            return;
        }
        try {
            c cVar = new c(this, yVar);
            ThreadLocal threadLocal = k.f23450a;
            if (context.isRestricted()) {
                cVar.a(-4);
            } else {
                k.c(context, i10, new TypedValue(), 0, cVar, false, false);
            }
        } catch (Resources.NotFoundException unused) {
            this.f713n = true;
            yVar.z(1);
        } catch (Exception e3) {
            Log.d("TextAppearance", "Error loading font " + this.f703b, e3);
            this.f713n = true;
            yVar.z(-3);
        }
    }

    public final boolean c(Context context) throws Exception {
        Context context2;
        Typeface typefaceC;
        String string;
        Typeface typefaceCreate;
        if (this.f713n) {
            return true;
        }
        int i10 = this.f712m;
        if (i10 != 0) {
            ThreadLocal threadLocal = k.f23450a;
            Typeface typefaceCreate2 = null;
            if (context.isRestricted()) {
                context2 = context;
                typefaceC = null;
            } else {
                context2 = context;
                typefaceC = k.c(context2, i10, new TypedValue(), 0, null, false, true);
            }
            if (typefaceC != null) {
                this.f715p = typefaceC;
                this.f713n = true;
                return true;
            }
            if (!this.f714o) {
                this.f714o = true;
                Resources resources = context2.getResources();
                int i11 = this.f712m;
                if (i11 == 0 || !resources.getResourceTypeName(i11).equals("font")) {
                    string = null;
                    break;
                }
                try {
                    XmlResourceParser xml = resources.getXml(i11);
                    while (true) {
                        if (xml.getEventType() == 1) {
                            string = null;
                            break;
                        }
                        if (xml.getEventType() == 2 && xml.getName().equals("font-family")) {
                            TypedArray typedArrayObtainAttributes = resources.obtainAttributes(Xml.asAttributeSet(xml), u1.a.f20200b);
                            string = typedArrayObtainAttributes.getString(7);
                            typedArrayObtainAttributes.recycle();
                            break;
                        }
                        xml.next();
                        string = null;
                        break;
                    }
                } catch (Throwable unused) {
                }
                if (string != null && (typefaceCreate = Typeface.create(string, 0)) != Typeface.DEFAULT) {
                    typefaceCreate2 = Typeface.create(typefaceCreate, this.f705d);
                }
            }
            if (typefaceCreate2 != null) {
                this.f715p = typefaceCreate2;
                this.f713n = true;
                return true;
            }
        }
        return false;
    }

    public final void d(Context context, TextPaint textPaint, y yVar) {
        e(context, textPaint, yVar);
        ColorStateList colorStateList = this.f710k;
        textPaint.setColor(colorStateList != null ? colorStateList.getColorForState(textPaint.drawableState, colorStateList.getDefaultColor()) : -16777216);
        ColorStateList colorStateList2 = this.f702a;
        textPaint.setShadowLayer(this.h, this.f, this.f707g, colorStateList2 != null ? colorStateList2.getColorForState(textPaint.drawableState, colorStateList2.getDefaultColor()) : 0);
    }

    public final void e(Context context, TextPaint textPaint, y yVar) {
        Typeface typeface;
        if (c(context) && this.f713n && (typeface = this.f715p) != null) {
            f(context, textPaint, typeface);
            return;
        }
        a();
        f(context, textPaint, this.f715p);
        b(context, new d(this, context, textPaint, yVar));
    }

    public final void f(Context context, TextPaint textPaint, Typeface typeface) {
        Typeface typefaceJ = t.j(context.getResources().getConfiguration(), typeface);
        if (typefaceJ != null) {
            typeface = typefaceJ;
        }
        textPaint.setTypeface(typeface);
        int i10 = (~typeface.getStyle()) & this.f705d;
        textPaint.setFakeBoldText((i10 & 1) != 0);
        textPaint.setTextSkewX((i10 & 2) != 0 ? -0.25f : 0.0f);
        textPaint.setTextSize(this.f711l);
        if (Build.VERSION.SDK_INT >= 26) {
            textPaint.setFontVariationSettings(this.f704c);
        }
        if (this.f708i) {
            textPaint.setLetterSpacing(this.f709j);
        }
    }
}
