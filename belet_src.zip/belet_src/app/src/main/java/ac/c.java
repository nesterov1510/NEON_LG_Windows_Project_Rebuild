package ac;

import android.graphics.Typeface;
import g6.y;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class c extends z1.b {
    public final /* synthetic */ y h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final /* synthetic */ e f700i;

    public c(e eVar, y yVar) {
        this.f700i = eVar;
        this.h = yVar;
    }

    @Override // z1.b
    public final void h(int i10) {
        this.f700i.f713n = true;
        this.h.z(i10);
    }

    @Override // z1.b
    public final void i(Typeface typeface) {
        e eVar = this.f700i;
        eVar.f715p = Typeface.create(typeface, eVar.f705d);
        eVar.f713n = true;
        this.h.A(eVar.f715p, false);
    }
}
