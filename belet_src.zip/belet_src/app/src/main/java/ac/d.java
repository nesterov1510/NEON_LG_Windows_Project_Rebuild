package ac;

import android.content.Context;
import android.graphics.Typeface;
import android.text.TextPaint;
import g6.y;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class d extends y {
    public final /* synthetic */ Context X;
    public final /* synthetic */ TextPaint Y;
    public final /* synthetic */ y Z;

    /* JADX INFO: renamed from: r0, reason: collision with root package name */
    public final /* synthetic */ e f701r0;

    public d(e eVar, Context context, TextPaint textPaint, y yVar) {
        this.f701r0 = eVar;
        this.X = context;
        this.Y = textPaint;
        this.Z = yVar;
    }

    @Override // g6.y
    public final void A(Typeface typeface, boolean z5) {
        this.f701r0.f(this.X, this.Y, typeface);
        this.Z.A(typeface, z5);
    }

    @Override // g6.y
    public final void z(int i10) {
        this.Z.z(i10);
    }
}
