package am;

import com.google.protobuf.m0;
import java.util.List;
import kotlin.jvm.internal.p;
import kotlin.jvm.internal.q;
import kotlinx.serialization.j;
import ri.s;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
@j
public final class c {
    public static final b Companion = new b();

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static final qi.f[] f888g = {null, null, null, null, g0.c.v(qi.g.f17354e, new al.j(3)), null};

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f889a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f890b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final String f891c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final String f892d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final List f893e;
    public final Boolean f;

    public /* synthetic */ c(int i10, String str, String str2, String str3, String str4, List list, Boolean bool) {
        if ((i10 & 1) == 0) {
            this.f889a = null;
        } else {
            this.f889a = str;
        }
        if ((i10 & 2) == 0) {
            this.f890b = null;
        } else {
            this.f890b = str2;
        }
        if ((i10 & 4) == 0) {
            this.f891c = null;
        } else {
            this.f891c = str3;
        }
        if ((i10 & 8) == 0) {
            this.f892d = null;
        } else {
            this.f892d = str4;
        }
        if ((i10 & 16) == 0) {
            this.f893e = s.f18050e;
        } else {
            this.f893e = list;
        }
        if ((i10 & 32) == 0) {
            this.f = null;
        } else {
            this.f = bool;
        }
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof c)) {
            return false;
        }
        c cVar = (c) obj;
        return q.c(this.f889a, cVar.f889a) && q.c(this.f890b, cVar.f890b) && q.c(this.f891c, cVar.f891c) && q.c(this.f892d, cVar.f892d) && q.c(this.f893e, cVar.f893e) && q.c(this.f, cVar.f);
    }

    public final int hashCode() {
        String str = this.f889a;
        int iHashCode = (str == null ? 0 : str.hashCode()) * 31;
        String str2 = this.f890b;
        int iHashCode2 = (iHashCode + (str2 == null ? 0 : str2.hashCode())) * 31;
        String str3 = this.f891c;
        int iHashCode3 = (iHashCode2 + (str3 == null ? 0 : str3.hashCode())) * 31;
        String str4 = this.f892d;
        int iHashCode4 = (iHashCode3 + (str4 == null ? 0 : str4.hashCode())) * 31;
        List list = this.f893e;
        int iHashCode5 = (iHashCode4 + (list == null ? 0 : list.hashCode())) * 31;
        Boolean bool = this.f;
        return iHashCode5 + (bool != null ? bool.hashCode() : 0);
    }

    public final String toString() {
        StringBuilder sbN = m0.n("SubscriptionDTO(code=", this.f889a, ", name=", this.f890b, ", description=");
        p.O(sbN, this.f891c, ", price_in_manats=", this.f892d, ", features=");
        sbN.append(this.f893e);
        sbN.append(", is_current=");
        sbN.append(this.f);
        sbN.append(")");
        return sbN.toString();
    }
}
