package am;

import java.util.List;
import kotlin.jvm.internal.q;
import kotlinx.serialization.encoding.j;
import kotlinx.serialization.encoding.l;
import kotlinx.serialization.internal.e2;
import kotlinx.serialization.internal.l0;
import kotlinx.serialization.internal.n0;
import kotlinx.serialization.t;
import ql.p;
import ql.r;
import ri.s;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class d implements n0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final d f894a;
    private static final kotlinx.serialization.descriptors.g descriptor;

    static {
        d dVar = new d();
        f894a = dVar;
        e2 e2Var = new e2("tm.belet.films.data.response.subscriptions.SubscriptionsV2DTO", dVar, 4);
        e2Var.addElement("subscriptions", true);
        e2Var.addElement("has_active_subscription", true);
        e2Var.addElement("suspension_status", true);
        e2Var.addElement("next_step_button", true);
        descriptor = e2Var;
    }

    @Override // kotlinx.serialization.internal.n0
    public final kotlinx.serialization.b[] childSerializers() {
        return new kotlinx.serialization.b[]{wj.a.getNullable((kotlinx.serialization.b) f.f895e[0].getValue()), wj.a.getNullable(kotlinx.serialization.internal.i.INSTANCE), wj.a.getNullable(g.f900a), wj.a.getNullable(p.f17499a)};
    }

    @Override // kotlinx.serialization.internal.n0, kotlinx.serialization.b, kotlinx.serialization.a
    public final Object deserialize(j decoder) {
        int i10;
        List list;
        Boolean bool;
        i iVar;
        r rVar;
        q.g(decoder, "decoder");
        kotlinx.serialization.descriptors.g gVar = descriptor;
        kotlinx.serialization.encoding.f fVarBeginStructure = decoder.beginStructure(gVar);
        qi.f[] fVarArr = f.f895e;
        List list2 = null;
        if (fVarBeginStructure.decodeSequentially()) {
            List list3 = (List) fVarBeginStructure.decodeNullableSerializableElement(gVar, 0, (kotlinx.serialization.a) fVarArr[0].getValue(), null);
            Boolean bool2 = (Boolean) fVarBeginStructure.decodeNullableSerializableElement(gVar, 1, kotlinx.serialization.internal.i.INSTANCE, null);
            i iVar2 = (i) fVarBeginStructure.decodeNullableSerializableElement(gVar, 2, g.f900a, null);
            list = list3;
            bool = bool2;
            rVar = (r) fVarBeginStructure.decodeNullableSerializableElement(gVar, 3, p.f17499a, null);
            iVar = iVar2;
            i10 = 15;
        } else {
            boolean z5 = true;
            int i11 = 0;
            Boolean bool3 = null;
            i iVar3 = null;
            r rVar2 = null;
            while (z5) {
                int iDecodeElementIndex = fVarBeginStructure.decodeElementIndex(gVar);
                if (iDecodeElementIndex == -1) {
                    z5 = false;
                } else if (iDecodeElementIndex == 0) {
                    list2 = (List) fVarBeginStructure.decodeNullableSerializableElement(gVar, 0, (kotlinx.serialization.a) fVarArr[0].getValue(), list2);
                    i11 |= 1;
                } else if (iDecodeElementIndex == 1) {
                    bool3 = (Boolean) fVarBeginStructure.decodeNullableSerializableElement(gVar, 1, kotlinx.serialization.internal.i.INSTANCE, bool3);
                    i11 |= 2;
                } else if (iDecodeElementIndex == 2) {
                    iVar3 = (i) fVarBeginStructure.decodeNullableSerializableElement(gVar, 2, g.f900a, iVar3);
                    i11 |= 4;
                } else {
                    if (iDecodeElementIndex != 3) {
                        throw new t(iDecodeElementIndex);
                    }
                    rVar2 = (r) fVarBeginStructure.decodeNullableSerializableElement(gVar, 3, p.f17499a, rVar2);
                    i11 |= 8;
                }
            }
            i10 = i11;
            list = list2;
            bool = bool3;
            iVar = iVar3;
            rVar = rVar2;
        }
        fVarBeginStructure.endStructure(gVar);
        return new f(i10, list, bool, iVar, rVar);
    }

    @Override // kotlinx.serialization.internal.n0, kotlinx.serialization.b, kotlinx.serialization.l, kotlinx.serialization.a
    public final kotlinx.serialization.descriptors.g getDescriptor() {
        return descriptor;
    }

    @Override // kotlinx.serialization.internal.n0, kotlinx.serialization.b, kotlinx.serialization.l
    public final void serialize(l encoder, Object obj) {
        f value = (f) obj;
        q.g(encoder, "encoder");
        q.g(value, "value");
        r rVar = value.f899d;
        i iVar = value.f898c;
        Boolean bool = value.f897b;
        List list = value.f896a;
        kotlinx.serialization.descriptors.g gVar = descriptor;
        kotlinx.serialization.encoding.h hVarBeginStructure = encoder.beginStructure(gVar);
        qi.f[] fVarArr = f.f895e;
        if (hVarBeginStructure.shouldEncodeElementDefault(gVar, 0) || !q.c(list, s.f18050e)) {
            hVarBeginStructure.encodeNullableSerializableElement(gVar, 0, (kotlinx.serialization.l) fVarArr[0].getValue(), list);
        }
        if (hVarBeginStructure.shouldEncodeElementDefault(gVar, 1) || bool != null) {
            hVarBeginStructure.encodeNullableSerializableElement(gVar, 1, kotlinx.serialization.internal.i.INSTANCE, bool);
        }
        if (hVarBeginStructure.shouldEncodeElementDefault(gVar, 2) || iVar != null) {
            hVarBeginStructure.encodeNullableSerializableElement(gVar, 2, g.f900a, iVar);
        }
        if (hVarBeginStructure.shouldEncodeElementDefault(gVar, 3) || rVar != null) {
            hVarBeginStructure.encodeNullableSerializableElement(gVar, 3, p.f17499a, rVar);
        }
        hVarBeginStructure.endStructure(gVar);
    }

    @Override // kotlinx.serialization.internal.n0
    public final /* bridge */ kotlinx.serialization.b[] typeParametersSerializers() {
        return l0.a(this);
    }
}
