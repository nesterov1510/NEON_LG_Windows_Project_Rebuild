package am;

import kotlin.jvm.internal.q;
import kotlinx.serialization.encoding.j;
import kotlinx.serialization.encoding.l;
import kotlinx.serialization.internal.e2;
import kotlinx.serialization.internal.l0;
import kotlinx.serialization.internal.n0;
import kotlinx.serialization.internal.u2;
import kotlinx.serialization.t;
import ql.p;
import ql.r;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class g implements n0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final g f900a;
    private static final kotlinx.serialization.descriptors.g descriptor;

    static {
        g gVar = new g();
        f900a = gVar;
        e2 e2Var = new e2("tm.belet.films.data.response.subscriptions.SuspensionStatusDTO", gVar, 3);
        e2Var.addElement("title", true);
        e2Var.addElement("description", true);
        e2Var.addElement("button", true);
        descriptor = e2Var;
    }

    @Override // kotlinx.serialization.internal.n0
    public final kotlinx.serialization.b[] childSerializers() {
        u2 u2Var = u2.INSTANCE;
        return new kotlinx.serialization.b[]{wj.a.getNullable(u2Var), wj.a.getNullable(u2Var), wj.a.getNullable(p.f17499a)};
    }

    @Override // kotlinx.serialization.internal.n0, kotlinx.serialization.b, kotlinx.serialization.a
    public final Object deserialize(j decoder) {
        int i10;
        String str;
        String str2;
        r rVar;
        q.g(decoder, "decoder");
        kotlinx.serialization.descriptors.g gVar = descriptor;
        kotlinx.serialization.encoding.f fVarBeginStructure = decoder.beginStructure(gVar);
        String str3 = null;
        if (fVarBeginStructure.decodeSequentially()) {
            u2 u2Var = u2.INSTANCE;
            str = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 0, u2Var, null);
            str2 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 1, u2Var, null);
            rVar = (r) fVarBeginStructure.decodeNullableSerializableElement(gVar, 2, p.f17499a, null);
            i10 = 7;
        } else {
            boolean z5 = true;
            int i11 = 0;
            String str4 = null;
            r rVar2 = null;
            while (z5) {
                int iDecodeElementIndex = fVarBeginStructure.decodeElementIndex(gVar);
                if (iDecodeElementIndex == -1) {
                    z5 = false;
                } else if (iDecodeElementIndex == 0) {
                    str3 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 0, u2.INSTANCE, str3);
                    i11 |= 1;
                } else if (iDecodeElementIndex == 1) {
                    str4 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 1, u2.INSTANCE, str4);
                    i11 |= 2;
                } else {
                    if (iDecodeElementIndex != 2) {
                        throw new t(iDecodeElementIndex);
                    }
                    rVar2 = (r) fVarBeginStructure.decodeNullableSerializableElement(gVar, 2, p.f17499a, rVar2);
                    i11 |= 4;
                }
            }
            i10 = i11;
            str = str3;
            str2 = str4;
            rVar = rVar2;
        }
        fVarBeginStructure.endStructure(gVar);
        return new i(i10, str, str2, rVar);
    }

    @Override // kotlinx.serialization.internal.n0, kotlinx.serialization.b, kotlinx.serialization.l, kotlinx.serialization.a
    public final kotlinx.serialization.descriptors.g getDescriptor() {
        return descriptor;
    }

    @Override // kotlinx.serialization.internal.n0, kotlinx.serialization.b, kotlinx.serialization.l
    public final void serialize(l encoder, Object obj) {
        i value = (i) obj;
        q.g(encoder, "encoder");
        q.g(value, "value");
        r rVar = value.f903c;
        String str = value.f902b;
        String str2 = value.f901a;
        kotlinx.serialization.descriptors.g gVar = descriptor;
        kotlinx.serialization.encoding.h hVarBeginStructure = encoder.beginStructure(gVar);
        if (hVarBeginStructure.shouldEncodeElementDefault(gVar, 0) || str2 != null) {
            hVarBeginStructure.encodeNullableSerializableElement(gVar, 0, u2.INSTANCE, str2);
        }
        if (hVarBeginStructure.shouldEncodeElementDefault(gVar, 1) || str != null) {
            hVarBeginStructure.encodeNullableSerializableElement(gVar, 1, u2.INSTANCE, str);
        }
        if (hVarBeginStructure.shouldEncodeElementDefault(gVar, 2) || rVar != null) {
            hVarBeginStructure.encodeNullableSerializableElement(gVar, 2, p.f17499a, rVar);
        }
        hVarBeginStructure.endStructure(gVar);
    }

    @Override // kotlinx.serialization.internal.n0
    public final /* bridge */ kotlinx.serialization.b[] typeParametersSerializers() {
        return l0.a(this);
    }
}
