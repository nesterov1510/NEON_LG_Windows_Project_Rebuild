package am;

import java.util.List;
import kotlin.jvm.internal.q;
import kotlinx.serialization.encoding.j;
import kotlinx.serialization.encoding.l;
import kotlinx.serialization.internal.e2;
import kotlinx.serialization.internal.l0;
import kotlinx.serialization.internal.n0;
import kotlinx.serialization.internal.u2;
import kotlinx.serialization.t;
import ri.s;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class a implements n0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final a f887a;
    private static final kotlinx.serialization.descriptors.g descriptor;

    static {
        a aVar = new a();
        f887a = aVar;
        e2 e2Var = new e2("tm.belet.films.data.response.subscriptions.SubscriptionDTO", aVar, 6);
        e2Var.addElement("code", true);
        e2Var.addElement("name", true);
        e2Var.addElement("description", true);
        e2Var.addElement("price_in_manats", true);
        e2Var.addElement("features", true);
        e2Var.addElement("is_current", true);
        descriptor = e2Var;
    }

    @Override // kotlinx.serialization.internal.n0
    public final kotlinx.serialization.b[] childSerializers() {
        qi.f[] fVarArr = c.f888g;
        u2 u2Var = u2.INSTANCE;
        return new kotlinx.serialization.b[]{wj.a.getNullable(u2Var), wj.a.getNullable(u2Var), wj.a.getNullable(u2Var), wj.a.getNullable(u2Var), wj.a.getNullable((kotlinx.serialization.b) fVarArr[4].getValue()), wj.a.getNullable(kotlinx.serialization.internal.i.INSTANCE)};
    }

    @Override // kotlinx.serialization.internal.n0, kotlinx.serialization.b, kotlinx.serialization.a
    public final Object deserialize(j decoder) {
        int i10;
        String str;
        String str2;
        String str3;
        String str4;
        List list;
        Boolean bool;
        q.g(decoder, "decoder");
        kotlinx.serialization.descriptors.g gVar = descriptor;
        kotlinx.serialization.encoding.f fVarBeginStructure = decoder.beginStructure(gVar);
        qi.f[] fVarArr = c.f888g;
        int i11 = 5;
        String str5 = null;
        if (fVarBeginStructure.decodeSequentially()) {
            u2 u2Var = u2.INSTANCE;
            String str6 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 0, u2Var, null);
            String str7 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 1, u2Var, null);
            String str8 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 2, u2Var, null);
            String str9 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 3, u2Var, null);
            list = (List) fVarBeginStructure.decodeNullableSerializableElement(gVar, 4, (kotlinx.serialization.a) fVarArr[4].getValue(), null);
            str4 = str9;
            bool = (Boolean) fVarBeginStructure.decodeNullableSerializableElement(gVar, 5, kotlinx.serialization.internal.i.INSTANCE, null);
            i10 = 63;
            str3 = str8;
            str2 = str7;
            str = str6;
        } else {
            boolean z5 = true;
            int i12 = 0;
            String str10 = null;
            String str11 = null;
            String str12 = null;
            List list2 = null;
            Boolean bool2 = null;
            while (z5) {
                int iDecodeElementIndex = fVarBeginStructure.decodeElementIndex(gVar);
                switch (iDecodeElementIndex) {
                    case -1:
                        z5 = false;
                        i11 = 5;
                        break;
                    case 0:
                        str5 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 0, u2.INSTANCE, str5);
                        i12 |= 1;
                        i11 = 5;
                        break;
                    case 1:
                        str10 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 1, u2.INSTANCE, str10);
                        i12 |= 2;
                        break;
                    case 2:
                        str11 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 2, u2.INSTANCE, str11);
                        i12 |= 4;
                        break;
                    case 3:
                        str12 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 3, u2.INSTANCE, str12);
                        i12 |= 8;
                        break;
                    case 4:
                        list2 = (List) fVarBeginStructure.decodeNullableSerializableElement(gVar, 4, (kotlinx.serialization.a) fVarArr[4].getValue(), list2);
                        i12 |= 16;
                        break;
                    case 5:
                        bool2 = (Boolean) fVarBeginStructure.decodeNullableSerializableElement(gVar, i11, kotlinx.serialization.internal.i.INSTANCE, bool2);
                        i12 |= 32;
                        break;
                    default:
                        throw new t(iDecodeElementIndex);
                }
            }
            i10 = i12;
            str = str5;
            str2 = str10;
            str3 = str11;
            str4 = str12;
            list = list2;
            bool = bool2;
        }
        fVarBeginStructure.endStructure(gVar);
        return new c(i10, str, str2, str3, str4, list, bool);
    }

    @Override // kotlinx.serialization.internal.n0, kotlinx.serialization.b, kotlinx.serialization.l, kotlinx.serialization.a
    public final kotlinx.serialization.descriptors.g getDescriptor() {
        return descriptor;
    }

    @Override // kotlinx.serialization.internal.n0, kotlinx.serialization.b, kotlinx.serialization.l
    public final void serialize(l encoder, Object obj) {
        c value = (c) obj;
        q.g(encoder, "encoder");
        q.g(value, "value");
        Boolean bool = value.f;
        List list = value.f893e;
        String str = value.f892d;
        String str2 = value.f891c;
        String str3 = value.f890b;
        String str4 = value.f889a;
        kotlinx.serialization.descriptors.g gVar = descriptor;
        kotlinx.serialization.encoding.h hVarBeginStructure = encoder.beginStructure(gVar);
        qi.f[] fVarArr = c.f888g;
        if (hVarBeginStructure.shouldEncodeElementDefault(gVar, 0) || str4 != null) {
            hVarBeginStructure.encodeNullableSerializableElement(gVar, 0, u2.INSTANCE, str4);
        }
        if (hVarBeginStructure.shouldEncodeElementDefault(gVar, 1) || str3 != null) {
            hVarBeginStructure.encodeNullableSerializableElement(gVar, 1, u2.INSTANCE, str3);
        }
        if (hVarBeginStructure.shouldEncodeElementDefault(gVar, 2) || str2 != null) {
            hVarBeginStructure.encodeNullableSerializableElement(gVar, 2, u2.INSTANCE, str2);
        }
        if (hVarBeginStructure.shouldEncodeElementDefault(gVar, 3) || str != null) {
            hVarBeginStructure.encodeNullableSerializableElement(gVar, 3, u2.INSTANCE, str);
        }
        if (hVarBeginStructure.shouldEncodeElementDefault(gVar, 4) || !q.c(list, s.f18050e)) {
            hVarBeginStructure.encodeNullableSerializableElement(gVar, 4, (kotlinx.serialization.l) fVarArr[4].getValue(), list);
        }
        if (hVarBeginStructure.shouldEncodeElementDefault(gVar, 5) || bool != null) {
            hVarBeginStructure.encodeNullableSerializableElement(gVar, 5, kotlinx.serialization.internal.i.INSTANCE, bool);
        }
        hVarBeginStructure.endStructure(gVar);
    }

    @Override // kotlinx.serialization.internal.n0
    public final /* bridge */ kotlinx.serialization.b[] typeParametersSerializers() {
        return l0.a(this);
    }
}
