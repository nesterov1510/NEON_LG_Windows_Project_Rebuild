package am;

import java.util.ArrayList;
import java.util.List;
import kotlin.jvm.internal.q;
import kotlinx.serialization.j;
import okhttp3.internal.url._UrlKt;
import ql.r;
import ql.y;
import ri.o;
import ri.s;
import tm.belet.films.domain.models.profile.SuspensionStatusModel;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
@j
public final class f {
    public static final e Companion = new e();

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final qi.f[] f895e = {g0.c.v(qi.g.f17354e, new al.j(4)), null, null, null};

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final List f896a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Boolean f897b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final i f898c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final r f899d;

    public /* synthetic */ f(int i10, List list, Boolean bool, i iVar, r rVar) {
        this.f896a = (i10 & 1) == 0 ? s.f18050e : list;
        if ((i10 & 2) == 0) {
            this.f897b = null;
        } else {
            this.f897b = bool;
        }
        if ((i10 & 4) == 0) {
            this.f898c = null;
        } else {
            this.f898c = iVar;
        }
        if ((i10 & 8) == 0) {
            this.f899d = null;
        } else {
            this.f899d = rVar;
        }
    }

    public final in.b a() {
        SuspensionStatusModel suspensionStatusModel;
        in.a aVar;
        List list;
        an.f fVar;
        List list2 = s.f18050e;
        String str = _UrlKt.FRAGMENT_ENCODE_SET;
        List<c> list3 = this.f896a;
        if (list3 != null) {
            ArrayList arrayList = new ArrayList(o.S(list3, 10));
            for (c cVar : list3) {
                if (cVar != null) {
                    String str2 = cVar.f889a;
                    String str3 = str2 == null ? _UrlKt.FRAGMENT_ENCODE_SET : str2;
                    String str4 = cVar.f890b;
                    String str5 = str4 == null ? _UrlKt.FRAGMENT_ENCODE_SET : str4;
                    String str6 = cVar.f891c;
                    String str7 = str6 == null ? _UrlKt.FRAGMENT_ENCODE_SET : str6;
                    String str8 = cVar.f892d;
                    String str9 = str8 == null ? _UrlKt.FRAGMENT_ENCODE_SET : str8;
                    List<y> list4 = cVar.f893e;
                    if (list4 != null) {
                        ArrayList arrayList2 = new ArrayList(o.S(list4, 10));
                        for (y yVar : list4) {
                            if (yVar != null) {
                                String str10 = yVar.f17537a;
                                if (str10 == null) {
                                    str10 = _UrlKt.FRAGMENT_ENCODE_SET;
                                }
                                String str11 = yVar.f17538b;
                                if (str11 == null) {
                                    str11 = _UrlKt.FRAGMENT_ENCODE_SET;
                                }
                                fVar = new an.f(str10, str11);
                            } else {
                                fVar = null;
                            }
                            arrayList2.add(fVar);
                        }
                        list = arrayList2;
                    } else {
                        list = list2;
                    }
                    Boolean bool = cVar.f;
                    aVar = new in.a(str3, str5, str7, str9, list, bool != null ? bool.booleanValue() : false);
                } else {
                    aVar = null;
                }
                arrayList.add(aVar);
            }
            list2 = arrayList;
        }
        Boolean bool2 = this.f897b;
        boolean zBooleanValue = bool2 != null ? bool2.booleanValue() : false;
        i iVar = this.f898c;
        if (iVar != null) {
            String str12 = iVar.f901a;
            if (str12 == null) {
                str12 = _UrlKt.FRAGMENT_ENCODE_SET;
            }
            String str13 = iVar.f902b;
            if (str13 != null) {
                str = str13;
            }
            r rVar = iVar.f903c;
            suspensionStatusModel = new SuspensionStatusModel(str12, str, rVar != null ? rVar.a() : null);
        } else {
            suspensionStatusModel = null;
        }
        r rVar2 = this.f899d;
        return new in.b(list2, zBooleanValue, suspensionStatusModel, rVar2 != null ? rVar2.a() : null);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof f)) {
            return false;
        }
        f fVar = (f) obj;
        return q.c(this.f896a, fVar.f896a) && q.c(this.f897b, fVar.f897b) && q.c(this.f898c, fVar.f898c) && q.c(this.f899d, fVar.f899d);
    }

    public final int hashCode() {
        List list = this.f896a;
        int iHashCode = (list == null ? 0 : list.hashCode()) * 31;
        Boolean bool = this.f897b;
        int iHashCode2 = (iHashCode + (bool == null ? 0 : bool.hashCode())) * 31;
        i iVar = this.f898c;
        int iHashCode3 = (iHashCode2 + (iVar == null ? 0 : iVar.hashCode())) * 31;
        r rVar = this.f899d;
        return iHashCode3 + (rVar != null ? rVar.hashCode() : 0);
    }

    public final String toString() {
        return "SubscriptionsV2DTO(subscriptions=" + this.f896a + ", has_active_subscription=" + this.f897b + ", suspension_status=" + this.f898c + ", next_step_button=" + this.f899d + ")";
    }
}
