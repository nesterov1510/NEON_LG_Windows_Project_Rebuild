package am;

import com.google.protobuf.m0;
import kotlin.jvm.internal.q;
import kotlinx.serialization.j;
import ql.r;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
@j
public final class i {
    public static final h Companion = new h();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f901a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f902b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final r f903c;

    public /* synthetic */ i(int i10, String str, String str2, r rVar) {
        if ((i10 & 1) == 0) {
            this.f901a = null;
        } else {
            this.f901a = str;
        }
        if ((i10 & 2) == 0) {
            this.f902b = null;
        } else {
            this.f902b = str2;
        }
        if ((i10 & 4) == 0) {
            this.f903c = null;
        } else {
            this.f903c = rVar;
        }
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof i)) {
            return false;
        }
        i iVar = (i) obj;
        return q.c(this.f901a, iVar.f901a) && q.c(this.f902b, iVar.f902b) && q.c(this.f903c, iVar.f903c);
    }

    public final int hashCode() {
        String str = this.f901a;
        int iHashCode = (str == null ? 0 : str.hashCode()) * 31;
        String str2 = this.f902b;
        int iHashCode2 = (iHashCode + (str2 == null ? 0 : str2.hashCode())) * 31;
        r rVar = this.f903c;
        return iHashCode2 + (rVar != null ? rVar.hashCode() : 0);
    }

    public final String toString() {
        StringBuilder sbN = m0.n("SuspensionStatusDTO(title=", this.f901a, ", description=", this.f902b, ", button=");
        sbN.append(this.f903c);
        sbN.append(")");
        return sbN.toString();
    }
}
