package a9;

import k8.u;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public interface f {
    void d(Object obj, Object obj2, b9.d dVar, int i10);

    void e(u uVar, b9.d dVar);
}
