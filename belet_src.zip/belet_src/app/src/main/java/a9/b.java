package a9;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class b implements d, c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Object f654a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final d f655b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public volatile c f656c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public volatile c f657d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f658e = 3;
    public int f = 3;

    public b(Object obj, d dVar) {
        this.f654a = obj;
        this.f655b = dVar;
    }

    @Override // a9.d
    public final boolean a(c cVar) {
        boolean z5;
        boolean zEquals;
        int i10;
        synchronized (this.f654a) {
            d dVar = this.f655b;
            z5 = false;
            if (dVar == null || dVar.a(this)) {
                if (this.f658e != 5) {
                    zEquals = cVar.equals(this.f656c);
                } else {
                    zEquals = cVar.equals(this.f657d) && ((i10 = this.f) == 4 || i10 == 5);
                }
                if (zEquals) {
                    z5 = true;
                }
            }
        }
        return z5;
    }

    @Override // a9.d
    public final boolean b(c cVar) {
        boolean z5;
        synchronized (this.f654a) {
            d dVar = this.f655b;
            z5 = (dVar == null || dVar.b(this)) && cVar.equals(this.f656c);
        }
        return z5;
    }

    @Override // a9.c
    public final void c() {
        synchronized (this.f654a) {
            try {
                if (this.f658e == 1) {
                    this.f658e = 2;
                    this.f656c.c();
                }
                if (this.f == 1) {
                    this.f = 2;
                    this.f657d.c();
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    @Override // a9.c
    public final void clear() {
        synchronized (this.f654a) {
            try {
                this.f658e = 3;
                this.f656c.clear();
                if (this.f != 3) {
                    this.f = 3;
                    this.f657d.clear();
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    @Override // a9.d, a9.c
    public final boolean d() {
        boolean z5;
        synchronized (this.f654a) {
            try {
                z5 = this.f656c.d() || this.f657d.d();
            } catch (Throwable th2) {
                throw th2;
            }
        }
        return z5;
    }

    @Override // a9.d
    public final boolean e(c cVar) {
        boolean z5;
        synchronized (this.f654a) {
            d dVar = this.f655b;
            z5 = dVar == null || dVar.e(this);
        }
        return z5;
    }

    @Override // a9.c
    public final boolean f() {
        boolean z5;
        synchronized (this.f654a) {
            try {
                z5 = this.f658e == 3 && this.f == 3;
            } catch (Throwable th2) {
                throw th2;
            }
        }
        return z5;
    }

    @Override // a9.d
    public final void g(c cVar) {
        synchronized (this.f654a) {
            try {
                if (cVar.equals(this.f656c)) {
                    this.f658e = 4;
                } else if (cVar.equals(this.f657d)) {
                    this.f = 4;
                }
                d dVar = this.f655b;
                if (dVar != null) {
                    dVar.g(this);
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    @Override // a9.d
    public final d getRoot() {
        d root;
        synchronized (this.f654a) {
            try {
                d dVar = this.f655b;
                root = dVar != null ? dVar.getRoot() : this;
            } catch (Throwable th2) {
                throw th2;
            }
        }
        return root;
    }

    @Override // a9.c
    public final void h() {
        synchronized (this.f654a) {
            try {
                if (this.f658e != 1) {
                    this.f658e = 1;
                    this.f656c.h();
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    @Override // a9.c
    public final boolean i(c cVar) {
        if (cVar instanceof b) {
            b bVar = (b) cVar;
            if (this.f656c.i(bVar.f656c) && this.f657d.i(bVar.f657d)) {
                return true;
            }
        }
        return false;
    }

    @Override // a9.c
    public final boolean isRunning() {
        boolean z5;
        synchronized (this.f654a) {
            try {
                z5 = true;
                if (this.f658e != 1 && this.f != 1) {
                    z5 = false;
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
        return z5;
    }

    @Override // a9.d
    public final void j(c cVar) {
        synchronized (this.f654a) {
            try {
                if (cVar.equals(this.f657d)) {
                    this.f = 5;
                    d dVar = this.f655b;
                    if (dVar != null) {
                        dVar.j(this);
                    }
                    return;
                }
                this.f658e = 5;
                if (this.f != 1) {
                    this.f = 1;
                    this.f657d.h();
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    @Override // a9.c
    public final boolean k() {
        boolean z5;
        synchronized (this.f654a) {
            try {
                z5 = this.f658e == 4 || this.f == 4;
            } catch (Throwable th2) {
                throw th2;
            }
        }
        return z5;
    }
}
