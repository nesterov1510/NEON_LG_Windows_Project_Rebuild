package a9;

import android.graphics.drawable.Drawable;
import android.os.Looper;
import e9.o;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import k8.u;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class e implements Future, b9.d, f {
    public c X;
    public boolean Y;
    public boolean Z;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public Object f659e;

    /* JADX INFO: renamed from: r0, reason: collision with root package name */
    public boolean f660r0;

    /* JADX INFO: renamed from: s0, reason: collision with root package name */
    public u f661s0;

    @Override // java.util.concurrent.Future
    public final boolean cancel(boolean z5) {
        synchronized (this) {
            try {
                if (isDone()) {
                    return false;
                }
                this.Y = true;
                notifyAll();
                c cVar = null;
                if (z5) {
                    c cVar2 = this.X;
                    this.X = null;
                    cVar = cVar2;
                }
                if (cVar != null) {
                    cVar.clear();
                }
                return true;
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    @Override // a9.f
    public final synchronized void d(Object obj, Object obj2, b9.d dVar, int i10) {
        this.Z = true;
        this.f659e = obj;
        notifyAll();
    }

    @Override // a9.f
    public final synchronized void e(u uVar, b9.d dVar) {
        this.f660r0 = true;
        this.f661s0 = uVar;
        notifyAll();
    }

    public final synchronized Object g(Long l10) {
        if (!isDone()) {
            char[] cArr = o.f7695a;
            if (Looper.myLooper() == Looper.getMainLooper()) {
                throw new IllegalArgumentException("You must call this method on a background thread");
            }
        }
        if (this.Y) {
            throw new CancellationException();
        }
        if (this.f660r0) {
            throw new ExecutionException(this.f661s0);
        }
        if (this.Z) {
            return this.f659e;
        }
        if (l10 == null) {
            wait(0L);
        } else if (l10.longValue() > 0) {
            long jCurrentTimeMillis = System.currentTimeMillis();
            long jLongValue = l10.longValue() + jCurrentTimeMillis;
            while (!isDone() && jCurrentTimeMillis < jLongValue) {
                wait(jLongValue - jCurrentTimeMillis);
                jCurrentTimeMillis = System.currentTimeMillis();
            }
        }
        if (Thread.interrupted()) {
            throw new InterruptedException();
        }
        if (this.f660r0) {
            throw new ExecutionException(this.f661s0);
        }
        if (this.Y) {
            throw new CancellationException();
        }
        if (this.Z) {
            return this.f659e;
        }
        throw new TimeoutException();
    }

    @Override // java.util.concurrent.Future
    public final Object get() {
        try {
            return g(null);
        } catch (TimeoutException e3) {
            throw new AssertionError(e3);
        }
    }

    @Override // java.util.concurrent.Future
    public final synchronized boolean isCancelled() {
        return this.Y;
    }

    @Override // java.util.concurrent.Future
    public final synchronized boolean isDone() {
        return this.Y || this.Z || this.f660r0;
    }

    @Override // b9.d
    public final synchronized c m() {
        return this.X;
    }

    @Override // b9.d
    public final void n(h hVar) throws Throwable {
        hVar.m(Integer.MIN_VALUE, Integer.MIN_VALUE);
    }

    @Override // b9.d
    public final synchronized void o(Object obj) {
    }

    @Override // b9.d
    public final synchronized void p(Drawable drawable) {
    }

    @Override // b9.d
    public final synchronized void t(c cVar) {
        this.X = cVar;
    }

    public final String toString() {
        c cVar;
        String str;
        String strR = a0.f.r(new StringBuilder(), super.toString(), "[status=");
        synchronized (this) {
            try {
                cVar = null;
                if (this.Y) {
                    str = "CANCELLED";
                } else if (this.f660r0) {
                    str = "FAILURE";
                } else if (this.Z) {
                    str = "SUCCESS";
                } else {
                    str = "PENDING";
                    cVar = this.X;
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
        if (cVar == null) {
            return p0.e.m(strR, str, "]");
        }
        return strR + str + ", request=[" + cVar + "]]";
    }

    @Override // java.util.concurrent.Future
    public final Object get(long j10, TimeUnit timeUnit) {
        return g(Long.valueOf(timeUnit.toMillis(j10)));
    }

    @Override // x8.i
    public final void b() {
    }

    @Override // x8.i
    public final void c() {
    }

    @Override // x8.i
    public final void f() {
    }

    @Override // b9.d
    public final void q(h hVar) {
    }

    @Override // b9.d
    public final void r(Drawable drawable) {
    }

    @Override // b9.d
    public final void s(Drawable drawable) {
    }
}
