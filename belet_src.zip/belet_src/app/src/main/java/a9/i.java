package a9;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class i implements d, c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final d f686a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Object f687b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public volatile h f688c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public volatile c f689d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f690e = 3;
    public int f = 3;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f691g;

    public i(Object obj, d dVar) {
        this.f687b = obj;
        this.f686a = dVar;
    }

    @Override // a9.d
    public final boolean a(c cVar) {
        boolean z5;
        synchronized (this.f687b) {
            try {
                d dVar = this.f686a;
                z5 = (dVar == null || dVar.a(this)) && cVar.equals(this.f688c) && !d();
            } catch (Throwable th2) {
                throw th2;
            }
        }
        return z5;
    }

    @Override // a9.d
    public final boolean b(c cVar) {
        boolean z5;
        synchronized (this.f687b) {
            try {
                d dVar = this.f686a;
                z5 = (dVar == null || dVar.b(this)) && cVar.equals(this.f688c) && this.f690e != 2;
            } catch (Throwable th2) {
                throw th2;
            }
        }
        return z5;
    }

    @Override // a9.c
    public final void c() {
        synchronized (this.f687b) {
            try {
                if (!a0.f.e(this.f)) {
                    this.f = 2;
                    this.f689d.c();
                }
                if (!a0.f.e(this.f690e)) {
                    this.f690e = 2;
                    this.f688c.c();
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    @Override // a9.c
    public final void clear() {
        synchronized (this.f687b) {
            this.f691g = false;
            this.f690e = 3;
            this.f = 3;
            this.f689d.clear();
            this.f688c.clear();
        }
    }

    @Override // a9.d, a9.c
    public final boolean d() {
        boolean z5;
        synchronized (this.f687b) {
            try {
                z5 = this.f689d.d() || this.f688c.d();
            } catch (Throwable th2) {
                throw th2;
            }
        }
        return z5;
    }

    @Override // a9.d
    public final boolean e(c cVar) {
        boolean z5;
        synchronized (this.f687b) {
            try {
                d dVar = this.f686a;
                z5 = (dVar == null || dVar.e(this)) && (cVar.equals(this.f688c) || this.f690e != 4);
            } catch (Throwable th2) {
                throw th2;
            }
        }
        return z5;
    }

    @Override // a9.c
    public final boolean f() {
        boolean z5;
        synchronized (this.f687b) {
            z5 = this.f690e == 3;
        }
        return z5;
    }

    @Override // a9.d
    public final void g(c cVar) {
        synchronized (this.f687b) {
            try {
                if (cVar.equals(this.f689d)) {
                    this.f = 4;
                    return;
                }
                this.f690e = 4;
                d dVar = this.f686a;
                if (dVar != null) {
                    dVar.g(this);
                }
                if (!a0.f.e(this.f)) {
                    this.f689d.clear();
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    @Override // a9.d
    public final d getRoot() {
        d root;
        synchronized (this.f687b) {
            try {
                d dVar = this.f686a;
                root = dVar != null ? dVar.getRoot() : this;
            } catch (Throwable th2) {
                throw th2;
            }
        }
        return root;
    }

    @Override // a9.c
    public final void h() {
        synchronized (this.f687b) {
            try {
                this.f691g = true;
                try {
                    if (this.f690e != 4 && this.f != 1) {
                        this.f = 1;
                        this.f689d.h();
                    }
                    if (this.f691g && this.f690e != 1) {
                        this.f690e = 1;
                        this.f688c.h();
                    }
                    this.f691g = false;
                } catch (Throwable th2) {
                    this.f691g = false;
                    throw th2;
                }
            } catch (Throwable th3) {
                throw th3;
            }
        }
    }

    @Override // a9.c
    public final boolean i(c cVar) {
        if (!(cVar instanceof i)) {
            return false;
        }
        i iVar = (i) cVar;
        if (this.f688c == null) {
            if (iVar.f688c != null) {
                return false;
            }
        } else if (!this.f688c.i(iVar.f688c)) {
            return false;
        }
        if (this.f689d == null) {
            return iVar.f689d == null;
        }
        return this.f689d.i(iVar.f689d);
    }

    @Override // a9.c
    public final boolean isRunning() {
        boolean z5;
        synchronized (this.f687b) {
            z5 = true;
            if (this.f690e != 1) {
                z5 = false;
            }
        }
        return z5;
    }

    @Override // a9.d
    public final void j(c cVar) {
        synchronized (this.f687b) {
            try {
                if (!cVar.equals(this.f688c)) {
                    this.f = 5;
                    return;
                }
                this.f690e = 5;
                d dVar = this.f686a;
                if (dVar != null) {
                    dVar.j(this);
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    @Override // a9.c
    public final boolean k() {
        boolean z5;
        synchronized (this.f687b) {
            z5 = this.f690e == 4;
        }
        return z5;
    }
}
