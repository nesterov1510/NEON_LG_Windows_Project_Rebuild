package a9;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public interface c {
    void c();

    void clear();

    boolean d();

    boolean f();

    void h();

    boolean i(c cVar);

    boolean isRunning();

    boolean k();
}
