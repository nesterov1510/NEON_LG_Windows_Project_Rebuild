package a9;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.SystemClock;
import android.util.Log;
import com.google.protobuf.m0;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Executor;
import k8.j;
import k8.k;
import k8.l;
import k8.o;
import k8.u;
import k8.y;
import okhttp3.internal.url._UrlKt;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class h implements c, b9.c {
    public static final boolean D = Log.isLoggable("GlideRequest", 2);
    public boolean A;
    public final RuntimeException B;
    public int C;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f662a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final f9.e f663b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Object f664c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final f f665d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final d f666e;
    public final Context f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final com.bumptech.glide.f f667g;
    public final Object h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final Class f668i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final a f669j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final int f670k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final int f671l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final com.bumptech.glide.h f672m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final b9.d f673n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final List f674o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final c9.a f675p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final Executor f676q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public y f677r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public k f678s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public long f679t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public volatile l f680u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public Drawable f681v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public Drawable f682w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public Drawable f683x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public int f684y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public int f685z;

    public h(Context context, com.bumptech.glide.f fVar, Object obj, Object obj2, Class cls, a aVar, int i10, int i11, com.bumptech.glide.h hVar, b9.d dVar, f fVar2, ArrayList arrayList, d dVar2, l lVar, c9.a aVar2, Executor executor) {
        this.f662a = D ? String.valueOf(hashCode()) : null;
        this.f663b = new f9.e();
        this.f664c = obj;
        this.f = context;
        this.f667g = fVar;
        this.h = obj2;
        this.f668i = cls;
        this.f669j = aVar;
        this.f670k = i10;
        this.f671l = i11;
        this.f672m = hVar;
        this.f673n = dVar;
        this.f665d = fVar2;
        this.f674o = arrayList;
        this.f666e = dVar2;
        this.f680u = lVar;
        this.f675p = aVar2;
        this.f676q = executor;
        this.C = 1;
        if (this.B == null && fVar.h.f4749a.containsKey(com.bumptech.glide.d.class)) {
            this.B = new RuntimeException("Glide request origin trace");
        }
    }

    public final void a() {
        if (this.A) {
            throw new IllegalStateException("You can't start or clear loads in RequestListener or Target callbacks. If you're trying to start a fallback request when a load fails, use RequestBuilder#error(RequestBuilder). Otherwise consider posting your into() or clear() calls to the main thread using a Handler instead.");
        }
        this.f663b.a();
        this.f673n.q(this);
        k kVar = this.f678s;
        if (kVar != null) {
            synchronized (((l) kVar.Z)) {
                ((o) kVar.X).j((h) kVar.Y);
            }
            this.f678s = null;
        }
    }

    public final Drawable b() {
        if (this.f682w == null) {
            a aVar = this.f669j;
            aVar.getClass();
            this.f682w = null;
            int i10 = aVar.f646r0;
            if (i10 > 0) {
                aVar.getClass();
                Context context = this.f;
                this.f682w = g0.c.m(context, context, i10, context.getTheme());
            }
        }
        return this.f682w;
    }

    @Override // a9.c
    public final void c() {
        synchronized (this.f664c) {
            try {
                if (isRunning()) {
                    clear();
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    @Override // a9.c
    public final void clear() {
        synchronized (this.f664c) {
            try {
                if (this.A) {
                    throw new IllegalStateException("You can't start or clear loads in RequestListener or Target callbacks. If you're trying to start a fallback request when a load fails, use RequestBuilder#error(RequestBuilder). Otherwise consider posting your into() or clear() calls to the main thread using a Handler instead.");
                }
                this.f663b.a();
                if (this.C == 6) {
                    return;
                }
                a();
                y yVar = this.f677r;
                if (yVar != null) {
                    this.f677r = null;
                } else {
                    yVar = null;
                }
                d dVar = this.f666e;
                if (dVar == null || dVar.b(this)) {
                    this.f673n.s(b());
                }
                this.C = 6;
                if (yVar != null) {
                    this.f680u.getClass();
                    l.g(yVar);
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    @Override // a9.c
    public final boolean d() {
        boolean z5;
        synchronized (this.f664c) {
            z5 = this.C == 4;
        }
        return z5;
    }

    public final void e(String str) {
        StringBuilder sbU = a0.f.u(str, " this: ");
        sbU.append(this.f662a);
        Log.v("GlideRequest", sbU.toString());
    }

    @Override // a9.c
    public final boolean f() {
        boolean z5;
        synchronized (this.f664c) {
            z5 = this.C == 6;
        }
        return z5;
    }

    public final void g(u uVar, int i10) {
        Drawable drawableB;
        this.f663b.a();
        synchronized (this.f664c) {
            try {
                uVar.getClass();
                int i11 = this.f667g.f4747i;
                if (i11 <= i10) {
                    Log.w("Glide", "Load failed for [" + this.h + "] with dimensions [" + this.f684y + "x" + this.f685z + "]", uVar);
                    if (i11 <= 4) {
                        uVar.d();
                    }
                }
                this.f678s = null;
                this.C = 5;
                d dVar = this.f666e;
                if (dVar != null) {
                    dVar.j(this);
                }
                boolean z5 = true;
                this.A = true;
                try {
                    List<f> list = this.f674o;
                    if (list != null) {
                        for (f fVar : list) {
                            b9.d dVar2 = this.f673n;
                            d dVar3 = this.f666e;
                            if (dVar3 != null) {
                                dVar3.getRoot().d();
                            }
                            fVar.e(uVar, dVar2);
                        }
                    }
                    f fVar2 = this.f665d;
                    if (fVar2 != null) {
                        b9.d dVar4 = this.f673n;
                        d dVar5 = this.f666e;
                        if (dVar5 != null) {
                            dVar5.getRoot().d();
                        }
                        fVar2.e(uVar, dVar4);
                    }
                    d dVar6 = this.f666e;
                    if (dVar6 != null && !dVar6.a(this)) {
                        z5 = false;
                    }
                    if (z5) {
                        if (this.h == null) {
                            if (this.f683x == null) {
                                this.f669j.getClass();
                                this.f683x = null;
                            }
                            drawableB = this.f683x;
                        } else {
                            drawableB = null;
                        }
                        if (drawableB == null) {
                            if (this.f681v == null) {
                                a aVar = this.f669j;
                                aVar.getClass();
                                this.f681v = null;
                                int i12 = aVar.Z;
                                if (i12 > 0) {
                                    Context context = this.f;
                                    this.f669j.getClass();
                                    this.f681v = g0.c.m(context, context, i12, context.getTheme());
                                }
                            }
                            drawableB = this.f681v;
                        }
                        if (drawableB == null) {
                            drawableB = b();
                        }
                        this.f673n.p(drawableB);
                    }
                    this.A = false;
                } catch (Throwable th2) {
                    this.A = false;
                    throw th2;
                }
            } catch (Throwable th3) {
                throw th3;
            }
        }
    }

    @Override // a9.c
    public final void h() {
        synchronized (this.f664c) {
            try {
                if (this.A) {
                    throw new IllegalStateException("You can't start or clear loads in RequestListener or Target callbacks. If you're trying to start a fallback request when a load fails, use RequestBuilder#error(RequestBuilder). Otherwise consider posting your into() or clear() calls to the main thread using a Handler instead.");
                }
                this.f663b.a();
                int i10 = e9.i.f7684b;
                this.f679t = SystemClock.elapsedRealtimeNanos();
                if (this.h == null) {
                    if (e9.o.i(this.f670k, this.f671l)) {
                        this.f684y = this.f670k;
                        this.f685z = this.f671l;
                    }
                    if (this.f683x == null) {
                        this.f669j.getClass();
                        this.f683x = null;
                    }
                    g(new u("Received null model"), this.f683x == null ? 5 : 3);
                    return;
                }
                int i11 = this.C;
                if (i11 == 2) {
                    throw new IllegalArgumentException("Cannot restart a running request");
                }
                if (i11 == 4) {
                    j(this.f677r, 5, false);
                    return;
                }
                List<f> list = this.f674o;
                if (list != null) {
                    for (f fVar : list) {
                    }
                }
                this.C = 3;
                if (e9.o.i(this.f670k, this.f671l)) {
                    m(this.f670k, this.f671l);
                } else {
                    this.f673n.n(this);
                }
                int i12 = this.C;
                if (i12 == 2 || i12 == 3) {
                    d dVar = this.f666e;
                    if (dVar == null || dVar.a(this)) {
                        this.f673n.r(b());
                    }
                }
                if (D) {
                    e("finished run method in " + e9.i.a(this.f679t));
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    @Override // a9.c
    public final boolean i(c cVar) {
        int i10;
        int i11;
        Object obj;
        Class cls;
        a aVar;
        com.bumptech.glide.h hVar;
        int size;
        int i12;
        int i13;
        Object obj2;
        Class cls2;
        a aVar2;
        com.bumptech.glide.h hVar2;
        int size2;
        boolean zEquals;
        boolean zF;
        if (!(cVar instanceof h)) {
            return false;
        }
        synchronized (this.f664c) {
            try {
                i10 = this.f670k;
                i11 = this.f671l;
                obj = this.h;
                cls = this.f668i;
                aVar = this.f669j;
                hVar = this.f672m;
                List list = this.f674o;
                size = list != null ? list.size() : 0;
            } catch (Throwable th2) {
                throw th2;
            }
        }
        h hVar3 = (h) cVar;
        synchronized (hVar3.f664c) {
            try {
                i12 = hVar3.f670k;
                i13 = hVar3.f671l;
                obj2 = hVar3.h;
                cls2 = hVar3.f668i;
                aVar2 = hVar3.f669j;
                hVar2 = hVar3.f672m;
                List list2 = hVar3.f674o;
                size2 = list2 != null ? list2.size() : 0;
            } catch (Throwable th3) {
                throw th3;
            }
        }
        if (i10 == i12 && i11 == i13) {
            char[] cArr = e9.o.f7695a;
            if (obj == null) {
                zEquals = obj2 == null;
            } else {
                zEquals = obj.equals(obj2);
            }
            if (zEquals && cls.equals(cls2)) {
                if (aVar == null) {
                    zF = aVar2 == null;
                } else {
                    zF = aVar.f(aVar2);
                }
                if (zF && hVar == hVar2 && size == size2) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override // a9.c
    public final boolean isRunning() {
        boolean z5;
        synchronized (this.f664c) {
            int i10 = this.C;
            z5 = i10 == 2 || i10 == 3;
        }
        return z5;
    }

    public final void j(y yVar, int i10, boolean z5) {
        this.f663b.a();
        y yVar2 = null;
        try {
            synchronized (this.f664c) {
                try {
                    this.f678s = null;
                    if (yVar == null) {
                        g(new u("Expected to receive a Resource<R> with an object of " + this.f668i + " inside, but instead got null."), 5);
                        return;
                    }
                    Object obj = yVar.get();
                    try {
                        if (obj == null || !this.f668i.isAssignableFrom(obj.getClass())) {
                            this.f677r = null;
                            StringBuilder sb2 = new StringBuilder("Expected to receive an object of ");
                            sb2.append(this.f668i);
                            sb2.append(" but instead got ");
                            sb2.append(obj != null ? obj.getClass() : _UrlKt.FRAGMENT_ENCODE_SET);
                            sb2.append("{");
                            sb2.append(obj);
                            sb2.append("} inside Resource{");
                            sb2.append(yVar);
                            sb2.append("}.");
                            sb2.append(obj != null ? _UrlKt.FRAGMENT_ENCODE_SET : " To indicate failure return a null Resource object, rather than a Resource object containing null data.");
                            g(new u(sb2.toString()), 5);
                        } else {
                            d dVar = this.f666e;
                            if (dVar == null || dVar.e(this)) {
                                l(yVar, obj, i10);
                                return;
                            } else {
                                this.f677r = null;
                                this.C = 4;
                            }
                        }
                        this.f680u.getClass();
                        l.g(yVar);
                    } catch (Throwable th2) {
                        yVar2 = yVar;
                        th = th2;
                        throw th;
                    }
                } catch (Throwable th3) {
                    th = th3;
                }
            }
        } catch (Throwable th4) {
            if (yVar2 != null) {
                this.f680u.getClass();
                l.g(yVar2);
            }
            throw th4;
        }
    }

    @Override // a9.c
    public final boolean k() {
        boolean z5;
        synchronized (this.f664c) {
            z5 = this.C == 4;
        }
        return z5;
    }

    public final void l(y yVar, Object obj, int i10) {
        d dVar = this.f666e;
        if (dVar != null) {
            dVar.getRoot().d();
        }
        this.C = 4;
        this.f677r = yVar;
        int i11 = this.f667g.f4747i;
        Object obj2 = this.h;
        if (i11 <= 3) {
            Log.d("Glide", "Finished loading " + obj.getClass().getSimpleName() + " from " + m0.w(i10) + " for " + obj2 + " with size [" + this.f684y + "x" + this.f685z + "] in " + e9.i.a(this.f679t) + " ms");
        }
        if (dVar != null) {
            dVar.g(this);
        }
        this.A = true;
        try {
            List list = this.f674o;
            b9.d dVar2 = this.f673n;
            if (list != null) {
                Iterator it = list.iterator();
                while (it.hasNext()) {
                    ((f) it.next()).d(obj, obj2, dVar2, i10);
                }
            }
            f fVar = this.f665d;
            if (fVar != null) {
                fVar.d(obj, obj2, dVar2, i10);
            }
            this.f675p.getClass();
            dVar2.o(obj);
        } finally {
            this.A = false;
        }
    }

    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$PrimitiveArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    public final void m(int i10, int i11) throws Throwable {
        Object obj;
        h hVar = this;
        int iRound = i10;
        hVar.f663b.a();
        Object obj2 = hVar.f664c;
        synchronized (obj2) {
            try {
                try {
                    boolean z5 = D;
                    if (z5) {
                        hVar.e("Got onSizeReady in " + e9.i.a(hVar.f679t));
                    }
                    if (hVar.C == 3) {
                        hVar.C = 2;
                        hVar.f669j.getClass();
                        if (iRound != Integer.MIN_VALUE) {
                            iRound = Math.round(iRound * 1.0f);
                        }
                        hVar.f684y = iRound;
                        hVar.f685z = i11 == Integer.MIN_VALUE ? i11 : Math.round(1.0f * i11);
                        if (z5) {
                            hVar.e("finished setup for calling load in " + e9.i.a(hVar.f679t));
                        }
                        l lVar = hVar.f680u;
                        com.bumptech.glide.f fVar = hVar.f667g;
                        Object obj3 = hVar.h;
                        a aVar = hVar.f669j;
                        i8.e eVar = aVar.f649v0;
                        try {
                            int i12 = hVar.f684y;
                            int i13 = hVar.f685z;
                            Class cls = aVar.f653z0;
                            try {
                                Class cls2 = hVar.f668i;
                                com.bumptech.glide.h hVar2 = hVar.f672m;
                                j jVar = aVar.X;
                                try {
                                    e9.d dVar = aVar.f652y0;
                                    boolean z6 = aVar.f650w0;
                                    boolean z9 = aVar.C0;
                                    try {
                                        i8.h hVar3 = aVar.f651x0;
                                        boolean z10 = aVar.f647s0;
                                        boolean z11 = aVar.D0;
                                        Executor executor = hVar.f676q;
                                        Object obj4 = obj2;
                                        try {
                                            hVar.f678s = lVar.a(fVar, obj3, eVar, i12, i13, cls, cls2, hVar2, jVar, dVar, z6, z9, hVar3, z10, z11, hVar, executor);
                                            if (hVar.C != 2) {
                                                hVar.f678s = null;
                                            }
                                            if (z5) {
                                                hVar.e("finished onSizeReady in " + e9.i.a(hVar.f679t));
                                            }
                                        } catch (Throwable th2) {
                                            th = th2;
                                            obj = obj4;
                                            throw th;
                                        }
                                    } catch (Throwable th3) {
                                        th = th3;
                                        obj = obj2;
                                    }
                                } catch (Throwable th4) {
                                    th = th4;
                                    obj = obj2;
                                }
                            } catch (Throwable th5) {
                                th = th5;
                                obj = obj2;
                            }
                        } catch (Throwable th6) {
                            th = th6;
                            obj = obj2;
                        }
                    }
                } catch (Throwable th7) {
                    th = th7;
                    obj = hVar;
                }
            } catch (Throwable th8) {
                th = th8;
                obj = obj2;
            }
        }
    }

    public final String toString() {
        Object obj;
        Class cls;
        synchronized (this.f664c) {
            obj = this.h;
            cls = this.f668i;
        }
        return super.toString() + "[model=" + obj + ", transcodeClass=" + cls + "]";
    }
}
