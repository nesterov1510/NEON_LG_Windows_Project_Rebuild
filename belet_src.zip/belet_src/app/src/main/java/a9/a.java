package a9;

import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import e9.o;
import i8.l;
import k8.j;
import okio.internal.Buffer;
import r8.m;
import r8.r;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public abstract class a implements Cloneable {
    public boolean A0;
    public boolean B0;
    public boolean D0;
    public int Z;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f645e;

    /* JADX INFO: renamed from: r0, reason: collision with root package name */
    public int f646r0;

    /* JADX INFO: renamed from: w0, reason: collision with root package name */
    public boolean f650w0;
    public j X = j.f13675d;
    public com.bumptech.glide.h Y = com.bumptech.glide.h.Y;

    /* JADX INFO: renamed from: s0, reason: collision with root package name */
    public boolean f647s0 = true;

    /* JADX INFO: renamed from: t0, reason: collision with root package name */
    public int f648t0 = -1;
    public int u0 = -1;

    /* JADX INFO: renamed from: v0, reason: collision with root package name */
    public i8.e f649v0 = d9.a.f6734b;

    /* JADX INFO: renamed from: x0, reason: collision with root package name */
    public i8.h f651x0 = new i8.h();

    /* JADX INFO: renamed from: y0, reason: collision with root package name */
    public e9.d f652y0 = new e9.d(0);

    /* JADX INFO: renamed from: z0, reason: collision with root package name */
    public Class f653z0 = Object.class;
    public boolean C0 = true;

    public static boolean g(int i10, int i11) {
        return (i10 & i11) != 0;
    }

    public a a(a aVar) {
        if (this.B0) {
            return clone().a(aVar);
        }
        int i10 = aVar.f645e;
        if (g(aVar.f645e, 1048576)) {
            this.D0 = aVar.D0;
        }
        if (g(aVar.f645e, 4)) {
            this.X = aVar.X;
        }
        if (g(aVar.f645e, 8)) {
            this.Y = aVar.Y;
        }
        if (g(aVar.f645e, 16)) {
            this.Z = 0;
            this.f645e &= -33;
        }
        if (g(aVar.f645e, 32)) {
            this.Z = aVar.Z;
            this.f645e &= -17;
        }
        if (g(aVar.f645e, 64)) {
            this.f646r0 = 0;
            this.f645e &= -129;
        }
        if (g(aVar.f645e, 128)) {
            this.f646r0 = aVar.f646r0;
            this.f645e &= -65;
        }
        if (g(aVar.f645e, 256)) {
            this.f647s0 = aVar.f647s0;
        }
        if (g(aVar.f645e, 512)) {
            this.u0 = aVar.u0;
            this.f648t0 = aVar.f648t0;
        }
        if (g(aVar.f645e, 1024)) {
            this.f649v0 = aVar.f649v0;
        }
        if (g(aVar.f645e, Buffer.SEGMENTING_THRESHOLD)) {
            this.f653z0 = aVar.f653z0;
        }
        if (g(aVar.f645e, 8192)) {
            this.f645e &= -16385;
        }
        if (g(aVar.f645e, 16384)) {
            this.f645e &= -8193;
        }
        if (g(aVar.f645e, 131072)) {
            this.f650w0 = aVar.f650w0;
        }
        if (g(aVar.f645e, 2048)) {
            this.f652y0.putAll(aVar.f652y0);
            this.C0 = aVar.C0;
        }
        this.f645e |= aVar.f645e;
        this.f651x0.f11341b.g(aVar.f651x0.f11341b);
        l();
        return this;
    }

    @Override // 
    /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
    public a clone() {
        try {
            a aVar = (a) super.clone();
            i8.h hVar = new i8.h();
            aVar.f651x0 = hVar;
            hVar.f11341b.g(this.f651x0.f11341b);
            e9.d dVar = new e9.d(0);
            aVar.f652y0 = dVar;
            dVar.putAll(this.f652y0);
            aVar.A0 = false;
            aVar.B0 = false;
            return aVar;
        } catch (CloneNotSupportedException e3) {
            throw new RuntimeException(e3);
        }
    }

    public final a c(Class cls) {
        if (this.B0) {
            return clone().c(cls);
        }
        this.f653z0 = cls;
        this.f645e |= Buffer.SEGMENTING_THRESHOLD;
        l();
        return this;
    }

    public final a d(j jVar) {
        if (this.B0) {
            return clone().d(jVar);
        }
        this.X = jVar;
        this.f645e |= 4;
        l();
        return this;
    }

    public final a e(int i10) {
        if (this.B0) {
            return clone().e(i10);
        }
        this.Z = i10;
        this.f645e = (this.f645e | 32) & (-17);
        l();
        return this;
    }

    public boolean equals(Object obj) {
        if (obj instanceof a) {
            return f((a) obj);
        }
        return false;
    }

    public final boolean f(a aVar) {
        aVar.getClass();
        if (Float.compare(1.0f, 1.0f) != 0 || this.Z != aVar.Z) {
            return false;
        }
        char[] cArr = o.f7695a;
        return this.f646r0 == aVar.f646r0 && this.f647s0 == aVar.f647s0 && this.f648t0 == aVar.f648t0 && this.u0 == aVar.u0 && this.f650w0 == aVar.f650w0 && this.X.equals(aVar.X) && this.Y == aVar.Y && this.f651x0.equals(aVar.f651x0) && this.f652y0.equals(aVar.f652y0) && this.f653z0.equals(aVar.f653z0) && this.f649v0.equals(aVar.f649v0);
    }

    public final a h(m mVar, r8.e eVar) {
        if (this.B0) {
            return clone().h(mVar, eVar);
        }
        m(m.f17922g, mVar);
        return p(eVar, false);
    }

    public int hashCode() {
        char[] cArr = o.f7695a;
        return o.h(o.h(o.h(o.h(o.h(o.h(o.h(o.g(0, o.g(0, o.g(1, o.g(this.f650w0 ? 1 : 0, o.g(this.u0, o.g(this.f648t0, o.g(this.f647s0 ? 1 : 0, o.h(o.g(0, o.h(o.g(this.f646r0, o.h(o.g(this.Z, o.g(Float.floatToIntBits(1.0f), 17)), null)), null)), null)))))))), this.X), this.Y), this.f651x0), this.f652y0), this.f653z0), this.f649v0), null);
    }

    public final a i(int i10, int i11) {
        if (this.B0) {
            return clone().i(i10, i11);
        }
        this.u0 = i10;
        this.f648t0 = i11;
        this.f645e |= 512;
        l();
        return this;
    }

    public final a j(int i10) {
        if (this.B0) {
            return clone().j(i10);
        }
        this.f646r0 = i10;
        this.f645e = (this.f645e | 128) & (-65);
        l();
        return this;
    }

    public final a k() {
        if (this.B0) {
            return clone().k();
        }
        this.Y = com.bumptech.glide.h.Z;
        this.f645e |= 8;
        l();
        return this;
    }

    public final void l() {
        if (this.A0) {
            throw new IllegalStateException("You cannot modify locked T, consider clone()");
        }
    }

    public final a m(i8.g gVar, m mVar) {
        if (this.B0) {
            return clone().m(gVar, mVar);
        }
        e9.g.b(gVar);
        this.f651x0.f11341b.put(gVar, mVar);
        l();
        return this;
    }

    public final a n(i8.e eVar) {
        if (this.B0) {
            return clone().n(eVar);
        }
        this.f649v0 = eVar;
        this.f645e |= 1024;
        l();
        return this;
    }

    public final a o(boolean z5) {
        if (this.B0) {
            return clone().o(true);
        }
        this.f647s0 = !z5;
        this.f645e |= 256;
        l();
        return this;
    }

    public final a p(l lVar, boolean z5) {
        if (this.B0) {
            return clone().p(lVar, z5);
        }
        r rVar = new r(lVar, z5);
        q(Bitmap.class, lVar, z5);
        q(Drawable.class, rVar, z5);
        q(BitmapDrawable.class, rVar, z5);
        q(v8.b.class, new v8.c(lVar), z5);
        l();
        return this;
    }

    public final a q(Class cls, l lVar, boolean z5) {
        if (this.B0) {
            return clone().q(cls, lVar, z5);
        }
        e9.g.b(lVar);
        this.f652y0.put(cls, lVar);
        int i10 = this.f645e;
        this.f645e = 67584 | i10;
        this.C0 = false;
        if (z5) {
            this.f645e = i10 | 198656;
            this.f650w0 = true;
        }
        l();
        return this;
    }

    public final a r() {
        if (this.B0) {
            return clone().r();
        }
        this.D0 = true;
        this.f645e |= 1048576;
        l();
        return this;
    }
}
