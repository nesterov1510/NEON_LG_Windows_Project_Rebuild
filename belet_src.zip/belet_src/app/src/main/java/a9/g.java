package a9;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class g extends a {
    public static g E0;

    @Override // a9.a
    public final boolean equals(Object obj) {
        return (obj instanceof g) && super.equals(obj);
    }
}
