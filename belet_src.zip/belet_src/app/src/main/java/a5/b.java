package a5;

import i3.m0;
import i3.o0;
import j$.util.Objects;
import java.util.List;
import java.util.Map;
import ji.k;
import kotlin.jvm.internal.p;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class b implements o0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f571a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f572b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final String f573c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final String f574d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final boolean f575e;
    public final int f;

    public b(int i10, int i11, String str, String str2, String str3, boolean z5) {
        k.n(i11 == -1 || i11 > 0);
        this.f571a = i10;
        this.f572b = str;
        this.f573c = str2;
        this.f574d = str3;
        this.f575e = z5;
        this.f = i11;
    }

    public static b d(Map map) {
        boolean z5;
        int i10;
        String str;
        String str2;
        String str3;
        boolean zEquals;
        int i11;
        List list = (List) map.get("icy-br");
        boolean z6 = true;
        int i12 = -1;
        if (list != null) {
            String str4 = (String) list.get(0);
            try {
                i11 = Integer.parseInt(str4) * 1000;
                if (i11 > 0) {
                    z5 = true;
                } else {
                    try {
                        l3.b.m("IcyHeaders", "Invalid bitrate: " + str4);
                        z5 = false;
                        i11 = -1;
                    } catch (NumberFormatException unused) {
                        p.N("Invalid bitrate header: ", str4, "IcyHeaders");
                        z5 = false;
                    }
                }
            } catch (NumberFormatException unused2) {
                i11 = -1;
            }
            i10 = i11;
        } else {
            z5 = false;
            i10 = -1;
        }
        List list2 = (List) map.get("icy-genre");
        if (list2 != null) {
            str = (String) list2.get(0);
            z5 = true;
        } else {
            str = null;
        }
        List list3 = (List) map.get("icy-name");
        if (list3 != null) {
            str2 = (String) list3.get(0);
            z5 = true;
        } else {
            str2 = null;
        }
        List list4 = (List) map.get("icy-url");
        if (list4 != null) {
            str3 = (String) list4.get(0);
            z5 = true;
        } else {
            str3 = null;
        }
        List list5 = (List) map.get("icy-pub");
        if (list5 != null) {
            zEquals = ((String) list5.get(0)).equals("1");
            z5 = true;
        } else {
            zEquals = false;
        }
        List list6 = (List) map.get("icy-metaint");
        if (list6 != null) {
            String str5 = (String) list6.get(0);
            try {
                int i13 = Integer.parseInt(str5);
                if (i13 > 0) {
                    i12 = i13;
                } else {
                    try {
                        l3.b.m("IcyHeaders", "Invalid metadata interval: " + str5);
                        z6 = z5;
                    } catch (NumberFormatException unused3) {
                        i12 = i13;
                        p.N("Invalid metadata interval: ", str5, "IcyHeaders");
                    }
                }
                z5 = z6;
            } catch (NumberFormatException unused4) {
            }
        }
        int i14 = i12;
        if (z5) {
            return new b(i10, i14, str, str2, str3, zEquals);
        }
        return null;
    }

    @Override // i3.o0
    public final /* synthetic */ androidx.media3.common.b a() {
        return null;
    }

    @Override // i3.o0
    public final void b(m0 m0Var) {
        String str = this.f573c;
        if (str != null) {
            m0Var.G = str;
        }
        String str2 = this.f572b;
        if (str2 != null) {
            m0Var.E = str2;
        }
    }

    @Override // i3.o0
    public final /* synthetic */ byte[] c() {
        return null;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && b.class == obj.getClass()) {
            b bVar = (b) obj;
            if (this.f571a == bVar.f571a && Objects.equals(this.f572b, bVar.f572b) && Objects.equals(this.f573c, bVar.f573c) && Objects.equals(this.f574d, bVar.f574d) && this.f575e == bVar.f575e && this.f == bVar.f) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        int i10 = (527 + this.f571a) * 31;
        String str = this.f572b;
        int iHashCode = (i10 + (str != null ? str.hashCode() : 0)) * 31;
        String str2 = this.f573c;
        int iHashCode2 = (iHashCode + (str2 != null ? str2.hashCode() : 0)) * 31;
        String str3 = this.f574d;
        return ((((iHashCode2 + (str3 != null ? str3.hashCode() : 0)) * 31) + (this.f575e ? 1 : 0)) * 31) + this.f;
    }

    public final String toString() {
        return "IcyHeaders: name=\"" + this.f573c + "\", genre=\"" + this.f572b + "\", bitrate=" + this.f571a + ", metadataInterval=" + this.f;
    }
}
