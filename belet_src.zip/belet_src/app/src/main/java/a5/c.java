package a5;

import i3.m0;
import i3.o0;
import java.util.Arrays;
import p0.e;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class c implements o0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final byte[] f576a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f577b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final String f578c;

    public c(String str, String str2, byte[] bArr) {
        this.f576a = bArr;
        this.f577b = str;
        this.f578c = str2;
    }

    @Override // i3.o0
    public final /* synthetic */ androidx.media3.common.b a() {
        return null;
    }

    @Override // i3.o0
    public final void b(m0 m0Var) {
        String str = this.f577b;
        if (str != null) {
            m0Var.f10909a = str;
        }
    }

    @Override // i3.o0
    public final /* synthetic */ byte[] c() {
        return null;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || c.class != obj.getClass()) {
            return false;
        }
        return Arrays.equals(this.f576a, ((c) obj).f576a);
    }

    public final int hashCode() {
        return Arrays.hashCode(this.f576a);
    }

    public final String toString() {
        return e.i(this.f576a.length, "\"", com.google.protobuf.m0.n("ICY: title=\"", this.f577b, "\", url=\"", this.f578c, "\", rawMetadata.length=\""));
    }
}
