package a4;

import android.app.Notification;
import android.graphics.Bitmap;
import android.media.MediaCodecInfo;
import android.media.MediaCodecList;
import android.util.Log;
import android.view.View;
import androidx.media3.session.b4;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.common.util.concurrent.ListenableFuture;
import i3.n0;
import j$.util.DesugarCollections;
import java.io.ByteArrayOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import l3.l0;
import rc.m0;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class c0 implements b0, l3.d, rc.y, n4.d0, k2.p, w8.a {
    public int X;
    public Object Y;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f473e;

    public /* synthetic */ c0(int i10, int i11, Object obj) {
        this.f473e = i11;
        this.Y = obj;
        this.X = i10;
    }

    public void a(long j10) {
        int i10 = this.X;
        long[] jArr = (long[]) this.Y;
        if (i10 == jArr.length) {
            this.Y = Arrays.copyOf(jArr, i10 * 2);
        }
        long[] jArr2 = (long[]) this.Y;
        int i11 = this.X;
        this.X = i11 + 1;
        jArr2[i11] = j10;
    }

    @Override // a4.b0
    public MediaCodecInfo b(int i10) {
        if (((MediaCodecInfo[]) this.Y) == null) {
            this.Y = new MediaCodecList(this.X).getCodecInfos();
        }
        return ((MediaCodecInfo[]) this.Y)[i10];
    }

    @Override // a4.b0
    public boolean c(String str, String str2, MediaCodecInfo.CodecCapabilities codecCapabilities) {
        return codecCapabilities.isFeatureSupported(str);
    }

    @Override // rc.y
    public /* synthetic */ ListenableFuture call() {
        return ((n) this.Y).z(this.X);
    }

    @Override // a4.b0
    public boolean d(String str, MediaCodecInfo.CodecCapabilities codecCapabilities) {
        return codecCapabilities.isFeatureRequired(str);
    }

    @Override // k2.p
    public boolean e(View view) {
        ((BottomSheetBehavior) this.Y).K(this.X);
        return true;
    }

    @Override // a4.b0
    public int f() {
        if (((MediaCodecInfo[]) this.Y) == null) {
            this.Y = new MediaCodecList(this.X).getCodecInfos();
        }
        return ((MediaCodecInfo[]) this.Y).length;
    }

    @Override // l3.d
    public ListenableFuture g(n0 n0Var) {
        ListenableFuture listenableFutureG = ((l3.d) this.Y).g(n0Var);
        if (listenableFutureG == null) {
            return null;
        }
        return m0.g(listenableFutureG, new b4(2, this), rc.d0.f17971e);
    }

    @Override // a4.b0
    public boolean h() {
        return true;
    }

    public void i(long[] jArr) {
        int length = this.X + jArr.length;
        long[] jArr2 = (long[]) this.Y;
        if (length > jArr2.length) {
            this.Y = Arrays.copyOf(jArr2, Math.max(jArr2.length * 2, length));
        }
        System.arraycopy(jArr, 0, (long[]) this.Y, this.X, jArr.length);
        this.X = length;
    }

    public long j(int i10) {
        if (i10 >= 0 && i10 < this.X) {
            return ((long[]) this.Y)[i10];
        }
        StringBuilder sbP = p0.e.p("Invalid index ", i10, ", size is ");
        sbP.append(this.X);
        throw new IndexOutOfBoundsException(sbP.toString());
    }

    public synchronized List k() {
        return DesugarCollections.unmodifiableList(new ArrayList((ArrayList) this.Y));
    }

    @Override // l3.d
    public ListenableFuture l(byte[] bArr) {
        return m0.g(((l3.d) this.Y).l(bArr), new b4(2, this), rc.d0.f17971e);
    }

    @Override // w8.a
    public k8.y m(k8.y yVar, i8.h hVar) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        ((Bitmap) yVar.get()).compress((Bitmap.CompressFormat) this.Y, this.X, byteArrayOutputStream);
        yVar.b();
        return new r8.z(byteArrayOutputStream.toByteArray());
    }

    public boolean n() {
        return ((c8.b) this.Y) != null;
    }

    public long o(n4.k kVar) {
        l3.v vVar = (l3.v) this.Y;
        int i10 = 0;
        kVar.d(vVar.f14157a, 0, 1, false);
        int i11 = vVar.f14157a[0] & 255;
        if (i11 == 0) {
            return Long.MIN_VALUE;
        }
        int i12 = 128;
        int i13 = 0;
        while ((i11 & i12) == 0) {
            i12 >>= 1;
            i13++;
        }
        int i14 = i11 & (~i12);
        kVar.d(vVar.f14157a, 1, i13, false);
        while (i10 < i13) {
            i10++;
            i14 = (vVar.f14157a[i10] & 255) + (i14 << 8);
        }
        this.X = i13 + 1 + this.X;
        return i14;
    }

    public synchronized boolean p(List list) {
        ((ArrayList) this.Y).clear();
        if (list.size() <= this.X) {
            return ((ArrayList) this.Y).addAll(list);
        }
        Log.w("FirebaseCrashlytics", "Ignored 0 entries when adding rollout assignments. Maximum allowable: " + this.X, null);
        return ((ArrayList) this.Y).addAll(list.subList(0, this.X));
    }

    public String toString() {
        switch (this.f473e) {
            case 9:
                qc.a aVar = (qc.a) this.Y;
                ArrayList arrayList = new ArrayList(aVar.X);
                for (int i10 = 0; i10 < aVar.X; i10++) {
                    arrayList.add(l0.m0(aVar.b(i10)));
                }
                return "UnsupportedBrands{major=" + l0.m0(this.X) + ", compatible=" + arrayList + "}";
            default:
                return super.toString();
        }
    }

    public /* synthetic */ c0(int i10, Serializable serializable, int i11) {
        this.f473e = i11;
        this.X = i10;
        this.Y = serializable;
    }

    public c0(ConnectionResult connectionResult, int i10) {
        this.f473e = 7;
        ga.r.g(connectionResult);
        this.Y = connectionResult;
        this.X = i10;
    }

    public c0(int i10, byte b10) {
        this.f473e = i10;
        switch (i10) {
            case 4:
                this.X = 255;
                this.Y = null;
                break;
            case 8:
                this.Y = new l3.v(8);
                break;
            case ue.r.NETWORK_CLIENT_ERROR_REASON_FIELD_NUMBER /* 11 */:
                this.Y = new ArrayList();
                this.X = 128;
                break;
            case 17:
                this.Y = Bitmap.CompressFormat.JPEG;
                this.X = 100;
                break;
        }
    }

    public c0(int i10) {
        this.f473e = 13;
        this.Y = new long[i10];
    }

    public c0(int[] iArr, int i10) {
        qc.a aVar;
        this.f473e = 9;
        this.X = i10;
        if (iArr != null) {
            qc.a aVar2 = qc.a.Y;
            aVar = iArr.length == 0 ? qc.a.Y : new qc.a(Arrays.copyOf(iArr, iArr.length));
        } else {
            aVar = qc.a.Y;
        }
        this.Y = aVar;
    }

    public c0(int i10, ai.i iVar) {
        this.f473e = 6;
        this.X = i10;
        this.Y = new ai.i[]{iVar};
    }

    public c0(ai.i iVar, ai.i iVar2) {
        this.f473e = 6;
        this.X = 62;
        this.Y = new ai.i[]{iVar, iVar2};
    }

    public c0(int i10, Notification notification) {
        this.f473e = 1;
        this.X = i10;
        notification.getClass();
        this.Y = notification;
    }

    public c0(boolean z5, boolean z6, boolean z9) {
        this.f473e = 0;
        this.X = (z5 || z6 || z9) ? 1 : 0;
    }
}
