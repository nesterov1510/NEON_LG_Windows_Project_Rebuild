package a4;

import android.media.MediaCodecInfo;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public interface b0 {
    MediaCodecInfo b(int i10);

    boolean c(String str, String str2, MediaCodecInfo.CodecCapabilities codecCapabilities);

    boolean d(String str, MediaCodecInfo.CodecCapabilities codecCapabilities);

    int f();

    boolean h();
}
