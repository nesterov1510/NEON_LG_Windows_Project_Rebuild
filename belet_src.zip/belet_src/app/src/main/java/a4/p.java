package a4;

import android.media.MediaCodec;
import android.media.MediaFormat;
import android.os.Bundle;
import android.os.Handler;
import android.view.Surface;
import java.nio.ByteBuffer;
import java.util.ArrayList;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public interface p {
    void b(Bundle bundle);

    void c(int i10, r3.c cVar, long j10, int i11);

    void d(int i10, int i11, long j10, int i12);

    void e(int i10);

    boolean f(z7.b bVar);

    void flush();

    MediaFormat g();

    void h();

    void i(int i10, long j10);

    int j();

    void k(b bVar);

    void l(k4.i iVar, Handler handler);

    int m(MediaCodec.BufferInfo bufferInfo);

    void n(int i10);

    ByteBuffer o(int i10);

    void p(Surface surface);

    ByteBuffer q(int i10);

    void r(ArrayList arrayList);

    void release();

    void s(ArrayList arrayList);
}
