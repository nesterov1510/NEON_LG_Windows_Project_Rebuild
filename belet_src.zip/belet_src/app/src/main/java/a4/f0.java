package a4;

import android.media.MediaCodec;
import android.media.MediaFormat;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.Surface;
import java.nio.ByteBuffer;
import java.util.ArrayList;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class f0 implements p {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final MediaCodec f487a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final m f488b;

    public f0(MediaCodec mediaCodec, m mVar) {
        this.f487a = mediaCodec;
        this.f488b = mVar;
        if (Build.VERSION.SDK_INT < 35 || mVar == null) {
            return;
        }
        mVar.a(mediaCodec);
    }

    @Override // a4.p
    public final void b(Bundle bundle) {
        this.f487a.setParameters(bundle);
    }

    @Override // a4.p
    public final void c(int i10, r3.c cVar, long j10, int i11) {
        this.f487a.queueSecureInputBuffer(i10, 0, cVar.f17863i, j10, i11);
    }

    @Override // a4.p
    public final void d(int i10, int i11, long j10, int i12) {
        this.f487a.queueInputBuffer(i10, 0, i11, j10, i12);
    }

    @Override // a4.p
    public final void e(int i10) {
        this.f487a.releaseOutputBuffer(i10, false);
    }

    @Override // a4.p
    public final /* synthetic */ boolean f(z7.b bVar) {
        return false;
    }

    @Override // a4.p
    public final void flush() {
        this.f487a.flush();
    }

    @Override // a4.p
    public final MediaFormat g() {
        return this.f487a.getOutputFormat();
    }

    @Override // a4.p
    public final void h() {
        this.f487a.detachOutputSurface();
    }

    @Override // a4.p
    public final void i(int i10, long j10) {
        this.f487a.releaseOutputBuffer(i10, j10);
    }

    @Override // a4.p
    public final int j() {
        return this.f487a.dequeueInputBuffer(0L);
    }

    @Override // a4.p
    public final void k(b bVar) {
        bVar.run();
    }

    @Override // a4.p
    public final void l(k4.i iVar, Handler handler) {
        this.f487a.setOnFrameRenderedListener(new a(this, iVar, 1), handler);
    }

    @Override // a4.p
    public final int m(MediaCodec.BufferInfo bufferInfo) {
        int iDequeueOutputBuffer;
        do {
            iDequeueOutputBuffer = this.f487a.dequeueOutputBuffer(bufferInfo, 0L);
        } while (iDequeueOutputBuffer == -3);
        return iDequeueOutputBuffer;
    }

    @Override // a4.p
    public final void n(int i10) {
        this.f487a.setVideoScalingMode(i10);
    }

    @Override // a4.p
    public final ByteBuffer o(int i10) {
        return this.f487a.getInputBuffer(i10);
    }

    @Override // a4.p
    public final void p(Surface surface) {
        this.f487a.setOutputSurface(surface);
    }

    @Override // a4.p
    public final ByteBuffer q(int i10) {
        return this.f487a.getOutputBuffer(i10);
    }

    @Override // a4.p
    public final void r(ArrayList arrayList) {
        this.f487a.subscribeToVendorParameters(arrayList);
    }

    @Override // a4.p
    public final void release() {
        m mVar = this.f488b;
        MediaCodec mediaCodec = this.f487a;
        try {
            int i10 = Build.VERSION.SDK_INT;
            if (i10 >= 30 && i10 < 33) {
                mediaCodec.stop();
            }
        } finally {
            if (Build.VERSION.SDK_INT >= 35 && mVar != null) {
                mVar.c(mediaCodec);
            }
            mediaCodec.release();
        }
    }

    @Override // a4.p
    public final void s(ArrayList arrayList) {
        this.f487a.unsubscribeFromVendorParameters(arrayList);
    }
}
