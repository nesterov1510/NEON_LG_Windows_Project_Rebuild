package a4;

import android.media.MediaCodec;
import com.google.android.gms.internal.measurement.ec;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.button.MaterialButtonToggleGroup;
import g0.k1;
import java.util.Comparator;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class y implements Comparator {
    public final /* synthetic */ Object X;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f564e;

    public /* synthetic */ y(int i10, Object obj) {
        this.f564e = i10;
        this.X = obj;
    }

    @Override // java.util.Comparator
    public final int compare(Object obj, Object obj2) {
        int i10;
        switch (this.f564e) {
            case 0:
                d0 d0Var = (d0) this.X;
                return d0Var.b(obj2) - d0Var.b(obj);
            case 1:
                MaterialButtonToggleGroup materialButtonToggleGroup = (MaterialButtonToggleGroup) this.X;
                MaterialButton materialButton = (MaterialButton) obj;
                MaterialButton materialButton2 = (MaterialButton) obj2;
                int iCompareTo = Boolean.valueOf(materialButton.E0).compareTo(Boolean.valueOf(materialButton2.E0));
                if (iCompareTo != 0) {
                    return iCompareTo;
                }
                int iCompareTo2 = Boolean.valueOf(materialButton.isPressed()).compareTo(Boolean.valueOf(materialButton2.isPressed()));
                return iCompareTo2 != 0 ? iCompareTo2 : Integer.compare(materialButtonToggleGroup.indexOfChild(materialButton), materialButtonToggleGroup.indexOfChild(materialButton2));
            default:
                m0.k kVar = (m0.k) obj2;
                ((ec) this.X).getClass();
                Class cls = ((m0.k) obj).f14860a.f14949j;
                int i11 = 0;
                if (cls == MediaCodec.class) {
                    i10 = 2;
                } else {
                    i10 = (cls == k1.class || cls == a1.e.class) ? 0 : 1;
                }
                Class cls2 = kVar.f14860a.f14949j;
                if (cls2 == MediaCodec.class) {
                    i11 = 2;
                } else if (cls2 != k1.class && cls2 != a1.e.class) {
                    i11 = 1;
                }
                return i10 - i11;
        }
    }
}
