package a4;

import android.media.MediaCodec;
import android.media.MediaCrypto;
import android.media.MediaFormat;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Trace;
import android.view.Surface;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import l3.l0;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class d implements p {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final MediaCodec f474a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final h f475b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final q f476c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final m f477d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f478e;
    public int f = 0;

    public d(MediaCodec mediaCodec, HandlerThread handlerThread, q qVar, m mVar) {
        this.f474a = mediaCodec;
        this.f475b = new h(handlerThread);
        this.f476c = qVar;
        this.f477d = mVar;
    }

    public static void a(d dVar, MediaFormat mediaFormat, Surface surface, MediaCrypto mediaCrypto, int i10) {
        m mVar;
        h hVar = dVar.f475b;
        MediaCodec mediaCodec = dVar.f474a;
        HandlerThread handlerThread = hVar.f494b;
        ji.k.A(hVar.f495c == null);
        handlerThread.start();
        Handler handler = new Handler(handlerThread.getLooper());
        mediaCodec.setCallback(hVar, handler);
        hVar.f495c = handler;
        Trace.beginSection("configureCodec");
        mediaCodec.configure(mediaFormat, surface, mediaCrypto, i10);
        Trace.endSection();
        dVar.f476c.start();
        Trace.beginSection("startCodec");
        mediaCodec.start();
        Trace.endSection();
        if (Build.VERSION.SDK_INT >= 35 && (mVar = dVar.f477d) != null) {
            mVar.a(mediaCodec);
        }
        dVar.f = 1;
    }

    public static String t(int i10, String str) {
        StringBuilder sb2 = new StringBuilder(str);
        if (i10 == 1) {
            sb2.append("Audio");
        } else if (i10 == 2) {
            sb2.append("Video");
        } else {
            sb2.append("Unknown(");
            sb2.append(i10);
            sb2.append(")");
        }
        return sb2.toString();
    }

    @Override // a4.p
    public final void b(Bundle bundle) {
        this.f476c.b(bundle);
    }

    @Override // a4.p
    public final void c(int i10, r3.c cVar, long j10, int i11) {
        this.f476c.c(i10, cVar, j10, i11);
    }

    @Override // a4.p
    public final void d(int i10, int i11, long j10, int i12) {
        this.f476c.d(i10, i11, j10, i12);
    }

    @Override // a4.p
    public final void e(int i10) {
        this.f474a.releaseOutputBuffer(i10, false);
    }

    @Override // a4.p
    public final boolean f(z7.b bVar) {
        h hVar = this.f475b;
        synchronized (hVar.f493a) {
            hVar.f505o = bVar;
        }
        return true;
    }

    @Override // a4.p
    public final void flush() {
        this.f476c.flush();
        this.f474a.flush();
        h hVar = this.f475b;
        synchronized (hVar.f493a) {
            hVar.f502l++;
            Handler handler = hVar.f495c;
            int i10 = l0.f14115a;
            handler.post(new a0.l0(2, hVar));
        }
        this.f474a.start();
    }

    @Override // a4.p
    public final MediaFormat g() {
        MediaFormat mediaFormat;
        h hVar = this.f475b;
        synchronized (hVar.f493a) {
            try {
                mediaFormat = hVar.h;
                if (mediaFormat == null) {
                    throw new IllegalStateException();
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
        return mediaFormat;
    }

    @Override // a4.p
    public final void h() {
        this.f474a.detachOutputSurface();
    }

    @Override // a4.p
    public final void i(int i10, long j10) {
        this.f474a.releaseOutputBuffer(i10, j10);
    }

    @Override // a4.p
    public final int j() {
        this.f476c.i();
        h hVar = this.f475b;
        synchronized (hVar.f493a) {
            try {
                hVar.b();
                int i10 = -1;
                if (hVar.f502l > 0 || hVar.f503m) {
                    return -1;
                }
                androidx.recyclerview.widget.x xVar = hVar.f496d;
                int i11 = xVar.f3154b;
                int i12 = xVar.f3155c;
                if (!(i11 == i12)) {
                    if (i11 == i12) {
                        throw new ArrayIndexOutOfBoundsException();
                    }
                    i10 = xVar.f3153a[i11];
                    xVar.f3154b = (i11 + 1) & xVar.f3156d;
                }
                return i10;
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    @Override // a4.p
    public final void k(b bVar) {
        h hVar = this.f475b;
        b bVar2 = new b(this, bVar, 0);
        synchronized (hVar.f493a) {
            hVar.b();
            bVar2.run();
        }
    }

    @Override // a4.p
    public final void l(k4.i iVar, Handler handler) {
        this.f474a.setOnFrameRenderedListener(new a(this, iVar, 0), handler);
    }

    @Override // a4.p
    public final int m(MediaCodec.BufferInfo bufferInfo) {
        this.f476c.i();
        h hVar = this.f475b;
        synchronized (hVar.f493a) {
            try {
                hVar.b();
                if (hVar.f502l > 0 || hVar.f503m) {
                    return -1;
                }
                androidx.recyclerview.widget.x xVar = hVar.f497e;
                int i10 = xVar.f3154b;
                int i11 = xVar.f3155c;
                if (i10 == i11) {
                    return -1;
                }
                if (i10 == i11) {
                    throw new ArrayIndexOutOfBoundsException();
                }
                int i12 = xVar.f3153a[i10];
                xVar.f3154b = xVar.f3156d & (i10 + 1);
                if (i12 >= 0) {
                    hVar.h.getClass();
                    MediaCodec.BufferInfo bufferInfo2 = (MediaCodec.BufferInfo) hVar.f.remove();
                    bufferInfo.set(bufferInfo2.offset, bufferInfo2.size, bufferInfo2.presentationTimeUs, bufferInfo2.flags);
                } else if (i12 == -2) {
                    hVar.h = (MediaFormat) hVar.f498g.remove();
                }
                return i12;
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    @Override // a4.p
    public final void n(int i10) {
        this.f474a.setVideoScalingMode(i10);
    }

    @Override // a4.p
    public final ByteBuffer o(int i10) {
        return this.f474a.getInputBuffer(i10);
    }

    @Override // a4.p
    public final void p(Surface surface) {
        this.f474a.setOutputSurface(surface);
    }

    @Override // a4.p
    public final ByteBuffer q(int i10) {
        return this.f474a.getOutputBuffer(i10);
    }

    @Override // a4.p
    public final void r(ArrayList arrayList) {
        this.f474a.subscribeToVendorParameters(arrayList);
    }

    @Override // a4.p
    public final void release() {
        m mVar;
        m mVar2;
        try {
            if (this.f == 1) {
                this.f476c.shutdown();
                h hVar = this.f475b;
                synchronized (hVar.f493a) {
                    hVar.f503m = true;
                    hVar.f494b.quit();
                    hVar.a();
                }
            }
            this.f = 2;
            if (this.f478e) {
                return;
            }
            try {
                int i10 = Build.VERSION.SDK_INT;
                if (i10 >= 30 && i10 < 33) {
                    this.f474a.stop();
                }
            } finally {
                if (Build.VERSION.SDK_INT >= 35 && (mVar2 = this.f477d) != null) {
                    mVar2.c(this.f474a);
                }
                this.f474a.release();
                this.f478e = true;
            }
        } catch (Throwable th2) {
            if (!this.f478e) {
                try {
                    int i11 = Build.VERSION.SDK_INT;
                    if (i11 >= 30 && i11 < 33) {
                        this.f474a.stop();
                    }
                } finally {
                    if (Build.VERSION.SDK_INT >= 35 && (mVar = this.f477d) != null) {
                        mVar.c(this.f474a);
                    }
                    this.f474a.release();
                    this.f478e = true;
                }
            }
            throw th2;
        }
    }

    @Override // a4.p
    public final void s(ArrayList arrayList) {
        this.f474a.unsubscribeFromVendorParameters(arrayList);
    }
}
