package a4;

import android.text.TextUtils;
import com.google.protobuf.m0;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class z {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f565a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final boolean f566b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final boolean f567c;

    public z(String str, boolean z5, boolean z6) {
        this.f565a = str;
        this.f566b = z5;
        this.f567c = z6;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && obj.getClass() == z.class) {
            z zVar = (z) obj;
            if (TextUtils.equals(this.f565a, zVar.f565a) && this.f566b == zVar.f566b && this.f567c == zVar.f567c) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        return ((m0.h(31, 31, this.f565a) + (this.f566b ? 1231 : 1237)) * 31) + (this.f567c ? 1231 : 1237);
    }
}
