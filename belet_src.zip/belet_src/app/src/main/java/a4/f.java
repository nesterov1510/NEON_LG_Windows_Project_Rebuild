package a4;

import android.media.MediaCodec;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f482a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f483b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final MediaCodec.CryptoInfo f484c = new MediaCodec.CryptoInfo();

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public long f485d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f486e;
}
