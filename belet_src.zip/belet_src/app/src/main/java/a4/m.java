package a4;

import android.media.LoudnessCodecController;
import android.media.MediaCodec;
import java.util.HashSet;
import java.util.Iterator;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class m {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final HashSet f512a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final l f513b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public LoudnessCodecController f514c;

    public m() {
        l lVar = l.f511e;
        this.f512a = new HashSet();
        this.f513b = lVar;
    }

    public final void a(MediaCodec mediaCodec) {
        LoudnessCodecController loudnessCodecController = this.f514c;
        if (loudnessCodecController == null || loudnessCodecController.addMediaCodec(mediaCodec)) {
            ji.k.A(this.f512a.add(mediaCodec));
        }
    }

    public final void b() {
        this.f512a.clear();
        LoudnessCodecController loudnessCodecController = this.f514c;
        if (loudnessCodecController != null) {
            loudnessCodecController.close();
        }
    }

    public final void c(MediaCodec mediaCodec) {
        LoudnessCodecController loudnessCodecController;
        if (!this.f512a.remove(mediaCodec) || (loudnessCodecController = this.f514c) == null) {
            return;
        }
        loudnessCodecController.removeMediaCodec(mediaCodec);
    }

    public final void d(int i10) {
        LoudnessCodecController loudnessCodecController = this.f514c;
        if (loudnessCodecController != null) {
            loudnessCodecController.close();
            this.f514c = null;
        }
        LoudnessCodecController loudnessCodecControllerCreate = LoudnessCodecController.create(i10, rc.d0.f17971e, new k(this));
        this.f514c = loudnessCodecControllerCreate;
        Iterator it = this.f512a.iterator();
        while (it.hasNext()) {
            if (!loudnessCodecControllerCreate.addMediaCodec((MediaCodec) it.next())) {
                it.remove();
            }
        }
    }
}
