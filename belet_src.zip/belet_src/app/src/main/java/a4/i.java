package a4;

import java.nio.ByteBuffer;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class i extends r3.g {

    /* JADX INFO: renamed from: w0, reason: collision with root package name */
    public long f506w0;

    /* JADX INFO: renamed from: x0, reason: collision with root package name */
    public int f507x0;

    /* JADX INFO: renamed from: y0, reason: collision with root package name */
    public int f508y0;

    @Override // r3.g
    public final void s() {
        super.s();
        this.f507x0 = 0;
    }

    public final boolean w(r3.g gVar) {
        ByteBuffer byteBuffer;
        ji.k.n(!gVar.f(1073741824));
        ji.k.n(!gVar.f(268435456));
        ji.k.n(!gVar.f(4));
        if (x()) {
            if (this.f507x0 >= this.f508y0) {
                return false;
            }
            ByteBuffer byteBuffer2 = gVar.f17865r0;
            if (byteBuffer2 != null && (byteBuffer = this.f17865r0) != null) {
                if (byteBuffer2.remaining() + byteBuffer.position() > 3072000) {
                    return false;
                }
            }
        }
        int i10 = this.f507x0;
        this.f507x0 = i10 + 1;
        if (i10 == 0) {
            this.f17867t0 = gVar.f17867t0;
            if (gVar.f(1)) {
                this.X = 1;
            }
        }
        ByteBuffer byteBuffer3 = gVar.f17865r0;
        if (byteBuffer3 != null) {
            u(byteBuffer3.remaining());
            this.f17865r0.put(byteBuffer3);
        }
        this.f506w0 = gVar.f17867t0;
        return true;
    }

    public final boolean x() {
        return this.f507x0 > 0;
    }
}
