package a4;

import android.media.MediaCodec;
import android.media.MediaFormat;
import android.os.Handler;
import android.os.HandlerThread;
import java.util.ArrayDeque;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class h extends MediaCodec.Callback {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final HandlerThread f494b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Handler f495c;
    public MediaFormat h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public MediaFormat f499i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public MediaCodec.CodecException f500j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public MediaCodec.CryptoException f501k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public long f502l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public boolean f503m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public IllegalStateException f504n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public z7.b f505o;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Object f493a = new Object();

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final androidx.recyclerview.widget.x f496d = new androidx.recyclerview.widget.x();

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final androidx.recyclerview.widget.x f497e = new androidx.recyclerview.widget.x();
    public final ArrayDeque f = new ArrayDeque();

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final ArrayDeque f498g = new ArrayDeque();

    public h(HandlerThread handlerThread) {
        this.f494b = handlerThread;
    }

    public final void a() {
        ArrayDeque arrayDeque = this.f498g;
        if (!arrayDeque.isEmpty()) {
            this.f499i = (MediaFormat) arrayDeque.getLast();
        }
        androidx.recyclerview.widget.x xVar = this.f496d;
        xVar.f3155c = xVar.f3154b;
        androidx.recyclerview.widget.x xVar2 = this.f497e;
        xVar2.f3155c = xVar2.f3154b;
        this.f.clear();
        arrayDeque.clear();
    }

    public final void b() {
        IllegalStateException illegalStateException = this.f504n;
        if (illegalStateException != null) {
            this.f504n = null;
            throw illegalStateException;
        }
        MediaCodec.CodecException codecException = this.f500j;
        if (codecException != null) {
            this.f500j = null;
            throw codecException;
        }
        MediaCodec.CryptoException cryptoException = this.f501k;
        if (cryptoException == null) {
            return;
        }
        this.f501k = null;
        throw cryptoException;
    }

    public final void c(IllegalStateException illegalStateException) {
        synchronized (this.f493a) {
            this.f504n = illegalStateException;
        }
    }

    @Override // android.media.MediaCodec.Callback
    public final void onCryptoError(MediaCodec mediaCodec, MediaCodec.CryptoException cryptoException) {
        synchronized (this.f493a) {
            this.f501k = cryptoException;
        }
    }

    @Override // android.media.MediaCodec.Callback
    public final void onError(MediaCodec mediaCodec, MediaCodec.CodecException codecException) {
        synchronized (this.f493a) {
            this.f500j = codecException;
        }
    }

    @Override // android.media.MediaCodec.Callback
    public final void onInputBufferAvailable(MediaCodec mediaCodec, int i10) {
        s3.b0 b0Var;
        synchronized (this.f493a) {
            this.f496d.a(i10);
            z7.b bVar = this.f505o;
            if (bVar != null && (b0Var = ((w) bVar.X).W0) != null) {
                b0Var.a();
            }
        }
    }

    @Override // android.media.MediaCodec.Callback
    public final void onOutputBufferAvailable(MediaCodec mediaCodec, int i10, MediaCodec.BufferInfo bufferInfo) {
        s3.b0 b0Var;
        synchronized (this.f493a) {
            try {
                MediaFormat mediaFormat = this.f499i;
                if (mediaFormat != null) {
                    this.f497e.a(-2);
                    this.f498g.add(mediaFormat);
                    this.f499i = null;
                }
                this.f497e.a(i10);
                this.f.add(bufferInfo);
                z7.b bVar = this.f505o;
                if (bVar != null && (b0Var = ((w) bVar.X).W0) != null) {
                    b0Var.a();
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    @Override // android.media.MediaCodec.Callback
    public final void onOutputFormatChanged(MediaCodec mediaCodec, MediaFormat mediaFormat) {
        synchronized (this.f493a) {
            this.f497e.a(-2);
            this.f498g.add(mediaFormat);
            this.f499i = null;
        }
    }
}
