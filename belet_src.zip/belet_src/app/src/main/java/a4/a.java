package a4;

import android.media.MediaCodec;
import android.os.Build;
import android.os.Handler;
import android.os.Message;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class a implements MediaCodec.OnFrameRenderedListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f469a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ k4.i f470b;

    public /* synthetic */ a(p pVar, k4.i iVar, int i10) {
        this.f469a = i10;
        this.f470b = iVar;
    }

    @Override // android.media.MediaCodec.OnFrameRenderedListener
    public final void onFrameRendered(MediaCodec mediaCodec, long j10, long j11) {
        switch (this.f469a) {
            case 0:
                k4.i iVar = this.f470b;
                Handler handler = iVar.f13500e;
                if (Build.VERSION.SDK_INT >= 30) {
                    iVar.a(j10);
                } else {
                    handler.sendMessageAtFrontOfQueue(Message.obtain(handler, 0, (int) (j10 >> 32), (int) j10));
                }
                break;
            default:
                k4.i iVar2 = this.f470b;
                Handler handler2 = iVar2.f13500e;
                if (Build.VERSION.SDK_INT >= 30) {
                    iVar2.a(j10);
                } else {
                    handler2.sendMessageAtFrontOfQueue(Message.obtain(handler2, 0, (int) (j10 >> 32), (int) j10));
                }
                break;
        }
    }
}
