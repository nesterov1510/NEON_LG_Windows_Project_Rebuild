package a4;

import android.accounts.Account;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.Shader;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;
import android.util.SparseArray;
import android.util.SparseBooleanArray;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.widget.b3;
import androidx.appcompat.widget.t2;
import androidx.media3.session.h5;
import androidx.media3.session.l5;
import androidx.media3.session.legacy.r0;
import androidx.media3.session.p5;
import androidx.media3.session.q5;
import androidx.media3.session.x2;
import com.google.android.gms.internal.measurement.f6;
import com.google.android.gms.internal.measurement.ld;
import com.google.android.gms.internal.measurement.oe;
import com.google.android.gms.internal.measurement.re;
import com.google.android.gms.internal.measurement.rf;
import com.google.android.gms.internal.measurement.rg;
import com.google.android.gms.internal.measurement.sf;
import com.google.android.gms.internal.measurement.wg;
import com.google.android.gms.internal.measurement.ze;
import com.google.android.material.card.MaterialCardView;
import com.google.common.util.concurrent.ListenableFuture;
import e4.g0;
import i3.a1;
import i3.a2;
import i3.w0;
import i3.x1;
import j$.util.DesugarCollections;
import j$.util.Objects;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;
import java.util.regex.Pattern;
import l3.l0;
import lc.l2;
import lc.q0;
import lc.q2;
import lc.u0;
import lc.x0;
import okhttp3.internal.url._UrlKt;
import rc.b1;
import rc.c1;
import rc.m0;
import rc.n0;
import rc.z0;
import tm.belet.films.R;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class n {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public Object f515a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public Object f516b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Object f517c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Object f518d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public Object f519e;
    public Object f;

    public /* synthetic */ n(ViewGroup viewGroup, View view, View view2, View view3, View view4, Object obj, View view5) {
        this.f515a = view;
        this.f516b = view2;
        this.f517c = view3;
        this.f518d = view4;
        this.f519e = obj;
        this.f = view5;
    }

    public static p3.s a(DataInputStream dataInputStream) throws IOException {
        int i10 = dataInputStream.readInt();
        HashMap map = new HashMap();
        for (int i11 = 0; i11 < i10; i11++) {
            String utf = dataInputStream.readUTF();
            int i12 = dataInputStream.readInt();
            if (i12 < 0) {
                throw new IOException(kotlin.jvm.internal.p.z(i12, "Invalid value size: "));
            }
            int iMin = Math.min(i12, 10485760);
            byte[] bArrCopyOf = l0.f14117c;
            int i13 = 0;
            while (i13 != i12) {
                int i14 = i13 + iMin;
                bArrCopyOf = Arrays.copyOf(bArrCopyOf, i14);
                dataInputStream.readFully(bArrCopyOf, i13, iMin);
                iMin = Math.min(i12 - i14, 10485760);
                i13 = i14;
            }
            map.put(utf, bArrCopyOf);
        }
        return new p3.s(map);
    }

    public static void b(p3.s sVar, DataOutputStream dataOutputStream) throws IOException {
        Set<Map.Entry> setEntrySet = sVar.f16814b.entrySet();
        dataOutputStream.writeInt(setEntrySet.size());
        for (Map.Entry entry : setEntrySet) {
            dataOutputStream.writeUTF((String) entry.getKey());
            byte[] bArr = (byte[]) entry.getValue();
            dataOutputStream.writeInt(bArr.length);
            dataOutputStream.write(bArr);
        }
    }

    public static final void c(n nVar, Throwable th2) {
        ri.i iVar = (ri.i) nVar.f;
        kotlinx.coroutines.channels.i iVar2 = (kotlinx.coroutines.channels.i) nVar.f519e;
        if (iVar2.close(th2)) {
            for (Object objMo14tryReceivePtdJZtk = iVar2.mo14tryReceivePtdJZtk(); kotlinx.coroutines.channels.n.m37isSuccessimpl(objMo14tryReceivePtdJZtk); objMo14tryReceivePtdJZtk = iVar2.mo14tryReceivePtdJZtk()) {
                iVar.addLast(kotlinx.coroutines.channels.n.m33getOrThrowimpl(objMo14tryReceivePtdJZtk));
            }
            if (iVar.isEmpty()) {
                return;
            }
            ((ej.l) nVar.f516b).invoke(ri.m.B0(iVar));
            iVar.clear();
        }
    }

    public static boolean e(int[] iArr, int i10) {
        for (int i11 : iArr) {
            if (i11 == i10) {
                return true;
            }
        }
        return false;
    }

    public static n f(View view) {
        int i10 = R.id.back_btn;
        MaterialCardView materialCardView = (MaterialCardView) fk.j.l(view, R.id.back_btn);
        if (materialCardView != null) {
            LinearLayout linearLayout = (LinearLayout) view;
            i10 = R.id.second_btn;
            MaterialCardView materialCardView2 = (MaterialCardView) fk.j.l(view, R.id.second_btn);
            if (materialCardView2 != null) {
                i10 = R.id.second_btn_icon;
                ImageView imageView = (ImageView) fk.j.l(view, R.id.second_btn_icon);
                if (imageView != null) {
                    i10 = R.id.title;
                    TextView textView = (TextView) fk.j.l(view, R.id.title);
                    if (textView != null) {
                        return new n(linearLayout, materialCardView, linearLayout, materialCardView2, imageView, textView);
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    public static ColorStateList g(Context context, int i10) {
        int iC = b3.c(context, R.attr.colorControlHighlight);
        return new ColorStateList(new int[][]{b3.f1270b, b3.f1272d, b3.f1271c, b3.f}, new int[]{b3.b(context, R.attr.colorButtonNormal), a2.b.c(iC, i10), a2.b.c(iC, i10), i10});
    }

    public static g0 i(a1 a1Var, u0 u0Var, g0 g0Var, x1 x1Var) {
        a2 a2VarG0 = a1Var.G0();
        int iY = a1Var.y();
        Object objL = a2VarG0.p() ? null : a2VarG0.l(iY);
        int iB = (a1Var.l() || a2VarG0.p()) ? -1 : a2VarG0.f(iY, x1Var, false).b(l0.W(a1Var.W0()) - x1Var.f11119e);
        for (int i10 = 0; i10 < u0Var.size(); i10++) {
            g0 g0Var2 = (g0) u0Var.get(i10);
            if (o(g0Var2, objL, a1Var.l(), a1Var.w0(), a1Var.M(), iB)) {
                return g0Var2;
            }
        }
        if (u0Var.isEmpty() && g0Var != null && o(g0Var, objL, a1Var.l(), a1Var.w0(), a1Var.M(), iB)) {
            return g0Var;
        }
        return null;
    }

    public static LayerDrawable l(t2 t2Var, Context context, int i10) {
        BitmapDrawable bitmapDrawable;
        BitmapDrawable bitmapDrawable2;
        BitmapDrawable bitmapDrawable3;
        int dimensionPixelSize = context.getResources().getDimensionPixelSize(i10);
        Drawable drawableF = t2Var.f(context, R.drawable.abc_star_black_48dp);
        Drawable drawableF2 = t2Var.f(context, R.drawable.abc_star_half_black_48dp);
        if ((drawableF instanceof BitmapDrawable) && drawableF.getIntrinsicWidth() == dimensionPixelSize && drawableF.getIntrinsicHeight() == dimensionPixelSize) {
            bitmapDrawable = (BitmapDrawable) drawableF;
            bitmapDrawable2 = new BitmapDrawable(bitmapDrawable.getBitmap());
        } else {
            Bitmap bitmapCreateBitmap = Bitmap.createBitmap(dimensionPixelSize, dimensionPixelSize, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmapCreateBitmap);
            drawableF.setBounds(0, 0, dimensionPixelSize, dimensionPixelSize);
            drawableF.draw(canvas);
            bitmapDrawable = new BitmapDrawable(bitmapCreateBitmap);
            bitmapDrawable2 = new BitmapDrawable(bitmapCreateBitmap);
        }
        bitmapDrawable2.setTileModeX(Shader.TileMode.REPEAT);
        if ((drawableF2 instanceof BitmapDrawable) && drawableF2.getIntrinsicWidth() == dimensionPixelSize && drawableF2.getIntrinsicHeight() == dimensionPixelSize) {
            bitmapDrawable3 = (BitmapDrawable) drawableF2;
        } else {
            Bitmap bitmapCreateBitmap2 = Bitmap.createBitmap(dimensionPixelSize, dimensionPixelSize, Bitmap.Config.ARGB_8888);
            Canvas canvas2 = new Canvas(bitmapCreateBitmap2);
            drawableF2.setBounds(0, 0, dimensionPixelSize, dimensionPixelSize);
            drawableF2.draw(canvas2);
            bitmapDrawable3 = new BitmapDrawable(bitmapCreateBitmap2);
        }
        LayerDrawable layerDrawable = new LayerDrawable(new Drawable[]{bitmapDrawable, bitmapDrawable3, bitmapDrawable2});
        layerDrawable.setId(0, android.R.id.background);
        layerDrawable.setId(1, android.R.id.secondaryProgress);
        layerDrawable.setId(2, android.R.id.progress);
        return layerDrawable;
    }

    public static boolean o(g0 g0Var, Object obj, boolean z5, int i10, int i11, int i12) {
        Object obj2 = g0Var.f7379a;
        int i13 = g0Var.f7380b;
        if (!obj2.equals(obj)) {
            return false;
        }
        if (z5 && i13 == i10 && g0Var.f7381c == i11) {
            return true;
        }
        return !z5 && i13 == -1 && g0Var.f7383e == i12;
    }

    public static void r(Drawable drawable, int i10, PorterDuff.Mode mode) {
        Drawable drawableMutate = drawable.mutate();
        if (mode == null) {
            mode = androidx.appcompat.widget.y.f1489b;
        }
        drawableMutate.setColorFilter(androidx.appcompat.widget.y.c(i10, mode));
    }

    public void d(androidx.appcompat.widget.c0 c0Var, g0 g0Var, a2 a2Var) {
        if (g0Var == null) {
            return;
        }
        if (a2Var.b(g0Var.f7379a) != -1) {
            c0Var.u(g0Var, a2Var);
            return;
        }
        a2 a2Var2 = (a2) ((q2) this.f517c).get(g0Var);
        if (a2Var2 != null) {
            c0Var.u(g0Var, a2Var2);
        }
    }

    public gb.p h(gb.p pVar) {
        return pVar.k(new d6.c(0), new ge.i(2, this));
    }

    public p3.o j(String str) {
        return (p3.o) ((HashMap) this.f515a).get(str);
    }

    public p3.o k(String str) {
        HashMap map = (HashMap) this.f515a;
        p3.o oVar = (p3.o) map.get(str);
        if (oVar != null) {
            return oVar;
        }
        SparseArray sparseArray = (SparseArray) this.f516b;
        int size = sparseArray.size();
        int i10 = 0;
        int iKeyAt = size == 0 ? 0 : sparseArray.keyAt(size - 1) + 1;
        if (iKeyAt < 0) {
            while (i10 < size && i10 == sparseArray.keyAt(i10)) {
                i10++;
            }
            iKeyAt = i10;
        }
        p3.o oVar2 = new p3.o(iKeyAt, str, p3.s.f16812c);
        map.put(str, oVar2);
        sparseArray.put(iKeyAt, str);
        ((SparseBooleanArray) this.f518d).put(iKeyAt, true);
        ((p3.q) this.f519e).h(oVar2);
        return oVar2;
    }

    public ColorStateList m(Context context, int i10) {
        if (i10 == R.drawable.abc_edit_text_material) {
            return ji.k.J(context, R.color.abc_tint_edittext);
        }
        if (i10 == 2131230835) {
            return ji.k.J(context, R.color.abc_tint_switch_track);
        }
        if (i10 != R.drawable.abc_switch_thumb_material) {
            if (i10 == R.drawable.abc_btn_default_mtrl_shape) {
                return g(context, b3.c(context, R.attr.colorButtonNormal));
            }
            if (i10 == R.drawable.abc_btn_borderless_material) {
                return g(context, 0);
            }
            if (i10 == R.drawable.abc_btn_colored_material) {
                return g(context, b3.c(context, R.attr.colorAccent));
            }
            if (i10 == 2131230830 || i10 == R.drawable.abc_spinner_textfield_background_material) {
                return ji.k.J(context, R.color.abc_tint_spinner);
            }
            if (e((int[]) this.f516b, i10)) {
                return b3.d(context, R.attr.colorControlNormal);
            }
            if (e((int[]) this.f519e, i10)) {
                return ji.k.J(context, R.color.abc_tint_default);
            }
            if (e((int[]) this.f, i10)) {
                return ji.k.J(context, R.color.abc_tint_btn_checkable);
            }
            if (i10 == R.drawable.abc_seekbar_thumb_material) {
                return ji.k.J(context, R.color.abc_tint_seek_thumb);
            }
            return null;
        }
        int[][] iArr = new int[3][];
        int[] iArr2 = new int[3];
        ColorStateList colorStateListD = b3.d(context, R.attr.colorSwitchThumbNormal);
        if (colorStateListD == null || !colorStateListD.isStateful()) {
            iArr[0] = b3.f1270b;
            iArr2[0] = b3.b(context, R.attr.colorSwitchThumbNormal);
            iArr[1] = b3.f1273e;
            iArr2[1] = b3.c(context, R.attr.colorControlActivated);
            iArr[2] = b3.f;
            iArr2[2] = b3.c(context, R.attr.colorSwitchThumbNormal);
        } else {
            int[] iArr3 = b3.f1270b;
            iArr[0] = iArr3;
            iArr2[0] = colorStateListD.getColorForState(iArr3, 0);
            iArr[1] = b3.f1273e;
            iArr2[1] = b3.c(context, R.attr.colorControlActivated);
            iArr[2] = b3.f;
            iArr2[2] = colorStateListD.getDefaultColor();
        }
        return new ColorStateList(iArr, iArr2);
    }

    public void n(long j10) {
        p3.q qVar;
        SparseArray sparseArray = (SparseArray) this.f516b;
        HashMap map = (HashMap) this.f515a;
        p3.q qVar2 = (p3.q) this.f519e;
        qVar2.e(j10);
        p3.q qVar3 = (p3.q) this.f;
        if (qVar3 != null) {
            qVar3.e(j10);
        }
        if (qVar2.c() || (qVar = (p3.q) this.f) == null || !qVar.c()) {
            qVar2.f(map, sparseArray);
        } else {
            ((p3.q) this.f).f(map, sparseArray);
            qVar2.a(map);
        }
        p3.q qVar4 = (p3.q) this.f;
        if (qVar4 != null) {
            qVar4.g();
            this.f = null;
        }
    }

    public void p(String str) {
        SparseArray sparseArray = (SparseArray) this.f516b;
        SparseBooleanArray sparseBooleanArray = (SparseBooleanArray) this.f518d;
        HashMap map = (HashMap) this.f515a;
        p3.o oVar = (p3.o) map.get(str);
        if (oVar != null && oVar.f16804c.isEmpty() && oVar.f16805d.isEmpty()) {
            map.remove(str);
            int i10 = oVar.f16802a;
            boolean z5 = sparseBooleanArray.get(i10);
            ((p3.q) this.f519e).b(oVar, z5);
            if (z5) {
                sparseArray.remove(i10);
                sparseBooleanArray.delete(i10);
            } else {
                sparseArray.put(i10, null);
                ((SparseBooleanArray) this.f517c).put(i10, true);
            }
        }
    }

    public void q(String str, String str2, Bundle bundle) {
        int i10;
        String strEncodeToString;
        int iA;
        PackageInfo packageInfoD;
        bundle.putString("scope", str2);
        bundle.putString("sender", str);
        bundle.putString("subtype", str);
        tc.f fVar = (tc.f) this.f515a;
        fVar.a();
        bundle.putString("gmp_app_id", fVar.f19187c.f19196b);
        ge.o oVar = (ge.o) this.f516b;
        synchronized (oVar) {
            try {
                if (oVar.f8928a == 0 && (packageInfoD = oVar.d("com.google.android.gms")) != null) {
                    oVar.f8928a = packageInfoD.versionCode;
                }
                i10 = oVar.f8928a;
            } catch (Throwable th2) {
                throw th2;
            }
        }
        bundle.putString("gmsv", Integer.toString(i10));
        bundle.putString("osv", Integer.toString(Build.VERSION.SDK_INT));
        bundle.putString("app_ver", ((ge.o) this.f516b).a());
        bundle.putString("app_ver_name", ((ge.o) this.f516b).b());
        tc.f fVar2 = (tc.f) this.f515a;
        fVar2.a();
        try {
            strEncodeToString = Base64.encodeToString(MessageDigest.getInstance("SHA-1").digest(fVar2.f19186b.getBytes()), 11);
        } catch (NoSuchAlgorithmException unused) {
            strEncodeToString = "[HASH-ERROR]";
        }
        bundle.putString("firebase-app-name-hash", strEncodeToString);
        try {
            String str3 = ((be.a) fk.j.b(((be.c) ((be.d) this.f)).e())).f3489a;
            if (TextUtils.isEmpty(str3)) {
                Log.w("FirebaseMessaging", "FIS auth token is empty");
            } else {
                bundle.putString("Goog-Firebase-Installations-Auth", str3);
            }
        } catch (InterruptedException e3) {
            e = e3;
            Log.e("FirebaseMessaging", "Failed to get FIS auth token", e);
        } catch (ExecutionException e10) {
            e = e10;
            Log.e("FirebaseMessaging", "Failed to get FIS auth token", e);
        }
        bundle.putString("appid", (String) fk.j.b(((be.c) ((be.d) this.f)).d()));
        bundle.putString("cliv", "fcm-25.0.2");
        yd.f fVar3 = (yd.f) ((ae.b) this.f519e).get();
        ve.b bVar = (ve.b) ((ae.b) this.f518d).get();
        if (fVar3 == null || bVar == null || (iA = ((yd.c) fVar3).a()) == 1) {
            return;
        }
        bundle.putString("Firebase-Client-Log-Type", Integer.toString(g0.t.c(iA)));
        bundle.putString("Firebase-Client", bVar.a());
    }

    public gb.p s(String str, String str2, Bundle bundle) {
        int i10;
        try {
            q(str, str2, bundle);
            ba.a aVar = (ba.a) this.f517c;
            ba.f fVar = ba.f.Y;
            ba.o oVar = aVar.f3435c;
            if (oVar.h() < 12000000) {
                return oVar.i() != 0 ? aVar.a(bundle).e(fVar, new r0(aVar, bundle, 4)) : fk.j.n(new IOException("MISSING_INSTANCEID_SERVICE"));
            }
            ba.n nVarE = ba.n.e(aVar.f3434b);
            synchronized (nVarE) {
                i10 = nVarE.X;
                nVarE.X = i10 + 1;
            }
            return nVarE.f(new ba.l(i10, 1, bundle, 1)).k(fVar, ba.c.X);
        } catch (InterruptedException | ExecutionException e3) {
            return fk.j.n(e3);
        }
    }

    public void t() {
        ((p3.q) this.f519e).d((HashMap) this.f515a);
        SparseBooleanArray sparseBooleanArray = (SparseBooleanArray) this.f517c;
        int size = sparseBooleanArray.size();
        for (int i10 = 0; i10 < size; i10++) {
            ((SparseArray) this.f516b).remove(sparseBooleanArray.keyAt(i10));
        }
        sparseBooleanArray.clear();
        ((SparseBooleanArray) this.f518d).clear();
    }

    public void u(a2 a2Var) {
        androidx.appcompat.widget.c0 c0VarA = x0.a();
        if (((u0) this.f516b).isEmpty()) {
            d(c0VarA, (g0) this.f519e, a2Var);
            if (!Objects.equals((g0) this.f, (g0) this.f519e)) {
                d(c0VarA, (g0) this.f, a2Var);
            }
            if (!Objects.equals((g0) this.f518d, (g0) this.f519e) && !Objects.equals((g0) this.f518d, (g0) this.f)) {
                d(c0VarA, (g0) this.f518d, a2Var);
            }
        } else {
            for (int i10 = 0; i10 < ((u0) this.f516b).size(); i10++) {
                d(c0VarA, (g0) ((u0) this.f516b).get(i10), a2Var);
            }
            if (!((u0) this.f516b).contains((g0) this.f518d)) {
                d(c0VarA, (g0) this.f518d, a2Var);
            }
        }
        this.f517c = c0VarA.e(true);
    }

    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    public rc.r v() {
        AtomicLong atomicLong;
        long j10;
        final int i10;
        ListenableFuture listenableFutureB;
        rc.d0 d0Var = rc.d0.f17971e;
        rc.a1 a1Var = (rc.a1) this.f;
        if (a1Var.isDone()) {
            return a1Var;
        }
        do {
            atomicLong = (AtomicLong) this.f516b;
            j10 = atomicLong.get();
            i10 = (int) (j10 >>> 32);
        } while (!atomicLong.compareAndSet(j10, (((long) (((int) j10) + 1)) & 4294967295L) | (((long) i10) << 32)));
        AtomicReference atomicReference = (AtomicReference) this.f518d;
        rc.a1 a1Var2 = new rc.a1();
        ListenableFuture listenableFuture = (ListenableFuture) atomicReference.getAndSet(a1Var2);
        if (listenableFuture == null) {
            f6 f6VarA = rg.a(new c0(i10, 5, this));
            c1 c1Var = new c1();
            c1Var.f17966v0 = new b1(c1Var, f6VarA);
            d0Var.execute(c1Var);
            listenableFutureB = c1Var;
        } else {
            listenableFutureB = m0.b(listenableFuture, Throwable.class, rg.b(new rc.z() { // from class: com.google.android.gms.internal.measurement.qf
                @Override // rc.z
                public final /* synthetic */ ListenableFuture apply(Object obj) {
                    return this.f5390a.z(i10);
                }
            }), (z0) this.f519e);
        }
        a1Var2.o(listenableFutureB);
        rf rfVar = new rf(this, i10);
        a1Var2.a(new androidx.media3.session.legacy.n(11, this, a1Var2, rfVar, false), d0Var);
        return rfVar;
    }

    public void w(String str) {
        wg.e(re.f5407a.matcher(str).matches(), "Module must match [a-z]+(_[a-z]+)*: %s", str);
        wg.e(!re.f5409c.contains(str), "Module name is reserved and cannot be used: %s", str);
        this.f517c = str;
    }

    public void x(String str) {
        if (str.startsWith("/")) {
            str = str.substring(1);
        }
        Pattern pattern = re.f5407a;
        this.f519e = str;
    }

    public Uri y() {
        String strO;
        String str = (String) this.f516b;
        String str2 = (String) this.f517c;
        Account account = oe.f5332a;
        Account account2 = (Account) this.f518d;
        wg.e(account2.type.indexOf(58) == -1, "Account type contains ':'.", new Object[0]);
        wg.e(account2.type.indexOf(47) == -1, "Account type contains '/'.", new Object[0]);
        wg.e(account2.name.indexOf(47) == -1, "Account name contains '/'.", new Object[0]);
        if (oe.f5332a.equals(account2)) {
            strO = "shared";
        } else {
            String str3 = account2.type;
            String str4 = account2.name;
            strO = p0.e.o(new StringBuilder(String.valueOf(str3).length() + 1 + String.valueOf(str4).length()), str3, ":", str4);
        }
        String str5 = (String) this.f519e;
        StringBuilder sb2 = new StringBuilder(strO.length() + str2.length() + str.length() + 2 + 1 + 1 + String.valueOf(str5).length());
        kotlin.jvm.internal.p.O(sb2, "/", str, "/", str2);
        String strL = com.google.protobuf.m0.l(sb2, "/", strO, "/", str5);
        l2 l2VarG = ((q0) this.f).g();
        Pattern pattern = ze.f5606a;
        return new Uri.Builder().scheme("android").authority((String) this.f515a).path(strL).encodedFragment(l2VarG.isEmpty() ? null : "transform=".concat(String.valueOf(new x2("+").c(l2VarG)))).build();
    }

    public rc.r z(int i10) {
        rc.d0 d0Var;
        AtomicLong atomicLong = (AtomicLong) this.f516b;
        if (((int) (atomicLong.get() >>> 32)) > i10) {
            n0 n0Var = n0.u0;
            return n0Var != null ? n0Var : new n0();
        }
        sf sfVar = new sf(i10);
        while (true) {
            AtomicReference atomicReference = (AtomicReference) this.f517c;
            sf sfVar2 = (sf) atomicReference.get();
            if (sfVar2 != null && sfVar2.u0 > i10) {
                n0 n0Var2 = n0.u0;
                return n0Var2 != null ? n0Var2 : new n0();
            }
            do {
                if (atomicReference.compareAndSet(sfVar2, sfVar)) {
                    if (((int) (atomicLong.get() >>> 32)) > i10) {
                        sfVar.cancel(true);
                        while (!atomicReference.compareAndSet(sfVar, null) && atomicReference.get() == sfVar) {
                        }
                        return sfVar;
                    }
                    ld ldVar = (ld) this.f515a;
                    rc.y yVar = (rc.y) ldVar.X;
                    if (yVar == null || (d0Var = (rc.d0) ldVar.Y) == null) {
                        sfVar.o((rc.a1) this.f);
                        return sfVar;
                    }
                    f6 f6VarA = rg.a(yVar);
                    c1 c1Var = new c1();
                    c1Var.f17966v0 = new b1(c1Var, f6VarA);
                    d0Var.execute(c1Var);
                    sfVar.o(c1Var);
                    return sfVar;
                }
            } while (atomicReference.get() == sfVar2);
        }
    }

    public /* synthetic */ n(Object obj, Object obj2, Object obj3, Object obj4, Object obj5, Object obj6) {
        this.f515a = obj;
        this.f516b = obj2;
        this.f517c = obj3;
        this.f518d = obj4;
        this.f519e = obj5;
        this.f = obj6;
    }

    public /* synthetic */ n(Context context) {
        this.f516b = "files";
        this.f517c = "common";
        this.f518d = re.f5408b;
        this.f519e = _UrlKt.FRAGMENT_ENCODE_SET;
        this.f = u0.i();
        wg.e(context != null, "Context cannot be null", new Object[0]);
        this.f515a = context.getPackageName();
    }

    public n(rc.y yVar) {
        long j10 = Integer.MIN_VALUE;
        this.f516b = new AtomicLong((j10 & 4294967295L) | (j10 << 32));
        this.f517c = new AtomicReference(null);
        this.f518d = new AtomicReference(null);
        rc.d0 d0Var = rc.d0.f17971e;
        this.f519e = new z0(d0Var);
        rc.a1 a1Var = new rc.a1();
        this.f = a1Var;
        ld ldVar = new ld();
        ldVar.X = yVar;
        ldVar.Y = d0Var;
        this.f515a = ldVar;
        a1Var.a(ldVar, d0Var);
    }

    public n(Set set, String str, String str2) {
        Set setUnmodifiableSet = set == null ? Collections.EMPTY_SET : DesugarCollections.unmodifiableSet(set);
        this.f515a = setUnmodifiableSet;
        Map map = Collections.EMPTY_MAP;
        this.f517c = str;
        this.f518d = str2;
        this.f519e = db.a.f6752e;
        HashSet hashSet = new HashSet(setUnmodifiableSet);
        Iterator it = map.values().iterator();
        if (!it.hasNext()) {
            this.f516b = DesugarCollections.unmodifiableSet(hashSet);
            return;
        }
        throw a0.f.m(it);
    }

    public n(int i10) {
        switch (i10) {
            case 2:
                this.f515a = h5.H.l(l5.f2397g);
                this.f516b = p5.f2591b;
                this.f517c = w0.f11103b;
                this.f518d = l2.f14447r0;
                this.f519e = Bundle.EMPTY;
                this.f = null;
                break;
            default:
                this.f515a = new int[]{2131230845, 2131230843, 2131230769};
                this.f516b = new int[]{2131230793, R.drawable.abc_seekbar_tick_mark_material, R.drawable.abc_ic_menu_share_mtrl_alpha, R.drawable.abc_ic_menu_copy_mtrl_am_alpha, R.drawable.abc_ic_menu_cut_mtrl_alpha, R.drawable.abc_ic_menu_selectall_mtrl_alpha, R.drawable.abc_ic_menu_paste_mtrl_am_alpha};
                this.f517c = new int[]{2131230842, 2131230844, 2131230786, R.drawable.abc_text_cursor_material, 2131230839, 2131230840, 2131230841};
                this.f518d = new int[]{2131230818, R.drawable.abc_cab_background_internal_bg, 2131230817};
                this.f519e = new int[]{R.drawable.abc_tab_indicator_material, R.drawable.abc_textfield_search_material};
                this.f = new int[]{R.drawable.abc_btn_check_material, R.drawable.abc_btn_radio_material, R.drawable.abc_btn_check_material_anim, R.drawable.abc_btn_radio_material_anim};
                break;
        }
    }

    public n(h5 h5Var, p5 p5Var, w0 w0Var, u0 u0Var, Bundle bundle, q5 q5Var) {
        this.f515a = h5Var;
        this.f516b = p5Var;
        this.f517c = w0Var;
        this.f518d = u0Var;
        this.f519e = bundle == null ? Bundle.EMPTY : bundle;
        this.f = q5Var;
    }
}
