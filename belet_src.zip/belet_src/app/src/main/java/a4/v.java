package a4;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class v {

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static final v f532g = new v(-9223372036854775807L, -9223372036854775807L, -9223372036854775807L);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final long f533a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final long f534b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final long f535c;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f537e;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final com.google.android.material.textfield.o f536d = new com.google.android.material.textfield.o();
    public long f = -9223372036854775807L;

    public v(long j10, long j11, long j12) {
        this.f533a = j10;
        this.f534b = j11;
        this.f535c = j12;
    }
}
