package a4;

import android.content.Context;
import android.media.MediaCodec;
import android.media.MediaCrypto;
import android.media.MediaCryptoException;
import android.media.MediaFormat;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.os.Trace;
import com.google.protobuf.m0;
import e4.h1;
import j$.util.Objects;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import l3.l0;
import lc.c3;
import lc.f1;
import lc.s2;
import u3.p0;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public abstract class w extends s3.a {
    public static final byte[] W1 = {0, 0, 1, 103, 66, -64, 11, -38, 37, -112, 0, 0, 1, 104, -50, 15, 19, 32, 0, 0, 1, 101, -120, -124, 13, -50, 113, 24, -96, 0, 47, -65, 28, 49, -61, 39, 93, 120};
    public int A1;
    public int B1;
    public int C1;
    public boolean D1;
    public boolean E1;
    public final Context F0;
    public boolean F1;
    public final o G0;
    public long G1;
    public final l H0;
    public boolean H1;
    public final boolean I0;
    public boolean I1;
    public final float J0;
    public boolean J1;
    public final r3.g K0;
    public boolean K1;
    public final r3.g L0;
    public s3.m L1;
    public final r3.g M0;
    public s3.c M1;
    public final i N0;
    public v N1;
    public final MediaCodec.BufferInfo O0;
    public long O1;
    public final ArrayDeque P0;
    public boolean P1;
    public final p0 Q0;
    public boolean Q1;
    public final AtomicInteger R0;
    public boolean R1;
    public androidx.media3.common.b S0;
    public long S1;
    public androidx.media3.common.b T0;
    public s3.b T1;
    public v3.g U0;
    public s3.b U1;
    public v3.g V0;
    public f1 V1;
    public s3.b0 W0;
    public MediaCrypto X0;
    public final long Y0;
    public float Z0;

    /* JADX INFO: renamed from: a1, reason: collision with root package name */
    public float f538a1;

    /* JADX INFO: renamed from: b1, reason: collision with root package name */
    public p f539b1;

    /* JADX INFO: renamed from: c1, reason: collision with root package name */
    public androidx.media3.common.b f540c1;

    /* JADX INFO: renamed from: d1, reason: collision with root package name */
    public MediaFormat f541d1;

    /* JADX INFO: renamed from: e1, reason: collision with root package name */
    public boolean f542e1;

    /* JADX INFO: renamed from: f1, reason: collision with root package name */
    public float f543f1;

    /* JADX INFO: renamed from: g1, reason: collision with root package name */
    public ArrayDeque f544g1;

    /* JADX INFO: renamed from: h1, reason: collision with root package name */
    public u f545h1;

    /* JADX INFO: renamed from: i1, reason: collision with root package name */
    public s f546i1;

    /* JADX INFO: renamed from: j1, reason: collision with root package name */
    public int f547j1;

    /* JADX INFO: renamed from: k1, reason: collision with root package name */
    public boolean f548k1;

    /* JADX INFO: renamed from: l1, reason: collision with root package name */
    public boolean f549l1;

    /* JADX INFO: renamed from: m1, reason: collision with root package name */
    public boolean f550m1;

    /* JADX INFO: renamed from: n1, reason: collision with root package name */
    public boolean f551n1;

    /* JADX INFO: renamed from: o1, reason: collision with root package name */
    public boolean f552o1;

    /* JADX INFO: renamed from: p1, reason: collision with root package name */
    public long f553p1;

    /* JADX INFO: renamed from: q1, reason: collision with root package name */
    public boolean f554q1;

    /* JADX INFO: renamed from: r1, reason: collision with root package name */
    public long f555r1;

    /* JADX INFO: renamed from: s1, reason: collision with root package name */
    public int f556s1;

    /* JADX INFO: renamed from: t1, reason: collision with root package name */
    public int f557t1;

    /* JADX INFO: renamed from: u1, reason: collision with root package name */
    public ByteBuffer f558u1;

    /* JADX INFO: renamed from: v1, reason: collision with root package name */
    public boolean f559v1;

    /* JADX INFO: renamed from: w1, reason: collision with root package name */
    public boolean f560w1;

    /* JADX INFO: renamed from: x1, reason: collision with root package name */
    public boolean f561x1;
    public boolean y1;

    /* JADX INFO: renamed from: z1, reason: collision with root package name */
    public boolean f562z1;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public w(Context context, int i10, o oVar, boolean z5, float f) {
        super(i10);
        l lVar = l.X;
        this.F0 = context.getApplicationContext();
        this.G0 = oVar;
        this.H0 = lVar;
        this.I0 = z5;
        this.J0 = f;
        this.R0 = new AtomicInteger();
        this.K0 = new r3.g(0);
        this.L0 = new r3.g(0);
        this.M0 = new r3.g(2);
        i iVar = new i(2);
        iVar.f508y0 = 32;
        this.N0 = iVar;
        this.O0 = new MediaCodec.BufferInfo();
        this.Z0 = 1.0f;
        this.f538a1 = 1.0f;
        this.Y0 = -9223372036854775807L;
        this.P0 = new ArrayDeque();
        this.N1 = v.f532g;
        iVar.u(0);
        iVar.f17865r0.order(ByteOrder.nativeOrder());
        p0 p0Var = new p0();
        p0Var.f20378a = j3.m.f12771a;
        p0Var.f20380c = 0;
        p0Var.f20379b = 2;
        this.Q0 = p0Var;
        this.f543f1 = -1.0f;
        this.f547j1 = 0;
        this.A1 = 0;
        this.f556s1 = -1;
        this.f557t1 = -1;
        this.f555r1 = -9223372036854775807L;
        this.G1 = -9223372036854775807L;
        this.O1 = -9223372036854775807L;
        this.f553p1 = -9223372036854775807L;
        this.B1 = 0;
        this.C1 = 0;
        this.M1 = new s3.c();
        this.R1 = false;
        this.S1 = 0L;
        int i11 = f1.Y;
        this.V1 = s2.f14475w0;
        s3.b bVar = s3.b.f18174b;
        this.T1 = bVar;
        this.U1 = bVar;
    }

    @Override // s3.a
    public void A(float f, float f10) throws s3.m {
        this.Z0 = f;
        this.f538a1 = f10;
        z0(this.f540c1);
    }

    public final void A0() throws s3.m {
        v3.g gVar = this.V0;
        gVar.getClass();
        r3.a aVarG = gVar.g();
        if (aVarG instanceof v3.s) {
            try {
                MediaCrypto mediaCrypto = this.X0;
                mediaCrypto.getClass();
                mediaCrypto.setMediaDrmSession(((v3.s) aVarG).f21045b);
            } catch (MediaCryptoException e3) {
                throw d(e3, this.S0, false, 6006);
            }
        }
        r0(this.V0);
        this.B1 = 0;
        this.C1 = 0;
    }

    @Override // s3.a
    public final int B(androidx.media3.common.b bVar) throws s3.m {
        try {
            return y0(this.H0, bVar);
        } catch (a0 e3) {
            throw d(e3, bVar, false, 4002);
        }
    }

    public final void B0(long j10) {
        androidx.media3.common.b bVar = (androidx.media3.common.b) this.N1.f536d.f(j10);
        if (bVar == null && this.P1 && this.f541d1 != null) {
            bVar = (androidx.media3.common.b) this.N1.f536d.e();
        }
        if (bVar != null) {
            this.T0 = bVar;
        } else if (!this.f542e1 || this.T0 == null) {
            return;
        }
        androidx.media3.common.b bVar2 = this.T0;
        bVar2.getClass();
        e0(bVar2, this.f541d1);
        this.f542e1 = false;
        this.P1 = false;
    }

    @Override // s3.a
    public final int C() {
        return 8;
    }

    public final void E(MediaFormat mediaFormat) {
        if (Build.VERSION.SDK_INT >= 29) {
            for (Map.Entry entry : this.T1.f18175a.entrySet()) {
                String str = (String) entry.getKey();
                Object value = entry.getValue();
                if (value == null) {
                    mediaFormat.setString(str, null);
                } else if (value instanceof Integer) {
                    mediaFormat.setInteger(str, ((Integer) value).intValue());
                } else if (value instanceof Long) {
                    mediaFormat.setLong(str, ((Long) value).longValue());
                } else if (value instanceof Float) {
                    mediaFormat.setFloat(str, ((Float) value).floatValue());
                } else if (value instanceof String) {
                    mediaFormat.setString(str, (String) value);
                } else if (value instanceof ByteBuffer) {
                    mediaFormat.setByteBuffer(str, (ByteBuffer) value);
                }
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:114:0x030b  */
    /* JADX WARN: Code duplicated, block: B:117:0x0313 A[LOOP:0: B:25:0x0090->B:117:0x0313, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:136:0x0311 A[SYNTHETIC] */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r24v0, types: [a4.w, s3.a] */
    /* JADX WARN: Type inference failed for: r28v0 */
    /* JADX WARN: Type inference failed for: r28v1, types: [int] */
    /* JADX WARN: Type inference failed for: r2v1 */
    /* JADX WARN: Type inference failed for: r2v2, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r2v5 */
    /* JADX WARN: Type inference failed for: r4v22, types: [int] */
    /* JADX WARN: Type inference failed for: r4v40 */
    /* JADX WARN: Type inference failed for: r4v41 */
    /* JADX WARN: Type inference failed for: r4v5 */
    /* JADX WARN: Type inference failed for: r4v6 */
    /* JADX WARN: Type inference failed for: r5v16, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r5v32, types: [java.util.List] */
    public final boolean F(long j10, long j11) throws s3.m {
        i iVar;
        ?? r4;
        ?? r28;
        ji.k.A(!this.I1);
        i iVar2 = this.N0;
        if (iVar2.x()) {
            ByteBuffer byteBuffer = iVar2.f17865r0;
            int i10 = this.f557t1;
            int i11 = iVar2.f507x0;
            long j12 = iVar2.f17867t0;
            boolean zV = V(this.f18166y0, iVar2.f506w0);
            boolean zF = iVar2.f(4);
            androidx.media3.common.b bVar = this.T0;
            bVar.getClass();
            iVar = iVar2;
            if (k0(j10, j11, null, byteBuffer, i10, 0, i11, j12, zV, zF, bVar)) {
                g0(iVar.f506w0);
                iVar.s();
            }
        }
        iVar = iVar2;
        if (this.H1) {
            this.I1 = true;
            return false;
        }
        ?? r9 = 0;
        boolean z5 = this.f561x1;
        r3.g gVar = this.M0;
        if (z5) {
            ji.k.A(iVar.w(gVar));
            this.f561x1 = false;
        }
        if (this.y1) {
            if (iVar.x()) {
                return true;
            }
            this.f560w1 = false;
            o0();
            this.y1 = false;
            W();
            if (!this.f560w1) {
                return false;
            }
        }
        ji.k.A(!this.H1);
        m7.e eVar = this.Y;
        eVar.j();
        gVar.s();
        while (true) {
            gVar.s();
            int iW = w(eVar, gVar, r9);
            if (iW == -5) {
                d0(eVar);
            } else if (iW != -4) {
                if (iW != -3) {
                    throw new IllegalStateException();
                }
                if (k()) {
                    R().f = this.G1;
                }
            } else if (gVar.f(4)) {
                this.H1 = true;
                R().f = this.G1;
            } else {
                this.G1 = Math.max(this.G1, gVar.f17867t0);
                if (k() || this.L0.f(536870912)) {
                    R().f = this.G1;
                }
                byte[] bArr = null;
                if (this.J1) {
                    androidx.media3.common.b bVar2 = this.S0;
                    bVar2.getClass();
                    this.T0 = bVar2;
                    if (Objects.equals(bVar2.f2125o, "audio/opus") && !this.T0.f2128r.isEmpty()) {
                        byte[] bArr2 = (byte[]) this.T0.f2128r.get(r9);
                        int i12 = (bArr2[10] & 255) | ((bArr2[11] & 255) << 8);
                        i3.s sVarA = this.T0.a();
                        sVarA.I = i12;
                        this.T0 = new androidx.media3.common.b(sVarA);
                    }
                    e0(this.T0, null);
                    this.J1 = r9;
                }
                gVar.v();
                androidx.media3.common.b bVar3 = this.T0;
                if (bVar3 != null && Objects.equals(bVar3.f2125o, "audio/opus")) {
                    if (gVar.f(268435456)) {
                        gVar.Y = this.T0;
                        T(gVar);
                    }
                    if (this.f18166y0 - gVar.f17867t0 <= 80000) {
                        ?? r10 = this.T0.f2128r;
                        p0 p0Var = this.Q0;
                        p0Var.getClass();
                        gVar.f17865r0.getClass();
                        if (gVar.f17865r0.limit() - gVar.f17865r0.position() != 0) {
                            if (p0Var.f20379b == 2 && (r10.size() == 1 || r10.size() == 3)) {
                                bArr = (byte[]) r10.get(r9);
                            }
                            ByteBuffer byteBuffer2 = gVar.f17865r0;
                            int iPosition = byteBuffer2.position();
                            int iLimit = byteBuffer2.limit();
                            int i13 = iLimit - iPosition;
                            int i14 = (i13 + 255) / 255;
                            int i15 = i14 + 27 + i13;
                            if (p0Var.f20379b == 2) {
                                int length = bArr != null ? bArr.length + 28 : 47;
                                i15 = (length == true ? 1 : 0) + 44 + i15;
                                r4 = length;
                            } else {
                                r4 = r9;
                            }
                            if (p0Var.f20378a.capacity() < i15) {
                                p0Var.f20378a = ByteBuffer.allocate(i15).order(ByteOrder.LITTLE_ENDIAN);
                            } else {
                                p0Var.f20378a.clear();
                            }
                            ByteBuffer byteBuffer3 = p0Var.f20378a;
                            if (p0Var.f20379b == 2) {
                                if (bArr != null) {
                                    p0.a(byteBuffer3, 0L, 0, 1, true);
                                    byteBuffer3.put(com.bumptech.glide.c.c(bArr.length));
                                    byteBuffer3.put(bArr);
                                    byteBuffer3.putInt(22, l0.q(byteBuffer3.arrayOffset(), byteBuffer3.array(), bArr.length + 28, 0));
                                    byteBuffer3.position(bArr.length + 28);
                                } else {
                                    byteBuffer3.put(p0.f20376d);
                                }
                                byteBuffer3.put(p0.f20377e);
                                r28 = r4;
                            } else {
                                r28 = r4 == true ? 1 : 0;
                                iLimit = iLimit;
                            }
                            int iE = p0Var.f20380c + ((int) ((m3.n.e(byteBuffer2.get(0), byteBuffer2.limit() > 1 ? byteBuffer2.get(1) : (byte) 0) * 48000) / 1000000));
                            p0Var.f20380c = iE;
                            p0.a(byteBuffer3, iE, p0Var.f20379b, i14, false);
                            for (int i16 = 0; i16 < i14; i16++) {
                                if (i13 >= 255) {
                                    byteBuffer3.put((byte) -1);
                                    i13 -= 255;
                                } else {
                                    byteBuffer3.put((byte) i13);
                                    i13 = 0;
                                }
                            }
                            int i17 = iLimit;
                            while (iPosition < i17) {
                                byteBuffer3.put(byteBuffer2.get(iPosition));
                                iPosition++;
                            }
                            byteBuffer2.position(byteBuffer2.limit());
                            byteBuffer3.flip();
                            if (p0Var.f20379b == 2) {
                                byteBuffer3.putInt(r28 + 66, l0.q(byteBuffer3.arrayOffset() + r28 + 44, byteBuffer3.array(), byteBuffer3.limit() - byteBuffer3.position(), 0));
                            } else {
                                byteBuffer3.putInt(22, l0.q(byteBuffer3.arrayOffset(), byteBuffer3.array(), byteBuffer3.limit() - byteBuffer3.position(), 0));
                            }
                            p0Var.f20379b++;
                            p0Var.f20378a = byteBuffer3;
                            gVar.s();
                            gVar.u(p0Var.f20378a.remaining());
                            gVar.f17865r0.put(p0Var.f20378a);
                            gVar.v();
                        }
                    }
                }
                if (iVar.x()) {
                    long j13 = this.f18166y0;
                    if (V(j13, iVar.f506w0) == V(j13, gVar.f17867t0)) {
                        if (!iVar.w(gVar)) {
                            r9 = 0;
                        }
                    }
                } else if (!iVar.w(gVar)) {
                    r9 = 0;
                }
                this.f561x1 = true;
            }
            if (iVar.x()) {
                iVar.v();
            }
            return iVar.x() || this.H1 || this.y1;
        }
    }

    public abstract s3.d G(s sVar, androidx.media3.common.b bVar, androidx.media3.common.b bVar2, boolean z5);

    public r H(IllegalStateException illegalStateException, s sVar) {
        return new r(illegalStateException, sVar);
    }

    public final boolean I() throws s3.m {
        if (!this.D1) {
            A0();
            return true;
        }
        this.B1 = 1;
        if (this.f549l1) {
            this.C1 = 3;
            return false;
        }
        this.C1 = 2;
        return true;
    }

    public final boolean J(long j10, long j11) throws s3.m {
        p pVar = this.f539b1;
        pVar.getClass();
        int i10 = this.f557t1;
        MediaCodec.BufferInfo bufferInfo = this.O0;
        if (i10 < 0) {
            int iM = pVar.m(bufferInfo);
            if (iM < 0) {
                if (iM != -2) {
                    if (this.f552o1 && (this.H1 || this.B1 == 2)) {
                        j0();
                    }
                    long j12 = this.f553p1;
                    if (j12 != -9223372036854775807L) {
                        long j13 = j12 + 100;
                        this.f18162t0.getClass();
                        if (j13 < System.currentTimeMillis()) {
                            j0();
                            return false;
                        }
                    }
                    return false;
                }
                this.F1 = true;
                p pVar2 = this.f539b1;
                pVar2.getClass();
                MediaFormat mediaFormatG = pVar2.g();
                if (this.f547j1 != 0 && mediaFormatG.getInteger("width") == 32 && mediaFormatG.getInteger("height") == 32) {
                    this.f551n1 = true;
                    return true;
                }
                if (Build.VERSION.SDK_INT >= 29 && !this.V1.isEmpty()) {
                    s3.b bVar = new s3.b(s3.b.a(mediaFormatG, this.V1).f4501a);
                    if (!bVar.equals(this.U1)) {
                        this.U1 = bVar;
                        b0(bVar);
                    }
                }
                this.f541d1 = mediaFormatG;
                this.f542e1 = true;
                return true;
            }
            bufferInfo.presentationTimeUs -= this.S1;
            if (this.f551n1) {
                this.f551n1 = false;
                pVar.e(iM);
                return true;
            }
            if (bufferInfo.size == 0 && (bufferInfo.flags & 4) != 0) {
                j0();
                return false;
            }
            this.f557t1 = iM;
            ByteBuffer byteBufferQ = pVar.q(iM);
            this.f558u1 = byteBufferQ;
            if (byteBufferQ != null) {
                byteBufferQ.position(bufferInfo.offset);
                this.f558u1.limit(bufferInfo.offset + bufferInfo.size);
            }
            B0(bufferInfo.presentationTimeUs);
        }
        boolean z5 = this.R1 || bufferInfo.presentationTimeUs < this.f18166y0;
        long j14 = this.N1.f;
        boolean z6 = j14 != -9223372036854775807L && j14 <= bufferInfo.presentationTimeUs;
        this.f559v1 = z6;
        ByteBuffer byteBuffer = this.f558u1;
        int i11 = this.f557t1;
        int i12 = bufferInfo.flags;
        long j15 = bufferInfo.presentationTimeUs;
        androidx.media3.common.b bVar2 = this.T0;
        bVar2.getClass();
        if (!k0(j10, j11, pVar, byteBuffer, i11, i12, 1, j15, z5, z6, bVar2)) {
            return false;
        }
        g0(bufferInfo.presentationTimeUs);
        boolean z9 = (bufferInfo.flags & 4) != 0;
        if (!z9 && this.E1 && this.f559v1) {
            this.f18162t0.getClass();
            this.f553p1 = System.currentTimeMillis();
        }
        this.f557t1 = -1;
        this.f558u1 = null;
        if (!z9) {
            return true;
        }
        j0();
        return false;
    }

    /* JADX WARN: Code duplicated, block: B:102:0x01b0  */
    /* JADX WARN: Code duplicated, block: B:103:0x01b9  */
    /* JADX WARN: Code duplicated, block: B:112:0x0091 A[EDGE_INSN: B:112:0x0091->B:33:0x0091 BREAK  A[LOOP:0: B:30:0x006f->B:32:0x007c], SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:17:0x0032  */
    /* JADX WARN: Code duplicated, block: B:20:0x0037  */
    /* JADX WARN: Code duplicated, block: B:23:0x0049  */
    /* JADX WARN: Code duplicated, block: B:25:0x004d  */
    /* JADX WARN: Code duplicated, block: B:27:0x006a  */
    /* JADX WARN: Code duplicated, block: B:29:0x006e  */
    /* JADX WARN: Code duplicated, block: B:32:0x007c A[LOOP:0: B:30:0x006f->B:32:0x007c, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:38:0x00b3  */
    /* JADX WARN: Code duplicated, block: B:40:0x00b9  */
    /* JADX WARN: Code duplicated, block: B:42:0x00c2  */
    /* JADX WARN: Code duplicated, block: B:44:0x00c5  */
    /* JADX WARN: Code duplicated, block: B:46:0x00c9  */
    /* JADX WARN: Code duplicated, block: B:49:0x00d2  */
    /* JADX WARN: Code duplicated, block: B:51:0x00d9  */
    /* JADX WARN: Code duplicated, block: B:53:0x00e5  */
    /* JADX WARN: Code duplicated, block: B:56:0x00f0  */
    /* JADX WARN: Code duplicated, block: B:58:0x00f4  */
    /* JADX WARN: Code duplicated, block: B:61:0x00fa  */
    /* JADX WARN: Code duplicated, block: B:63:0x010a  */
    /* JADX WARN: Code duplicated, block: B:71:0x011e  */
    /* JADX WARN: Code duplicated, block: B:74:0x0127  */
    /* JADX WARN: Code duplicated, block: B:76:0x012f  */
    /* JADX WARN: Code duplicated, block: B:78:0x0133  */
    /* JADX WARN: Code duplicated, block: B:79:0x0137  */
    /* JADX WARN: Code duplicated, block: B:81:0x013b  */
    /* JADX WARN: Code duplicated, block: B:85:0x014e  */
    /* JADX WARN: Code duplicated, block: B:88:0x016e  */
    /* JADX WARN: Code duplicated, block: B:90:0x0176  */
    /* JADX WARN: Code duplicated, block: B:93:0x0189  */
    /* JADX WARN: Code duplicated, block: B:96:0x0190  */
    /* JADX WARN: Code duplicated, block: B:98:0x0196  */
    public final boolean K() throws s3.m {
        int iPosition;
        m7.e eVar;
        int i10;
        long j10;
        boolean zF;
        int iN;
        long j11;
        long j12;
        r3.c cVar;
        int i11;
        androidx.media3.common.b bVar;
        p pVar = this.f539b1;
        if (pVar != null && this.B1 != 2 && !this.H1) {
            int i12 = this.f556s1;
            r3.g gVar = this.L0;
            if (i12 < 0) {
                int iJ = pVar.j();
                this.f556s1 = iJ;
                if (iJ >= 0) {
                    gVar.f17865r0 = pVar.o(iJ);
                    gVar.s();
                    if (this.B1 == 1) {
                        if (!this.f552o1) {
                            this.E1 = true;
                            pVar.d(this.f556s1, 0, 0L, 4);
                            this.f556s1 = -1;
                            gVar.f17865r0 = null;
                        }
                        this.B1 = 2;
                        return false;
                    }
                    if (this.f550m1) {
                        this.f550m1 = false;
                        ByteBuffer byteBuffer = gVar.f17865r0;
                        byteBuffer.getClass();
                        byteBuffer.put(W1);
                        pVar.d(this.f556s1, 38, 0L, 0);
                        this.f556s1 = -1;
                        gVar.f17865r0 = null;
                        this.D1 = true;
                        return true;
                    }
                    if (this.A1 == 1) {
                        i11 = 0;
                        while (true) {
                            bVar = this.f540c1;
                            bVar.getClass();
                            if (i11 < bVar.f2128r.size()) {
                                break;
                            }
                            byte[] bArr = (byte[]) this.f540c1.f2128r.get(i11);
                            ByteBuffer byteBuffer2 = gVar.f17865r0;
                            byteBuffer2.getClass();
                            byteBuffer2.put(bArr);
                            i11++;
                        }
                        this.A1 = 2;
                    }
                    ByteBuffer byteBuffer3 = gVar.f17865r0;
                    byteBuffer3.getClass();
                    iPosition = byteBuffer3.position();
                    eVar = this.Y;
                    eVar.j();
                    try {
                        pVar.k(new b(this, eVar, 1));
                        i10 = this.R0.get();
                        if (i10 == -3) {
                            if (k()) {
                                R().f = this.G1;
                                return false;
                            }
                        } else {
                            if (i10 == -5) {
                                if (this.A1 == 2) {
                                    gVar.s();
                                    this.A1 = 1;
                                }
                                d0(eVar);
                                return true;
                            }
                            if (gVar.f(4)) {
                                if (!this.D1 || gVar.f(1)) {
                                    j10 = gVar.f17867t0;
                                    if (!t0(gVar)) {
                                        zF = gVar.f(1073741824);
                                        if (zF) {
                                            cVar = gVar.Z;
                                            if (iPosition == 0) {
                                                cVar.getClass();
                                            } else {
                                                if (cVar.f17860d == null) {
                                                    int[] iArr = new int[1];
                                                    cVar.f17860d = iArr;
                                                    cVar.f17863i.numBytesOfClearData = iArr;
                                                }
                                                int[] iArr2 = cVar.f17860d;
                                                iArr2[0] = iArr2[0] + iPosition;
                                            }
                                        }
                                        if (this.J1) {
                                            v vVarR = R();
                                            com.google.android.material.textfield.o oVar = vVarR.f536d;
                                            androidx.media3.common.b bVar2 = this.S0;
                                            bVar2.getClass();
                                            oVar.a(j10, bVar2);
                                            vVarR.f537e = true;
                                            this.J1 = false;
                                        }
                                        this.G1 = Math.max(this.G1, j10);
                                        if (k() || gVar.f(536870912)) {
                                            R().f = this.G1;
                                        }
                                        gVar.v();
                                        if (gVar.f(268435456)) {
                                            T(gVar);
                                        }
                                        if (this.R1) {
                                            j12 = this.G1;
                                            if (j10 <= j12) {
                                                this.S1 = (j12 - j10) + 1 + this.S1;
                                            }
                                            this.G1 = j10;
                                            this.R1 = false;
                                        }
                                        i0(gVar);
                                        iN = N(gVar);
                                        j11 = j10 + this.S1;
                                        if (zF) {
                                            pVar.c(this.f556s1, gVar.Z, j11, iN);
                                        } else {
                                            int i13 = this.f556s1;
                                            ByteBuffer byteBuffer4 = gVar.f17865r0;
                                            byteBuffer4.getClass();
                                            pVar.d(i13, byteBuffer4.limit(), j11, iN);
                                        }
                                        this.f556s1 = -1;
                                        gVar.f17865r0 = null;
                                        this.D1 = true;
                                        this.A1 = 0;
                                        this.M1.f18179c++;
                                        return true;
                                    }
                                } else {
                                    gVar.s();
                                    if (this.A1 == 2) {
                                        this.A1 = 1;
                                        return true;
                                    }
                                }
                                return true;
                            }
                            R().f = this.G1;
                            if (this.A1 == 2) {
                                gVar.s();
                                this.A1 = 1;
                            }
                            this.H1 = true;
                            if (!this.D1) {
                                j0();
                                return false;
                            }
                            if (!this.f552o1) {
                                this.E1 = true;
                                pVar.d(this.f556s1, 0, 0L, 4);
                                this.f556s1 = -1;
                                gVar.f17865r0 = null;
                                return false;
                            }
                        }
                    } catch (r3.f e3) {
                        Z(e3);
                        l0(0);
                        L();
                        return true;
                    }
                }
            } else {
                if (this.B1 == 1) {
                    if (!this.f552o1) {
                        this.E1 = true;
                        pVar.d(this.f556s1, 0, 0L, 4);
                        this.f556s1 = -1;
                        gVar.f17865r0 = null;
                    }
                    this.B1 = 2;
                    return false;
                }
                if (this.f550m1) {
                    this.f550m1 = false;
                    ByteBuffer byteBuffer5 = gVar.f17865r0;
                    byteBuffer5.getClass();
                    byteBuffer5.put(W1);
                    pVar.d(this.f556s1, 38, 0L, 0);
                    this.f556s1 = -1;
                    gVar.f17865r0 = null;
                    this.D1 = true;
                    return true;
                }
                if (this.A1 == 1) {
                    i11 = 0;
                    while (true) {
                        bVar = this.f540c1;
                        bVar.getClass();
                        if (i11 < bVar.f2128r.size()) {
                            break;
                            break;
                        }
                        byte[] bArr2 = (byte[]) this.f540c1.f2128r.get(i11);
                        ByteBuffer byteBuffer6 = gVar.f17865r0;
                        byteBuffer6.getClass();
                        byteBuffer6.put(bArr2);
                        i11++;
                    }
                    this.A1 = 2;
                }
                ByteBuffer byteBuffer7 = gVar.f17865r0;
                byteBuffer7.getClass();
                iPosition = byteBuffer7.position();
                eVar = this.Y;
                eVar.j();
                pVar.k(new b(this, eVar, 1));
                i10 = this.R0.get();
                if (i10 == -3) {
                    if (k()) {
                        R().f = this.G1;
                        return false;
                    }
                } else {
                    if (i10 == -5) {
                        if (this.A1 == 2) {
                            gVar.s();
                            this.A1 = 1;
                        }
                        d0(eVar);
                        return true;
                    }
                    if (gVar.f(4)) {
                        if (this.D1) {
                            j10 = gVar.f17867t0;
                            if (!t0(gVar)) {
                                zF = gVar.f(1073741824);
                                if (zF) {
                                    cVar = gVar.Z;
                                    if (iPosition == 0) {
                                        cVar.getClass();
                                    } else {
                                        if (cVar.f17860d == null) {
                                            int[] iArr3 = new int[1];
                                            cVar.f17860d = iArr3;
                                            cVar.f17863i.numBytesOfClearData = iArr3;
                                        }
                                        int[] iArr4 = cVar.f17860d;
                                        iArr4[0] = iArr4[0] + iPosition;
                                    }
                                }
                                if (this.J1) {
                                    v vVarR2 = R();
                                    com.google.android.material.textfield.o oVar2 = vVarR2.f536d;
                                    androidx.media3.common.b bVar3 = this.S0;
                                    bVar3.getClass();
                                    oVar2.a(j10, bVar3);
                                    vVarR2.f537e = true;
                                    this.J1 = false;
                                }
                                this.G1 = Math.max(this.G1, j10);
                                if (k()) {
                                    R().f = this.G1;
                                } else {
                                    R().f = this.G1;
                                }
                                gVar.v();
                                if (gVar.f(268435456)) {
                                    T(gVar);
                                }
                                if (this.R1) {
                                    j12 = this.G1;
                                    if (j10 <= j12) {
                                        this.S1 = (j12 - j10) + 1 + this.S1;
                                    }
                                    this.G1 = j10;
                                    this.R1 = false;
                                }
                                i0(gVar);
                                iN = N(gVar);
                                j11 = j10 + this.S1;
                                if (zF) {
                                    pVar.c(this.f556s1, gVar.Z, j11, iN);
                                } else {
                                    int i14 = this.f556s1;
                                    ByteBuffer byteBuffer8 = gVar.f17865r0;
                                    byteBuffer8.getClass();
                                    pVar.d(i14, byteBuffer8.limit(), j11, iN);
                                }
                                this.f556s1 = -1;
                                gVar.f17865r0 = null;
                                this.D1 = true;
                                this.A1 = 0;
                                this.M1.f18179c++;
                                return true;
                            }
                        } else {
                            j10 = gVar.f17867t0;
                            if (!t0(gVar)) {
                                zF = gVar.f(1073741824);
                                if (zF) {
                                    cVar = gVar.Z;
                                    if (iPosition == 0) {
                                        cVar.getClass();
                                    } else {
                                        if (cVar.f17860d == null) {
                                            int[] iArr5 = new int[1];
                                            cVar.f17860d = iArr5;
                                            cVar.f17863i.numBytesOfClearData = iArr5;
                                        }
                                        int[] iArr6 = cVar.f17860d;
                                        iArr6[0] = iArr6[0] + iPosition;
                                    }
                                }
                                if (this.J1) {
                                    v vVarR3 = R();
                                    com.google.android.material.textfield.o oVar3 = vVarR3.f536d;
                                    androidx.media3.common.b bVar4 = this.S0;
                                    bVar4.getClass();
                                    oVar3.a(j10, bVar4);
                                    vVarR3.f537e = true;
                                    this.J1 = false;
                                }
                                this.G1 = Math.max(this.G1, j10);
                                if (k()) {
                                    R().f = this.G1;
                                } else {
                                    R().f = this.G1;
                                }
                                gVar.v();
                                if (gVar.f(268435456)) {
                                    T(gVar);
                                }
                                if (this.R1) {
                                    j12 = this.G1;
                                    if (j10 <= j12) {
                                        this.S1 = (j12 - j10) + 1 + this.S1;
                                    }
                                    this.G1 = j10;
                                    this.R1 = false;
                                }
                                i0(gVar);
                                iN = N(gVar);
                                j11 = j10 + this.S1;
                                if (zF) {
                                    pVar.c(this.f556s1, gVar.Z, j11, iN);
                                } else {
                                    int i15 = this.f556s1;
                                    ByteBuffer byteBuffer9 = gVar.f17865r0;
                                    byteBuffer9.getClass();
                                    pVar.d(i15, byteBuffer9.limit(), j11, iN);
                                }
                                this.f556s1 = -1;
                                gVar.f17865r0 = null;
                                this.D1 = true;
                                this.A1 = 0;
                                this.M1.f18179c++;
                                return true;
                            }
                        }
                        return true;
                    }
                    R().f = this.G1;
                    if (this.A1 == 2) {
                        gVar.s();
                        this.A1 = 1;
                    }
                    this.H1 = true;
                    if (!this.D1) {
                        j0();
                        return false;
                    }
                    if (!this.f552o1) {
                        this.E1 = true;
                        pVar.d(this.f556s1, 0, 0L, 4);
                        this.f556s1 = -1;
                        gVar.f17865r0 = null;
                        return false;
                    }
                }
            }
        }
        return false;
    }

    public final void L() {
        try {
            p pVar = this.f539b1;
            pVar.getClass();
            pVar.flush();
        } finally {
            p0();
        }
    }

    public final List M(boolean z5) {
        androidx.media3.common.b bVar = this.S0;
        bVar.getClass();
        l lVar = this.H0;
        ArrayList arrayListP = P(lVar, bVar, z5);
        if (!arrayListP.isEmpty() || !z5) {
            return arrayListP;
        }
        ArrayList arrayListP2 = P(lVar, bVar, false);
        if (!arrayListP2.isEmpty()) {
            l3.b.m("MediaCodecRenderer", "Drm session requires secure decoder for " + bVar.f2125o + ", but no secure decoder available. Trying to proceed with " + arrayListP2 + ".");
        }
        return arrayListP2;
    }

    public int N(r3.g gVar) {
        return 0;
    }

    public abstract float O(float f, androidx.media3.common.b bVar, androidx.media3.common.b[] bVarArr);

    public abstract ArrayList P(l lVar, androidx.media3.common.b bVar, boolean z5);

    public long Q(long j10, long j11, boolean z5) {
        return super.f(j10, j11);
    }

    public final v R() {
        ArrayDeque arrayDeque = this.P0;
        return !arrayDeque.isEmpty() ? (v) arrayDeque.getLast() : this.N1;
    }

    public abstract n S(s sVar, androidx.media3.common.b bVar, MediaCrypto mediaCrypto, float f);

    public abstract void T(r3.g gVar);

    /* JADX WARN: Code duplicated, block: B:25:0x00bd  */
    /* JADX WARN: Code duplicated, block: B:40:0x00f5  */
    public final void U(s sVar, MediaCrypto mediaCrypto) {
        int i10;
        this.f546i1 = sVar;
        androidx.media3.common.b bVar = this.S0;
        bVar.getClass();
        String str = sVar.f521a;
        float f = this.f538a1;
        androidx.media3.common.b[] bVarArr = this.f18164w0;
        bVarArr.getClass();
        float fO = O(f, bVar, bVarArr);
        if (fO <= this.J0) {
            fO = -1.0f;
        }
        this.f18162t0.getClass();
        long jElapsedRealtime = SystemClock.elapsedRealtime();
        n nVarS = S(sVar, bVar, mediaCrypto, fO);
        int i11 = Build.VERSION.SDK_INT;
        if (i11 >= 31) {
            t3.j jVar = this.f18161s0;
            jVar.getClass();
            t.m(nVarS, jVar);
        }
        try {
            Trace.beginSection("createCodec:" + str);
            p pVarE = this.G0.e(nVarS);
            this.f539b1 = pVarE;
            this.f554q1 = pVarE.f(new z7.b(1, this));
            Trace.endSection();
            this.f18162t0.getClass();
            long jElapsedRealtime2 = SystemClock.elapsedRealtime();
            if (!sVar.e(this.F0, bVar)) {
                String strC = androidx.media3.common.b.c(bVar);
                Locale locale = Locale.US;
                l3.b.m("MediaCodecRenderer", m0.j("Format exceeds selected codec's capabilities [", strC, ", ", str, "]"));
            }
            this.f543f1 = fO;
            this.f540c1 = bVar;
            boolean z5 = false;
            if (i11 <= 25 && "OMX.Exynos.avc.dec.secure".equals(str)) {
                String str2 = Build.MODEL;
                if (str2.startsWith("SM-T585") || str2.startsWith("SM-A510") || str2.startsWith("SM-A520") || str2.startsWith("SM-J700")) {
                    i10 = 2;
                } else if (i11 < 24) {
                    i10 = 0;
                } else {
                    i10 = 0;
                }
            } else if (i11 < 24 || !("OMX.Nvidia.h264.decode".equals(str) || "OMX.Nvidia.h264.decode.secure".equals(str))) {
                i10 = 0;
            } else {
                String str3 = Build.DEVICE;
                if ("flounder".equals(str3) || "flounder_lte".equals(str3) || "grouper".equals(str3) || "tilapia".equals(str3)) {
                    i10 = 1;
                } else {
                    i10 = 0;
                }
            }
            this.f547j1 = i10;
            this.f548k1 = i11 == 29 && "c2.android.aac.decoder".equals(str);
            this.f549l1 = i11 == 23 && "OMX.google.vorbis.decoder".equals(str);
            String str4 = sVar.f521a;
            if ((i11 <= 25 && "OMX.rk.video_decoder.avc".equals(str4)) || ((i11 <= 29 && ("OMX.broadcom.video_decoder.tunnel".equals(str4) || "OMX.broadcom.video_decoder.tunnel.secure".equals(str4) || "OMX.bcm.vdec.avc.tunnel".equals(str4) || "OMX.bcm.vdec.avc.tunnel.secure".equals(str4) || "OMX.bcm.vdec.hevc.tunnel".equals(str4) || "OMX.bcm.vdec.hevc.tunnel.secure".equals(str4))) || ("Amazon".equals(Build.MANUFACTURER) && "AFTS".equals(Build.MODEL) && sVar.f))) {
                z5 = true;
            }
            this.f552o1 = z5;
            this.f539b1.getClass();
            if (this.u0 == 2) {
                this.f18162t0.getClass();
                this.f555r1 = SystemClock.elapsedRealtime() + 1000;
            }
            this.M1.f18177a++;
            long j10 = jElapsedRealtime2 - jElapsedRealtime;
            if (i11 >= 31 && !this.V1.isEmpty()) {
                p pVar = this.f539b1;
                pVar.getClass();
                pVar.r(new ArrayList(this.V1));
            }
            a0(jElapsedRealtime2, j10, str);
        } catch (Throwable th2) {
            Trace.endSection();
            throw th2;
        }
    }

    public final boolean V(long j10, long j11) {
        if (j11 >= j10) {
            return false;
        }
        androidx.media3.common.b bVar = this.T0;
        return bVar == null || !Objects.equals(bVar.f2125o, "audio/opus") || j10 - j11 > 80000;
    }

    /* JADX WARN: Code duplicated, block: B:39:0x0086 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:40:0x0088  */
    /* JADX WARN: Code duplicated, block: B:43:0x008f  */
    /* JADX WARN: Code duplicated, block: B:45:0x0093  */
    /* JADX WARN: Code duplicated, block: B:53:0x00af A[Catch: u -> 0x00bf, TryCatch #0 {u -> 0x00bf, blocks: (B:51:0x00ab, B:53:0x00af, B:55:0x00b6, B:60:0x00c1, B:64:0x00ce), top: B:74:0x00ab }] */
    /* JADX WARN: Code duplicated, block: B:63:0x00cd  */
    public final void W() throws s3.m {
        androidx.media3.common.b bVar;
        v3.g gVar;
        if (this.f539b1 != null || this.f560w1 || (bVar = this.S0) == null) {
            return;
        }
        String str = bVar.f2125o;
        boolean z5 = true;
        if (this.V0 == null && x0(bVar)) {
            this.f560w1 = false;
            o0();
            boolean zEquals = "audio/mp4a-latm".equals(str);
            i iVar = this.N0;
            if (zEquals || "audio/mpeg".equals(str) || "audio/opus".equals(str)) {
                iVar.getClass();
                iVar.f508y0 = 32;
            } else {
                iVar.getClass();
                iVar.f508y0 = 1;
            }
            this.f560w1 = true;
            return;
        }
        r0(this.V0);
        if (this.U0 == null) {
            try {
                gVar = this.U0;
                if (gVar == null && (gVar.getState() == 3 || this.U0.getState() == 4)) {
                    v3.g gVar2 = this.U0;
                    str.getClass();
                    if (!gVar2.e(str)) {
                        z5 = false;
                    }
                } else {
                    z5 = false;
                }
                X(this.X0, z5);
            } catch (u e3) {
                throw d(e3, bVar, false, 4001);
            }
        } else {
            ji.k.A(this.X0 == null);
            v3.g gVar3 = this.U0;
            r3.a aVarG = gVar3.g();
            if (v3.s.f21043c && (aVarG instanceof v3.s)) {
                int state = gVar3.getState();
                if (state == 1) {
                    v3.f fVarF = gVar3.f();
                    fVarF.getClass();
                    throw d(fVarF, this.S0, false, fVarF.f21029e);
                }
                if (state == 4) {
                    if (aVarG == null) {
                        if (gVar3.f() != null) {
                        }
                    } else if (aVarG instanceof v3.s) {
                        v3.s sVar = (v3.s) aVarG;
                        this.X0 = new MediaCrypto(sVar.f21044a, sVar.f21045b);
                    }
                    gVar = this.U0;
                    if (gVar == null) {
                        z5 = false;
                    } else {
                        z5 = false;
                    }
                    X(this.X0, z5);
                }
            } else {
                if (aVarG == null) {
                    if (gVar3.f() != null) {
                    }
                } else if (aVarG instanceof v3.s) {
                    v3.s sVar2 = (v3.s) aVarG;
                    try {
                        this.X0 = new MediaCrypto(sVar2.f21044a, sVar2.f21045b);
                    } catch (MediaCryptoException e10) {
                        throw d(e10, this.S0, false, 6006);
                    }
                }
                gVar = this.U0;
                if (gVar == null) {
                    z5 = false;
                } else {
                    z5 = false;
                }
                X(this.X0, z5);
            }
        }
        MediaCrypto mediaCrypto = this.X0;
        if (mediaCrypto == null || this.f539b1 != null) {
            return;
        }
        mediaCrypto.release();
        this.X0 = null;
    }

    public final void X(MediaCrypto mediaCrypto, boolean z5) throws u {
        androidx.media3.common.b bVar = this.S0;
        bVar.getClass();
        if (this.f544g1 == null) {
            try {
                List listM = M(z5);
                ArrayDeque arrayDeque = new ArrayDeque();
                this.f544g1 = arrayDeque;
                if (this.I0) {
                    arrayDeque.addAll(listM);
                } else {
                    ArrayList arrayList = (ArrayList) listM;
                    if (!arrayList.isEmpty()) {
                        this.f544g1.add((s) arrayList.get(0));
                    }
                }
                this.f545h1 = null;
            } catch (a0 e3) {
                throw new u(bVar, e3, z5, -49998);
            }
        }
        if (this.f544g1.isEmpty()) {
            throw new u(bVar, null, z5, -49999);
        }
        ArrayDeque arrayDeque2 = this.f544g1;
        arrayDeque2.getClass();
        while (this.f539b1 == null) {
            s sVar = (s) arrayDeque2.peekFirst();
            sVar.getClass();
            if (!Y(bVar) || !v0(sVar)) {
                return;
            }
            try {
                U(sVar, mediaCrypto);
            } catch (Exception e10) {
                l3.b.n("MediaCodecRenderer", "Failed to initialize decoder: " + sVar, e10);
                arrayDeque2.removeFirst();
                u uVar = new u("Decoder init failed: " + sVar.f521a + ", " + bVar, e10, bVar.f2125o, z5, sVar, e10 instanceof MediaCodec.CodecException ? ((MediaCodec.CodecException) e10).getDiagnosticInfo() : null);
                Z(uVar);
                u uVar2 = this.f545h1;
                if (uVar2 == null) {
                    this.f545h1 = uVar;
                } else {
                    this.f545h1 = new u(uVar2.getMessage(), uVar2.getCause(), uVar2.f531e, uVar2.X, uVar2.Y, uVar2.Z);
                }
                if (arrayDeque2.isEmpty()) {
                    throw this.f545h1;
                }
            }
        }
        this.f544g1 = null;
    }

    public boolean Y(androidx.media3.common.b bVar) {
        return true;
    }

    public abstract void Z(Exception exc);

    public abstract void a0(long j10, long j11, String str);

    public abstract void b0(s3.b bVar);

    @Override // s3.a, s3.z0
    public void c(int i10, Object obj) {
        int i11;
        if (i10 == 11) {
            s3.b0 b0Var = (s3.b0) obj;
            b0Var.getClass();
            this.W0 = b0Var;
            return;
        }
        if (i10 != 21) {
            if (i10 == 22 && (i11 = Build.VERSION.SDK_INT) >= 29) {
                obj.getClass();
                f1 f1Var = (f1) obj;
                if (this.V1.equals(f1Var)) {
                    return;
                }
                if (i11 >= 31) {
                    HashSet hashSet = new HashSet(f1Var);
                    HashSet hashSet2 = new HashSet();
                    c3 it = this.V1.iterator();
                    while (it.hasNext()) {
                        String str = (String) it.next();
                        if (!hashSet.remove(str)) {
                            hashSet2.add(str);
                        }
                    }
                    p pVar = this.f539b1;
                    if (pVar != null) {
                        if (!hashSet2.isEmpty()) {
                            pVar.s(new ArrayList(hashSet2));
                        }
                        if (!hashSet.isEmpty()) {
                            pVar.r(new ArrayList(hashSet));
                        }
                    }
                }
                this.V1 = f1Var;
                return;
            }
            return;
        }
        if (Build.VERSION.SDK_INT >= 29) {
            obj.getClass();
            s3.b bVar = (s3.b) obj;
            this.T1 = bVar;
            p pVar2 = this.f539b1;
            if (pVar2 != null) {
                Bundle bundle = new Bundle();
                for (Map.Entry entry : bVar.f18175a.entrySet()) {
                    String str2 = (String) entry.getKey();
                    Object value = entry.getValue();
                    if (value != null) {
                        if (value instanceof Integer) {
                            bundle.putInt(str2, ((Integer) value).intValue());
                        } else if (value instanceof Long) {
                            bundle.putLong(str2, ((Long) value).longValue());
                        } else if (value instanceof Float) {
                            bundle.putFloat(str2, ((Float) value).floatValue());
                        } else if (value instanceof String) {
                            bundle.putString(str2, (String) value);
                        } else if (value instanceof ByteBuffer) {
                            ByteBuffer byteBuffer = (ByteBuffer) value;
                            byte[] bArr = new byte[byteBuffer.remaining()];
                            byteBuffer.duplicate().get(bArr);
                            bundle.putByteArray(str2, bArr);
                        }
                    }
                }
                pVar2.b(bundle);
            }
        }
    }

    public abstract void c0(String str);

    /* JADX WARN: Code duplicated, block: B:103:0x015a  */
    /* JADX WARN: Code duplicated, block: B:12:0x0032  */
    /* JADX WARN: Code duplicated, block: B:32:0x0063  */
    /* JADX WARN: Code duplicated, block: B:34:0x006b  */
    /* JADX WARN: Code duplicated, block: B:98:0x014d  */
    /* JADX WARN: Code restructure failed: missing block: B:85:0x0126, code lost:
    
        if (r4.e(r2) != false) goto L150;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public s3.d d0(m7.e r15) {
        /*
            Method dump skipped, instruction units count: 509
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: a4.w.d0(m7.e):s3.d");
    }

    public abstract void e0(androidx.media3.common.b bVar, MediaFormat mediaFormat);

    @Override // s3.a
    public final long f(long j10, long j11) {
        return Q(j10, j11, this.f554q1);
    }

    public void g0(long j10) {
        this.O1 = j10;
        while (true) {
            ArrayDeque arrayDeque = this.P0;
            if (arrayDeque.isEmpty() || j10 < ((v) arrayDeque.peek()).f533a) {
                return;
            }
            v vVar = (v) arrayDeque.poll();
            vVar.getClass();
            s0(vVar);
            h0();
        }
    }

    public abstract void h0();

    public final void j0() throws s3.m {
        int i10 = this.C1;
        if (i10 == 1) {
            L();
            return;
        }
        if (i10 == 2) {
            L();
            A0();
        } else if (i10 != 3) {
            this.I1 = true;
            n0();
        } else {
            m0();
            W();
        }
    }

    public abstract boolean k0(long j10, long j11, p pVar, ByteBuffer byteBuffer, int i10, int i11, int i12, long j12, boolean z5, boolean z6, androidx.media3.common.b bVar);

    public final boolean l0(int i10) throws s3.m {
        m7.e eVar = this.Y;
        eVar.j();
        r3.g gVar = this.K0;
        gVar.s();
        int iW = w(eVar, gVar, i10 | 4);
        if (iW == -5) {
            d0(eVar);
            return true;
        }
        if (iW != -4 || !gVar.f(4)) {
            return false;
        }
        this.H1 = true;
        j0();
        return false;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final void m0() {
        try {
            p pVar = this.f539b1;
            if (pVar != null) {
                pVar.release();
                this.M1.f18178b++;
                s sVar = this.f546i1;
                sVar.getClass();
                c0(sVar.f521a);
            }
            this.f539b1 = null;
            try {
                MediaCrypto mediaCrypto = this.X0;
                if (mediaCrypto != null) {
                    mediaCrypto.release();
                }
            } finally {
                this.X0 = null;
                r0(null);
                q0();
            }
        } catch (Throwable th2) {
            this.f539b1 = null;
            try {
                MediaCrypto mediaCrypto2 = this.X0;
                if (mediaCrypto2 != null) {
                    mediaCrypto2.release();
                }
                throw th2;
            } finally {
                this.X0 = null;
                r0(null);
                q0();
            }
        }
    }

    @Override // s3.a
    public void n() {
        this.S0 = null;
        s0(v.f532g);
        this.P0.clear();
        if (this.f560w1) {
            this.f560w1 = false;
            o0();
        } else {
            if (this.f539b1 == null) {
                return;
            }
            if (w0()) {
                m0();
            } else if (u0()) {
                L();
            } else {
                this.R1 = true;
            }
        }
    }

    public abstract void n0();

    public final void o0() {
        this.G1 = -9223372036854775807L;
        R().f = -9223372036854775807L;
        this.O1 = -9223372036854775807L;
        this.y1 = false;
        this.N0.s();
        this.M0.s();
        this.f561x1 = false;
        p0 p0Var = this.Q0;
        p0Var.getClass();
        p0Var.f20378a = j3.m.f12771a;
        p0Var.f20380c = 0;
        p0Var.f20379b = 2;
    }

    @Override // s3.a
    public void p(long j10, boolean z5, boolean z6) {
        ArrayDeque arrayDeque = this.P0;
        if (!arrayDeque.isEmpty()) {
            this.N1 = (v) arrayDeque.getLast();
        }
        arrayDeque.clear();
        if (z6) {
            this.H1 = false;
            this.I1 = false;
            this.K1 = false;
            if (this.f560w1) {
                o0();
            } else if (this.f539b1 != null) {
                if (w0()) {
                    m0();
                    W();
                } else if (u0()) {
                    L();
                } else {
                    this.R1 = true;
                }
            }
            if (this.N1.f536d.h() > 0) {
                this.J1 = true;
            }
            this.N1.f536d.b();
            this.N1.f537e = false;
        }
    }

    public void p0() {
        this.f556s1 = -1;
        this.L0.f17865r0 = null;
        this.f557t1 = -1;
        this.f558u1 = null;
        this.G1 = -9223372036854775807L;
        R().f = -9223372036854775807L;
        this.O1 = -9223372036854775807L;
        this.f555r1 = -9223372036854775807L;
        this.E1 = false;
        this.f553p1 = -9223372036854775807L;
        this.D1 = false;
        this.f550m1 = false;
        this.f551n1 = false;
        this.f559v1 = false;
        this.B1 = 0;
        this.C1 = 0;
        this.A1 = this.f562z1 ? 1 : 0;
        this.R1 = false;
        this.S1 = 0L;
    }

    public final void q0() {
        p0();
        this.L1 = null;
        this.f544g1 = null;
        this.f546i1 = null;
        this.f540c1 = null;
        this.f541d1 = null;
        this.f542e1 = false;
        this.F1 = false;
        this.f543f1 = -1.0f;
        this.f547j1 = 0;
        this.f548k1 = false;
        this.f549l1 = false;
        this.f552o1 = false;
        this.f554q1 = false;
        this.f562z1 = false;
        this.A1 = 0;
    }

    public final void r0(v3.g gVar) {
        v3.g gVar2 = this.U0;
        if (gVar2 != gVar) {
            if (gVar != null) {
                gVar.d(null);
            }
            if (gVar2 != null) {
                gVar2.a(null);
            }
        }
        this.U0 = gVar;
    }

    public final void s0(v vVar) {
        this.N1 = vVar;
        if (vVar.f535c != -9223372036854775807L) {
            this.P1 = true;
            f0();
        }
    }

    public boolean t0(r3.g gVar) {
        return false;
    }

    /* JADX WARN: Code restructure failed: missing block: B:15:0x003a, code lost:
    
        if (r4 >= r0) goto L16;
     */
    @Override // s3.a
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void u(androidx.media3.common.b[] r12, long r13, long r15, e4.g0 r17) {
        /*
            r11 = this;
            a4.v r12 = r11.N1
            long r0 = r12.f535c
            r2 = -9223372036854775807(0x8000000000000001, double:-4.9E-324)
            int r12 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1))
            if (r12 != 0) goto L24
            a4.v r4 = new a4.v
            r5 = -9223372036854775807(0x8000000000000001, double:-4.9E-324)
            r7 = r13
            r9 = r15
            r4.<init>(r5, r7, r9)
            r11.s0(r4)
            boolean r12 = r11.Q1
            if (r12 == 0) goto L56
            r11.h0()
            return
        L24:
            java.util.ArrayDeque r12 = r11.P0
            boolean r0 = r12.isEmpty()
            if (r0 == 0) goto L57
            long r0 = r11.G1
            int r4 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1))
            if (r4 == 0) goto L3c
            long r4 = r11.O1
            int r6 = (r4 > r2 ? 1 : (r4 == r2 ? 0 : -1))
            if (r6 == 0) goto L57
            int r0 = (r4 > r0 ? 1 : (r4 == r0 ? 0 : -1))
            if (r0 < 0) goto L57
        L3c:
            a4.v r4 = new a4.v
            r5 = -9223372036854775807(0x8000000000000001, double:-4.9E-324)
            r7 = r13
            r9 = r15
            r4.<init>(r5, r7, r9)
            r11.s0(r4)
            a4.v r12 = r11.N1
            long r12 = r12.f535c
            int r12 = (r12 > r2 ? 1 : (r12 == r2 ? 0 : -1))
            if (r12 == 0) goto L56
            r11.h0()
        L56:
            return
        L57:
            a4.v r0 = new a4.v
            long r1 = r11.G1
            r3 = r13
            r5 = r15
            r0.<init>(r1, r3, r5)
            r12.add(r0)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: a4.w.u(androidx.media3.common.b[], long, long, e4.g0):void");
    }

    public boolean u0() {
        return true;
    }

    public boolean v0(s sVar) {
        return true;
    }

    public boolean w0() {
        int i10 = this.C1;
        if (i10 == 3 || ((this.f548k1 && !this.F1) || (this.f549l1 && this.E1))) {
            return true;
        }
        if (i10 != 2) {
            return false;
        }
        try {
            A0();
            return false;
        } catch (s3.m e3) {
            l3.b.n("MediaCodecRenderer", "Failed to update the DRM session, releasing the codec instead.", e3);
            return true;
        }
    }

    @Override // s3.a
    public void x(long j10, long j11) throws s3.m {
        boolean z5;
        boolean z6;
        boolean z9 = false;
        if (this.K1) {
            this.K1 = false;
            j0();
        }
        s3.m mVar = this.L1;
        if (mVar != null) {
            this.L1 = null;
            throw mVar;
        }
        try {
            if (this.I1) {
                n0();
                return;
            }
            if (this.S0 != null || l0(2)) {
                W();
                if (this.f560w1) {
                    Trace.beginSection("bypassRender");
                    while (F(j10, j11)) {
                    }
                    Trace.endSection();
                } else if (this.f539b1 != null) {
                    this.f18162t0.getClass();
                    long jElapsedRealtime = SystemClock.elapsedRealtime();
                    Trace.beginSection("drainAndFeed");
                    while (J(j10, j11)) {
                        long j12 = this.Y0;
                        if (j12 != -9223372036854775807L) {
                            this.f18162t0.getClass();
                            z6 = SystemClock.elapsedRealtime() - jElapsedRealtime < j12;
                        }
                        if (!z6) {
                            break;
                        }
                    }
                    while (K()) {
                        long j13 = this.Y0;
                        if (j13 != -9223372036854775807L) {
                            this.f18162t0.getClass();
                            z5 = SystemClock.elapsedRealtime() - jElapsedRealtime < j13;
                        }
                        if (!z5) {
                            break;
                        }
                    }
                    Trace.endSection();
                } else {
                    s3.c cVar = this.M1;
                    int i10 = cVar.f18180d;
                    h1 h1Var = this.f18163v0;
                    h1Var.getClass();
                    cVar.f18180d = i10 + h1Var.m(j10 - this.f18165x0);
                    l0(1);
                }
                synchronized (this.M1) {
                }
            }
        } catch (MediaCodec.CryptoException e3) {
            throw d(e3, this.S0, false, l0.C(e3.getErrorCode()));
        } catch (IllegalStateException e10) {
            boolean z10 = e10 instanceof MediaCodec.CodecException;
            if (!z10) {
                StackTraceElement[] stackTrace = e10.getStackTrace();
                if (stackTrace.length <= 0 || !stackTrace[0].getClassName().equals("android.media.MediaCodec")) {
                    throw e10;
                }
            }
            Z(e10);
            if (z10 && ((MediaCodec.CodecException) e10).isRecoverable()) {
                z9 = true;
            }
            if (z9) {
                m0();
            }
            r rVarH = H(e10, this.f546i1);
            throw d(rVarH, this.S0, z9, rVarH.f520e == 1101 ? 4006 : 4003);
        }
    }

    public boolean x0(androidx.media3.common.b bVar) {
        return false;
    }

    public abstract int y0(l lVar, androidx.media3.common.b bVar);

    public final boolean z0(androidx.media3.common.b bVar) throws s3.m {
        if (this.f539b1 != null && this.C1 != 3 && this.u0 != 0) {
            float f = this.f538a1;
            bVar.getClass();
            androidx.media3.common.b[] bVarArr = this.f18164w0;
            bVarArr.getClass();
            float fO = O(f, bVar, bVarArr);
            float f10 = this.f543f1;
            if (f10 != fO) {
                if (fO == -1.0f) {
                    if (this.D1) {
                        this.B1 = 1;
                        this.C1 = 3;
                        return false;
                    }
                    m0();
                    W();
                    return false;
                }
                if (f10 != -1.0f || fO > this.J0) {
                    Bundle bundle = new Bundle();
                    bundle.putFloat("operating-rate", fO);
                    p pVar = this.f539b1;
                    pVar.getClass();
                    pVar.b(bundle);
                    this.f543f1 = fO;
                }
            }
        }
        return true;
    }

    public void f0() {
    }

    public void i0(r3.g gVar) {
    }
}
