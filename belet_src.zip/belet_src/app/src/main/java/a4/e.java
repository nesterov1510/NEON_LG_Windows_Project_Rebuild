package a4;

import android.content.DialogInterface;
import android.media.MediaCodec;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.support.v4.os.ResultReceiver;
import android.text.TextUtils;
import android.util.Pair;
import androidx.media3.session.c3;
import androidx.media3.session.d3;
import androidx.media3.session.legacy.k0;
import androidx.media3.session.legacy.m0;
import androidx.media3.session.legacy.r0;
import androidx.media3.session.legacy.s0;
import androidx.media3.session.n2;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.concurrent.atomic.AtomicReference;
import l3.l0;
import lc.u0;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class e extends Handler {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f479a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public Object f480b;

    public /* synthetic */ e() {
        this.f479a = 1;
    }

    private final void a(Message message) {
        m0 m0Var;
        k0 k0Var;
        e eVar;
        if (message.what == 1) {
            synchronized (((k0) this.f480b).f2456a) {
                m0Var = (m0) ((k0) this.f480b).f2459d.get();
                k0Var = (k0) this.f480b;
                eVar = k0Var.f2460e;
            }
            if (m0Var == null || k0Var != m0Var.b() || eVar == null) {
                return;
            }
            m0Var.d((s0) message.obj);
            ((k0) this.f480b).a(m0Var, eVar);
            m0Var.d(null);
        }
    }

    private final void b(Message message) {
        v3.w wVar;
        Pair pair = (Pair) message.obj;
        Object obj = pair.first;
        Object obj2 = pair.second;
        int i10 = message.what;
        if (i10 == 1) {
            v3.b bVar = (v3.b) this.f480b;
            r0 r0Var = bVar.f20997c;
            if (obj == bVar.f21018z) {
                if (bVar.f21008p == 2 || bVar.j()) {
                    bVar.f21018z = null;
                    if (obj2 instanceof Exception) {
                        r0Var.w((Exception) obj2, false);
                        return;
                    }
                    try {
                        bVar.f20996b.j(((v3.y) obj2).f21053a);
                        r0Var.Y = null;
                        HashSet hashSet = (HashSet) r0Var.X;
                        u0 u0VarL = u0.l(hashSet);
                        hashSet.clear();
                        lc.r0 r0VarListIterator = u0VarL.listIterator(0);
                        while (r0VarListIterator.hasNext()) {
                            v3.b bVar2 = (v3.b) r0VarListIterator.next();
                            if (bVar2.m()) {
                                bVar2.i(true);
                            }
                        }
                        return;
                    } catch (Exception e3) {
                        r0Var.w(e3, true);
                        return;
                    }
                }
                return;
            }
            return;
        }
        if (i10 != 2) {
            return;
        }
        v3.b bVar3 = (v3.b) this.f480b;
        if (obj == bVar3.f21016x && bVar3.j()) {
            bVar3.f21016x = null;
            synchronized (bVar3.f21007o) {
                v3.v vVar = bVar3.f21017y;
                vVar.getClass();
                wVar = new v3.w();
                vVar.f21052a.g();
                bVar3.f21017y = null;
            }
            if ((obj2 instanceof Exception) || (obj2 instanceof NoSuchMethodError)) {
                bVar3.l((Throwable) obj2, false);
                return;
            }
            try {
                byte[] bArrI = bVar3.f20996b.i(bVar3.f21014v, ((v3.y) obj2).f21053a);
                if (bVar3.f21015w != null && bArrI != null && bArrI.length != 0) {
                    bVar3.f21015w = bArrI;
                }
                bVar3.f21008p = 4;
                bVar3.h(new r0.e(15, wVar));
            } catch (Exception e10) {
                e = e10;
                bVar3.l(e, true);
            } catch (NoSuchMethodError e11) {
                e = e11;
                bVar3.l(e, true);
            }
        }
    }

    public void c(Runnable runnable) {
        if (Thread.currentThread() == getLooper().getThread()) {
            runnable.run();
        } else {
            post(runnable);
        }
    }

    @Override // android.os.Handler
    public final void handleMessage(Message message) {
        f fVar = null;
        boolean z5 = false;
        int i10 = 1;
        switch (this.f479a) {
            case 0:
                g gVar = (g) this.f480b;
                int i11 = message.what;
                if (i11 == 1) {
                    f fVar2 = (f) message.obj;
                    try {
                        gVar.f490e.queueInputBuffer(fVar2.f482a, 0, fVar2.f483b, fVar2.f485d, fVar2.f486e);
                        break;
                    } catch (RuntimeException e3) {
                        AtomicReference atomicReference = gVar.Z;
                        while (!atomicReference.compareAndSet(null, e3) && atomicReference.get() == null) {
                        }
                    }
                    fVar = fVar2;
                } else if (i11 == 2) {
                    f fVar3 = (f) message.obj;
                    int i12 = fVar3.f482a;
                    MediaCodec.CryptoInfo cryptoInfo = fVar3.f484c;
                    long j10 = fVar3.f485d;
                    int i13 = fVar3.f486e;
                    try {
                        if (Build.VERSION.SDK_INT < 31) {
                            synchronized (g.u0) {
                                gVar.f490e.queueSecureInputBuffer(i12, 0, cryptoInfo, j10, i13);
                            }
                        } else {
                            gVar.f490e.queueSecureInputBuffer(i12, 0, cryptoInfo, j10, i13);
                        }
                        break;
                    } catch (RuntimeException e10) {
                        AtomicReference atomicReference2 = gVar.Z;
                        while (!atomicReference2.compareAndSet(null, e10) && atomicReference2.get() == null) {
                        }
                    }
                    fVar = fVar3;
                } else if (i11 == 3) {
                    gVar.f491r0.e();
                } else if (i11 != 4) {
                    AtomicReference atomicReference3 = gVar.Z;
                    IllegalStateException illegalStateException = new IllegalStateException(String.valueOf(message.what));
                    while (!atomicReference3.compareAndSet(null, illegalStateException) && atomicReference3.get() == null) {
                    }
                } else {
                    try {
                        gVar.f490e.setParameters((Bundle) message.obj);
                        break;
                    } catch (RuntimeException e11) {
                        AtomicReference atomicReference4 = gVar.Z;
                        while (!atomicReference4.compareAndSet(null, e11) && atomicReference4.get() == null) {
                        }
                    }
                }
                if (fVar != null) {
                    g.e(fVar);
                    return;
                }
                return;
            case 1:
                int i14 = message.what;
                if (i14 == -3 || i14 == -2 || i14 == -1) {
                    ((DialogInterface.OnClickListener) message.obj).onClick((DialogInterface) ((WeakReference) this.f480b).get(), message.what);
                    return;
                } else {
                    if (i14 != 1) {
                        return;
                    }
                    ((DialogInterface) message.obj).dismiss();
                    return;
                }
            case 2:
                d3 d3Var = (d3) message.obj;
                ge.q qVar = (ge.q) this.f480b;
                if (qVar.t(d3Var)) {
                    c3 c3Var = d3Var.f2240d;
                    c3Var.getClass();
                    c3Var.k();
                    qVar.y(d3Var);
                    return;
                }
                return;
            case 3:
                n2 n2Var = (n2) this.f480b;
                if (n2Var == null) {
                    removeCallbacksAndMessages(null);
                    return;
                }
                androidx.media3.session.legacy.h hVar = n2Var.X;
                Bundle data = message.getData();
                switch (message.what) {
                    case 3:
                        Bundle bundleP = l0.p(data.getBundle("data_options"));
                        ((n2) hVar.f2449a).f2550t0.c(new androidx.media3.session.legacy.t(hVar, new androidx.media3.session.legacy.h(message.replyTo), data.getString("data_media_item_id"), data.getBinder("data_callback_token"), bundleP, 0));
                        return;
                    case 4:
                        ((n2) hVar.f2449a).f2550t0.c(new androidx.media3.session.legacy.u(hVar, new androidx.media3.session.legacy.h(message.replyTo), data.getString("data_media_item_id"), data.getBinder("data_callback_token"), 0));
                        return;
                    case 5:
                        String string = data.getString("data_media_item_id");
                        ResultReceiver resultReceiver = (ResultReceiver) data.getParcelable("data_result_receiver");
                        androidx.media3.session.legacy.h hVar2 = new androidx.media3.session.legacy.h(message.replyTo);
                        hVar.getClass();
                        if (TextUtils.isEmpty(string) || resultReceiver == null) {
                            return;
                        }
                        ((n2) hVar.f2449a).f2550t0.c(new androidx.media3.session.legacy.u(hVar, hVar2, string, resultReceiver, 1));
                        return;
                    case 6:
                        Bundle bundleP2 = l0.p(data.getBundle("data_root_hints"));
                        ((n2) hVar.f2449a).f2550t0.c(new androidx.media3.session.legacy.v(hVar, new androidx.media3.session.legacy.h(message.replyTo), data.getInt("data_calling_uid"), data.getString("data_package_name"), data.getInt("data_calling_pid"), bundleP2));
                        return;
                    case 7:
                        ((n2) hVar.f2449a).f2550t0.c(new rc.k0(i10, hVar, new androidx.media3.session.legacy.h(message.replyTo), z5));
                        return;
                    case 8:
                        Bundle bundleP3 = l0.p(data.getBundle("data_search_extras"));
                        String string2 = data.getString("data_search_query");
                        ResultReceiver resultReceiver2 = (ResultReceiver) data.getParcelable("data_result_receiver");
                        androidx.media3.session.legacy.h hVar3 = new androidx.media3.session.legacy.h(message.replyTo);
                        hVar.getClass();
                        if (TextUtils.isEmpty(string2) || resultReceiver2 == null) {
                            return;
                        }
                        ((n2) hVar.f2449a).f2550t0.c(new androidx.media3.session.legacy.w(hVar, hVar3, string2, bundleP3, resultReceiver2, 0));
                        return;
                    case 9:
                        Bundle bundleP4 = l0.p(data.getBundle("data_custom_action_extras"));
                        String string3 = data.getString("data_custom_action");
                        ResultReceiver resultReceiver3 = (ResultReceiver) data.getParcelable("data_result_receiver");
                        androidx.media3.session.legacy.h hVar4 = new androidx.media3.session.legacy.h(message.replyTo);
                        hVar.getClass();
                        if (TextUtils.isEmpty(string3) || resultReceiver3 == null) {
                            return;
                        }
                        ((n2) hVar.f2449a).f2550t0.c(new androidx.media3.session.legacy.w(hVar, hVar4, string3, bundleP4, resultReceiver3, 1));
                        return;
                    default:
                        l3.b.m("MBServiceCompat", "Unhandled message: " + message + "\n  Service version: 2\n  Client version: " + message.arg1);
                        return;
                }
            case 4:
                a(message);
                return;
            case 5:
                b(message);
                return;
            default:
                byte[] bArr = (byte[]) message.obj;
                if (bArr == null) {
                    return;
                }
                ArrayList arrayList = ((v3.e) this.f480b).f21027y0;
                int size = arrayList.size();
                int i15 = 0;
                while (i15 < size) {
                    Object obj = arrayList.get(i15);
                    i15++;
                    v3.b bVar = (v3.b) obj;
                    bVar.o();
                    if (Arrays.equals(bVar.f21014v, bArr)) {
                        if (message.what == 2 && bVar.f21008p == 4) {
                            int i16 = l0.f14115a;
                            bVar.i(false);
                            return;
                        }
                        return;
                    }
                }
                return;
        }
    }

    @Override // android.os.Handler
    public boolean sendMessageAtTime(Message message, long j10) {
        switch (this.f479a) {
            case 3:
                Bundle data = message.getData();
                ClassLoader classLoader = androidx.media3.session.legacy.h.class.getClassLoader();
                classLoader.getClass();
                data.setClassLoader(classLoader);
                data.putInt("data_calling_uid", Binder.getCallingUid());
                int callingPid = Binder.getCallingPid();
                if (callingPid > 0) {
                    data.putInt("data_calling_pid", callingPid);
                } else if (!data.containsKey("data_calling_pid")) {
                    data.putInt("data_calling_pid", -1);
                }
                break;
        }
        return super.sendMessageAtTime(message, j10);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ e(Looper looper) {
        super(looper);
        this.f479a = 3;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ e(Object obj, Looper looper, int i10) {
        super(looper);
        this.f479a = i10;
        this.f480b = obj;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public e(Looper looper, ge.q qVar) {
        super(looper);
        this.f479a = 2;
        this.f480b = qVar;
    }
}
