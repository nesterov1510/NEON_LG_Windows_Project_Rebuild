package a4;

import a0.y4;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.os.Trace;
import android.text.TextUtils;
import android.view.Surface;
import androidx.media3.session.a5;
import androidx.media3.session.b5;
import androidx.media3.session.c2;
import androidx.media3.session.d2;
import androidx.media3.session.d3;
import androidx.media3.session.e2;
import androidx.media3.session.f5;
import androidx.media3.session.h5;
import androidx.media3.session.j5;
import androidx.media3.session.k3;
import androidx.media3.session.legacy.MediaDescriptionCompat;
import androidx.media3.session.n1;
import androidx.media3.session.p5;
import androidx.media3.session.r1;
import androidx.media3.session.s2;
import androidx.media3.session.s5;
import androidx.media3.session.y3;
import androidx.media3.session.z3;
import androidx.media3.session.z4;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.google.common.util.concurrent.ListenableFuture;
import e4.g0;
import e4.m0;
import i3.a2;
import i3.b2;
import i3.f2;
import i3.g2;
import i3.k0;
import i3.n0;
import i3.u0;
import i3.w0;
import i3.y0;
import i3.z1;
import j$.util.Objects;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicReference;
import l3.l0;
import lc.c3;
import lc.l2;
import lc.x0;
import m0.d1;
import m0.e1;
import okhttp3.internal.ws.WebSocketProtocol;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class x implements d0, ae.a, n1, l3.m, c2, y3, l3.i, z4, l1.i, n4.q, ad.f, d1, gb.d, gb.b, androidx.swiperefreshlayout.widget.j {
    public final /* synthetic */ Object X;
    public final /* synthetic */ Object Y;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f563e;

    public /* synthetic */ x(d1.d dVar, g0.r rVar, ArrayList arrayList) {
        this.f563e = 18;
        this.X = rVar;
        this.Y = arrayList;
    }

    @Override // androidx.media3.session.n1
    public void a(androidx.media3.session.t tVar, int i10) {
        switch (this.f563e) {
            case 2:
                r1 r1Var = (r1) this.X;
                tVar.N(r1Var.f2608c, i10, (Surface) this.Y);
                break;
            case 3:
                r1 r1Var2 = (r1) this.X;
                tVar.R(r1Var2.f2608c, i10, ((n0) this.Y).c(r1Var2.n1()));
                break;
            case 4:
                tVar.l1(((r1) this.X).f2608c, i10, ((g2) this.Y).c());
                break;
            default:
                r1 r1Var3 = (r1) this.X;
                u0 u0Var = (u0) this.Y;
                d2 d2Var = r1Var3.f2608c;
                Bundle bundle = new Bundle();
                bundle.putFloat(u0.f11087e, u0Var.f11088a);
                bundle.putFloat(u0.f, u0Var.f11089b);
                tVar.J(d2Var, i10, bundle);
                break;
        }
    }

    @Override // l3.i
    public void accept(Object obj) {
        switch (this.f563e) {
            case ue.r.CUSTOM_ATTRIBUTES_FIELD_NUMBER /* 12 */:
                b5 b5Var = (b5) this.X;
                g2 g2VarB = (g2) this.Y;
                j5 j5Var = (j5) obj;
                x0 x0Var = g2VarB.H;
                if (!x0Var.isEmpty()) {
                    f2 f2VarC = g2VarB.a().c();
                    c3 it = x0Var.values().iterator();
                    while (it.hasNext()) {
                        i3.c2 c2Var = (i3.c2) it.next();
                        b2 b2Var = (b2) b5Var.f2201g.u0.get(c2Var.f10659a.f10637b);
                        if (b2Var == null || c2Var.f10659a.f10636a != b2Var.f10636a) {
                            f2VarC.a(c2Var);
                        } else {
                            f2VarC.a(new i3.c2(b2Var, c2Var.f10660b));
                        }
                    }
                    g2VarB = f2VarC.b();
                }
                j5Var.p0(g2VarB);
                break;
            case ue.r.PERF_SESSIONS_FIELD_NUMBER /* 13 */:
                b5 b5Var2 = (b5) this.X;
                d3 d3Var = (d3) this.Y;
                s2 s2Var = (s2) b5Var2.f2199d.get();
                if (s2Var != null && !s2Var.o()) {
                    s2Var.l(d3Var, false);
                    break;
                }
                break;
            case 14:
                b5 b5Var3 = (b5) this.X;
                Surface surface = (Surface) this.Y;
                j5 j5Var2 = (j5) obj;
                ((s2) b5Var3.f2199d.get()).getClass();
                if (surface != null) {
                    a5 a5Var = new a5(surface);
                    b5Var3.f2203j = a5Var;
                    j5Var2.Y(a5Var);
                } else {
                    j5Var2.Y(null);
                    b5Var3.f2203j = null;
                }
                break;
            default:
                androidx.appcompat.widget.c0 c0Var = (androidx.appcompat.widget.c0) this.X;
                ((m0) obj).L(c0Var.X, (g0) c0Var.Y, (e4.c0) this.Y);
                break;
        }
    }

    @Override // a4.d0
    public int b(Object obj) {
        Context context = (Context) this.X;
        androidx.media3.common.b bVar = (androidx.media3.common.b) this.Y;
        s sVar = (s) obj;
        String str = sVar.f522b;
        return ((str.equals(bVar.f2125o) || str.equals(e0.c(bVar))) && sVar.c(context, bVar, false) && sVar.d(bVar)) ? 1 : 0;
    }

    @Override // n4.q
    public n4.n[] c(Uri uri, Map map) {
        e4.u uVar = (e4.u) this.X;
        androidx.media3.common.b bVar = (androidx.media3.common.b) this.Y;
        return new n4.n[]{uVar.f7511c.q(bVar) ? new k5.h(uVar.f7511c.p(bVar)) : new e4.t(bVar)};
    }

    @Override // androidx.media3.session.y3
    public void d(d3 d3Var) {
        switch (this.f563e) {
            case 10:
                ((androidx.media3.session.d) this.Y).h(((z3) this.X).f2801g.f2675t);
                break;
            default:
                z3 z3Var = (z3) this.X;
                MediaDescriptionCompat mediaDescriptionCompat = (MediaDescriptionCompat) this.Y;
                z3Var.getClass();
                String str = mediaDescriptionCompat.f2401e;
                if (TextUtils.isEmpty(str)) {
                    l3.b.m("MediaSessionLegacyStub", "onRemoveQueueItem(): Media ID shouldn't be null");
                } else {
                    j5 j5Var = z3Var.f2801g.f2675t;
                    if (j5Var.g1(17)) {
                        a2 a2VarG0 = j5Var.G0();
                        z1 z1Var = new z1();
                        for (int i10 = 0; i10 < a2VarG0.o(); i10++) {
                            if (TextUtils.equals(a2VarG0.m(i10, z1Var, 0L).f11156c.f10876a, str)) {
                                j5Var.R(i10);
                            }
                        }
                    } else {
                        l3.b.m("MediaSessionLegacyStub", "Can't remove item by ID without COMMAND_GET_TIMELINE being available");
                    }
                }
                break;
        }
    }

    @Override // gb.b
    public Object f(gb.i iVar) {
        ge.j jVar = (ge.j) this.X;
        String str = (String) this.Y;
        synchronized (jVar) {
            ((j1.e) jVar.f8923b).remove(str);
        }
        return iVar;
    }

    @Override // ae.a
    public void g(ae.b bVar) {
        ae.a aVar = (ae.a) this.X;
        ae.a aVar2 = (ae.a) this.Y;
        aVar.g(bVar);
        aVar2.g(bVar);
    }

    @Override // ad.f
    public Object h(y4 y4Var) {
        String str = (String) this.X;
        ad.c cVar = (ad.c) this.Y;
        try {
            Trace.beginSection(str);
            return cVar.f.h(y4Var);
        } finally {
            Trace.endSection();
        }
    }

    @Override // l1.i
    public Object i(l1.h hVar) {
        switch (this.f563e) {
            case 18:
                g0.r rVar = (g0.r) this.X;
                ArrayList arrayList = (ArrayList) this.Y;
                d1.c cVar = new d1.c(hVar, rVar);
                arrayList.add(cVar);
                ((m0.a0) rVar).h(tc.b.u(), cVar);
                return "waitForCaptureResult";
            case 19:
                d1.u uVar = (d1.u) this.X;
                Surface surface = (Surface) this.Y;
                y6.a.e("TextureViewImpl", "Surface set on Preview.");
                uVar.h.a(surface, tc.b.u(), new d1.q(1, hVar));
                return "provideSurface[request=" + uVar.h + " surface=" + surface + "]";
            case 23:
                g0.w wVar = (g0.w) this.Y;
                Context context = (Context) this.X;
                Executor executor = wVar.f8442d;
                executor.execute(new g0.v(wVar, context, executor, 1, hVar, SystemClock.elapsedRealtime()));
                return "CameraX initInternal";
            default:
                g0.z1 z1Var = (g0.z1) this.X;
                ((AtomicReference) this.Y).set(hVar);
                return "SurfaceRequest-surface-recreation(" + z1Var.hashCode() + ")";
        }
    }

    @Override // l3.m
    public void invoke(Object obj) {
        switch (this.f563e) {
            case 5:
                ((y0) obj).l(((Integer) this.Y).intValue(), (k0) this.X);
                break;
            default:
                n nVar = (n) this.X;
                Integer num = (Integer) this.Y;
                ((y0) obj).l(num.intValue(), ((h5) nVar.f515a).s());
                break;
        }
    }

    @Override // androidx.media3.session.z4
    public Object j(final s2 s2Var, final d3 d3Var, int i10) {
        switch (this.f563e) {
            case WebSocketProtocol.B0_MASK_OPCODE /* 15 */:
                return s2Var.B(d3Var, (String) this.X, (e2) this.Y);
            case WebSocketProtocol.B0_FLAG_RSV3 /* 16 */:
                z4 z4Var = (z4) this.X;
                final k3 k3Var = (k3) this.Y;
                if (s2Var.o()) {
                    return rc.m0.e(new s5(-100));
                }
                final int i11 = 0;
                return l0.n0((ListenableFuture) z4Var.j(s2Var, d3Var, i10), new rc.z() { // from class: androidx.media3.session.s4
                    @Override // rc.z
                    public final ListenableFuture apply(Object obj) {
                        int i12 = i11;
                        Object obj2 = k3Var;
                        switch (i12) {
                            case 0:
                                s2 s2Var2 = s2Var;
                                Handler handler = s2Var2.f2667l;
                                a4.b bVar = new a4.b(s2Var2, d3Var, new androidx.fragment.app.d(s2Var2, (k3) obj2, (e3) obj, 8));
                                s5 s5Var = new s5(0);
                                int i13 = l3.l0.f14115a;
                                rc.a1 a1Var = new rc.a1();
                                l3.l0.c0(handler, new androidx.fragment.app.d(a1Var, bVar, s5Var, 15));
                                return a1Var;
                            default:
                                List list = (List) obj;
                                s2 s2Var3 = s2Var;
                                Handler handler2 = s2Var3.f2667l;
                                d3 d3Var2 = d3Var;
                                a4.b bVar2 = new a4.b(s2Var3, d3Var2, new h(s2Var3, (y4) obj2, d3Var2, list, 11));
                                s5 s5Var2 = new s5(0);
                                int i14 = l3.l0.f14115a;
                                rc.a1 a1Var2 = new rc.a1();
                                l3.l0.c0(handler2, new androidx.fragment.app.d(a1Var2, bVar2, s5Var2, 15));
                                return a1Var2;
                        }
                    }
                });
            default:
                z4 z4Var2 = (z4) this.X;
                final androidx.media3.session.y4 y4Var = (androidx.media3.session.y4) this.Y;
                if (s2Var.o()) {
                    return rc.m0.e(new s5(-100));
                }
                final int i12 = 1;
                return l0.n0((ListenableFuture) z4Var2.j(s2Var, d3Var, i10), new rc.z() { // from class: androidx.media3.session.s4
                    @Override // rc.z
                    public final ListenableFuture apply(Object obj) {
                        int i13 = i12;
                        Object obj2 = y4Var;
                        switch (i13) {
                            case 0:
                                s2 s2Var2 = s2Var;
                                Handler handler = s2Var2.f2667l;
                                a4.b bVar = new a4.b(s2Var2, d3Var, new androidx.fragment.app.d(s2Var2, (k3) obj2, (e3) obj, 8));
                                s5 s5Var = new s5(0);
                                int i14 = l3.l0.f14115a;
                                rc.a1 a1Var = new rc.a1();
                                l3.l0.c0(handler, new androidx.fragment.app.d(a1Var, bVar, s5Var, 15));
                                return a1Var;
                            default:
                                List list = (List) obj;
                                s2 s2Var3 = s2Var;
                                Handler handler2 = s2Var3.f2667l;
                                d3 d3Var2 = d3Var;
                                a4.b bVar2 = new a4.b(s2Var3, d3Var2, new h(s2Var3, (y4) obj2, d3Var2, list, 11));
                                s5 s5Var2 = new s5(0);
                                int i15 = l3.l0.f14115a;
                                rc.a1 a1Var2 = new rc.a1();
                                l3.l0.c0(handler2, new androidx.fragment.app.d(a1Var2, bVar2, s5Var2, 15));
                                return a1Var2;
                        }
                    }
                });
        }
    }

    @Override // androidx.media3.session.c2
    public void k(r1 r1Var) {
        boolean z5;
        boolean z6;
        boolean z9;
        switch (this.f563e) {
            case 8:
                r1Var.v1((h5) this.X, (f5) this.Y);
                break;
            default:
                p5 p5Var = (p5) this.X;
                w0 w0Var = (w0) this.Y;
                androidx.media3.session.b0 b0Var = r1Var.f2606a;
                if (r1Var.b1()) {
                    boolean zEquals = Objects.equals(r1Var.f2627x, w0Var);
                    boolean zEquals2 = Objects.equals(r1Var.f2626w, p5Var);
                    if (!zEquals || !zEquals2) {
                        r1Var.f2626w = p5Var;
                        if (zEquals) {
                            z5 = false;
                        } else {
                            r1Var.f2627x = w0Var;
                            w0 w0Var2 = r1Var.f2629z;
                            w0 w0VarD0 = r1Var.D0(w0Var, r1Var.f2628y);
                            r1Var.f2629z = w0VarD0;
                            z5 = !w0VarD0.equals(w0Var2);
                        }
                        if (!zEquals2 || z5) {
                            l2 l2Var = r1Var.f2624u;
                            l2 l2Var2 = r1Var.f2625v;
                            l2 l2VarB1 = r1.B1(r1Var.f2623t, r1Var.f2622s, p5Var, r1Var.f2629z, r1Var.J);
                            r1Var.f2624u = l2VarB1;
                            r1Var.f2625v = r1.A1(l2VarB1, r1Var.f2622s, r1Var.J, p5Var, r1Var.f2629z, r1Var.n1());
                            z6 = !r1Var.f2624u.equals(l2Var);
                            z9 = !r1Var.f2625v.equals(l2Var2);
                        } else {
                            z6 = false;
                            z9 = false;
                        }
                        if (z5) {
                            r1Var.f2612i.f(13, new androidx.media3.session.l0(r1Var, 0));
                        }
                        if (!zEquals2) {
                            b0Var.getClass();
                            ji.k.A(Looper.myLooper() == b0Var.f2187r0.getLooper());
                            b0Var.Z.d();
                        }
                        if (z9) {
                            b0Var.getClass();
                            ji.k.A(Looper.myLooper() == b0Var.f2187r0.getLooper());
                            b0Var.Z.getClass();
                        }
                        if (z6) {
                            b0Var.getClass();
                            ji.k.A(Looper.myLooper() == b0Var.f2187r0.getLooper());
                            b0Var.Z.h();
                        }
                    }
                    break;
                }
                break;
        }
    }

    @Override // m0.d1
    public void l(e1 e1Var) {
        e4.s sVar = (e4.s) this.X;
        d1 d1Var = (d1) this.Y;
        sVar.getClass();
        d1Var.l(sVar);
    }

    @Override // androidx.swiperefreshlayout.widget.j
    public void m() {
        switch (this.f563e) {
            case 28:
                go.d1 d1Var = (go.d1) this.X;
                y5.h hVar = (y5.h) this.Y;
                d1Var.m0();
                ((SwipeRefreshLayout) d1Var.j0().f8938d).setRefreshing(hVar.f22635a instanceof y5.x);
                break;
            default:
                go.n1 n1Var = (go.n1) this.X;
                y5.h hVar2 = (y5.h) this.Y;
                n1Var.p0();
                n1Var.l0().f7095x.setRefreshing(hVar2.f22635a instanceof y5.x);
                break;
        }
    }

    @Override // gb.d
    public void onComplete(gb.i iVar) {
        ((ge.h) this.X).a((Intent) this.Y);
    }

    public /* synthetic */ x(g0.w wVar, Context context) {
        this.f563e = 23;
        this.Y = wVar;
        this.X = context;
    }

    public /* synthetic */ x(Object obj, Object obj2, int i10) {
        this.f563e = i10;
        this.X = obj;
        this.Y = obj2;
    }
}
