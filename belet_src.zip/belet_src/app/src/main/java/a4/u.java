package a4;

import okhttp3.internal.url._UrlKt;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class u extends Exception {
    public final boolean X;
    public final s Y;
    public final String Z;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final String f531e;

    public u(androidx.media3.common.b bVar, a0 a0Var, boolean z5, int i10) {
        this("Decoder init failed: [" + i10 + "], " + bVar, a0Var, bVar.f2125o, z5, null, "androidx.media3.exoplayer.mediacodec.MediaCodecRenderer_" + (i10 < 0 ? "neg_" : _UrlKt.FRAGMENT_ENCODE_SET) + Math.abs(i10));
    }

    public u(String str, Throwable th2, String str2, boolean z5, s sVar, String str3) {
        super(str, th2);
        this.f531e = str2;
        this.X = z5;
        this.Y = sVar;
        this.Z = str3;
    }
}
