package a4;

import android.media.MediaCodecInfo;
import android.os.Build;
import android.util.Pair;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import lc.l2;
import lc.q0;
import lc.u0;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public abstract class e0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final HashMap f481a = new HashMap();

    public static void a(String str, ArrayList arrayList) {
        if ("audio/raw".equals(str)) {
            if (Build.VERSION.SDK_INT < 26 && Build.DEVICE.equals("R9") && arrayList.size() == 1 && ((s) arrayList.get(0)).f521a.equals("OMX.MTK.AUDIO.DECODER.RAW")) {
                arrayList.add(s.i("OMX.google.raw.decoder", "audio/raw", "audio/raw", null, false, true, false, false));
            }
            Collections.sort(arrayList, new y(0, new l()));
        }
        if (Build.VERSION.SDK_INT >= 32 || arrayList.size() <= 1 || !"OMX.qti.audio.decoder.flac".equals(((s) arrayList.get(0)).f521a)) {
            return;
        }
        arrayList.add((s) arrayList.remove(0));
    }

    public static MediaCodecInfo.CodecProfileLevel b(int i10, int i11) {
        MediaCodecInfo.CodecProfileLevel codecProfileLevel = new MediaCodecInfo.CodecProfileLevel();
        codecProfileLevel.profile = i10;
        codecProfileLevel.level = i11;
        return codecProfileLevel;
    }

    public static String c(androidx.media3.common.b bVar) {
        Pair pairB;
        String str = bVar.f2125o;
        String str2 = bVar.f2125o;
        if ("audio/eac3-joc".equals(str)) {
            return "audio/eac3";
        }
        if ("video/dolby-vision".equals(str2) && (pairB = l3.f.b(bVar)) != null) {
            int iIntValue = ((Integer) pairB.first).intValue();
            if (iIntValue == 16 || iIntValue == 256) {
                return "video/hevc";
            }
            if (iIntValue == 512) {
                return "video/avc";
            }
            if (iIntValue == 1024) {
                i3.m mVar = bVar.E;
                if (mVar != null && mVar.f10905c == 6 && mVar.f10904b == 1) {
                    return null;
                }
                return "video/av01";
            }
        }
        if ("video/mv-hevc".equals(str2)) {
            return "video/hevc";
        }
        return null;
    }

    public static String d(MediaCodecInfo mediaCodecInfo, String str, String str2) {
        for (String str3 : mediaCodecInfo.getSupportedTypes()) {
            if (str3.equalsIgnoreCase(str2)) {
                return str3;
            }
        }
        if (str2.equals("video/dolby-vision")) {
            if ("OMX.MS.HEVCDV.Decoder".equals(str)) {
                return "video/hevcdv";
            }
            if ("OMX.RTK.video.decoder".equals(str) || "OMX.realtek.video.decoder.tunneled".equals(str)) {
                return "video/dv_hevc";
            }
            return null;
        }
        if (str2.equals("video/mv-hevc")) {
            if ("c2.qti.mvhevc.decoder".equals(str) || "c2.qti.mvhevc.decoder.secure".equals(str)) {
                return "video/x-mvhevc";
            }
            return null;
        }
        if (str2.equals("audio/alac") && "OMX.lge.alac.decoder".equals(str)) {
            return "audio/x-lg-alac";
        }
        if (str2.equals("audio/flac") && "OMX.lge.flac.decoder".equals(str)) {
            return "audio/x-lg-flac";
        }
        if (str2.equals("audio/ac3") && "OMX.lge.ac3.decoder".equals(str)) {
            return "audio/lg-ac3";
        }
        return null;
    }

    public static synchronized List e(String str, boolean z5, boolean z6) {
        try {
            z zVar = new z(str, z5, z6);
            HashMap map = f481a;
            List list = (List) map.get(zVar);
            if (list != null) {
                return list;
            }
            ArrayList arrayListF = f(zVar, new c0(z5, z6, str.equals("video/mv-hevc")));
            if (z5 && arrayListF.isEmpty() && Build.VERSION.SDK_INT == 23) {
                arrayListF = f(zVar, new dc.f(1));
                if (!arrayListF.isEmpty()) {
                    l3.b.m("MediaCodecUtil", "MediaCodecList API didn't list secure decoder for: " + str + ". Assuming: " + ((s) arrayListF.get(0)).f521a);
                }
            }
            a(str, arrayListF);
            u0 u0VarL = u0.l(arrayListF);
            map.put(zVar, u0VarL);
            return u0VarL;
        } catch (Throwable th2) {
            throw th2;
        }
    }

    /* JADX WARN: Code duplicated, block: B:15:0x0047  */
    /* JADX WARN: Code duplicated, block: B:74:0x0119 A[Catch: Exception -> 0x0163, TRY_ENTER, TryCatch #4 {Exception -> 0x0163, blocks: (B:3:0x000a, B:5:0x001f, B:7:0x0029, B:77:0x0138, B:10:0x0035, B:13:0x0040, B:71:0x0111, B:74:0x0119, B:76:0x011f, B:78:0x0140, B:79:0x0161), top: B:92:0x000a }] */
    /* JADX WARN: Code duplicated, block: B:96:0x0140 A[ADDED_TO_REGION, REMOVE, SYNTHETIC] */
    public static ArrayList f(z zVar, b0 b0Var) throws a0 {
        boolean z5;
        String str;
        int i10;
        int i11;
        z zVar2 = zVar;
        boolean z6 = zVar2.f566b;
        try {
            ArrayList arrayList = new ArrayList();
            String str2 = zVar2.f565a;
            int iF = b0Var.f();
            boolean zH = b0Var.h();
            int i12 = 0;
            while (i12 < iF) {
                MediaCodecInfo mediaCodecInfoB = b0Var.b(i12);
                int i13 = Build.VERSION.SDK_INT;
                if (i13 < 29 || !mediaCodecInfoB.isAlias()) {
                    String name = mediaCodecInfoB.getName();
                    if (h(mediaCodecInfoB, name, zH, str2)) {
                        int i14 = i12;
                        String strD = d(mediaCodecInfoB, name, str2);
                        if (strD == null) {
                            z5 = zH;
                            i10 = i14;
                        } else {
                            try {
                                MediaCodecInfo.CodecCapabilities capabilitiesForType = mediaCodecInfoB.getCapabilitiesForType(strD);
                                boolean zC = b0Var.c("tunneled-playback", strD, capabilitiesForType);
                                boolean zD = b0Var.d("tunneled-playback", capabilitiesForType);
                                boolean z9 = zVar2.f567c;
                                if (!z9 && zD) {
                                    z5 = zH;
                                    i10 = i14;
                                } else if (!z9 || zC) {
                                    boolean zC2 = b0Var.c("secure-playback", strD, capabilitiesForType);
                                    boolean zD2 = b0Var.d("secure-playback", capabilitiesForType);
                                    if (!z6 && zD2) {
                                        z5 = zH;
                                        i10 = i14;
                                    } else if (!z6 || zC2) {
                                        boolean zIsVendor = true;
                                        boolean zIsHardwareAccelerated = i13 >= 29 ? mediaCodecInfoB.isHardwareAccelerated() : !i(mediaCodecInfoB, str2);
                                        z5 = zH;
                                        try {
                                            boolean zI = i(mediaCodecInfoB, str2);
                                            if (i13 >= 29) {
                                                zIsVendor = mediaCodecInfoB.isVendor();
                                            } else {
                                                String strI = g0.c.I(mediaCodecInfoB.getName());
                                                if (strI.startsWith("omx.google.") || strI.startsWith("c2.android.") || strI.startsWith("c2.google.")) {
                                                    zIsVendor = false;
                                                }
                                            }
                                            if (!(z5 && z6 == zC2) && (z5 || z6)) {
                                                boolean z10 = zIsHardwareAccelerated;
                                                i11 = i14;
                                                boolean z11 = zIsVendor;
                                                if (!z5 && zC2) {
                                                    i10 = i11;
                                                    str = name;
                                                    try {
                                                        arrayList.add(s.i(name + ".secure", str2, strD, capabilitiesForType, z10, zI, z11, true));
                                                        break;
                                                    } catch (Exception e3) {
                                                        e = e3;
                                                        if (Build.VERSION.SDK_INT == 23) {
                                                        }
                                                        l3.b.d("MediaCodecUtil", "Failed to query codec " + str + " (" + strD + ")");
                                                        throw e;
                                                    }
                                                }
                                            } else {
                                                boolean z12 = zIsHardwareAccelerated;
                                                i11 = i14;
                                                try {
                                                    arrayList.add(s.i(name, str2, strD, capabilitiesForType, z12, zI, zIsVendor, false));
                                                } catch (Exception e10) {
                                                    e = e10;
                                                    i10 = i11;
                                                    str = name;
                                                    if (Build.VERSION.SDK_INT == 23 || arrayList.isEmpty()) {
                                                        l3.b.d("MediaCodecUtil", "Failed to query codec " + str + " (" + strD + ")");
                                                        throw e;
                                                    }
                                                    l3.b.d("MediaCodecUtil", "Skipping codec " + str + " (failed to query capabilities)");
                                                }
                                            }
                                            i10 = i11;
                                        } catch (Exception e11) {
                                            e = e11;
                                            str = name;
                                            i10 = i14;
                                            if (Build.VERSION.SDK_INT == 23) {
                                            }
                                            l3.b.d("MediaCodecUtil", "Failed to query codec " + str + " (" + strD + ")");
                                            throw e;
                                        }
                                    } else {
                                        z5 = zH;
                                        i10 = i14;
                                    }
                                } else {
                                    z5 = zH;
                                    i10 = i14;
                                }
                            } catch (Exception e12) {
                                e = e12;
                                z5 = zH;
                                str = name;
                            }
                        }
                    } else {
                        z5 = zH;
                        i10 = i12;
                    }
                } else {
                    z5 = zH;
                    i10 = i12;
                }
                i12 = i10 + 1;
                zVar2 = zVar;
                zH = z5;
            }
            return arrayList;
        } catch (Exception e13) {
            throw new a0("Failed to query underlying media codecs", e13);
        }
    }

    public static l2 g(l lVar, androidx.media3.common.b bVar, boolean z5, boolean z6) {
        List listA = lVar.a(bVar.f2125o, z5, z6);
        String strC = c(bVar);
        List listA2 = strC == null ? l2.f14447r0 : lVar.a(strC, z5, z6);
        q0 q0VarI = u0.i();
        q0VarI.d(listA);
        q0VarI.d(listA2);
        return q0VarI.g();
    }

    public static boolean h(MediaCodecInfo mediaCodecInfo, String str, boolean z5, String str2) {
        if (mediaCodecInfo.isEncoder()) {
            return false;
        }
        if (!z5 && str.endsWith(".secure")) {
            return false;
        }
        int i10 = Build.VERSION.SDK_INT;
        if (i10 < 24 && (("OMX.SEC.aac.dec".equals(str) || "OMX.Exynos.AAC.Decoder".equals(str)) && "samsung".equals(Build.MANUFACTURER))) {
            String str3 = Build.DEVICE;
            if (str3.startsWith("zeroflte") || str3.startsWith("zerolte") || str3.startsWith("zenlte") || "SC-05G".equals(str3) || "marinelteatt".equals(str3) || "404SC".equals(str3) || "SC-04G".equals(str3) || "SCV31".equals(str3)) {
                return false;
            }
        }
        return (i10 == 23 && "audio/eac3-joc".equals(str2) && "OMX.MTK.AUDIO.DECODER.DSPAC3".equals(str)) ? false : true;
    }

    public static boolean i(MediaCodecInfo mediaCodecInfo, String str) {
        if (Build.VERSION.SDK_INT >= 29) {
            return mediaCodecInfo.isSoftwareOnly();
        }
        if (i3.q0.i(str)) {
            return true;
        }
        String strI = g0.c.I(mediaCodecInfo.getName());
        if (strI.startsWith("arc.")) {
            return false;
        }
        if (strI.startsWith("omx.google.") || strI.startsWith("omx.ffmpeg.")) {
            return true;
        }
        if ((strI.startsWith("omx.sec.") && strI.contains(".sw.")) || strI.equals("omx.qcom.video.decoder.hevcswvdec") || strI.startsWith("c2.android.") || strI.startsWith("c2.google.")) {
            return true;
        }
        return (strI.startsWith("omx.") || strI.startsWith("c2.")) ? false : true;
    }
}
