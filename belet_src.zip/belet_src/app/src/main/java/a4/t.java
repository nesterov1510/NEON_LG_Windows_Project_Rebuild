package a4;

import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.Typeface;
import android.media.AudioDescriptor;
import android.media.CamcorderProfile;
import android.media.EncoderProfiles;
import android.media.MediaDrm;
import android.media.MediaFormat;
import android.media.metrics.LogSessionId;
import android.media.session.MediaSession;
import android.os.Build;
import android.view.Display;
import android.view.RoundedCorner;
import androidx.media3.session.legacy.m0;
import i3.r0;
import j$.util.Comparator;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.TreeSet;
import l3.l0;
import lc.l2;
import lc.u0;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public abstract class t {
    public static Bitmap a(byte[] bArr, int i10, int i11) throws IOException {
        BitmapFactory.Options options;
        int i12 = 0;
        if (i11 != -1) {
            options = new BitmapFactory.Options();
            options.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(bArr, 0, i10, options);
            options.inJustDecodeBounds = false;
            options.inSampleSize = 1;
            for (int iMax = Math.max(options.outWidth, options.outHeight); iMax > i11; iMax /= 2) {
                options.inSampleSize *= 2;
            }
        } else {
            options = null;
        }
        Bitmap bitmapDecodeByteArray = BitmapFactory.decodeByteArray(bArr, 0, i10, options);
        if (options != null) {
            options.inSampleSize = 1;
        }
        if (bitmapDecodeByteArray == null) {
            throw r0.a(new IllegalStateException(), "Could not decode image data");
        }
        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(bArr);
        try {
            z2.g gVar = new z2.g(byteArrayInputStream);
            byteArrayInputStream.close();
            switch (gVar.c(1, "Orientation")) {
                case 3:
                case 4:
                    i12 = 180;
                    break;
                case 5:
                case 8:
                    i12 = 270;
                    break;
                case 6:
                case 7:
                    i12 = 90;
                    break;
            }
            if (i12 == 0) {
                return bitmapDecodeByteArray;
            }
            Matrix matrix = new Matrix();
            matrix.postRotate(i12);
            return Bitmap.createBitmap(bitmapDecodeByteArray, 0, 0, bitmapDecodeByteArray.getWidth(), bitmapDecodeByteArray.getHeight(), matrix, false);
        } catch (Throwable th2) {
            try {
                byteArrayInputStream.close();
                throw th2;
            } catch (Throwable th3) {
                th2.addSuppressed(th3);
                throw th2;
            }
        }
    }

    public static m0.h b(EncoderProfiles encoderProfiles) {
        int defaultDurationSeconds = encoderProfiles.getDefaultDurationSeconds();
        int recommendedFileFormat = encoderProfiles.getRecommendedFileFormat();
        List<EncoderProfiles.AudioProfile> audioProfiles = encoderProfiles.getAudioProfiles();
        ArrayList arrayList = new ArrayList();
        for (EncoderProfiles.AudioProfile audioProfile : audioProfiles) {
            arrayList.add(new m0.g(audioProfile.getCodec(), audioProfile.getMediaType(), audioProfile.getBitrate(), audioProfile.getSampleRate(), audioProfile.getChannels(), audioProfile.getProfile()));
        }
        List<EncoderProfiles.VideoProfile> videoProfiles = encoderProfiles.getVideoProfiles();
        ArrayList arrayList2 = new ArrayList();
        for (EncoderProfiles.VideoProfile videoProfile : videoProfiles) {
            arrayList2.add(new m0.i(videoProfile.getCodec(), videoProfile.getMediaType(), videoProfile.getBitrate(), videoProfile.getFrameRate(), videoProfile.getWidth(), videoProfile.getHeight(), videoProfile.getProfile(), 8, 0, 0));
        }
        return m0.h.a(defaultDurationSeconds, recommendedFileFormat, arrayList, arrayList2);
    }

    public static EncoderProfiles c(int i10, String str) {
        return CamcorderProfile.getAll(str, i10);
    }

    public static u0 d(List list) {
        if (Build.VERSION.SDK_INT < 31 || list == null) {
            lc.r0 r0Var = u0.X;
            return l2.f14447r0;
        }
        TreeSet treeSet = new TreeSet(Comparator.EL.reversed(Comparator.CC.comparing(new hk.c0(5))));
        Iterator it = list.iterator();
        while (it.hasNext()) {
            AudioDescriptor audioDescriptorB = t3.e.b(it.next());
            if (audioDescriptorB.getStandard() == 1) {
                byte[] descriptor = audioDescriptorB.getDescriptor();
                if (descriptor.length != 3) {
                    l3.b.m("AudioDescriptorUtil", "Invalid SAD length: " + descriptor.length);
                } else {
                    byte b10 = descriptor[0];
                    int i10 = (b10 & 7) + 1;
                    if (((b10 >> 3) & 15) == 1) {
                        treeSet.add(Integer.valueOf(l0.w(i10)));
                    }
                }
            }
        }
        return u0.l(treeSet);
    }

    public static j2.t e(Display display, int i10) {
        RoundedCorner roundedCorner;
        int i11;
        if (Build.VERSION.SDK_INT < 31 || (roundedCorner = display.getRoundedCorner(i10)) == null) {
            return null;
        }
        int position = roundedCorner.getPosition();
        if (position != 0) {
            i11 = 1;
            if (position != 1) {
                i11 = 2;
                if (position != 2) {
                    i11 = 3;
                    if (position != 3) {
                        throw new IllegalArgumentException(kotlin.jvm.internal.p.z(position, "Invalid position: "));
                    }
                }
            }
        } else {
            i11 = 0;
        }
        return new j2.t(i11, roundedCorner.getRadius(), roundedCorner.getCenter());
    }

    public static boolean f(PendingIntent pendingIntent) {
        return pendingIntent.isActivity();
    }

    public static boolean g(String str) {
        String MANUFACTURER = Build.MANUFACTURER;
        kotlin.jvm.internal.q.f(MANUFACTURER, "MANUFACTURER");
        if (MANUFACTURER.equalsIgnoreCase(str)) {
            return true;
        }
        String BRAND = Build.BRAND;
        kotlin.jvm.internal.q.f(BRAND, "BRAND");
        return BRAND.equalsIgnoreCase(str);
    }

    public static boolean h() {
        if (Build.VERSION.SDK_INT >= 31 && "Spreadtrum".equalsIgnoreCase(Build.SOC_MANUFACTURER)) {
            return true;
        }
        String HARDWARE = Build.HARDWARE;
        kotlin.jvm.internal.q.f(HARDWARE, "HARDWARE");
        Locale locale = Locale.ROOT;
        String lowerCase = HARDWARE.toLowerCase(locale);
        kotlin.jvm.internal.q.f(lowerCase, "toLowerCase(...)");
        if (mj.t.Z(lowerCase, "ums", false)) {
            return true;
        }
        if (g("Itel")) {
            String lowerCase2 = HARDWARE.toLowerCase(locale);
            kotlin.jvm.internal.q.f(lowerCase2, "toLowerCase(...)");
            if (mj.t.Z(lowerCase2, "sp", false)) {
                return true;
            }
        }
        return false;
    }

    public static Bitmap i(Bitmap bitmap) {
        return Build.VERSION.SDK_INT >= 31 ? bitmap.asShared() : bitmap;
    }

    public static Typeface j(Configuration configuration, Typeface typeface) {
        int i10;
        if (Build.VERSION.SDK_INT < 31 || (i10 = configuration.fontWeightAdjustment) == Integer.MAX_VALUE || i10 == 0 || typeface == null) {
            return null;
        }
        return Typeface.create(typeface, tc.b.f(typeface.getWeight() + configuration.fontWeightAdjustment, 1, 1000), typeface.isItalic());
    }

    public static boolean k(MediaDrm mediaDrm, String str, int i10) {
        return mediaDrm.requiresSecureDecoder(str, i10);
    }

    public static void l(MediaDrm mediaDrm, byte[] bArr, t3.j jVar) {
        LogSessionId logSessionIdA = jVar.a();
        if (logSessionIdA.equals(LogSessionId.LOG_SESSION_ID_NONE)) {
            return;
        }
        MediaDrm.PlaybackComponent playbackComponent = mediaDrm.getPlaybackComponent(bArr);
        playbackComponent.getClass();
        playbackComponent.setLogSessionId(logSessionIdA);
    }

    public static void m(n nVar, t3.j jVar) {
        LogSessionId logSessionIdA = jVar.a();
        if (logSessionIdA.equals(LogSessionId.LOG_SESSION_ID_NONE)) {
            return;
        }
        ((MediaFormat) nVar.f516b).setString("log-session-id", logSessionIdA.getStringId());
    }

    public static void n(androidx.media3.session.legacy.r0 r0Var, ComponentName componentName) {
        try {
            MediaSession mediaSession = ((m0) r0Var.X).f2470a;
            mediaSession.getClass();
            mediaSession.setMediaButtonBroadcastReceiver(componentName);
        } catch (IllegalArgumentException e3) {
            if (!Build.MANUFACTURER.equals("motorola")) {
                throw e3;
            }
            l3.b.e("MediaSessionLegacyStub", "caught IllegalArgumentException on a motorola device when attempting to set the media button broadcast receiver. See https://github.com/androidx/media/issues/1730 for details.", e3);
        }
    }
}
