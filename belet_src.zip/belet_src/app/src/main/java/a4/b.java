package a4;

import a0.w4;
import android.content.Context;
import android.content.Intent;
import android.media.session.MediaController;
import android.os.BadParcelableException;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.os.RemoteException;
import android.os.ResultReceiver;
import android.os.StrictMode;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import androidx.media3.session.b5;
import androidx.media3.session.c2;
import androidx.media3.session.d3;
import androidx.media3.session.d4;
import androidx.media3.session.i2;
import androidx.media3.session.j5;
import androidx.media3.session.k2;
import androidx.media3.session.l2;
import androidx.media3.session.legacy.MediaSessionCompat$Token;
import androidx.media3.session.legacy.r0;
import androidx.media3.session.m2;
import androidx.media3.session.n2;
import androidx.media3.session.r1;
import androidx.media3.session.s2;
import androidx.media3.session.s5;
import androidx.media3.session.t1;
import androidx.media3.session.w1;
import androidx.media3.session.y1;
import androidx.media3.session.z2;
import com.google.android.material.textfield.TextInputLayout;
import com.google.common.util.concurrent.ListenableFuture;
import e4.y0;
import g0.z1;
import g6.g0;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import kotlinx.coroutines.q0;
import l3.l0;
import lc.u0;
import okhttp3.internal.ws.WebSocketProtocol;
import rc.a1;
import rc.p0;
import tm.belet.films.R;
import tm.belet.films.domain.background.PlaybackService;
import tm.belet.films.presentation.widgets.indicator.ProgressDotsIndicator;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class b implements Runnable {
    public final /* synthetic */ Object X;
    public final /* synthetic */ Object Y;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f471e;

    public /* synthetic */ b(s2 s2Var, d3 d3Var, Runnable runnable) {
        this.f471e = 12;
        this.X = s2Var;
        this.Y = runnable;
    }

    private final void a() {
        ae.a aVar;
        ad.s sVar = (ad.s) this.X;
        ae.b bVar = (ae.b) this.Y;
        if (sVar.f759b != ad.s.f757d) {
            throw new IllegalStateException("provide() can be called only once.");
        }
        synchronized (sVar) {
            aVar = sVar.f758a;
            sVar.f758a = null;
            sVar.f759b = bVar;
        }
        aVar.g(bVar);
    }

    private final void b() {
        ad.r rVar = (ad.r) this.X;
        ae.b bVar = (ae.b) this.Y;
        synchronized (rVar) {
            try {
                if (rVar.f755b == null) {
                    rVar.f754a.add(bVar);
                } else {
                    rVar.f755b.add(bVar.get());
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    private final void c() {
        y1 y1Var = (y1) this.X;
        r0 r0Var = new r0(y1Var.f2777a, (MediaSessionCompat$Token) this.Y);
        y1Var.f2783i = r0Var;
        w1 w1Var = y1Var.f2781e;
        Handler handler = y1Var.f2778b.f2187r0;
        if (!((Set) r0Var.Y).add(w1Var)) {
            l3.b.m("MediaControllerCompat", "the callback has already been registered");
            return;
        }
        if (handler == null) {
            handler = new Handler();
        }
        w1Var.d(handler);
        androidx.media3.session.legacy.b0 b0Var = (androidx.media3.session.legacy.b0) r0Var.X;
        MediaController mediaController = b0Var.f2427a;
        androidx.media3.session.legacy.z zVar = w1Var.f2746a;
        zVar.getClass();
        mediaController.registerCallback(zVar, handler);
        synchronized (b0Var.f2428b) {
            androidx.media3.session.legacy.d dVarB = b0Var.f2431e.b();
            if (dVarB != null) {
                androidx.media3.session.legacy.y yVar = new androidx.media3.session.legacy.y(w1Var);
                b0Var.f2430d.put(w1Var, yVar);
                w1Var.f2748c = yVar;
                try {
                    dVarB.k1(yVar);
                    w1Var.c(13, null);
                } catch (RemoteException | SecurityException e3) {
                    l3.b.e("MediaControllerCompat", "Dead object in registerCallback.", e3);
                }
            } else {
                w1Var.f2748c = null;
                b0Var.f2429c.add(w1Var);
            }
        }
    }

    @Override // java.lang.Runnable
    public final void run() {
        int i10;
        int i11;
        int i12;
        int i13;
        s5 s5Var;
        int i14 = 1;
        switch (this.f471e) {
            case 0:
                d dVar = (d) this.X;
                b bVar = (b) this.Y;
                dVar.f476c.i();
                h hVar = dVar.f475b;
                synchronized (hVar.f493a) {
                    hVar.b();
                    bVar.run();
                    break;
                }
                return;
            case 1:
                w wVar = (w) this.X;
                wVar.R0.set(wVar.w((m7.e) this.Y, wVar.L0, 0));
                return;
            case 2:
                a();
                return;
            case 3:
                b();
                return;
            case 4:
                g0 g0Var = (g0) this.X;
                Runnable runnable = (Runnable) this.Y;
                g0Var.getClass();
                try {
                    runnable.run();
                    return;
                } finally {
                    g0Var.d();
                }
            case 5:
                c();
                return;
            case 6:
                y1 y1Var = (y1) this.X;
                u0 u0Var = (u0) ((n) this.Y).f518d;
                androidx.media3.session.b0 b0Var = y1Var.f2778b;
                b0Var.getClass();
                ji.k.A(Looper.myLooper() == b0Var.f2187r0.getLooper());
                z2 z2Var = b0Var.Z;
                z2Var.j(b0Var, u0Var);
                z2Var.h();
                return;
            case 7:
                r1 r1Var = (r1) this.X;
                c2 c2Var = (c2) this.Y;
                if (r1Var.f2619p) {
                    return;
                }
                c2Var.k(r1Var);
                return;
            case 8:
                p0 p0Var = (p0) this.X;
                androidx.media3.session.legacy.j jVar = (androidx.media3.session.legacy.j) this.Y;
                try {
                    s5 s5Var2 = (s5) p0Var.f17991e;
                    ji.k.v(s5Var2, "SessionResult must not be null");
                    jVar.f(s5Var2.f2691b);
                    return;
                } catch (InterruptedException | CancellationException | ExecutionException e3) {
                    l3.b.n("MLSLegacyStub", "Custom action failed", e3);
                    jVar.e();
                    return;
                }
            case 9:
                a1 a1Var = (a1) this.X;
                ArrayList arrayList = (ArrayList) this.Y;
                if (a1Var.f17999e instanceof rc.d) {
                    for (int i15 = 0; i15 < arrayList.size(); i15++) {
                        if (arrayList.get(i15) != null) {
                            ((ListenableFuture) arrayList.get(i15)).cancel(false);
                        }
                    }
                    return;
                }
                return;
            case 10:
                l2 l2Var = (l2) this.X;
                ArrayList arrayList2 = (ArrayList) this.Y;
                n2 n2Var = l2Var.Z;
                s2 s2Var = n2Var.f2554y0;
                for (int i16 = 0; i16 < arrayList2.size(); i16++) {
                    m2 m2Var = (m2) arrayList2.get(i16);
                    Bundle bundle = m2Var.f2541d;
                    androidx.media3.session.legacy.j jVar2 = m2Var.f2542e;
                    if (bundle != null) {
                        try {
                            bundle.setClassLoader(s2Var.f.getClassLoader());
                            i10 = bundle.getInt("android.media.browse.extra.PAGE", -1);
                            i11 = bundle.getInt("android.media.browse.extra.PAGE_SIZE", -1);
                        } catch (BadParcelableException unused) {
                            jVar2.f(null);
                            return;
                        }
                    } else {
                        i10 = 0;
                        i11 = Integer.MAX_VALUE;
                    }
                    if (i10 < 0 || i11 < 1) {
                        i12 = 0;
                        i13 = Integer.MAX_VALUE;
                    } else {
                        i12 = i10;
                        i13 = i11;
                    }
                    a1 a1VarN0 = l0.n0(n2Var.f2554y0.x(m2Var.f2538a, m2Var.f2540c, i12, i13, androidx.media3.session.x.h(s2Var.f, bundle)), new i2(n2Var, i14));
                    a1VarN0.a(new k2(a1VarN0, jVar2, i14), rc.d0.f17971e);
                    break;
                }
                return;
            case ue.r.NETWORK_CLIENT_ERROR_REASON_FIELD_NUMBER /* 11 */:
                ((s2) this.X).K(null, (j5) this.Y);
                return;
            case ue.r.CUSTOM_ATTRIBUTES_FIELD_NUMBER /* 12 */:
                s2 s2Var2 = (s2) this.X;
                Runnable runnable2 = (Runnable) this.Y;
                s2Var2.getClass();
                runnable2.run();
                return;
            case ue.r.PERF_SESSIONS_FIELD_NUMBER /* 13 */:
                ((l1.h) this.Y).a(Boolean.valueOf(((s2) this.X).z()));
                return;
            case 14:
                p0 p0Var2 = (p0) this.X;
                ResultReceiver resultReceiver = (ResultReceiver) this.Y;
                try {
                    s5Var = (s5) p0Var2.f17991e;
                    ji.k.v(s5Var, "SessionResult must not be null");
                    break;
                } catch (InterruptedException e10) {
                    e = e10;
                    l3.b.n("MediaSessionLegacyStub", "Custom command failed", e);
                    s5Var = new s5(-1);
                } catch (CancellationException e11) {
                    l3.b.n("MediaSessionLegacyStub", "Custom command cancelled", e11);
                    s5Var = new s5(1);
                } catch (ExecutionException e12) {
                    e = e12;
                    l3.b.n("MediaSessionLegacyStub", "Custom command failed", e);
                    s5Var = new s5(-1);
                }
                resultReceiver.send(s5Var.f2690a, s5Var.f2691b);
                return;
            case WebSocketProtocol.B0_MASK_OPCODE /* 15 */:
                PlaybackService playbackService = (PlaybackService) this.X;
                w4 w4Var = (w4) this.Y;
                playbackService.d(w4Var).f2171v0 = w4Var;
                return;
            case WebSocketProtocol.B0_FLAG_RSV3 /* 16 */:
                s2 s2Var3 = (s2) this.X;
                Intent intent = (Intent) this.Y;
                d3 d3VarI = s2Var3.i();
                if (d3VarI == null) {
                    d3VarI = d4.c(intent);
                }
                if (s2Var3.y(d3VarI, intent)) {
                    return;
                }
                l3.b.b("MSessionService", "Ignored unrecognized media button intent.");
                return;
            case 17:
                b5 b5Var = (b5) this.X;
                androidx.media3.session.r rVar = (androidx.media3.session.r) this.Y;
                ge.q qVar = b5Var.f2200e;
                d3 d3VarK = qVar.k(rVar.asBinder());
                if (d3VarK != null) {
                    qVar.y(d3VarK);
                    return;
                }
                return;
            case 18:
                ((b5) this.X).f2200e.h((d3) this.Y);
                return;
            case 19:
                kotlin.jvm.internal.d0 d0Var = (kotlin.jvm.internal.d0) this.X;
                kotlin.jvm.internal.d0 d0Var2 = (kotlin.jvm.internal.d0) this.Y;
                q0.cancel$default((kotlinx.coroutines.p0) d0Var.f13951e, null, 1, null);
                q0.cancel$default((kotlinx.coroutines.p0) d0Var2.f13951e, null, 1, null);
                return;
            case 20:
                bd.a aVar = (bd.a) this.X;
                Runnable runnable3 = (Runnable) this.Y;
                Process.setThreadPriority(aVar.f3469c);
                StrictMode.ThreadPolicy threadPolicy = aVar.f3470d;
                if (threadPolicy != null) {
                    StrictMode.setThreadPolicy(threadPolicy);
                }
                runnable3.run();
                return;
            case 21:
                Callable callable = (Callable) this.X;
                bd.i iVar = (bd.i) ((w4) this.Y).X;
                try {
                    iVar.j(callable.call());
                    return;
                } catch (Exception e13) {
                    iVar.k(e13);
                    return;
                }
            case 22:
                ProgressDotsIndicator progressDotsIndicator = (ProgressDotsIndicator) this.X;
                View view = (View) this.Y;
                LinearLayout linearLayout = progressDotsIndicator.f20082x0;
                if (linearLayout == null) {
                    kotlin.jvm.internal.q.n("linearLayout");
                    throw null;
                }
                int width = linearLayout.getWidth();
                HorizontalScrollView horizontalScrollView = progressDotsIndicator.f20083y0;
                if (horizontalScrollView == null) {
                    kotlin.jvm.internal.q.n("dotsScrollView");
                    throw null;
                }
                int width2 = width - horizontalScrollView.getWidth();
                if (width2 < 0) {
                    width2 = 0;
                }
                if (width2 == 0) {
                    return;
                }
                int width3 = (view.getWidth() / 2) + view.getLeft();
                HorizontalScrollView horizontalScrollView2 = progressDotsIndicator.f20083y0;
                if (horizontalScrollView2 == null) {
                    kotlin.jvm.internal.q.n("dotsScrollView");
                    throw null;
                }
                int iE = com.bumptech.glide.c.e(width3 - (horizontalScrollView2.getWidth() / 2), 0, width2);
                HorizontalScrollView horizontalScrollView3 = progressDotsIndicator.f20083y0;
                if (horizontalScrollView3 != null) {
                    horizontalScrollView3.scrollTo(iE, 0);
                    return;
                } else {
                    kotlin.jvm.internal.q.n("dotsScrollView");
                    throw null;
                }
            case 23:
                i0.c cVar = (i0.c) this.X;
                e6.b bVar2 = (e6.b) this.Y;
                HashSet hashSet = new HashSet();
                if (cVar != null) {
                    hashSet.addAll(cVar.f10568a);
                }
                ((e1.a) bVar2.h).getClass();
                return;
            case 24:
                com.google.android.material.datepicker.h hVar2 = (com.google.android.material.datepicker.h) this.X;
                String str = (String) this.Y;
                TextInputLayout textInputLayout = hVar2.f5884e;
                SimpleDateFormat simpleDateFormat = hVar2.Y;
                Context context = textInputLayout.getContext();
                textInputLayout.setError(context.getString(R.string.mtrl_picker_invalid_format) + "\n" + String.format(context.getString(R.string.mtrl_picker_invalid_format_use), str.replace(' ', (char) 160)) + "\n" + String.format(context.getString(R.string.mtrl_picker_invalid_format_example), simpleDateFormat.format(new Date(com.google.android.material.datepicker.g0.h().getTimeInMillis())).replace(' ', (char) 160)));
                hVar2.a();
                return;
            case 25:
                ((d1.j) ((z7.c) this.X).X).B0.l((z1) this.Y);
                return;
            case 26:
                d1.u uVar = (d1.u) this.X;
                z1 z1Var = (z1) this.Y;
                z1 z1Var2 = uVar.h;
                if (z1Var2 != null && z1Var2 == z1Var) {
                    uVar.h = null;
                    uVar.f6642g = null;
                }
                t1 t1Var = uVar.f6646l;
                if (t1Var != null) {
                    t1Var.c();
                    uVar.f6646l = null;
                    return;
                }
                return;
            case 27:
                ((l3.i) this.X).accept(this.Y);
                return;
            case 28:
                ((y0) this.X).E((n4.z) this.Y);
                return;
            default:
                ((e7.e) this.X).f((m7.j) this.Y, false);
                return;
        }
    }

    public /* synthetic */ b(Object obj, Object obj2, int i10) {
        this.f471e = i10;
        this.X = obj;
        this.Y = obj2;
    }
}
