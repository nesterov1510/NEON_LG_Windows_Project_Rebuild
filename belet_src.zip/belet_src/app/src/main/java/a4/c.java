package a4;

import android.os.HandlerThread;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class c implements kc.x {
    public final /* synthetic */ int X;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f472e;

    public /* synthetic */ c(int i10, int i11) {
        this.f472e = i11;
        this.X = i10;
    }

    @Override // kc.x
    public final Object get() {
        switch (this.f472e) {
            case 0:
                return new HandlerThread(d.t(this.X, "ExoPlayer:MediaCodecAsyncAdapter:"));
            default:
                return new HandlerThread(d.t(this.X, "ExoPlayer:MediaCodecQueueingThread:"));
        }
    }
}
