package a4;

import android.media.MediaCodec;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public class r extends r3.e {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int f520e;

    public r(IllegalStateException illegalStateException, s sVar) {
        StringBuilder sb2 = new StringBuilder("Decoder failed: ");
        sb2.append(sVar == null ? null : sVar.f521a);
        super(sb2.toString(), illegalStateException);
        boolean z5 = illegalStateException instanceof MediaCodec.CodecException;
        if (z5) {
            ((MediaCodec.CodecException) illegalStateException).getDiagnosticInfo();
        }
        this.f520e = z5 ? ((MediaCodec.CodecException) illegalStateException).getErrorCode() : 0;
    }
}
