package a4;

import android.media.MediaCodec;
import android.os.Build;
import android.os.Bundle;
import android.os.HandlerThread;
import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.concurrent.atomic.AtomicReference;
import l3.l0;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class g implements q {

    /* JADX INFO: renamed from: t0, reason: collision with root package name */
    public static final ArrayDeque f489t0 = new ArrayDeque();
    public static final Object u0 = new Object();
    public final HandlerThread X;
    public e Y;
    public final AtomicReference Z;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final MediaCodec f490e;

    /* JADX INFO: renamed from: r0, reason: collision with root package name */
    public final l3.h f491r0;

    /* JADX INFO: renamed from: s0, reason: collision with root package name */
    public boolean f492s0;

    public g(MediaCodec mediaCodec, HandlerThread handlerThread) {
        l3.h hVar = new l3.h();
        this.f490e = mediaCodec;
        this.X = handlerThread;
        this.f491r0 = hVar;
        this.Z = new AtomicReference();
    }

    public static f a() {
        ArrayDeque arrayDeque = f489t0;
        synchronized (arrayDeque) {
            try {
                if (arrayDeque.isEmpty()) {
                    return new f();
                }
                return (f) arrayDeque.removeFirst();
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    public static void e(f fVar) {
        ArrayDeque arrayDeque = f489t0;
        synchronized (arrayDeque) {
            arrayDeque.add(fVar);
        }
    }

    @Override // a4.q
    public final void b(Bundle bundle) {
        i();
        e eVar = this.Y;
        int i10 = l0.f14115a;
        eVar.obtainMessage(4, bundle).sendToTarget();
    }

    @Override // a4.q
    public final void c(int i10, r3.c cVar, long j10, int i11) {
        i();
        f fVarA = a();
        fVarA.f482a = i10;
        fVarA.f483b = 0;
        fVarA.f485d = j10;
        fVarA.f486e = i11;
        MediaCodec.CryptoInfo cryptoInfo = fVarA.f484c;
        cryptoInfo.numSubSamples = cVar.f;
        int[] iArr = cVar.f17860d;
        int[] iArrCopyOf = cryptoInfo.numBytesOfClearData;
        if (iArr != null) {
            if (iArrCopyOf == null || iArrCopyOf.length < iArr.length) {
                iArrCopyOf = Arrays.copyOf(iArr, iArr.length);
            } else {
                System.arraycopy(iArr, 0, iArrCopyOf, 0, iArr.length);
            }
        }
        cryptoInfo.numBytesOfClearData = iArrCopyOf;
        int[] iArr2 = cVar.f17861e;
        int[] iArrCopyOf2 = cryptoInfo.numBytesOfEncryptedData;
        if (iArr2 != null) {
            if (iArrCopyOf2 == null || iArrCopyOf2.length < iArr2.length) {
                iArrCopyOf2 = Arrays.copyOf(iArr2, iArr2.length);
            } else {
                System.arraycopy(iArr2, 0, iArrCopyOf2, 0, iArr2.length);
            }
        }
        cryptoInfo.numBytesOfEncryptedData = iArrCopyOf2;
        byte[] bArr = cVar.f17858b;
        byte[] bArrCopyOf = cryptoInfo.key;
        if (bArr != null) {
            if (bArrCopyOf == null || bArrCopyOf.length < bArr.length) {
                bArrCopyOf = Arrays.copyOf(bArr, bArr.length);
            } else {
                System.arraycopy(bArr, 0, bArrCopyOf, 0, bArr.length);
            }
        }
        bArrCopyOf.getClass();
        cryptoInfo.key = bArrCopyOf;
        byte[] bArr2 = cVar.f17857a;
        byte[] bArrCopyOf2 = cryptoInfo.iv;
        if (bArr2 != null) {
            if (bArrCopyOf2 == null || bArrCopyOf2.length < bArr2.length) {
                bArrCopyOf2 = Arrays.copyOf(bArr2, bArr2.length);
            } else {
                System.arraycopy(bArr2, 0, bArrCopyOf2, 0, bArr2.length);
            }
        }
        bArrCopyOf2.getClass();
        cryptoInfo.iv = bArrCopyOf2;
        cryptoInfo.mode = cVar.f17859c;
        if (Build.VERSION.SDK_INT >= 24) {
            cryptoInfo.setPattern(new MediaCodec.CryptoInfo.Pattern(cVar.f17862g, cVar.h));
        }
        e eVar = this.Y;
        int i12 = l0.f14115a;
        eVar.obtainMessage(2, fVarA).sendToTarget();
    }

    @Override // a4.q
    public final void d(int i10, int i11, long j10, int i12) {
        i();
        f fVarA = a();
        fVarA.f482a = i10;
        fVarA.f483b = i11;
        fVarA.f485d = j10;
        fVarA.f486e = i12;
        e eVar = this.Y;
        int i13 = l0.f14115a;
        eVar.obtainMessage(1, fVarA).sendToTarget();
    }

    @Override // a4.q
    public final void flush() {
        if (this.f492s0) {
            try {
                e eVar = this.Y;
                eVar.getClass();
                eVar.removeCallbacksAndMessages(null);
                l3.h hVar = this.f491r0;
                synchronized (hVar) {
                    hVar.f14107b = false;
                }
                e eVar2 = this.Y;
                eVar2.getClass();
                eVar2.obtainMessage(3).sendToTarget();
                hVar.a();
            } catch (InterruptedException e3) {
                Thread.currentThread().interrupt();
                throw new IllegalStateException(e3);
            }
        }
    }

    @Override // a4.q
    public final void i() {
        RuntimeException runtimeException = (RuntimeException) this.Z.getAndSet(null);
        if (runtimeException != null) {
            throw runtimeException;
        }
    }

    @Override // a4.q
    public final void shutdown() {
        if (this.f492s0) {
            flush();
            this.X.quit();
        }
        this.f492s0 = false;
    }

    @Override // a4.q
    public final void start() {
        if (this.f492s0) {
            return;
        }
        HandlerThread handlerThread = this.X;
        handlerThread.start();
        this.Y = new e(this, handlerThread.getLooper(), 0);
        this.f492s0 = true;
    }
}
