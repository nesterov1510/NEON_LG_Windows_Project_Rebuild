package a4;

import android.content.Context;
import android.graphics.Point;
import android.media.MediaCodecInfo;
import android.os.Build;
import android.util.Pair;
import android.util.Range;
import com.google.android.gms.internal.measurement.ng;
import com.google.protobuf.m0;
import i3.q0;
import j$.util.Objects;
import java.util.HashMap;
import java.util.List;
import l3.l0;
import lc.l2;
import lc.u0;
import okio.internal.Buffer;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class s {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f521a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f522b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final String f523c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final MediaCodecInfo.CodecCapabilities f524d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final boolean f525e;
    public final boolean f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final boolean f526g;
    public final boolean h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final boolean f527i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public int f528j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public int f529k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public float f530l;

    public s(String str, String str2, String str3, MediaCodecInfo.CodecCapabilities codecCapabilities, boolean z5, boolean z6, boolean z9, boolean z10, boolean z11, boolean z12) {
        str.getClass();
        this.f521a = str;
        this.f522b = str2;
        this.f523c = str3;
        this.f524d = codecCapabilities;
        this.f526g = z5;
        this.f525e = z10;
        this.f = z11;
        this.h = z12;
        this.f527i = q0.m(str2);
        this.f530l = -3.4028235E38f;
        this.f528j = -1;
        this.f529k = -1;
    }

    public static boolean a(MediaCodecInfo.VideoCapabilities videoCapabilities, int i10, int i11, double d2) {
        Range<Double> achievableFrameRatesFor;
        int widthAlignment = videoCapabilities.getWidthAlignment();
        int heightAlignment = videoCapabilities.getHeightAlignment();
        Point point = new Point(l0.g(i10, widthAlignment) * widthAlignment, l0.g(i11, heightAlignment) * heightAlignment);
        int i12 = point.x;
        int i13 = point.y;
        if (d2 == -1.0d || d2 < 1.0d) {
            return videoCapabilities.isSizeSupported(i12, i13);
        }
        double dFloor = Math.floor(d2);
        if (videoCapabilities.areSizeAndRateSupported(i12, i13, dFloor)) {
            return Build.VERSION.SDK_INT < 24 || (achievableFrameRatesFor = videoCapabilities.getAchievableFrameRatesFor(i12, i13)) == null || dFloor <= ((Double) achievableFrameRatesFor.getUpper()).doubleValue();
        }
        return false;
    }

    /* JADX WARN: Code duplicated, block: B:34:0x006f  */
    public static s i(String str, String str2, String str3, MediaCodecInfo.CodecCapabilities codecCapabilities, boolean z5, boolean z6, boolean z9, boolean z10) {
        boolean z11;
        boolean z12 = codecCapabilities != null && codecCapabilities.isFeatureSupported("adaptive-playback");
        if (codecCapabilities != null) {
            codecCapabilities.isFeatureSupported("tunneled-playback");
        }
        boolean z13 = z10 || (codecCapabilities != null && codecCapabilities.isFeatureSupported("secure-playback"));
        if (Build.VERSION.SDK_INT < 35 || codecCapabilities == null || !codecCapabilities.isFeatureSupported("detached-surface")) {
            z11 = false;
        } else {
            String str4 = Build.MANUFACTURER;
            if (str4.equals("Xiaomi") || str4.equals("OPPO") || str4.equals("realme") || str4.equals("motorola") || str4.equals("LENOVO")) {
                z11 = false;
            } else {
                z11 = true;
            }
        }
        return new s(str, str2, str3, codecCapabilities, z5, z6, z9, z12, z13, z11);
    }

    public final s3.d b(androidx.media3.common.b bVar, androidx.media3.common.b bVar2) {
        androidx.media3.common.b bVar3;
        androidx.media3.common.b bVar4;
        int i10;
        String str = bVar.f2125o;
        i3.m mVar = bVar.E;
        String str2 = bVar2.f2125o;
        i3.m mVar2 = bVar2.E;
        int i11 = !Objects.equals(str, str2) ? 8 : 0;
        if (this.f527i) {
            if (bVar.A != bVar2.A) {
                i11 |= 1024;
            }
            boolean z5 = (bVar.f2132v == bVar2.f2132v && bVar.f2133w == bVar2.f2133w) ? false : true;
            if (!this.f525e && z5) {
                i11 |= 512;
            }
            if ((!i3.m.e(mVar) || !i3.m.e(mVar2)) && !Objects.equals(mVar, mVar2)) {
                i11 |= 2048;
            }
            if (Build.MODEL.startsWith("SM-T230") && "OMX.MARVELL.VIDEO.HW.CODA7542DECODER".equals(this.f521a) && !bVar.b(bVar2)) {
                i11 |= 2;
            }
            int i12 = bVar.f2134x;
            if (i12 != -1 && (i10 = bVar.f2135y) != -1 && i12 == bVar2.f2134x && i10 == bVar2.f2135y && z5) {
                i11 |= 2;
            }
            if (i11 == 0 && Objects.equals(bVar2.f2125o, "video/dolby-vision")) {
                Pair pairB = l3.f.b(bVar);
                Pair pairB2 = l3.f.b(bVar2);
                if (pairB == null || pairB2 == null || !((Integer) pairB.first).equals(pairB2.first)) {
                    i11 |= 2;
                }
            }
            if (i11 == 0) {
                return new s3.d(this.f521a, bVar, bVar2, bVar.b(bVar2) ? 3 : 2, 0);
            }
            bVar3 = bVar;
            bVar4 = bVar2;
        } else {
            bVar3 = bVar;
            bVar4 = bVar2;
            if (bVar3.G != bVar4.G) {
                i11 |= Buffer.SEGMENTING_THRESHOLD;
            }
            if (bVar3.H != bVar4.H) {
                i11 |= 8192;
            }
            if (bVar3.I != bVar4.I) {
                i11 |= 16384;
            }
            String str3 = this.f522b;
            if (i11 == 0 && (str3.equals("audio/mp4a-latm") || str3.equals("audio/ac4"))) {
                Pair pairB3 = l3.f.b(bVar3);
                Pair pairB4 = l3.f.b(bVar4);
                if (pairB3 != null && pairB4 != null) {
                    int iIntValue = ((Integer) pairB3.first).intValue();
                    int iIntValue2 = ((Integer) pairB4.first).intValue();
                    if (iIntValue == 42 && iIntValue2 == 42) {
                        return new s3.d(this.f521a, bVar3, bVar4, 3, 0);
                    }
                    if (str3.equals("audio/ac4") && pairB3.equals(pairB4)) {
                        return new s3.d(this.f521a, bVar3, bVar4, 3, 0);
                    }
                }
            }
            if (i11 == 0 && (str3.equals("audio/eac3-joc") || str3.equals("audio/eac3"))) {
                return new s3.d(this.f521a, bVar3, bVar4, 3, 0);
            }
            if (!bVar3.b(bVar4)) {
                i11 |= 32;
            }
            if ("audio/opus".equals(str3)) {
                i11 |= 2;
            }
            if (i11 == 0) {
                return new s3.d(this.f521a, bVar3, bVar4, 1, 0);
            }
        }
        return new s3.d(this.f521a, bVar3, bVar4, 0, i11);
    }

    /* JADX WARN: Code duplicated, block: B:38:0x00c3 A[PHI: r2
      0x00c3: PHI (r2v1 android.util.Pair) = (r2v0 android.util.Pair), (r2v0 android.util.Pair), (r2v0 android.util.Pair), (r2v15 android.util.Pair) binds: [B:3:0x0010, B:5:0x0018, B:10:0x002c, B:37:0x00c2] A[DONT_GENERATE, DONT_INLINE]] */
    public final boolean c(Context context, androidx.media3.common.b bVar, boolean z5) {
        MediaCodecInfo.CodecProfileLevel[] codecProfileLevelArr;
        int i10;
        int i11;
        MediaCodecInfo.VideoCapabilities videoCapabilities;
        MediaCodecInfo.AudioCapabilities audioCapabilities;
        Pair pair;
        String strA;
        Pair pairB = l3.f.b(bVar);
        String str = bVar.f2125o;
        int i12 = 3;
        String str2 = this.f523c;
        if (str != null && str.equals("video/mv-hevc")) {
            String strN = q0.n(str2);
            if (strN.equals("video/mv-hevc")) {
                return true;
            }
            if (strN.equals("video/hevc")) {
                HashMap map = e0.f481a;
                List list = bVar.f2128r;
                int i13 = 0;
                loop0: while (true) {
                    if (i13 >= list.size()) {
                        pair = null;
                        strA = null;
                        break;
                    }
                    byte[] bArr = (byte[]) list.get(i13);
                    int length = bArr.length;
                    if (length > i12) {
                        boolean[] zArr = new boolean[i12];
                        lc.q0 q0VarI = u0.i();
                        int i14 = 0;
                        while (i14 < bArr.length) {
                            int iC = m3.n.c(bArr, i14, bArr.length, zArr);
                            if (iC != bArr.length) {
                                q0VarI.c(Integer.valueOf(iC));
                            }
                            i14 = iC + 3;
                        }
                        l2 l2VarG = q0VarI.g();
                        int i15 = 0;
                        while (i15 < l2VarG.Z) {
                            if (((Integer) l2VarG.get(i15)).intValue() + i12 < length) {
                                m3.r rVar = new m3.r(bArr, ((Integer) l2VarG.get(i15)).intValue() + i12, length);
                                ng ngVarH = m3.n.h(rVar);
                                if (ngVarH.f5310a == 33 && ngVarH.f5311b == 0) {
                                    rVar.j(4);
                                    int iE = rVar.e(3);
                                    rVar.i();
                                    pair = null;
                                    m3.h hVarI = m3.n.i(rVar, true, iE, null);
                                    strA = l3.f.a(hVarI.f15033a, hVarI.f15034b, hVarI.f15035c, hVarI.f15036d, hVarI.f15037e, hVarI.f);
                                    break loop0;
                                }
                            }
                            i15++;
                            i12 = 3;
                        }
                    }
                    i13++;
                    i12 = 3;
                }
                if (strA == null) {
                    pairB = pair;
                } else {
                    String strTrim = strA.trim();
                    int i16 = l0.f14115a;
                    pairB = l3.f.c(strA, strTrim.split("\\.", -1), bVar.E);
                }
            }
        }
        if (pairB == null) {
            return true;
        }
        int iIntValue = ((Integer) pairB.first).intValue();
        int iIntValue2 = ((Integer) pairB.second).intValue();
        boolean zEquals = "video/dolby-vision".equals(str);
        String str3 = this.f522b;
        if (zEquals) {
            str3.getClass();
            switch (str3) {
                case "video/av01":
                case "video/hevc":
                    iIntValue = 2;
                    iIntValue2 = 0;
                    break;
                case "video/avc":
                    iIntValue2 = 0;
                    iIntValue = 8;
                    break;
            }
        }
        if (!this.f527i && !str3.equals("audio/ac4") && iIntValue != 42) {
            return true;
        }
        MediaCodecInfo.CodecCapabilities codecCapabilities = this.f524d;
        if (codecCapabilities == null || (codecProfileLevelArr = codecCapabilities.profileLevels) == null) {
            codecProfileLevelArr = new MediaCodecInfo.CodecProfileLevel[0];
        }
        if (str3.equals("audio/ac4") && codecProfileLevelArr.length == 0) {
            int i17 = ((codecCapabilities == null || (audioCapabilities = codecCapabilities.getAudioCapabilities()) == null) ? 2 : audioCapabilities.getMaxInputChannelCount()) > 18 ? 16 : 8;
            if (context.getPackageManager().hasSystemFeature("android.hardware.type.automotive")) {
                i10 = 4;
                codecProfileLevelArr = new MediaCodecInfo.CodecProfileLevel[]{e0.b(1026, i17)};
            } else {
                i10 = 4;
                codecProfileLevelArr = new MediaCodecInfo.CodecProfileLevel[]{e0.b(257, i17), e0.b(513, i17), e0.b(514, i17), e0.b(1026, i17), e0.b(1028, i17)};
            }
        } else {
            i10 = 4;
        }
        if (Build.VERSION.SDK_INT == 23 && "video/x-vnd.on2.vp9".equals(str3) && codecProfileLevelArr.length == 0) {
            int iIntValue3 = (codecCapabilities == null || (videoCapabilities = codecCapabilities.getVideoCapabilities()) == null) ? 0 : ((Integer) videoCapabilities.getBitrateRange().getUpper()).intValue();
            if (iIntValue3 >= 180000000) {
                i11 = 1024;
            } else if (iIntValue3 >= 120000000) {
                i11 = 512;
            } else if (iIntValue3 >= 60000000) {
                i11 = 256;
            } else if (iIntValue3 >= 30000000) {
                i11 = 128;
            } else if (iIntValue3 >= 18000000) {
                i11 = 64;
            } else if (iIntValue3 >= 12000000) {
                i11 = 32;
            } else if (iIntValue3 >= 7200000) {
                i11 = 16;
            } else if (iIntValue3 >= 3600000) {
                i11 = 8;
            } else if (iIntValue3 >= 1800000) {
                i11 = i10;
            } else {
                i11 = iIntValue3 >= 800000 ? 2 : 1;
            }
            codecProfileLevelArr = new MediaCodecInfo.CodecProfileLevel[]{e0.b(1, i11)};
        }
        for (MediaCodecInfo.CodecProfileLevel codecProfileLevel : codecProfileLevelArr) {
            if (codecProfileLevel.profile == iIntValue && (codecProfileLevel.level >= iIntValue2 || !z5)) {
                if (!"video/hevc".equals(str3) || 2 != iIntValue) {
                    return true;
                }
                String str4 = Build.DEVICE;
                if (!"sailfish".equals(str4) && !"marlin".equals(str4)) {
                    return true;
                }
            }
        }
        h("codec.profileLevel, " + bVar.f2121k + ", " + str2);
        return false;
    }

    public final boolean d(androidx.media3.common.b bVar) {
        return (Objects.equals(bVar.f2125o, "audio/flac") && bVar.I == 22 && Build.VERSION.SDK_INT < 34 && this.f521a.equals("c2.android.flac.decoder")) ? false : true;
    }

    public final boolean e(Context context, androidx.media3.common.b bVar) {
        int i10;
        int i11;
        String str = bVar.f2125o;
        String str2 = this.f522b;
        if ((!str2.equals(str) && !str2.equals(e0.c(bVar))) || !c(context, bVar, true) || !d(bVar)) {
            return false;
        }
        if (this.f527i) {
            int i12 = bVar.f2132v;
            if (i12 > 0 && (i11 = bVar.f2133w) > 0) {
                return g(i12, i11, bVar.f2136z);
            }
        } else {
            int i13 = bVar.H;
            MediaCodecInfo.CodecCapabilities codecCapabilities = this.f524d;
            if (i13 != -1) {
                if (codecCapabilities == null) {
                    h("sampleRate.caps");
                    return false;
                }
                MediaCodecInfo.AudioCapabilities audioCapabilities = codecCapabilities.getAudioCapabilities();
                if (audioCapabilities == null) {
                    h("sampleRate.aCaps");
                    return false;
                }
                if (!audioCapabilities.isSampleRateSupported(i13)) {
                    h("sampleRate.support, " + i13);
                    return false;
                }
            }
            int i14 = bVar.G;
            if (i14 != -1) {
                if (codecCapabilities == null) {
                    h("channelCount.caps");
                    return false;
                }
                MediaCodecInfo.AudioCapabilities audioCapabilities2 = codecCapabilities.getAudioCapabilities();
                if (audioCapabilities2 == null) {
                    h("channelCount.aCaps");
                    return false;
                }
                int maxInputChannelCount = audioCapabilities2.getMaxInputChannelCount();
                if (maxInputChannelCount <= 1 && ((Build.VERSION.SDK_INT < 26 || maxInputChannelCount <= 0) && !"audio/mpeg".equals(str2) && !"audio/3gpp".equals(str2) && !"audio/amr-wb".equals(str2) && !"audio/mp4a-latm".equals(str2) && !"audio/vorbis".equals(str2) && !"audio/opus".equals(str2) && !"audio/raw".equals(str2) && !"audio/flac".equals(str2) && !"audio/g711-alaw".equals(str2) && !"audio/g711-mlaw".equals(str2) && !"audio/gsm".equals(str2))) {
                    if ("audio/ac3".equals(str2)) {
                        i10 = 6;
                    } else {
                        i10 = "audio/eac3".equals(str2) ? 16 : 30;
                    }
                    l3.b.m("MediaCodecInfo", "AssumedMaxChannelAdjustment: " + this.f521a + ", [" + maxInputChannelCount + " to " + i10 + "]");
                    maxInputChannelCount = i10;
                }
                if (maxInputChannelCount < i14) {
                    h("channelCount.support, " + i14);
                    return false;
                }
            }
        }
        return true;
    }

    public final boolean f(androidx.media3.common.b bVar) {
        if (this.f527i) {
            return this.f525e;
        }
        Pair pairB = l3.f.b(bVar);
        return pairB != null && ((Integer) pairB.first).intValue() == 42;
    }

    /* JADX WARN: Code duplicated, block: B:28:0x0053 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:29:0x0055  */
    public final boolean g(int i10, int i11, double d2) {
        String str;
        Boolean bool;
        MediaCodecInfo.CodecCapabilities codecCapabilities = this.f524d;
        if (codecCapabilities == null) {
            h("sizeAndRate.caps");
            return false;
        }
        MediaCodecInfo.VideoCapabilities videoCapabilities = codecCapabilities.getVideoCapabilities();
        if (videoCapabilities == null) {
            h("sizeAndRate.vCaps");
            return false;
        }
        int i12 = Build.VERSION.SDK_INT;
        if (i12 >= 29) {
            int iB = (i12 < 29 || ((bool = com.bumptech.glide.d.f4726e) != null && bool.booleanValue())) ? 0 : a2.a.b(videoCapabilities, i10, i11, d2);
            if (iB != 2) {
                if (iB == 1) {
                    StringBuilder sbF = kotlin.jvm.internal.p.F(i10, i11, "sizeAndRate.cover, ", "x", "@");
                    sbF.append(d2);
                    h(sbF.toString());
                    return false;
                }
                if (!a(videoCapabilities, i10, i11, d2)) {
                    if (i10 < i11) {
                        str = this.f521a;
                        if ("OMX.MTK.VIDEO.DECODER.HEVC".equals(str)) {
                            StringBuilder sbF2 = kotlin.jvm.internal.p.F(i10, i11, "sizeAndRate.rotated, ", "x", "@");
                            sbF2.append(d2);
                            StringBuilder sbN = m0.n("AssumedSupport [", sbF2.toString(), "] [", str, ", ");
                            sbN.append(this.f522b);
                            sbN.append("] [");
                            sbN.append(l0.f14116b);
                            sbN.append("]");
                            l3.b.b("MediaCodecInfo", sbN.toString());
                            return true;
                        }
                        StringBuilder sbF3 = kotlin.jvm.internal.p.F(i10, i11, "sizeAndRate.rotated, ", "x", "@");
                        sbF3.append(d2);
                        StringBuilder sbN2 = m0.n("AssumedSupport [", sbF3.toString(), "] [", str, ", ");
                        sbN2.append(this.f522b);
                        sbN2.append("] [");
                        sbN2.append(l0.f14116b);
                        sbN2.append("]");
                        l3.b.b("MediaCodecInfo", sbN2.toString());
                        return true;
                    }
                    StringBuilder sbF4 = kotlin.jvm.internal.p.F(i10, i11, "sizeAndRate.support, ", "x", "@");
                    sbF4.append(d2);
                    h(sbF4.toString());
                    return false;
                }
            }
        } else if (!a(videoCapabilities, i10, i11, d2)) {
            if (i10 < i11) {
                str = this.f521a;
                if (("OMX.MTK.VIDEO.DECODER.HEVC".equals(str) || !"mcv5a".equals(Build.DEVICE)) && a(videoCapabilities, i11, i10, d2)) {
                    StringBuilder sbF5 = kotlin.jvm.internal.p.F(i10, i11, "sizeAndRate.rotated, ", "x", "@");
                    sbF5.append(d2);
                    StringBuilder sbN3 = m0.n("AssumedSupport [", sbF5.toString(), "] [", str, ", ");
                    sbN3.append(this.f522b);
                    sbN3.append("] [");
                    sbN3.append(l0.f14116b);
                    sbN3.append("]");
                    l3.b.b("MediaCodecInfo", sbN3.toString());
                    return true;
                }
            }
            StringBuilder sbF6 = kotlin.jvm.internal.p.F(i10, i11, "sizeAndRate.support, ", "x", "@");
            sbF6.append(d2);
            h(sbF6.toString());
            return false;
        }
        return true;
    }

    public final void h(String str) {
        StringBuilder sbM = m0.m("NoSupport [", str, "] [");
        sbM.append(this.f521a);
        sbM.append(", ");
        sbM.append(this.f522b);
        sbM.append("] [");
        sbM.append(l0.f14116b);
        sbM.append("]");
        l3.b.b("MediaCodecInfo", sbM.toString());
    }

    public final String toString() {
        return this.f521a;
    }
}
