package ai;

import a0.o4;
import java.util.ArrayList;
import java.util.Iterator;
import kotlin.jvm.internal.q;
import ri.m;
import ri.o;
import yh.v;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public abstract class h {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final /* synthetic */ int f795a = 0;

    /* JADX WARN: Code duplicated, block: B:14:0x004d A[PHI: r7
      0x004d: PHI (r7v2 long) = (r7v1 long), (r7v0 long) binds: [B:18:0x005b, B:13:0x004b] A[DONT_GENERATE, DONT_INLINE]] */
    static {
        long j10;
        p0.f.f(v.f23071j, new o4(2), new a(1));
        int i10 = 0;
        jj.f fVar = new jj.f(0, 255, 1);
        ArrayList arrayList = new ArrayList(o.S(fVar, 10));
        Iterator it = fVar.iterator();
        while (true) {
            jj.e eVar = (jj.e) it;
            if (!eVar.Y) {
                break;
            }
            int iNextInt = eVar.nextInt();
            if (48 > iNextInt || iNextInt >= 58) {
                long j11 = iNextInt;
                long j12 = 97;
                if (j11 < 97 || j11 > 102) {
                    j12 = 65;
                    if (j11 < 65 || j11 > 70) {
                        j10 = -1;
                    } else {
                        j10 = (j11 - j12) + ((long) 10);
                    }
                } else {
                    j10 = (j11 - j12) + ((long) 10);
                }
            } else {
                j10 = ((long) iNextInt) - 48;
            }
            arrayList.add(Long.valueOf(j10));
        }
        m.A0(arrayList);
        jj.f fVar2 = new jj.f(0, 15, 1);
        ArrayList arrayList2 = new ArrayList(o.S(fVar2, 10));
        Iterator it2 = fVar2.iterator();
        while (true) {
            jj.e eVar2 = (jj.e) it2;
            if (!eVar2.Y) {
                break;
            }
            int iNextInt2 = eVar2.nextInt();
            arrayList2.add(Byte.valueOf((byte) (iNextInt2 < 10 ? iNextInt2 + 48 : (char) (((char) (iNextInt2 + 97)) - '\n'))));
        }
        byte[] bArr = new byte[arrayList2.size()];
        int size = arrayList2.size();
        int i11 = 0;
        while (i11 < size) {
            Object obj = arrayList2.get(i11);
            i11++;
            bArr[i10] = ((Number) obj).byteValue();
            i10++;
        }
    }

    public static final boolean a(CharSequence charSequence, int i10, int i11, CharSequence other) {
        q.g(charSequence, "<this>");
        q.g(other, "other");
        if (i11 - i10 != other.length()) {
            return false;
        }
        for (int i12 = i10; i12 < i11; i12++) {
            int iCharAt = charSequence.charAt(i12);
            if (65 <= iCharAt && iCharAt < 91) {
                iCharAt += 32;
            }
            int iCharAt2 = other.charAt(i12 - i10);
            if (65 <= iCharAt2 && iCharAt2 < 91) {
                iCharAt2 += 32;
            }
            if (iCharAt != iCharAt2) {
                return false;
            }
        }
        return true;
    }

    public static final int b(CharSequence charSequence, int i10, int i11) {
        q.g(charSequence, "<this>");
        int i12 = 0;
        while (i10 < i11) {
            int iCharAt = charSequence.charAt(i10);
            if (65 <= iCharAt && iCharAt < 91) {
                iCharAt += 32;
            }
            i12 = (i12 * 31) + iCharAt;
            i10++;
        }
        return i12;
    }

    public static final void c(c cVar, int i10) {
        throw new NumberFormatException("Invalid number: " + ((Object) cVar) + ", wrong digit: " + cVar.charAt(i10) + " at position " + i10);
    }
}
