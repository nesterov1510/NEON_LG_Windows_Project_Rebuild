package ai;

import java.util.ArrayList;
import java.util.List;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final char f785a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Object f786b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final ArrayList f787c;

    /* JADX WARN: Multi-variable type inference failed */
    public b(char c10, List list, ArrayList arrayList) {
        this.f785a = c10;
        this.f786b = list;
        this.f787c = arrayList;
        b[] bVarArr = new b[256];
        for (int i10 = 0; i10 < 256; i10++) {
            ArrayList arrayList2 = this.f787c;
            int size = arrayList2.size();
            Object obj = null;
            boolean z5 = false;
            int i11 = 0;
            Object obj2 = null;
            while (true) {
                if (i11 >= size) {
                    if (!z5) {
                        break;
                    }
                    obj = obj2;
                    break;
                } else {
                    Object obj3 = arrayList2.get(i11);
                    i11++;
                    if (((b) obj3).f785a == i10) {
                        if (z5) {
                            break;
                        }
                        z5 = true;
                        obj2 = obj3;
                    }
                }
            }
            bVarArr[i10] = obj;
        }
    }
}
