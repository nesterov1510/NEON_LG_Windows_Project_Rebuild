package ai;

import java.util.ArrayList;
import java.util.Arrays;
import okio.internal.Buffer;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class f extends oi.c {

    /* JADX INFO: renamed from: s0, reason: collision with root package name */
    public final /* synthetic */ int f793s0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ f(int i10, int i11) {
        super(i10);
        this.f793s0 = i11;
    }

    @Override // oi.c
    public Object a(Object obj) {
        switch (this.f793s0) {
            case 2:
                zh.c cVar = (zh.c) obj;
                ArrayList arrayList = cVar.f23561a;
                int size = arrayList.size();
                int i10 = 0;
                while (i10 < size) {
                    Object obj2 = arrayList.get(i10);
                    i10++;
                    zh.e.f23566a.k0((int[]) obj2);
                }
                arrayList.clear();
                return cVar;
            case 3:
                int[] iArr = (int[]) obj;
                Arrays.fill(iArr, 0, iArr.length, -1);
                return iArr;
            default:
                return obj;
        }
    }

    @Override // oi.c
    public final Object m() {
        switch (this.f793s0) {
            case 0:
                return new char[2048];
            case 1:
                return new byte[Buffer.SEGMENTING_THRESHOLD];
            case 2:
                zh.c cVar = new zh.c();
                cVar.f23561a = new ArrayList();
                return cVar;
            default:
                int[] iArr = new int[768];
                for (int i10 = 0; i10 < 768; i10++) {
                    iArr[i10] = -1;
                }
                return iArr;
        }
    }
}
