package ai;

import kotlin.jvm.internal.p;
import okhttp3.internal.url._UrlKt;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class c implements CharSequence {
    public final int X;
    public String Y;
    public final /* synthetic */ d Z;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int f788e;

    public c(d dVar, int i10, int i11) {
        this.Z = dVar;
        this.f788e = i10;
        this.X = i11;
    }

    @Override // java.lang.CharSequence
    public final char charAt(int i10) {
        int i11 = this.f788e + i10;
        if (i10 < 0) {
            throw new IllegalArgumentException(p.z(i10, "index is negative: ").toString());
        }
        if (i11 < this.X) {
            return this.Z.c(i11);
        }
        StringBuilder sbP = p0.e.p("index (", i10, ") should be less than length (");
        sbP.append(length());
        sbP.append(')');
        throw new IllegalArgumentException(sbP.toString().toString());
    }

    public final boolean equals(Object obj) {
        if (obj instanceof CharSequence) {
            CharSequence charSequence = (CharSequence) obj;
            if (charSequence.length() == length()) {
                int length = length();
                for (int i10 = 0; i10 < length; i10++) {
                    if (this.Z.c(this.f788e + i10) != charSequence.charAt(i10)) {
                        return false;
                    }
                }
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        String str = this.Y;
        if (str != null) {
            return str.hashCode();
        }
        int iC = 0;
        for (int i10 = this.f788e; i10 < this.X; i10++) {
            iC = (iC * 31) + this.Z.c(i10);
        }
        return iC;
    }

    @Override // java.lang.CharSequence
    public final int length() {
        return this.X - this.f788e;
    }

    @Override // java.lang.CharSequence
    public final CharSequence subSequence(int i10, int i11) {
        if (i10 < 0) {
            throw new IllegalArgumentException(p.z(i10, "start is negative: ").toString());
        }
        if (i10 > i11) {
            throw new IllegalArgumentException(("start (" + i10 + ") should be less or equal to end (" + i11 + ')').toString());
        }
        int i12 = this.X;
        int i13 = this.f788e;
        if (i11 > i12 - i13) {
            throw new IllegalArgumentException(("end should be less than length (" + length() + ')').toString());
        }
        if (i10 == i11) {
            return _UrlKt.FRAGMENT_ENCODE_SET;
        }
        return new c(this.Z, i10 + i13, i13 + i11);
    }

    @Override // java.lang.CharSequence
    public final String toString() {
        String str = this.Y;
        if (str != null) {
            return str;
        }
        String string = this.Z.b(this.f788e, this.X).toString();
        this.Y = string;
        return string;
    }
}
