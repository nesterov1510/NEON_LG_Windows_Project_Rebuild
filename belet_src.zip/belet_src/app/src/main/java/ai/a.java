package ai;

import ej.p;
import java.util.List;
import java.util.concurrent.CancellationException;
import kotlin.jvm.internal.q;
import kotlinx.coroutines.channels.s;
import kotlinx.coroutines.f3;
import kotlinx.coroutines.flow.internal.w;
import kotlinx.coroutines.internal.o0;
import kotlinx.coroutines.internal.u0;
import kotlinx.coroutines.j0;
import kotlinx.coroutines.z;
import kotlinx.serialization.n;
import mh.r0;
import mh.y0;
import mh.z0;
import okhttp3.internal.ws.RealWebSocket;
import okhttp3.internal.ws.WebSocketProtocol;
import p2.k0;
import qi.b0;
import ue.r;
import ui.j;
import yh.v;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class a implements p {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f784e;

    public /* synthetic */ a(int i10) {
        this.f784e = i10;
    }

    @Override // ej.p
    public final Object invoke(Object obj, Object obj2) {
        ui.c cVar;
        switch (this.f784e) {
            case 0:
                CharSequence s8 = (CharSequence) obj;
                int iIntValue = ((Integer) obj2).intValue();
                q.g(s8, "s");
                return Character.valueOf(s8.charAt(iIntValue));
            case 1:
                v m10 = (v) obj;
                int iIntValue2 = ((Integer) obj2).intValue();
                q.g(m10, "m");
                return Character.valueOf(m10.f23072a.charAt(iIntValue2));
            case 2:
                return Boolean.valueOf(j0.hasCopyableElements$lambda$0(((Boolean) obj).booleanValue(), (ui.g) obj2));
            case 3:
                return ((ui.i) obj).plus((ui.g) obj2);
            case 4:
                return s.zip$lambda$23$ChannelsKt__DeprecatedKt(obj, obj2);
            case 5:
                return Boolean.valueOf(q.c(obj, obj2));
            case 6:
                return Integer.valueOf(w.collectContextSize$lambda$0(((Integer) obj).intValue(), (ui.g) obj2));
            case 7:
                return o0.countAll$lambda$0(obj, (ui.g) obj2);
            case 8:
                return o0.findOne$lambda$1((f3) obj, (ui.g) obj2);
            case 9:
                return o0.updateState$lambda$2((u0) obj, (ui.g) obj2);
            case 10:
                return n.PARAMETRIZED_SERIALIZERS_CACHE$lambda$0((kj.c) obj, (List) obj2);
            case r.NETWORK_CLIENT_ERROR_REASON_FIELD_NUMBER /* 11 */:
                return n.PARAMETRIZED_SERIALIZERS_CACHE_NULLABLE$lambda$0((kj.c) obj, (List) obj2);
            case r.CUSTOM_ATTRIBUTES_FIELD_NUMBER /* 12 */:
                y0 delayMillis = (y0) obj;
                int iIntValue3 = ((Integer) obj2).intValue();
                q.g(delayMillis, "$this$delayMillis");
                return Long.valueOf(hj.d.f9905e.b() + Math.min((long) (Math.pow(2.0d, iIntValue3 - 1) * 1000), RealWebSocket.CANCEL_AFTER_CLOSE_MILLIS));
            case r.PERF_SESSIONS_FIELD_NUMBER /* 13 */:
                th.c it = (th.c) obj2;
                q.g((z0) obj, "<this>");
                q.g(it, "it");
                return b0.f17350a;
            case 14:
                k0 msg = (k0) obj;
                Throwable cancellationException = (Throwable) obj2;
                q.g(msg, "msg");
                z zVar = msg.f16700b;
                if (cancellationException == null) {
                    cancellationException = new CancellationException("DataStore scope was cancelled before updateData could complete");
                }
                zVar.completeExceptionally(cancellationException);
                return b0.f17350a;
            case WebSocketProtocol.B0_MASK_OPCODE /* 15 */:
                String acc = (String) obj;
                ui.g element = (ui.g) obj2;
                q.g(acc, "acc");
                q.g(element, "element");
                if (acc.length() == 0) {
                    return element.toString();
                }
                return acc + ", " + element;
            default:
                ui.i acc2 = (ui.i) obj;
                ui.g element2 = (ui.g) obj2;
                q.g(acc2, "acc");
                q.g(element2, "element");
                ui.i iVarMinusKey = acc2.minusKey(element2.getKey());
                j jVar = j.f20781e;
                if (iVarMinusKey == jVar) {
                    return element2;
                }
                ui.e eVar = ui.e.f20780e;
                ui.f fVar = (ui.f) iVarMinusKey.get(eVar);
                if (fVar == null) {
                    cVar = new ui.c(iVarMinusKey, element2);
                } else {
                    ui.i iVarMinusKey2 = iVarMinusKey.minusKey(eVar);
                    if (iVarMinusKey2 == jVar) {
                        return new ui.c(element2, fVar);
                    }
                    cVar = new ui.c(new ui.c(iVarMinusKey2, element2), fVar);
                }
                return cVar;
        }
    }

    public /* synthetic */ a(r0 r0Var) {
        this.f784e = 12;
    }
}
