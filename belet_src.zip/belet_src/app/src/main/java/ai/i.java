package ai;

import android.view.View;
import androidx.recyclerview.widget.q1;
import vf.n;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class i {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f796a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f797b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f798c;

    public i(int i10) {
        this.f796a = 2;
        this.f797b = 2;
        this.f798c = i10;
    }

    public int a() {
        int i10 = this.f798c;
        if (i10 == 2) {
            return 10;
        }
        if (i10 == 5) {
            return 11;
        }
        if (i10 == 29) {
            return 12;
        }
        if (i10 == 42) {
            return 16;
        }
        if (i10 != 22) {
            return i10 != 23 ? 0 : 15;
        }
        return 1073741824;
    }

    public void b(q1 q1Var) {
        View view = q1Var.f3084a;
        this.f797b = view.getLeft();
        this.f798c = view.getTop();
        view.getRight();
        view.getBottom();
    }

    public n c() {
        return new n(this.f797b, this.f798c);
    }

    public String toString() {
        switch (this.f796a) {
            case 0:
                StringBuilder sb2 = new StringBuilder("MutableRange(start=");
                sb2.append(this.f797b);
                sb2.append(", end=");
                return a0.f.p(sb2, this.f798c, ')');
            case 10:
                StringBuilder sb3 = new StringBuilder("<");
                sb3.append(this.f797b);
                sb3.append(' ');
                return a0.f.p(sb3, this.f798c, '>');
            default:
                return super.toString();
        }
    }

    public /* synthetic */ i(int i10, byte b10) {
        this.f796a = i10;
    }

    public /* synthetic */ i(int i10, int i11, int i12) {
        this.f796a = i12;
        this.f797b = i10;
        this.f798c = i11;
    }

    public i() {
        this.f796a = 0;
        this.f797b = 0;
        this.f798c = 0;
    }
}
