package ai;

import okio.internal.Buffer;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public abstract class g {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final oi.d f794a;

    static {
        String property = System.getProperty("ktor.internal.cio.disable.chararray.pooling");
        f794a = property != null ? Boolean.parseBoolean(property) : false ? new e() : new f(Buffer.SEGMENTING_THRESHOLD, 0);
    }
}
