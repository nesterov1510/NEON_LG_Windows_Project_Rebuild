package ai;

import kotlin.jvm.internal.q;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class e implements oi.d {
    @Override // oi.d
    public final void k0(Object instance) {
        q.g(instance, "instance");
    }

    @Override // oi.d
    public final Object x() {
        return new char[2048];
    }

    @Override // java.lang.AutoCloseable
    public final void close() {
    }
}
