package ai;

import java.util.ArrayList;
import kotlin.jvm.internal.p;
import kotlin.jvm.internal.q;
import okhttp3.internal.url._UrlKt;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class d implements CharSequence, Appendable {
    public ArrayList X;
    public char[] Y;
    public String Z;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final oi.d f789e;

    /* JADX INFO: renamed from: r0, reason: collision with root package name */
    public boolean f790r0;

    /* JADX INFO: renamed from: s0, reason: collision with root package name */
    public int f791s0;

    /* JADX INFO: renamed from: t0, reason: collision with root package name */
    public int f792t0;

    public d() {
        oi.d pool = g.f794a;
        q.g(pool, "pool");
        this.f789e = pool;
    }

    public final char[] a(int i10) {
        ArrayList arrayList = this.X;
        if (arrayList != null) {
            char[] cArr = this.Y;
            q.d(cArr);
            return (char[]) arrayList.get(i10 / cArr.length);
        }
        if (i10 >= 2048) {
            e(i10);
            throw null;
        }
        char[] cArr2 = this.Y;
        if (cArr2 != null) {
            return cArr2;
        }
        e(i10);
        throw null;
    }

    @Override // java.lang.Appendable
    public final Appendable append(char c10) {
        char[] cArrD = d();
        char[] cArr = this.Y;
        q.d(cArr);
        int length = cArr.length;
        int i10 = this.f791s0;
        cArrD[length - i10] = c10;
        this.Z = null;
        this.f791s0 = i10 - 1;
        this.f792t0++;
        return this;
    }

    public final CharSequence b(int i10, int i11) {
        if (i10 == i11) {
            return _UrlKt.FRAGMENT_ENCODE_SET;
        }
        StringBuilder sb2 = new StringBuilder(i11 - i10);
        for (int i12 = i10 - (i10 % 2048); i12 < i11; i12 += 2048) {
            char[] cArrA = a(i12);
            int iMin = Math.min(i11 - i12, 2048);
            for (int iMax = Math.max(0, i10 - i12); iMax < iMin; iMax++) {
                sb2.append(cArrA[iMax]);
            }
        }
        return sb2;
    }

    public final char c(int i10) {
        char[] cArrA = a(i10);
        char[] cArr = this.Y;
        q.d(cArr);
        return cArrA[i10 % cArr.length];
    }

    @Override // java.lang.CharSequence
    public final char charAt(int i10) {
        if (i10 < 0) {
            throw new IllegalArgumentException(p.z(i10, "index is negative: ").toString());
        }
        if (i10 < this.f792t0) {
            return c(i10);
        }
        throw new IllegalArgumentException(a0.f.p(p0.e.p("index ", i10, " is not in range [0, "), this.f792t0, ')').toString());
    }

    public final char[] d() {
        if (this.f791s0 != 0) {
            char[] cArr = this.Y;
            q.d(cArr);
            return cArr;
        }
        char[] cArr2 = (char[]) this.f789e.x();
        char[] cArr3 = this.Y;
        this.Y = cArr2;
        this.f791s0 = cArr2.length;
        this.f790r0 = false;
        if (cArr3 != null) {
            ArrayList arrayList = this.X;
            if (arrayList == null) {
                arrayList = new ArrayList();
                this.X = arrayList;
                arrayList.add(cArr3);
            }
            arrayList.add(cArr2);
        }
        return cArr2;
    }

    public final void e(int i10) {
        if (this.f790r0) {
            throw new IllegalStateException("Buffer is already released");
        }
        StringBuilder sb2 = new StringBuilder();
        sb2.append(i10);
        sb2.append(" is not in range [0; ");
        char[] cArr = this.Y;
        q.d(cArr);
        sb2.append(cArr.length - this.f791s0);
        sb2.append(')');
        throw new IndexOutOfBoundsException(sb2.toString());
    }

    public final boolean equals(Object obj) {
        if (obj instanceof CharSequence) {
            CharSequence charSequence = (CharSequence) obj;
            if (this.f792t0 == charSequence.length()) {
                int i10 = this.f792t0;
                for (int i11 = 0; i11 < i10; i11++) {
                    if (c(i11) != charSequence.charAt(i11)) {
                        return false;
                    }
                }
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        String str = this.Z;
        if (str != null) {
            return str.hashCode();
        }
        int i10 = this.f792t0;
        int iC = 0;
        for (int i11 = 0; i11 < i10; i11++) {
            iC = (iC * 31) + c(i11);
        }
        return iC;
    }

    @Override // java.lang.CharSequence
    public final int length() {
        return this.f792t0;
    }

    @Override // java.lang.CharSequence
    public final CharSequence subSequence(int i10, int i11) {
        if (i10 <= i11) {
            if (i10 < 0) {
                throw new IllegalArgumentException(p.z(i10, "startIndex is negative: ").toString());
            }
            if (i11 <= this.f792t0) {
                return new c(this, i10, i11);
            }
            throw new IllegalArgumentException(a0.f.p(p0.e.p("endIndex (", i11, ") is greater than length ("), this.f792t0, ')').toString());
        }
        throw new IllegalArgumentException(("startIndex (" + i10 + ") should be less or equal to endIndex (" + i11 + ')').toString());
    }

    @Override // java.lang.CharSequence
    public final String toString() {
        String str = this.Z;
        if (str != null) {
            return str;
        }
        String string = b(0, this.f792t0).toString();
        this.Z = string;
        return string;
    }

    @Override // java.lang.Appendable
    public final Appendable append(CharSequence charSequence, int i10, int i11) {
        if (charSequence == null) {
            return this;
        }
        int i12 = i10;
        while (i12 < i11) {
            char[] cArrD = d();
            int length = cArrD.length;
            int i13 = this.f791s0;
            int i14 = length - i13;
            int iMin = Math.min(i11 - i12, i13);
            for (int i15 = 0; i15 < iMin; i15++) {
                cArrD[i14 + i15] = charSequence.charAt(i12 + i15);
            }
            i12 += iMin;
            this.f791s0 -= iMin;
        }
        this.Z = null;
        this.f792t0 = (i11 - i10) + this.f792t0;
        return this;
    }

    @Override // java.lang.Appendable
    public final Appendable append(CharSequence charSequence) {
        if (charSequence == null) {
            return this;
        }
        append(charSequence, 0, charSequence.length());
        return this;
    }
}
