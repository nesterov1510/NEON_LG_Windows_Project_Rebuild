package androidx.appcompat.app;

import android.R;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.Log;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import androidx.appcompat.widget.n3;
import androidx.appcompat.widget.s3;
import androidx.fragment.app.b1;
import androidx.fragment.app.j1;
import j$.util.Objects;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public abstract class j extends c.i implements k {
    public boolean I0;
    public boolean J0;
    public e0 L0;
    public final androidx.fragment.app.y G0 = new androidx.fragment.app.y(new androidx.fragment.app.h0(this));
    public final androidx.lifecycle.x H0 = new androidx.lifecycle.x(this);
    public boolean K0 = true;

    public j() {
        ((m7.e) this.f3797r0.Y).B("android:support:lifecycle", new androidx.fragment.app.e0(this, 0));
        final int i10 = 0;
        w(new i2.a(this) { // from class: androidx.fragment.app.f0

            /* JADX INFO: renamed from: b, reason: collision with root package name */
            public final /* synthetic */ androidx.appcompat.app.j f1884b;

            {
                this.f1884b = this;
            }

            @Override // i2.a
            public final void accept(Object obj) {
                switch (i10) {
                    case 0:
                        this.f1884b.G0.a();
                        break;
                    default:
                        this.f1884b.G0.a();
                        break;
                }
            }
        });
        final int i11 = 1;
        this.B0.add(new i2.a(this) { // from class: androidx.fragment.app.f0

            /* JADX INFO: renamed from: b, reason: collision with root package name */
            public final /* synthetic */ androidx.appcompat.app.j f1884b;

            {
                this.f1884b = this;
            }

            @Override // i2.a
            public final void accept(Object obj) {
                switch (i11) {
                    case 0:
                        this.f1884b.G0.a();
                        break;
                    default:
                        this.f1884b.G0.a();
                        break;
                }
            }
        });
        x(new androidx.fragment.app.g0(this, 0));
    }

    public static boolean C(b1 b1Var) {
        androidx.lifecycle.p pVar = androidx.lifecycle.p.f2033e;
        boolean zC = false;
        for (androidx.fragment.app.d0 d0Var : b1Var.f1827c.i()) {
            if (d0Var != null) {
                androidx.fragment.app.h0 h0Var = d0Var.H0;
                if ((h0Var == null ? null : h0Var.f1895s0) != null) {
                    zC |= C(d0Var.l());
                }
                j1 j1Var = d0Var.f1855d1;
                if (j1Var != null && j1Var.u().f2063d.compareTo(androidx.lifecycle.p.Z) >= 0) {
                    d0Var.f1855d1.f1915r0.g();
                    zC = true;
                }
                if (d0Var.f1854c1.f2063d.compareTo(androidx.lifecycle.p.Z) >= 0) {
                    d0Var.f1854c1.g();
                    zC = true;
                }
            }
        }
        return zC;
    }

    public final p A() {
        if (this.L0 == null) {
            g6.g0 g0Var = p.f1112e;
            this.L0 = new e0(this, null, this, this);
        }
        return this.L0;
    }

    public final b1 B() {
        return ((androidx.fragment.app.h0) this.G0.f1980e).f1894r0;
    }

    public final void D() {
        super.onDestroy();
        ((androidx.fragment.app.h0) this.G0.f1980e).f1894r0.l();
        this.H0.d(androidx.lifecycle.o.ON_DESTROY);
    }

    public final boolean E(int i10, MenuItem menuItem) {
        if (super.onMenuItemSelected(i10, menuItem)) {
            return true;
        }
        if (i10 == 6) {
            return ((androidx.fragment.app.h0) this.G0.f1980e).f1894r0.j();
        }
        return false;
    }

    public final void F() {
        super.onPostResume();
        this.H0.d(androidx.lifecycle.o.ON_RESUME);
        b1 b1Var = ((androidx.fragment.app.h0) this.G0.f1980e).f1894r0;
        b1Var.I = false;
        b1Var.J = false;
        b1Var.P.f1875g = false;
        b1Var.u(7);
    }

    public final void G() {
        androidx.fragment.app.y yVar = this.G0;
        yVar.a();
        androidx.fragment.app.h0 h0Var = (androidx.fragment.app.h0) yVar.f1980e;
        super.onStart();
        this.K0 = false;
        if (!this.I0) {
            this.I0 = true;
            b1 b1Var = h0Var.f1894r0;
            b1Var.I = false;
            b1Var.J = false;
            b1Var.P.f1875g = false;
            b1Var.u(4);
        }
        h0Var.f1894r0.A(true);
        this.H0.d(androidx.lifecycle.o.ON_START);
        b1 b1Var2 = h0Var.f1894r0;
        b1Var2.I = false;
        b1Var2.J = false;
        b1Var2.P.f1875g = false;
        b1Var2.u(5);
    }

    public final void H() {
        b1 b1VarB;
        super.onStop();
        this.K0 = true;
        do {
            b1VarB = B();
            androidx.lifecycle.p pVar = androidx.lifecycle.p.f2033e;
        } while (C(b1VarB));
        b1 b1Var = ((androidx.fragment.app.h0) this.G0.f1980e).f1894r0;
        b1Var.J = true;
        b1Var.P.f1875g = true;
        b1Var.u(4);
        this.H0.d(androidx.lifecycle.o.ON_STOP);
    }

    @Override // android.app.Activity
    public final void addContentView(View view, ViewGroup.LayoutParams layoutParams) {
        z();
        e0 e0Var = (e0) A();
        e0Var.v();
        ((ViewGroup) e0Var.O0.findViewById(R.id.content)).addView(view, layoutParams);
        e0Var.f1085z0.a(e0Var.f1084y0.getCallback());
    }

    /* JADX WARN: Code duplicated, block: B:102:0x0181  */
    /* JADX WARN: Code duplicated, block: B:105:0x018e  */
    /* JADX WARN: Code duplicated, block: B:108:0x019d  */
    /* JADX WARN: Code duplicated, block: B:111:0x01a8  */
    /* JADX WARN: Code duplicated, block: B:114:0x01b0  */
    /* JADX WARN: Code duplicated, block: B:117:0x01b8  */
    /* JADX WARN: Code duplicated, block: B:120:0x01c0  */
    /* JADX WARN: Code duplicated, block: B:124:0x01d7  */
    /* JADX WARN: Code duplicated, block: B:44:0x0095  */
    /* JADX WARN: Code duplicated, block: B:47:0x00a1  */
    /* JADX WARN: Code duplicated, block: B:50:0x00a7  */
    /* JADX WARN: Code duplicated, block: B:52:0x00d0  */
    /* JADX WARN: Code duplicated, block: B:55:0x00df  */
    /* JADX WARN: Code duplicated, block: B:57:0x00e7  */
    /* JADX WARN: Code duplicated, block: B:60:0x00ef  */
    /* JADX WARN: Code duplicated, block: B:63:0x00f7  */
    /* JADX WARN: Code duplicated, block: B:66:0x00ff  */
    /* JADX WARN: Code duplicated, block: B:67:0x0103  */
    /* JADX WARN: Code duplicated, block: B:69:0x010d  */
    /* JADX WARN: Code duplicated, block: B:72:0x0117  */
    /* JADX WARN: Code duplicated, block: B:75:0x011f  */
    /* JADX WARN: Code duplicated, block: B:78:0x0127  */
    /* JADX WARN: Code duplicated, block: B:81:0x012f  */
    /* JADX WARN: Code duplicated, block: B:84:0x0137  */
    /* JADX WARN: Code duplicated, block: B:87:0x013f  */
    /* JADX WARN: Code duplicated, block: B:90:0x014b  */
    /* JADX WARN: Code duplicated, block: B:93:0x015a  */
    /* JADX WARN: Code duplicated, block: B:96:0x0169  */
    /* JADX WARN: Code duplicated, block: B:99:0x0178  */
    @Override // android.app.Activity, android.view.ContextThemeWrapper, android.content.ContextWrapper
    public void attachBaseContext(Context context) {
        Configuration configuration;
        Configuration configuration2;
        l.c cVar;
        float f;
        float f10;
        int i10;
        int i11;
        int i12;
        int i13;
        int i14;
        int i15;
        int i16;
        int i17;
        int i18;
        int i19;
        int i20;
        int i21;
        int i22;
        int i23;
        int i24;
        int i25;
        int i26;
        int i27;
        int i28;
        int i29;
        int i30;
        int i31;
        int i32;
        int i33;
        int i34;
        int i35;
        int i36;
        int i37;
        int i38;
        int i39;
        int i40;
        int i41;
        int i42;
        int i43;
        int i44;
        int i45;
        int i46;
        e0 e0Var = (e0) A();
        e0Var.f1063c1 = true;
        int i47 = e0Var.f1067g1;
        if (i47 == -100) {
            i47 = p.X;
        }
        int iC = e0Var.C(context, i47);
        if (p.b(context) && p.b(context)) {
            if (Build.VERSION.SDK_INT < 33) {
                synchronized (p.f1116v0) {
                    try {
                        e2.e eVar = p.Y;
                        if (eVar == null) {
                            if (p.Z == null) {
                                p.Z = e2.e.b(v1.c.e(context));
                            }
                            if (!p.Z.f7310a.isEmpty()) {
                                p.Y = p.Z;
                            }
                        } else if (!eVar.equals(p.Z)) {
                            e2.e eVar2 = p.Y;
                            p.Z = eVar2;
                            v1.c.d(context, eVar2.f7310a.a());
                        }
                    } catch (Throwable th2) {
                        throw th2;
                    }
                }
            } else if (!p.f1114s0) {
                p.f1112e.execute(new l(context, 0));
            }
        }
        e2.e eVarO = e0.o(context);
        Configuration configuration3 = null;
        if (context instanceof ContextThemeWrapper) {
            try {
                ((ContextThemeWrapper) context).applyOverrideConfiguration(e0.s(context, iC, eVarO, null, false));
            } catch (IllegalStateException unused) {
                if (context instanceof l.c) {
                    try {
                        ((l.c) context).a(e0.s(context, iC, eVarO, null, false));
                    } catch (IllegalStateException unused2) {
                        if (e0.f1060x1) {
                            Configuration configuration4 = new Configuration();
                            configuration4.uiMode = -1;
                            configuration4.fontScale = 0.0f;
                            configuration = context.createConfigurationContext(configuration4).getResources().getConfiguration();
                            configuration2 = context.getResources().getConfiguration();
                            configuration.uiMode = configuration2.uiMode;
                            if (!configuration.equals(configuration2)) {
                                configuration3 = new Configuration();
                                configuration3.fontScale = 0.0f;
                                if (configuration.diff(configuration2) != 0) {
                                    f = configuration.fontScale;
                                    f10 = configuration2.fontScale;
                                    if (f != f10) {
                                        configuration3.fontScale = f10;
                                    }
                                    i10 = configuration.mcc;
                                    i11 = configuration2.mcc;
                                    if (i10 != i11) {
                                        configuration3.mcc = i11;
                                    }
                                    i12 = configuration.mnc;
                                    i13 = configuration2.mnc;
                                    if (i12 != i13) {
                                        configuration3.mnc = i13;
                                    }
                                    i14 = Build.VERSION.SDK_INT;
                                    if (i14 >= 24) {
                                        u.a(configuration, configuration2, configuration3);
                                    } else if (!Objects.equals(configuration.locale, configuration2.locale)) {
                                        configuration3.locale = configuration2.locale;
                                    }
                                    i15 = configuration.touchscreen;
                                    i16 = configuration2.touchscreen;
                                    if (i15 != i16) {
                                        configuration3.touchscreen = i16;
                                    }
                                    i17 = configuration.keyboard;
                                    i18 = configuration2.keyboard;
                                    if (i17 != i18) {
                                        configuration3.keyboard = i18;
                                    }
                                    i19 = configuration.keyboardHidden;
                                    i20 = configuration2.keyboardHidden;
                                    if (i19 != i20) {
                                        configuration3.keyboardHidden = i20;
                                    }
                                    i21 = configuration.navigation;
                                    i22 = configuration2.navigation;
                                    if (i21 != i22) {
                                        configuration3.navigation = i22;
                                    }
                                    i23 = configuration.navigationHidden;
                                    i24 = configuration2.navigationHidden;
                                    if (i23 != i24) {
                                        configuration3.navigationHidden = i24;
                                    }
                                    i25 = configuration.orientation;
                                    i26 = configuration2.orientation;
                                    if (i25 != i26) {
                                        configuration3.orientation = i26;
                                    }
                                    i27 = configuration.screenLayout & 15;
                                    i28 = configuration2.screenLayout & 15;
                                    if (i27 != i28) {
                                        configuration3.screenLayout |= i28;
                                    }
                                    i29 = configuration.screenLayout & 192;
                                    i30 = configuration2.screenLayout & 192;
                                    if (i29 != i30) {
                                        configuration3.screenLayout |= i30;
                                    }
                                    i31 = configuration.screenLayout & 48;
                                    i32 = configuration2.screenLayout & 48;
                                    if (i31 != i32) {
                                        configuration3.screenLayout |= i32;
                                    }
                                    i33 = configuration.screenLayout & 768;
                                    i34 = configuration2.screenLayout & 768;
                                    if (i33 != i34) {
                                        configuration3.screenLayout |= i34;
                                    }
                                    if (i14 >= 26) {
                                        ra.a.d(configuration, configuration2, configuration3);
                                    }
                                    i35 = configuration.uiMode & 15;
                                    i36 = configuration2.uiMode & 15;
                                    if (i35 != i36) {
                                        configuration3.uiMode |= i36;
                                    }
                                    i37 = configuration.uiMode & 48;
                                    i38 = configuration2.uiMode & 48;
                                    if (i37 != i38) {
                                        configuration3.uiMode |= i38;
                                    }
                                    i39 = configuration.screenWidthDp;
                                    i40 = configuration2.screenWidthDp;
                                    if (i39 != i40) {
                                        configuration3.screenWidthDp = i40;
                                    }
                                    i41 = configuration.screenHeightDp;
                                    i42 = configuration2.screenHeightDp;
                                    if (i41 != i42) {
                                        configuration3.screenHeightDp = i42;
                                    }
                                    i43 = configuration.smallestScreenWidthDp;
                                    i44 = configuration2.smallestScreenWidthDp;
                                    if (i43 != i44) {
                                        configuration3.smallestScreenWidthDp = i44;
                                    }
                                    i45 = configuration.densityDpi;
                                    i46 = configuration2.densityDpi;
                                    if (i45 != i46) {
                                        configuration3.densityDpi = i46;
                                    }
                                }
                            }
                            Configuration configurationS = e0.s(context, iC, eVarO, configuration3, true);
                            cVar = new l.c(context, tm.belet.films.R.style.Theme_AppCompat_Empty);
                            cVar.a(configurationS);
                            try {
                                if (context.getTheme() != null) {
                                    z1.b.l(cVar.getTheme());
                                }
                            } catch (NullPointerException unused3) {
                            }
                            context = cVar;
                        }
                    }
                } else if (e0.f1060x1) {
                    Configuration configuration5 = new Configuration();
                    configuration5.uiMode = -1;
                    configuration5.fontScale = 0.0f;
                    configuration = context.createConfigurationContext(configuration5).getResources().getConfiguration();
                    configuration2 = context.getResources().getConfiguration();
                    configuration.uiMode = configuration2.uiMode;
                    if (!configuration.equals(configuration2)) {
                        configuration3 = new Configuration();
                        configuration3.fontScale = 0.0f;
                        if (configuration.diff(configuration2) != 0) {
                            f = configuration.fontScale;
                            f10 = configuration2.fontScale;
                            if (f != f10) {
                                configuration3.fontScale = f10;
                            }
                            i10 = configuration.mcc;
                            i11 = configuration2.mcc;
                            if (i10 != i11) {
                                configuration3.mcc = i11;
                            }
                            i12 = configuration.mnc;
                            i13 = configuration2.mnc;
                            if (i12 != i13) {
                                configuration3.mnc = i13;
                            }
                            i14 = Build.VERSION.SDK_INT;
                            if (i14 >= 24) {
                                u.a(configuration, configuration2, configuration3);
                            } else if (!Objects.equals(configuration.locale, configuration2.locale)) {
                                configuration3.locale = configuration2.locale;
                            }
                            i15 = configuration.touchscreen;
                            i16 = configuration2.touchscreen;
                            if (i15 != i16) {
                                configuration3.touchscreen = i16;
                            }
                            i17 = configuration.keyboard;
                            i18 = configuration2.keyboard;
                            if (i17 != i18) {
                                configuration3.keyboard = i18;
                            }
                            i19 = configuration.keyboardHidden;
                            i20 = configuration2.keyboardHidden;
                            if (i19 != i20) {
                                configuration3.keyboardHidden = i20;
                            }
                            i21 = configuration.navigation;
                            i22 = configuration2.navigation;
                            if (i21 != i22) {
                                configuration3.navigation = i22;
                            }
                            i23 = configuration.navigationHidden;
                            i24 = configuration2.navigationHidden;
                            if (i23 != i24) {
                                configuration3.navigationHidden = i24;
                            }
                            i25 = configuration.orientation;
                            i26 = configuration2.orientation;
                            if (i25 != i26) {
                                configuration3.orientation = i26;
                            }
                            i27 = configuration.screenLayout & 15;
                            i28 = configuration2.screenLayout & 15;
                            if (i27 != i28) {
                                configuration3.screenLayout |= i28;
                            }
                            i29 = configuration.screenLayout & 192;
                            i30 = configuration2.screenLayout & 192;
                            if (i29 != i30) {
                                configuration3.screenLayout |= i30;
                            }
                            i31 = configuration.screenLayout & 48;
                            i32 = configuration2.screenLayout & 48;
                            if (i31 != i32) {
                                configuration3.screenLayout |= i32;
                            }
                            i33 = configuration.screenLayout & 768;
                            i34 = configuration2.screenLayout & 768;
                            if (i33 != i34) {
                                configuration3.screenLayout |= i34;
                            }
                            if (i14 >= 26) {
                                ra.a.d(configuration, configuration2, configuration3);
                            }
                            i35 = configuration.uiMode & 15;
                            i36 = configuration2.uiMode & 15;
                            if (i35 != i36) {
                                configuration3.uiMode |= i36;
                            }
                            i37 = configuration.uiMode & 48;
                            i38 = configuration2.uiMode & 48;
                            if (i37 != i38) {
                                configuration3.uiMode |= i38;
                            }
                            i39 = configuration.screenWidthDp;
                            i40 = configuration2.screenWidthDp;
                            if (i39 != i40) {
                                configuration3.screenWidthDp = i40;
                            }
                            i41 = configuration.screenHeightDp;
                            i42 = configuration2.screenHeightDp;
                            if (i41 != i42) {
                                configuration3.screenHeightDp = i42;
                            }
                            i43 = configuration.smallestScreenWidthDp;
                            i44 = configuration2.smallestScreenWidthDp;
                            if (i43 != i44) {
                                configuration3.smallestScreenWidthDp = i44;
                            }
                            i45 = configuration.densityDpi;
                            i46 = configuration2.densityDpi;
                            if (i45 != i46) {
                                configuration3.densityDpi = i46;
                            }
                        }
                    }
                    Configuration configurationS2 = e0.s(context, iC, eVarO, configuration3, true);
                    cVar = new l.c(context, tm.belet.films.R.style.Theme_AppCompat_Empty);
                    cVar.a(configurationS2);
                    if (context.getTheme() != null) {
                        z1.b.l(cVar.getTheme());
                    }
                    context = cVar;
                }
            }
        } else if (context instanceof l.c) {
            ((l.c) context).a(e0.s(context, iC, eVarO, null, false));
        } else if (e0.f1060x1) {
            Configuration configuration6 = new Configuration();
            configuration6.uiMode = -1;
            configuration6.fontScale = 0.0f;
            configuration = context.createConfigurationContext(configuration6).getResources().getConfiguration();
            configuration2 = context.getResources().getConfiguration();
            configuration.uiMode = configuration2.uiMode;
            if (!configuration.equals(configuration2)) {
                configuration3 = new Configuration();
                configuration3.fontScale = 0.0f;
                if (configuration.diff(configuration2) != 0) {
                    f = configuration.fontScale;
                    f10 = configuration2.fontScale;
                    if (f != f10) {
                        configuration3.fontScale = f10;
                    }
                    i10 = configuration.mcc;
                    i11 = configuration2.mcc;
                    if (i10 != i11) {
                        configuration3.mcc = i11;
                    }
                    i12 = configuration.mnc;
                    i13 = configuration2.mnc;
                    if (i12 != i13) {
                        configuration3.mnc = i13;
                    }
                    i14 = Build.VERSION.SDK_INT;
                    if (i14 >= 24) {
                        u.a(configuration, configuration2, configuration3);
                    } else if (!Objects.equals(configuration.locale, configuration2.locale)) {
                        configuration3.locale = configuration2.locale;
                    }
                    i15 = configuration.touchscreen;
                    i16 = configuration2.touchscreen;
                    if (i15 != i16) {
                        configuration3.touchscreen = i16;
                    }
                    i17 = configuration.keyboard;
                    i18 = configuration2.keyboard;
                    if (i17 != i18) {
                        configuration3.keyboard = i18;
                    }
                    i19 = configuration.keyboardHidden;
                    i20 = configuration2.keyboardHidden;
                    if (i19 != i20) {
                        configuration3.keyboardHidden = i20;
                    }
                    i21 = configuration.navigation;
                    i22 = configuration2.navigation;
                    if (i21 != i22) {
                        configuration3.navigation = i22;
                    }
                    i23 = configuration.navigationHidden;
                    i24 = configuration2.navigationHidden;
                    if (i23 != i24) {
                        configuration3.navigationHidden = i24;
                    }
                    i25 = configuration.orientation;
                    i26 = configuration2.orientation;
                    if (i25 != i26) {
                        configuration3.orientation = i26;
                    }
                    i27 = configuration.screenLayout & 15;
                    i28 = configuration2.screenLayout & 15;
                    if (i27 != i28) {
                        configuration3.screenLayout |= i28;
                    }
                    i29 = configuration.screenLayout & 192;
                    i30 = configuration2.screenLayout & 192;
                    if (i29 != i30) {
                        configuration3.screenLayout |= i30;
                    }
                    i31 = configuration.screenLayout & 48;
                    i32 = configuration2.screenLayout & 48;
                    if (i31 != i32) {
                        configuration3.screenLayout |= i32;
                    }
                    i33 = configuration.screenLayout & 768;
                    i34 = configuration2.screenLayout & 768;
                    if (i33 != i34) {
                        configuration3.screenLayout |= i34;
                    }
                    if (i14 >= 26) {
                        ra.a.d(configuration, configuration2, configuration3);
                    }
                    i35 = configuration.uiMode & 15;
                    i36 = configuration2.uiMode & 15;
                    if (i35 != i36) {
                        configuration3.uiMode |= i36;
                    }
                    i37 = configuration.uiMode & 48;
                    i38 = configuration2.uiMode & 48;
                    if (i37 != i38) {
                        configuration3.uiMode |= i38;
                    }
                    i39 = configuration.screenWidthDp;
                    i40 = configuration2.screenWidthDp;
                    if (i39 != i40) {
                        configuration3.screenWidthDp = i40;
                    }
                    i41 = configuration.screenHeightDp;
                    i42 = configuration2.screenHeightDp;
                    if (i41 != i42) {
                        configuration3.screenHeightDp = i42;
                    }
                    i43 = configuration.smallestScreenWidthDp;
                    i44 = configuration2.smallestScreenWidthDp;
                    if (i43 != i44) {
                        configuration3.smallestScreenWidthDp = i44;
                    }
                    i45 = configuration.densityDpi;
                    i46 = configuration2.densityDpi;
                    if (i45 != i46) {
                        configuration3.densityDpi = i46;
                    }
                }
            }
            Configuration configurationS3 = e0.s(context, iC, eVarO, configuration3, true);
            cVar = new l.c(context, tm.belet.films.R.style.Theme_AppCompat_Empty);
            cVar.a(configurationS3);
            if (context.getTheme() != null) {
                z1.b.l(cVar.getTheme());
            }
            context = cVar;
        }
        super.attachBaseContext(context);
    }

    @Override // android.app.Activity
    public final void closeOptionsMenu() {
        ((e0) A()).A();
        if (getWindow().hasFeature(0)) {
            super.closeOptionsMenu();
        }
    }

    @Override // v1.e, android.app.Activity, android.view.Window.Callback
    public final boolean dispatchKeyEvent(KeyEvent keyEvent) {
        keyEvent.getKeyCode();
        ((e0) A()).A();
        return super.dispatchKeyEvent(keyEvent);
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code duplicated, block: B:28:0x0046  */
    /* JADX WARN: Code duplicated, block: B:58:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    @Override // android.app.Activity
    public final void dump(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        super.dump(str, fileDescriptor, printWriter, strArr);
        if (strArr != null && strArr.length != 0) {
            String str2 = strArr[0];
            switch (str2.hashCode()) {
                case -645125871:
                    if (str2.equals("--translation") && Build.VERSION.SDK_INT >= 31) {
                        return;
                    }
                    break;
                case 100470631:
                    if (str2.equals("--dump-dumpable")) {
                        if (Build.VERSION.SDK_INT >= 33) {
                            return;
                        }
                    }
                    break;
                case 472614934:
                    if (str2.equals("--list-dumpables")) {
                        if (Build.VERSION.SDK_INT >= 33) {
                            return;
                        }
                    }
                    break;
                case 1159329357:
                    if (str2.equals("--contentcapture") && Build.VERSION.SDK_INT >= 29) {
                        return;
                    }
                    break;
                case 1455016274:
                    if (str2.equals("--autofill") && Build.VERSION.SDK_INT >= 26) {
                        return;
                    }
                    break;
            }
        }
        printWriter.print(str);
        printWriter.print("Local FragmentActivity ");
        printWriter.print(Integer.toHexString(System.identityHashCode(this)));
        printWriter.println(" State:");
        String str3 = str + "  ";
        printWriter.print(str3);
        printWriter.print("mCreated=");
        printWriter.print(this.I0);
        printWriter.print(" mResumed=");
        printWriter.print(this.J0);
        printWriter.print(" mStopped=");
        printWriter.print(this.K0);
        if (getApplication() != null) {
            androidx.lifecycle.b1 store = k();
            kotlin.jvm.internal.q.g(store, "store");
            f3.a defaultCreationExtras = f3.a.f7929b;
            kotlin.jvm.internal.q.g(defaultCreationExtras, "defaultCreationExtras");
            m7.i iVar = new m7.i(store, h3.a.f9471c, defaultCreationExtras);
            kotlin.jvm.internal.h hVarA = kotlin.jvm.internal.e0.a(h3.a.class);
            String strB = hVarA.b();
            if (strB == null) {
                throw new IllegalArgumentException("Local and anonymous classes can not be ViewModels");
            }
            j1.j jVar = ((h3.a) iVar.l("androidx.lifecycle.ViewModelProvider.DefaultKey:".concat(strB), hVarA)).f9472b;
            if (jVar.Y > 0) {
                printWriter.print(str3);
                printWriter.println("Loaders:");
                if (jVar.Y > 0) {
                    if (jVar.e(0) != null) {
                        throw new ClassCastException();
                    }
                    printWriter.print(str3);
                    printWriter.print("  #");
                    printWriter.print(jVar.f12619e[0]);
                    printWriter.print(": ");
                    throw null;
                }
            }
        }
        ((androidx.fragment.app.h0) this.G0.f1980e).f1894r0.w(str, fileDescriptor, printWriter, strArr);
    }

    @Override // android.app.Activity
    public final View findViewById(int i10) {
        e0 e0Var = (e0) A();
        e0Var.v();
        return e0Var.f1084y0.findViewById(i10);
    }

    @Override // android.app.Activity
    public final MenuInflater getMenuInflater() {
        e0 e0Var = (e0) A();
        if (e0Var.C0 == null) {
            e0Var.A();
            q0 q0Var = e0Var.B0;
            e0Var.C0 = new l.h(q0Var != null ? q0Var.B() : e0Var.f1083x0);
        }
        return e0Var.C0;
    }

    @Override // android.view.ContextThemeWrapper, android.content.ContextWrapper, android.content.Context
    public final Resources getResources() {
        int i10 = s3.f1432a;
        return super.getResources();
    }

    @Override // android.app.Activity
    public final void invalidateOptionsMenu() {
        e0 e0Var = (e0) A();
        if (e0Var.B0 != null) {
            e0Var.A();
            e0Var.B0.getClass();
            e0Var.B(0);
        }
    }

    @Override // c.i, android.app.Activity
    public final void onActivityResult(int i10, int i11, Intent intent) {
        this.G0.a();
        super.onActivityResult(i10, i11, intent);
    }

    @Override // c.i, android.app.Activity, android.content.ComponentCallbacks
    public final void onConfigurationChanged(Configuration configuration) throws IllegalAccessException {
        super.onConfigurationChanged(configuration);
        e0 e0Var = (e0) A();
        if (e0Var.T0 && e0Var.N0) {
            e0Var.A();
            q0 q0Var = e0Var.B0;
            if (q0Var != null) {
                q0Var.E(q0Var.f.getResources().getBoolean(tm.belet.films.R.bool.abc_action_bar_embed_tabs));
            }
        }
        androidx.appcompat.widget.y yVarA = androidx.appcompat.widget.y.a();
        Context context = e0Var.f1083x0;
        synchronized (yVarA) {
            yVarA.f1491a.l(context);
        }
        e0Var.f1066f1 = new Configuration(e0Var.f1083x0.getResources().getConfiguration());
        e0Var.m(false, false);
    }

    @Override // c.i, v1.e, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.H0.d(androidx.lifecycle.o.ON_CREATE);
        b1 b1Var = ((androidx.fragment.app.h0) this.G0.f1980e).f1894r0;
        b1Var.I = false;
        b1Var.J = false;
        b1Var.P.f1875g = false;
        b1Var.u(1);
    }

    @Override // android.app.Activity, android.view.LayoutInflater.Factory2
    public final View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        View viewOnCreateView = ((androidx.fragment.app.h0) this.G0.f1980e).f1894r0.f.onCreateView(view, str, context, attributeSet);
        return viewOnCreateView == null ? super.onCreateView(view, str, context, attributeSet) : viewOnCreateView;
    }

    @Override // android.app.Activity
    public void onDestroy() {
        D();
        A().d();
    }

    @Override // android.app.Activity, android.view.KeyEvent.Callback
    public final boolean onKeyDown(int i10, KeyEvent keyEvent) {
        Window window;
        if (Build.VERSION.SDK_INT >= 26 || keyEvent.isCtrlPressed() || KeyEvent.metaStateHasNoModifiers(keyEvent.getMetaState()) || keyEvent.getRepeatCount() != 0 || KeyEvent.isModifierKey(keyEvent.getKeyCode()) || (window = getWindow()) == null || window.getDecorView() == null || !window.getDecorView().dispatchKeyShortcutEvent(keyEvent)) {
            return super.onKeyDown(i10, keyEvent);
        }
        return true;
    }

    @Override // c.i, android.app.Activity, android.view.Window.Callback
    public final boolean onMenuItemSelected(int i10, MenuItem menuItem) {
        Intent intentA;
        if (!E(i10, menuItem)) {
            e0 e0Var = (e0) A();
            e0Var.A();
            q0 q0Var = e0Var.B0;
            if (menuItem.getItemId() != 16908332 || q0Var == null || (((n3) q0Var.f1123j).f1382b & 4) == 0 || (intentA = v1.c.a(this)) == null) {
                return false;
            }
            if (!shouldUpRecreateTask(intentA)) {
                navigateUpTo(intentA);
                return true;
            }
            ArrayList arrayList = new ArrayList();
            Intent intentA2 = v1.c.a(this);
            if (intentA2 == null) {
                intentA2 = v1.c.a(this);
            }
            if (intentA2 != null) {
                ComponentName component = intentA2.getComponent();
                if (component == null) {
                    component = intentA2.resolveActivity(getPackageManager());
                }
                int size = arrayList.size();
                try {
                    Intent intentB = v1.c.b(this, component);
                    while (intentB != null) {
                        arrayList.add(size, intentB);
                        intentB = v1.c.b(this, intentB.getComponent());
                    }
                    arrayList.add(intentA2);
                } catch (PackageManager.NameNotFoundException e3) {
                    Log.e("TaskStackBuilder", "Bad ComponentName while traversing activity parent metadata");
                    throw new IllegalArgumentException(e3);
                }
            }
            if (arrayList.isEmpty()) {
                throw new IllegalStateException("No intents added to TaskStackBuilder; cannot startActivities");
            }
            Intent[] intentArr = (Intent[]) arrayList.toArray(new Intent[0]);
            intentArr[0] = new Intent(intentArr[0]).addFlags(268484608);
            startActivities(intentArr, null);
            try {
                finishAffinity();
            } catch (IllegalStateException unused) {
                finish();
            }
        }
        return true;
    }

    @Override // android.app.Activity
    public final void onPause() {
        super.onPause();
        this.J0 = false;
        ((androidx.fragment.app.h0) this.G0.f1980e).f1894r0.u(5);
        this.H0.d(androidx.lifecycle.o.ON_PAUSE);
    }

    @Override // android.app.Activity
    public final void onPostCreate(Bundle bundle) {
        super.onPostCreate(bundle);
        ((e0) A()).v();
    }

    @Override // android.app.Activity
    public final void onPostResume() {
        F();
        e0 e0Var = (e0) A();
        e0Var.A();
        q0 q0Var = e0Var.B0;
        if (q0Var != null) {
            q0Var.f1138y = true;
        }
    }

    @Override // c.i, android.app.Activity
    public final void onRequestPermissionsResult(int i10, String[] strArr, int[] iArr) {
        this.G0.a();
        super.onRequestPermissionsResult(i10, strArr, iArr);
    }

    @Override // android.app.Activity
    public void onResume() {
        androidx.fragment.app.y yVar = this.G0;
        yVar.a();
        super.onResume();
        this.J0 = true;
        ((androidx.fragment.app.h0) yVar.f1980e).f1894r0.A(true);
    }

    @Override // android.app.Activity
    public void onStart() throws IllegalAccessException {
        G();
        ((e0) A()).m(true, false);
    }

    @Override // android.app.Activity
    public final void onStateNotSaved() {
        this.G0.a();
    }

    @Override // android.app.Activity
    public void onStop() {
        H();
        e0 e0Var = (e0) A();
        e0Var.A();
        q0 q0Var = e0Var.B0;
        if (q0Var != null) {
            q0Var.f1138y = false;
            l.i iVar = q0Var.f1137x;
            if (iVar != null) {
                iVar.a();
            }
        }
    }

    @Override // android.app.Activity
    public final void onTitleChanged(CharSequence charSequence, int i10) {
        super.onTitleChanged(charSequence, i10);
        A().l(charSequence);
    }

    @Override // android.app.Activity
    public final void openOptionsMenu() {
        ((e0) A()).A();
        if (getWindow().hasFeature(0)) {
            super.openOptionsMenu();
        }
    }

    @Override // android.app.Activity
    public final void setContentView(int i10) {
        z();
        A().g(i10);
    }

    @Override // android.app.Activity, android.view.ContextThemeWrapper, android.content.ContextWrapper, android.content.Context
    public final void setTheme(int i10) {
        super.setTheme(i10);
        ((e0) A()).f1068h1 = i10;
    }

    @Override // c.i, android.app.Activity
    public void setContentView(View view) {
        z();
        A().i(view);
    }

    @Override // android.app.Activity
    public final void setContentView(View view, ViewGroup.LayoutParams layoutParams) {
        z();
        A().k(view, layoutParams);
    }

    @Override // android.app.Activity, android.view.LayoutInflater.Factory
    public final View onCreateView(String str, Context context, AttributeSet attributeSet) {
        View viewOnCreateView = ((androidx.fragment.app.h0) this.G0.f1980e).f1894r0.f.onCreateView(null, str, context, attributeSet);
        return viewOnCreateView == null ? super.onCreateView(str, context, attributeSet) : viewOnCreateView;
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public final void onContentChanged() {
    }
}
