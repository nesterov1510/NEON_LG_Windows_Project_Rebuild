package androidx.appcompat.app;

import android.content.Context;
import android.content.IntentFilter;
import android.os.Looper;
import android.util.SparseIntArray;
import android.view.MenuItem;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.TextureView;
import i3.a1;
import i3.a2;
import i3.g2;
import i3.i2;
import i3.m2;
import i3.t0;
import i3.u0;
import i3.w0;
import i3.y0;
import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Set;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public abstract class a0 implements a1 {
    public Object X;
    public Object Y;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f1003e;

    public a0(String content, List parameters) {
        this.f1003e = 7;
        kotlin.jvm.internal.q.g(content, "content");
        kotlin.jvm.internal.q.g(parameters, "parameters");
        this.X = content;
        this.Y = parameters;
    }

    public static float f1(int i10, int i11, int i12) {
        return tc.b.e((i10 - i11) / i12, 0.0f, 1.0f);
    }

    @Override // i3.a1
    public m2 A() {
        return ((a1) this.X).A();
    }

    @Override // i3.a1
    public void A0(SurfaceView surfaceView) {
        ((a1) this.X).A0(surfaceView);
    }

    @Override // i3.a1
    public void B0(int i10, int i11) {
        ((a1) this.X).B0(i10, i11);
    }

    @Override // i3.a1
    public void C(i3.n0 n0Var) {
        ((a1) this.X).C(n0Var);
    }

    @Override // i3.a1
    public void C0(int i10, int i11, int i12) {
        ((a1) this.X).C0(i10, i11, i12);
    }

    @Override // i3.a1
    public float D() {
        return ((a1) this.X).D();
    }

    @Override // i3.a1
    public void E() {
        ((a1) this.X).E();
    }

    @Override // i3.a1
    public int E0() {
        return ((a1) this.X).E0();
    }

    @Override // i3.a1
    public i3.e F() {
        return ((a1) this.X).F();
    }

    @Override // i3.a1
    public void F0(List list) {
        ((a1) this.X).F0(list);
    }

    @Override // i3.a1
    public void G(int i10, boolean z5) {
        ((a1) this.X).G(i10, z5);
    }

    @Override // i3.a1
    public a2 G0() {
        return ((a1) this.X).G0();
    }

    @Override // i3.a1
    public i3.o H() {
        return ((a1) this.X).H();
    }

    @Override // i3.a1
    public boolean H0() {
        return ((a1) this.X).H0();
    }

    @Override // i3.a1
    public void I() {
        ((a1) this.X).I();
    }

    @Override // i3.a1
    public int I0() {
        return ((a1) this.X).I0();
    }

    @Override // i3.a1
    public void J(i3.k0 k0Var) {
        ((a1) this.X).J(k0Var);
    }

    @Override // i3.a1
    public void J0() {
        ((a1) this.X).J0();
    }

    @Override // i3.a1
    public void K(int i10, int i11) {
        ((a1) this.X).K(i10, i11);
    }

    @Override // i3.a1
    public void K0() {
        ((a1) this.X).K0();
    }

    @Override // i3.a1
    public void L(int i10) {
        ((a1) this.X).L(i10);
    }

    @Override // i3.a1
    public boolean L0() {
        return ((a1) this.X).L0();
    }

    @Override // i3.a1
    public int M() {
        return ((a1) this.X).M();
    }

    @Override // i3.a1
    public g2 M0() {
        return ((a1) this.X).M0();
    }

    @Override // i3.a1
    public void N(int i10, i3.k0 k0Var) {
        ((a1) this.X).N(i10, k0Var);
    }

    @Override // i3.a1
    public long N0() {
        return ((a1) this.X).N0();
    }

    @Override // i3.a1
    public void O(SurfaceView surfaceView) {
        ((a1) this.X).O(surfaceView);
    }

    @Override // i3.a1
    public void O0(int i10) {
        ((a1) this.X).O0(i10);
    }

    @Override // i3.a1
    public l3.x P() {
        return ((a1) this.X).P();
    }

    @Override // i3.a1
    public void P0() {
        m0();
    }

    @Override // i3.a1
    public void Q(int i10, int i11, List list) {
        ((a1) this.X).Q(i10, i11, list);
    }

    @Override // i3.a1
    public void Q0() {
        ((a1) this.X).Q0();
    }

    @Override // i3.a1
    public void R(int i10) {
        ((a1) this.X).R(i10);
    }

    @Override // i3.a1
    public void R0(TextureView textureView) {
        ((a1) this.X).R0(textureView);
    }

    @Override // i3.a1
    public void S0() {
        ((a1) this.X).S0();
    }

    @Override // i3.a1
    public void T(i3.e eVar, boolean z5) {
        ((a1) this.X).T(eVar, z5);
    }

    @Override // i3.a1
    public i3.n0 T0() {
        return ((a1) this.X).T0();
    }

    @Override // i3.a1
    public void U(long j10) {
        ((a1) this.X).U(j10);
    }

    @Override // i3.a1
    public void U0(List list) {
        ((a1) this.X).U0(list);
    }

    @Override // i3.a1
    public void V(int i10, int i11) {
        ((a1) this.X).V(i10, i11);
    }

    @Override // i3.a1
    public void V0(SurfaceHolder surfaceHolder) {
        ((a1) this.X).V0(surfaceHolder);
    }

    @Override // i3.a1
    public void W() {
        ((a1) this.X).W();
    }

    @Override // i3.a1
    public long W0() {
        return ((a1) this.X).W0();
    }

    @Override // i3.a1
    public long X0() {
        return ((a1) this.X).X0();
    }

    @Override // i3.a1
    public void Y(SurfaceHolder surfaceHolder) {
        ((a1) this.X).Y(surfaceHolder);
    }

    @Override // i3.a1
    public i3.k0 Y0() {
        return ((a1) this.X).Y0();
    }

    public abstract void Z0();

    @Override // i3.a1
    public void a0(float f) {
        ((a1) this.X).a0(f);
    }

    public void a1() {
        z zVar = (z) this.X;
        if (zVar != null) {
            try {
                ((e0) this.Y).f1083x0.unregisterReceiver(zVar);
            } catch (IllegalArgumentException unused) {
            }
            this.X = null;
        }
    }

    @Override // i3.a1
    public void b() {
        ((a1) this.X).b();
    }

    @Override // i3.a1
    public void b0() {
        B();
    }

    public abstract IntentFilter b1();

    @Override // i3.a1
    public void c() {
        ((a1) this.X).c();
    }

    @Override // i3.a1
    public boolean c1() {
        return ((a1) this.X).c1();
    }

    @Override // i3.a1
    public void d(float f) {
        ((a1) this.X).d(f);
    }

    @Override // i3.a1
    public t0 d0() {
        return ((a1) this.X).d0();
    }

    public abstract int d1();

    @Override // i3.a1
    public boolean e() {
        return ((a1) this.X).e();
    }

    @Override // i3.a1
    public void e0(boolean z5) {
        ((a1) this.X).e0(z5);
    }

    @Override // i3.a1
    public boolean e1() {
        return ((a1) this.X).e1();
    }

    @Override // i3.a1
    public int f() {
        return ((a1) this.X).f();
    }

    @Override // i3.a1
    public void f0(int i10) {
        ((a1) this.X).f0(i10);
    }

    @Override // i3.a1
    public void g(u0 u0Var) {
        ((a1) this.X).g(u0Var);
    }

    @Override // i3.a1
    public long g0() {
        return ((a1) this.X).g0();
    }

    @Override // i3.a1
    public boolean g1(int i10) {
        return ((a1) this.X).g1(i10);
    }

    @Override // i3.a1
    public long getDuration() {
        return ((a1) this.X).getDuration();
    }

    @Override // i3.a1
    public int h() {
        return ((a1) this.X).h();
    }

    @Override // i3.a1
    public long h0() {
        return ((a1) this.X).h0();
    }

    @Override // i3.a1
    public boolean h1() {
        return ((a1) this.X).h1();
    }

    @Override // i3.a1
    public u0 i() {
        return ((a1) this.X).i();
    }

    @Override // i3.a1
    public void i0(int i10, List list) {
        ((a1) this.X).i0(i10, list);
    }

    @Override // i3.a1
    public Looper i1() {
        return ((a1) this.X).i1();
    }

    @Override // i3.a1
    public int j() {
        return ((a1) this.X).j();
    }

    @Override // i3.a1
    public void j0(int i10, i3.k0 k0Var) {
        ((a1) this.X).j0(i10, k0Var);
    }

    public MenuItem j1(MenuItem menuItem) {
        if (!(menuItem instanceof c2.a)) {
            return menuItem;
        }
        c2.a aVar = (c2.a) menuItem;
        if (((j1.i) this.Y) == null) {
            this.Y = new j1.i(0);
        }
        MenuItem menuItem2 = (MenuItem) ((j1.i) this.Y).get(aVar);
        if (menuItem2 != null) {
            return menuItem2;
        }
        m.q qVar = new m.q((Context) this.X, aVar);
        ((j1.i) this.Y).put(aVar, qVar);
        return qVar;
    }

    @Override // i3.a1
    public void k(Surface surface) {
        ((a1) this.X).k(surface);
    }

    @Override // i3.a1
    public void k0() {
        ((a1) this.X).k0();
    }

    public int k1(int i10, int i11) {
        int iM1 = m1(i10);
        int i12 = 0;
        int i13 = 0;
        for (int i14 = 0; i14 < i10; i14++) {
            int iM2 = m1(i14);
            i12 += iM2;
            if (i12 == i11) {
                i13++;
                i12 = 0;
            } else if (i12 > i11) {
                i13++;
                i12 = iM2;
            }
        }
        return i12 + iM1 > i11 ? i13 + 1 : i13;
    }

    @Override // i3.a1
    public boolean l() {
        return ((a1) this.X).l();
    }

    @Override // i3.a1
    public long l0() {
        return ((a1) this.X).l0();
    }

    public int l1(int i10, int i11) {
        int iM1 = m1(i10);
        if (iM1 == i11) {
            return 0;
        }
        int i12 = 0;
        for (int i13 = 0; i13 < i10; i13++) {
            int iM2 = m1(i13);
            i12 += iM2;
            if (i12 == i11) {
                i12 = 0;
            } else if (i12 > i11) {
                i12 = iM2;
            }
        }
        if (iM1 + i12 <= i11) {
            return i12;
        }
        return 0;
    }

    @Override // i3.a1
    public long m() {
        return ((a1) this.X).m();
    }

    public abstract int m1(int i10);

    @Override // i3.a1
    public long n() {
        return ((a1) this.X).n();
    }

    @Override // i3.a1
    public void n0(int i10) {
        ((a1) this.X).n0(i10);
    }

    public void n1() {
        ((SparseIntArray) this.X).clear();
    }

    @Override // i3.a1
    public void o(int i10, long j10) {
        ((a1) this.X).o(i10, j10);
    }

    @Override // i3.a1
    public i2 o0() {
        return ((a1) this.X).o0();
    }

    @Override // i3.a1
    public boolean o1() {
        return ((a1) this.X).o1();
    }

    @Override // i3.a1
    public w0 p() {
        return ((a1) this.X).p();
    }

    @Override // i3.a1
    public void p0(g2 g2Var) {
        ((a1) this.X).p0(g2Var);
    }

    public abstract void p1();

    @Override // i3.a1
    public boolean q() {
        return ((a1) this.X).q();
    }

    @Override // i3.a1
    public void q0(y0 y0Var) {
        synchronized (((IdentityHashMap) this.Y)) {
            try {
                i3.t tVar = (i3.t) ((IdentityHashMap) this.Y).get(y0Var);
                if (tVar == null) {
                    tVar = new i3.t(this, y0Var);
                }
                ((a1) this.X).q0(tVar);
                ((IdentityHashMap) this.Y).put(y0Var, tVar);
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    public abstract void q1();

    @Override // i3.a1
    public void r() {
        ((a1) this.X).r();
    }

    @Override // i3.a1
    public i3.n0 r0() {
        return ((a1) this.X).r0();
    }

    public String r1(String name) {
        kotlin.jvm.internal.q.g(name, "name");
        List list = (List) this.Y;
        int iN = ri.n.N(list);
        if (iN < 0) {
            return null;
        }
        int i10 = 0;
        while (true) {
            yh.l lVar = (yh.l) list.get(i10);
            if (mj.t.T(lVar.f23058a, name)) {
                return lVar.f23059b;
            }
            if (i10 == iN) {
                return null;
            }
            i10++;
        }
    }

    @Override // i3.a1
    public void s(Surface surface) {
        ((a1) this.X).s(surface);
    }

    @Override // i3.a1
    public boolean s0() {
        return ((a1) this.X).s0();
    }

    public abstract String s1();

    @Override // i3.a1
    public void stop() {
        ((a1) this.X).stop();
    }

    @Override // i3.a1
    public void t(boolean z5) {
        ((a1) this.X).t(z5);
    }

    @Override // i3.a1
    public k3.c t0() {
        return ((a1) this.X).t0();
    }

    public abstract void t1(yb.c cVar);

    /* JADX WARN: Code duplicated, block: B:43:0x00bb  */
    /* JADX WARN: Code duplicated, block: B:45:0x00c2  */
    /* JADX WARN: Code duplicated, block: B:49:0x00e0  */
    /* JADX WARN: Code duplicated, block: B:51:0x00e8  */
    /* JADX WARN: Code duplicated, block: B:53:0x00ec  */
    /* JADX WARN: Code duplicated, block: B:55:0x00f0 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:56:0x00f2 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:57:0x00f4  */
    /* JADX WARN: Code duplicated, block: B:58:0x00f8  */
    /* JADX WARN: Code duplicated, block: B:59:0x00fe  */
    /* JADX WARN: Code duplicated, block: B:60:0x0104  */
    /* JADX WARN: Code duplicated, block: B:61:0x010a  */
    /* JADX WARN: Code duplicated, block: B:62:0x0110  */
    /* JADX WARN: Code duplicated, block: B:65:0x0123 A[LOOP:4: B:44:0x00c0->B:65:0x0123, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:81:0x0126 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:82:0x00d2 A[SYNTHETIC] */
    public String toString() {
        StringBuilder sb2;
        int length;
        int i10;
        char cCharAt;
        int length2;
        int i11;
        switch (this.f1003e) {
            case 7:
                String str = (String) this.X;
                List<yh.l> list = (List) this.Y;
                if (list.isEmpty()) {
                    return str;
                }
                int length3 = str.length();
                int length4 = 0;
                for (yh.l lVar : list) {
                    length4 += lVar.f23059b.length() + lVar.f23058a.length() + 3;
                }
                StringBuilder sb3 = new StringBuilder(length3 + length4);
                sb3.append(str);
                int iN = ri.n.N(list);
                if (iN >= 0) {
                    int i12 = 0;
                    while (true) {
                        yh.l lVar2 = (yh.l) list.get(i12);
                        sb3.append("; ");
                        sb3.append(lVar2.f23058a);
                        sb3.append("=");
                        String str2 = lVar2.f23059b;
                        Set set = yh.m.f23060a;
                        if (str2.length() != 0) {
                            if (str2.length() < 2) {
                                length2 = str2.length();
                                i11 = 0;
                                while (true) {
                                    if (i11 < length2) {
                                        if (yh.m.f23060a.contains(Character.valueOf(str2.charAt(i11)))) {
                                            sb2 = new StringBuilder("\"");
                                            length = str2.length();
                                            for (i10 = 0; i10 < length; i10++) {
                                                cCharAt = str2.charAt(i10);
                                                if (cCharAt != '\t') {
                                                    sb2.append("\\t");
                                                } else if (cCharAt != '\n') {
                                                    sb2.append("\\n");
                                                } else if (cCharAt != '\r') {
                                                    sb2.append("\\r");
                                                } else if (cCharAt != '\"') {
                                                    sb2.append("\\\"");
                                                } else if (cCharAt != '\\') {
                                                    sb2.append(cCharAt);
                                                } else {
                                                    sb2.append("\\\\");
                                                }
                                            }
                                            sb2.append("\"");
                                            sb3.append(sb2.toString());
                                        } else {
                                            i11++;
                                        }
                                    }
                                }
                            } else {
                                if (str2.length() == 0) {
                                    throw new NoSuchElementException("Char sequence is empty.");
                                }
                                if (str2.charAt(0) == '\"' && mj.l.n0(str2) == '\"') {
                                    int i13 = 1;
                                    while (true) {
                                        int iJ0 = mj.l.j0(str2, kotlinx.serialization.json.internal.b.STRING, i13, 4);
                                        if (iJ0 != mj.l.g0(str2)) {
                                            int i14 = 0;
                                            for (int i15 = iJ0 - 1; str2.charAt(i15) == '\\'; i15--) {
                                                i14++;
                                            }
                                            if (i14 % 2 == 0) {
                                                length2 = str2.length();
                                                i11 = 0;
                                                while (true) {
                                                    if (i11 < length2) {
                                                        if (yh.m.f23060a.contains(Character.valueOf(str2.charAt(i11)))) {
                                                            sb2 = new StringBuilder("\"");
                                                            length = str2.length();
                                                            while (i10 < length) {
                                                                cCharAt = str2.charAt(i10);
                                                                if (cCharAt != '\t') {
                                                                    sb2.append("\\t");
                                                                } else if (cCharAt != '\n') {
                                                                    sb2.append("\\n");
                                                                } else if (cCharAt != '\r') {
                                                                    sb2.append("\\r");
                                                                } else if (cCharAt != '\"') {
                                                                    sb2.append("\\\"");
                                                                } else if (cCharAt != '\\') {
                                                                    sb2.append(cCharAt);
                                                                } else {
                                                                    sb2.append("\\\\");
                                                                }
                                                            }
                                                            sb2.append("\"");
                                                            sb3.append(sb2.toString());
                                                        } else {
                                                            i11++;
                                                        }
                                                    }
                                                }
                                            } else {
                                                i13 = iJ0 + 1;
                                                if (i13 >= str2.length()) {
                                                }
                                            }
                                        }
                                    }
                                } else {
                                    length2 = str2.length();
                                    i11 = 0;
                                    while (true) {
                                        if (i11 < length2) {
                                            if (yh.m.f23060a.contains(Character.valueOf(str2.charAt(i11)))) {
                                                sb2 = new StringBuilder("\"");
                                                length = str2.length();
                                                while (i10 < length) {
                                                    cCharAt = str2.charAt(i10);
                                                    if (cCharAt != '\t') {
                                                        sb2.append("\\t");
                                                    } else if (cCharAt != '\n') {
                                                        sb2.append("\\n");
                                                    } else if (cCharAt != '\r') {
                                                        sb2.append("\\r");
                                                    } else if (cCharAt != '\"') {
                                                        sb2.append("\\\"");
                                                    } else if (cCharAt != '\\') {
                                                        sb2.append(cCharAt);
                                                    } else {
                                                        sb2.append("\\\\");
                                                    }
                                                }
                                                sb2.append("\"");
                                                sb3.append(sb2.toString());
                                            } else {
                                                i11++;
                                            }
                                        }
                                    }
                                }
                            }
                            sb3.append(str2);
                        } else {
                            sb2 = new StringBuilder("\"");
                            length = str2.length();
                            while (i10 < length) {
                                cCharAt = str2.charAt(i10);
                                if (cCharAt != '\t') {
                                    sb2.append("\\t");
                                } else if (cCharAt != '\n') {
                                    sb2.append("\\n");
                                } else if (cCharAt != '\r') {
                                    sb2.append("\\r");
                                } else if (cCharAt != '\"') {
                                    sb2.append("\\\"");
                                } else if (cCharAt != '\\') {
                                    sb2.append(cCharAt);
                                } else {
                                    sb2.append("\\\\");
                                }
                            }
                            sb2.append("\"");
                            sb3.append(sb2.toString());
                        }
                        if (i12 != iN) {
                            i12++;
                        }
                    }
                }
                String string = sb3.toString();
                kotlin.jvm.internal.q.d(string);
                return string;
            default:
                return super.toString();
        }
    }

    @Override // i3.a1
    public void u(y0 y0Var) {
        synchronized (((IdentityHashMap) this.Y)) {
            y0 y0Var2 = (y0) ((IdentityHashMap) this.Y).remove(y0Var);
            a1 a1Var = (a1) this.X;
            if (y0Var2 != null) {
                y0Var = y0Var2;
            }
            a1Var.u(y0Var);
        }
    }

    @Override // i3.a1
    public void u0() {
        ((a1) this.X).u0();
    }

    public abstract void u1();

    @Override // i3.a1
    public int v() {
        return ((a1) this.X).v();
    }

    public void v1() {
        a1();
        IntentFilter intentFilterB1 = b1();
        if (intentFilterB1.countActions() == 0) {
            return;
        }
        if (((z) this.X) == null) {
            this.X = new z(0, this);
        }
        ((e0) this.Y).f1083x0.registerReceiver((z) this.X, intentFilterB1);
    }

    @Override // i3.a1
    public long w() {
        return ((a1) this.X).w();
    }

    @Override // i3.a1
    public int w0() {
        return ((a1) this.X).w0();
    }

    public abstract void w1();

    @Override // i3.a1
    public long x() {
        return ((a1) this.X).x();
    }

    @Override // i3.a1
    public int x0() {
        return ((a1) this.X).x0();
    }

    public abstract void x1();

    @Override // i3.a1
    public int y() {
        return ((a1) this.X).y();
    }

    @Override // i3.a1
    public void y0(int i10) {
        ((a1) this.X).y0(i10);
    }

    @Override // i3.a1
    public void z(TextureView textureView) {
        ((a1) this.X).z(textureView);
    }

    @Override // i3.a1
    public void z0(boolean z5) {
        ((a1) this.X).z0(z5);
    }

    public a0(Context context) {
        this.f1003e = 5;
        this.X = context;
    }

    public a0(int i10) {
        this.f1003e = 6;
        this.Y = new ArrayList();
        for (int i11 = 0; i11 < i10; i11++) {
            ((ArrayList) this.Y).add(new yb.o());
        }
    }

    public a0(zf.a aVar) {
        this.f1003e = 4;
        this.X = aVar;
        this.Y = new k8.k(aVar);
    }

    public a0(a1 a1Var) {
        this.f1003e = 3;
        this.Y = new IdentityHashMap();
        this.X = a1Var;
    }

    public a0(int i10, byte b10) {
        this.f1003e = i10;
        switch (i10) {
            case 2:
                this.X = pj.b.atomic(1);
                this.Y = kotlinx.coroutines.b0.CompletableDeferred$default(null, 1, null);
                break;
            default:
                this.X = new SparseIntArray();
                this.Y = new SparseIntArray();
                break;
        }
    }

    public a0(e0 e0Var) {
        this.f1003e = 0;
        this.Y = e0Var;
    }
}
