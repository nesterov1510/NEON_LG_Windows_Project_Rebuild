package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import tm.belet.films.R;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public class ActionBarContainer extends FrameLayout {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f1165e;

    /* JADX INFO: renamed from: r0, reason: collision with root package name */
    public View f1166r0;

    /* JADX INFO: renamed from: s0, reason: collision with root package name */
    public View f1167s0;

    /* JADX INFO: renamed from: t0, reason: collision with root package name */
    public Drawable f1168t0;
    public Drawable u0;

    /* JADX INFO: renamed from: v0, reason: collision with root package name */
    public Drawable f1169v0;

    /* JADX INFO: renamed from: w0, reason: collision with root package name */
    public final boolean f1170w0;

    /* JADX INFO: renamed from: x0, reason: collision with root package name */
    public boolean f1171x0;

    /* JADX INFO: renamed from: y0, reason: collision with root package name */
    public final int f1172y0;

    public ActionBarContainer(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setBackground(new b(this));
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, g.a.f8270a);
        boolean z5 = false;
        this.f1168t0 = typedArrayObtainStyledAttributes.getDrawable(0);
        this.u0 = typedArrayObtainStyledAttributes.getDrawable(2);
        this.f1172y0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(13, -1);
        if (getId() == R.id.split_action_bar) {
            this.f1170w0 = true;
            this.f1169v0 = typedArrayObtainStyledAttributes.getDrawable(1);
        }
        typedArrayObtainStyledAttributes.recycle();
        if (!this.f1170w0 ? !(this.f1168t0 != null || this.u0 != null) : this.f1169v0 == null) {
            z5 = true;
        }
        setWillNotDraw(z5);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        Drawable drawable = this.f1168t0;
        if (drawable != null && drawable.isStateful()) {
            this.f1168t0.setState(getDrawableState());
        }
        Drawable drawable2 = this.u0;
        if (drawable2 != null && drawable2.isStateful()) {
            this.u0.setState(getDrawableState());
        }
        Drawable drawable3 = this.f1169v0;
        if (drawable3 == null || !drawable3.isStateful()) {
            return;
        }
        this.f1169v0.setState(getDrawableState());
    }

    public View getTabContainer() {
        return null;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        Drawable drawable = this.f1168t0;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
        Drawable drawable2 = this.u0;
        if (drawable2 != null) {
            drawable2.jumpToCurrentState();
        }
        Drawable drawable3 = this.f1169v0;
        if (drawable3 != null) {
            drawable3.jumpToCurrentState();
        }
    }

    @Override // android.view.View
    public final void onFinishInflate() {
        super.onFinishInflate();
        this.f1166r0 = findViewById(R.id.action_bar);
        this.f1167s0 = findViewById(R.id.action_context_bar);
    }

    @Override // android.view.View
    public final boolean onHoverEvent(MotionEvent motionEvent) {
        super.onHoverEvent(motionEvent);
        return true;
    }

    @Override // android.view.ViewGroup
    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        return this.f1165e || super.onInterceptTouchEvent(motionEvent);
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z5, int i10, int i11, int i12, int i13) {
        super.onLayout(z5, i10, i11, i12, i13);
        boolean z6 = true;
        if (this.f1170w0) {
            Drawable drawable = this.f1169v0;
            if (drawable != null) {
                drawable.setBounds(0, 0, getMeasuredWidth(), getMeasuredHeight());
            } else {
                z6 = false;
            }
        } else {
            if (this.f1168t0 == null) {
                z6 = false;
            } else if (this.f1166r0.getVisibility() == 0) {
                this.f1168t0.setBounds(this.f1166r0.getLeft(), this.f1166r0.getTop(), this.f1166r0.getRight(), this.f1166r0.getBottom());
            } else {
                View view = this.f1167s0;
                if (view == null || view.getVisibility() != 0) {
                    this.f1168t0.setBounds(0, 0, 0, 0);
                } else {
                    this.f1168t0.setBounds(this.f1167s0.getLeft(), this.f1167s0.getTop(), this.f1167s0.getRight(), this.f1167s0.getBottom());
                }
            }
            this.f1171x0 = false;
        }
        if (z6) {
            invalidate();
        }
    }

    @Override // android.widget.FrameLayout, android.view.View
    public final void onMeasure(int i10, int i11) {
        int i12;
        if (this.f1166r0 == null && View.MeasureSpec.getMode(i11) == Integer.MIN_VALUE && (i12 = this.f1172y0) >= 0) {
            i11 = View.MeasureSpec.makeMeasureSpec(Math.min(i12, View.MeasureSpec.getSize(i11)), Integer.MIN_VALUE);
        }
        super.onMeasure(i10, i11);
        if (this.f1166r0 == null) {
            return;
        }
        View.MeasureSpec.getMode(i11);
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        super.onTouchEvent(motionEvent);
        return true;
    }

    public void setPrimaryBackground(Drawable drawable) {
        Drawable drawable2 = this.f1168t0;
        if (drawable2 != null) {
            drawable2.setCallback(null);
            unscheduleDrawable(this.f1168t0);
        }
        this.f1168t0 = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
            View view = this.f1166r0;
            if (view != null) {
                this.f1168t0.setBounds(view.getLeft(), this.f1166r0.getTop(), this.f1166r0.getRight(), this.f1166r0.getBottom());
            }
        }
        boolean z5 = false;
        if (!this.f1170w0 ? !(this.f1168t0 != null || this.u0 != null) : this.f1169v0 == null) {
            z5 = true;
        }
        setWillNotDraw(z5);
        invalidate();
        invalidateOutline();
    }

    public void setSplitBackground(Drawable drawable) {
        Drawable drawable2;
        Drawable drawable3 = this.f1169v0;
        if (drawable3 != null) {
            drawable3.setCallback(null);
            unscheduleDrawable(this.f1169v0);
        }
        this.f1169v0 = drawable;
        boolean z5 = this.f1170w0;
        boolean z6 = false;
        if (drawable != null) {
            drawable.setCallback(this);
            if (z5 && (drawable2 = this.f1169v0) != null) {
                drawable2.setBounds(0, 0, getMeasuredWidth(), getMeasuredHeight());
            }
        }
        if (!z5 ? !(this.f1168t0 != null || this.u0 != null) : this.f1169v0 == null) {
            z6 = true;
        }
        setWillNotDraw(z6);
        invalidate();
        invalidateOutline();
    }

    public void setStackedBackground(Drawable drawable) {
        Drawable drawable2 = this.u0;
        if (drawable2 != null) {
            drawable2.setCallback(null);
            unscheduleDrawable(this.u0);
        }
        this.u0 = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
            if (this.f1171x0 && this.u0 != null) {
                throw null;
            }
        }
        boolean z5 = false;
        if (!this.f1170w0 ? !(this.f1168t0 != null || this.u0 != null) : this.f1169v0 == null) {
            z5 = true;
        }
        setWillNotDraw(z5);
        invalidate();
        invalidateOutline();
    }

    public void setTransitioning(boolean z5) {
        this.f1165e = z5;
        setDescendantFocusability(z5 ? 393216 : 262144);
    }

    @Override // android.view.View
    public void setVisibility(int i10) {
        super.setVisibility(i10);
        boolean z5 = i10 == 0;
        Drawable drawable = this.f1168t0;
        if (drawable != null) {
            drawable.setVisible(z5, false);
        }
        Drawable drawable2 = this.u0;
        if (drawable2 != null) {
            drawable2.setVisible(z5, false);
        }
        Drawable drawable3 = this.f1169v0;
        if (drawable3 != null) {
            drawable3.setVisible(z5, false);
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final ActionMode startActionModeForChild(View view, ActionMode.Callback callback) {
        return null;
    }

    @Override // android.view.View
    public final boolean verifyDrawable(Drawable drawable) {
        Drawable drawable2 = this.f1168t0;
        boolean z5 = this.f1170w0;
        if (drawable == drawable2 && !z5) {
            return true;
        }
        if (drawable == this.u0 && this.f1171x0) {
            return true;
        }
        return (drawable == this.f1169v0 && z5) || super.verifyDrawable(drawable);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final ActionMode startActionModeForChild(View view, ActionMode.Callback callback, int i10) {
        if (i10 != 0) {
            return super.startActionModeForChild(view, callback, i10);
        }
        return null;
    }

    public void setTabContainer(w2 w2Var) {
    }
}
