package androidx.appcompat.app;

import tm.belet.films.presentation.activities.ActivityLoginRegister;
import tm.belet.films.presentation.activities.BeletActivity;
import tm.belet.films.presentation.activities.DeleteDeviceActivity;
import tm.belet.films.presentation.activities.HomeActivity;
import tm.belet.films.presentation.activities.PlayerActivity;
import tm.belet.films.presentation.activities.RouterActivity;
import tm.belet.films.presentation.activities.SplashScreenActivity;
import tm.belet.films.presentation.activities.WebViewActivity;
import xn.c1;
import xn.s0;
import xn.t0;
import xn.w0;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class i implements d.a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1093a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ BeletActivity f1094b;

    public /* synthetic */ i(BeletActivity beletActivity, int i10) {
        this.f1093a = i10;
        this.f1094b = beletActivity;
    }

    @Override // d.a
    public final void a() {
        switch (this.f1093a) {
            case 0:
                BeletActivity beletActivity = this.f1094b;
                p pVarA = beletActivity.A();
                pVarA.a();
                ((m7.e) beletActivity.f3797r0.Y).k("androidx:appcompat");
                pVarA.c();
                break;
            case 1:
                ActivityLoginRegister activityLoginRegister = (ActivityLoginRegister) this.f1094b;
                if (!activityLoginRegister.P0) {
                    activityLoginRegister.P0 = true;
                    ((xn.a) activityLoginRegister.b()).getClass();
                }
                break;
            case 2:
                DeleteDeviceActivity deleteDeviceActivity = (DeleteDeviceActivity) this.f1094b;
                if (!deleteDeviceActivity.P0) {
                    deleteDeviceActivity.P0 = true;
                    ((xn.f) deleteDeviceActivity.b()).getClass();
                }
                break;
            case 3:
                HomeActivity homeActivity = (HomeActivity) this.f1094b;
                if (!homeActivity.P0) {
                    homeActivity.P0 = true;
                    ((xn.u) homeActivity.b()).getClass();
                }
                break;
            case 4:
                PlayerActivity playerActivity = (PlayerActivity) this.f1094b;
                if (!playerActivity.Q0) {
                    playerActivity.Q0 = true;
                    ((s0) playerActivity.b()).getClass();
                }
                break;
            case 5:
                RouterActivity routerActivity = (RouterActivity) this.f1094b;
                if (!routerActivity.P0) {
                    routerActivity.P0 = true;
                    ((t0) routerActivity.b()).getClass();
                }
                break;
            case 6:
                SplashScreenActivity splashScreenActivity = (SplashScreenActivity) this.f1094b;
                if (!splashScreenActivity.P0) {
                    splashScreenActivity.P0 = true;
                    ((w0) splashScreenActivity.b()).getClass();
                }
                break;
            default:
                WebViewActivity webViewActivity = (WebViewActivity) this.f1094b;
                if (!webViewActivity.Q0) {
                    webViewActivity.Q0 = true;
                    ((c1) webViewActivity.b()).getClass();
                }
                break;
        }
    }
}
