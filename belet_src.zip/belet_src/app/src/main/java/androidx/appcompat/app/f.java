package androidx.appcompat.app;

import android.R;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.view.ContextThemeWrapper;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.TextView;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public class f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final c f1086a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f1087b;

    public f(Context context) {
        this(context, g.e(context, 0));
    }

    public f a(String str) {
        this.f1086a.f = str;
        return this;
    }

    public f b(CharSequence charSequence, DialogInterface.OnClickListener onClickListener) {
        c cVar = this.f1086a;
        cVar.f1012i = charSequence;
        cVar.f1013j = onClickListener;
        return this;
    }

    public f c(CharSequence charSequence, DialogInterface.OnClickListener onClickListener) {
        c cVar = this.f1086a;
        cVar.f1011g = charSequence;
        cVar.h = onClickListener;
        return this;
    }

    public g create() {
        c cVar = this.f1086a;
        g gVar = new g(cVar.f1006a, this.f1087b);
        View view = cVar.f1010e;
        e eVar = gVar.f1089s0;
        if (view != null) {
            eVar.f1054w = view;
        } else {
            CharSequence charSequence = cVar.f1009d;
            if (charSequence != null) {
                eVar.f1037d = charSequence;
                TextView textView = eVar.f1052u;
                if (textView != null) {
                    textView.setText(charSequence);
                }
            }
            Drawable drawable = cVar.f1008c;
            if (drawable != null) {
                eVar.f1050s = drawable;
                ImageView imageView = eVar.f1051t;
                if (imageView != null) {
                    imageView.setVisibility(0);
                    eVar.f1051t.setImageDrawable(drawable);
                }
            }
        }
        CharSequence charSequence2 = cVar.f;
        if (charSequence2 != null) {
            eVar.f1038e = charSequence2;
            TextView textView2 = eVar.f1053v;
            if (textView2 != null) {
                textView2.setText(charSequence2);
            }
        }
        CharSequence charSequence3 = cVar.f1011g;
        if (charSequence3 != null) {
            eVar.c(-1, charSequence3, cVar.h);
        }
        CharSequence charSequence4 = cVar.f1012i;
        if (charSequence4 != null) {
            eVar.c(-2, charSequence4, cVar.f1013j);
        }
        if (cVar.f1015l != null) {
            AlertController$RecycleListView alertController$RecycleListView = (AlertController$RecycleListView) cVar.f1007b.inflate(eVar.A, (ViewGroup) null);
            int i10 = cVar.f1018o ? eVar.B : eVar.C;
            ListAdapter dVar = cVar.f1015l;
            if (dVar == null) {
                dVar = new d(cVar.f1006a, i10, R.id.text1, null);
            }
            eVar.f1055x = dVar;
            eVar.f1056y = cVar.f1019p;
            if (cVar.f1016m != null) {
                alertController$RecycleListView.setOnItemClickListener(new b(cVar, eVar));
            }
            if (cVar.f1018o) {
                alertController$RecycleListView.setChoiceMode(1);
            }
            eVar.f = alertController$RecycleListView;
        }
        View view2 = cVar.f1017n;
        if (view2 != null) {
            eVar.f1039g = view2;
            eVar.h = false;
        }
        gVar.setCancelable(true);
        gVar.setCanceledOnTouchOutside(true);
        gVar.setOnCancelListener(null);
        gVar.setOnDismissListener(null);
        m.k kVar = cVar.f1014k;
        if (kVar != null) {
            gVar.setOnKeyListener(kVar);
        }
        return gVar;
    }

    public final g d() {
        g gVarCreate = create();
        gVarCreate.show();
        return gVarCreate;
    }

    public Context getContext() {
        return this.f1086a.f1006a;
    }

    public f setNegativeButton(int i10, DialogInterface.OnClickListener onClickListener) {
        c cVar = this.f1086a;
        cVar.f1012i = cVar.f1006a.getText(i10);
        cVar.f1013j = onClickListener;
        return this;
    }

    public f setPositiveButton(int i10, DialogInterface.OnClickListener onClickListener) {
        c cVar = this.f1086a;
        cVar.f1011g = cVar.f1006a.getText(i10);
        cVar.h = onClickListener;
        return this;
    }

    public f setTitle(CharSequence charSequence) {
        this.f1086a.f1009d = charSequence;
        return this;
    }

    public f setView(View view) {
        this.f1086a.f1017n = view;
        return this;
    }

    public f(Context context, int i10) {
        this.f1086a = new c(new ContextThemeWrapper(context, g.e(context, i10)));
        this.f1087b = i10;
    }
}
