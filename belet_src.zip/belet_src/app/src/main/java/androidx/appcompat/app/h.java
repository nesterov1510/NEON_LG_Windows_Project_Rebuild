package androidx.appcompat.app;

import android.os.Bundle;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import tm.belet.films.presentation.activities.BeletActivity;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class h implements m6.c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1091a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Object f1092b;

    public h(m7.e eVar) {
        this.f1091a = 1;
        this.f1092b = new LinkedHashSet();
        eVar.B("androidx.savedstate.Restarter", this);
    }

    @Override // m6.c
    public final Bundle a() {
        switch (this.f1091a) {
            case 0:
                Bundle bundle = new Bundle();
                ((BeletActivity) this.f1092b).A().getClass();
                return bundle;
            default:
                Bundle bundleI = ji.k.i((qi.i[]) Arrays.copyOf(new qi.i[0], 0));
                List listZ0 = ri.m.z0((LinkedHashSet) this.f1092b);
                bundleI.putStringArrayList("classes_to_restore", listZ0 instanceof ArrayList ? (ArrayList) listZ0 : new ArrayList<>(listZ0));
                return bundleI;
        }
    }

    public h(BeletActivity beletActivity) {
        this.f1091a = 0;
        this.f1092b = beletActivity;
    }
}
