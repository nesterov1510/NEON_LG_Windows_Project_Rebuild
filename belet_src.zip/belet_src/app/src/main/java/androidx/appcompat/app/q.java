package androidx.appcompat.app;

import android.view.ViewGroup;
import j2.w0;
import okio.internal.Buffer;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class q implements Runnable {
    public final /* synthetic */ e0 X;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f1120e;

    public /* synthetic */ q(e0 e0Var, int i10) {
        this.f1120e = i10;
        this.X = e0Var;
    }

    @Override // java.lang.Runnable
    public final void run() {
        ViewGroup viewGroup;
        switch (this.f1120e) {
            case 0:
                e0 e0Var = this.X;
                if ((e0Var.f1074n1 & 1) != 0) {
                    e0Var.u(0);
                }
                if ((e0Var.f1074n1 & Buffer.SEGMENTING_THRESHOLD) != 0) {
                    e0Var.u(108);
                }
                e0Var.f1073m1 = false;
                e0Var.f1074n1 = 0;
                break;
            default:
                e0 e0Var2 = this.X;
                e0Var2.J0.showAtLocation(e0Var2.I0, 55, 0, 0);
                w0 w0Var = e0Var2.L0;
                if (w0Var != null) {
                    w0Var.b();
                }
                if (e0Var2.N0 && (viewGroup = e0Var2.O0) != null && viewGroup.isLaidOut()) {
                    e0Var2.I0.setAlpha(0.0f);
                    w0 w0VarA = j2.q0.a(e0Var2.I0);
                    w0VarA.a(1.0f);
                    e0Var2.L0 = w0VarA;
                    w0VarA.d(new s(0, this));
                } else {
                    e0Var2.I0.setAlpha(1.0f);
                    e0Var2.I0.setVisibility(0);
                }
                break;
        }
    }
}
