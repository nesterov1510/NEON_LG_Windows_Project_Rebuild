package androidx.appcompat.app;

import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ListAdapter;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ContextThemeWrapper f1006a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final LayoutInflater f1007b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Drawable f1008c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public CharSequence f1009d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public View f1010e;
    public CharSequence f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public CharSequence f1011g;
    public DialogInterface.OnClickListener h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public CharSequence f1012i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public DialogInterface.OnClickListener f1013j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public m.k f1014k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public ListAdapter f1015l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public DialogInterface.OnClickListener f1016m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public View f1017n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public boolean f1018o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f1019p = -1;

    public c(ContextThemeWrapper contextThemeWrapper) {
        this.f1006a = contextThemeWrapper;
        this.f1007b = (LayoutInflater) contextThemeWrapper.getSystemService("layout_inflater");
    }
}
