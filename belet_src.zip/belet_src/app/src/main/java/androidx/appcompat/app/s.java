package androidx.appcompat.app;

import android.view.View;
import android.view.ViewGroup;
import android.widget.PopupWindow;
import java.util.WeakHashMap;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class s extends ta.f {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ int f1141c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Object f1142d;

    public /* synthetic */ s(int i10, Object obj) {
        this.f1141c = i10;
        this.f1142d = obj;
    }

    @Override // ta.f, j2.x0
    public void b() {
        int i10 = this.f1141c;
        Object obj = this.f1142d;
        switch (i10) {
            case 0:
                ((q) obj).X.I0.setVisibility(0);
                break;
            case 1:
                e0 e0Var = (e0) obj;
                e0Var.I0.setVisibility(0);
                if (e0Var.I0.getParent() instanceof View) {
                    View view = (View) e0Var.I0.getParent();
                    WeakHashMap weakHashMap = j2.q0.f12703a;
                    view.requestApplyInsets();
                }
                break;
        }
    }

    @Override // j2.x0
    public final void c() {
        int i10 = this.f1141c;
        Object obj = this.f1142d;
        switch (i10) {
            case 0:
                e0 e0Var = ((q) obj).X;
                e0Var.I0.setAlpha(1.0f);
                e0Var.L0.d(null);
                e0Var.L0 = null;
                break;
            case 1:
                e0 e0Var2 = (e0) obj;
                e0Var2.I0.setAlpha(1.0f);
                e0Var2.L0.d(null);
                e0Var2.L0 = null;
                break;
            default:
                e0 e0Var3 = (e0) ((m7.c) obj).Y;
                e0Var3.I0.setVisibility(8);
                PopupWindow popupWindow = e0Var3.J0;
                if (popupWindow != null) {
                    popupWindow.dismiss();
                } else if (e0Var3.I0.getParent() instanceof View) {
                    View view = (View) e0Var3.I0.getParent();
                    WeakHashMap weakHashMap = j2.q0.f12703a;
                    view.requestApplyInsets();
                }
                e0Var3.I0.e();
                e0Var3.L0.d(null);
                e0Var3.L0 = null;
                ViewGroup viewGroup = e0Var3.O0;
                WeakHashMap weakHashMap2 = j2.q0.f12703a;
                viewGroup.requestApplyInsets();
                break;
        }
    }
}
