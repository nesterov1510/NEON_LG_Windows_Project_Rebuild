package androidx.appcompat.app;

import android.content.Context;
import android.content.IntentFilter;
import android.location.Location;
import android.location.LocationManager;
import android.os.PowerManager;
import android.util.Log;
import java.util.Calendar;
import okhttp3.internal.ws.RealWebSocket;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class y extends a0 {
    public final /* synthetic */ int Z = 0;

    /* JADX INFO: renamed from: r0, reason: collision with root package name */
    public final /* synthetic */ e0 f1147r0;

    /* JADX INFO: renamed from: s0, reason: collision with root package name */
    public final Object f1148s0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public y(e0 e0Var, m7.m mVar) {
        super(e0Var);
        this.f1147r0 = e0Var;
        this.f1148s0 = mVar;
    }

    @Override // androidx.appcompat.app.a0
    public final IntentFilter b1() {
        switch (this.Z) {
            case 0:
                IntentFilter intentFilter = new IntentFilter();
                intentFilter.addAction("android.os.action.POWER_SAVE_MODE_CHANGED");
                return intentFilter;
            default:
                IntentFilter intentFilter2 = new IntentFilter();
                intentFilter2.addAction("android.intent.action.TIME_SET");
                intentFilter2.addAction("android.intent.action.TIMEZONE_CHANGED");
                intentFilter2.addAction("android.intent.action.TIME_TICK");
                return intentFilter2;
        }
    }

    @Override // androidx.appcompat.app.a0
    public final int d1() {
        Location location;
        boolean z5;
        long j10;
        Location lastKnownLocation;
        switch (this.Z) {
            case 0:
                return t.a((PowerManager) this.f1148s0) ? 2 : 1;
            default:
                m7.m mVar = (m7.m) this.f1148s0;
                n0 n0Var = (n0) mVar.Z;
                LocationManager locationManager = (LocationManager) mVar.Y;
                if (n0Var.f1109b <= System.currentTimeMillis()) {
                    Context context = (Context) mVar.X;
                    Location lastKnownLocation2 = null;
                    if (m7.f.e(context, "android.permission.ACCESS_COARSE_LOCATION") == 0) {
                        try {
                            lastKnownLocation = locationManager.isProviderEnabled("network") ? locationManager.getLastKnownLocation("network") : null;
                        } catch (Exception e3) {
                            Log.d("TwilightManager", "Failed to get last known location", e3);
                        }
                        location = lastKnownLocation;
                    } else {
                        location = null;
                    }
                    if (m7.f.e(context, "android.permission.ACCESS_FINE_LOCATION") == 0) {
                        try {
                            if (locationManager.isProviderEnabled("gps")) {
                                lastKnownLocation2 = locationManager.getLastKnownLocation("gps");
                            }
                        } catch (Exception e10) {
                            Log.d("TwilightManager", "Failed to get last known location", e10);
                        }
                    }
                    if (lastKnownLocation2 == null || location == null ? lastKnownLocation2 != null : lastKnownLocation2.getTime() > location.getTime()) {
                        location = lastKnownLocation2;
                    }
                    z5 = false;
                    if (location != null) {
                        long jCurrentTimeMillis = System.currentTimeMillis();
                        if (m0.f1104d == null) {
                            m0.f1104d = new m0();
                        }
                        m0 m0Var = m0.f1104d;
                        m0Var.a(location.getLatitude(), location.getLongitude(), jCurrentTimeMillis - 86400000);
                        m0Var.a(location.getLatitude(), location.getLongitude(), jCurrentTimeMillis);
                        z5 = m0Var.f1107c == 1;
                        long j11 = m0Var.f1106b;
                        long j12 = m0Var.f1105a;
                        m0Var.a(location.getLatitude(), location.getLongitude(), jCurrentTimeMillis + 86400000);
                        long j13 = m0Var.f1106b;
                        if (j11 == -1 || j12 == -1) {
                            j10 = jCurrentTimeMillis + 43200000;
                        } else {
                            if (jCurrentTimeMillis > j12) {
                                j11 = j13;
                            } else if (jCurrentTimeMillis > j11) {
                                j11 = j12;
                            }
                            j10 = j11 + RealWebSocket.CANCEL_AFTER_CLOSE_MILLIS;
                        }
                        n0Var.f1108a = z5;
                        n0Var.f1109b = j10;
                    } else {
                        Log.i("TwilightManager", "Could not get last known location. This is probably because the app does not have any location permissions. Falling back to hardcoded sunrise/sunset values.");
                        int i10 = Calendar.getInstance().get(11);
                        if (i10 < 6 || i10 >= 22) {
                            z5 = true;
                        }
                    }
                    break;
                } else {
                    z5 = n0Var.f1108a;
                }
                return z5 ? 2 : 1;
        }
    }

    @Override // androidx.appcompat.app.a0
    public final void q1() throws IllegalAccessException {
        switch (this.Z) {
            case 0:
                this.f1147r0.m(true, true);
                break;
            default:
                this.f1147r0.m(true, true);
                break;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public y(e0 e0Var, Context context) {
        super(e0Var);
        this.f1147r0 = e0Var;
        this.f1148s0 = (PowerManager) context.getApplicationContext().getSystemService("power");
    }
}
