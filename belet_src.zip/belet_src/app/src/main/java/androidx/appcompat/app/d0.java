package androidx.appcompat.app;

import android.os.Bundle;
import android.view.View;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class d0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f1020a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f1021b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f1022c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f1023d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public b0 f1024e;
    public View f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public View f1025g;
    public m.j h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public m.f f1026i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public l.c f1027j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public boolean f1028k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public boolean f1029l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public boolean f1030m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public boolean f1031n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public boolean f1032o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public Bundle f1033p;
}
