package androidx.appcompat.app;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
@SuppressLint({"BanParcelableUsage"})
class AppCompatDelegateImpl$PanelFeatureState$SavedState implements Parcelable {
    public static final Parcelable.Creator<AppCompatDelegateImpl$PanelFeatureState$SavedState> CREATOR = new c0();
    public boolean X;
    public Bundle Y;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f1001e;

    public static AppCompatDelegateImpl$PanelFeatureState$SavedState b(Parcel parcel, ClassLoader classLoader) {
        AppCompatDelegateImpl$PanelFeatureState$SavedState appCompatDelegateImpl$PanelFeatureState$SavedState = new AppCompatDelegateImpl$PanelFeatureState$SavedState();
        appCompatDelegateImpl$PanelFeatureState$SavedState.f1001e = parcel.readInt();
        boolean z5 = parcel.readInt() == 1;
        appCompatDelegateImpl$PanelFeatureState$SavedState.X = z5;
        if (z5) {
            appCompatDelegateImpl$PanelFeatureState$SavedState.Y = parcel.readBundle(classLoader);
        }
        return appCompatDelegateImpl$PanelFeatureState$SavedState;
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i10) {
        parcel.writeInt(this.f1001e);
        parcel.writeInt(this.X ? 1 : 0);
        if (this.X) {
            parcel.writeBundle(this.Y);
        }
    }
}
