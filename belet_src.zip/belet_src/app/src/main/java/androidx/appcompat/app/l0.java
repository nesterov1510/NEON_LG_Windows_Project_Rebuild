package androidx.appcompat.app;

import android.app.Service;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public abstract class l0 extends Service {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final /* synthetic */ int f1103e = 0;
}
