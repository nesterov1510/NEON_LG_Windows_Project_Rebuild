package androidx.appcompat.app;

import android.content.Context;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import androidx.appcompat.widget.ActionBarContextView;
import java.lang.ref.WeakReference;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class p0 extends l.a implements m.h {
    public final Context Y;
    public final m.j Z;

    /* JADX INFO: renamed from: r0, reason: collision with root package name */
    public m7.c f1117r0;

    /* JADX INFO: renamed from: s0, reason: collision with root package name */
    public WeakReference f1118s0;

    /* JADX INFO: renamed from: t0, reason: collision with root package name */
    public final /* synthetic */ q0 f1119t0;

    public p0(q0 q0Var, Context context, m7.c cVar) {
        this.f1119t0 = q0Var;
        this.Y = context;
        this.f1117r0 = cVar;
        m.j jVar = new m.j(context);
        jVar.f14726y0 = 1;
        this.Z = jVar;
        jVar.f14720r0 = this;
    }

    @Override // l.a
    public final void a() {
        q0 q0Var = this.f1119t0;
        if (q0Var.f1127n != this) {
            return;
        }
        if (q0Var.f1134u) {
            q0Var.f1128o = this;
            q0Var.f1129p = this.f1117r0;
        } else {
            this.f1117r0.A(this);
        }
        this.f1117r0 = null;
        q0Var.A(false);
        ActionBarContextView actionBarContextView = q0Var.f1124k;
        if (actionBarContextView.A0 == null) {
            actionBarContextView.e();
        }
        q0Var.h.setHideOnContentScrollEnabled(q0Var.f1139z);
        q0Var.f1127n = null;
    }

    @Override // l.a
    public final View b() {
        WeakReference weakReference = this.f1118s0;
        if (weakReference != null) {
            return (View) weakReference.get();
        }
        return null;
    }

    @Override // l.a
    public final m.j c() {
        return this.Z;
    }

    @Override // l.a
    public final MenuInflater d() {
        return new l.h(this.Y);
    }

    @Override // l.a
    public final CharSequence e() {
        return this.f1119t0.f1124k.getSubtitle();
    }

    @Override // l.a
    public final CharSequence f() {
        return this.f1119t0.f1124k.getTitle();
    }

    @Override // l.a
    public final void g() {
        if (this.f1119t0.f1127n != this) {
            return;
        }
        m.j jVar = this.Z;
        jVar.w();
        try {
            this.f1117r0.B(this, jVar);
        } finally {
            jVar.v();
        }
    }

    @Override // m.h
    public final void h(m.j jVar) {
        if (this.f1117r0 == null) {
            return;
        }
        g();
        androidx.appcompat.widget.n nVar = this.f1119t0.f1124k.f1176t0;
        if (nVar != null) {
            nVar.n();
        }
    }

    @Override // l.a
    public final boolean i() {
        return this.f1119t0.f1124k.I0;
    }

    @Override // m.h
    public final boolean j(m.j jVar, MenuItem menuItem) {
        m7.c cVar = this.f1117r0;
        if (cVar != null) {
            return ((m7.i) cVar.X).r(this, menuItem);
        }
        return false;
    }

    @Override // l.a
    public final void k(View view) {
        this.f1119t0.f1124k.setCustomView(view);
        this.f1118s0 = new WeakReference(view);
    }

    @Override // l.a
    public final void l(int i10) {
        m(this.f1119t0.f.getResources().getString(i10));
    }

    @Override // l.a
    public final void m(CharSequence charSequence) {
        this.f1119t0.f1124k.setSubtitle(charSequence);
    }

    @Override // l.a
    public final void n(int i10) {
        o(this.f1119t0.f.getResources().getString(i10));
    }

    @Override // l.a
    public final void o(CharSequence charSequence) {
        this.f1119t0.f1124k.setTitle(charSequence);
    }

    @Override // l.a
    public final void p(boolean z5) {
        this.X = z5;
        this.f1119t0.f1124k.setTitleOptional(z5);
    }
}
