package androidx.appcompat.app;

import android.R;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import androidx.appcompat.widget.ActionBarContainer;
import androidx.appcompat.widget.ActionBarContextView;
import androidx.appcompat.widget.ActionBarOverlayLayout;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.m3;
import androidx.appcompat.widget.n3;
import androidx.appcompat.widget.p1;
import go.d4;
import j2.w0;
import java.util.ArrayList;
import java.util.WeakHashMap;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class q0 extends q0.f implements androidx.appcompat.widget.e {
    public static final AccelerateInterpolator D = new AccelerateInterpolator();
    public static final DecelerateInterpolator E = new DecelerateInterpolator();
    public final o0 A;
    public final o0 B;
    public final z7.c C;
    public Context f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public Context f1121g;
    public ActionBarOverlayLayout h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public ActionBarContainer f1122i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public p1 f1123j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public ActionBarContextView f1124k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final View f1125l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public boolean f1126m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public p0 f1127n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public p0 f1128o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public m7.c f1129p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public boolean f1130q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final ArrayList f1131r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f1132s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public boolean f1133t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public boolean f1134u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public boolean f1135v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public boolean f1136w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public l.i f1137x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public boolean f1138y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public boolean f1139z;

    public q0(Activity activity, boolean z5) {
        new ArrayList();
        this.f1131r = new ArrayList();
        this.f1132s = 0;
        this.f1133t = true;
        this.f1136w = true;
        this.A = new o0(this, 0);
        this.B = new o0(this, 1);
        this.C = new z7.c(4, this);
        View decorView = activity.getWindow().getDecorView();
        C(decorView);
        if (z5) {
            return;
        }
        this.f1125l = decorView.findViewById(R.id.content);
    }

    public final void A(boolean z5) {
        w0 w0VarI;
        w0 w0VarI2;
        if (z5) {
            if (!this.f1135v) {
                this.f1135v = true;
                ActionBarOverlayLayout actionBarOverlayLayout = this.h;
                if (actionBarOverlayLayout != null) {
                    actionBarOverlayLayout.setShowingForActionMode(true);
                }
                F(false);
            }
        } else if (this.f1135v) {
            this.f1135v = false;
            ActionBarOverlayLayout actionBarOverlayLayout2 = this.h;
            if (actionBarOverlayLayout2 != null) {
                actionBarOverlayLayout2.setShowingForActionMode(false);
            }
            F(false);
        }
        if (!this.f1122i.isLaidOut()) {
            if (z5) {
                ((n3) this.f1123j).f1381a.setVisibility(4);
                this.f1124k.setVisibility(0);
                return;
            } else {
                ((n3) this.f1123j).f1381a.setVisibility(0);
                this.f1124k.setVisibility(8);
                return;
            }
        }
        if (z5) {
            n3 n3Var = (n3) this.f1123j;
            w0VarI = j2.q0.a(n3Var.f1381a);
            w0VarI.a(0.0f);
            w0VarI.c(100L);
            w0VarI.d(new m3(n3Var, 4));
            w0VarI2 = this.f1124k.i(0, 200L);
        } else {
            n3 n3Var2 = (n3) this.f1123j;
            w0 w0VarA = j2.q0.a(n3Var2.f1381a);
            w0VarA.a(1.0f);
            w0VarA.c(200L);
            w0VarA.d(new m3(n3Var2, 0));
            w0VarI = this.f1124k.i(8, 100L);
            w0VarI2 = w0VarA;
        }
        l.i iVar = new l.i();
        ArrayList arrayList = iVar.f14030a;
        arrayList.add(w0VarI);
        View view = (View) w0VarI.f12726a.get();
        long duration = view != null ? view.animate().getDuration() : 0L;
        View view2 = (View) w0VarI2.f12726a.get();
        if (view2 != null) {
            view2.animate().setStartDelay(duration);
        }
        arrayList.add(w0VarI2);
        iVar.b();
    }

    public final Context B() {
        if (this.f1121g == null) {
            TypedValue typedValue = new TypedValue();
            this.f.getTheme().resolveAttribute(tm.belet.films.R.attr.actionBarWidgetTheme, typedValue, true);
            int i10 = typedValue.resourceId;
            if (i10 != 0) {
                this.f1121g = new ContextThemeWrapper(this.f, i10);
            } else {
                this.f1121g = this.f;
            }
        }
        return this.f1121g;
    }

    public final void C(View view) {
        p1 wrapper;
        ActionBarOverlayLayout actionBarOverlayLayout = (ActionBarOverlayLayout) view.findViewById(tm.belet.films.R.id.decor_content_parent);
        this.h = actionBarOverlayLayout;
        if (actionBarOverlayLayout != null) {
            actionBarOverlayLayout.setActionBarVisibilityCallback(this);
        }
        KeyEvent.Callback callbackFindViewById = view.findViewById(tm.belet.films.R.id.action_bar);
        if (callbackFindViewById instanceof p1) {
            wrapper = (p1) callbackFindViewById;
        } else {
            if (!(callbackFindViewById instanceof Toolbar)) {
                throw new IllegalStateException("Can't make a decor toolbar out of ".concat(callbackFindViewById != null ? callbackFindViewById.getClass().getSimpleName() : kotlinx.serialization.json.internal.b.NULL));
            }
            wrapper = ((Toolbar) callbackFindViewById).getWrapper();
        }
        this.f1123j = wrapper;
        this.f1124k = (ActionBarContextView) view.findViewById(tm.belet.films.R.id.action_context_bar);
        ActionBarContainer actionBarContainer = (ActionBarContainer) view.findViewById(tm.belet.films.R.id.action_bar_container);
        this.f1122i = actionBarContainer;
        p1 p1Var = this.f1123j;
        if (p1Var == null || this.f1124k == null || actionBarContainer == null) {
            throw new IllegalStateException(q0.class.getSimpleName().concat(" can only be used with a compatible window decor layout"));
        }
        Context context = ((n3) p1Var).f1381a.getContext();
        this.f = context;
        if ((((n3) this.f1123j).f1382b & 4) != 0) {
            this.f1126m = true;
        }
        int i10 = context.getApplicationInfo().targetSdkVersion;
        this.f1123j.getClass();
        E(context.getResources().getBoolean(tm.belet.films.R.bool.abc_action_bar_embed_tabs));
        TypedArray typedArrayObtainStyledAttributes = this.f.obtainStyledAttributes(null, g.a.f8270a, tm.belet.films.R.attr.actionBarStyle, 0);
        if (typedArrayObtainStyledAttributes.getBoolean(14, false)) {
            ActionBarOverlayLayout actionBarOverlayLayout2 = this.h;
            if (!actionBarOverlayLayout2.f1187w0) {
                throw new IllegalStateException("Action bar must be in overlay mode (Window.FEATURE_OVERLAY_ACTION_BAR) to enable hide on content scroll");
            }
            this.f1139z = true;
            actionBarOverlayLayout2.setHideOnContentScrollEnabled(true);
        }
        int dimensionPixelSize = typedArrayObtainStyledAttributes.getDimensionPixelSize(12, 0);
        if (dimensionPixelSize != 0) {
            ActionBarContainer actionBarContainer2 = this.f1122i;
            WeakHashMap weakHashMap = j2.q0.f12703a;
            actionBarContainer2.setElevation(dimensionPixelSize);
        }
        typedArrayObtainStyledAttributes.recycle();
    }

    public final void D(boolean z5) {
        if (this.f1126m) {
            return;
        }
        int i10 = z5 ? 4 : 0;
        n3 n3Var = (n3) this.f1123j;
        int i11 = n3Var.f1382b;
        this.f1126m = true;
        n3Var.a((i10 & 4) | (i11 & (-5)));
    }

    public final void E(boolean z5) {
        if (z5) {
            this.f1122i.setTabContainer(null);
            ((n3) this.f1123j).getClass();
        } else {
            ((n3) this.f1123j).getClass();
            this.f1122i.setTabContainer(null);
        }
        ((n3) this.f1123j).getClass();
        ((n3) this.f1123j).f1381a.setCollapsible(false);
        this.h.setHasNonEmbeddedTabs(false);
    }

    public final void F(boolean z5) {
        boolean z6 = this.f1134u;
        boolean z9 = this.f1135v;
        z7.c cVar = this.C;
        View view = this.f1125l;
        if (!z9 && z6) {
            if (this.f1136w) {
                this.f1136w = false;
                l.i iVar = this.f1137x;
                if (iVar != null) {
                    iVar.a();
                }
                int i10 = this.f1132s;
                o0 o0Var = this.A;
                if (i10 != 0 || (!this.f1138y && !z5)) {
                    o0Var.c();
                    return;
                }
                this.f1122i.setAlpha(1.0f);
                this.f1122i.setTransitioning(true);
                l.i iVar2 = new l.i();
                float f = -this.f1122i.getHeight();
                if (z5) {
                    int[] iArr = {0, 0};
                    this.f1122i.getLocationInWindow(iArr);
                    f -= iArr[1];
                }
                w0 w0VarA = j2.q0.a(this.f1122i);
                w0VarA.e(f);
                View view2 = (View) w0VarA.f12726a.get();
                if (view2 != null) {
                    view2.animate().setUpdateListener(cVar != null ? new d4(cVar, view2) : null);
                }
                boolean z10 = iVar2.f14034e;
                ArrayList arrayList = iVar2.f14030a;
                if (!z10) {
                    arrayList.add(w0VarA);
                }
                if (this.f1133t && view != null) {
                    w0 w0VarA2 = j2.q0.a(view);
                    w0VarA2.e(f);
                    if (!iVar2.f14034e) {
                        arrayList.add(w0VarA2);
                    }
                }
                boolean z11 = iVar2.f14034e;
                if (!z11) {
                    iVar2.f14032c = D;
                }
                if (!z11) {
                    iVar2.f14031b = 250L;
                }
                if (!z11) {
                    iVar2.f14033d = o0Var;
                }
                this.f1137x = iVar2;
                iVar2.b();
                return;
            }
            return;
        }
        if (this.f1136w) {
            return;
        }
        this.f1136w = true;
        l.i iVar3 = this.f1137x;
        if (iVar3 != null) {
            iVar3.a();
        }
        this.f1122i.setVisibility(0);
        int i11 = this.f1132s;
        o0 o0Var2 = this.B;
        if (i11 == 0 && (this.f1138y || z5)) {
            this.f1122i.setTranslationY(0.0f);
            float f10 = -this.f1122i.getHeight();
            if (z5) {
                int[] iArr2 = {0, 0};
                this.f1122i.getLocationInWindow(iArr2);
                f10 -= iArr2[1];
            }
            this.f1122i.setTranslationY(f10);
            l.i iVar4 = new l.i();
            w0 w0VarA3 = j2.q0.a(this.f1122i);
            w0VarA3.e(0.0f);
            View view3 = (View) w0VarA3.f12726a.get();
            if (view3 != null) {
                view3.animate().setUpdateListener(cVar != null ? new d4(cVar, view3) : null);
            }
            boolean z12 = iVar4.f14034e;
            ArrayList arrayList2 = iVar4.f14030a;
            if (!z12) {
                arrayList2.add(w0VarA3);
            }
            if (this.f1133t && view != null) {
                view.setTranslationY(f10);
                w0 w0VarA4 = j2.q0.a(view);
                w0VarA4.e(0.0f);
                if (!iVar4.f14034e) {
                    arrayList2.add(w0VarA4);
                }
            }
            boolean z13 = iVar4.f14034e;
            if (!z13) {
                iVar4.f14032c = E;
            }
            if (!z13) {
                iVar4.f14031b = 250L;
            }
            if (!z13) {
                iVar4.f14033d = o0Var2;
            }
            this.f1137x = iVar4;
            iVar4.b();
        } else {
            this.f1122i.setAlpha(1.0f);
            this.f1122i.setTranslationY(0.0f);
            if (this.f1133t && view != null) {
                view.setTranslationY(0.0f);
            }
            o0Var2.c();
        }
        ActionBarOverlayLayout actionBarOverlayLayout = this.h;
        if (actionBarOverlayLayout != null) {
            WeakHashMap weakHashMap = j2.q0.f12703a;
            actionBarOverlayLayout.requestApplyInsets();
        }
    }

    public q0(Dialog dialog) {
        new ArrayList();
        this.f1131r = new ArrayList();
        this.f1132s = 0;
        this.f1133t = true;
        this.f1136w = true;
        this.A = new o0(this, 0);
        this.B = new o0(this, 1);
        this.C = new z7.c(4, this);
        C(dialog.getWindow().getDecorView());
    }
}
