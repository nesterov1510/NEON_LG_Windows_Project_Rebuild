package androidx.appcompat.app;

import android.app.Dialog;
import android.os.Bundle;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public class h0 extends androidx.fragment.app.t {
    @Override // androidx.fragment.app.t
    public Dialog j0(Bundle bundle) {
        return new g0(o(), i0());
    }

    @Override // androidx.fragment.app.t
    public final void m0(Dialog dialog, int i10) {
        if (!(dialog instanceof g0)) {
            super.m0(dialog, i10);
            return;
        }
        g0 g0Var = (g0) dialog;
        if (i10 != 1 && i10 != 2) {
            if (i10 != 3) {
                return;
            } else {
                dialog.getWindow().addFlags(24);
            }
        }
        g0Var.c().f(1);
    }
}
