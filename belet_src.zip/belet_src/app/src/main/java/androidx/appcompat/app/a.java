package androidx.appcompat.app;

import android.content.res.TypedArray;
import android.os.Message;
import android.view.View;
import android.widget.CheckedTextView;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.h3;
import androidx.media3.ui.TrackSelectionView;
import i3.b2;
import i3.c2;
import i3.h2;
import java.util.ArrayList;
import java.util.HashMap;
import lc.u0;
import tm.belet.films.R;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class a implements View.OnClickListener {
    public final /* synthetic */ Object X;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f1002e;

    public /* synthetic */ a(int i10, Object obj) {
        this.f1002e = i10;
        this.X = obj;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        Message messageObtain;
        Message message;
        Message message2;
        Message message3;
        switch (this.f1002e) {
            case 0:
                e eVar = (e) this.X;
                if (view == eVar.f1040i && (message3 = eVar.f1042k) != null) {
                    messageObtain = Message.obtain(message3);
                } else if (view != eVar.f1043l || (message2 = eVar.f1045n) == null) {
                    messageObtain = (view != eVar.f1046o || (message = eVar.f1048q) == null) ? null : Message.obtain(message);
                } else {
                    messageObtain = Message.obtain(message2);
                }
                if (messageObtain != null) {
                    messageObtain.sendToTarget();
                }
                eVar.E.obtainMessage(1, eVar.f1035b).sendToTarget();
                break;
            case 1:
                ((l.a) this.X).a();
                break;
            case 2:
                h3 h3Var = ((Toolbar) this.X).f1233b1;
                m.l lVar = h3Var == null ? null : h3Var.X;
                if (lVar != null) {
                    lVar.collapseActionView();
                }
                break;
            case 3:
                com.google.android.material.datepicker.r rVar = (com.google.android.material.datepicker.r) this.X;
                int i10 = rVar.f5910r1;
                if (i10 == 2) {
                    rVar.j0(1);
                    rVar.f5913u1.announceForAccessibility(rVar.x(R.string.mtrl_picker_toggled_to_day_selection));
                } else if (i10 == 1) {
                    rVar.j0(2);
                    rVar.f5912t1.announceForAccessibility(rVar.x(R.string.mtrl_picker_toggled_to_year_selection));
                }
                break;
            case 4:
                m.l itemData = ((com.google.android.material.navigation.g) view).getItemData();
                mb.b bVar = (mb.b) this.X;
                boolean zQ = bVar.f6074c1.f6065a.q(itemData, bVar.f6073b1, 0);
                if (itemData != null && itemData.isCheckable()) {
                    if (!zQ || itemData.isChecked()) {
                        bVar.setCheckedItem(itemData);
                    }
                    break;
                }
                break;
            case 5:
                nb.c cVar = (nb.c) this.X;
                if (cVar.f15870w0 && cVar.isShowing()) {
                    if (!cVar.f15872y0) {
                        TypedArray typedArrayObtainStyledAttributes = cVar.getContext().obtainStyledAttributes(new int[]{android.R.attr.windowCloseOnTouchOutside});
                        cVar.f15871x0 = typedArrayObtainStyledAttributes.getBoolean(0, true);
                        typedArrayObtainStyledAttributes.recycle();
                        cVar.f15872y0 = true;
                    }
                    if (cVar.f15871x0) {
                        cVar.cancel();
                    }
                    break;
                }
                break;
            default:
                TrackSelectionView trackSelectionView = (TrackSelectionView) this.X;
                HashMap map = trackSelectionView.f2825w0;
                boolean z5 = true;
                if (view == trackSelectionView.f2822s0) {
                    trackSelectionView.B0 = true;
                    map.clear();
                } else if (view == trackSelectionView.f2823t0) {
                    trackSelectionView.B0 = false;
                    map.clear();
                } else {
                    trackSelectionView.B0 = false;
                    Object tag = view.getTag();
                    tag.getClass();
                    x5.b bVar2 = (x5.b) tag;
                    h2 h2Var = bVar2.f21967a;
                    b2 b2Var = h2Var.f10812b;
                    int i11 = bVar2.f21968b;
                    c2 c2Var = (c2) map.get(b2Var);
                    if (c2Var == null) {
                        if (!trackSelectionView.f2827y0 && !map.isEmpty()) {
                            map.clear();
                        }
                        map.put(b2Var, new c2(b2Var, u0.q(Integer.valueOf(i11))));
                    } else {
                        ArrayList arrayList = new ArrayList(c2Var.f10660b);
                        boolean zIsChecked = ((CheckedTextView) view).isChecked();
                        boolean z6 = trackSelectionView.f2826x0 && h2Var.f10813c;
                        if (!z6 && (!trackSelectionView.f2827y0 || trackSelectionView.f2824v0.size() <= 1)) {
                            z5 = false;
                        }
                        if (zIsChecked && z5) {
                            arrayList.remove(Integer.valueOf(i11));
                            if (arrayList.isEmpty()) {
                                map.remove(b2Var);
                            } else {
                                map.put(b2Var, new c2(b2Var, arrayList));
                            }
                        } else if (!zIsChecked) {
                            if (z6) {
                                arrayList.add(Integer.valueOf(i11));
                                map.put(b2Var, new c2(b2Var, arrayList));
                            } else {
                                map.put(b2Var, new c2(b2Var, u0.q(Integer.valueOf(i11))));
                            }
                        }
                    }
                }
                trackSelectionView.a();
                break;
        }
    }
}
