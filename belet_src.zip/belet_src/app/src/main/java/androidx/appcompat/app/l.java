package androidx.appcompat.app;

import android.content.ComponentName;
import android.content.Context;
import android.os.Build;
import java.lang.ref.WeakReference;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class l implements Runnable {
    public final /* synthetic */ Context X;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f1102e;

    public /* synthetic */ l(Context context, int i10) {
        this.f1102e = i10;
        this.X = context;
    }

    /* JADX WARN: Code duplicated, block: B:28:0x008e  */
    @Override // java.lang.Runnable
    public final void run() {
        e2.e eVar;
        Object systemService;
        Context context;
        switch (this.f1102e) {
            case 0:
                int i10 = Build.VERSION.SDK_INT;
                if (i10 >= 33) {
                    Context context2 = this.X;
                    ComponentName componentName = new ComponentName(context2, "androidx.appcompat.app.AppLocalesMetadataHolderService");
                    if (context2.getPackageManager().getComponentEnabledSetting(componentName) != 1) {
                        if (i10 >= 33) {
                            j1.f fVar = p.f1115t0;
                            fVar.getClass();
                            j1.a aVar = new j1.a(fVar);
                            while (true) {
                                if (aVar.hasNext()) {
                                    p pVar = (p) ((WeakReference) aVar.next()).get();
                                    if (pVar != null && (context = ((e0) pVar).f1083x0) != null) {
                                        systemService = context.getSystemService("locale");
                                    }
                                } else {
                                    systemService = null;
                                }
                            }
                            if (systemService != null) {
                                eVar = new e2.e(new e2.h(n.a(systemService)));
                            } else {
                                eVar = e2.e.f7309b;
                            }
                        } else {
                            eVar = p.Y;
                            if (eVar == null) {
                                eVar = e2.e.f7309b;
                            }
                        }
                        if (eVar.f7310a.isEmpty()) {
                            String strE = v1.c.e(context2);
                            Object systemService2 = context2.getSystemService("locale");
                            if (systemService2 != null) {
                                n.b(systemService2, m.a(strE));
                            }
                        }
                        context2.getPackageManager().setComponentEnabledSetting(componentName, 1, 1);
                    }
                }
                p.f1114s0 = true;
                break;
            case 1:
                new ThreadPoolExecutor(0, 1, 0L, TimeUnit.MILLISECONDS, new LinkedBlockingQueue()).execute(new l(this.X, 2));
                break;
            default:
                e6.e.t(this.X, new d6.c(0), e6.e.f7581a, false);
                break;
        }
    }
}
