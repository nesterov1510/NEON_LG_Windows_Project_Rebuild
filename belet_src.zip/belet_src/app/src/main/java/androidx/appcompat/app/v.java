package androidx.appcompat.app;

import android.window.OnBackInvokedCallback;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class v implements OnBackInvokedCallback {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1143a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f1144b;

    public /* synthetic */ v(int i10, Object obj) {
        this.f1143a = i10;
        this.f1144b = obj;
    }

    public final void onBackInvoked() {
        switch (this.f1143a) {
            case 0:
                ((e0) this.f1144b).D();
                break;
            case 1:
                ((Runnable) this.f1144b).run();
                break;
            case 2:
                ej.a onBackInvoked = (ej.a) this.f1144b;
                kotlin.jvm.internal.q.g(onBackInvoked, "$onBackInvoked");
                onBackInvoked.invoke();
                break;
            default:
                ((xb.b) this.f1144b).b();
                break;
        }
    }
}
