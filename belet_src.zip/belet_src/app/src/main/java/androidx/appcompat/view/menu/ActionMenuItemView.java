package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.widget.g1;
import androidx.appcompat.widget.k;
import androidx.appcompat.widget.o;
import g.a;
import m.b;
import m.i;
import m.j;
import m.l;
import m.w;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public class ActionMenuItemView extends g1 implements w, View.OnClickListener, o {
    public i A0;
    public k B0;
    public b C0;
    public boolean D0;
    public boolean E0;
    public final int F0;
    public int G0;
    public final int H0;

    /* JADX INFO: renamed from: x0, reason: collision with root package name */
    public l f1151x0;

    /* JADX INFO: renamed from: y0, reason: collision with root package name */
    public CharSequence f1152y0;

    /* JADX INFO: renamed from: z0, reason: collision with root package name */
    public Drawable f1153z0;

    public ActionMenuItemView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        Resources resources = context.getResources();
        this.D0 = g();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, a.f8272c, 0, 0);
        this.F0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(0, 0);
        typedArrayObtainStyledAttributes.recycle();
        this.H0 = (int) ((resources.getDisplayMetrics().density * 32.0f) + 0.5f);
        setOnClickListener(this);
        this.G0 = -1;
        setSaveEnabled(false);
    }

    @Override // m.w
    public final void a(l lVar) {
        this.f1151x0 = lVar;
        setIcon(lVar.getIcon());
        setTitle(lVar.getTitleCondensed());
        setId(lVar.f14729e);
        setVisibility(lVar.isVisible() ? 0 : 8);
        setEnabled(lVar.isEnabled());
        if (lVar.hasSubMenu() && this.B0 == null) {
            this.B0 = new k(this);
        }
    }

    @Override // androidx.appcompat.widget.o
    public final boolean b() {
        return !TextUtils.isEmpty(getText());
    }

    @Override // androidx.appcompat.widget.o
    public final boolean c() {
        return !TextUtils.isEmpty(getText()) && this.f1151x0.getIcon() == null;
    }

    public final boolean g() {
        Configuration configuration = getContext().getResources().getConfiguration();
        int i10 = configuration.screenWidthDp;
        int i11 = configuration.screenHeightDp;
        if (i10 < 480) {
            return (i10 >= 640 && i11 >= 480) || configuration.orientation == 2;
        }
        return true;
    }

    @Override // android.widget.TextView, android.view.View
    public CharSequence getAccessibilityClassName() {
        return Button.class.getName();
    }

    @Override // m.w
    public l getItemData() {
        return this.f1151x0;
    }

    public final void h() {
        boolean z5 = true;
        boolean z6 = !TextUtils.isEmpty(this.f1152y0);
        if (this.f1153z0 != null && ((this.f1151x0.L0 & 4) != 4 || (!this.D0 && !this.E0))) {
            z5 = false;
        }
        boolean z9 = z6 & z5;
        setText(z9 ? this.f1152y0 : null);
        CharSequence charSequence = this.f1151x0.D0;
        if (TextUtils.isEmpty(charSequence)) {
            setContentDescription(z9 ? null : this.f1151x0.f14730r0);
        } else {
            setContentDescription(charSequence);
        }
        CharSequence charSequence2 = this.f1151x0.E0;
        if (TextUtils.isEmpty(charSequence2)) {
            a.a.F(this, z9 ? null : this.f1151x0.f14730r0);
        } else {
            a.a.F(this, charSequence2);
        }
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        i iVar = this.A0;
        if (iVar != null) {
            iVar.c(this.f1151x0);
        }
    }

    @Override // android.widget.TextView, android.view.View
    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        this.D0 = g();
        h();
    }

    @Override // androidx.appcompat.widget.g1, android.widget.TextView, android.view.View
    public final void onMeasure(int i10, int i11) {
        int i12;
        boolean zIsEmpty = TextUtils.isEmpty(getText());
        if (!zIsEmpty && (i12 = this.G0) >= 0) {
            super.setPadding(i12, getPaddingTop(), getPaddingRight(), getPaddingBottom());
        }
        super.onMeasure(i10, i11);
        int mode = View.MeasureSpec.getMode(i10);
        int size = View.MeasureSpec.getSize(i10);
        int measuredWidth = getMeasuredWidth();
        int i13 = this.F0;
        int iMin = mode == Integer.MIN_VALUE ? Math.min(size, i13) : i13;
        if (mode != 1073741824 && i13 > 0 && measuredWidth < iMin) {
            super.onMeasure(View.MeasureSpec.makeMeasureSpec(iMin, 1073741824), i11);
        }
        if (!zIsEmpty || this.f1153z0 == null) {
            return;
        }
        super.setPadding((getMeasuredWidth() - this.f1153z0.getBounds().width()) / 2, getPaddingTop(), getPaddingRight(), getPaddingBottom());
    }

    @Override // android.widget.TextView, android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        super.onRestoreInstanceState(null);
    }

    @Override // android.widget.TextView, android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        k kVar;
        if (this.f1151x0.hasSubMenu() && (kVar = this.B0) != null && kVar.onTouch(this, motionEvent)) {
            return true;
        }
        return super.onTouchEvent(motionEvent);
    }

    public void setExpandedFormat(boolean z5) {
        if (this.E0 != z5) {
            this.E0 = z5;
            l lVar = this.f1151x0;
            if (lVar != null) {
                j jVar = lVar.A0;
                jVar.f14725x0 = true;
                jVar.p(true);
            }
        }
    }

    public void setIcon(Drawable drawable) {
        this.f1153z0 = drawable;
        if (drawable != null) {
            int intrinsicWidth = drawable.getIntrinsicWidth();
            int intrinsicHeight = drawable.getIntrinsicHeight();
            int i10 = this.H0;
            if (intrinsicWidth > i10) {
                intrinsicHeight = (int) (intrinsicHeight * (i10 / intrinsicWidth));
                intrinsicWidth = i10;
            }
            if (intrinsicHeight > i10) {
                intrinsicWidth = (int) (intrinsicWidth * (i10 / intrinsicHeight));
            } else {
                i10 = intrinsicHeight;
            }
            drawable.setBounds(0, 0, intrinsicWidth, i10);
        }
        setCompoundDrawables(drawable, null, null, null);
        h();
    }

    public void setItemInvoker(i iVar) {
        this.A0 = iVar;
    }

    @Override // android.widget.TextView, android.view.View
    public final void setPadding(int i10, int i11, int i12, int i13) {
        this.G0 = i10;
        super.setPadding(i10, i11, i12, i13);
    }

    public void setPopupCallback(b bVar) {
        this.C0 = bVar;
    }

    public void setTitle(CharSequence charSequence) {
        this.f1152y0 = charSequence;
        h();
    }

    public void setCheckable(boolean z5) {
    }

    public void setChecked(boolean z5) {
    }
}
