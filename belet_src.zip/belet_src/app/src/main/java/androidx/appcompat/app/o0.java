package androidx.appcompat.app;

import android.view.View;
import androidx.appcompat.widget.ActionBarOverlayLayout;
import java.util.WeakHashMap;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class o0 extends ta.f {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ int f1110c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ q0 f1111d;

    public /* synthetic */ o0(q0 q0Var, int i10) {
        this.f1110c = i10;
        this.f1111d = q0Var;
    }

    @Override // j2.x0
    public final void c() {
        View view;
        int i10 = this.f1110c;
        q0 q0Var = this.f1111d;
        switch (i10) {
            case 0:
                if (q0Var.f1133t && (view = q0Var.f1125l) != null) {
                    view.setTranslationY(0.0f);
                    q0Var.f1122i.setTranslationY(0.0f);
                }
                q0Var.f1122i.setVisibility(8);
                q0Var.f1122i.setTransitioning(false);
                q0Var.f1137x = null;
                m7.c cVar = q0Var.f1129p;
                if (cVar != null) {
                    cVar.A(q0Var.f1128o);
                    q0Var.f1128o = null;
                    q0Var.f1129p = null;
                }
                ActionBarOverlayLayout actionBarOverlayLayout = q0Var.h;
                if (actionBarOverlayLayout != null) {
                    WeakHashMap weakHashMap = j2.q0.f12703a;
                    actionBarOverlayLayout.requestApplyInsets();
                }
                break;
            default:
                q0Var.f1137x = null;
                q0Var.f1122i.requestLayout();
                break;
        }
    }
}
