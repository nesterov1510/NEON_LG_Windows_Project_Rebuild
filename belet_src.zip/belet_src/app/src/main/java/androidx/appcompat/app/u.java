package androidx.appcompat.app;

import android.content.res.Configuration;
import android.os.LocaleList;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public abstract class u {
    public static void a(Configuration configuration, Configuration configuration2, Configuration configuration3) {
        LocaleList locales = configuration.getLocales();
        LocaleList locales2 = configuration2.getLocales();
        if (locales.equals(locales2)) {
            return;
        }
        configuration3.setLocales(locales2);
        configuration3.locale = configuration2.locale;
    }

    public static e2.e b(Configuration configuration) {
        return e2.e.b(configuration.getLocales().toLanguageTags());
    }

    public static void c(e2.e eVar) {
        LocaleList.setDefault(LocaleList.forLanguageTags(eVar.f7310a.a()));
    }

    public static void d(Configuration configuration, e2.e eVar) {
        configuration.setLocales(LocaleList.forLanguageTags(eVar.f7310a.a()));
    }
}
