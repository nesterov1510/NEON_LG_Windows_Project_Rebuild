package androidx.appcompat.app;

import android.R;
import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import androidx.appcompat.widget.g1;
import java.lang.reflect.Constructor;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public class j0 {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final Class[] f1096b = {Context.class, AttributeSet.class};

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final int[] f1097c = {R.attr.onClick};

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final int[] f1098d = {R.attr.accessibilityHeading};

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final int[] f1099e = {R.attr.accessibilityPaneTitle};
    public static final int[] f = {R.attr.screenReaderFocusable};

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static final String[] f1100g = {"android.widget.", "android.view.", "android.webkit."};
    public static final j1.i h = new j1.i(0);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Object[] f1101a = new Object[2];

    public androidx.appcompat.widget.s a(Context context, AttributeSet attributeSet) {
        return new androidx.appcompat.widget.s(context, attributeSet);
    }

    public androidx.appcompat.widget.u b(Context context, AttributeSet attributeSet) {
        return new androidx.appcompat.widget.u(context, attributeSet, tm.belet.films.R.attr.buttonStyle);
    }

    public androidx.appcompat.widget.v c(Context context, AttributeSet attributeSet) {
        return new androidx.appcompat.widget.v(context, attributeSet, tm.belet.films.R.attr.checkboxStyle);
    }

    public androidx.appcompat.widget.g0 d(Context context, AttributeSet attributeSet) {
        return new androidx.appcompat.widget.g0(context, attributeSet);
    }

    public g1 e(Context context, AttributeSet attributeSet) {
        return new g1(context, attributeSet);
    }

    public final View f(Context context, String str, String str2) {
        String strConcat;
        j1.i iVar = h;
        Constructor constructor = (Constructor) iVar.get(str);
        if (constructor == null) {
            if (str2 != null) {
                try {
                    strConcat = str2.concat(str);
                } catch (Exception unused) {
                    return null;
                }
            } else {
                strConcat = str;
            }
            constructor = Class.forName(strConcat, false, context.getClassLoader()).asSubclass(View.class).getConstructor(f1096b);
            iVar.put(str, constructor);
        }
        constructor.setAccessible(true);
        return (View) constructor.newInstance(this.f1101a);
    }
}
