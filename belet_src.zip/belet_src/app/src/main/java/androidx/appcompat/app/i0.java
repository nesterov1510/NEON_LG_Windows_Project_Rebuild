package androidx.appcompat.app;

import android.content.Context;
import android.content.ContextWrapper;
import android.view.View;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import okhttp3.internal.url._UrlKt;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class i0 implements View.OnClickListener {
    public final String X;
    public Method Y;
    public Context Z;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final View f1095e;

    public i0(View view, String str) {
        this.f1095e = view;
        this.X = str;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        String str;
        Method method;
        if (this.Y != null) {
            break;
        }
        View view2 = this.f1095e;
        Context context = view2.getContext();
        while (true) {
            String str2 = this.X;
            if (context == null) {
                int id2 = view2.getId();
                if (id2 == -1) {
                    str = _UrlKt.FRAGMENT_ENCODE_SET;
                } else {
                    str = " with id '" + view2.getContext().getResources().getResourceEntryName(id2) + "'";
                }
                StringBuilder sbM = com.google.protobuf.m0.m("Could not find method ", str2, "(View) in a parent or ancestor Context for android:onClick attribute defined on view ");
                sbM.append(view2.getClass());
                sbM.append(str);
                throw new IllegalStateException(sbM.toString());
            }
            try {
                if (!context.isRestricted() && (method = context.getClass().getMethod(str2, View.class)) != null) {
                    this.Y = method;
                    this.Z = context;
                    break;
                }
            } catch (NoSuchMethodException unused) {
            }
            context = context instanceof ContextWrapper ? ((ContextWrapper) context).getBaseContext() : null;
        }
        try {
            this.Y.invoke(this.Z, view);
        } catch (IllegalAccessException e3) {
            throw new IllegalStateException("Could not execute non-public method for android:onClick", e3);
        } catch (InvocationTargetException e10) {
            throw new IllegalStateException("Could not execute method for android:onClick", e10);
        }
    }
}
