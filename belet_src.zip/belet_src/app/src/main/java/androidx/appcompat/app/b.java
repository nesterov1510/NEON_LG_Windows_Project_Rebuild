package androidx.appcompat.app;

import android.content.DialogInterface;
import android.view.View;
import android.widget.AdapterView;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class b implements AdapterView.OnItemClickListener {
    public final /* synthetic */ c X;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ e f1004e;

    public b(c cVar, e eVar) {
        this.X = cVar;
        this.f1004e = eVar;
    }

    @Override // android.widget.AdapterView.OnItemClickListener
    public final void onItemClick(AdapterView adapterView, View view, int i10, long j10) {
        c cVar = this.X;
        DialogInterface.OnClickListener onClickListener = cVar.f1016m;
        e eVar = this.f1004e;
        onClickListener.onClick(eVar.f1035b, i10);
        if (cVar.f1018o) {
            return;
        }
        eVar.f1035b.dismiss();
    }
}
