package androidx.appcompat.app;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.widget.ListView;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public class AlertController$RecycleListView extends ListView {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int f999e;

    /* JADX INFO: renamed from: r0, reason: collision with root package name */
    public final int f1000r0;

    public AlertController$RecycleListView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, g.a.f8287t);
        this.f1000r0 = typedArrayObtainStyledAttributes.getDimensionPixelOffset(0, -1);
        this.f999e = typedArrayObtainStyledAttributes.getDimensionPixelOffset(1, -1);
    }
}
