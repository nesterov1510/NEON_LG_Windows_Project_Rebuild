package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import tm.belet.films.R;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public class ActionBarContextView extends ViewGroup {
    public View A0;
    public View B0;
    public View C0;
    public LinearLayout D0;
    public TextView E0;
    public TextView F0;
    public final int G0;
    public final int H0;
    public boolean I0;
    public final int J0;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final a f1173e;

    /* JADX INFO: renamed from: r0, reason: collision with root package name */
    public final Context f1174r0;

    /* JADX INFO: renamed from: s0, reason: collision with root package name */
    public ActionMenuView f1175s0;

    /* JADX INFO: renamed from: t0, reason: collision with root package name */
    public n f1176t0;
    public int u0;

    /* JADX INFO: renamed from: v0, reason: collision with root package name */
    public j2.w0 f1177v0;

    /* JADX INFO: renamed from: w0, reason: collision with root package name */
    public boolean f1178w0;

    /* JADX INFO: renamed from: x0, reason: collision with root package name */
    public boolean f1179x0;

    /* JADX INFO: renamed from: y0, reason: collision with root package name */
    public CharSequence f1180y0;

    /* JADX INFO: renamed from: z0, reason: collision with root package name */
    public CharSequence f1181z0;

    public ActionBarContextView(Context context, AttributeSet attributeSet) {
        int resourceId;
        super(context, attributeSet, R.attr.actionModeStyle);
        a aVar = new a();
        aVar.f1254c = this;
        aVar.f1253b = false;
        this.f1173e = aVar;
        TypedValue typedValue = new TypedValue();
        if (!context.getTheme().resolveAttribute(R.attr.actionBarPopupTheme, typedValue, true) || typedValue.resourceId == 0) {
            this.f1174r0 = context;
        } else {
            this.f1174r0 = new ContextThemeWrapper(context, typedValue.resourceId);
        }
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, g.a.f8273d, R.attr.actionModeStyle, 0);
        setBackground((!typedArrayObtainStyledAttributes.hasValue(0) || (resourceId = typedArrayObtainStyledAttributes.getResourceId(0, 0)) == 0) ? typedArrayObtainStyledAttributes.getDrawable(0) : p0.f.w(context, resourceId));
        this.G0 = typedArrayObtainStyledAttributes.getResourceId(5, 0);
        this.H0 = typedArrayObtainStyledAttributes.getResourceId(4, 0);
        this.u0 = typedArrayObtainStyledAttributes.getLayoutDimension(3, 0);
        this.J0 = typedArrayObtainStyledAttributes.getResourceId(2, R.layout.abc_action_mode_close_item_material);
        typedArrayObtainStyledAttributes.recycle();
    }

    public static int f(View view, int i10, int i11) {
        view.measure(View.MeasureSpec.makeMeasureSpec(i10, Integer.MIN_VALUE), i11);
        return Math.max(0, i10 - view.getMeasuredWidth());
    }

    public static int g(int i10, int i11, int i12, View view, boolean z5) {
        int measuredWidth = view.getMeasuredWidth();
        int measuredHeight = view.getMeasuredHeight();
        int i13 = ((i12 - measuredHeight) / 2) + i11;
        if (z5) {
            view.layout(i10 - measuredWidth, i13, i10, measuredHeight + i13);
        } else {
            view.layout(i10, i13, i10 + measuredWidth, measuredHeight + i13);
        }
        return z5 ? -measuredWidth : measuredWidth;
    }

    public final void c(l.a aVar) {
        View view = this.A0;
        if (view == null) {
            View viewInflate = LayoutInflater.from(getContext()).inflate(this.J0, (ViewGroup) this, false);
            this.A0 = viewInflate;
            addView(viewInflate);
        } else if (view.getParent() == null) {
            addView(this.A0);
        }
        View viewFindViewById = this.A0.findViewById(R.id.action_mode_close_button);
        this.B0 = viewFindViewById;
        viewFindViewById.setOnClickListener(new androidx.appcompat.app.a(1, aVar));
        m.j jVarC = aVar.c();
        n nVar = this.f1176t0;
        if (nVar != null) {
            nVar.g();
            h hVar = nVar.H0;
            if (hVar != null && hVar.b()) {
                hVar.f14754i.dismiss();
            }
        }
        n nVar2 = new n(getContext());
        this.f1176t0 = nVar2;
        nVar2.f1380z0 = true;
        nVar2.A0 = true;
        ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(-2, -1);
        jVarC.b(this.f1176t0, this.f1174r0);
        n nVar3 = this.f1176t0;
        m.x xVar = nVar3.u0;
        if (xVar == null) {
            m.x xVar2 = (m.x) nVar3.Z.inflate(nVar3.f1374s0, (ViewGroup) this, false);
            nVar3.u0 = xVar2;
            xVar2.b(nVar3.Y);
            nVar3.c(true);
        }
        m.x xVar3 = nVar3.u0;
        if (xVar != xVar3) {
            ((ActionMenuView) xVar3).setPresenter(nVar3);
        }
        ActionMenuView actionMenuView = (ActionMenuView) xVar3;
        this.f1175s0 = actionMenuView;
        actionMenuView.setBackground(null);
        addView(this.f1175s0, layoutParams);
    }

    public final void d() {
        if (this.D0 == null) {
            LayoutInflater.from(getContext()).inflate(R.layout.abc_action_bar_title_item, this);
            LinearLayout linearLayout = (LinearLayout) getChildAt(getChildCount() - 1);
            this.D0 = linearLayout;
            this.E0 = (TextView) linearLayout.findViewById(R.id.action_bar_title);
            this.F0 = (TextView) this.D0.findViewById(R.id.action_bar_subtitle);
            int i10 = this.G0;
            if (i10 != 0) {
                this.E0.setTextAppearance(getContext(), i10);
            }
            int i11 = this.H0;
            if (i11 != 0) {
                this.F0.setTextAppearance(getContext(), i11);
            }
        }
        this.E0.setText(this.f1180y0);
        this.F0.setText(this.f1181z0);
        boolean zIsEmpty = TextUtils.isEmpty(this.f1180y0);
        boolean zIsEmpty2 = TextUtils.isEmpty(this.f1181z0);
        this.F0.setVisibility(!zIsEmpty2 ? 0 : 8);
        this.D0.setVisibility((zIsEmpty && zIsEmpty2) ? 8 : 0);
        if (this.D0.getParent() == null) {
            addView(this.D0);
        }
    }

    public final void e() {
        removeAllViews();
        this.C0 = null;
        this.f1175s0 = null;
        this.f1176t0 = null;
        View view = this.B0;
        if (view != null) {
            view.setOnClickListener(null);
        }
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new ViewGroup.MarginLayoutParams(-1, -2);
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new ViewGroup.MarginLayoutParams(getContext(), attributeSet);
    }

    public int getAnimatedVisibility() {
        return this.f1177v0 != null ? this.f1173e.f1252a : getVisibility();
    }

    public int getContentHeight() {
        return this.u0;
    }

    public CharSequence getSubtitle() {
        return this.f1181z0;
    }

    public CharSequence getTitle() {
        return this.f1180y0;
    }

    @Override // android.view.View
    /* JADX INFO: renamed from: h, reason: merged with bridge method [inline-methods] */
    public final void setVisibility(int i10) {
        if (i10 != getVisibility()) {
            j2.w0 w0Var = this.f1177v0;
            if (w0Var != null) {
                w0Var.b();
            }
            super.setVisibility(i10);
        }
    }

    public final j2.w0 i(int i10, long j10) {
        j2.w0 w0Var = this.f1177v0;
        if (w0Var != null) {
            w0Var.b();
        }
        a aVar = this.f1173e;
        if (i10 != 0) {
            j2.w0 w0VarA = j2.q0.a(this);
            w0VarA.a(0.0f);
            w0VarA.c(j10);
            ((ActionBarContextView) aVar.f1254c).f1177v0 = w0VarA;
            aVar.f1252a = i10;
            w0VarA.d(aVar);
            return w0VarA;
        }
        if (getVisibility() != 0) {
            setAlpha(0.0f);
        }
        j2.w0 w0VarA2 = j2.q0.a(this);
        w0VarA2.a(1.0f);
        w0VarA2.c(j10);
        ((ActionBarContextView) aVar.f1254c).f1177v0 = w0VarA2;
        aVar.f1252a = i10;
        w0VarA2.d(aVar);
        return w0VarA2;
    }

    @Override // android.view.View
    public final void onConfigurationChanged(Configuration configuration) {
        int i10;
        super.onConfigurationChanged(configuration);
        TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(null, g.a.f8270a, R.attr.actionBarStyle, 0);
        setContentHeight(typedArrayObtainStyledAttributes.getLayoutDimension(13, 0));
        typedArrayObtainStyledAttributes.recycle();
        n nVar = this.f1176t0;
        if (nVar != null) {
            Configuration configuration2 = nVar.X.getResources().getConfiguration();
            int i11 = configuration2.screenWidthDp;
            int i12 = configuration2.screenHeightDp;
            if (configuration2.smallestScreenWidthDp > 600 || i11 > 600 || ((i11 > 960 && i12 > 720) || (i11 > 720 && i12 > 960))) {
                i10 = 5;
            } else if (i11 >= 500 || ((i11 > 640 && i12 > 480) || (i11 > 480 && i12 > 640))) {
                i10 = 4;
            } else {
                i10 = i11 >= 360 ? 3 : 2;
            }
            nVar.D0 = i10;
            m.j jVar = nVar.Y;
            if (jVar != null) {
                jVar.p(true);
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        n nVar = this.f1176t0;
        if (nVar != null) {
            nVar.g();
            h hVar = this.f1176t0.H0;
            if (hVar == null || !hVar.b()) {
                return;
            }
            hVar.f14754i.dismiss();
        }
    }

    @Override // android.view.View
    public final boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 9) {
            this.f1179x0 = false;
        }
        if (!this.f1179x0) {
            boolean zOnHoverEvent = super.onHoverEvent(motionEvent);
            if (actionMasked == 9 && !zOnHoverEvent) {
                this.f1179x0 = true;
            }
        }
        if (actionMasked != 10 && actionMasked != 3) {
            return true;
        }
        this.f1179x0 = false;
        return true;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z5, int i10, int i11, int i12, int i13) {
        boolean z6 = v3.f1471a;
        boolean z9 = getLayoutDirection() == 1;
        int paddingRight = z9 ? (i12 - i10) - getPaddingRight() : getPaddingLeft();
        int paddingTop = getPaddingTop();
        int paddingTop2 = ((i13 - i11) - getPaddingTop()) - getPaddingBottom();
        View view = this.A0;
        if (view != null && view.getVisibility() != 8) {
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.A0.getLayoutParams();
            int i14 = z9 ? marginLayoutParams.rightMargin : marginLayoutParams.leftMargin;
            int i15 = z9 ? marginLayoutParams.leftMargin : marginLayoutParams.rightMargin;
            int i16 = z9 ? paddingRight - i14 : paddingRight + i14;
            int iG = g(i16, paddingTop, paddingTop2, this.A0, z9) + i16;
            paddingRight = z9 ? iG - i15 : iG + i15;
        }
        LinearLayout linearLayout = this.D0;
        if (linearLayout != null && this.C0 == null && linearLayout.getVisibility() != 8) {
            paddingRight += g(paddingRight, paddingTop, paddingTop2, this.D0, z9);
        }
        View view2 = this.C0;
        if (view2 != null) {
            g(paddingRight, paddingTop, paddingTop2, view2, z9);
        }
        int paddingLeft = z9 ? getPaddingLeft() : (i12 - i10) - getPaddingRight();
        ActionMenuView actionMenuView = this.f1175s0;
        if (actionMenuView != null) {
            g(paddingLeft, paddingTop, paddingTop2, actionMenuView, !z9);
        }
    }

    @Override // android.view.View
    public final void onMeasure(int i10, int i11) {
        if (View.MeasureSpec.getMode(i10) != 1073741824) {
            throw new IllegalStateException(getClass().getSimpleName().concat(" can only be used with android:layout_width=\"match_parent\" (or fill_parent)"));
        }
        if (View.MeasureSpec.getMode(i11) == 0) {
            throw new IllegalStateException(getClass().getSimpleName().concat(" can only be used with android:layout_height=\"wrap_content\""));
        }
        int size = View.MeasureSpec.getSize(i10);
        int size2 = this.u0;
        if (size2 <= 0) {
            size2 = View.MeasureSpec.getSize(i11);
        }
        int paddingBottom = getPaddingBottom() + getPaddingTop();
        int paddingLeft = (size - getPaddingLeft()) - getPaddingRight();
        int iMin = size2 - paddingBottom;
        int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(iMin, Integer.MIN_VALUE);
        View view = this.A0;
        if (view != null) {
            int iF = f(view, paddingLeft, iMakeMeasureSpec);
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.A0.getLayoutParams();
            paddingLeft = iF - (marginLayoutParams.leftMargin + marginLayoutParams.rightMargin);
        }
        ActionMenuView actionMenuView = this.f1175s0;
        if (actionMenuView != null && actionMenuView.getParent() == this) {
            paddingLeft = f(this.f1175s0, paddingLeft, iMakeMeasureSpec);
        }
        LinearLayout linearLayout = this.D0;
        if (linearLayout != null && this.C0 == null) {
            if (this.I0) {
                this.D0.measure(View.MeasureSpec.makeMeasureSpec(0, 0), iMakeMeasureSpec);
                int measuredWidth = this.D0.getMeasuredWidth();
                boolean z5 = measuredWidth <= paddingLeft;
                if (z5) {
                    paddingLeft -= measuredWidth;
                }
                this.D0.setVisibility(z5 ? 0 : 8);
            } else {
                paddingLeft = f(linearLayout, paddingLeft, iMakeMeasureSpec);
            }
        }
        View view2 = this.C0;
        if (view2 != null) {
            ViewGroup.LayoutParams layoutParams = view2.getLayoutParams();
            int i12 = layoutParams.width;
            int i13 = i12 != -2 ? 1073741824 : Integer.MIN_VALUE;
            if (i12 >= 0) {
                paddingLeft = Math.min(i12, paddingLeft);
            }
            int i14 = layoutParams.height;
            int i15 = i14 == -2 ? Integer.MIN_VALUE : 1073741824;
            if (i14 >= 0) {
                iMin = Math.min(i14, iMin);
            }
            this.C0.measure(View.MeasureSpec.makeMeasureSpec(paddingLeft, i13), View.MeasureSpec.makeMeasureSpec(iMin, i15));
        }
        if (this.u0 > 0) {
            setMeasuredDimension(size, size2);
            return;
        }
        int childCount = getChildCount();
        int i16 = 0;
        for (int i17 = 0; i17 < childCount; i17++) {
            int measuredHeight = getChildAt(i17).getMeasuredHeight() + paddingBottom;
            if (measuredHeight > i16) {
                i16 = measuredHeight;
            }
        }
        setMeasuredDimension(size, i16);
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.f1178w0 = false;
        }
        if (!this.f1178w0) {
            boolean zOnTouchEvent = super.onTouchEvent(motionEvent);
            if (actionMasked == 0 && !zOnTouchEvent) {
                this.f1178w0 = true;
            }
        }
        if (actionMasked != 1 && actionMasked != 3) {
            return true;
        }
        this.f1178w0 = false;
        return true;
    }

    public void setContentHeight(int i10) {
        this.u0 = i10;
    }

    public void setCustomView(View view) {
        LinearLayout linearLayout;
        View view2 = this.C0;
        if (view2 != null) {
            removeView(view2);
        }
        this.C0 = view;
        if (view != null && (linearLayout = this.D0) != null) {
            removeView(linearLayout);
            this.D0 = null;
        }
        if (view != null) {
            addView(view);
        }
        requestLayout();
    }

    public void setSubtitle(CharSequence charSequence) {
        this.f1181z0 = charSequence;
        d();
    }

    public void setTitle(CharSequence charSequence) {
        this.f1180y0 = charSequence;
        d();
        j2.q0.o(this, charSequence);
    }

    public void setTitleOptional(boolean z5) {
        if (z5 != this.I0) {
            requestLayout();
        }
        this.I0 = z5;
    }

    @Override // android.view.ViewGroup
    public final boolean shouldDelayChildPressedState() {
        return false;
    }
}
