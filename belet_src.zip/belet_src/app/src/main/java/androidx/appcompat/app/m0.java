package androidx.appcompat.app;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class m0 {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static m0 f1104d;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public long f1105a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public long f1106b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f1107c;

    public final void a(double d2, double d10, long j10) {
        float f = (j10 - 946728000000L) / 8.64E7f;
        float f10 = (0.01720197f * f) + 6.24006f;
        double d11 = f10;
        double dSin = (Math.sin(f10 * 3.0f) * 5.236000106378924E-6d) + (Math.sin(2.0f * f10) * 3.4906598739326E-4d) + (Math.sin(d11) * 0.03341960161924362d) + d11 + 1.796593063d + 3.141592653589793d;
        double d12 = (-d10) / 360.0d;
        double dSin2 = (Math.sin(2.0d * dSin) * (-0.0069d)) + (Math.sin(d11) * 0.0053d) + ((double) (Math.round(((double) (f - 9.0E-4f)) - d12) + 9.0E-4f)) + d12;
        double dAsin = Math.asin(Math.sin(0.4092797040939331d) * Math.sin(dSin));
        double d13 = 0.01745329238474369d * d2;
        double dSin3 = (Math.sin(-0.10471975803375244d) - (Math.sin(dAsin) * Math.sin(d13))) / (Math.cos(dAsin) * Math.cos(d13));
        if (dSin3 >= 1.0d) {
            this.f1107c = 1;
            this.f1105a = -1L;
            this.f1106b = -1L;
        } else {
            if (dSin3 <= -1.0d) {
                this.f1107c = 0;
                this.f1105a = -1L;
                this.f1106b = -1L;
                return;
            }
            double dAcos = (float) (Math.acos(dSin3) / 6.283185307179586d);
            this.f1105a = Math.round((dSin2 + dAcos) * 8.64E7d) + 946728000000L;
            long jRound = Math.round((dSin2 - dAcos) * 8.64E7d) + 946728000000L;
            this.f1106b = jRound;
            if (jRound >= j10 || this.f1105a <= j10) {
                this.f1107c = 1;
            } else {
                this.f1107c = 0;
            }
        }
    }
}
