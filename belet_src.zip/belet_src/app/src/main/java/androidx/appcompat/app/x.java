package androidx.appcompat.app;

import android.content.Context;
import android.content.res.Resources;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.ActionMode;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.SearchEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.PopupWindow;
import androidx.appcompat.widget.ActionBarContextView;
import androidx.appcompat.widget.ViewStubCompat;
import j2.w0;
import java.util.ArrayList;
import java.util.List;
import java.util.WeakHashMap;
import tm.belet.films.R;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class x implements Window.Callback {
    public boolean X;
    public boolean Y;
    public boolean Z;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final Window.Callback f1145e;

    /* JADX INFO: renamed from: r0, reason: collision with root package name */
    public final /* synthetic */ e0 f1146r0;

    public x(e0 e0Var, Window.Callback callback) {
        this.f1146r0 = e0Var;
        if (callback == null) {
            throw new IllegalArgumentException("Window callback may not be null");
        }
        this.f1145e = callback;
    }

    public final void a(Window.Callback callback) {
        try {
            this.X = true;
            callback.onContentChanged();
        } finally {
            this.X = false;
        }
    }

    public final boolean b(int i10, Menu menu) {
        return this.f1145e.onMenuOpened(i10, menu);
    }

    public final void c(int i10, Menu menu) {
        this.f1145e.onPanelClosed(i10, menu);
    }

    public final void d(List list, Menu menu, int i10) {
        l.k.a(this.f1145e, list, menu, i10);
    }

    @Override // android.view.Window.Callback
    public final boolean dispatchGenericMotionEvent(MotionEvent motionEvent) {
        return this.f1145e.dispatchGenericMotionEvent(motionEvent);
    }

    @Override // android.view.Window.Callback
    public final boolean dispatchKeyEvent(KeyEvent keyEvent) {
        boolean z5 = this.Y;
        Window.Callback callback = this.f1145e;
        if (z5) {
            return callback.dispatchKeyEvent(keyEvent);
        }
        return this.f1146r0.t(keyEvent) || callback.dispatchKeyEvent(keyEvent);
    }

    /* JADX WARN: Code duplicated, block: B:17:0x003b  */
    /* JADX WARN: Code duplicated, block: B:18:0x003d  */
    /* JADX WARN: Code duplicated, block: B:25:0x0052  */
    /* JADX WARN: Code duplicated, block: B:27:0x0056  */
    @Override // android.view.Window.Callback
    public final boolean dispatchKeyShortcutEvent(KeyEvent keyEvent) {
        d0 d0Var;
        boolean z5;
        boolean zF;
        m.j jVar;
        boolean zPerformShortcut;
        if (!this.f1145e.dispatchKeyShortcutEvent(keyEvent)) {
            int keyCode = keyEvent.getKeyCode();
            e0 e0Var = this.f1146r0;
            e0Var.A();
            q0 q0Var = e0Var.B0;
            if (q0Var == null) {
                d0Var = e0Var.f1061a1;
                if (d0Var == null && e0Var.F(d0Var, keyEvent.getKeyCode(), keyEvent)) {
                    d0 d0Var2 = e0Var.f1061a1;
                    if (d0Var2 != null) {
                        d0Var2.f1029l = true;
                    }
                } else {
                    if (e0Var.f1061a1 == null) {
                        d0 d0VarZ = e0Var.z(0);
                        e0Var.G(d0VarZ, keyEvent);
                        zF = e0Var.F(d0VarZ, keyEvent.getKeyCode(), keyEvent);
                        d0VarZ.f1028k = false;
                        if (zF) {
                        }
                    }
                    z5 = false;
                }
                z5 = true;
            } else {
                p0 p0Var = q0Var.f1127n;
                if (p0Var == null || (jVar = p0Var.Z) == null) {
                    zPerformShortcut = false;
                } else {
                    jVar.setQwertyMode(KeyCharacterMap.load(keyEvent.getDeviceId()).getKeyboardType() != 1);
                    zPerformShortcut = jVar.performShortcut(keyCode, keyEvent, 0);
                }
                if (zPerformShortcut) {
                    z5 = true;
                } else {
                    d0Var = e0Var.f1061a1;
                    if (d0Var == null) {
                        if (e0Var.f1061a1 == null) {
                            d0 d0VarZ2 = e0Var.z(0);
                            e0Var.G(d0VarZ2, keyEvent);
                            zF = e0Var.F(d0VarZ2, keyEvent.getKeyCode(), keyEvent);
                            d0VarZ2.f1028k = false;
                            if (zF) {
                                z5 = true;
                            }
                        }
                        z5 = false;
                    } else {
                        if (e0Var.f1061a1 == null) {
                            d0 d0VarZ3 = e0Var.z(0);
                            e0Var.G(d0VarZ3, keyEvent);
                            zF = e0Var.F(d0VarZ3, keyEvent.getKeyCode(), keyEvent);
                            d0VarZ3.f1028k = false;
                            if (zF) {
                                z5 = true;
                            }
                        }
                        z5 = false;
                    }
                }
            }
            if (!z5) {
                return false;
            }
        }
        return true;
    }

    @Override // android.view.Window.Callback
    public final boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        return this.f1145e.dispatchPopulateAccessibilityEvent(accessibilityEvent);
    }

    @Override // android.view.Window.Callback
    public final boolean dispatchTouchEvent(MotionEvent motionEvent) {
        return this.f1145e.dispatchTouchEvent(motionEvent);
    }

    @Override // android.view.Window.Callback
    public final boolean dispatchTrackballEvent(MotionEvent motionEvent) {
        return this.f1145e.dispatchTrackballEvent(motionEvent);
    }

    @Override // android.view.Window.Callback
    public final void onActionModeFinished(ActionMode actionMode) {
        this.f1145e.onActionModeFinished(actionMode);
    }

    @Override // android.view.Window.Callback
    public final void onActionModeStarted(ActionMode actionMode) {
        this.f1145e.onActionModeStarted(actionMode);
    }

    @Override // android.view.Window.Callback
    public final void onAttachedToWindow() {
        this.f1145e.onAttachedToWindow();
    }

    @Override // android.view.Window.Callback
    public final void onContentChanged() {
        if (this.X) {
            this.f1145e.onContentChanged();
        }
    }

    @Override // android.view.Window.Callback
    public final boolean onCreatePanelMenu(int i10, Menu menu) {
        if (i10 != 0 || (menu instanceof m.j)) {
            return this.f1145e.onCreatePanelMenu(i10, menu);
        }
        return false;
    }

    @Override // android.view.Window.Callback
    public final View onCreatePanelView(int i10) {
        return this.f1145e.onCreatePanelView(i10);
    }

    @Override // android.view.Window.Callback
    public final void onDetachedFromWindow() {
        this.f1145e.onDetachedFromWindow();
    }

    @Override // android.view.Window.Callback
    public final boolean onMenuItemSelected(int i10, MenuItem menuItem) {
        return this.f1145e.onMenuItemSelected(i10, menuItem);
    }

    @Override // android.view.Window.Callback
    public final boolean onMenuOpened(int i10, Menu menu) {
        b(i10, menu);
        if (i10 == 108) {
            e0 e0Var = this.f1146r0;
            e0Var.A();
            q0 q0Var = e0Var.B0;
            if (q0Var != null) {
                ArrayList arrayList = q0Var.f1131r;
                if (true != q0Var.f1130q) {
                    q0Var.f1130q = true;
                    if (arrayList.size() > 0) {
                        arrayList.get(0).getClass();
                        throw new ClassCastException();
                    }
                }
            }
        }
        return true;
    }

    @Override // android.view.Window.Callback
    public final void onPanelClosed(int i10, Menu menu) {
        if (this.Z) {
            this.f1145e.onPanelClosed(i10, menu);
            return;
        }
        c(i10, menu);
        e0 e0Var = this.f1146r0;
        if (i10 != 108) {
            if (i10 == 0) {
                d0 d0VarZ = e0Var.z(i10);
                if (d0VarZ.f1030m) {
                    e0Var.r(d0VarZ, false);
                    return;
                }
                return;
            }
            return;
        }
        e0Var.A();
        q0 q0Var = e0Var.B0;
        if (q0Var != null) {
            ArrayList arrayList = q0Var.f1131r;
            if (q0Var.f1130q) {
                q0Var.f1130q = false;
                if (arrayList.size() <= 0) {
                    return;
                }
                arrayList.get(0).getClass();
                throw new ClassCastException();
            }
        }
    }

    @Override // android.view.Window.Callback
    public final void onPointerCaptureChanged(boolean z5) {
        l.l.a(this.f1145e, z5);
    }

    @Override // android.view.Window.Callback
    public final boolean onPreparePanel(int i10, View view, Menu menu) {
        m.j jVar = menu instanceof m.j ? (m.j) menu : null;
        if (i10 == 0 && jVar == null) {
            return false;
        }
        if (jVar != null) {
            jVar.K0 = true;
        }
        boolean zOnPreparePanel = this.f1145e.onPreparePanel(i10, view, menu);
        if (jVar != null) {
            jVar.K0 = false;
        }
        return zOnPreparePanel;
    }

    @Override // android.view.Window.Callback
    public final void onProvideKeyboardShortcuts(List list, Menu menu, int i10) {
        m.j jVar = this.f1146r0.z(0).h;
        if (jVar != null) {
            d(list, jVar, i10);
        } else {
            d(list, menu, i10);
        }
    }

    @Override // android.view.Window.Callback
    public final boolean onSearchRequested(SearchEvent searchEvent) {
        return l.j.a(this.f1145e, searchEvent);
    }

    @Override // android.view.Window.Callback
    public final void onWindowAttributesChanged(WindowManager.LayoutParams layoutParams) {
        this.f1145e.onWindowAttributesChanged(layoutParams);
    }

    @Override // android.view.Window.Callback
    public final void onWindowFocusChanged(boolean z5) {
        this.f1145e.onWindowFocusChanged(z5);
    }

    @Override // android.view.Window.Callback
    public final ActionMode onWindowStartingActionMode(ActionMode.Callback callback) {
        return null;
    }

    @Override // android.view.Window.Callback
    public final boolean onSearchRequested() {
        return this.f1145e.onSearchRequested();
    }

    @Override // android.view.Window.Callback
    public final ActionMode onWindowStartingActionMode(ActionMode.Callback callback, int i10) {
        ViewGroup viewGroup;
        e0 e0Var = this.f1146r0;
        if (!e0Var.M0 || i10 != 0) {
            return l.j.b(this.f1145e, callback, i10);
        }
        Context context = e0Var.f1083x0;
        m7.i iVar = new m7.i();
        iVar.X = context;
        iVar.f15154e = callback;
        iVar.Y = new ArrayList();
        iVar.Z = new j1.i(0);
        l.a aVar = e0Var.H0;
        if (aVar != null) {
            aVar.a();
        }
        int i11 = 1;
        m7.c cVar = new m7.c(e0Var, iVar, i11);
        e0Var.A();
        q0 q0Var = e0Var.B0;
        if (q0Var != null) {
            p0 p0Var = q0Var.f1127n;
            if (p0Var != null) {
                p0Var.a();
            }
            q0Var.h.setHideOnContentScrollEnabled(false);
            q0Var.f1124k.e();
            p0 p0Var2 = new p0(q0Var, q0Var.f1124k.getContext(), cVar);
            m.j jVar = p0Var2.Z;
            jVar.w();
            try {
                boolean zT = ((m7.i) p0Var2.f1117r0.X).t(p0Var2, jVar);
                jVar.v();
                if (zT) {
                    q0Var.f1127n = p0Var2;
                    p0Var2.g();
                    q0Var.f1124k.c(p0Var2);
                    q0Var.A(true);
                } else {
                    p0Var2 = null;
                }
                e0Var.H0 = p0Var2;
            } catch (Throwable th2) {
                jVar.v();
                throw th2;
            }
        }
        if (e0Var.H0 == null) {
            w0 w0Var = e0Var.L0;
            if (w0Var != null) {
                w0Var.b();
            }
            l.a aVar2 = e0Var.H0;
            if (aVar2 != null) {
                aVar2.a();
            }
            if (e0Var.I0 == null) {
                if (e0Var.W0) {
                    TypedValue typedValue = new TypedValue();
                    Resources.Theme theme = context.getTheme();
                    theme.resolveAttribute(R.attr.actionBarTheme, typedValue, true);
                    if (typedValue.resourceId != 0) {
                        Resources.Theme themeNewTheme = context.getResources().newTheme();
                        themeNewTheme.setTo(theme);
                        themeNewTheme.applyStyle(typedValue.resourceId, true);
                        l.c cVar2 = new l.c(context, 0);
                        cVar2.getTheme().setTo(themeNewTheme);
                        context = cVar2;
                    }
                    e0Var.I0 = new ActionBarContextView(context, null);
                    PopupWindow popupWindow = new PopupWindow(context, (AttributeSet) null, R.attr.actionModePopupWindowStyle);
                    e0Var.J0 = popupWindow;
                    popupWindow.setWindowLayoutType(2);
                    e0Var.J0.setContentView(e0Var.I0);
                    e0Var.J0.setWidth(-1);
                    context.getTheme().resolveAttribute(R.attr.actionBarSize, typedValue, true);
                    e0Var.I0.setContentHeight(TypedValue.complexToDimensionPixelSize(typedValue.data, context.getResources().getDisplayMetrics()));
                    e0Var.J0.setHeight(-2);
                    e0Var.K0 = new q(e0Var, i11);
                } else {
                    ViewStubCompat viewStubCompat = (ViewStubCompat) e0Var.O0.findViewById(R.id.action_mode_bar_stub);
                    if (viewStubCompat != null) {
                        e0Var.A();
                        q0 q0Var2 = e0Var.B0;
                        Context contextB = q0Var2 != null ? q0Var2.B() : null;
                        if (contextB != null) {
                            context = contextB;
                        }
                        viewStubCompat.setLayoutInflater(LayoutInflater.from(context));
                        e0Var.I0 = (ActionBarContextView) viewStubCompat.a();
                    }
                }
            }
            if (e0Var.I0 != null) {
                w0 w0Var2 = e0Var.L0;
                if (w0Var2 != null) {
                    w0Var2.b();
                }
                e0Var.I0.e();
                Context context2 = e0Var.I0.getContext();
                ActionBarContextView actionBarContextView = e0Var.I0;
                l.d dVar = new l.d();
                dVar.Y = context2;
                dVar.Z = actionBarContextView;
                dVar.f13993r0 = cVar;
                m.j jVar2 = new m.j(actionBarContextView.getContext());
                jVar2.f14726y0 = 1;
                dVar.u0 = jVar2;
                jVar2.f14720r0 = dVar;
                if (iVar.t(dVar, jVar2)) {
                    dVar.g();
                    e0Var.I0.c(dVar);
                    e0Var.H0 = dVar;
                    if (e0Var.N0 && (viewGroup = e0Var.O0) != null && viewGroup.isLaidOut()) {
                        e0Var.I0.setAlpha(0.0f);
                        w0 w0VarA = j2.q0.a(e0Var.I0);
                        w0VarA.a(1.0f);
                        e0Var.L0 = w0VarA;
                        w0VarA.d(new s(i11, e0Var));
                    } else {
                        e0Var.I0.setAlpha(1.0f);
                        e0Var.I0.setVisibility(0);
                        if (e0Var.I0.getParent() instanceof View) {
                            View view = (View) e0Var.I0.getParent();
                            WeakHashMap weakHashMap = j2.q0.f12703a;
                            view.requestApplyInsets();
                        }
                    }
                    if (e0Var.J0 != null) {
                        e0Var.f1084y0.getDecorView().post(e0Var.K0);
                    }
                } else {
                    e0Var.H0 = null;
                }
            }
            e0Var.I();
            e0Var.H0 = e0Var.H0;
        }
        e0Var.I();
        l.a aVar3 = e0Var.H0;
        if (aVar3 != null) {
            return iVar.e(aVar3);
        }
        return null;
    }
}
