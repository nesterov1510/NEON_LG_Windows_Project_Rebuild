package androidx.appcompat.app;

import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import java.lang.ref.WeakReference;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public abstract class p {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final g6.g0 f1112e = new g6.g0(new o());
    public static final int X = -100;
    public static e2.e Y = null;
    public static e2.e Z = null;

    /* JADX INFO: renamed from: r0, reason: collision with root package name */
    public static Boolean f1113r0 = null;

    /* JADX INFO: renamed from: s0, reason: collision with root package name */
    public static boolean f1114s0 = false;

    /* JADX INFO: renamed from: t0, reason: collision with root package name */
    public static final j1.f f1115t0 = new j1.f(0);
    public static final Object u0 = new Object();

    /* JADX INFO: renamed from: v0, reason: collision with root package name */
    public static final Object f1116v0 = new Object();

    public static boolean b(Context context) {
        if (f1113r0 == null) {
            try {
                int i10 = l0.f1103e;
                Bundle bundle = context.getPackageManager().getServiceInfo(new ComponentName(context, (Class<?>) l0.class), Build.VERSION.SDK_INT >= 24 ? k0.a() | 128 : 640).metaData;
                if (bundle != null) {
                    f1113r0 = Boolean.valueOf(bundle.getBoolean("autoStoreLocales"));
                }
            } catch (PackageManager.NameNotFoundException unused) {
                Log.d("AppCompatDelegate", "Checking for metadata for AppLocalesMetadataHolderService : Service not found");
                f1113r0 = Boolean.FALSE;
            }
        }
        return f1113r0.booleanValue();
    }

    public static void e(e0 e0Var) {
        synchronized (u0) {
            try {
                j1.f fVar = f1115t0;
                fVar.getClass();
                j1.a aVar = new j1.a(fVar);
                while (aVar.hasNext()) {
                    p pVar = (p) ((WeakReference) aVar.next()).get();
                    if (pVar == e0Var || pVar == null) {
                        aVar.remove();
                    }
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    public abstract void a();

    public abstract void c();

    public abstract void d();

    public abstract boolean f(int i10);

    public abstract void g(int i10);

    public abstract void i(View view);

    public abstract void k(View view, ViewGroup.LayoutParams layoutParams);

    public abstract void l(CharSequence charSequence);
}
