package androidx.appcompat.app;

import android.content.Context;
import android.graphics.Rect;
import android.os.Build;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;
import androidx.appcompat.widget.ActionBarContextView;
import androidx.appcompat.widget.u3;
import androidx.appcompat.widget.v3;
import j2.z1;
import java.lang.reflect.Method;
import java.util.WeakHashMap;
import tm.belet.films.R;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class r implements j2.q, m.u {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ e0 f1140e;

    public /* synthetic */ r(e0 e0Var) {
        this.f1140e = e0Var;
    }

    @Override // m.u
    public void b(m.j jVar, boolean z5) {
        d0 d0Var;
        m.j jVarK = jVar.k();
        int i10 = 0;
        boolean z6 = jVarK != jVar;
        if (z6) {
            jVar = jVarK;
        }
        e0 e0Var = this.f1140e;
        d0[] d0VarArr = e0Var.Z0;
        int length = d0VarArr != null ? d0VarArr.length : 0;
        while (true) {
            if (i10 < length) {
                d0Var = d0VarArr[i10];
                if (d0Var != null && d0Var.h == jVar) {
                    break;
                } else {
                    i10++;
                }
            } else {
                d0Var = null;
                break;
            }
        }
        if (d0Var != null) {
            if (!z6) {
                e0Var.r(d0Var, z5);
            } else {
                e0Var.p(d0Var.f1020a, d0Var, jVarK);
                e0Var.r(d0Var, true);
            }
        }
    }

    /* JADX WARN: Unreachable blocks removed: 1, instructions: 1 */
    @Override // j2.q
    public z1 d(View view, z1 z1Var) {
        int i10;
        int i11;
        int i12;
        int i13;
        int iD = z1Var.d();
        e0 e0Var = this.f1140e;
        Context context = e0Var.f1083x0;
        int iD2 = z1Var.d();
        ActionBarContextView actionBarContextView = e0Var.I0;
        if (actionBarContextView == null || !(actionBarContextView.getLayoutParams() instanceof ViewGroup.MarginLayoutParams)) {
            i10 = 0;
            i11 = 0;
        } else {
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) e0Var.I0.getLayoutParams();
            int i14 = 1;
            if (e0Var.I0.isShown()) {
                if (e0Var.f1077q1 == null) {
                    e0Var.f1077q1 = new Rect();
                    e0Var.f1078r1 = new Rect();
                }
                Rect rect = e0Var.f1077q1;
                Rect rect2 = e0Var.f1078r1;
                rect.set(z1Var.b(), z1Var.d(), z1Var.c(), z1Var.a());
                ViewGroup viewGroup = e0Var.O0;
                if (Build.VERSION.SDK_INT >= 29) {
                    boolean z5 = v3.f1471a;
                    u3.a(viewGroup, rect, rect2);
                    i12 = 0;
                } else {
                    if (v3.f1471a) {
                        i12 = 0;
                    } else {
                        v3.f1471a = true;
                        i12 = 0;
                        try {
                            Method declaredMethod = View.class.getDeclaredMethod("computeFitSystemWindows", Rect.class, Rect.class);
                            v3.f1472b = declaredMethod;
                            if (!declaredMethod.isAccessible()) {
                                v3.f1472b.setAccessible(true);
                            }
                        } catch (NoSuchMethodException unused) {
                            Log.d("ViewUtils", "Could not find method computeFitSystemWindows. Oh well.");
                        }
                    }
                    Method method = v3.f1472b;
                    if (method != null) {
                        try {
                            Object[] objArr = new Object[2];
                            objArr[i12] = rect;
                            objArr[1] = rect2;
                            method.invoke(viewGroup, objArr);
                        } catch (Exception e3) {
                            Log.d("ViewUtils", "Could not invoke computeFitSystemWindows", e3);
                        }
                    }
                }
                int i15 = rect.top;
                int i16 = rect.left;
                int i17 = rect.right;
                ViewGroup viewGroup2 = e0Var.O0;
                WeakHashMap weakHashMap = j2.q0.f12703a;
                z1 z1VarA = j2.i0.a(viewGroup2);
                int iB = z1VarA == null ? i12 : z1VarA.b();
                int iC = z1VarA == null ? i12 : z1VarA.c();
                if (marginLayoutParams.topMargin == i15 && marginLayoutParams.leftMargin == i16 && marginLayoutParams.rightMargin == i17) {
                    i13 = i12;
                } else {
                    marginLayoutParams.topMargin = i15;
                    marginLayoutParams.leftMargin = i16;
                    marginLayoutParams.rightMargin = i17;
                    i13 = 1;
                }
                if (i15 <= 0 || e0Var.Q0 != null) {
                    View view2 = e0Var.Q0;
                    if (view2 != null) {
                        ViewGroup.MarginLayoutParams marginLayoutParams2 = (ViewGroup.MarginLayoutParams) view2.getLayoutParams();
                        int i18 = marginLayoutParams2.height;
                        int i19 = marginLayoutParams.topMargin;
                        if (i18 != i19 || marginLayoutParams2.leftMargin != iB || marginLayoutParams2.rightMargin != iC) {
                            marginLayoutParams2.height = i19;
                            marginLayoutParams2.leftMargin = iB;
                            marginLayoutParams2.rightMargin = iC;
                            e0Var.Q0.setLayoutParams(marginLayoutParams2);
                        }
                    }
                } else {
                    View view3 = new View(context);
                    e0Var.Q0 = view3;
                    view3.setVisibility(8);
                    FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-1, marginLayoutParams.topMargin, 51);
                    layoutParams.leftMargin = iB;
                    layoutParams.rightMargin = iC;
                    e0Var.O0.addView(e0Var.Q0, -1, layoutParams);
                }
                View view4 = e0Var.Q0;
                i14 = view4 == null ? i12 : 1;
                if (i14 != 0 && view4.getVisibility() != 0) {
                    View view5 = e0Var.Q0;
                    view5.setBackgroundColor((view5.getWindowSystemUiVisibility() & 8192) != 0 ? context.getColor(R.color.abc_decor_view_status_guard_light) : context.getColor(R.color.abc_decor_view_status_guard));
                }
                if (!e0Var.V0 && i14 != 0) {
                    iD2 = i12;
                }
                i11 = i14;
                i10 = i12;
                i14 = i13;
            } else {
                i10 = 0;
                if (marginLayoutParams.topMargin != 0) {
                    marginLayoutParams.topMargin = 0;
                    i11 = 0;
                } else {
                    i11 = 0;
                    i14 = 0;
                }
            }
            if (i14 != 0) {
                e0Var.I0.setLayoutParams(marginLayoutParams);
            }
        }
        View view6 = e0Var.Q0;
        if (view6 != null) {
            view6.setVisibility(i11 != 0 ? i10 : 8);
        }
        return j2.q0.i(view, iD != iD2 ? z1Var.f(z1Var.b(), iD2, z1Var.c(), z1Var.a()) : z1Var);
    }

    @Override // m.u
    public boolean h(m.j jVar) {
        Window.Callback callback;
        if (jVar != jVar.k()) {
            return true;
        }
        e0 e0Var = this.f1140e;
        if (!e0Var.T0 || (callback = e0Var.f1084y0.getCallback()) == null || e0Var.f1065e1) {
            return true;
        }
        callback.onMenuOpened(108, jVar);
        return true;
    }
}
