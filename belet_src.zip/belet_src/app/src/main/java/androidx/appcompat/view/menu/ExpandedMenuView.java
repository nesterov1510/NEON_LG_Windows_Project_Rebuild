package androidx.appcompat.view.menu;

import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import m.i;
import m.j;
import m.l;
import m.x;
import nh.c;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class ExpandedMenuView extends ListView implements i, x, AdapterView.OnItemClickListener {

    /* JADX INFO: renamed from: r0, reason: collision with root package name */
    public static final int[] f1154r0 = {R.attr.background, R.attr.divider};

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public j f1155e;

    public ExpandedMenuView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setOnItemClickListener(this);
        c cVarC = c.C(context, attributeSet, f1154r0, R.attr.listViewStyle);
        TypedArray typedArray = (TypedArray) cVarC.Y;
        if (typedArray.hasValue(0)) {
            setBackgroundDrawable(cVarC.u(0));
        }
        if (typedArray.hasValue(1)) {
            setDivider(cVarC.u(1));
        }
        cVarC.F();
    }

    @Override // m.x
    public final void b(j jVar) {
        this.f1155e = jVar;
    }

    @Override // m.i
    public final boolean c(l lVar) {
        return this.f1155e.q(lVar, null, 0);
    }

    public int getWindowAnimations() {
        return 0;
    }

    @Override // android.widget.ListView, android.widget.AbsListView, android.widget.AdapterView, android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        setChildrenDrawingCacheEnabled(false);
    }

    @Override // android.widget.AdapterView.OnItemClickListener
    public final void onItemClick(AdapterView adapterView, View view, int i10, long j10) {
        c((l) getAdapter().getItem(i10));
    }
}
