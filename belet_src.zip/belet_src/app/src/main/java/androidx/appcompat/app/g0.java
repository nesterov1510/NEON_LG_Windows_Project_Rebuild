package androidx.appcompat.app;

import android.content.Context;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import tm.belet.films.R;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public class g0 extends c.j implements k {
    public e0 Z;

    /* JADX INFO: renamed from: r0, reason: collision with root package name */
    public final f0 f1090r0;

    /* JADX WARN: Type inference failed for: r2v2, types: [androidx.appcompat.app.f0] */
    public g0(Context context, int i10) {
        int i11;
        if (i10 == 0) {
            TypedValue typedValue = new TypedValue();
            context.getTheme().resolveAttribute(R.attr.dialogTheme, typedValue, true);
            i11 = typedValue.resourceId;
        } else {
            i11 = i10;
        }
        super(context, i11);
        this.f1090r0 = new j2.l() { // from class: androidx.appcompat.app.f0
            @Override // j2.l
            public final boolean o(KeyEvent keyEvent) {
                return this.f1088e.d(keyEvent);
            }
        };
        p pVarC = c();
        if (i10 == 0) {
            TypedValue typedValue2 = new TypedValue();
            context.getTheme().resolveAttribute(R.attr.dialogTheme, typedValue2, true);
            i10 = typedValue2.resourceId;
        }
        ((e0) pVarC).f1068h1 = i10;
        pVarC.c();
    }

    @Override // c.j, android.app.Dialog
    public final void addContentView(View view, ViewGroup.LayoutParams layoutParams) {
        b();
        e0 e0Var = (e0) c();
        e0Var.v();
        ((ViewGroup) e0Var.O0.findViewById(android.R.id.content)).addView(view, layoutParams);
        e0Var.f1085z0.a(e0Var.f1084y0.getCallback());
    }

    public final p c() {
        if (this.Z == null) {
            g6.g0 g0Var = p.f1112e;
            this.Z = new e0(getContext(), getWindow(), this, this);
        }
        return this.Z;
    }

    public final boolean d(KeyEvent keyEvent) {
        return super.dispatchKeyEvent(keyEvent);
    }

    @Override // android.app.Dialog, android.content.DialogInterface
    public final void dismiss() {
        super.dismiss();
        c().d();
    }

    @Override // android.app.Dialog, android.view.Window.Callback
    public final boolean dispatchKeyEvent(KeyEvent keyEvent) {
        return q0.f.h(this.f1090r0, getWindow().getDecorView(), this, keyEvent);
    }

    @Override // android.app.Dialog
    public final View findViewById(int i10) {
        e0 e0Var = (e0) c();
        e0Var.v();
        return e0Var.f1084y0.findViewById(i10);
    }

    @Override // android.app.Dialog
    public final void invalidateOptionsMenu() {
        e0 e0Var = (e0) c();
        if (e0Var.B0 != null) {
            e0Var.A();
            e0Var.B0.getClass();
            e0Var.B(0);
        }
    }

    @Override // c.j, android.app.Dialog
    public void onCreate(Bundle bundle) {
        c().a();
        super.onCreate(bundle);
        c().c();
    }

    @Override // c.j, android.app.Dialog
    public final void onStop() {
        super.onStop();
        e0 e0Var = (e0) c();
        e0Var.A();
        q0 q0Var = e0Var.B0;
        if (q0Var != null) {
            q0Var.f1138y = false;
            l.i iVar = q0Var.f1137x;
            if (iVar != null) {
                iVar.a();
            }
        }
    }

    @Override // c.j, android.app.Dialog
    public void setContentView(int i10) {
        b();
        c().g(i10);
    }

    @Override // android.app.Dialog
    public void setTitle(CharSequence charSequence) {
        super.setTitle(charSequence);
        c().l(charSequence);
    }

    @Override // c.j, android.app.Dialog
    public void setContentView(View view) {
        b();
        c().i(view);
    }

    @Override // android.app.Dialog
    public final void setTitle(int i10) {
        super.setTitle(i10);
        c().l(getContext().getString(i10));
    }

    @Override // c.j, android.app.Dialog
    public void setContentView(View view, ViewGroup.LayoutParams layoutParams) {
        b();
        c().k(view, layoutParams);
    }
}
