package androidx.appcompat.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import androidx.media3.session.legacy.r0;
import androidx.media3.session.z3;
import cb.j1;
import cb.k1;
import com.google.android.gms.internal.measurement.t4;
import j$.util.Objects;
import java.util.concurrent.Executor;
import tm.belet.films.presentation.activities.PlayerActivity;
import tm.belet.films.presentation.utils.picture_in_picture.PlayerEvent;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class z extends BroadcastReceiver {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1149a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Object f1150b;

    public /* synthetic */ z(int i10, Object obj) {
        this.f1149a = i10;
        this.f1150b = obj;
    }

    @Override // android.content.BroadcastReceiver
    public final void onReceive(Context context, Intent intent) {
        KeyEvent keyEvent;
        switch (this.f1149a) {
            case 0:
                ((a0) this.f1150b).q1();
                return;
            case 1:
                androidx.media3.session.b bVar = (androidx.media3.session.b) this.f1150b;
                bVar.f2183c.execute(new androidx.media3.session.a(bVar, 2));
                return;
            case 2:
                if (Objects.equals(intent.getAction(), "android.intent.action.MEDIA_BUTTON") && (keyEvent = (KeyEvent) intent.getParcelableExtra("android.intent.extra.KEY_EVENT")) != null) {
                    ((androidx.media3.session.legacy.b0) ((r0) ((z3) this.f1150b).f2806m.Y).X).f2427a.dispatchMediaButtonEvent(keyEvent);
                    return;
                }
                return;
            case 3:
                k1 k1Var = (k1) this.f1150b;
                if (intent == null) {
                    cb.p0 p0Var = k1Var.f4205s0;
                    k1.h(p0Var);
                    p0Var.f4286w0.a("App receiver called with null intent");
                    return;
                }
                String action = intent.getAction();
                if (action == null) {
                    cb.p0 p0Var2 = k1Var.f4205s0;
                    k1.h(p0Var2);
                    p0Var2.f4286w0.a("App receiver called with null action");
                    return;
                }
                int iHashCode = action.hashCode();
                if (iHashCode != -1928239649) {
                    if (iHashCode == 1279883384 && action.equals("com.google.android.gms.measurement.BATCHES_AVAILABLE")) {
                        cb.p0 p0Var3 = k1Var.f4205s0;
                        k1.h(p0Var3);
                        p0Var3.B0.a("[sgtm] App Receiver notified batches are available");
                        j1 j1Var = k1Var.f4206t0;
                        k1.h(j1Var);
                        j1Var.Q1(new a7.d(16, this));
                        return;
                    }
                } else if (action.equals("com.google.android.gms.measurement.TRIGGERS_AVAILABLE")) {
                    t4.a();
                    if (k1Var.Z.S1(null, cb.z.Q0)) {
                        cb.p0 p0Var4 = k1Var.f4205s0;
                        k1.h(p0Var4);
                        p0Var4.B0.a("App receiver notified triggers are available");
                        j1 j1Var2 = k1Var.f4206t0;
                        k1.h(j1Var2);
                        j1Var2.Q1(new a7.d(17, k1Var));
                        return;
                    }
                    return;
                }
                cb.p0 p0Var5 = k1Var.f4205s0;
                k1.h(p0Var5);
                p0Var5.f4286w0.a("App receiver called with unknown action");
                return;
            case 4:
                if (isInitialStickyBroadcast()) {
                    return;
                }
                ((d4.d) this.f1150b).a();
                return;
            case 5:
                kotlin.jvm.internal.q.g(context, "context");
                kotlin.jvm.internal.q.g(intent, "intent");
                ((k7.d) this.f1150b).g(intent);
                return;
            case 6:
                ((Executor) ((l3.t) this.f1150b).f14151c).execute(new k4.d0(this, context, 8));
                return;
            case 7:
                u3.e eVar = (u3.e) this.f1150b;
                if (isInitialStickyBroadcast()) {
                    return;
                }
                eVar.b(u3.b.b(context, intent, eVar.f20262j, eVar.f20261i, eVar.a()));
                return;
            case 8:
                x8.r.f22125g.execute(new x8.q((x8.r) this.f1150b, 2));
                return;
            default:
                PlayerActivity playerActivity = (PlayerActivity) this.f1150b;
                kotlin.jvm.internal.q.g(context, "context");
                kotlin.jvm.internal.q.g(intent, "intent");
                try {
                    Bundle extras = intent.getExtras();
                    PlayerEvent playerEvent = (PlayerEvent) (extras != null ? e2.c.h(extras, "control_type", PlayerEvent.class) : null);
                    if (playerEvent == null) {
                        return;
                    }
                    int i10 = xn.d0.f22275a[playerEvent.ordinal()];
                    if (i10 == 1) {
                        s3.y yVar = playerActivity.f19379b1;
                        if (yVar != null) {
                            yVar.e0(true);
                            return;
                        }
                        return;
                    }
                    if (i10 == 2) {
                        s3.y yVar2 = playerActivity.f19379b1;
                        if (yVar2 != null) {
                            yVar2.e0(false);
                            return;
                        }
                        return;
                    }
                    if (i10 == 3) {
                        s3.y yVar3 = playerActivity.f19379b1;
                        if (yVar3 != null) {
                            yVar3.U(yVar3.W0() + (((long) ji.k.S(10.0f)) * ((long) 1000)));
                            return;
                        }
                        return;
                    }
                    if (i10 != 4) {
                        throw new ad.n(11);
                    }
                    s3.y yVar4 = playerActivity.f19379b1;
                    if (yVar4 != null) {
                        yVar4.U(yVar4.W0() + (-(((long) ji.k.S(10.0f)) * ((long) 1000))));
                        return;
                    }
                    return;
                } catch (Exception e3) {
                    ro.g.y(playerActivity.f19402j2, "broadcastReceiver", e3.getMessage(), e3.getLocalizedMessage());
                    return;
                }
        }
    }

    public z(k1 k1Var) {
        this.f1149a = 3;
        this.f1150b = k1Var;
    }
}
