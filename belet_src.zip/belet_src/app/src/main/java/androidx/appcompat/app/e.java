package androidx.appcompat.app;

import android.content.Context;
import android.content.DialogInterface;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Message;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewStub;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.TextView;
import androidx.core.widget.NestedScrollView;
import java.lang.ref.WeakReference;
import tm.belet.films.R;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class e {
    public final int A;
    public final int B;
    public final int C;
    public final boolean D;
    public final a4.e E;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Context f1034a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final g f1035b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Window f1036c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public CharSequence f1037d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public CharSequence f1038e;
    public AlertController$RecycleListView f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public View f1039g;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public Button f1040i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public CharSequence f1041j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public Message f1042k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public Button f1043l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public CharSequence f1044m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public Message f1045n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public Button f1046o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public CharSequence f1047p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public Message f1048q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public NestedScrollView f1049r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public Drawable f1050s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public ImageView f1051t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public TextView f1052u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public TextView f1053v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public View f1054w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public ListAdapter f1055x;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public final int f1057z;
    public boolean h = false;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public int f1056y = -1;
    public final a F = new a(0, this);

    public e(Context context, g gVar, Window window) {
        this.f1034a = context;
        this.f1035b = gVar;
        this.f1036c = window;
        a4.e eVar = new a4.e();
        eVar.f480b = new WeakReference(gVar);
        this.E = eVar;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(null, g.a.f8274e, R.attr.alertDialogStyle, 0);
        this.f1057z = typedArrayObtainStyledAttributes.getResourceId(0, 0);
        typedArrayObtainStyledAttributes.getResourceId(2, 0);
        this.A = typedArrayObtainStyledAttributes.getResourceId(4, 0);
        typedArrayObtainStyledAttributes.getResourceId(5, 0);
        this.B = typedArrayObtainStyledAttributes.getResourceId(7, 0);
        this.C = typedArrayObtainStyledAttributes.getResourceId(3, 0);
        this.D = typedArrayObtainStyledAttributes.getBoolean(6, true);
        typedArrayObtainStyledAttributes.getDimensionPixelSize(1, 0);
        typedArrayObtainStyledAttributes.recycle();
        gVar.c().f(1);
    }

    public static boolean a(View view) {
        if (view.onCheckIsTextEditor()) {
            return true;
        }
        if (!(view instanceof ViewGroup)) {
            return false;
        }
        ViewGroup viewGroup = (ViewGroup) view;
        int childCount = viewGroup.getChildCount();
        while (childCount > 0) {
            childCount--;
            if (a(viewGroup.getChildAt(childCount))) {
                return true;
            }
        }
        return false;
    }

    public static ViewGroup b(View view, View view2) {
        if (view == null) {
            if (view2 instanceof ViewStub) {
                view2 = ((ViewStub) view2).inflate();
            }
            return (ViewGroup) view2;
        }
        if (view2 != null) {
            ViewParent parent = view2.getParent();
            if (parent instanceof ViewGroup) {
                ((ViewGroup) parent).removeView(view2);
            }
        }
        if (view instanceof ViewStub) {
            view = ((ViewStub) view).inflate();
        }
        return (ViewGroup) view;
    }

    public final void c(int i10, CharSequence charSequence, DialogInterface.OnClickListener onClickListener) {
        Message messageObtainMessage = onClickListener != null ? this.E.obtainMessage(i10, onClickListener) : null;
        if (i10 == -3) {
            this.f1047p = charSequence;
            this.f1048q = messageObtainMessage;
        } else if (i10 == -2) {
            this.f1044m = charSequence;
            this.f1045n = messageObtainMessage;
        } else {
            if (i10 != -1) {
                throw new IllegalArgumentException("Button does not exist");
            }
            this.f1041j = charSequence;
            this.f1042k = messageObtainMessage;
        }
    }
}
