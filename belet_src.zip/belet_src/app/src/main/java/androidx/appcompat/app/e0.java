package androidx.appcompat.app;

import a0.w4;
import android.R;
import android.app.Activity;
import android.app.Dialog;
import android.app.UiModeManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.location.LocationManager;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.util.AndroidRuntimeException;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import androidx.appcompat.widget.ActionBarContextView;
import androidx.appcompat.widget.ActionBarOverlayLayout;
import androidx.appcompat.widget.ActionMenuView;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.ContentFrameLayout;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.h3;
import androidx.appcompat.widget.m1;
import androidx.appcompat.widget.n3;
import androidx.appcompat.widget.o1;
import androidx.appcompat.widget.p1;
import androidx.appcompat.widget.s3;
import androidx.appcompat.widget.u0;
import androidx.appcompat.widget.v3;
import j2.w0;
import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.WeakHashMap;
import okhttp3.internal.ws.WebSocketProtocol;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class e0 extends p implements m.h, LayoutInflater.Factory2 {

    /* JADX INFO: renamed from: v1, reason: collision with root package name */
    public static final j1.i f1058v1 = new j1.i(0);

    /* JADX INFO: renamed from: w1, reason: collision with root package name */
    public static final int[] f1059w1 = {R.attr.windowBackground};

    /* JADX INFO: renamed from: x1, reason: collision with root package name */
    public static final boolean f1060x1 = !"robolectric".equals(Build.FINGERPRINT);
    public final Object A0;
    public q0 B0;
    public l.h C0;
    public CharSequence D0;
    public o1 E0;
    public w4 F0;
    public r G0;
    public l.a H0;
    public ActionBarContextView I0;
    public PopupWindow J0;
    public q K0;
    public boolean N0;
    public ViewGroup O0;
    public TextView P0;
    public View Q0;
    public boolean R0;
    public boolean S0;
    public boolean T0;
    public boolean U0;
    public boolean V0;
    public boolean W0;
    public boolean X0;
    public boolean Y0;
    public d0[] Z0;

    /* JADX INFO: renamed from: a1, reason: collision with root package name */
    public d0 f1061a1;

    /* JADX INFO: renamed from: b1, reason: collision with root package name */
    public boolean f1062b1;

    /* JADX INFO: renamed from: c1, reason: collision with root package name */
    public boolean f1063c1;

    /* JADX INFO: renamed from: d1, reason: collision with root package name */
    public boolean f1064d1;

    /* JADX INFO: renamed from: e1, reason: collision with root package name */
    public boolean f1065e1;

    /* JADX INFO: renamed from: f1, reason: collision with root package name */
    public Configuration f1066f1;

    /* JADX INFO: renamed from: g1, reason: collision with root package name */
    public final int f1067g1;

    /* JADX INFO: renamed from: h1, reason: collision with root package name */
    public int f1068h1;

    /* JADX INFO: renamed from: i1, reason: collision with root package name */
    public int f1069i1;

    /* JADX INFO: renamed from: j1, reason: collision with root package name */
    public boolean f1070j1;

    /* JADX INFO: renamed from: k1, reason: collision with root package name */
    public y f1071k1;

    /* JADX INFO: renamed from: l1, reason: collision with root package name */
    public y f1072l1;

    /* JADX INFO: renamed from: m1, reason: collision with root package name */
    public boolean f1073m1;

    /* JADX INFO: renamed from: n1, reason: collision with root package name */
    public int f1074n1;

    /* JADX INFO: renamed from: p1, reason: collision with root package name */
    public boolean f1076p1;

    /* JADX INFO: renamed from: q1, reason: collision with root package name */
    public Rect f1077q1;

    /* JADX INFO: renamed from: r1, reason: collision with root package name */
    public Rect f1078r1;

    /* JADX INFO: renamed from: s1, reason: collision with root package name */
    public j0 f1079s1;

    /* JADX INFO: renamed from: t1, reason: collision with root package name */
    public OnBackInvokedDispatcher f1080t1;

    /* JADX INFO: renamed from: u1, reason: collision with root package name */
    public OnBackInvokedCallback f1081u1;

    /* JADX INFO: renamed from: w0, reason: collision with root package name */
    public final Object f1082w0;

    /* JADX INFO: renamed from: x0, reason: collision with root package name */
    public final Context f1083x0;

    /* JADX INFO: renamed from: y0, reason: collision with root package name */
    public Window f1084y0;

    /* JADX INFO: renamed from: z0, reason: collision with root package name */
    public x f1085z0;
    public w0 L0 = null;
    public final boolean M0 = true;

    /* JADX INFO: renamed from: o1, reason: collision with root package name */
    public final q f1075o1 = new q(this, 0);

    public e0(Context context, Window window, k kVar, Object obj) {
        j jVar = null;
        this.f1067g1 = -100;
        this.f1083x0 = context;
        this.A0 = kVar;
        this.f1082w0 = obj;
        if (obj instanceof Dialog) {
            while (context != null) {
                if (!(context instanceof j)) {
                    if (!(context instanceof ContextWrapper)) {
                        break;
                    } else {
                        context = ((ContextWrapper) context).getBaseContext();
                    }
                } else {
                    jVar = (j) context;
                    break;
                }
            }
            if (jVar != null) {
                this.f1067g1 = ((e0) jVar.A()).f1067g1;
            }
        }
        if (this.f1067g1 == -100) {
            String name = this.f1082w0.getClass().getName();
            j1.i iVar = f1058v1;
            Integer num = (Integer) iVar.get(name);
            if (num != null) {
                this.f1067g1 = num.intValue();
                iVar.remove(this.f1082w0.getClass().getName());
            }
        }
        if (window != null) {
            n(window);
        }
        androidx.appcompat.widget.y.d();
    }

    public static e2.e o(Context context) {
        e2.e eVar;
        e2.e eVarB;
        int i10 = Build.VERSION.SDK_INT;
        if (i10 >= 33 || (eVar = p.Y) == null) {
            return null;
        }
        e2.g gVar = eVar.f7310a;
        e2.e eVarY = y(context.getApplicationContext().getResources().getConfiguration());
        int i11 = 0;
        if (i10 < 24) {
            eVarB = gVar.isEmpty() ? e2.e.f7309b : e2.e.b(t.b(gVar.get(0)));
        } else if (gVar.isEmpty()) {
            eVarB = e2.e.f7309b;
        } else {
            LinkedHashSet linkedHashSet = new LinkedHashSet();
            while (i11 < eVarY.f7310a.size() + gVar.size()) {
                Locale locale = i11 < gVar.size() ? gVar.get(i11) : eVarY.f7310a.get(i11 - gVar.size());
                if (locale != null) {
                    linkedHashSet.add(locale);
                }
                i11++;
            }
            eVarB = e2.e.a((Locale[]) linkedHashSet.toArray(new Locale[linkedHashSet.size()]));
        }
        return eVarB.f7310a.isEmpty() ? eVarY : eVarB;
    }

    public static Configuration s(Context context, int i10, e2.e eVar, Configuration configuration, boolean z5) {
        int i11;
        if (i10 == 1) {
            i11 = 16;
        } else if (i10 != 2) {
            i11 = z5 ? 0 : context.getApplicationContext().getResources().getConfiguration().uiMode & 48;
        } else {
            i11 = 32;
        }
        Configuration configuration2 = new Configuration();
        configuration2.fontScale = 0.0f;
        if (configuration != null) {
            configuration2.setTo(configuration);
        }
        configuration2.uiMode = i11 | (configuration2.uiMode & (-49));
        if (eVar != null) {
            e2.g gVar = eVar.f7310a;
            if (Build.VERSION.SDK_INT >= 24) {
                u.d(configuration2, eVar);
                return configuration2;
            }
            configuration2.setLocale(gVar.get(0));
            configuration2.setLayoutDirection(gVar.get(0));
        }
        return configuration2;
    }

    public static e2.e y(Configuration configuration) {
        return Build.VERSION.SDK_INT >= 24 ? u.b(configuration) : e2.e.b(t.b(configuration.locale));
    }

    public final void A() {
        v();
        if (this.T0 && this.B0 == null) {
            Object obj = this.f1082w0;
            if (obj instanceof Activity) {
                this.B0 = new q0((Activity) obj, this.U0);
            } else if (obj instanceof Dialog) {
                this.B0 = new q0((Dialog) obj);
            }
            q0 q0Var = this.B0;
            if (q0Var != null) {
                q0Var.D(this.f1076p1);
            }
        }
    }

    public final void B(int i10) {
        this.f1074n1 = (1 << i10) | this.f1074n1;
        if (this.f1073m1) {
            return;
        }
        View decorView = this.f1084y0.getDecorView();
        WeakHashMap weakHashMap = j2.q0.f12703a;
        decorView.postOnAnimation(this.f1075o1);
        this.f1073m1 = true;
    }

    public final int C(Context context, int i10) {
        if (i10 != -100) {
            if (i10 != -1) {
                if (i10 != 0) {
                    if (i10 != 1 && i10 != 2) {
                        if (i10 != 3) {
                            throw new IllegalStateException("Unknown value set for night mode. Please use one of the MODE_NIGHT values from AppCompatDelegate.");
                        }
                        if (this.f1072l1 == null) {
                            this.f1072l1 = new y(this, context);
                        }
                        return this.f1072l1.d1();
                    }
                } else if (((UiModeManager) context.getApplicationContext().getSystemService("uimode")).getNightMode() != 0) {
                    return x(context).d1();
                }
            }
            return i10;
        }
        return -1;
    }

    public final boolean D() {
        p1 p1Var;
        h3 h3Var;
        boolean z5 = this.f1062b1;
        this.f1062b1 = false;
        d0 d0VarZ = z(0);
        if (!d0VarZ.f1030m) {
            l.a aVar = this.H0;
            if (aVar != null) {
                aVar.a();
                return true;
            }
            A();
            q0 q0Var = this.B0;
            if (q0Var == null || (p1Var = q0Var.f1123j) == null || (h3Var = ((n3) p1Var).f1381a.f1233b1) == null || h3Var.X == null) {
                return false;
            }
            h3 h3Var2 = ((n3) p1Var).f1381a.f1233b1;
            m.l lVar = h3Var2 == null ? null : h3Var2.X;
            if (lVar != null) {
                lVar.collapseActionView();
            }
        } else if (!z5) {
            r(d0VarZ, true);
            return true;
        }
        return true;
    }

    /* JADX WARN: Code duplicated, block: B:100:0x01d2  */
    /* JADX WARN: Code duplicated, block: B:105:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Code restructure failed: missing block: B:87:0x0175, code lost:
    
        if (r2.f14713s0.getCount() > 0) goto L88;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void E(androidx.appcompat.app.d0 r18, android.view.KeyEvent r19) {
        /*
            Method dump skipped, instruction units count: 473
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.app.e0.E(androidx.appcompat.app.d0, android.view.KeyEvent):void");
    }

    public final boolean F(d0 d0Var, int i10, KeyEvent keyEvent) {
        m.j jVar;
        if (keyEvent.isSystem()) {
            return false;
        }
        if ((d0Var.f1028k || G(d0Var, keyEvent)) && (jVar = d0Var.h) != null) {
            return jVar.performShortcut(i10, keyEvent, 1);
        }
        return false;
    }

    /* JADX WARN: Code duplicated, block: B:59:0x00d0  */
    /* JADX WARN: Code duplicated, block: B:64:0x00da  */
    /* JADX WARN: Code duplicated, block: B:68:0x00f8  */
    /* JADX WARN: Code duplicated, block: B:71:0x00fd A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:72:0x00ff  */
    /* JADX WARN: Code duplicated, block: B:79:0x0114  */
    public final boolean G(d0 d0Var, KeyEvent keyEvent) {
        m.j jVar;
        o1 o1Var;
        o1 o1Var2;
        Resources.Theme themeNewTheme;
        o1 o1Var3;
        o1 o1Var4;
        if (!this.f1065e1) {
            boolean z5 = d0Var.f1028k;
            int i10 = d0Var.f1020a;
            if (z5) {
                return true;
            }
            d0 d0Var2 = this.f1061a1;
            if (d0Var2 != null && d0Var2 != d0Var) {
                r(d0Var2, false);
            }
            Window.Callback callback = this.f1084y0.getCallback();
            if (callback != null) {
                d0Var.f1025g = callback.onCreatePanelView(i10);
            }
            boolean z6 = i10 == 0 || i10 == 108;
            if (z6 && (o1Var4 = this.E0) != null) {
                ActionBarOverlayLayout actionBarOverlayLayout = (ActionBarOverlayLayout) o1Var4;
                actionBarOverlayLayout.k();
                ((n3) actionBarOverlayLayout.u0).f1390l = true;
            }
            if (d0Var.f1025g == null) {
                m.j jVar2 = d0Var.h;
                if (jVar2 == null || d0Var.f1032o) {
                    if (jVar2 == null) {
                        Context context = this.f1083x0;
                        if ((i10 == 0 || i10 == 108) && this.E0 != null) {
                            TypedValue typedValue = new TypedValue();
                            Resources.Theme theme = context.getTheme();
                            theme.resolveAttribute(tm.belet.films.R.attr.actionBarTheme, typedValue, true);
                            if (typedValue.resourceId != 0) {
                                themeNewTheme = context.getResources().newTheme();
                                themeNewTheme.setTo(theme);
                                themeNewTheme.applyStyle(typedValue.resourceId, true);
                                themeNewTheme.resolveAttribute(tm.belet.films.R.attr.actionBarWidgetTheme, typedValue, true);
                            } else {
                                theme.resolveAttribute(tm.belet.films.R.attr.actionBarWidgetTheme, typedValue, true);
                                themeNewTheme = null;
                            }
                            if (typedValue.resourceId != 0) {
                                if (themeNewTheme == null) {
                                    themeNewTheme = context.getResources().newTheme();
                                    themeNewTheme.setTo(theme);
                                }
                                themeNewTheme.applyStyle(typedValue.resourceId, true);
                            }
                            if (themeNewTheme != null) {
                                l.c cVar = new l.c(context, 0);
                                cVar.getTheme().setTo(themeNewTheme);
                                context = cVar;
                            }
                        }
                        m.j jVar3 = new m.j(context);
                        jVar3.f14720r0 = this;
                        m.j jVar4 = d0Var.h;
                        if (jVar3 != jVar4) {
                            if (jVar4 != null) {
                                jVar4.r(d0Var.f1026i);
                            }
                            d0Var.h = jVar3;
                            m.f fVar = d0Var.f1026i;
                            if (fVar != null) {
                                jVar3.b(fVar, jVar3.f14719e);
                            }
                        }
                        if (d0Var.h != null) {
                            if (z6 && (o1Var2 = this.E0) != null) {
                                if (this.F0 == null) {
                                    this.F0 = new w4(1, this);
                                }
                                ((ActionBarOverlayLayout) o1Var2).l(d0Var.h, this.F0);
                            }
                            d0Var.h.w();
                            if (callback.onCreatePanelMenu(i10, d0Var.h)) {
                                d0Var.f1032o = false;
                            } else {
                                jVar = d0Var.h;
                                if (jVar != null) {
                                    if (jVar != null) {
                                        jVar.r(d0Var.f1026i);
                                    }
                                    d0Var.h = null;
                                }
                                if (z6 && (o1Var = this.E0) != null) {
                                    ((ActionBarOverlayLayout) o1Var).l(null, this.F0);
                                }
                            }
                        }
                    } else {
                        if (z6) {
                            if (this.F0 == null) {
                                this.F0 = new w4(1, this);
                            }
                            ((ActionBarOverlayLayout) o1Var2).l(d0Var.h, this.F0);
                        }
                        d0Var.h.w();
                        if (callback.onCreatePanelMenu(i10, d0Var.h)) {
                            jVar = d0Var.h;
                            if (jVar != null) {
                                if (jVar != null) {
                                    jVar.r(d0Var.f1026i);
                                }
                                d0Var.h = null;
                            }
                            if (z6) {
                                ((ActionBarOverlayLayout) o1Var).l(null, this.F0);
                            }
                        } else {
                            d0Var.f1032o = false;
                        }
                    }
                }
                d0Var.h.w();
                Bundle bundle = d0Var.f1033p;
                if (bundle != null) {
                    d0Var.h.s(bundle);
                    d0Var.f1033p = null;
                }
                if (!callback.onPreparePanel(0, d0Var.f1025g, d0Var.h)) {
                    if (z6 && (o1Var3 = this.E0) != null) {
                        ((ActionBarOverlayLayout) o1Var3).l(null, this.F0);
                    }
                    d0Var.h.v();
                    return false;
                }
                d0Var.h.setQwertyMode(KeyCharacterMap.load(keyEvent != null ? keyEvent.getDeviceId() : -1).getKeyboardType() != 1);
                d0Var.h.v();
            }
            d0Var.f1028k = true;
            d0Var.f1029l = false;
            this.f1061a1 = d0Var;
            return true;
        }
        return false;
    }

    public final void H() {
        if (this.N0) {
            throw new AndroidRuntimeException("Window feature must be requested before adding content");
        }
    }

    public final void I() {
        OnBackInvokedCallback onBackInvokedCallback;
        if (Build.VERSION.SDK_INT >= 33) {
            boolean z5 = false;
            if (this.f1080t1 != null && (z(0).f1030m || this.H0 != null)) {
                z5 = true;
            }
            if (z5 && this.f1081u1 == null) {
                this.f1081u1 = w.b(this.f1080t1, this);
            } else {
                if (z5 || (onBackInvokedCallback = this.f1081u1) == null) {
                    return;
                }
                w.c(this.f1080t1, onBackInvokedCallback);
                this.f1081u1 = null;
            }
        }
    }

    @Override // androidx.appcompat.app.p
    public final void a() {
        LayoutInflater layoutInflaterFrom = LayoutInflater.from(this.f1083x0);
        if (layoutInflaterFrom.getFactory() == null) {
            layoutInflaterFrom.setFactory2(this);
        } else {
            if (layoutInflaterFrom.getFactory2() instanceof e0) {
                return;
            }
            Log.i("AppCompatDelegate", "The Activity's LayoutInflater already has a Factory installed so we can not install AppCompat's");
        }
    }

    @Override // androidx.appcompat.app.p
    public final void c() throws IllegalAccessException {
        String strC;
        this.f1063c1 = true;
        m(false, true);
        w();
        Object obj = this.f1082w0;
        if (obj instanceof Activity) {
            try {
                Activity activity = (Activity) obj;
                try {
                    strC = v1.c.c(activity, activity.getComponentName());
                } catch (PackageManager.NameNotFoundException e3) {
                    throw new IllegalArgumentException(e3);
                }
            } catch (IllegalArgumentException unused) {
                strC = null;
            }
            if (strC != null) {
                q0 q0Var = this.B0;
                if (q0Var == null) {
                    this.f1076p1 = true;
                } else {
                    q0Var.D(true);
                }
            }
            synchronized (p.u0) {
                p.e(this);
                p.f1115t0.add(new WeakReference(this));
            }
        }
        this.f1066f1 = new Configuration(this.f1083x0.getResources().getConfiguration());
        this.f1064d1 = true;
    }

    /* JADX WARN: Code duplicated, block: B:22:0x004d  */
    @Override // androidx.appcompat.app.p
    public final void d() {
        if (this.f1082w0 instanceof Activity) {
            synchronized (p.u0) {
                p.e(this);
            }
        }
        if (this.f1073m1) {
            this.f1084y0.getDecorView().removeCallbacks(this.f1075o1);
        }
        this.f1065e1 = true;
        if (this.f1067g1 != -100) {
            Object obj = this.f1082w0;
            if ((obj instanceof Activity) && ((Activity) obj).isChangingConfigurations()) {
                f1058v1.put(this.f1082w0.getClass().getName(), Integer.valueOf(this.f1067g1));
            } else {
                f1058v1.remove(this.f1082w0.getClass().getName());
            }
        } else {
            f1058v1.remove(this.f1082w0.getClass().getName());
        }
        y yVar = this.f1071k1;
        if (yVar != null) {
            yVar.a1();
        }
        y yVar2 = this.f1072l1;
        if (yVar2 != null) {
            yVar2.a1();
        }
    }

    @Override // androidx.appcompat.app.p
    public final boolean f(int i10) {
        if (i10 == 8) {
            Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR id when requesting this feature.");
            i10 = 108;
        } else if (i10 == 9) {
            Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR_OVERLAY id when requesting this feature.");
            i10 = 109;
        }
        if (this.X0 && i10 == 108) {
            return false;
        }
        if (this.T0 && i10 == 1) {
            this.T0 = false;
        }
        if (i10 == 1) {
            H();
            this.X0 = true;
            return true;
        }
        if (i10 == 2) {
            H();
            this.R0 = true;
            return true;
        }
        if (i10 == 5) {
            H();
            this.S0 = true;
            return true;
        }
        if (i10 == 10) {
            H();
            this.V0 = true;
            return true;
        }
        if (i10 == 108) {
            H();
            this.T0 = true;
            return true;
        }
        if (i10 != 109) {
            return this.f1084y0.requestFeature(i10);
        }
        H();
        this.U0 = true;
        return true;
    }

    @Override // androidx.appcompat.app.p
    public final void g(int i10) {
        v();
        ViewGroup viewGroup = (ViewGroup) this.O0.findViewById(R.id.content);
        viewGroup.removeAllViews();
        LayoutInflater.from(this.f1083x0).inflate(i10, viewGroup);
        this.f1085z0.a(this.f1084y0.getCallback());
    }

    /* JADX WARN: Code restructure failed: missing block: B:19:0x0048, code lost:
    
        if (r6.i() != false) goto L20;
     */
    @Override // m.h
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void h(m.j r6) {
        /*
            Method dump skipped, instruction units count: 241
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.app.e0.h(m.j):void");
    }

    @Override // androidx.appcompat.app.p
    public final void i(View view) {
        v();
        ViewGroup viewGroup = (ViewGroup) this.O0.findViewById(R.id.content);
        viewGroup.removeAllViews();
        viewGroup.addView(view);
        this.f1085z0.a(this.f1084y0.getCallback());
    }

    /* JADX WARN: Code duplicated, block: B:20:0x002a  */
    @Override // m.h
    public final boolean j(m.j jVar, MenuItem menuItem) {
        d0 d0Var;
        Window.Callback callback = this.f1084y0.getCallback();
        if (callback != null && !this.f1065e1) {
            m.j jVarK = jVar.k();
            d0[] d0VarArr = this.Z0;
            int length = d0VarArr != null ? d0VarArr.length : 0;
            for (int i10 = 0; i10 < length; i10++) {
                d0Var = d0VarArr[i10];
                if (d0Var != null && d0Var.h == jVarK) {
                    if (d0Var != null) {
                        return callback.onMenuItemSelected(d0Var.f1020a, menuItem);
                    }
                }
            }
            d0Var = null;
            if (d0Var != null) {
                return callback.onMenuItemSelected(d0Var.f1020a, menuItem);
            }
        }
        return false;
    }

    @Override // androidx.appcompat.app.p
    public final void k(View view, ViewGroup.LayoutParams layoutParams) {
        v();
        ViewGroup viewGroup = (ViewGroup) this.O0.findViewById(R.id.content);
        viewGroup.removeAllViews();
        viewGroup.addView(view, layoutParams);
        this.f1085z0.a(this.f1084y0.getCallback());
    }

    @Override // androidx.appcompat.app.p
    public final void l(CharSequence charSequence) {
        this.D0 = charSequence;
        o1 o1Var = this.E0;
        if (o1Var != null) {
            o1Var.setWindowTitle(charSequence);
            return;
        }
        q0 q0Var = this.B0;
        if (q0Var == null) {
            TextView textView = this.P0;
            if (textView != null) {
                textView.setText(charSequence);
                return;
            }
            return;
        }
        n3 n3Var = (n3) q0Var.f1123j;
        if (n3Var.f1386g) {
            return;
        }
        Toolbar toolbar = n3Var.f1381a;
        n3Var.h = charSequence;
        if ((n3Var.f1382b & 8) != 0) {
            toolbar.setTitle(charSequence);
            if (n3Var.f1386g) {
                j2.q0.o(toolbar.getRootView(), charSequence);
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:72:0x0100  */
    /* JADX WARN: Multi-variable type inference failed */
    public final boolean m(boolean z5, boolean z6) throws IllegalAccessException {
        int i10;
        boolean z9;
        boolean z10;
        boolean z11;
        Object obj;
        int i11;
        if (this.f1065e1) {
            return false;
        }
        int i12 = this.f1067g1;
        if (i12 == -100) {
            i12 = p.X;
        }
        Context context = this.f1083x0;
        int iC = C(context, i12);
        int i13 = Build.VERSION.SDK_INT;
        Object obj2 = null;
        e2.e eVarO = i13 < 33 ? o(context) : null;
        if (!z6 && eVarO != null) {
            eVarO = y(context.getResources().getConfiguration());
        }
        Configuration configurationS = s(context, iC, eVarO, null, false);
        boolean z12 = this.f1070j1;
        Object obj3 = this.f1082w0;
        if (z12 || !(obj3 instanceof Activity)) {
            this.f1070j1 = true;
            i10 = this.f1069i1;
        } else {
            PackageManager packageManager = context.getPackageManager();
            if (packageManager == null) {
                i10 = 0;
            } else {
                if (i13 >= 29) {
                    i11 = 269221888;
                } else {
                    i11 = i13 >= 24 ? 786432 : 0;
                }
                try {
                    ActivityInfo activityInfo = packageManager.getActivityInfo(new ComponentName(context, obj3.getClass()), i11);
                    if (activityInfo != null) {
                        this.f1069i1 = activityInfo.configChanges;
                    }
                } catch (PackageManager.NameNotFoundException e3) {
                    Log.d("AppCompatDelegate", "Exception while getting ActivityInfo", e3);
                    this.f1069i1 = 0;
                }
                this.f1070j1 = true;
                i10 = this.f1069i1;
            }
        }
        Configuration configuration = this.f1066f1;
        if (configuration == null) {
            configuration = context.getResources().getConfiguration();
        }
        int i14 = configuration.uiMode & 48;
        int i15 = configurationS.uiMode & 48;
        e2.e eVarY = y(configuration);
        e2.e eVarY2 = eVarO == null ? null : y(configurationS);
        int i16 = i14 != i15 ? 512 : 0;
        if (eVarY2 != null && !eVarY.equals(eVarY2)) {
            i16 |= 8196;
        }
        if (((~i10) & i16) != 0 && z5 && this.f1063c1 && ((f1060x1 || this.f1064d1) && (obj3 instanceof Activity))) {
            Activity activity = (Activity) obj3;
            if (activity.isChild()) {
                z9 = false;
            } else {
                int i17 = Build.VERSION.SDK_INT;
                if (i17 >= 31 && (i16 & 8192) != 0) {
                    activity.getWindow().getDecorView().setLayoutDirection(configurationS.getLayoutDirection());
                }
                if (i17 >= 28) {
                    activity.recreate();
                } else {
                    new Handler(activity.getMainLooper()).post(new t3.d(5, activity));
                }
                z9 = true;
            }
        } else {
            z9 = false;
        }
        if (z9 || i16 == 0) {
            z10 = z9;
        } else {
            boolean z13 = (i10 & i16) == i16;
            Resources resources = context.getResources();
            Configuration configuration2 = new Configuration(resources.getConfiguration());
            configuration2.uiMode = (resources.getConfiguration().uiMode & (-49)) | i15;
            if (eVarY2 != null) {
                e2.g gVar = eVarY2.f7310a;
                if (Build.VERSION.SDK_INT >= 24) {
                    u.d(configuration2, eVarY2);
                } else {
                    configuration2.setLocale(gVar.get(0));
                    configuration2.setLayoutDirection(gVar.get(0));
                }
            }
            resources.updateConfiguration(configuration2, null);
            int i18 = Build.VERSION.SDK_INT;
            if (i18 < 26 && i18 < 28) {
                if (i18 >= 24) {
                    if (!tc.b.h) {
                        try {
                            Field declaredField = Resources.class.getDeclaredField("mResourcesImpl");
                            tc.b.f19178g = declaredField;
                            declaredField.setAccessible(true);
                        } catch (NoSuchFieldException e10) {
                            Log.e("ResourcesFlusher", "Could not retrieve Resources#mResourcesImpl field", e10);
                        }
                        tc.b.h = true;
                    }
                    Field field = tc.b.f19178g;
                    if (field != null) {
                        try {
                            obj = field.get(resources);
                        } catch (IllegalAccessException e11) {
                            Log.e("ResourcesFlusher", "Could not retrieve value from Resources#mResourcesImpl", e11);
                            obj = null;
                        }
                        if (obj != null) {
                            if (!tc.b.f19174b) {
                                try {
                                    Field declaredField2 = obj.getClass().getDeclaredField("mDrawableCache");
                                    tc.b.f19173a = declaredField2;
                                    declaredField2.setAccessible(true);
                                } catch (NoSuchFieldException e12) {
                                    Log.e("ResourcesFlusher", "Could not retrieve ResourcesImpl#mDrawableCache field", e12);
                                }
                                tc.b.f19174b = true;
                            }
                            Field field2 = tc.b.f19173a;
                            if (field2 != null) {
                                try {
                                    obj2 = field2.get(obj);
                                } catch (IllegalAccessException e13) {
                                    Log.e("ResourcesFlusher", "Could not retrieve value from ResourcesImpl#mDrawableCache", e13);
                                }
                            }
                            if (obj2 != null) {
                                tc.b.y(obj2);
                            }
                        }
                    }
                } else {
                    if (!tc.b.f19174b) {
                        try {
                            Field declaredField3 = Resources.class.getDeclaredField("mDrawableCache");
                            tc.b.f19173a = declaredField3;
                            declaredField3.setAccessible(true);
                        } catch (NoSuchFieldException e14) {
                            Log.e("ResourcesFlusher", "Could not retrieve Resources#mDrawableCache field", e14);
                        }
                        tc.b.f19174b = true;
                    }
                    Field field3 = tc.b.f19173a;
                    if (field3 != null) {
                        try {
                            obj2 = field3.get(resources);
                        } catch (IllegalAccessException e15) {
                            Log.e("ResourcesFlusher", "Could not retrieve value from Resources#mDrawableCache", e15);
                        }
                    }
                    if (obj2 != null) {
                        tc.b.y(obj2);
                    }
                }
            }
            int i19 = this.f1068h1;
            if (i19 != 0) {
                context.setTheme(i19);
                z11 = true;
                context.getTheme().applyStyle(this.f1068h1, true);
            } else {
                z11 = true;
            }
            if (z13 && (obj3 instanceof Activity)) {
                Activity activity2 = (Activity) obj3;
                if (activity2 instanceof androidx.lifecycle.v) {
                    if (((androidx.lifecycle.v) activity2).u().f2063d.compareTo(androidx.lifecycle.p.Y) >= 0) {
                        activity2.onConfigurationChanged(configuration2);
                    }
                } else if (this.f1064d1 && !this.f1065e1) {
                    activity2.onConfigurationChanged(configuration2);
                }
            }
            z10 = z11;
        }
        if (eVarY2 != null) {
            e2.e eVarY3 = y(context.getResources().getConfiguration());
            if (Build.VERSION.SDK_INT >= 24) {
                u.c(eVarY3);
            } else {
                Locale.setDefault(eVarY3.f7310a.get(0));
            }
        }
        if (i12 == 0) {
            x(context).v1();
        } else {
            y yVar = this.f1071k1;
            if (yVar != null) {
                yVar.a1();
            }
        }
        if (i12 == 3) {
            if (this.f1072l1 == null) {
                this.f1072l1 = new y(this, context);
            }
            this.f1072l1.v1();
        } else {
            y yVar2 = this.f1072l1;
            if (yVar2 != null) {
                yVar2.a1();
            }
        }
        return z10;
    }

    /* JADX WARN: Code duplicated, block: B:35:0x0074  */
    public final void n(Window window) {
        Drawable drawableG;
        OnBackInvokedDispatcher onBackInvokedDispatcher;
        OnBackInvokedCallback onBackInvokedCallback;
        int resourceId;
        if (this.f1084y0 != null) {
            throw new IllegalStateException("AppCompat has already installed itself into the Window");
        }
        Window.Callback callback = window.getCallback();
        if (callback instanceof x) {
            throw new IllegalStateException("AppCompat has already installed itself into the Window");
        }
        x xVar = new x(this, callback);
        this.f1085z0 = xVar;
        window.setCallback(xVar);
        Context context = this.f1083x0;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes((AttributeSet) null, f1059w1);
        if (!typedArrayObtainStyledAttributes.hasValue(0) || (resourceId = typedArrayObtainStyledAttributes.getResourceId(0, 0)) == 0) {
            drawableG = null;
        } else {
            androidx.appcompat.widget.y yVarA = androidx.appcompat.widget.y.a();
            synchronized (yVarA) {
                drawableG = yVarA.f1491a.g(context, resourceId, true);
            }
        }
        if (drawableG != null) {
            window.setBackgroundDrawable(drawableG);
        }
        typedArrayObtainStyledAttributes.recycle();
        this.f1084y0 = window;
        if (Build.VERSION.SDK_INT < 33 || (onBackInvokedDispatcher = this.f1080t1) != null) {
            return;
        }
        Object obj = this.f1082w0;
        if (onBackInvokedDispatcher != null && (onBackInvokedCallback = this.f1081u1) != null) {
            w.c(onBackInvokedDispatcher, onBackInvokedCallback);
            this.f1081u1 = null;
        }
        if (obj instanceof Activity) {
            Activity activity = (Activity) obj;
            if (activity.getWindow() != null) {
                this.f1080t1 = w.a(activity);
            } else {
                this.f1080t1 = null;
            }
        } else {
            this.f1080t1 = null;
        }
        I();
    }

    @Override // android.view.LayoutInflater.Factory2
    public final View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        View h0Var;
        View view2 = null;
        if (this.f1079s1 == null) {
            int[] iArr = g.a.f8277j;
            Context context2 = this.f1083x0;
            TypedArray typedArrayObtainStyledAttributes = context2.obtainStyledAttributes(iArr);
            String string = typedArrayObtainStyledAttributes.getString(116);
            typedArrayObtainStyledAttributes.recycle();
            if (string == null) {
                this.f1079s1 = new j0();
            } else {
                try {
                    this.f1079s1 = (j0) context2.getClassLoader().loadClass(string).getDeclaredConstructor(null).newInstance(null);
                } catch (Throwable th2) {
                    Log.i("AppCompatDelegate", "Failed to instantiate custom view inflater " + string + ". Falling back to default.", th2);
                    this.f1079s1 = new j0();
                }
            }
        }
        j0 j0Var = this.f1079s1;
        int i10 = s3.f1432a;
        j0Var.getClass();
        TypedArray typedArrayObtainStyledAttributes2 = context.obtainStyledAttributes(attributeSet, g.a.f8292y, 0, 0);
        byte b10 = 4;
        int resourceId = typedArrayObtainStyledAttributes2.getResourceId(4, 0);
        if (resourceId != 0) {
            Log.i("AppCompatViewInflater", "app:theme is now deprecated. Please move to using android:theme instead.");
        }
        typedArrayObtainStyledAttributes2.recycle();
        Context cVar = (resourceId == 0 || ((context instanceof l.c) && ((l.c) context).f13988a == resourceId)) ? context : new l.c(context, resourceId);
        str.getClass();
        switch (str.hashCode()) {
            case -1946472170:
                b10 = !str.equals("RatingBar") ? (byte) -1 : (byte) 0;
                break;
            case -1455429095:
                b10 = !str.equals("CheckedTextView") ? (byte) -1 : (byte) 1;
                break;
            case -1346021293:
                b10 = !str.equals("MultiAutoCompleteTextView") ? (byte) -1 : (byte) 2;
                break;
            case -938935918:
                b10 = !str.equals("TextView") ? (byte) -1 : (byte) 3;
                break;
            case -937446323:
                if (!str.equals("ImageButton")) {
                    b10 = -1;
                }
                break;
            case -658531749:
                b10 = !str.equals("SeekBar") ? (byte) -1 : (byte) 5;
                break;
            case -339785223:
                b10 = !str.equals("Spinner") ? (byte) -1 : (byte) 6;
                break;
            case 776382189:
                b10 = !str.equals("RadioButton") ? (byte) -1 : (byte) 7;
                break;
            case 799298502:
                b10 = !str.equals("ToggleButton") ? (byte) -1 : (byte) 8;
                break;
            case 1125864064:
                b10 = !str.equals("ImageView") ? (byte) -1 : (byte) 9;
                break;
            case 1413872058:
                b10 = !str.equals("AutoCompleteTextView") ? (byte) -1 : (byte) 10;
                break;
            case 1601505219:
                b10 = !str.equals("CheckBox") ? (byte) -1 : (byte) 11;
                break;
            case 1666676343:
                b10 = !str.equals("EditText") ? (byte) -1 : (byte) 12;
                break;
            case 2001146706:
                b10 = !str.equals("Button") ? (byte) -1 : (byte) 13;
                break;
            default:
                b10 = -1;
                break;
        }
        switch (b10) {
            case 0:
                h0Var = new androidx.appcompat.widget.h0(cVar, attributeSet);
                break;
            case 1:
                h0Var = new androidx.appcompat.widget.w(cVar, attributeSet);
                break;
            case 2:
                h0Var = new androidx.appcompat.widget.d0(cVar, attributeSet);
                break;
            case 3:
                h0Var = j0Var.e(cVar, attributeSet);
                break;
            case 4:
                h0Var = new androidx.appcompat.widget.b0(cVar, attributeSet, tm.belet.films.R.attr.imageButtonStyle);
                break;
            case 5:
                h0Var = new androidx.appcompat.widget.j0(cVar, attributeSet);
                break;
            case 6:
                h0Var = new u0(cVar, attributeSet);
                break;
            case 7:
                h0Var = j0Var.d(cVar, attributeSet);
                break;
            case 8:
                h0Var = new m1(cVar, attributeSet);
                break;
            case 9:
                h0Var = new AppCompatImageView(cVar, attributeSet);
                break;
            case 10:
                h0Var = j0Var.a(cVar, attributeSet);
                break;
            case ue.r.NETWORK_CLIENT_ERROR_REASON_FIELD_NUMBER /* 11 */:
                h0Var = j0Var.c(cVar, attributeSet);
                break;
            case ue.r.CUSTOM_ATTRIBUTES_FIELD_NUMBER /* 12 */:
                h0Var = new AppCompatEditText(cVar, attributeSet);
                break;
            case ue.r.PERF_SESSIONS_FIELD_NUMBER /* 13 */:
                h0Var = j0Var.b(cVar, attributeSet);
                break;
            default:
                h0Var = null;
                break;
        }
        if (h0Var != null || context == cVar) {
            view2 = h0Var;
        } else {
            Object[] objArr = j0Var.f1101a;
            if (str.equals("view")) {
                str = attributeSet.getAttributeValue(null, "class");
            }
            try {
                objArr[0] = cVar;
                objArr[1] = attributeSet;
                if (-1 == str.indexOf(46)) {
                    int i11 = 0;
                    while (true) {
                        String[] strArr = j0.f1100g;
                        if (i11 < 3) {
                            View viewF = j0Var.f(cVar, str, strArr[i11]);
                            if (viewF != null) {
                                objArr[0] = null;
                                objArr[1] = null;
                                view2 = viewF;
                            } else {
                                i11++;
                            }
                        } else {
                            objArr[0] = null;
                            objArr[1] = null;
                        }
                    }
                } else {
                    View viewF2 = j0Var.f(cVar, str, null);
                    objArr[0] = null;
                    objArr[1] = null;
                    view2 = viewF2;
                }
            } catch (Exception unused) {
                objArr[0] = view2;
                objArr[1] = view2;
            } catch (Throwable th3) {
                objArr[0] = view2;
                objArr[1] = view2;
                throw th3;
            }
        }
        if (view2 != null) {
            Context context3 = view2.getContext();
            if ((context3 instanceof ContextWrapper) && view2.hasOnClickListeners()) {
                TypedArray typedArrayObtainStyledAttributes3 = context3.obtainStyledAttributes(attributeSet, j0.f1097c);
                String string2 = typedArrayObtainStyledAttributes3.getString(0);
                if (string2 != null) {
                    view2.setOnClickListener(new i0(view2, string2));
                }
                typedArrayObtainStyledAttributes3.recycle();
            }
            if (Build.VERSION.SDK_INT <= 28) {
                TypedArray typedArrayObtainStyledAttributes4 = cVar.obtainStyledAttributes(attributeSet, j0.f1098d);
                if (typedArrayObtainStyledAttributes4.hasValue(0)) {
                    boolean z5 = typedArrayObtainStyledAttributes4.getBoolean(0, false);
                    WeakHashMap weakHashMap = j2.q0.f12703a;
                    new j2.c0(tm.belet.films.R.id.tag_accessibility_heading, Boolean.class, 0, 28, 3).f(view2, Boolean.valueOf(z5));
                }
                typedArrayObtainStyledAttributes4.recycle();
                TypedArray typedArrayObtainStyledAttributes5 = cVar.obtainStyledAttributes(attributeSet, j0.f1099e);
                if (typedArrayObtainStyledAttributes5.hasValue(0)) {
                    j2.q0.o(view2, typedArrayObtainStyledAttributes5.getString(0));
                }
                typedArrayObtainStyledAttributes5.recycle();
                TypedArray typedArrayObtainStyledAttributes6 = cVar.obtainStyledAttributes(attributeSet, j0.f);
                if (typedArrayObtainStyledAttributes6.hasValue(0)) {
                    boolean z6 = typedArrayObtainStyledAttributes6.getBoolean(0, false);
                    WeakHashMap weakHashMap2 = j2.q0.f12703a;
                    new j2.c0(tm.belet.films.R.id.tag_screen_reader_focusable, Boolean.class, 0, 28, 0).f(view2, Boolean.valueOf(z6));
                }
                typedArrayObtainStyledAttributes6.recycle();
            }
        }
        return view2;
    }

    public final void p(int i10, d0 d0Var, m.j jVar) {
        if (jVar == null) {
            if (d0Var == null && i10 >= 0) {
                d0[] d0VarArr = this.Z0;
                if (i10 < d0VarArr.length) {
                    d0Var = d0VarArr[i10];
                }
            }
            if (d0Var != null) {
                jVar = d0Var.h;
            }
        }
        if ((d0Var == null || d0Var.f1030m) && !this.f1065e1) {
            x xVar = this.f1085z0;
            Window.Callback callback = this.f1084y0.getCallback();
            xVar.getClass();
            try {
                xVar.Z = true;
                callback.onPanelClosed(i10, jVar);
            } finally {
                xVar.Z = false;
            }
        }
    }

    public final void q(m.j jVar) {
        androidx.appcompat.widget.n nVar;
        if (this.Y0) {
            return;
        }
        this.Y0 = true;
        ActionBarOverlayLayout actionBarOverlayLayout = (ActionBarOverlayLayout) this.E0;
        actionBarOverlayLayout.k();
        ActionMenuView actionMenuView = ((n3) actionBarOverlayLayout.u0).f1381a.f1236e;
        if (actionMenuView != null && (nVar = actionMenuView.J0) != null) {
            nVar.g();
            androidx.appcompat.widget.h hVar = nVar.H0;
            if (hVar != null && hVar.b()) {
                hVar.f14754i.dismiss();
            }
        }
        Window.Callback callback = this.f1084y0.getCallback();
        if (callback != null && !this.f1065e1) {
            callback.onPanelClosed(108, jVar);
        }
        this.Y0 = false;
    }

    public final void r(d0 d0Var, boolean z5) {
        b0 b0Var;
        o1 o1Var;
        androidx.appcompat.widget.n nVar;
        if (z5 && d0Var.f1020a == 0 && (o1Var = this.E0) != null) {
            ActionBarOverlayLayout actionBarOverlayLayout = (ActionBarOverlayLayout) o1Var;
            actionBarOverlayLayout.k();
            ActionMenuView actionMenuView = ((n3) actionBarOverlayLayout.u0).f1381a.f1236e;
            if (actionMenuView != null && (nVar = actionMenuView.J0) != null && nVar.i()) {
                q(d0Var.h);
                return;
            }
        }
        WindowManager windowManager = (WindowManager) this.f1083x0.getSystemService("window");
        if (windowManager != null && d0Var.f1030m && (b0Var = d0Var.f1024e) != null) {
            windowManager.removeView(b0Var);
            if (z5) {
                p(d0Var.f1020a, d0Var, null);
            }
        }
        d0Var.f1028k = false;
        d0Var.f1029l = false;
        d0Var.f1030m = false;
        d0Var.f = null;
        d0Var.f1031n = true;
        if (this.f1061a1 == d0Var) {
            this.f1061a1 = null;
        }
        if (d0Var.f1020a == 0) {
            I();
        }
    }

    /* JADX WARN: Code duplicated, block: B:101:0x0147  */
    /* JADX WARN: Code duplicated, block: B:104:0x014e A[RETURN] */
    /* JADX WARN: Code duplicated, block: B:21:0x003f  */
    /* JADX WARN: Code duplicated, block: B:23:0x004a A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:24:0x004c A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:26:0x0050  */
    /* JADX WARN: Code duplicated, block: B:28:0x0056  */
    /* JADX WARN: Code duplicated, block: B:30:0x005e  */
    /* JADX WARN: Code duplicated, block: B:32:0x0062  */
    /* JADX WARN: Code duplicated, block: B:35:0x006b  */
    /* JADX WARN: Code duplicated, block: B:38:0x006f A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:39:0x0071 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:41:0x0075  */
    /* JADX WARN: Code duplicated, block: B:44:0x007b  */
    /* JADX WARN: Code duplicated, block: B:46:0x0085  */
    /* JADX WARN: Code duplicated, block: B:78:0x0105  */
    /* JADX WARN: Code duplicated, block: B:80:0x0109  */
    /* JADX WARN: Code duplicated, block: B:91:0x0123  */
    /* JADX WARN: Code duplicated, block: B:95:0x012d  */
    /* JADX WARN: Code duplicated, block: B:97:0x013b  */
    /* JADX WARN: Code duplicated, block: B:99:0x013f  */
    public final boolean t(KeyEvent keyEvent) {
        View decorView;
        int keyCode;
        d0 d0VarZ;
        o1 o1Var;
        Context context;
        boolean z5;
        boolean z6;
        boolean zG;
        AudioManager audioManager;
        Toolbar toolbar;
        ActionMenuView actionMenuView;
        androidx.appcompat.widget.n nVar;
        androidx.appcompat.widget.n nVar2;
        androidx.appcompat.widget.n nVar3;
        d0 d0VarZ2;
        Object obj = this.f1082w0;
        if ((!(obj instanceof j2.l) && !(obj instanceof g0)) || (decorView = this.f1084y0.getDecorView()) == null || !q0.f.g(decorView, keyEvent)) {
            if (keyEvent.getKeyCode() == 82) {
                x xVar = this.f1085z0;
                Window.Callback callback = this.f1084y0.getCallback();
                xVar.getClass();
                try {
                    xVar.Y = true;
                    boolean zDispatchKeyEvent = callback.dispatchKeyEvent(keyEvent);
                    xVar.Y = false;
                    if (!zDispatchKeyEvent) {
                        keyCode = keyEvent.getKeyCode();
                        if (keyEvent.getAction() == 0) {
                            if (keyCode != 4) {
                                this.f1062b1 = (keyEvent.getFlags() & 128) != 0;
                                return false;
                            }
                            if (keyCode == 82) {
                                if (keyEvent.getRepeatCount() == 0) {
                                    d0VarZ2 = z(0);
                                    if (!d0VarZ2.f1030m) {
                                        G(d0VarZ2, keyEvent);
                                        return true;
                                    }
                                }
                            }
                            return false;
                        }
                        if (keyCode != 4) {
                            if (keyCode == 82) {
                                if (this.H0 == null) {
                                    d0VarZ = z(0);
                                    o1Var = this.E0;
                                    context = this.f1083x0;
                                    if (o1Var != null) {
                                        ActionBarOverlayLayout actionBarOverlayLayout = (ActionBarOverlayLayout) o1Var;
                                        actionBarOverlayLayout.k();
                                        toolbar = ((n3) actionBarOverlayLayout.u0).f1381a;
                                        if (toolbar.getVisibility() == 0 || (actionMenuView = toolbar.f1236e) == null || !actionMenuView.I0 || ViewConfiguration.get(context).hasPermanentMenuKey()) {
                                            z5 = d0VarZ.f1030m;
                                            if (!z5 || d0VarZ.f1029l) {
                                                r(d0VarZ, true);
                                                z6 = z5;
                                            } else {
                                                if (d0VarZ.f1028k) {
                                                    if (d0VarZ.f1032o) {
                                                        d0VarZ.f1028k = false;
                                                        zG = G(d0VarZ, keyEvent);
                                                    } else {
                                                        zG = true;
                                                    }
                                                    if (zG) {
                                                        E(d0VarZ, keyEvent);
                                                        z6 = true;
                                                    }
                                                }
                                                z6 = false;
                                            }
                                        } else {
                                            ActionBarOverlayLayout actionBarOverlayLayout2 = (ActionBarOverlayLayout) this.E0;
                                            actionBarOverlayLayout2.k();
                                            ActionMenuView actionMenuView2 = ((n3) actionBarOverlayLayout2.u0).f1381a.f1236e;
                                            if (actionMenuView2 == null || (nVar2 = actionMenuView2.J0) == null || !nVar2.i()) {
                                                if (!this.f1065e1 && G(d0VarZ, keyEvent)) {
                                                    ActionBarOverlayLayout actionBarOverlayLayout3 = (ActionBarOverlayLayout) this.E0;
                                                    actionBarOverlayLayout3.k();
                                                    ActionMenuView actionMenuView3 = ((n3) actionBarOverlayLayout3.u0).f1381a.f1236e;
                                                    if (actionMenuView3 != null && (nVar = actionMenuView3.J0) != null && nVar.n()) {
                                                        z6 = true;
                                                    }
                                                }
                                                z6 = false;
                                            } else {
                                                ActionBarOverlayLayout actionBarOverlayLayout4 = (ActionBarOverlayLayout) this.E0;
                                                actionBarOverlayLayout4.k();
                                                ActionMenuView actionMenuView4 = ((n3) actionBarOverlayLayout4.u0).f1381a.f1236e;
                                                if (actionMenuView4 == null || (nVar3 = actionMenuView4.J0) == null || !nVar3.g()) {
                                                    z6 = false;
                                                } else {
                                                    z6 = true;
                                                }
                                            }
                                        }
                                    } else {
                                        z5 = d0VarZ.f1030m;
                                        if (z5) {
                                        }
                                        r(d0VarZ, true);
                                        z6 = z5;
                                    }
                                    if (z6) {
                                        audioManager = (AudioManager) context.getApplicationContext().getSystemService("audio");
                                        if (audioManager != null) {
                                            audioManager.playSoundEffect(0);
                                            return true;
                                        }
                                        Log.w("AppCompatDelegate", "Couldn't get audio manager");
                                        return true;
                                    }
                                }
                            }
                            return false;
                        }
                        if (D()) {
                            return false;
                        }
                    }
                } catch (Throwable th2) {
                    xVar.Y = false;
                    throw th2;
                }
            } else {
                keyCode = keyEvent.getKeyCode();
                if (keyEvent.getAction() == 0) {
                    if (keyCode != 4) {
                        this.f1062b1 = (keyEvent.getFlags() & 128) != 0;
                        return false;
                    }
                    if (keyCode == 82) {
                        if (keyEvent.getRepeatCount() == 0) {
                            d0VarZ2 = z(0);
                            if (!d0VarZ2.f1030m) {
                                G(d0VarZ2, keyEvent);
                                return true;
                            }
                        }
                    }
                    return false;
                }
                if (keyCode != 4) {
                    if (keyCode == 82) {
                        if (this.H0 == null) {
                            d0VarZ = z(0);
                            o1Var = this.E0;
                            context = this.f1083x0;
                            if (o1Var != null) {
                                ActionBarOverlayLayout actionBarOverlayLayout5 = (ActionBarOverlayLayout) o1Var;
                                actionBarOverlayLayout5.k();
                                toolbar = ((n3) actionBarOverlayLayout5.u0).f1381a;
                                if (toolbar.getVisibility() == 0) {
                                    z5 = d0VarZ.f1030m;
                                    if (z5) {
                                    }
                                    r(d0VarZ, true);
                                    z6 = z5;
                                } else {
                                    z5 = d0VarZ.f1030m;
                                    if (z5) {
                                    }
                                    r(d0VarZ, true);
                                    z6 = z5;
                                }
                            } else {
                                z5 = d0VarZ.f1030m;
                                if (z5) {
                                }
                                r(d0VarZ, true);
                                z6 = z5;
                            }
                            if (z6) {
                                audioManager = (AudioManager) context.getApplicationContext().getSystemService("audio");
                                if (audioManager != null) {
                                    audioManager.playSoundEffect(0);
                                    return true;
                                }
                                Log.w("AppCompatDelegate", "Couldn't get audio manager");
                                return true;
                            }
                        }
                    }
                    return false;
                }
                if (D()) {
                    return false;
                }
            }
        }
        return true;
    }

    public final void u(int i10) {
        d0 d0VarZ = z(i10);
        if (d0VarZ.h != null) {
            Bundle bundle = new Bundle();
            d0VarZ.h.t(bundle);
            if (bundle.size() > 0) {
                d0VarZ.f1033p = bundle;
            }
            d0VarZ.h.w();
            d0VarZ.h.clear();
        }
        d0VarZ.f1032o = true;
        d0VarZ.f1031n = true;
        if ((i10 == 108 || i10 == 0) && this.E0 != null) {
            d0 d0VarZ2 = z(0);
            d0VarZ2.f1028k = false;
            G(d0VarZ2, null);
        }
    }

    public final void v() {
        ViewGroup viewGroup;
        if (this.N0) {
            return;
        }
        Context context = this.f1083x0;
        int[] iArr = g.a.f8277j;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(iArr);
        if (!typedArrayObtainStyledAttributes.hasValue(117)) {
            typedArrayObtainStyledAttributes.recycle();
            throw new IllegalStateException("You need to use a Theme.AppCompat theme (or descendant) with this activity.");
        }
        if (typedArrayObtainStyledAttributes.getBoolean(WebSocketProtocol.PAYLOAD_SHORT, false)) {
            f(1);
        } else if (typedArrayObtainStyledAttributes.getBoolean(117, false)) {
            f(108);
        }
        if (typedArrayObtainStyledAttributes.getBoolean(118, false)) {
            f(109);
        }
        if (typedArrayObtainStyledAttributes.getBoolean(119, false)) {
            f(10);
        }
        this.W0 = typedArrayObtainStyledAttributes.getBoolean(0, false);
        typedArrayObtainStyledAttributes.recycle();
        w();
        this.f1084y0.getDecorView();
        LayoutInflater layoutInflaterFrom = LayoutInflater.from(context);
        if (this.X0) {
            viewGroup = this.V0 ? (ViewGroup) layoutInflaterFrom.inflate(tm.belet.films.R.layout.abc_screen_simple_overlay_action_mode, (ViewGroup) null) : (ViewGroup) layoutInflaterFrom.inflate(tm.belet.films.R.layout.abc_screen_simple, (ViewGroup) null);
        } else if (this.W0) {
            viewGroup = (ViewGroup) layoutInflaterFrom.inflate(tm.belet.films.R.layout.abc_dialog_title_material, (ViewGroup) null);
            this.U0 = false;
            this.T0 = false;
        } else if (this.T0) {
            TypedValue typedValue = new TypedValue();
            context.getTheme().resolveAttribute(tm.belet.films.R.attr.actionBarTheme, typedValue, true);
            viewGroup = (ViewGroup) LayoutInflater.from(typedValue.resourceId != 0 ? new l.c(context, typedValue.resourceId) : context).inflate(tm.belet.films.R.layout.abc_screen_toolbar, (ViewGroup) null);
            o1 o1Var = (o1) viewGroup.findViewById(tm.belet.films.R.id.decor_content_parent);
            this.E0 = o1Var;
            o1Var.setWindowCallback(this.f1084y0.getCallback());
            if (this.U0) {
                ((ActionBarOverlayLayout) this.E0).j(109);
            }
            if (this.R0) {
                ((ActionBarOverlayLayout) this.E0).j(2);
            }
            if (this.S0) {
                ((ActionBarOverlayLayout) this.E0).j(5);
            }
        } else {
            viewGroup = null;
        }
        if (viewGroup == null) {
            throw new IllegalArgumentException("AppCompat does not support the current theme features: { windowActionBar: " + this.T0 + ", windowActionBarOverlay: " + this.U0 + ", android:windowIsFloating: " + this.W0 + ", windowActionModeOverlay: " + this.V0 + ", windowNoTitle: " + this.X0 + " }");
        }
        r rVar = new r(this);
        WeakHashMap weakHashMap = j2.q0.f12703a;
        j2.h0.c(viewGroup, rVar);
        if (this.E0 == null) {
            this.P0 = (TextView) viewGroup.findViewById(tm.belet.films.R.id.title);
        }
        boolean z5 = v3.f1471a;
        try {
            Method method = viewGroup.getClass().getMethod("makeOptionalFitsSystemWindows", null);
            if (!method.isAccessible()) {
                method.setAccessible(true);
            }
            method.invoke(viewGroup, null);
        } catch (IllegalAccessException e3) {
            Log.d("ViewUtils", "Could not invoke makeOptionalFitsSystemWindows", e3);
        } catch (NoSuchMethodException unused) {
            Log.d("ViewUtils", "Could not find method makeOptionalFitsSystemWindows. Oh well...");
        } catch (InvocationTargetException e10) {
            Log.d("ViewUtils", "Could not invoke makeOptionalFitsSystemWindows", e10);
        }
        ContentFrameLayout contentFrameLayout = (ContentFrameLayout) viewGroup.findViewById(tm.belet.films.R.id.action_bar_activity_content);
        ViewGroup viewGroup2 = (ViewGroup) this.f1084y0.findViewById(R.id.content);
        if (viewGroup2 != null) {
            while (viewGroup2.getChildCount() > 0) {
                View childAt = viewGroup2.getChildAt(0);
                viewGroup2.removeViewAt(0);
                contentFrameLayout.addView(childAt);
            }
            viewGroup2.setId(-1);
            contentFrameLayout.setId(R.id.content);
            if (viewGroup2 instanceof FrameLayout) {
                ((FrameLayout) viewGroup2).setForeground(null);
            }
        }
        this.f1084y0.setContentView(viewGroup);
        contentFrameLayout.setAttachListener(new z7.c(3, this));
        this.O0 = viewGroup;
        Object obj = this.f1082w0;
        CharSequence title = obj instanceof Activity ? ((Activity) obj).getTitle() : this.D0;
        if (!TextUtils.isEmpty(title)) {
            o1 o1Var2 = this.E0;
            if (o1Var2 != null) {
                o1Var2.setWindowTitle(title);
            } else {
                q0 q0Var = this.B0;
                if (q0Var != null) {
                    n3 n3Var = (n3) q0Var.f1123j;
                    if (!n3Var.f1386g) {
                        Toolbar toolbar = n3Var.f1381a;
                        n3Var.h = title;
                        if ((n3Var.f1382b & 8) != 0) {
                            toolbar.setTitle(title);
                            if (n3Var.f1386g) {
                                j2.q0.o(toolbar.getRootView(), title);
                            }
                        }
                    }
                } else {
                    TextView textView = this.P0;
                    if (textView != null) {
                        textView.setText(title);
                    }
                }
            }
        }
        ContentFrameLayout contentFrameLayout2 = (ContentFrameLayout) this.O0.findViewById(R.id.content);
        View decorView = this.f1084y0.getDecorView();
        contentFrameLayout2.f1210w0.set(decorView.getPaddingLeft(), decorView.getPaddingTop(), decorView.getPaddingRight(), decorView.getPaddingBottom());
        if (contentFrameLayout2.isLaidOut()) {
            contentFrameLayout2.requestLayout();
        }
        TypedArray typedArrayObtainStyledAttributes2 = context.obtainStyledAttributes(iArr);
        typedArrayObtainStyledAttributes2.getValue(124, contentFrameLayout2.getMinWidthMajor());
        typedArrayObtainStyledAttributes2.getValue(125, contentFrameLayout2.getMinWidthMinor());
        if (typedArrayObtainStyledAttributes2.hasValue(122)) {
            typedArrayObtainStyledAttributes2.getValue(122, contentFrameLayout2.getFixedWidthMajor());
        }
        if (typedArrayObtainStyledAttributes2.hasValue(123)) {
            typedArrayObtainStyledAttributes2.getValue(123, contentFrameLayout2.getFixedWidthMinor());
        }
        if (typedArrayObtainStyledAttributes2.hasValue(120)) {
            typedArrayObtainStyledAttributes2.getValue(120, contentFrameLayout2.getFixedHeightMajor());
        }
        if (typedArrayObtainStyledAttributes2.hasValue(121)) {
            typedArrayObtainStyledAttributes2.getValue(121, contentFrameLayout2.getFixedHeightMinor());
        }
        typedArrayObtainStyledAttributes2.recycle();
        contentFrameLayout2.requestLayout();
        this.N0 = true;
        d0 d0VarZ = z(0);
        if (this.f1065e1 || d0VarZ.h != null) {
            return;
        }
        B(108);
    }

    public final void w() {
        if (this.f1084y0 == null) {
            Object obj = this.f1082w0;
            if (obj instanceof Activity) {
                n(((Activity) obj).getWindow());
            }
        }
        if (this.f1084y0 == null) {
            throw new IllegalStateException("We have not been given a Window");
        }
    }

    public final a0 x(Context context) {
        if (this.f1071k1 == null) {
            if (m7.m.f15160r0 == null) {
                Context applicationContext = context.getApplicationContext();
                m7.m.f15160r0 = new m7.m(applicationContext, (LocationManager) applicationContext.getSystemService("location"));
            }
            this.f1071k1 = new y(this, m7.m.f15160r0);
        }
        return this.f1071k1;
    }

    public final d0 z(int i10) {
        d0[] d0VarArr = this.Z0;
        if (d0VarArr == null || d0VarArr.length <= i10) {
            d0[] d0VarArr2 = new d0[i10 + 1];
            if (d0VarArr != null) {
                System.arraycopy(d0VarArr, 0, d0VarArr2, 0, d0VarArr.length);
            }
            this.Z0 = d0VarArr2;
            d0VarArr = d0VarArr2;
        }
        d0 d0Var = d0VarArr[i10];
        if (d0Var != null) {
            return d0Var;
        }
        d0 d0Var2 = new d0();
        d0Var2.f1020a = i10;
        d0Var2.f1031n = false;
        d0VarArr[i10] = d0Var2;
        return d0Var2;
    }

    @Override // android.view.LayoutInflater.Factory
    public final View onCreateView(String str, Context context, AttributeSet attributeSet) {
        return onCreateView(null, str, context, attributeSet);
    }
}
