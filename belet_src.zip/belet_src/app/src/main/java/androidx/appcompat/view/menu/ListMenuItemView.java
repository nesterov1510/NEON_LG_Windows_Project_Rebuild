package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import g.a;
import m.j;
import m.l;
import m.w;
import nh.c;
import okhttp3.internal.url._UrlKt;
import okio.internal.Buffer;
import tm.belet.films.R;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public class ListMenuItemView extends LinearLayout implements w, AbsListView.SelectionBoundsAdjuster {
    public final int A0;
    public final Context B0;
    public boolean C0;
    public final Drawable D0;
    public final boolean E0;
    public LayoutInflater F0;
    public boolean G0;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public l f1156e;

    /* JADX INFO: renamed from: r0, reason: collision with root package name */
    public ImageView f1157r0;

    /* JADX INFO: renamed from: s0, reason: collision with root package name */
    public RadioButton f1158s0;

    /* JADX INFO: renamed from: t0, reason: collision with root package name */
    public TextView f1159t0;
    public CheckBox u0;

    /* JADX INFO: renamed from: v0, reason: collision with root package name */
    public TextView f1160v0;

    /* JADX INFO: renamed from: w0, reason: collision with root package name */
    public ImageView f1161w0;

    /* JADX INFO: renamed from: x0, reason: collision with root package name */
    public ImageView f1162x0;

    /* JADX INFO: renamed from: y0, reason: collision with root package name */
    public LinearLayout f1163y0;

    /* JADX INFO: renamed from: z0, reason: collision with root package name */
    public final Drawable f1164z0;

    public ListMenuItemView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        c cVarC = c.C(getContext(), attributeSet, a.f8285r, R.attr.listMenuViewStyle);
        this.f1164z0 = cVarC.u(5);
        TypedArray typedArray = (TypedArray) cVarC.Y;
        this.A0 = typedArray.getResourceId(1, -1);
        this.C0 = typedArray.getBoolean(7, false);
        this.B0 = context;
        this.D0 = cVarC.u(8);
        TypedArray typedArrayObtainStyledAttributes = context.getTheme().obtainStyledAttributes(null, new int[]{android.R.attr.divider}, R.attr.dropDownListViewStyle, 0);
        this.E0 = typedArrayObtainStyledAttributes.hasValue(0);
        cVarC.F();
        typedArrayObtainStyledAttributes.recycle();
    }

    private LayoutInflater getInflater() {
        if (this.F0 == null) {
            this.F0 = LayoutInflater.from(getContext());
        }
        return this.F0;
    }

    private void setSubMenuArrowVisible(boolean z5) {
        ImageView imageView = this.f1161w0;
        if (imageView != null) {
            imageView.setVisibility(z5 ? 0 : 8);
        }
    }

    /* JADX WARN: Code duplicated, block: B:14:0x0035  */
    /* JADX WARN: Code duplicated, block: B:25:0x0054  */
    /* JADX WARN: Code duplicated, block: B:28:0x0058  */
    @Override // m.w
    public final void a(l lVar) {
        boolean z5;
        int i10;
        String string;
        boolean z6;
        this.f1156e = lVar;
        boolean zIsVisible = lVar.isVisible();
        j jVar = lVar.A0;
        setVisibility(zIsVisible ? 0 : 8);
        setTitle(lVar.f14730r0);
        setCheckable(lVar.isCheckable());
        if (jVar.o()) {
            if ((jVar.n() ? lVar.f14734w0 : lVar.u0) != 0) {
                z5 = true;
            } else {
                z5 = false;
            }
        } else {
            z5 = false;
        }
        jVar.n();
        if (z5) {
            l lVar2 = this.f1156e;
            j jVar2 = lVar2.A0;
            if (jVar2.o()) {
                if ((jVar2.n() ? lVar2.f14734w0 : lVar2.u0) != 0) {
                    z6 = true;
                } else {
                    z6 = false;
                }
            } else {
                z6 = false;
            }
            i10 = z6 ? 0 : 8;
        }
        if (i10 == 0) {
            TextView textView = this.f1160v0;
            l lVar3 = this.f1156e;
            j jVar3 = lVar3.A0;
            Context context = jVar3.f14719e;
            char c10 = jVar3.n() ? lVar3.f14734w0 : lVar3.u0;
            if (c10 == 0) {
                string = _UrlKt.FRAGMENT_ENCODE_SET;
            } else {
                Resources resources = context.getResources();
                StringBuilder sb2 = new StringBuilder();
                if (ViewConfiguration.get(context).hasPermanentMenuKey()) {
                    sb2.append(resources.getString(R.string.abc_prepend_shortcut_label));
                }
                int i11 = jVar3.n() ? lVar3.f14735x0 : lVar3.f14733v0;
                l.b(i11, 65536, resources.getString(R.string.abc_menu_meta_shortcut_label), sb2);
                l.b(i11, Buffer.SEGMENTING_THRESHOLD, resources.getString(R.string.abc_menu_ctrl_shortcut_label), sb2);
                l.b(i11, 2, resources.getString(R.string.abc_menu_alt_shortcut_label), sb2);
                l.b(i11, 1, resources.getString(R.string.abc_menu_shift_shortcut_label), sb2);
                l.b(i11, 4, resources.getString(R.string.abc_menu_sym_shortcut_label), sb2);
                l.b(i11, 8, resources.getString(R.string.abc_menu_function_shortcut_label), sb2);
                if (c10 == '\b') {
                    sb2.append(resources.getString(R.string.abc_menu_delete_shortcut_label));
                } else if (c10 == '\n') {
                    sb2.append(resources.getString(R.string.abc_menu_enter_shortcut_label));
                } else if (c10 != ' ') {
                    sb2.append(c10);
                } else {
                    sb2.append(resources.getString(R.string.abc_menu_space_shortcut_label));
                }
                string = sb2.toString();
            }
            textView.setText(string);
        }
        if (this.f1160v0.getVisibility() != i10) {
            this.f1160v0.setVisibility(i10);
        }
        setIcon(lVar.getIcon());
        setEnabled(lVar.isEnabled());
        setSubMenuArrowVisible(lVar.hasSubMenu());
        setContentDescription(lVar.D0);
    }

    @Override // android.widget.AbsListView.SelectionBoundsAdjuster
    public final void adjustListItemSelectionBounds(Rect rect) {
        ImageView imageView = this.f1162x0;
        if (imageView == null || imageView.getVisibility() != 0) {
            return;
        }
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) this.f1162x0.getLayoutParams();
        rect.top = this.f1162x0.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin + rect.top;
    }

    @Override // m.w
    public l getItemData() {
        return this.f1156e;
    }

    @Override // android.view.View
    public final void onFinishInflate() {
        super.onFinishInflate();
        setBackground(this.f1164z0);
        TextView textView = (TextView) findViewById(R.id.title);
        this.f1159t0 = textView;
        int i10 = this.A0;
        if (i10 != -1) {
            textView.setTextAppearance(this.B0, i10);
        }
        this.f1160v0 = (TextView) findViewById(R.id.shortcut);
        ImageView imageView = (ImageView) findViewById(R.id.submenuarrow);
        this.f1161w0 = imageView;
        if (imageView != null) {
            imageView.setImageDrawable(this.D0);
        }
        this.f1162x0 = (ImageView) findViewById(R.id.group_divider);
        this.f1163y0 = (LinearLayout) findViewById(R.id.content);
    }

    @Override // android.widget.LinearLayout, android.view.View
    public final void onMeasure(int i10, int i11) {
        if (this.f1157r0 != null && this.C0) {
            ViewGroup.LayoutParams layoutParams = getLayoutParams();
            LinearLayout.LayoutParams layoutParams2 = (LinearLayout.LayoutParams) this.f1157r0.getLayoutParams();
            int i12 = layoutParams.height;
            if (i12 > 0 && layoutParams2.width <= 0) {
                layoutParams2.width = i12;
            }
        }
        super.onMeasure(i10, i11);
    }

    public void setCheckable(boolean z5) {
        CompoundButton compoundButton;
        View view;
        if (!z5 && this.f1158s0 == null && this.u0 == null) {
            return;
        }
        if ((this.f1156e.K0 & 4) != 0) {
            if (this.f1158s0 == null) {
                RadioButton radioButton = (RadioButton) getInflater().inflate(R.layout.abc_list_menu_item_radio, (ViewGroup) this, false);
                this.f1158s0 = radioButton;
                LinearLayout linearLayout = this.f1163y0;
                if (linearLayout != null) {
                    linearLayout.addView(radioButton, -1);
                } else {
                    addView(radioButton, -1);
                }
            }
            compoundButton = this.f1158s0;
            view = this.u0;
        } else {
            if (this.u0 == null) {
                CheckBox checkBox = (CheckBox) getInflater().inflate(R.layout.abc_list_menu_item_checkbox, (ViewGroup) this, false);
                this.u0 = checkBox;
                LinearLayout linearLayout2 = this.f1163y0;
                if (linearLayout2 != null) {
                    linearLayout2.addView(checkBox, -1);
                } else {
                    addView(checkBox, -1);
                }
            }
            compoundButton = this.u0;
            view = this.f1158s0;
        }
        if (z5) {
            compoundButton.setChecked(this.f1156e.isChecked());
            if (compoundButton.getVisibility() != 0) {
                compoundButton.setVisibility(0);
            }
            if (view == null || view.getVisibility() == 8) {
                return;
            }
            view.setVisibility(8);
            return;
        }
        CheckBox checkBox2 = this.u0;
        if (checkBox2 != null) {
            checkBox2.setVisibility(8);
        }
        RadioButton radioButton2 = this.f1158s0;
        if (radioButton2 != null) {
            radioButton2.setVisibility(8);
        }
    }

    public void setChecked(boolean z5) {
        CompoundButton compoundButton;
        if ((this.f1156e.K0 & 4) != 0) {
            if (this.f1158s0 == null) {
                RadioButton radioButton = (RadioButton) getInflater().inflate(R.layout.abc_list_menu_item_radio, (ViewGroup) this, false);
                this.f1158s0 = radioButton;
                LinearLayout linearLayout = this.f1163y0;
                if (linearLayout != null) {
                    linearLayout.addView(radioButton, -1);
                } else {
                    addView(radioButton, -1);
                }
            }
            compoundButton = this.f1158s0;
        } else {
            if (this.u0 == null) {
                CheckBox checkBox = (CheckBox) getInflater().inflate(R.layout.abc_list_menu_item_checkbox, (ViewGroup) this, false);
                this.u0 = checkBox;
                LinearLayout linearLayout2 = this.f1163y0;
                if (linearLayout2 != null) {
                    linearLayout2.addView(checkBox, -1);
                } else {
                    addView(checkBox, -1);
                }
            }
            compoundButton = this.u0;
        }
        compoundButton.setChecked(z5);
    }

    public void setForceShowIcon(boolean z5) {
        this.G0 = z5;
        this.C0 = z5;
    }

    public void setGroupDividerEnabled(boolean z5) {
        ImageView imageView = this.f1162x0;
        if (imageView != null) {
            imageView.setVisibility((this.E0 || !z5) ? 8 : 0);
        }
    }

    public void setIcon(Drawable drawable) {
        j jVar = this.f1156e.A0;
        boolean z5 = this.G0;
        if (z5 || this.C0) {
            ImageView imageView = this.f1157r0;
            if (imageView == null && drawable == null && !this.C0) {
                return;
            }
            if (imageView == null) {
                ImageView imageView2 = (ImageView) getInflater().inflate(R.layout.abc_list_menu_item_icon, (ViewGroup) this, false);
                this.f1157r0 = imageView2;
                LinearLayout linearLayout = this.f1163y0;
                if (linearLayout != null) {
                    linearLayout.addView(imageView2, 0);
                } else {
                    addView(imageView2, 0);
                }
            }
            if (drawable == null && !this.C0) {
                this.f1157r0.setVisibility(8);
                return;
            }
            ImageView imageView3 = this.f1157r0;
            if (!z5) {
                drawable = null;
            }
            imageView3.setImageDrawable(drawable);
            if (this.f1157r0.getVisibility() != 0) {
                this.f1157r0.setVisibility(0);
            }
        }
    }

    public void setTitle(CharSequence charSequence) {
        if (charSequence == null) {
            if (this.f1159t0.getVisibility() != 8) {
                this.f1159t0.setVisibility(8);
            }
        } else {
            this.f1159t0.setText(charSequence);
            if (this.f1159t0.getVisibility() != 0) {
                this.f1159t0.setVisibility(0);
            }
        }
    }
}
