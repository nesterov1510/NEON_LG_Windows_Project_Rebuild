package androidx.activity.result;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.IntentSender;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.images.a;
import kotlin.jvm.internal.q;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
@SuppressLint({"BanParcelableUsage"})
public final class IntentSenderRequest implements Parcelable {
    public static final Parcelable.Creator<IntentSenderRequest> CREATOR = new a(5);
    public final Intent X;
    public final int Y;
    public final int Z;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final IntentSender f998e;

    public IntentSenderRequest(IntentSender intentSender, Intent intent, int i10, int i11) {
        this.f998e = intentSender;
        this.X = intent;
        this.Y = i10;
        this.Z = i11;
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel dest, int i10) {
        q.g(dest, "dest");
        dest.writeParcelable(this.f998e, i10);
        dest.writeParcelable(this.X, i10);
        dest.writeInt(this.Y);
        dest.writeInt(this.Z);
    }
}
