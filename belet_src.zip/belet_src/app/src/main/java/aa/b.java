package aa;

import android.app.PendingIntent;
import android.graphics.Bitmap;
import android.media.MediaDescription;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.media.MediaBrowserCompat$MediaItem;
import android.support.v4.media.MediaDescriptionCompat;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.RatingCompat;
import android.support.v4.os.ResultReceiver;
import androidx.media3.exoplayer.offline.DownloadRequest;
import b.c;
import com.auth0.android.jwt.JWT;
import com.google.android.gms.auth.api.signin.internal.GoogleSignInOptionsExtensionParcelable;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.Feature;
import com.google.android.gms.common.zzp;
import com.google.android.gms.common.zzr;
import com.google.android.gms.common.zzt;
import com.google.android.gms.measurement.internal.zzaf;
import com.google.android.gms.measurement.internal.zzah;
import com.google.android.gms.measurement.internal.zzao;
import com.google.android.gms.measurement.internal.zzbf;
import com.google.android.gms.measurement.internal.zzbh;
import com.google.android.gms.measurement.internal.zzoh;
import com.google.android.gms.measurement.internal.zzom;
import com.google.android.gms.measurement.internal.zzoo;
import com.google.android.gms.measurement.internal.zzoq;
import com.google.android.gms.measurement.internal.zzpl;
import java.util.ArrayList;
import kotlin.jvm.internal.q;
import okhttp3.internal.url._UrlKt;
import okhttp3.internal.ws.WebSocketProtocol;
import tm.belet.films.domain.models.profile.ColorModel;
import tm.belet.films.domain.models.profile.ColoredUIComponentModel;
import tm.belet.films.domain.models.profile.ResponseModel;
import tm.belet.films.domain.models.profile.SuspensionStatusModel;
import tm.belet.films.domain.models.profile.SwitchConfirmModel;
import tm.belet.films.domain.models.profile.SwitchInfoModel;
import ue.r;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class b implements Parcelable.Creator {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f696a;

    public /* synthetic */ b(int i10) {
        this.f696a = i10;
    }

    public static void a(zzbh zzbhVar, Parcel parcel, int i10) {
        String str = zzbhVar.f5660e;
        int iS = y6.a.S(parcel, 20293);
        y6.a.N(parcel, 2, str);
        y6.a.M(parcel, 3, zzbhVar.X, i10);
        y6.a.N(parcel, 4, zzbhVar.Y);
        long j10 = zzbhVar.Z;
        y6.a.R(parcel, 5, 8);
        parcel.writeLong(j10);
        long j11 = zzbhVar.f5661r0;
        y6.a.R(parcel, 6, 8);
        parcel.writeLong(j11);
        y6.a.T(parcel, iS);
    }

    public static void b(zzpl zzplVar, Parcel parcel) {
        int i10 = zzplVar.f5669e;
        int iS = y6.a.S(parcel, 20293);
        y6.a.R(parcel, 1, 4);
        parcel.writeInt(i10);
        y6.a.N(parcel, 2, zzplVar.X);
        long j10 = zzplVar.Y;
        y6.a.R(parcel, 3, 8);
        parcel.writeLong(j10);
        y6.a.L(parcel, 4, zzplVar.Z);
        y6.a.N(parcel, 6, zzplVar.f5670r0);
        y6.a.N(parcel, 7, zzplVar.f5671s0);
        Double d2 = zzplVar.f5672t0;
        if (d2 != null) {
            y6.a.R(parcel, 8, 8);
            parcel.writeDouble(d2.doubleValue());
        }
        y6.a.T(parcel, iS);
    }

    @Override // android.os.Parcelable.Creator
    public final Object createFromParcel(Parcel parcel) {
        Bundle bundle;
        long jN = 0;
        int iM = 0;
        int iM2 = 0;
        boolean zJ = false;
        Bundle bundleI = null;
        ArrayList arrayListS = null;
        String strO = null;
        Bundle bundleI2 = null;
        Bundle bundleI3 = null;
        String strO2 = null;
        b.b bVar = null;
        switch (this.f696a) {
            case 0:
                int iY = tc.b.Y(parcel);
                int iM3 = 0;
                while (parcel.dataPosition() < iY) {
                    int i10 = parcel.readInt();
                    char c10 = (char) i10;
                    if (c10 == 1) {
                        iM = tc.b.M(parcel, i10);
                    } else if (c10 == 2) {
                        iM3 = tc.b.M(parcel, i10);
                    } else if (c10 != 3) {
                        tc.b.X(parcel, i10);
                    } else {
                        bundleI = tc.b.i(parcel, i10);
                    }
                }
                tc.b.w(parcel, iY);
                return new GoogleSignInOptionsExtensionParcelable(iM, iM3, bundleI);
            case 1:
                q.g(parcel, "parcel");
                return new ColorModel(parcel.readString(), parcel.readString());
            case 2:
                q.g(parcel, "parcel");
                return new ColoredUIComponentModel(parcel.readString(), parcel.readString(), parcel.readInt() == 0 ? null : ColorModel.CREATOR.createFromParcel(parcel), parcel.readInt() == 0 ? null : ColorModel.CREATOR.createFromParcel(parcel), parcel.readInt() != 0 ? ColorModel.CREATOR.createFromParcel(parcel) : null);
            case 3:
                q.g(parcel, "parcel");
                return new ResponseModel(parcel.readString(), parcel.readString());
            case 4:
                q.g(parcel, "parcel");
                return new SuspensionStatusModel(parcel.readString(), parcel.readString(), parcel.readInt() != 0 ? ColoredUIComponentModel.CREATOR.createFromParcel(parcel) : null);
            case 5:
                q.g(parcel, "parcel");
                return new SwitchConfirmModel(parcel.readString(), parcel.readString(), parcel.readInt() != 0 ? ColoredUIComponentModel.CREATOR.createFromParcel(parcel) : null);
            case 6:
                q.g(parcel, "parcel");
                return new SwitchInfoModel(parcel.readString(), parcel.readString(), parcel.readString(), parcel.readString(), parcel.readString(), parcel.readInt() != 0 ? ColoredUIComponentModel.CREATOR.createFromParcel(parcel) : null);
            case 7:
                return new MediaBrowserCompat$MediaItem(parcel);
            case 8:
                Object objCreateFromParcel = MediaDescription.CREATOR.createFromParcel(parcel);
                if (objCreateFromParcel == null) {
                    return null;
                }
                MediaDescription mediaDescription = (MediaDescription) objCreateFromParcel;
                String strG = android.support.v4.media.a.g(mediaDescription);
                CharSequence charSequenceI = android.support.v4.media.a.i(mediaDescription);
                CharSequence charSequenceH = android.support.v4.media.a.h(mediaDescription);
                CharSequence charSequenceC = android.support.v4.media.a.c(mediaDescription);
                Bitmap bitmapE = android.support.v4.media.a.e(mediaDescription);
                Uri uriF = android.support.v4.media.a.f(mediaDescription);
                Bundle bundleD = android.support.v4.media.a.d(mediaDescription);
                if (bundleD != null) {
                    bundleD = android.support.v4.media.session.b.M(bundleD);
                }
                Uri uriA = bundleD != null ? (Uri) bundleD.getParcelable("android.support.v4.media.description.MEDIA_URI") : null;
                if (uriA == null) {
                    bundle = bundleD;
                } else if (bundleD.containsKey("android.support.v4.media.description.NULL_BUNDLE_FLAG") && bundleD.size() == 2) {
                    bundle = null;
                } else {
                    bundleD.remove("android.support.v4.media.description.MEDIA_URI");
                    bundleD.remove("android.support.v4.media.description.NULL_BUNDLE_FLAG");
                    bundle = bundleD;
                }
                if (uriA == null) {
                    uriA = android.support.v4.media.b.a(mediaDescription);
                }
                MediaDescriptionCompat mediaDescriptionCompat = new MediaDescriptionCompat(strG, charSequenceI, charSequenceH, charSequenceC, bitmapE, uriF, bundle, uriA);
                mediaDescriptionCompat.f979v0 = mediaDescription;
                return mediaDescriptionCompat;
            case 9:
                return new MediaMetadataCompat(parcel);
            case 10:
                return new RatingCompat(parcel.readInt(), parcel.readFloat());
            case r.NETWORK_CLIENT_ERROR_REASON_FIELD_NUMBER /* 11 */:
                ResultReceiver resultReceiver = new ResultReceiver();
                IBinder strongBinder = parcel.readStrongBinder();
                int i11 = c.f3310e;
                if (strongBinder != null) {
                    IInterface iInterfaceQueryLocalInterface = strongBinder.queryLocalInterface(b.b.f3309a);
                    if (iInterfaceQueryLocalInterface == null || !(iInterfaceQueryLocalInterface instanceof b.b)) {
                        b.a aVar = new b.a();
                        aVar.f3308d = strongBinder;
                        bVar = aVar;
                    } else {
                        bVar = (b.b) iInterfaceQueryLocalInterface;
                    }
                }
                resultReceiver.f996e = bVar;
                return resultReceiver;
            case r.CUSTOM_ATTRIBUTES_FIELD_NUMBER /* 12 */:
                return new DownloadRequest(parcel);
            case r.PERF_SESSIONS_FIELD_NUMBER /* 13 */:
                int iY2 = tc.b.Y(parcel);
                int iM4 = 0;
                int iM5 = 0;
                PendingIntent pendingIntent = null;
                String strO3 = null;
                Integer numValueOf = null;
                while (parcel.dataPosition() < iY2) {
                    int i12 = parcel.readInt();
                    char c11 = (char) i12;
                    if (c11 == 1) {
                        iM4 = tc.b.M(parcel, i12);
                    } else if (c11 == 2) {
                        iM5 = tc.b.M(parcel, i12);
                    } else if (c11 == 3) {
                        pendingIntent = (PendingIntent) tc.b.n(parcel, i12, PendingIntent.CREATOR);
                    } else if (c11 == 4) {
                        strO3 = tc.b.o(parcel, i12);
                    } else if (c11 != 5) {
                        tc.b.X(parcel, i12);
                    } else {
                        int iP = tc.b.P(parcel, i12);
                        if (iP == 0) {
                            numValueOf = null;
                        } else {
                            tc.b.a0(parcel, iP, 4);
                            numValueOf = Integer.valueOf(parcel.readInt());
                        }
                    }
                }
                tc.b.w(parcel, iY2);
                return new ConnectionResult(iM4, iM5, pendingIntent, strO3, numValueOf);
            case 14:
                int iY3 = tc.b.Y(parcel);
                long jN2 = -1;
                int iM6 = 0;
                boolean zJ2 = false;
                String strO4 = null;
                while (parcel.dataPosition() < iY3) {
                    int i13 = parcel.readInt();
                    char c12 = (char) i13;
                    if (c12 == 1) {
                        strO4 = tc.b.o(parcel, i13);
                    } else if (c12 == 2) {
                        iM6 = tc.b.M(parcel, i13);
                    } else if (c12 == 3) {
                        jN2 = tc.b.N(parcel, i13);
                    } else if (c12 != 4) {
                        tc.b.X(parcel, i13);
                    } else {
                        zJ2 = tc.b.J(parcel, i13);
                    }
                }
                tc.b.w(parcel, iY3);
                return new Feature(strO4, iM6, jN2, zJ2);
            case WebSocketProtocol.B0_MASK_OPCODE /* 15 */:
                int iY4 = tc.b.Y(parcel);
                boolean zJ3 = false;
                boolean zJ4 = false;
                boolean zJ5 = false;
                boolean zJ6 = false;
                boolean zJ7 = false;
                String strO5 = null;
                IBinder iBinderL = null;
                while (parcel.dataPosition() < iY4) {
                    int i14 = parcel.readInt();
                    switch ((char) i14) {
                        case 1:
                            strO5 = tc.b.o(parcel, i14);
                            break;
                        case 2:
                            zJ3 = tc.b.J(parcel, i14);
                            break;
                        case 3:
                            zJ4 = tc.b.J(parcel, i14);
                            break;
                        case 4:
                            iBinderL = tc.b.L(parcel, i14);
                            break;
                        case 5:
                            zJ5 = tc.b.J(parcel, i14);
                            break;
                        case 6:
                            zJ6 = tc.b.J(parcel, i14);
                            break;
                        case 7:
                        default:
                            tc.b.X(parcel, i14);
                            break;
                        case '\b':
                            zJ7 = tc.b.J(parcel, i14);
                            break;
                    }
                }
                tc.b.w(parcel, iY4);
                return new zzp(strO5, zJ3, zJ4, iBinderL, zJ5, zJ6, zJ7);
            case WebSocketProtocol.B0_FLAG_RSV3 /* 16 */:
                int iY5 = tc.b.Y(parcel);
                long jN3 = -1;
                int iM7 = 0;
                int iM8 = 0;
                boolean zJ8 = false;
                String strO6 = null;
                while (parcel.dataPosition() < iY5) {
                    int i15 = parcel.readInt();
                    char c13 = (char) i15;
                    if (c13 == 1) {
                        zJ8 = tc.b.J(parcel, i15);
                    } else if (c13 == 2) {
                        strO6 = tc.b.o(parcel, i15);
                    } else if (c13 == 3) {
                        iM7 = tc.b.M(parcel, i15);
                    } else if (c13 == 4) {
                        iM8 = tc.b.M(parcel, i15);
                    } else if (c13 != 5) {
                        tc.b.X(parcel, i15);
                    } else {
                        jN3 = tc.b.N(parcel, i15);
                    }
                }
                tc.b.w(parcel, iY5);
                return new zzr(iM7, iM8, jN3, strO6, zJ8);
            case 17:
                int iY6 = tc.b.Y(parcel);
                boolean zJ9 = false;
                IBinder iBinderL2 = null;
                while (parcel.dataPosition() < iY6) {
                    int i16 = parcel.readInt();
                    char c14 = (char) i16;
                    if (c14 == 1) {
                        strO2 = tc.b.o(parcel, i16);
                    } else if (c14 == 2) {
                        iBinderL2 = tc.b.L(parcel, i16);
                    } else if (c14 == 3) {
                        zJ = tc.b.J(parcel, i16);
                    } else if (c14 != 4) {
                        tc.b.X(parcel, i16);
                    } else {
                        zJ9 = tc.b.J(parcel, i16);
                    }
                }
                tc.b.w(parcel, iY6);
                return new zzt(strO2, iBinderL2, zJ, zJ9);
            case 18:
                int iY7 = tc.b.Y(parcel);
                long jN4 = 0;
                long jN5 = 0;
                int iM9 = 0;
                while (parcel.dataPosition() < iY7) {
                    int i17 = parcel.readInt();
                    char c15 = (char) i17;
                    if (c15 == 1) {
                        jN4 = tc.b.N(parcel, i17);
                    } else if (c15 == 2) {
                        iM9 = tc.b.M(parcel, i17);
                    } else if (c15 != 3) {
                        tc.b.X(parcel, i17);
                    } else {
                        jN5 = tc.b.N(parcel, i17);
                    }
                }
                tc.b.w(parcel, iY7);
                return new zzaf(jN4, jN5, iM9);
            case 19:
                int iY8 = tc.b.Y(parcel);
                long jN6 = 0;
                long jN7 = 0;
                long jN8 = 0;
                boolean zJ10 = false;
                String strO7 = null;
                String strO8 = null;
                zzpl zzplVar = null;
                String strO9 = null;
                zzbh zzbhVar = null;
                zzbh zzbhVar2 = null;
                zzbh zzbhVar3 = null;
                while (parcel.dataPosition() < iY8) {
                    int i18 = parcel.readInt();
                    switch ((char) i18) {
                        case 2:
                            strO7 = tc.b.o(parcel, i18);
                            break;
                        case 3:
                            strO8 = tc.b.o(parcel, i18);
                            break;
                        case 4:
                            zzplVar = (zzpl) tc.b.n(parcel, i18, zzpl.CREATOR);
                            break;
                        case 5:
                            jN6 = tc.b.N(parcel, i18);
                            break;
                        case 6:
                            zJ10 = tc.b.J(parcel, i18);
                            break;
                        case 7:
                            strO9 = tc.b.o(parcel, i18);
                            break;
                        case '\b':
                            zzbhVar = (zzbh) tc.b.n(parcel, i18, zzbh.CREATOR);
                            break;
                        case '\t':
                            jN7 = tc.b.N(parcel, i18);
                            break;
                        case '\n':
                            zzbhVar2 = (zzbh) tc.b.n(parcel, i18, zzbh.CREATOR);
                            break;
                        case r.NETWORK_CLIENT_ERROR_REASON_FIELD_NUMBER /* 11 */:
                            jN8 = tc.b.N(parcel, i18);
                            break;
                        case r.CUSTOM_ATTRIBUTES_FIELD_NUMBER /* 12 */:
                            zzbhVar3 = (zzbh) tc.b.n(parcel, i18, zzbh.CREATOR);
                            break;
                        default:
                            tc.b.X(parcel, i18);
                            break;
                    }
                }
                tc.b.w(parcel, iY8);
                return new zzah(strO7, strO8, zzplVar, jN6, zJ10, strO9, zzbhVar, jN7, zzbhVar2, jN8, zzbhVar3);
            case 20:
                int iY9 = tc.b.Y(parcel);
                while (parcel.dataPosition() < iY9) {
                    int i19 = parcel.readInt();
                    if (((char) i19) != 1) {
                        tc.b.X(parcel, i19);
                    } else {
                        bundleI3 = tc.b.i(parcel, i19);
                    }
                }
                tc.b.w(parcel, iY9);
                return new zzao(bundleI3);
            case 21:
                int iY10 = tc.b.Y(parcel);
                while (parcel.dataPosition() < iY10) {
                    int i20 = parcel.readInt();
                    if (((char) i20) != 2) {
                        tc.b.X(parcel, i20);
                    } else {
                        bundleI2 = tc.b.i(parcel, i20);
                    }
                }
                tc.b.w(parcel, iY10);
                return new zzbf(bundleI2);
            case 22:
                int iY11 = tc.b.Y(parcel);
                long jN9 = 0;
                long jN10 = 0;
                String strO10 = null;
                zzbf zzbfVar = null;
                String strO11 = null;
                while (parcel.dataPosition() < iY11) {
                    int i21 = parcel.readInt();
                    char c16 = (char) i21;
                    if (c16 == 2) {
                        strO10 = tc.b.o(parcel, i21);
                    } else if (c16 == 3) {
                        zzbfVar = (zzbf) tc.b.n(parcel, i21, zzbf.CREATOR);
                    } else if (c16 == 4) {
                        strO11 = tc.b.o(parcel, i21);
                    } else if (c16 == 5) {
                        jN9 = tc.b.N(parcel, i21);
                    } else if (c16 != 6) {
                        tc.b.X(parcel, i21);
                    } else {
                        jN10 = tc.b.N(parcel, i21);
                    }
                }
                tc.b.w(parcel, iY11);
                return new zzbh(strO10, zzbfVar, strO11, jN9, jN10);
            case 23:
                int iY12 = tc.b.Y(parcel);
                while (parcel.dataPosition() < iY12) {
                    int i22 = parcel.readInt();
                    char c17 = (char) i22;
                    if (c17 == 1) {
                        strO = tc.b.o(parcel, i22);
                    } else if (c17 == 2) {
                        jN = tc.b.N(parcel, i22);
                    } else if (c17 != 3) {
                        tc.b.X(parcel, i22);
                    } else {
                        iM2 = tc.b.M(parcel, i22);
                    }
                }
                tc.b.w(parcel, iY12);
                return new zzoh(iM2, strO, jN);
            case 24:
                int iY13 = tc.b.Y(parcel);
                long jN11 = 0;
                long jN12 = 0;
                int iM10 = 0;
                byte[] bArrJ = null;
                String strO12 = null;
                Bundle bundleI4 = null;
                String strO13 = null;
                while (parcel.dataPosition() < iY13) {
                    int i23 = parcel.readInt();
                    switch ((char) i23) {
                        case 1:
                            jN11 = tc.b.N(parcel, i23);
                            break;
                        case 2:
                            bArrJ = tc.b.j(parcel, i23);
                            break;
                        case 3:
                            strO12 = tc.b.o(parcel, i23);
                            break;
                        case 4:
                            bundleI4 = tc.b.i(parcel, i23);
                            break;
                        case 5:
                            iM10 = tc.b.M(parcel, i23);
                            break;
                        case 6:
                            jN12 = tc.b.N(parcel, i23);
                            break;
                        case 7:
                            strO13 = tc.b.o(parcel, i23);
                            break;
                        default:
                            tc.b.X(parcel, i23);
                            break;
                    }
                }
                tc.b.w(parcel, iY13);
                return new zzom(jN11, bArrJ, strO12, bundleI4, iM10, jN12, strO13);
            case 25:
                int iY14 = tc.b.Y(parcel);
                while (true) {
                    ArrayList arrayList = null;
                    while (true) {
                        if (parcel.dataPosition() >= iY14) {
                            tc.b.w(parcel, iY14);
                            return new zzoo(arrayList);
                        }
                        int i24 = parcel.readInt();
                        if (((char) i24) != 1) {
                            tc.b.X(parcel, i24);
                        } else {
                            int iP2 = tc.b.P(parcel, i24);
                            int iDataPosition = parcel.dataPosition();
                            if (iP2 == 0) {
                            }
                            ArrayList arrayList2 = new ArrayList();
                            int i25 = parcel.readInt();
                            for (int i26 = 0; i26 < i25; i26++) {
                                arrayList2.add(Integer.valueOf(parcel.readInt()));
                            }
                            parcel.setDataPosition(iDataPosition + iP2);
                            arrayList = arrayList2;
                        }
                        break;
                    }
                }
                break;
            case 26:
                int iY15 = tc.b.Y(parcel);
                while (parcel.dataPosition() < iY15) {
                    int i27 = parcel.readInt();
                    if (((char) i27) != 1) {
                        tc.b.X(parcel, i27);
                    } else {
                        arrayListS = tc.b.s(parcel, i27, zzom.CREATOR);
                    }
                }
                tc.b.w(parcel, iY15);
                return new zzoq(arrayListS);
            case 27:
                int iY16 = tc.b.Y(parcel);
                long jN13 = 0;
                int iM11 = 0;
                String strO14 = null;
                Long lO = null;
                Float fValueOf = null;
                String strO15 = null;
                String strO16 = null;
                Double dValueOf = null;
                while (parcel.dataPosition() < iY16) {
                    int i28 = parcel.readInt();
                    switch ((char) i28) {
                        case 1:
                            iM11 = tc.b.M(parcel, i28);
                            break;
                        case 2:
                            strO14 = tc.b.o(parcel, i28);
                            break;
                        case 3:
                            jN13 = tc.b.N(parcel, i28);
                            break;
                        case 4:
                            lO = tc.b.O(parcel, i28);
                            break;
                        case 5:
                            int iP3 = tc.b.P(parcel, i28);
                            if (iP3 == 0) {
                                fValueOf = null;
                            } else {
                                tc.b.a0(parcel, iP3, 4);
                                fValueOf = Float.valueOf(parcel.readFloat());
                            }
                            break;
                        case 6:
                            strO15 = tc.b.o(parcel, i28);
                            break;
                        case 7:
                            strO16 = tc.b.o(parcel, i28);
                            break;
                        case '\b':
                            int iP4 = tc.b.P(parcel, i28);
                            if (iP4 == 0) {
                                dValueOf = null;
                            } else {
                                tc.b.a0(parcel, iP4, 8);
                                dValueOf = Double.valueOf(parcel.readDouble());
                            }
                            break;
                        default:
                            tc.b.X(parcel, i28);
                            break;
                    }
                }
                tc.b.w(parcel, iY16);
                return new zzpl(iM11, strO14, jN13, lO, fValueOf, strO15, strO16, dValueOf);
            case 28:
                int iY17 = tc.b.Y(parcel);
                String strO17 = _UrlKt.FRAGMENT_ENCODE_SET;
                String strO18 = strO17;
                String strO19 = strO18;
                String strO20 = strO19;
                int iM12 = 100;
                long jN14 = -2147483648L;
                long jN15 = 0;
                long jN16 = 0;
                long jN17 = 0;
                long jN18 = 0;
                long jN19 = 0;
                long jN20 = 0;
                long jN21 = 0;
                long jN22 = 0;
                boolean zJ11 = true;
                boolean zJ12 = true;
                boolean zJ13 = false;
                int iM13 = 0;
                boolean zJ14 = false;
                boolean zJ15 = false;
                int iM14 = 0;
                int iM15 = 0;
                String strO21 = null;
                String strO22 = null;
                String strO23 = null;
                String strO24 = null;
                String strO25 = null;
                String strO26 = null;
                Boolean boolValueOf = null;
                ArrayList arrayListQ = null;
                String strO27 = null;
                String strO28 = null;
                while (parcel.dataPosition() < iY17) {
                    int i29 = parcel.readInt();
                    switch ((char) i29) {
                        case 2:
                            strO21 = tc.b.o(parcel, i29);
                            break;
                        case 3:
                            strO22 = tc.b.o(parcel, i29);
                            break;
                        case 4:
                            strO23 = tc.b.o(parcel, i29);
                            break;
                        case 5:
                            strO24 = tc.b.o(parcel, i29);
                            break;
                        case 6:
                            jN15 = tc.b.N(parcel, i29);
                            break;
                        case 7:
                            jN16 = tc.b.N(parcel, i29);
                            break;
                        case '\b':
                            strO25 = tc.b.o(parcel, i29);
                            break;
                        case '\t':
                            zJ11 = tc.b.J(parcel, i29);
                            break;
                        case '\n':
                            zJ13 = tc.b.J(parcel, i29);
                            break;
                        case r.NETWORK_CLIENT_ERROR_REASON_FIELD_NUMBER /* 11 */:
                            jN14 = tc.b.N(parcel, i29);
                            break;
                        case r.CUSTOM_ATTRIBUTES_FIELD_NUMBER /* 12 */:
                            strO26 = tc.b.o(parcel, i29);
                            break;
                        case r.PERF_SESSIONS_FIELD_NUMBER /* 13 */:
                        case 17:
                        case 19:
                        case 20:
                        case 24:
                        case '!':
                        default:
                            tc.b.X(parcel, i29);
                            break;
                        case 14:
                            jN17 = tc.b.N(parcel, i29);
                            break;
                        case WebSocketProtocol.B0_MASK_OPCODE /* 15 */:
                            iM13 = tc.b.M(parcel, i29);
                            break;
                        case WebSocketProtocol.B0_FLAG_RSV3 /* 16 */:
                            zJ12 = tc.b.J(parcel, i29);
                            break;
                        case 18:
                            zJ14 = tc.b.J(parcel, i29);
                            break;
                        case 21:
                            int iP5 = tc.b.P(parcel, i29);
                            if (iP5 == 0) {
                                boolValueOf = null;
                            } else {
                                tc.b.a0(parcel, iP5, 4);
                                boolValueOf = Boolean.valueOf(parcel.readInt() != 0);
                            }
                            break;
                        case 22:
                            jN18 = tc.b.N(parcel, i29);
                            break;
                        case 23:
                            arrayListQ = tc.b.q(parcel, i29);
                            break;
                        case 25:
                            strO17 = tc.b.o(parcel, i29);
                            break;
                        case 26:
                            strO18 = tc.b.o(parcel, i29);
                            break;
                        case 27:
                            strO27 = tc.b.o(parcel, i29);
                            break;
                        case 28:
                            zJ15 = tc.b.J(parcel, i29);
                            break;
                        case 29:
                            jN19 = tc.b.N(parcel, i29);
                            break;
                        case 30:
                            iM12 = tc.b.M(parcel, i29);
                            break;
                        case 31:
                            strO19 = tc.b.o(parcel, i29);
                            break;
                        case ' ':
                            iM14 = tc.b.M(parcel, i29);
                            break;
                        case '\"':
                            jN20 = tc.b.N(parcel, i29);
                            break;
                        case '#':
                            strO28 = tc.b.o(parcel, i29);
                            break;
                        case '$':
                            strO20 = tc.b.o(parcel, i29);
                            break;
                        case '%':
                            jN21 = tc.b.N(parcel, i29);
                            break;
                        case '&':
                            iM15 = tc.b.M(parcel, i29);
                            break;
                        case '\'':
                            jN22 = tc.b.N(parcel, i29);
                            break;
                    }
                }
                tc.b.w(parcel, iY17);
                return new com.google.android.gms.measurement.internal.zzr(strO21, strO22, strO23, strO24, jN15, jN16, strO25, zJ11, zJ13, jN14, strO26, jN17, iM13, zJ12, zJ14, boolValueOf, jN18, arrayListQ, strO17, strO18, strO27, zJ15, jN19, iM12, strO19, iM14, jN20, strO28, strO20, jN21, iM15, jN22);
            default:
                return new JWT(parcel.readString());
        }
    }

    @Override // android.os.Parcelable.Creator
    public final Object[] newArray(int i10) {
        switch (this.f696a) {
            case 0:
                return new GoogleSignInOptionsExtensionParcelable[i10];
            case 1:
                return new ColorModel[i10];
            case 2:
                return new ColoredUIComponentModel[i10];
            case 3:
                return new ResponseModel[i10];
            case 4:
                return new SuspensionStatusModel[i10];
            case 5:
                return new SwitchConfirmModel[i10];
            case 6:
                return new SwitchInfoModel[i10];
            case 7:
                return new MediaBrowserCompat$MediaItem[i10];
            case 8:
                return new MediaDescriptionCompat[i10];
            case 9:
                return new MediaMetadataCompat[i10];
            case 10:
                return new RatingCompat[i10];
            case r.NETWORK_CLIENT_ERROR_REASON_FIELD_NUMBER /* 11 */:
                return new ResultReceiver[i10];
            case r.CUSTOM_ATTRIBUTES_FIELD_NUMBER /* 12 */:
                return new DownloadRequest[i10];
            case r.PERF_SESSIONS_FIELD_NUMBER /* 13 */:
                return new ConnectionResult[i10];
            case 14:
                return new Feature[i10];
            case WebSocketProtocol.B0_MASK_OPCODE /* 15 */:
                return new zzp[i10];
            case WebSocketProtocol.B0_FLAG_RSV3 /* 16 */:
                return new zzr[i10];
            case 17:
                return new zzt[i10];
            case 18:
                return new zzaf[i10];
            case 19:
                return new zzah[i10];
            case 20:
                return new zzao[i10];
            case 21:
                return new zzbf[i10];
            case 22:
                return new zzbh[i10];
            case 23:
                return new zzoh[i10];
            case 24:
                return new zzom[i10];
            case 25:
                return new zzoo[i10];
            case 26:
                return new zzoq[i10];
            case 27:
                return new zzpl[i10];
            case 28:
                return new com.google.android.gms.measurement.internal.zzr[i10];
            default:
                return new JWT[i10];
        }
    }
}
