package an;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class n {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final float f948a;

    public n(float f) {
        this.f948a = f;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof n) && Float.compare(this.f948a, ((n) obj).f948a) == 0;
    }

    public final int hashCode() {
        return Float.floatToIntBits(this.f948a);
    }

    public final String toString() {
        return "PaymentInfoViewModel(balance=" + this.f948a + ")";
    }
}
