package an;

import com.google.protobuf.m0;
import java.util.List;
import tm.belet.films.domain.models.profile.ColoredUIComponentModel;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f908a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f909b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final List f910c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final ColoredUIComponentModel f911d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final ColoredUIComponentModel f912e;

    public c(String str, String str2, List list, ColoredUIComponentModel coloredUIComponentModel, ColoredUIComponentModel coloredUIComponentModel2) {
        this.f908a = str;
        this.f909b = str2;
        this.f910c = list;
        this.f911d = coloredUIComponentModel;
        this.f912e = coloredUIComponentModel2;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof c)) {
            return false;
        }
        c cVar = (c) obj;
        return kotlin.jvm.internal.q.c(this.f908a, cVar.f908a) && kotlin.jvm.internal.q.c(this.f909b, cVar.f909b) && kotlin.jvm.internal.q.c(this.f910c, cVar.f910c) && kotlin.jvm.internal.q.c(this.f911d, cVar.f911d) && kotlin.jvm.internal.q.c(this.f912e, cVar.f912e);
    }

    public final int hashCode() {
        String str = this.f908a;
        int iHashCode = (str == null ? 0 : str.hashCode()) * 31;
        String str2 = this.f909b;
        int iHashCode2 = (iHashCode + (str2 == null ? 0 : str2.hashCode())) * 31;
        List list = this.f910c;
        int iHashCode3 = (iHashCode2 + (list == null ? 0 : list.hashCode())) * 31;
        ColoredUIComponentModel coloredUIComponentModel = this.f911d;
        int iHashCode4 = (iHashCode3 + (coloredUIComponentModel == null ? 0 : coloredUIComponentModel.hashCode())) * 31;
        ColoredUIComponentModel coloredUIComponentModel2 = this.f912e;
        return iHashCode4 + (coloredUIComponentModel2 != null ? coloredUIComponentModel2.hashCode() : 0);
    }

    public final String toString() {
        StringBuilder sbN = m0.n("BaseInfoPrompt(title=", this.f908a, ", description=", this.f909b, ", icons=");
        sbN.append(this.f910c);
        sbN.append(", continue_button=");
        sbN.append(this.f911d);
        sbN.append(", skip_button=");
        sbN.append(this.f912e);
        sbN.append(")");
        return sbN.toString();
    }
}
