package an;

import com.google.protobuf.m0;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f923a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f924b;

    public f(String str, String str2) {
        this.f923a = str;
        this.f924b = str2;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof f)) {
            return false;
        }
        f fVar = (f) obj;
        return kotlin.jvm.internal.q.c(this.f923a, fVar.f923a) && kotlin.jvm.internal.q.c(this.f924b, fVar.f924b);
    }

    public final int hashCode() {
        return this.f924b.hashCode() + (this.f923a.hashCode() * 31);
    }

    public final String toString() {
        return m0.j("FeatureModel(icon_url=", this.f923a, ", description=", this.f924b, ")");
    }
}
