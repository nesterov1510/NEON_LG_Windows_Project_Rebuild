package an;

import tm.belet.films.domain.models.profile.ColoredUIComponentModel;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class m {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ColoredUIComponentModel f946a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final ColoredUIComponentModel f947b;

    public m(ColoredUIComponentModel coloredUIComponentModel, ColoredUIComponentModel coloredUIComponentModel2) {
        this.f946a = coloredUIComponentModel;
        this.f947b = coloredUIComponentModel2;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof m)) {
            return false;
        }
        m mVar = (m) obj;
        return kotlin.jvm.internal.q.c(this.f946a, mVar.f946a) && kotlin.jvm.internal.q.c(this.f947b, mVar.f947b);
    }

    public final int hashCode() {
        ColoredUIComponentModel coloredUIComponentModel = this.f946a;
        int iHashCode = (coloredUIComponentModel == null ? 0 : coloredUIComponentModel.hashCode()) * 31;
        ColoredUIComponentModel coloredUIComponentModel2 = this.f947b;
        return iHashCode + (coloredUIComponentModel2 != null ? coloredUIComponentModel2.hashCode() : 0);
    }

    public final String toString() {
        return "NoSubscriptionViewModel(status_message=" + this.f946a + ", plans_button=" + this.f947b + ")";
    }
}
