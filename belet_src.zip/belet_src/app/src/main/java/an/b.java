package an;

import java.util.ArrayList;
import java.util.List;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f906a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final List f907b;

    public b(String str, ArrayList arrayList) {
        this.f906a = str;
        this.f907b = arrayList;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof b)) {
            return false;
        }
        b bVar = (b) obj;
        return kotlin.jvm.internal.q.c(this.f906a, bVar.f906a) && kotlin.jvm.internal.q.c(this.f907b, bVar.f907b);
    }

    public final int hashCode() {
        String str = this.f906a;
        int iHashCode = (str == null ? 0 : str.hashCode()) * 31;
        List list = this.f907b;
        return iHashCode + (list != null ? list.hashCode() : 0);
    }

    public final String toString() {
        return "AvatarGroups(name=" + this.f906a + ", avatars=" + this.f907b + ")";
    }
}
