package an;

import tm.belet.films.domain.models.profile.ColoredUIComponentModel;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class s {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ColoredUIComponentModel f961a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final ColoredUIComponentModel f962b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final ColoredUIComponentModel f963c;

    public s(ColoredUIComponentModel coloredUIComponentModel, ColoredUIComponentModel coloredUIComponentModel2, ColoredUIComponentModel coloredUIComponentModel3) {
        this.f961a = coloredUIComponentModel;
        this.f962b = coloredUIComponentModel2;
        this.f963c = coloredUIComponentModel3;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof s)) {
            return false;
        }
        s sVar = (s) obj;
        return kotlin.jvm.internal.q.c(this.f961a, sVar.f961a) && kotlin.jvm.internal.q.c(this.f962b, sVar.f962b) && kotlin.jvm.internal.q.c(this.f963c, sVar.f963c);
    }

    public final int hashCode() {
        ColoredUIComponentModel coloredUIComponentModel = this.f961a;
        int iHashCode = (coloredUIComponentModel == null ? 0 : coloredUIComponentModel.hashCode()) * 31;
        ColoredUIComponentModel coloredUIComponentModel2 = this.f962b;
        int iHashCode2 = (iHashCode + (coloredUIComponentModel2 == null ? 0 : coloredUIComponentModel2.hashCode())) * 31;
        ColoredUIComponentModel coloredUIComponentModel3 = this.f963c;
        return iHashCode2 + (coloredUIComponentModel3 != null ? coloredUIComponentModel3.hashCode() : 0);
    }

    public final String toString() {
        return "SubscriptionEndsNoticeViewModel(primary_message=" + this.f961a + ", status_message=" + this.f962b + ", renew_button=" + this.f963c + ")";
    }
}
