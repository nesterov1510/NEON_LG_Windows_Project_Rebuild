package an;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class i {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final l f934a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final s f935b;

    public i(l lVar, s sVar) {
        this.f934a = lVar;
        this.f935b = sVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof i)) {
            return false;
        }
        i iVar = (i) obj;
        return kotlin.jvm.internal.q.c(this.f934a, iVar.f934a) && kotlin.jvm.internal.q.c(this.f935b, iVar.f935b);
    }

    public final int hashCode() {
        l lVar = this.f934a;
        int iHashCode = (lVar == null ? 0 : lVar.hashCode()) * 31;
        s sVar = this.f935b;
        return iHashCode + (sVar != null ? sVar.hashCode() : 0);
    }

    public final String toString() {
        return "IndividualSubscriptionNoticeViewModel(no_subscription_view=" + this.f934a + ", subscription_ends_view=" + this.f935b + ")";
    }
}
