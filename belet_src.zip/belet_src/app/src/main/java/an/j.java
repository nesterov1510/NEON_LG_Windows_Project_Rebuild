package an;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class j {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final t f936a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final m f937b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final n f938c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final e f939d;

    public j(t tVar, m mVar, n nVar, e eVar) {
        this.f936a = tVar;
        this.f937b = mVar;
        this.f938c = nVar;
        this.f939d = eVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof j)) {
            return false;
        }
        j jVar = (j) obj;
        return kotlin.jvm.internal.q.c(this.f936a, jVar.f936a) && kotlin.jvm.internal.q.c(this.f937b, jVar.f937b) && kotlin.jvm.internal.q.c(this.f938c, jVar.f938c) && kotlin.jvm.internal.q.c(this.f939d, jVar.f939d);
    }

    public final int hashCode() {
        t tVar = this.f936a;
        int iHashCode = (tVar == null ? 0 : tVar.hashCode()) * 31;
        m mVar = this.f937b;
        int iHashCode2 = (iHashCode + (mVar == null ? 0 : mVar.hashCode())) * 31;
        n nVar = this.f938c;
        int iFloatToIntBits = (iHashCode2 + (nVar == null ? 0 : Float.floatToIntBits(nVar.f948a))) * 31;
        e eVar = this.f939d;
        return iFloatToIntBits + (eVar != null ? eVar.hashCode() : 0);
    }

    public final String toString() {
        return "IndividualSubscriptionPageViewModel(subscription_info_view=" + this.f936a + ", no_subscription_info_view=" + this.f937b + ", payment_info_view=" + this.f938c + ", exclusive_access_info_view=" + this.f939d + ")";
    }
}
