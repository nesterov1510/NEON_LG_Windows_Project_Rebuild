package an;

import com.google.protobuf.m0;
import java.util.List;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f918a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f919b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final String f920c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final String f921d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final Object f922e;

    public e(String str, String str2, String str3, String str4, List list) {
        this.f918a = str;
        this.f919b = str2;
        this.f920c = str3;
        this.f921d = str4;
        this.f922e = list;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof e)) {
            return false;
        }
        e eVar = (e) obj;
        return this.f918a.equals(eVar.f918a) && this.f919b.equals(eVar.f919b) && this.f920c.equals(eVar.f920c) && this.f921d.equals(eVar.f921d) && this.f922e.equals(eVar.f922e);
    }

    public final int hashCode() {
        return this.f922e.hashCode() + m0.h(m0.h(m0.h(this.f918a.hashCode() * 31, 31, this.f919b), 31, this.f920c), 31, this.f921d);
    }

    public final String toString() {
        StringBuilder sbN = m0.n("ExclusiveAccessInfoViewModel(code=", this.f918a, ", name=", this.f919b, ", description=");
        kotlin.jvm.internal.p.O(sbN, this.f920c, ", price=", this.f921d, ", features=");
        return kotlin.jvm.internal.p.C(sbN, this.f922e, ")");
    }
}
