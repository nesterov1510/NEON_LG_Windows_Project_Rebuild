package an;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class u {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final long f970a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f971b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final d f972c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Integer f973d;

    public u(long j10, int i10, d dVar, Integer num) {
        this.f970a = j10;
        this.f971b = i10;
        this.f972c = dVar;
        this.f973d = num;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof u)) {
            return false;
        }
        u uVar = (u) obj;
        return this.f970a == uVar.f970a && this.f971b == uVar.f971b && kotlin.jvm.internal.q.c(this.f972c, uVar.f972c) && kotlin.jvm.internal.q.c(this.f973d, uVar.f973d);
    }

    public final int hashCode() {
        long j10 = this.f970a;
        int i10 = ((((int) (j10 ^ (j10 >>> 32))) * 31) + this.f971b) * 31;
        d dVar = this.f972c;
        int iHashCode = (i10 + (dVar == null ? 0 : dVar.hashCode())) * 31;
        Integer num = this.f973d;
        return iHashCode + (num != null ? num.hashCode() : 0);
    }

    public final String toString() {
        return "UserInfoViewModel(phone=" + this.f970a + ", mode_type=" + this.f971b + ", base_info=" + this.f972c + ", download_limit=" + this.f973d + ")";
    }
}
