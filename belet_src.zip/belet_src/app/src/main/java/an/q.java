package an;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class q {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final p f955a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final j f956b;

    public q(p pVar, j jVar) {
        this.f955a = pVar;
        this.f956b = jVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof q)) {
            return false;
        }
        q qVar = (q) obj;
        return kotlin.jvm.internal.q.c(this.f955a, qVar.f955a) && kotlin.jvm.internal.q.c(this.f956b, qVar.f956b);
    }

    public final int hashCode() {
        p pVar = this.f955a;
        int iHashCode = (pVar == null ? 0 : pVar.hashCode()) * 31;
        j jVar = this.f956b;
        return iHashCode + (jVar != null ? jVar.hashCode() : 0);
    }

    public final String toString() {
        return "ProfileV2Model(profile_page_view=" + this.f955a + ", individual_subscription_page_view=" + this.f956b + ")";
    }
}
