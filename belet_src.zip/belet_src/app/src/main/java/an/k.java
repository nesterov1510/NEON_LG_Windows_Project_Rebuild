package an;

import com.google.protobuf.m0;
import tm.belet.films.domain.models.profile.ColoredUIComponentModel;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class k {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f940a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f941b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final ColoredUIComponentModel f942c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final ColoredUIComponentModel f943d;

    public k(String str, String str2, ColoredUIComponentModel coloredUIComponentModel, ColoredUIComponentModel coloredUIComponentModel2) {
        this.f940a = str;
        this.f941b = str2;
        this.f942c = coloredUIComponentModel;
        this.f943d = coloredUIComponentModel2;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof k)) {
            return false;
        }
        k kVar = (k) obj;
        return kotlin.jvm.internal.q.c(this.f940a, kVar.f940a) && kotlin.jvm.internal.q.c(this.f941b, kVar.f941b) && kotlin.jvm.internal.q.c(this.f942c, kVar.f942c) && kotlin.jvm.internal.q.c(this.f943d, kVar.f943d);
    }

    public final int hashCode() {
        int iH = m0.h(this.f940a.hashCode() * 31, 31, this.f941b);
        ColoredUIComponentModel coloredUIComponentModel = this.f942c;
        int iHashCode = (iH + (coloredUIComponentModel == null ? 0 : coloredUIComponentModel.hashCode())) * 31;
        ColoredUIComponentModel coloredUIComponentModel2 = this.f943d;
        return iHashCode + (coloredUIComponentModel2 != null ? coloredUIComponentModel2.hashCode() : 0);
    }

    public final String toString() {
        StringBuilder sbN = m0.n("IndividualSubscriptionViewModel(subscription_code=", this.f940a, ", subscription_name=", this.f941b, ", status_message=");
        sbN.append(this.f942c);
        sbN.append(", manage_button=");
        sbN.append(this.f943d);
        sbN.append(")");
        return sbN.toString();
    }
}
