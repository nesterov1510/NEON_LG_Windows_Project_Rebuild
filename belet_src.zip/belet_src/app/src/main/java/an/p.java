package an;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class p {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final u f950a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final k f951b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final r f952c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final h f953d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final i f954e;

    public p(u uVar, k kVar, r rVar, h hVar, i iVar) {
        this.f950a = uVar;
        this.f951b = kVar;
        this.f952c = rVar;
        this.f953d = hVar;
        this.f954e = iVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof p)) {
            return false;
        }
        p pVar = (p) obj;
        return kotlin.jvm.internal.q.c(this.f950a, pVar.f950a) && kotlin.jvm.internal.q.c(this.f951b, pVar.f951b) && kotlin.jvm.internal.q.c(this.f952c, pVar.f952c) && kotlin.jvm.internal.q.c(this.f953d, pVar.f953d) && kotlin.jvm.internal.q.c(this.f954e, pVar.f954e);
    }

    public final int hashCode() {
        u uVar = this.f950a;
        int iHashCode = (uVar == null ? 0 : uVar.hashCode()) * 31;
        k kVar = this.f951b;
        int iHashCode2 = (iHashCode + (kVar == null ? 0 : kVar.hashCode())) * 31;
        r rVar = this.f952c;
        int iHashCode3 = (iHashCode2 + (rVar == null ? 0 : rVar.hashCode())) * 31;
        h hVar = this.f953d;
        int iHashCode4 = (iHashCode3 + (hVar == null ? 0 : hVar.hashCode())) * 31;
        i iVar = this.f954e;
        return iHashCode4 + (iVar != null ? iVar.hashCode() : 0);
    }

    public final String toString() {
        return "ProfilePageViewModel(user_info_view=" + this.f950a + ", individual_subscription_view=" + this.f951b + ", provider_subscription_view=" + this.f952c + ", individual_subscription_manage_view=" + this.f953d + ", subscription_notice_view=" + this.f954e + ")";
    }
}
