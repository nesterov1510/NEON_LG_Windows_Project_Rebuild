package an;

import tm.belet.films.domain.models.profile.ColoredUIComponentModel;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class h {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ColoredUIComponentModel f932a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final ColoredUIComponentModel f933b;

    public h(ColoredUIComponentModel coloredUIComponentModel, ColoredUIComponentModel coloredUIComponentModel2) {
        this.f932a = coloredUIComponentModel;
        this.f933b = coloredUIComponentModel2;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof h)) {
            return false;
        }
        h hVar = (h) obj;
        return kotlin.jvm.internal.q.c(this.f932a, hVar.f932a) && kotlin.jvm.internal.q.c(this.f933b, hVar.f933b);
    }

    public final int hashCode() {
        ColoredUIComponentModel coloredUIComponentModel = this.f932a;
        int iHashCode = (coloredUIComponentModel == null ? 0 : coloredUIComponentModel.hashCode()) * 31;
        ColoredUIComponentModel coloredUIComponentModel2 = this.f933b;
        return iHashCode + (coloredUIComponentModel2 != null ? coloredUIComponentModel2.hashCode() : 0);
    }

    public final String toString() {
        return "IndividualSubscriptionManageViewModel(status_message=" + this.f932a + ", manage_button=" + this.f933b + ")";
    }
}
