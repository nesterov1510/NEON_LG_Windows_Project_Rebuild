package an;

import com.google.protobuf.m0;
import tm.belet.films.domain.models.profile.ColoredUIComponentModel;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class t {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f964a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f965b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final ColoredUIComponentModel f966c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final ColoredUIComponentModel f967d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final ColoredUIComponentModel f968e;
    public final ColoredUIComponentModel f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final ColoredUIComponentModel f969g;

    public t(String str, String str2, ColoredUIComponentModel coloredUIComponentModel, ColoredUIComponentModel coloredUIComponentModel2, ColoredUIComponentModel coloredUIComponentModel3, ColoredUIComponentModel coloredUIComponentModel4, ColoredUIComponentModel coloredUIComponentModel5) {
        this.f964a = str;
        this.f965b = str2;
        this.f966c = coloredUIComponentModel;
        this.f967d = coloredUIComponentModel2;
        this.f968e = coloredUIComponentModel3;
        this.f = coloredUIComponentModel4;
        this.f969g = coloredUIComponentModel5;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof t)) {
            return false;
        }
        t tVar = (t) obj;
        return kotlin.jvm.internal.q.c(this.f964a, tVar.f964a) && kotlin.jvm.internal.q.c(this.f965b, tVar.f965b) && kotlin.jvm.internal.q.c(this.f966c, tVar.f966c) && kotlin.jvm.internal.q.c(this.f967d, tVar.f967d) && kotlin.jvm.internal.q.c(this.f968e, tVar.f968e) && kotlin.jvm.internal.q.c(this.f, tVar.f) && kotlin.jvm.internal.q.c(this.f969g, tVar.f969g);
    }

    public final int hashCode() {
        int iH = m0.h(this.f964a.hashCode() * 31, 31, this.f965b);
        ColoredUIComponentModel coloredUIComponentModel = this.f966c;
        int iHashCode = (iH + (coloredUIComponentModel == null ? 0 : coloredUIComponentModel.hashCode())) * 31;
        ColoredUIComponentModel coloredUIComponentModel2 = this.f967d;
        int iHashCode2 = (iHashCode + (coloredUIComponentModel2 == null ? 0 : coloredUIComponentModel2.hashCode())) * 31;
        ColoredUIComponentModel coloredUIComponentModel3 = this.f968e;
        int iHashCode3 = (iHashCode2 + (coloredUIComponentModel3 == null ? 0 : coloredUIComponentModel3.hashCode())) * 31;
        ColoredUIComponentModel coloredUIComponentModel4 = this.f;
        int iHashCode4 = (iHashCode3 + (coloredUIComponentModel4 == null ? 0 : coloredUIComponentModel4.hashCode())) * 31;
        ColoredUIComponentModel coloredUIComponentModel5 = this.f969g;
        return iHashCode4 + (coloredUIComponentModel5 != null ? coloredUIComponentModel5.hashCode() : 0);
    }

    public final String toString() {
        StringBuilder sbN = m0.n("SubscriptionInfoViewModel(subscription_code=", this.f964a, ", subscription_name=", this.f965b, ", plans_button=");
        sbN.append(this.f966c);
        sbN.append(", renew_button=");
        sbN.append(this.f967d);
        sbN.append(", stay_on_plan_button=");
        sbN.append(this.f968e);
        sbN.append(", primary_message=");
        sbN.append(this.f);
        sbN.append(", status_message=");
        sbN.append(this.f969g);
        sbN.append(")");
        return sbN.toString();
    }
}
