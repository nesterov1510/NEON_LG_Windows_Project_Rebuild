package an;

import com.google.protobuf.m0;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f913a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f914b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final String f915c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final String f916d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final String f917e;

    public d(String str, String str2, String str3, String str4, String str5) {
        this.f913a = str;
        this.f914b = str2;
        this.f915c = str3;
        this.f916d = str4;
        this.f917e = str5;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof d)) {
            return false;
        }
        d dVar = (d) obj;
        return kotlin.jvm.internal.q.c(this.f913a, dVar.f913a) && kotlin.jvm.internal.q.c(this.f914b, dVar.f914b) && kotlin.jvm.internal.q.c(this.f915c, dVar.f915c) && kotlin.jvm.internal.q.c(this.f916d, dVar.f916d) && kotlin.jvm.internal.q.c(this.f917e, dVar.f917e);
    }

    public final int hashCode() {
        String str = this.f913a;
        int iHashCode = (str == null ? 0 : str.hashCode()) * 31;
        String str2 = this.f914b;
        int iH = m0.h((iHashCode + (str2 == null ? 0 : str2.hashCode())) * 31, 31, this.f915c);
        String str3 = this.f916d;
        int iHashCode2 = (iH + (str3 == null ? 0 : str3.hashCode())) * 31;
        String str4 = this.f917e;
        return iHashCode2 + (str4 != null ? str4.hashCode() : 0);
    }

    public final String toString() {
        StringBuilder sbN = m0.n("BaseInfoView(username=", this.f913a, ", date_of_birth=", this.f914b, ", gender=");
        kotlin.jvm.internal.p.O(sbN, this.f915c, ", avatar_url=", this.f916d, ", phone_qr_code=");
        return a0.f.r(sbN, this.f917e, ")");
    }
}
