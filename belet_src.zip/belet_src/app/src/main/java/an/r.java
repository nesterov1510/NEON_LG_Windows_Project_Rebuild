package an;

import com.google.protobuf.m0;
import tm.belet.films.domain.models.profile.ColoredUIComponentModel;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class r {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f957a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f958b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final ColoredUIComponentModel f959c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final ColoredUIComponentModel f960d;

    public r(String str, String str2, ColoredUIComponentModel coloredUIComponentModel, ColoredUIComponentModel coloredUIComponentModel2) {
        this.f957a = str;
        this.f958b = str2;
        this.f959c = coloredUIComponentModel;
        this.f960d = coloredUIComponentModel2;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof r)) {
            return false;
        }
        r rVar = (r) obj;
        return kotlin.jvm.internal.q.c(this.f957a, rVar.f957a) && kotlin.jvm.internal.q.c(this.f958b, rVar.f958b) && kotlin.jvm.internal.q.c(this.f959c, rVar.f959c) && kotlin.jvm.internal.q.c(this.f960d, rVar.f960d);
    }

    public final int hashCode() {
        int iH = m0.h(this.f957a.hashCode() * 31, 31, this.f958b);
        ColoredUIComponentModel coloredUIComponentModel = this.f959c;
        int iHashCode = (iH + (coloredUIComponentModel == null ? 0 : coloredUIComponentModel.hashCode())) * 31;
        ColoredUIComponentModel coloredUIComponentModel2 = this.f960d;
        return iHashCode + (coloredUIComponentModel2 != null ? coloredUIComponentModel2.hashCode() : 0);
    }

    public final String toString() {
        StringBuilder sbN = m0.n("ProviderSubscriptionViewModel(subscription_code=", this.f957a, ", subscription_name=", this.f958b, ", status_message=");
        sbN.append(this.f959c);
        sbN.append(", manage_message=");
        sbN.append(this.f960d);
        sbN.append(")");
        return sbN.toString();
    }
}
