package an;

import java.util.List;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class o {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Object f949a;

    public o(List list) {
        this.f949a = list;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof o) && this.f949a.equals(((o) obj).f949a);
    }

    public final int hashCode() {
        return this.f949a.hashCode();
    }

    public final String toString() {
        return "ProfileAvatars(categories=" + this.f949a + ")";
    }
}
