package an;

import com.google.protobuf.m0;
import tm.belet.films.domain.models.profile.ColoredUIComponentModel;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class g {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f925a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f926b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final String f927c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Long f928d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final String f929e;
    public final String f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final hm.m f930g;
    public final hm.m h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final ColoredUIComponentModel f931i;

    public g(String str, String str2, String str3, Long l10, String str4, String str5, hm.m mVar, hm.m mVar2, ColoredUIComponentModel coloredUIComponentModel) {
        this.f925a = str;
        this.f926b = str2;
        this.f927c = str3;
        this.f928d = l10;
        this.f929e = str4;
        this.f = str5;
        this.f930g = mVar;
        this.h = mVar2;
        this.f931i = coloredUIComponentModel;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof g)) {
            return false;
        }
        g gVar = (g) obj;
        return kotlin.jvm.internal.q.c(this.f925a, gVar.f925a) && kotlin.jvm.internal.q.c(this.f926b, gVar.f926b) && kotlin.jvm.internal.q.c(this.f927c, gVar.f927c) && kotlin.jvm.internal.q.c(this.f928d, gVar.f928d) && kotlin.jvm.internal.q.c(this.f929e, gVar.f929e) && kotlin.jvm.internal.q.c(this.f, gVar.f) && kotlin.jvm.internal.q.c(this.f930g, gVar.f930g) && kotlin.jvm.internal.q.c(this.h, gVar.h) && kotlin.jvm.internal.q.c(this.f931i, gVar.f931i);
    }

    public final int hashCode() {
        String str = this.f925a;
        int iHashCode = (str == null ? 0 : str.hashCode()) * 31;
        String str2 = this.f926b;
        int iHashCode2 = (iHashCode + (str2 == null ? 0 : str2.hashCode())) * 31;
        String str3 = this.f927c;
        int iHashCode3 = (iHashCode2 + (str3 == null ? 0 : str3.hashCode())) * 31;
        Long l10 = this.f928d;
        int iHashCode4 = (iHashCode3 + (l10 == null ? 0 : l10.hashCode())) * 31;
        String str4 = this.f929e;
        int iHashCode5 = (iHashCode4 + (str4 == null ? 0 : str4.hashCode())) * 31;
        String str5 = this.f;
        int iHashCode6 = (iHashCode5 + (str5 == null ? 0 : str5.hashCode())) * 31;
        hm.m mVar = this.f930g;
        int iHashCode7 = (iHashCode6 + (mVar == null ? 0 : mVar.hashCode())) * 31;
        hm.m mVar2 = this.h;
        int iHashCode8 = (iHashCode7 + (mVar2 == null ? 0 : mVar2.hashCode())) * 31;
        ColoredUIComponentModel coloredUIComponentModel = this.f931i;
        return iHashCode8 + (coloredUIComponentModel != null ? coloredUIComponentModel.hashCode() : 0);
    }

    public final String toString() {
        StringBuilder sbN = m0.n("GiftReceivedInfo(title=", this.f925a, ", description=", this.f926b, ", card_url=");
        sbN.append(this.f927c);
        sbN.append(", amount=");
        sbN.append(this.f928d);
        sbN.append(", date=");
        kotlin.jvm.internal.p.O(sbN, this.f929e, ", message=", this.f, ", sender=");
        sbN.append(this.f930g);
        sbN.append(", receiver=");
        sbN.append(this.h);
        sbN.append(", button=");
        sbN.append(this.f931i);
        sbN.append(")");
        return sbN.toString();
    }
}
