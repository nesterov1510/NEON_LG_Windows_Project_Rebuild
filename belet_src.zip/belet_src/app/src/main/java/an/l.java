package an;

import tm.belet.films.domain.models.profile.ColoredUIComponentModel;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class l {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ColoredUIComponentModel f944a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final ColoredUIComponentModel f945b;

    public l(ColoredUIComponentModel coloredUIComponentModel, ColoredUIComponentModel coloredUIComponentModel2) {
        this.f944a = coloredUIComponentModel;
        this.f945b = coloredUIComponentModel2;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof l)) {
            return false;
        }
        l lVar = (l) obj;
        return kotlin.jvm.internal.q.c(this.f944a, lVar.f944a) && kotlin.jvm.internal.q.c(this.f945b, lVar.f945b);
    }

    public final int hashCode() {
        ColoredUIComponentModel coloredUIComponentModel = this.f944a;
        int iHashCode = (coloredUIComponentModel == null ? 0 : coloredUIComponentModel.hashCode()) * 31;
        ColoredUIComponentModel coloredUIComponentModel2 = this.f945b;
        return iHashCode + (coloredUIComponentModel2 != null ? coloredUIComponentModel2.hashCode() : 0);
    }

    public final String toString() {
        return "NoSubscriptionNoticeViewModel(message=" + this.f944a + ", plans_button=" + this.f945b + ")";
    }
}
