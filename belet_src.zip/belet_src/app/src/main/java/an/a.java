package an;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Boolean f904a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f905b;

    public a(Boolean bool, String str) {
        this.f904a = bool;
        this.f905b = str;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof a)) {
            return false;
        }
        a aVar = (a) obj;
        return kotlin.jvm.internal.q.c(this.f904a, aVar.f904a) && kotlin.jvm.internal.q.c(this.f905b, aVar.f905b);
    }

    public final int hashCode() {
        Boolean bool = this.f904a;
        int iHashCode = (bool == null ? 0 : bool.hashCode()) * 31;
        String str = this.f905b;
        return iHashCode + (str != null ? str.hashCode() : 0);
    }

    public final String toString() {
        return "Avatar(is_selected=" + this.f904a + ", url=" + this.f905b + ")";
    }
}
