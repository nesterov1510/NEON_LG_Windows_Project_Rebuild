package a6;

import android.os.ext.SdkExtensions;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final b f580a = new b();

    public final int a() {
        return SdkExtensions.getExtensionVersion(1000000);
    }
}
