package al;

import kotlinx.serialization.internal.e2;
import kotlinx.serialization.internal.i1;
import kotlinx.serialization.internal.l0;
import kotlinx.serialization.internal.n0;
import kotlinx.serialization.internal.u2;
import tm.belet.films.data.response.home.ImagesDTO;
import tm.belet.films.data.response.home.ImagesDTO$$serializer;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class c0 implements n0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final c0 f825a;
    private static final kotlinx.serialization.descriptors.g descriptor;

    static {
        c0 c0Var = new c0();
        f825a = c0Var;
        e2 e2Var = new e2("tm.belet.films.data.response.events.TournamentDTO", c0Var, 6);
        e2Var.addElement("id", false);
        e2Var.addElement("title", false);
        e2Var.addElement("images", false);
        e2Var.addElement("is_subscribed", false);
        e2Var.addElement("subscribers_count", false);
        e2Var.addElement("partner_logo_url", false);
        descriptor = e2Var;
    }

    @Override // kotlinx.serialization.internal.n0
    public final kotlinx.serialization.b[] childSerializers() {
        i1 i1Var = i1.INSTANCE;
        kotlinx.serialization.b nullable = wj.a.getNullable(i1Var);
        u2 u2Var = u2.INSTANCE;
        return new kotlinx.serialization.b[]{nullable, wj.a.getNullable(u2Var), wj.a.getNullable(ImagesDTO$$serializer.INSTANCE), wj.a.getNullable(kotlinx.serialization.internal.i.INSTANCE), wj.a.getNullable(i1Var), wj.a.getNullable(u2Var)};
    }

    @Override // kotlinx.serialization.internal.n0, kotlinx.serialization.b, kotlinx.serialization.a
    public final Object deserialize(kotlinx.serialization.encoding.j decoder) {
        int i10;
        Long l10;
        String str;
        ImagesDTO imagesDTO;
        Boolean bool;
        Long l11;
        String str2;
        kotlin.jvm.internal.q.g(decoder, "decoder");
        kotlinx.serialization.descriptors.g gVar = descriptor;
        kotlinx.serialization.encoding.f fVarBeginStructure = decoder.beginStructure(gVar);
        int i11 = 5;
        Long l12 = null;
        if (fVarBeginStructure.decodeSequentially()) {
            i1 i1Var = i1.INSTANCE;
            Long l13 = (Long) fVarBeginStructure.decodeNullableSerializableElement(gVar, 0, i1Var, null);
            u2 u2Var = u2.INSTANCE;
            String str3 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 1, u2Var, null);
            ImagesDTO imagesDTO2 = (ImagesDTO) fVarBeginStructure.decodeNullableSerializableElement(gVar, 2, ImagesDTO$$serializer.INSTANCE, null);
            Boolean bool2 = (Boolean) fVarBeginStructure.decodeNullableSerializableElement(gVar, 3, kotlinx.serialization.internal.i.INSTANCE, null);
            l11 = (Long) fVarBeginStructure.decodeNullableSerializableElement(gVar, 4, i1Var, null);
            str2 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 5, u2Var, null);
            bool = bool2;
            i10 = 63;
            imagesDTO = imagesDTO2;
            str = str3;
            l10 = l13;
        } else {
            boolean z5 = true;
            int i12 = 0;
            String str4 = null;
            ImagesDTO imagesDTO3 = null;
            Boolean bool3 = null;
            Long l14 = null;
            String str5 = null;
            while (z5) {
                int iDecodeElementIndex = fVarBeginStructure.decodeElementIndex(gVar);
                switch (iDecodeElementIndex) {
                    case -1:
                        z5 = false;
                        i11 = 5;
                        break;
                    case 0:
                        l12 = (Long) fVarBeginStructure.decodeNullableSerializableElement(gVar, 0, i1.INSTANCE, l12);
                        i12 |= 1;
                        i11 = 5;
                        break;
                    case 1:
                        str4 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 1, u2.INSTANCE, str4);
                        i12 |= 2;
                        break;
                    case 2:
                        imagesDTO3 = (ImagesDTO) fVarBeginStructure.decodeNullableSerializableElement(gVar, 2, ImagesDTO$$serializer.INSTANCE, imagesDTO3);
                        i12 |= 4;
                        break;
                    case 3:
                        bool3 = (Boolean) fVarBeginStructure.decodeNullableSerializableElement(gVar, 3, kotlinx.serialization.internal.i.INSTANCE, bool3);
                        i12 |= 8;
                        break;
                    case 4:
                        l14 = (Long) fVarBeginStructure.decodeNullableSerializableElement(gVar, 4, i1.INSTANCE, l14);
                        i12 |= 16;
                        break;
                    case 5:
                        str5 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, i11, u2.INSTANCE, str5);
                        i12 |= 32;
                        break;
                    default:
                        throw new kotlinx.serialization.t(iDecodeElementIndex);
                }
            }
            i10 = i12;
            l10 = l12;
            str = str4;
            imagesDTO = imagesDTO3;
            bool = bool3;
            l11 = l14;
            str2 = str5;
        }
        fVarBeginStructure.endStructure(gVar);
        return new e0(i10, l10, str, imagesDTO, bool, l11, str2);
    }

    @Override // kotlinx.serialization.internal.n0, kotlinx.serialization.b, kotlinx.serialization.l, kotlinx.serialization.a
    public final kotlinx.serialization.descriptors.g getDescriptor() {
        return descriptor;
    }

    @Override // kotlinx.serialization.internal.n0, kotlinx.serialization.b, kotlinx.serialization.l
    public final void serialize(kotlinx.serialization.encoding.l encoder, Object obj) {
        e0 value = (e0) obj;
        kotlin.jvm.internal.q.g(encoder, "encoder");
        kotlin.jvm.internal.q.g(value, "value");
        kotlinx.serialization.descriptors.g gVar = descriptor;
        kotlinx.serialization.encoding.h hVarBeginStructure = encoder.beginStructure(gVar);
        i1 i1Var = i1.INSTANCE;
        hVarBeginStructure.encodeNullableSerializableElement(gVar, 0, i1Var, value.f827a);
        u2 u2Var = u2.INSTANCE;
        hVarBeginStructure.encodeNullableSerializableElement(gVar, 1, u2Var, value.f828b);
        hVarBeginStructure.encodeNullableSerializableElement(gVar, 2, ImagesDTO$$serializer.INSTANCE, value.f829c);
        hVarBeginStructure.encodeNullableSerializableElement(gVar, 3, kotlinx.serialization.internal.i.INSTANCE, value.f830d);
        hVarBeginStructure.encodeNullableSerializableElement(gVar, 4, i1Var, value.f831e);
        hVarBeginStructure.encodeNullableSerializableElement(gVar, 5, u2Var, value.f);
        hVarBeginStructure.endStructure(gVar);
    }

    @Override // kotlinx.serialization.internal.n0
    public final /* bridge */ kotlinx.serialization.b[] typeParametersSerializers() {
        return l0.a(this);
    }
}
