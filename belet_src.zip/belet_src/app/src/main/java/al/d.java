package al;

import kotlinx.serialization.internal.e2;
import kotlinx.serialization.internal.i1;
import kotlinx.serialization.internal.l0;
import kotlinx.serialization.internal.n0;
import kotlinx.serialization.internal.u2;
import kotlinx.serialization.internal.x0;
import okio.internal.Buffer;
import tm.belet.films.data.response.home.ImagesDTO;
import tm.belet.films.data.response.home.ImagesDTO$$serializer;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class d implements n0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final d f826a;
    private static final kotlinx.serialization.descriptors.g descriptor;

    static {
        d dVar = new d();
        f826a = dVar;
        e2 e2Var = new e2("tm.belet.films.data.response.events.EventDTO", dVar, 15);
        e2Var.addElement("id", false);
        e2Var.addElement("title", false);
        e2Var.addElement("images", false);
        e2Var.addElement("tournament_title", false);
        e2Var.addElement("is_notification_enabled", false);
        e2Var.addElement("status", false);
        e2Var.addElement("hls", false);
        e2Var.addElement("views", false);
        e2Var.addElement("age_restriction", false);
        e2Var.addElement("tournament_id", false);
        e2Var.addElement("tournament_images", false);
        e2Var.addElement("is_tournament_subscribed", false);
        e2Var.addElement("tournament_subscribers_count", false);
        e2Var.addElement("start_time_in_unix", false);
        e2Var.addElement("voting_text", false);
        descriptor = e2Var;
    }

    @Override // kotlinx.serialization.internal.n0
    public final kotlinx.serialization.b[] childSerializers() {
        x0 x0Var = x0.INSTANCE;
        kotlinx.serialization.b nullable = wj.a.getNullable(x0Var);
        u2 u2Var = u2.INSTANCE;
        kotlinx.serialization.b nullable2 = wj.a.getNullable(u2Var);
        ImagesDTO$$serializer imagesDTO$$serializer = ImagesDTO$$serializer.INSTANCE;
        kotlinx.serialization.b nullable3 = wj.a.getNullable(imagesDTO$$serializer);
        kotlinx.serialization.b nullable4 = wj.a.getNullable(u2Var);
        kotlinx.serialization.internal.i iVar = kotlinx.serialization.internal.i.INSTANCE;
        kotlinx.serialization.b nullable5 = wj.a.getNullable(iVar);
        kotlinx.serialization.b nullable6 = wj.a.getNullable(u2Var);
        kotlinx.serialization.b nullable7 = wj.a.getNullable(u2Var);
        i1 i1Var = i1.INSTANCE;
        return new kotlinx.serialization.b[]{nullable, nullable2, nullable3, nullable4, nullable5, nullable6, nullable7, wj.a.getNullable(i1Var), wj.a.getNullable(a.f816a), wj.a.getNullable(x0Var), wj.a.getNullable(imagesDTO$$serializer), wj.a.getNullable(iVar), wj.a.getNullable(i1Var), wj.a.getNullable(i1Var), wj.a.getNullable(u2Var)};
    }

    @Override // kotlinx.serialization.internal.n0, kotlinx.serialization.b, kotlinx.serialization.a
    public final Object deserialize(kotlinx.serialization.encoding.j decoder) {
        String str;
        Integer num;
        String str2;
        String str3;
        Boolean bool;
        Long l10;
        Long l11;
        Boolean bool2;
        Integer num2;
        String str4;
        ImagesDTO imagesDTO;
        c cVar;
        ImagesDTO imagesDTO2;
        Long l12;
        int i10;
        ImagesDTO imagesDTO3;
        kotlin.jvm.internal.q.g(decoder, "decoder");
        kotlinx.serialization.descriptors.g gVar = descriptor;
        kotlinx.serialization.encoding.f fVarBeginStructure = decoder.beginStructure(gVar);
        String str5 = null;
        if (fVarBeginStructure.decodeSequentially()) {
            x0 x0Var = x0.INSTANCE;
            Integer num3 = (Integer) fVarBeginStructure.decodeNullableSerializableElement(gVar, 0, x0Var, null);
            u2 u2Var = u2.INSTANCE;
            String str6 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 1, u2Var, null);
            ImagesDTO$$serializer imagesDTO$$serializer = ImagesDTO$$serializer.INSTANCE;
            ImagesDTO imagesDTO4 = (ImagesDTO) fVarBeginStructure.decodeNullableSerializableElement(gVar, 2, imagesDTO$$serializer, null);
            String str7 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 3, u2Var, null);
            kotlinx.serialization.internal.i iVar = kotlinx.serialization.internal.i.INSTANCE;
            Boolean bool3 = (Boolean) fVarBeginStructure.decodeNullableSerializableElement(gVar, 4, iVar, null);
            String str8 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 5, u2Var, null);
            String str9 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 6, u2Var, null);
            i1 i1Var = i1.INSTANCE;
            Long l13 = (Long) fVarBeginStructure.decodeNullableSerializableElement(gVar, 7, i1Var, null);
            str = str6;
            c cVar2 = (c) fVarBeginStructure.decodeNullableSerializableElement(gVar, 8, a.f816a, null);
            Integer num4 = (Integer) fVarBeginStructure.decodeNullableSerializableElement(gVar, 9, x0Var, null);
            ImagesDTO imagesDTO5 = (ImagesDTO) fVarBeginStructure.decodeNullableSerializableElement(gVar, 10, imagesDTO$$serializer, null);
            Boolean bool4 = (Boolean) fVarBeginStructure.decodeNullableSerializableElement(gVar, 11, iVar, null);
            Long l14 = (Long) fVarBeginStructure.decodeNullableSerializableElement(gVar, 12, i1Var, null);
            Long l15 = (Long) fVarBeginStructure.decodeNullableSerializableElement(gVar, 13, i1Var, null);
            str5 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 14, u2Var, null);
            l10 = l15;
            cVar = cVar2;
            imagesDTO = imagesDTO5;
            i10 = 32767;
            bool2 = bool4;
            l11 = l14;
            l12 = l13;
            str2 = str9;
            str4 = str8;
            str3 = str7;
            bool = bool3;
            imagesDTO2 = imagesDTO4;
            num2 = num4;
            num = num3;
        } else {
            boolean z5 = true;
            int i11 = 0;
            Long l16 = null;
            String str10 = null;
            ImagesDTO imagesDTO6 = null;
            String str11 = null;
            Boolean bool5 = null;
            Long l17 = null;
            Long l18 = null;
            Boolean bool6 = null;
            Integer num5 = null;
            String str12 = null;
            ImagesDTO imagesDTO7 = null;
            c cVar3 = null;
            Integer num6 = null;
            String str13 = null;
            while (z5) {
                ImagesDTO imagesDTO8 = imagesDTO6;
                int iDecodeElementIndex = fVarBeginStructure.decodeElementIndex(gVar);
                switch (iDecodeElementIndex) {
                    case -1:
                        z5 = false;
                        imagesDTO6 = imagesDTO8;
                        l16 = l16;
                        i11 = i11;
                        break;
                    case 0:
                        imagesDTO3 = imagesDTO8;
                        num6 = (Integer) fVarBeginStructure.decodeNullableSerializableElement(gVar, 0, x0.INSTANCE, num6);
                        i11 |= 1;
                        str13 = str13;
                        imagesDTO6 = imagesDTO3;
                        l16 = l16;
                        break;
                    case 1:
                        imagesDTO3 = imagesDTO8;
                        str13 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 1, u2.INSTANCE, str13);
                        i11 |= 2;
                        imagesDTO6 = imagesDTO3;
                        l16 = l16;
                        break;
                    case 2:
                        l16 = l16;
                        imagesDTO6 = (ImagesDTO) fVarBeginStructure.decodeNullableSerializableElement(gVar, 2, ImagesDTO$$serializer.INSTANCE, imagesDTO8);
                        i11 |= 4;
                        l16 = l16;
                        break;
                    case 3:
                        str11 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 3, u2.INSTANCE, str11);
                        i11 |= 8;
                        imagesDTO6 = imagesDTO8;
                        break;
                    case 4:
                        bool5 = (Boolean) fVarBeginStructure.decodeNullableSerializableElement(gVar, 4, kotlinx.serialization.internal.i.INSTANCE, bool5);
                        i11 |= 16;
                        imagesDTO6 = imagesDTO8;
                        str11 = str11;
                        break;
                    case 5:
                        str12 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 5, u2.INSTANCE, str12);
                        i11 |= 32;
                        imagesDTO6 = imagesDTO8;
                        str11 = str11;
                        break;
                    case 6:
                        str10 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 6, u2.INSTANCE, str10);
                        i11 |= 64;
                        imagesDTO6 = imagesDTO8;
                        str11 = str11;
                        break;
                    case 7:
                        l16 = (Long) fVarBeginStructure.decodeNullableSerializableElement(gVar, 7, i1.INSTANCE, l16);
                        i11 |= 128;
                        imagesDTO6 = imagesDTO8;
                        str11 = str11;
                        break;
                    case 8:
                        cVar3 = (c) fVarBeginStructure.decodeNullableSerializableElement(gVar, 8, a.f816a, cVar3);
                        i11 |= 256;
                        imagesDTO6 = imagesDTO8;
                        str11 = str11;
                        break;
                    case 9:
                        num5 = (Integer) fVarBeginStructure.decodeNullableSerializableElement(gVar, 9, x0.INSTANCE, num5);
                        i11 |= 512;
                        imagesDTO6 = imagesDTO8;
                        str11 = str11;
                        break;
                    case 10:
                        imagesDTO7 = (ImagesDTO) fVarBeginStructure.decodeNullableSerializableElement(gVar, 10, ImagesDTO$$serializer.INSTANCE, imagesDTO7);
                        i11 |= 1024;
                        imagesDTO6 = imagesDTO8;
                        str11 = str11;
                        break;
                    case ue.r.NETWORK_CLIENT_ERROR_REASON_FIELD_NUMBER /* 11 */:
                        bool6 = (Boolean) fVarBeginStructure.decodeNullableSerializableElement(gVar, 11, kotlinx.serialization.internal.i.INSTANCE, bool6);
                        i11 |= 2048;
                        imagesDTO6 = imagesDTO8;
                        str11 = str11;
                        break;
                    case ue.r.CUSTOM_ATTRIBUTES_FIELD_NUMBER /* 12 */:
                        l18 = (Long) fVarBeginStructure.decodeNullableSerializableElement(gVar, 12, i1.INSTANCE, l18);
                        i11 |= Buffer.SEGMENTING_THRESHOLD;
                        imagesDTO6 = imagesDTO8;
                        str11 = str11;
                        break;
                    case ue.r.PERF_SESSIONS_FIELD_NUMBER /* 13 */:
                        l17 = (Long) fVarBeginStructure.decodeNullableSerializableElement(gVar, 13, i1.INSTANCE, l17);
                        i11 |= 8192;
                        imagesDTO6 = imagesDTO8;
                        str11 = str11;
                        break;
                    case 14:
                        str5 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 14, u2.INSTANCE, str5);
                        i11 |= 16384;
                        imagesDTO6 = imagesDTO8;
                        str11 = str11;
                        break;
                    default:
                        throw new kotlinx.serialization.t(iDecodeElementIndex);
                }
            }
            str = str13;
            num = num6;
            str2 = str10;
            str3 = str11;
            bool = bool5;
            l10 = l17;
            l11 = l18;
            bool2 = bool6;
            num2 = num5;
            str4 = str12;
            imagesDTO = imagesDTO7;
            cVar = cVar3;
            imagesDTO2 = imagesDTO6;
            l12 = l16;
            i10 = i11;
        }
        String str14 = str5;
        String str15 = str;
        fVarBeginStructure.endStructure(gVar);
        return new f(i10, num, str15, imagesDTO2, str3, bool, str4, str2, l12, cVar, num2, imagesDTO, bool2, l11, l10, str14);
    }

    @Override // kotlinx.serialization.internal.n0, kotlinx.serialization.b, kotlinx.serialization.l, kotlinx.serialization.a
    public final kotlinx.serialization.descriptors.g getDescriptor() {
        return descriptor;
    }

    @Override // kotlinx.serialization.internal.n0, kotlinx.serialization.b, kotlinx.serialization.l
    public final void serialize(kotlinx.serialization.encoding.l encoder, Object obj) {
        f value = (f) obj;
        kotlin.jvm.internal.q.g(encoder, "encoder");
        kotlin.jvm.internal.q.g(value, "value");
        kotlinx.serialization.descriptors.g gVar = descriptor;
        kotlinx.serialization.encoding.h hVarBeginStructure = encoder.beginStructure(gVar);
        x0 x0Var = x0.INSTANCE;
        hVarBeginStructure.encodeNullableSerializableElement(gVar, 0, x0Var, value.f832a);
        u2 u2Var = u2.INSTANCE;
        hVarBeginStructure.encodeNullableSerializableElement(gVar, 1, u2Var, value.f833b);
        ImagesDTO$$serializer imagesDTO$$serializer = ImagesDTO$$serializer.INSTANCE;
        hVarBeginStructure.encodeNullableSerializableElement(gVar, 2, imagesDTO$$serializer, value.f834c);
        hVarBeginStructure.encodeNullableSerializableElement(gVar, 3, u2Var, value.f835d);
        kotlinx.serialization.internal.i iVar = kotlinx.serialization.internal.i.INSTANCE;
        hVarBeginStructure.encodeNullableSerializableElement(gVar, 4, iVar, value.f836e);
        hVarBeginStructure.encodeNullableSerializableElement(gVar, 5, u2Var, value.f);
        hVarBeginStructure.encodeNullableSerializableElement(gVar, 6, u2Var, value.f837g);
        i1 i1Var = i1.INSTANCE;
        hVarBeginStructure.encodeNullableSerializableElement(gVar, 7, i1Var, value.h);
        hVarBeginStructure.encodeNullableSerializableElement(gVar, 8, a.f816a, value.f838i);
        hVarBeginStructure.encodeNullableSerializableElement(gVar, 9, x0Var, value.f839j);
        hVarBeginStructure.encodeNullableSerializableElement(gVar, 10, imagesDTO$$serializer, value.f840k);
        hVarBeginStructure.encodeNullableSerializableElement(gVar, 11, iVar, value.f841l);
        hVarBeginStructure.encodeNullableSerializableElement(gVar, 12, i1Var, value.f842m);
        hVarBeginStructure.encodeNullableSerializableElement(gVar, 13, i1Var, value.f843n);
        hVarBeginStructure.encodeNullableSerializableElement(gVar, 14, u2Var, value.f844o);
        hVarBeginStructure.endStructure(gVar);
    }

    @Override // kotlinx.serialization.internal.n0
    public final /* bridge */ kotlinx.serialization.b[] typeParametersSerializers() {
        return l0.a(this);
    }
}
