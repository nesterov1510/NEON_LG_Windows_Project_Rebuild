package al;

import com.google.protobuf.m0;
import kotlinx.serialization.internal.c2;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
@kotlinx.serialization.j
public final class v {
    public static final u Companion = new u();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f876a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f877b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final s f878c;

    public /* synthetic */ v(int i10, String str, String str2, s sVar) {
        if (7 != (i10 & 7)) {
            c2.throwMissingFieldException(i10, 7, t.f875a.getDescriptor());
        }
        this.f876a = str;
        this.f877b = str2;
        this.f878c = sVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof v)) {
            return false;
        }
        v vVar = (v) obj;
        return kotlin.jvm.internal.q.c(this.f876a, vVar.f876a) && kotlin.jvm.internal.q.c(this.f877b, vVar.f877b) && kotlin.jvm.internal.q.c(this.f878c, vVar.f878c);
    }

    public final int hashCode() {
        String str = this.f876a;
        int iHashCode = (str == null ? 0 : str.hashCode()) * 31;
        String str2 = this.f877b;
        int iHashCode2 = (iHashCode + (str2 == null ? 0 : str2.hashCode())) * 31;
        s sVar = this.f878c;
        return iHashCode2 + (sVar != null ? sVar.hashCode() : 0);
    }

    public final String toString() {
        StringBuilder sbN = m0.n("LiveInfoRespDTO(status=", this.f876a, ", message=", this.f877b, ", event_live_info=");
        sbN.append(this.f878c);
        sbN.append(")");
        return sbN.toString();
    }
}
