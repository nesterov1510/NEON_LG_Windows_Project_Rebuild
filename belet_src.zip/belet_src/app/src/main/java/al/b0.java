package al;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
@kotlinx.serialization.j
public final class b0 {
    public static final a0 Companion = new a0();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Integer f817a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f818b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final String f819c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Long f820d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final Long f821e;
    public final Float f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final Boolean f822g;
    public final String h;

    public /* synthetic */ b0(int i10, Integer num, String str, String str2, Long l10, Long l11, Float f, Boolean bool, String str3) {
        if ((i10 & 1) == 0) {
            this.f817a = null;
        } else {
            this.f817a = num;
        }
        if ((i10 & 2) == 0) {
            this.f818b = null;
        } else {
            this.f818b = str;
        }
        if ((i10 & 4) == 0) {
            this.f819c = null;
        } else {
            this.f819c = str2;
        }
        if ((i10 & 8) == 0) {
            this.f820d = null;
        } else {
            this.f820d = l10;
        }
        if ((i10 & 16) == 0) {
            this.f821e = null;
        } else {
            this.f821e = l11;
        }
        if ((i10 & 32) == 0) {
            this.f = null;
        } else {
            this.f = f;
        }
        if ((i10 & 64) == 0) {
            this.f822g = Boolean.FALSE;
        } else {
            this.f822g = bool;
        }
        if ((i10 & 128) == 0) {
            this.h = null;
        } else {
            this.h = str3;
        }
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof b0)) {
            return false;
        }
        b0 b0Var = (b0) obj;
        return kotlin.jvm.internal.q.c(this.f817a, b0Var.f817a) && kotlin.jvm.internal.q.c(this.f818b, b0Var.f818b) && kotlin.jvm.internal.q.c(this.f819c, b0Var.f819c) && kotlin.jvm.internal.q.c(this.f820d, b0Var.f820d) && kotlin.jvm.internal.q.c(this.f821e, b0Var.f821e) && kotlin.jvm.internal.q.c(this.f, b0Var.f) && kotlin.jvm.internal.q.c(this.f822g, b0Var.f822g) && kotlin.jvm.internal.q.c(this.h, b0Var.h);
    }

    public final int hashCode() {
        Integer num = this.f817a;
        int iHashCode = (num == null ? 0 : num.hashCode()) * 31;
        String str = this.f818b;
        int iHashCode2 = (iHashCode + (str == null ? 0 : str.hashCode())) * 31;
        String str2 = this.f819c;
        int iHashCode3 = (iHashCode2 + (str2 == null ? 0 : str2.hashCode())) * 31;
        Long l10 = this.f820d;
        int iHashCode4 = (iHashCode3 + (l10 == null ? 0 : l10.hashCode())) * 31;
        Long l11 = this.f821e;
        int iHashCode5 = (iHashCode4 + (l11 == null ? 0 : l11.hashCode())) * 31;
        Float f = this.f;
        int iHashCode6 = (iHashCode5 + (f == null ? 0 : f.hashCode())) * 31;
        Boolean bool = this.f822g;
        int iHashCode7 = (iHashCode6 + (bool == null ? 0 : bool.hashCode())) * 31;
        String str3 = this.h;
        return iHashCode7 + (str3 != null ? str3.hashCode() : 0);
    }

    public final String toString() {
        StringBuilder sbT = a0.f.t("TeamDTO(id=", this.f817a, ", image_url=", this.f818b, ", name=");
        sbT.append(this.f819c);
        sbT.append(", votes=");
        sbT.append(this.f820d);
        sbT.append(", position=");
        sbT.append(this.f821e);
        sbT.append(", vote_percentage=");
        sbT.append(this.f);
        sbT.append(", is_voted=");
        sbT.append(this.f822g);
        sbT.append(", color_hex=");
        sbT.append(this.h);
        sbT.append(")");
        return sbT.toString();
    }
}
