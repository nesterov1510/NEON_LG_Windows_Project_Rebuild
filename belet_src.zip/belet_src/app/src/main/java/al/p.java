package al;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
@kotlinx.serialization.j
public final class p {
    public static final o Companion = new o();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Integer f868a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f869b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Long f870c;

    public /* synthetic */ p(int i10, Integer num, String str, Long l10) {
        if ((i10 & 1) == 0) {
            this.f868a = null;
        } else {
            this.f868a = num;
        }
        if ((i10 & 2) == 0) {
            this.f869b = null;
        } else {
            this.f869b = str;
        }
        if ((i10 & 4) == 0) {
            this.f870c = null;
        } else {
            this.f870c = l10;
        }
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof p)) {
            return false;
        }
        p pVar = (p) obj;
        return kotlin.jvm.internal.q.c(this.f868a, pVar.f868a) && kotlin.jvm.internal.q.c(this.f869b, pVar.f869b) && kotlin.jvm.internal.q.c(this.f870c, pVar.f870c);
    }

    public final int hashCode() {
        Integer num = this.f868a;
        int iHashCode = (num == null ? 0 : num.hashCode()) * 31;
        String str = this.f869b;
        int iHashCode2 = (iHashCode + (str == null ? 0 : str.hashCode())) * 31;
        Long l10 = this.f870c;
        return iHashCode2 + (l10 != null ? l10.hashCode() : 0);
    }

    public final String toString() {
        StringBuilder sbT = a0.f.t("GroupsDTO(id=", this.f868a, ", name=", this.f869b, ", position=");
        sbT.append(this.f870c);
        sbT.append(")");
        return sbT.toString();
    }
}
