package al;

import kotlinx.serialization.internal.e2;
import kotlinx.serialization.internal.l0;
import kotlinx.serialization.internal.n0;
import kotlinx.serialization.internal.u2;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class f0 implements n0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final f0 f845a;
    private static final kotlinx.serialization.descriptors.g descriptor;

    static {
        f0 f0Var = new f0();
        f845a = f0Var;
        e2 e2Var = new e2("tm.belet.films.data.response.events.TournamentInfoDTO", f0Var, 3);
        e2Var.addElement("status", false);
        e2Var.addElement("message", false);
        e2Var.addElement("tournament", false);
        descriptor = e2Var;
    }

    @Override // kotlinx.serialization.internal.n0
    public final kotlinx.serialization.b[] childSerializers() {
        u2 u2Var = u2.INSTANCE;
        return new kotlinx.serialization.b[]{wj.a.getNullable(u2Var), wj.a.getNullable(u2Var), wj.a.getNullable(c0.f825a)};
    }

    @Override // kotlinx.serialization.internal.n0, kotlinx.serialization.b, kotlinx.serialization.a
    public final Object deserialize(kotlinx.serialization.encoding.j decoder) {
        int i10;
        String str;
        String str2;
        e0 e0Var;
        kotlin.jvm.internal.q.g(decoder, "decoder");
        kotlinx.serialization.descriptors.g gVar = descriptor;
        kotlinx.serialization.encoding.f fVarBeginStructure = decoder.beginStructure(gVar);
        String str3 = null;
        if (fVarBeginStructure.decodeSequentially()) {
            u2 u2Var = u2.INSTANCE;
            str = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 0, u2Var, null);
            str2 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 1, u2Var, null);
            e0Var = (e0) fVarBeginStructure.decodeNullableSerializableElement(gVar, 2, c0.f825a, null);
            i10 = 7;
        } else {
            boolean z5 = true;
            int i11 = 0;
            String str4 = null;
            e0 e0Var2 = null;
            while (z5) {
                int iDecodeElementIndex = fVarBeginStructure.decodeElementIndex(gVar);
                if (iDecodeElementIndex == -1) {
                    z5 = false;
                } else if (iDecodeElementIndex == 0) {
                    str3 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 0, u2.INSTANCE, str3);
                    i11 |= 1;
                } else if (iDecodeElementIndex == 1) {
                    str4 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 1, u2.INSTANCE, str4);
                    i11 |= 2;
                } else {
                    if (iDecodeElementIndex != 2) {
                        throw new kotlinx.serialization.t(iDecodeElementIndex);
                    }
                    e0Var2 = (e0) fVarBeginStructure.decodeNullableSerializableElement(gVar, 2, c0.f825a, e0Var2);
                    i11 |= 4;
                }
            }
            i10 = i11;
            str = str3;
            str2 = str4;
            e0Var = e0Var2;
        }
        fVarBeginStructure.endStructure(gVar);
        return new h0(i10, str, str2, e0Var);
    }

    @Override // kotlinx.serialization.internal.n0, kotlinx.serialization.b, kotlinx.serialization.l, kotlinx.serialization.a
    public final kotlinx.serialization.descriptors.g getDescriptor() {
        return descriptor;
    }

    @Override // kotlinx.serialization.internal.n0, kotlinx.serialization.b, kotlinx.serialization.l
    public final void serialize(kotlinx.serialization.encoding.l encoder, Object obj) {
        h0 value = (h0) obj;
        kotlin.jvm.internal.q.g(encoder, "encoder");
        kotlin.jvm.internal.q.g(value, "value");
        kotlinx.serialization.descriptors.g gVar = descriptor;
        kotlinx.serialization.encoding.h hVarBeginStructure = encoder.beginStructure(gVar);
        u2 u2Var = u2.INSTANCE;
        hVarBeginStructure.encodeNullableSerializableElement(gVar, 0, u2Var, value.f847a);
        hVarBeginStructure.encodeNullableSerializableElement(gVar, 1, u2Var, value.f848b);
        hVarBeginStructure.encodeNullableSerializableElement(gVar, 2, c0.f825a, value.f849c);
        hVarBeginStructure.endStructure(gVar);
    }

    @Override // kotlinx.serialization.internal.n0
    public final /* bridge */ kotlinx.serialization.b[] typeParametersSerializers() {
        return l0.a(this);
    }
}
