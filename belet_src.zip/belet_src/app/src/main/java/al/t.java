package al;

import kotlinx.serialization.internal.e2;
import kotlinx.serialization.internal.l0;
import kotlinx.serialization.internal.n0;
import kotlinx.serialization.internal.u2;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class t implements n0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final t f875a;
    private static final kotlinx.serialization.descriptors.g descriptor;

    static {
        t tVar = new t();
        f875a = tVar;
        e2 e2Var = new e2("tm.belet.films.data.response.events.LiveInfoRespDTO", tVar, 3);
        e2Var.addElement("status", false);
        e2Var.addElement("message", false);
        e2Var.addElement("event_live_info", false);
        descriptor = e2Var;
    }

    @Override // kotlinx.serialization.internal.n0
    public final kotlinx.serialization.b[] childSerializers() {
        u2 u2Var = u2.INSTANCE;
        return new kotlinx.serialization.b[]{wj.a.getNullable(u2Var), wj.a.getNullable(u2Var), wj.a.getNullable(q.f871a)};
    }

    @Override // kotlinx.serialization.internal.n0, kotlinx.serialization.b, kotlinx.serialization.a
    public final Object deserialize(kotlinx.serialization.encoding.j decoder) {
        int i10;
        String str;
        String str2;
        s sVar;
        kotlin.jvm.internal.q.g(decoder, "decoder");
        kotlinx.serialization.descriptors.g gVar = descriptor;
        kotlinx.serialization.encoding.f fVarBeginStructure = decoder.beginStructure(gVar);
        String str3 = null;
        if (fVarBeginStructure.decodeSequentially()) {
            u2 u2Var = u2.INSTANCE;
            str = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 0, u2Var, null);
            str2 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 1, u2Var, null);
            sVar = (s) fVarBeginStructure.decodeNullableSerializableElement(gVar, 2, q.f871a, null);
            i10 = 7;
        } else {
            boolean z5 = true;
            int i11 = 0;
            String str4 = null;
            s sVar2 = null;
            while (z5) {
                int iDecodeElementIndex = fVarBeginStructure.decodeElementIndex(gVar);
                if (iDecodeElementIndex == -1) {
                    z5 = false;
                } else if (iDecodeElementIndex == 0) {
                    str3 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 0, u2.INSTANCE, str3);
                    i11 |= 1;
                } else if (iDecodeElementIndex == 1) {
                    str4 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 1, u2.INSTANCE, str4);
                    i11 |= 2;
                } else {
                    if (iDecodeElementIndex != 2) {
                        throw new kotlinx.serialization.t(iDecodeElementIndex);
                    }
                    sVar2 = (s) fVarBeginStructure.decodeNullableSerializableElement(gVar, 2, q.f871a, sVar2);
                    i11 |= 4;
                }
            }
            i10 = i11;
            str = str3;
            str2 = str4;
            sVar = sVar2;
        }
        fVarBeginStructure.endStructure(gVar);
        return new v(i10, str, str2, sVar);
    }

    @Override // kotlinx.serialization.internal.n0, kotlinx.serialization.b, kotlinx.serialization.l, kotlinx.serialization.a
    public final kotlinx.serialization.descriptors.g getDescriptor() {
        return descriptor;
    }

    @Override // kotlinx.serialization.internal.n0, kotlinx.serialization.b, kotlinx.serialization.l
    public final void serialize(kotlinx.serialization.encoding.l encoder, Object obj) {
        v value = (v) obj;
        kotlin.jvm.internal.q.g(encoder, "encoder");
        kotlin.jvm.internal.q.g(value, "value");
        kotlinx.serialization.descriptors.g gVar = descriptor;
        kotlinx.serialization.encoding.h hVarBeginStructure = encoder.beginStructure(gVar);
        u2 u2Var = u2.INSTANCE;
        hVarBeginStructure.encodeNullableSerializableElement(gVar, 0, u2Var, value.f876a);
        hVarBeginStructure.encodeNullableSerializableElement(gVar, 1, u2Var, value.f877b);
        hVarBeginStructure.encodeNullableSerializableElement(gVar, 2, q.f871a, value.f878c);
        hVarBeginStructure.endStructure(gVar);
    }

    @Override // kotlinx.serialization.internal.n0
    public final /* bridge */ kotlinx.serialization.b[] typeParametersSerializers() {
        return l0.a(this);
    }
}
