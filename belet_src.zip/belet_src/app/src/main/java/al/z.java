package al;

import kotlinx.serialization.internal.e2;
import kotlinx.serialization.internal.i1;
import kotlinx.serialization.internal.l0;
import kotlinx.serialization.internal.n0;
import kotlinx.serialization.internal.u2;
import kotlinx.serialization.internal.x0;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class z implements n0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final z f886a;
    private static final kotlinx.serialization.descriptors.g descriptor;

    static {
        z zVar = new z();
        f886a = zVar;
        e2 e2Var = new e2("tm.belet.films.data.response.events.TeamDTO", zVar, 8);
        e2Var.addElement("id", true);
        e2Var.addElement("image_url", true);
        e2Var.addElement("name", true);
        e2Var.addElement("votes", true);
        e2Var.addElement("position", true);
        e2Var.addElement("vote_percentage", true);
        e2Var.addElement("is_voted", true);
        e2Var.addElement("color_hex", true);
        descriptor = e2Var;
    }

    @Override // kotlinx.serialization.internal.n0
    public final kotlinx.serialization.b[] childSerializers() {
        kotlinx.serialization.b nullable = wj.a.getNullable(x0.INSTANCE);
        u2 u2Var = u2.INSTANCE;
        kotlinx.serialization.b nullable2 = wj.a.getNullable(u2Var);
        kotlinx.serialization.b nullable3 = wj.a.getNullable(u2Var);
        i1 i1Var = i1.INSTANCE;
        return new kotlinx.serialization.b[]{nullable, nullable2, nullable3, wj.a.getNullable(i1Var), wj.a.getNullable(i1Var), wj.a.getNullable(kotlinx.serialization.internal.k0.INSTANCE), wj.a.getNullable(kotlinx.serialization.internal.i.INSTANCE), wj.a.getNullable(u2Var)};
    }

    @Override // kotlinx.serialization.internal.n0, kotlinx.serialization.b, kotlinx.serialization.a
    public final Object deserialize(kotlinx.serialization.encoding.j decoder) {
        int i10;
        String str;
        Boolean bool;
        Float f;
        Integer num;
        String str2;
        String str3;
        Long l10;
        Long l11;
        kotlin.jvm.internal.q.g(decoder, "decoder");
        kotlinx.serialization.descriptors.g gVar = descriptor;
        kotlinx.serialization.encoding.f fVarBeginStructure = decoder.beginStructure(gVar);
        int i11 = 7;
        Integer num2 = null;
        if (fVarBeginStructure.decodeSequentially()) {
            Integer num3 = (Integer) fVarBeginStructure.decodeNullableSerializableElement(gVar, 0, x0.INSTANCE, null);
            u2 u2Var = u2.INSTANCE;
            String str4 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 1, u2Var, null);
            String str5 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 2, u2Var, null);
            i1 i1Var = i1.INSTANCE;
            Long l12 = (Long) fVarBeginStructure.decodeNullableSerializableElement(gVar, 3, i1Var, null);
            Long l13 = (Long) fVarBeginStructure.decodeNullableSerializableElement(gVar, 4, i1Var, null);
            Float f10 = (Float) fVarBeginStructure.decodeNullableSerializableElement(gVar, 5, kotlinx.serialization.internal.k0.INSTANCE, null);
            Boolean bool2 = (Boolean) fVarBeginStructure.decodeNullableSerializableElement(gVar, 6, kotlinx.serialization.internal.i.INSTANCE, null);
            num = num3;
            str = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 7, u2Var, null);
            bool = bool2;
            f = f10;
            l10 = l12;
            l11 = l13;
            str3 = str5;
            str2 = str4;
            i10 = 255;
        } else {
            boolean z5 = true;
            int i12 = 0;
            String str6 = null;
            Boolean bool3 = null;
            Float f11 = null;
            String str7 = null;
            String str8 = null;
            Long l14 = null;
            Long l15 = null;
            while (z5) {
                int iDecodeElementIndex = fVarBeginStructure.decodeElementIndex(gVar);
                switch (iDecodeElementIndex) {
                    case -1:
                        z5 = false;
                        i11 = 7;
                        break;
                    case 0:
                        num2 = (Integer) fVarBeginStructure.decodeNullableSerializableElement(gVar, 0, x0.INSTANCE, num2);
                        i12 |= 1;
                        i11 = 7;
                        break;
                    case 1:
                        str7 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 1, u2.INSTANCE, str7);
                        i12 |= 2;
                        i11 = 7;
                        break;
                    case 2:
                        str8 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 2, u2.INSTANCE, str8);
                        i12 |= 4;
                        i11 = 7;
                        break;
                    case 3:
                        l14 = (Long) fVarBeginStructure.decodeNullableSerializableElement(gVar, 3, i1.INSTANCE, l14);
                        i12 |= 8;
                        i11 = 7;
                        break;
                    case 4:
                        l15 = (Long) fVarBeginStructure.decodeNullableSerializableElement(gVar, 4, i1.INSTANCE, l15);
                        i12 |= 16;
                        break;
                    case 5:
                        f11 = (Float) fVarBeginStructure.decodeNullableSerializableElement(gVar, 5, kotlinx.serialization.internal.k0.INSTANCE, f11);
                        i12 |= 32;
                        break;
                    case 6:
                        bool3 = (Boolean) fVarBeginStructure.decodeNullableSerializableElement(gVar, 6, kotlinx.serialization.internal.i.INSTANCE, bool3);
                        i12 |= 64;
                        break;
                    case 7:
                        str6 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, i11, u2.INSTANCE, str6);
                        i12 |= 128;
                        break;
                    default:
                        throw new kotlinx.serialization.t(iDecodeElementIndex);
                }
            }
            i10 = i12;
            str = str6;
            bool = bool3;
            f = f11;
            num = num2;
            str2 = str7;
            str3 = str8;
            l10 = l14;
            l11 = l15;
        }
        fVarBeginStructure.endStructure(gVar);
        return new b0(i10, num, str2, str3, l10, l11, f, bool, str);
    }

    @Override // kotlinx.serialization.internal.n0, kotlinx.serialization.b, kotlinx.serialization.l, kotlinx.serialization.a
    public final kotlinx.serialization.descriptors.g getDescriptor() {
        return descriptor;
    }

    @Override // kotlinx.serialization.internal.n0, kotlinx.serialization.b, kotlinx.serialization.l
    public final void serialize(kotlinx.serialization.encoding.l encoder, Object obj) {
        b0 value = (b0) obj;
        kotlin.jvm.internal.q.g(encoder, "encoder");
        kotlin.jvm.internal.q.g(value, "value");
        String str = value.h;
        Boolean bool = value.f822g;
        Float f = value.f;
        Long l10 = value.f821e;
        Long l11 = value.f820d;
        String str2 = value.f819c;
        String str3 = value.f818b;
        Integer num = value.f817a;
        kotlinx.serialization.descriptors.g gVar = descriptor;
        kotlinx.serialization.encoding.h hVarBeginStructure = encoder.beginStructure(gVar);
        if (hVarBeginStructure.shouldEncodeElementDefault(gVar, 0) || num != null) {
            hVarBeginStructure.encodeNullableSerializableElement(gVar, 0, x0.INSTANCE, num);
        }
        if (hVarBeginStructure.shouldEncodeElementDefault(gVar, 1) || str3 != null) {
            hVarBeginStructure.encodeNullableSerializableElement(gVar, 1, u2.INSTANCE, str3);
        }
        if (hVarBeginStructure.shouldEncodeElementDefault(gVar, 2) || str2 != null) {
            hVarBeginStructure.encodeNullableSerializableElement(gVar, 2, u2.INSTANCE, str2);
        }
        if (hVarBeginStructure.shouldEncodeElementDefault(gVar, 3) || l11 != null) {
            hVarBeginStructure.encodeNullableSerializableElement(gVar, 3, i1.INSTANCE, l11);
        }
        if (hVarBeginStructure.shouldEncodeElementDefault(gVar, 4) || l10 != null) {
            hVarBeginStructure.encodeNullableSerializableElement(gVar, 4, i1.INSTANCE, l10);
        }
        if (hVarBeginStructure.shouldEncodeElementDefault(gVar, 5) || f != null) {
            hVarBeginStructure.encodeNullableSerializableElement(gVar, 5, kotlinx.serialization.internal.k0.INSTANCE, f);
        }
        if (hVarBeginStructure.shouldEncodeElementDefault(gVar, 6) || !kotlin.jvm.internal.q.c(bool, Boolean.FALSE)) {
            hVarBeginStructure.encodeNullableSerializableElement(gVar, 6, kotlinx.serialization.internal.i.INSTANCE, bool);
        }
        if (hVarBeginStructure.shouldEncodeElementDefault(gVar, 7) || str != null) {
            hVarBeginStructure.encodeNullableSerializableElement(gVar, 7, u2.INSTANCE, str);
        }
        hVarBeginStructure.endStructure(gVar);
    }

    @Override // kotlinx.serialization.internal.n0
    public final /* bridge */ kotlinx.serialization.b[] typeParametersSerializers() {
        return l0.a(this);
    }
}
