package al;

import kotlinx.serialization.internal.c2;
import tm.belet.films.data.response.home.ImagesDTO;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
@kotlinx.serialization.j
public final class e0 {
    public static final d0 Companion = new d0();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Long f827a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f828b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final ImagesDTO f829c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Boolean f830d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final Long f831e;
    public final String f;

    public /* synthetic */ e0(int i10, Long l10, String str, ImagesDTO imagesDTO, Boolean bool, Long l11, String str2) {
        if (63 != (i10 & 63)) {
            c2.throwMissingFieldException(i10, 63, c0.f825a.getDescriptor());
        }
        this.f827a = l10;
        this.f828b = str;
        this.f829c = imagesDTO;
        this.f830d = bool;
        this.f831e = l11;
        this.f = str2;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof e0)) {
            return false;
        }
        e0 e0Var = (e0) obj;
        return kotlin.jvm.internal.q.c(this.f827a, e0Var.f827a) && kotlin.jvm.internal.q.c(this.f828b, e0Var.f828b) && kotlin.jvm.internal.q.c(this.f829c, e0Var.f829c) && kotlin.jvm.internal.q.c(this.f830d, e0Var.f830d) && kotlin.jvm.internal.q.c(this.f831e, e0Var.f831e) && kotlin.jvm.internal.q.c(this.f, e0Var.f);
    }

    public final int hashCode() {
        Long l10 = this.f827a;
        int iHashCode = (l10 == null ? 0 : l10.hashCode()) * 31;
        String str = this.f828b;
        int iHashCode2 = (iHashCode + (str == null ? 0 : str.hashCode())) * 31;
        ImagesDTO imagesDTO = this.f829c;
        int iHashCode3 = (iHashCode2 + (imagesDTO == null ? 0 : imagesDTO.hashCode())) * 31;
        Boolean bool = this.f830d;
        int iHashCode4 = (iHashCode3 + (bool == null ? 0 : bool.hashCode())) * 31;
        Long l11 = this.f831e;
        int iHashCode5 = (iHashCode4 + (l11 == null ? 0 : l11.hashCode())) * 31;
        String str2 = this.f;
        return iHashCode5 + (str2 != null ? str2.hashCode() : 0);
    }

    public final String toString() {
        return "TournamentDTO(id=" + this.f827a + ", title=" + this.f828b + ", images=" + this.f829c + ", is_subscribed=" + this.f830d + ", subscribers_count=" + this.f831e + ", partner_logo_url=" + this.f + ")";
    }
}
