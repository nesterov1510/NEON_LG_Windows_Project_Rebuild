package al;

import java.util.List;
import kotlinx.serialization.internal.e2;
import kotlinx.serialization.internal.l0;
import kotlinx.serialization.internal.n0;
import kotlinx.serialization.internal.u2;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class k implements n0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final k f856a;
    private static final kotlinx.serialization.descriptors.g descriptor;

    static {
        k kVar = new k();
        f856a = kVar;
        e2 e2Var = new e2("tm.belet.films.data.response.events.EventsRespDTO", kVar, 3);
        e2Var.addElement("status", false);
        e2Var.addElement("message", false);
        e2Var.addElement("content", false);
        descriptor = e2Var;
    }

    @Override // kotlinx.serialization.internal.n0
    public final kotlinx.serialization.b[] childSerializers() {
        qi.f[] fVarArr = m.f863d;
        u2 u2Var = u2.INSTANCE;
        return new kotlinx.serialization.b[]{wj.a.getNullable(u2Var), wj.a.getNullable(u2Var), wj.a.getNullable((kotlinx.serialization.b) fVarArr[2].getValue())};
    }

    @Override // kotlinx.serialization.internal.n0, kotlinx.serialization.b, kotlinx.serialization.a
    public final Object deserialize(kotlinx.serialization.encoding.j decoder) {
        int i10;
        String str;
        String str2;
        List list;
        kotlin.jvm.internal.q.g(decoder, "decoder");
        kotlinx.serialization.descriptors.g gVar = descriptor;
        kotlinx.serialization.encoding.f fVarBeginStructure = decoder.beginStructure(gVar);
        qi.f[] fVarArr = m.f863d;
        String str3 = null;
        if (fVarBeginStructure.decodeSequentially()) {
            u2 u2Var = u2.INSTANCE;
            str = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 0, u2Var, null);
            str2 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 1, u2Var, null);
            list = (List) fVarBeginStructure.decodeNullableSerializableElement(gVar, 2, (kotlinx.serialization.a) fVarArr[2].getValue(), null);
            i10 = 7;
        } else {
            boolean z5 = true;
            int i11 = 0;
            String str4 = null;
            List list2 = null;
            while (z5) {
                int iDecodeElementIndex = fVarBeginStructure.decodeElementIndex(gVar);
                if (iDecodeElementIndex == -1) {
                    z5 = false;
                } else if (iDecodeElementIndex == 0) {
                    str3 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 0, u2.INSTANCE, str3);
                    i11 |= 1;
                } else if (iDecodeElementIndex == 1) {
                    str4 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 1, u2.INSTANCE, str4);
                    i11 |= 2;
                } else {
                    if (iDecodeElementIndex != 2) {
                        throw new kotlinx.serialization.t(iDecodeElementIndex);
                    }
                    list2 = (List) fVarBeginStructure.decodeNullableSerializableElement(gVar, 2, (kotlinx.serialization.a) fVarArr[2].getValue(), list2);
                    i11 |= 4;
                }
            }
            i10 = i11;
            str = str3;
            str2 = str4;
            list = list2;
        }
        fVarBeginStructure.endStructure(gVar);
        return new m(i10, str, str2, list);
    }

    @Override // kotlinx.serialization.internal.n0, kotlinx.serialization.b, kotlinx.serialization.l, kotlinx.serialization.a
    public final kotlinx.serialization.descriptors.g getDescriptor() {
        return descriptor;
    }

    @Override // kotlinx.serialization.internal.n0, kotlinx.serialization.b, kotlinx.serialization.l
    public final void serialize(kotlinx.serialization.encoding.l encoder, Object obj) {
        m value = (m) obj;
        kotlin.jvm.internal.q.g(encoder, "encoder");
        kotlin.jvm.internal.q.g(value, "value");
        kotlinx.serialization.descriptors.g gVar = descriptor;
        kotlinx.serialization.encoding.h hVarBeginStructure = encoder.beginStructure(gVar);
        qi.f[] fVarArr = m.f863d;
        u2 u2Var = u2.INSTANCE;
        hVarBeginStructure.encodeNullableSerializableElement(gVar, 0, u2Var, value.f864a);
        hVarBeginStructure.encodeNullableSerializableElement(gVar, 1, u2Var, value.f865b);
        hVarBeginStructure.encodeNullableSerializableElement(gVar, 2, (kotlinx.serialization.l) fVarArr[2].getValue(), value.f866c);
        hVarBeginStructure.endStructure(gVar);
    }

    @Override // kotlinx.serialization.internal.n0
    public final /* bridge */ kotlinx.serialization.b[] typeParametersSerializers() {
        return l0.a(this);
    }
}
