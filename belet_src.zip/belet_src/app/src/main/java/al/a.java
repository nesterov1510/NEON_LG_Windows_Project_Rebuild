package al;

import kotlinx.serialization.internal.e2;
import kotlinx.serialization.internal.l0;
import kotlinx.serialization.internal.n0;
import kotlinx.serialization.internal.u2;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class a implements n0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final a f816a;
    private static final kotlinx.serialization.descriptors.g descriptor;

    static {
        a aVar = new a();
        f816a = aVar;
        e2 e2Var = new e2("tm.belet.films.data.response.events.AgeRestrictionDTO", aVar, 2);
        e2Var.addElement("age", false);
        e2Var.addElement("warning", false);
        descriptor = e2Var;
    }

    @Override // kotlinx.serialization.internal.n0
    public final kotlinx.serialization.b[] childSerializers() {
        return new kotlinx.serialization.b[]{wj.a.getNullable(u2.INSTANCE), wj.a.getNullable(bl.m.f3721a)};
    }

    @Override // kotlinx.serialization.internal.n0, kotlinx.serialization.b, kotlinx.serialization.a
    public final Object deserialize(kotlinx.serialization.encoding.j decoder) {
        int i10;
        String str;
        bl.o oVar;
        kotlin.jvm.internal.q.g(decoder, "decoder");
        kotlinx.serialization.descriptors.g gVar = descriptor;
        kotlinx.serialization.encoding.f fVarBeginStructure = decoder.beginStructure(gVar);
        String str2 = null;
        if (fVarBeginStructure.decodeSequentially()) {
            str = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 0, u2.INSTANCE, null);
            oVar = (bl.o) fVarBeginStructure.decodeNullableSerializableElement(gVar, 1, bl.m.f3721a, null);
            i10 = 3;
        } else {
            boolean z5 = true;
            int i11 = 0;
            bl.o oVar2 = null;
            while (z5) {
                int iDecodeElementIndex = fVarBeginStructure.decodeElementIndex(gVar);
                if (iDecodeElementIndex == -1) {
                    z5 = false;
                } else if (iDecodeElementIndex == 0) {
                    str2 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 0, u2.INSTANCE, str2);
                    i11 |= 1;
                } else {
                    if (iDecodeElementIndex != 1) {
                        throw new kotlinx.serialization.t(iDecodeElementIndex);
                    }
                    oVar2 = (bl.o) fVarBeginStructure.decodeNullableSerializableElement(gVar, 1, bl.m.f3721a, oVar2);
                    i11 |= 2;
                }
            }
            i10 = i11;
            str = str2;
            oVar = oVar2;
        }
        fVarBeginStructure.endStructure(gVar);
        return new c(i10, str, oVar);
    }

    @Override // kotlinx.serialization.internal.n0, kotlinx.serialization.b, kotlinx.serialization.l, kotlinx.serialization.a
    public final kotlinx.serialization.descriptors.g getDescriptor() {
        return descriptor;
    }

    @Override // kotlinx.serialization.internal.n0, kotlinx.serialization.b, kotlinx.serialization.l
    public final void serialize(kotlinx.serialization.encoding.l encoder, Object obj) {
        c value = (c) obj;
        kotlin.jvm.internal.q.g(encoder, "encoder");
        kotlin.jvm.internal.q.g(value, "value");
        kotlinx.serialization.descriptors.g gVar = descriptor;
        kotlinx.serialization.encoding.h hVarBeginStructure = encoder.beginStructure(gVar);
        hVarBeginStructure.encodeNullableSerializableElement(gVar, 0, u2.INSTANCE, value.f823a);
        hVarBeginStructure.encodeNullableSerializableElement(gVar, 1, bl.m.f3721a, value.f824b);
        hVarBeginStructure.endStructure(gVar);
    }

    @Override // kotlinx.serialization.internal.n0
    public final /* bridge */ kotlinx.serialization.b[] typeParametersSerializers() {
        return l0.a(this);
    }
}
