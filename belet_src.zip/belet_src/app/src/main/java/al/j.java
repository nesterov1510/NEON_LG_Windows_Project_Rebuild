package al;

import fl.o0;
import kotlinx.serialization.internal.c1;
import kotlinx.serialization.internal.u2;
import okhttp3.internal.ws.WebSocketProtocol;
import tm.belet.films.data.response.home.HomeByIdRespDTO;
import tm.belet.films.data.response.home.HomeRespDTO;
import tm.belet.films.data.response.home.HomeVoteGroupByIdDTO;
import tm.belet.films.data.response.home.MovieRespDTO;
import tm.belet.films.data.response.home.ResultRespDTO;
import tm.belet.films.presentation.widgets.double_tab_view.youtube.views.BFCircleClipTapView;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class j implements ej.a {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f855e;

    public /* synthetic */ j(int i10) {
        this.f855e = i10;
    }

    @Override // ej.a
    public final Object invoke() {
        switch (this.f855e) {
            case 0:
                return new kotlinx.serialization.internal.f(d.f826a);
            case 1:
                return new kotlinx.serialization.internal.f(wj.a.getNullable(z.f886a));
            case 2:
                return new kotlinx.serialization.internal.f(wj.a.getNullable(n.f867a));
            case 3:
                return new kotlinx.serialization.internal.f(wj.a.getNullable(ql.w.f17530a));
            case 4:
                return new kotlinx.serialization.internal.f(wj.a.getNullable(am.a.f887a));
            case 5:
                int i10 = BFCircleClipTapView.F0;
                return qi.b0.f17350a;
            case 6:
                return new c1(u2.INSTANCE, bf.d0.f3545a);
            case 7:
                return new kotlinx.serialization.internal.f(hl.a.f10195a);
            case 8:
                return new kotlinx.serialization.internal.f(bl.j.f3716a);
            case 9:
                return new kotlinx.serialization.internal.f(fl.f0.f8172a);
            case 10:
                return new kotlinx.serialization.internal.f(wj.a.getNullable(bm.a.f3724a));
            case ue.r.NETWORK_CLIENT_ERROR_REASON_FIELD_NUMBER /* 11 */:
                return new kotlinx.serialization.internal.f(wj.a.getNullable(cm.g.f4565a));
            case ue.r.CUSTOM_ATTRIBUTES_FIELD_NUMBER /* 12 */:
                return HomeByIdRespDTO._childSerializers$_anonymous_();
            case ue.r.PERF_SESSIONS_FIELD_NUMBER /* 13 */:
                return HomeRespDTO._childSerializers$_anonymous_();
            case 14:
                return HomeVoteGroupByIdDTO._childSerializers$_anonymous_();
            case WebSocketProtocol.B0_MASK_OPCODE /* 15 */:
                return MovieRespDTO._childSerializers$_anonymous_();
            case WebSocketProtocol.B0_FLAG_RSV3 /* 16 */:
                return MovieRespDTO._childSerializers$_anonymous_$0();
            case 17:
                return ResultRespDTO._childSerializers$_anonymous_();
            case 18:
                return ResultRespDTO._childSerializers$_anonymous_$0();
            case 19:
                return ResultRespDTO._childSerializers$_anonymous_$1();
            case 20:
                return ResultRespDTO._childSerializers$_anonymous_$2();
            case 21:
                return new fi.f();
            case 22:
                return new kotlinx.serialization.internal.f(wj.a.getNullable(el.a.f7831a));
            case 23:
                return new kotlinx.serialization.internal.f(wj.a.getNullable(fl.i0.f8180a));
            case 24:
                return new kotlinx.serialization.internal.f(fl.g.f8173a);
            case 25:
                return new kotlinx.serialization.internal.f(o0.f8193a);
            case 26:
                return new kotlinx.serialization.internal.f(fl.a.f8156a);
            case 27:
                return new kotlinx.serialization.internal.f(fl.j.f8181a);
            case 28:
                return new kotlinx.serialization.internal.f(fl.m.f8187a);
            default:
                return new kotlinx.serialization.internal.f(u2.INSTANCE);
        }
    }
}
