package al;

import kotlinx.serialization.internal.e2;
import kotlinx.serialization.internal.i1;
import kotlinx.serialization.internal.l0;
import kotlinx.serialization.internal.n0;
import kotlinx.serialization.internal.u2;
import kotlinx.serialization.internal.x0;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class n implements n0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final n f867a;
    private static final kotlinx.serialization.descriptors.g descriptor;

    static {
        n nVar = new n();
        f867a = nVar;
        e2 e2Var = new e2("tm.belet.films.data.response.events.GroupsDTO", nVar, 3);
        e2Var.addElement("id", true);
        e2Var.addElement("name", true);
        e2Var.addElement("position", true);
        descriptor = e2Var;
    }

    @Override // kotlinx.serialization.internal.n0
    public final kotlinx.serialization.b[] childSerializers() {
        return new kotlinx.serialization.b[]{wj.a.getNullable(x0.INSTANCE), wj.a.getNullable(u2.INSTANCE), wj.a.getNullable(i1.INSTANCE)};
    }

    @Override // kotlinx.serialization.internal.n0, kotlinx.serialization.b, kotlinx.serialization.a
    public final Object deserialize(kotlinx.serialization.encoding.j decoder) {
        int i10;
        Integer num;
        String str;
        Long l10;
        kotlin.jvm.internal.q.g(decoder, "decoder");
        kotlinx.serialization.descriptors.g gVar = descriptor;
        kotlinx.serialization.encoding.f fVarBeginStructure = decoder.beginStructure(gVar);
        Integer num2 = null;
        if (fVarBeginStructure.decodeSequentially()) {
            num = (Integer) fVarBeginStructure.decodeNullableSerializableElement(gVar, 0, x0.INSTANCE, null);
            str = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 1, u2.INSTANCE, null);
            l10 = (Long) fVarBeginStructure.decodeNullableSerializableElement(gVar, 2, i1.INSTANCE, null);
            i10 = 7;
        } else {
            boolean z5 = true;
            int i11 = 0;
            String str2 = null;
            Long l11 = null;
            while (z5) {
                int iDecodeElementIndex = fVarBeginStructure.decodeElementIndex(gVar);
                if (iDecodeElementIndex == -1) {
                    z5 = false;
                } else if (iDecodeElementIndex == 0) {
                    num2 = (Integer) fVarBeginStructure.decodeNullableSerializableElement(gVar, 0, x0.INSTANCE, num2);
                    i11 |= 1;
                } else if (iDecodeElementIndex == 1) {
                    str2 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 1, u2.INSTANCE, str2);
                    i11 |= 2;
                } else {
                    if (iDecodeElementIndex != 2) {
                        throw new kotlinx.serialization.t(iDecodeElementIndex);
                    }
                    l11 = (Long) fVarBeginStructure.decodeNullableSerializableElement(gVar, 2, i1.INSTANCE, l11);
                    i11 |= 4;
                }
            }
            i10 = i11;
            num = num2;
            str = str2;
            l10 = l11;
        }
        fVarBeginStructure.endStructure(gVar);
        return new p(i10, num, str, l10);
    }

    @Override // kotlinx.serialization.internal.n0, kotlinx.serialization.b, kotlinx.serialization.l, kotlinx.serialization.a
    public final kotlinx.serialization.descriptors.g getDescriptor() {
        return descriptor;
    }

    @Override // kotlinx.serialization.internal.n0, kotlinx.serialization.b, kotlinx.serialization.l
    public final void serialize(kotlinx.serialization.encoding.l encoder, Object obj) {
        p value = (p) obj;
        kotlin.jvm.internal.q.g(encoder, "encoder");
        kotlin.jvm.internal.q.g(value, "value");
        Long l10 = value.f870c;
        String str = value.f869b;
        Integer num = value.f868a;
        kotlinx.serialization.descriptors.g gVar = descriptor;
        kotlinx.serialization.encoding.h hVarBeginStructure = encoder.beginStructure(gVar);
        if (hVarBeginStructure.shouldEncodeElementDefault(gVar, 0) || num != null) {
            hVarBeginStructure.encodeNullableSerializableElement(gVar, 0, x0.INSTANCE, num);
        }
        if (hVarBeginStructure.shouldEncodeElementDefault(gVar, 1) || str != null) {
            hVarBeginStructure.encodeNullableSerializableElement(gVar, 1, u2.INSTANCE, str);
        }
        if (hVarBeginStructure.shouldEncodeElementDefault(gVar, 2) || l10 != null) {
            hVarBeginStructure.encodeNullableSerializableElement(gVar, 2, i1.INSTANCE, l10);
        }
        hVarBeginStructure.endStructure(gVar);
    }

    @Override // kotlinx.serialization.internal.n0
    public final /* bridge */ kotlinx.serialization.b[] typeParametersSerializers() {
        return l0.a(this);
    }
}
