package al;

import kotlinx.serialization.internal.c2;
import tm.belet.films.data.response.home.ImagesDTO;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
@kotlinx.serialization.j
public final class f {
    public static final e Companion = new e();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Integer f832a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f833b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final ImagesDTO f834c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final String f835d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final Boolean f836e;
    public final String f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final String f837g;
    public final Long h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final c f838i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final Integer f839j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final ImagesDTO f840k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final Boolean f841l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final Long f842m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final Long f843n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final String f844o;

    public /* synthetic */ f(int i10, Integer num, String str, ImagesDTO imagesDTO, String str2, Boolean bool, String str3, String str4, Long l10, c cVar, Integer num2, ImagesDTO imagesDTO2, Boolean bool2, Long l11, Long l12, String str5) {
        if (32767 != (i10 & 32767)) {
            c2.throwMissingFieldException(i10, 32767, d.f826a.getDescriptor());
        }
        this.f832a = num;
        this.f833b = str;
        this.f834c = imagesDTO;
        this.f835d = str2;
        this.f836e = bool;
        this.f = str3;
        this.f837g = str4;
        this.h = l10;
        this.f838i = cVar;
        this.f839j = num2;
        this.f840k = imagesDTO2;
        this.f841l = bool2;
        this.f842m = l11;
        this.f843n = l12;
        this.f844o = str5;
    }

    public final nm.b a() {
        nm.a aVar;
        ImagesDTO imagesDTO = this.f834c;
        sm.j images = imagesDTO != null ? imagesDTO.toImages() : null;
        c cVar = this.f838i;
        if (cVar != null) {
            String str = cVar.f823a;
            bl.o oVar = cVar.f824b;
            aVar = new nm.a(str, oVar != null ? oVar.a() : null);
        } else {
            aVar = null;
        }
        ImagesDTO imagesDTO2 = this.f840k;
        return new nm.b(this.f832a, this.f833b, images, this.f835d, this.f836e, this.f, this.f837g, this.h, aVar, this.f839j, imagesDTO2 != null ? imagesDTO2.toImages() : null, this.f841l, this.f842m, this.f843n, this.f844o);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof f)) {
            return false;
        }
        f fVar = (f) obj;
        return kotlin.jvm.internal.q.c(this.f832a, fVar.f832a) && kotlin.jvm.internal.q.c(this.f833b, fVar.f833b) && kotlin.jvm.internal.q.c(this.f834c, fVar.f834c) && kotlin.jvm.internal.q.c(this.f835d, fVar.f835d) && kotlin.jvm.internal.q.c(this.f836e, fVar.f836e) && kotlin.jvm.internal.q.c(this.f, fVar.f) && kotlin.jvm.internal.q.c(this.f837g, fVar.f837g) && kotlin.jvm.internal.q.c(this.h, fVar.h) && kotlin.jvm.internal.q.c(this.f838i, fVar.f838i) && kotlin.jvm.internal.q.c(this.f839j, fVar.f839j) && kotlin.jvm.internal.q.c(this.f840k, fVar.f840k) && kotlin.jvm.internal.q.c(this.f841l, fVar.f841l) && kotlin.jvm.internal.q.c(this.f842m, fVar.f842m) && kotlin.jvm.internal.q.c(this.f843n, fVar.f843n) && kotlin.jvm.internal.q.c(this.f844o, fVar.f844o);
    }

    public final int hashCode() {
        Integer num = this.f832a;
        int iHashCode = (num == null ? 0 : num.hashCode()) * 31;
        String str = this.f833b;
        int iHashCode2 = (iHashCode + (str == null ? 0 : str.hashCode())) * 31;
        ImagesDTO imagesDTO = this.f834c;
        int iHashCode3 = (iHashCode2 + (imagesDTO == null ? 0 : imagesDTO.hashCode())) * 31;
        String str2 = this.f835d;
        int iHashCode4 = (iHashCode3 + (str2 == null ? 0 : str2.hashCode())) * 31;
        Boolean bool = this.f836e;
        int iHashCode5 = (iHashCode4 + (bool == null ? 0 : bool.hashCode())) * 31;
        String str3 = this.f;
        int iHashCode6 = (iHashCode5 + (str3 == null ? 0 : str3.hashCode())) * 31;
        String str4 = this.f837g;
        int iHashCode7 = (iHashCode6 + (str4 == null ? 0 : str4.hashCode())) * 31;
        Long l10 = this.h;
        int iHashCode8 = (iHashCode7 + (l10 == null ? 0 : l10.hashCode())) * 31;
        c cVar = this.f838i;
        int iHashCode9 = (iHashCode8 + (cVar == null ? 0 : cVar.hashCode())) * 31;
        Integer num2 = this.f839j;
        int iHashCode10 = (iHashCode9 + (num2 == null ? 0 : num2.hashCode())) * 31;
        ImagesDTO imagesDTO2 = this.f840k;
        int iHashCode11 = (iHashCode10 + (imagesDTO2 == null ? 0 : imagesDTO2.hashCode())) * 31;
        Boolean bool2 = this.f841l;
        int iHashCode12 = (iHashCode11 + (bool2 == null ? 0 : bool2.hashCode())) * 31;
        Long l11 = this.f842m;
        int iHashCode13 = (iHashCode12 + (l11 == null ? 0 : l11.hashCode())) * 31;
        Long l12 = this.f843n;
        int iHashCode14 = (iHashCode13 + (l12 == null ? 0 : l12.hashCode())) * 31;
        String str5 = this.f844o;
        return iHashCode14 + (str5 != null ? str5.hashCode() : 0);
    }

    public final String toString() {
        StringBuilder sbT = a0.f.t("EventDTO(id=", this.f832a, ", title=", this.f833b, ", images=");
        sbT.append(this.f834c);
        sbT.append(", tournament_title=");
        sbT.append(this.f835d);
        sbT.append(", is_notification_enabled=");
        sbT.append(this.f836e);
        sbT.append(", status=");
        sbT.append(this.f);
        sbT.append(", hls=");
        sbT.append(this.f837g);
        sbT.append(", views=");
        sbT.append(this.h);
        sbT.append(", age_restriction=");
        sbT.append(this.f838i);
        sbT.append(", tournament_id=");
        sbT.append(this.f839j);
        sbT.append(", tournament_images=");
        sbT.append(this.f840k);
        sbT.append(", is_tournament_subscribed=");
        sbT.append(this.f841l);
        sbT.append(", tournament_subscribers_count=");
        sbT.append(this.f842m);
        sbT.append(", start_time_in_unix=");
        sbT.append(this.f843n);
        sbT.append(", voting_text=");
        return a0.f.r(sbT, this.f844o, ")");
    }
}
