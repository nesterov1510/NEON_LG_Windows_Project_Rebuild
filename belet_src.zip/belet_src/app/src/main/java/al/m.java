package al;

import com.google.protobuf.m0;
import java.util.List;
import kotlinx.serialization.internal.c2;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
@kotlinx.serialization.j
public final class m {
    public static final l Companion = new l();

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final qi.f[] f863d = {null, null, g0.c.v(qi.g.f17354e, new j(0))};

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f864a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f865b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final List f866c;

    public /* synthetic */ m(int i10, String str, String str2, List list) {
        if (7 != (i10 & 7)) {
            c2.throwMissingFieldException(i10, 7, k.f856a.getDescriptor());
        }
        this.f864a = str;
        this.f865b = str2;
        this.f866c = list;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof m)) {
            return false;
        }
        m mVar = (m) obj;
        return kotlin.jvm.internal.q.c(this.f864a, mVar.f864a) && kotlin.jvm.internal.q.c(this.f865b, mVar.f865b) && kotlin.jvm.internal.q.c(this.f866c, mVar.f866c);
    }

    public final int hashCode() {
        String str = this.f864a;
        int iHashCode = (str == null ? 0 : str.hashCode()) * 31;
        String str2 = this.f865b;
        int iHashCode2 = (iHashCode + (str2 == null ? 0 : str2.hashCode())) * 31;
        List list = this.f866c;
        return iHashCode2 + (list != null ? list.hashCode() : 0);
    }

    public final String toString() {
        StringBuilder sbN = m0.n("EventsRespDTO(status=", this.f864a, ", message=", this.f865b, ", content=");
        sbN.append(this.f866c);
        sbN.append(")");
        return sbN.toString();
    }
}
