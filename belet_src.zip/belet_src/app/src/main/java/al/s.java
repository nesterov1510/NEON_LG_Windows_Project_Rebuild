package al;

import kotlinx.serialization.internal.c2;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
@kotlinx.serialization.j
public final class s {
    public static final r Companion = new r();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Long f872a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f873b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Long f874c;

    public /* synthetic */ s(int i10, Long l10, String str, Long l11) {
        if (7 != (i10 & 7)) {
            c2.throwMissingFieldException(i10, 7, q.f871a.getDescriptor());
        }
        this.f872a = l10;
        this.f873b = str;
        this.f874c = l11;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof s)) {
            return false;
        }
        s sVar = (s) obj;
        return kotlin.jvm.internal.q.c(this.f872a, sVar.f872a) && kotlin.jvm.internal.q.c(this.f873b, sVar.f873b) && kotlin.jvm.internal.q.c(this.f874c, sVar.f874c);
    }

    public final int hashCode() {
        Long l10 = this.f872a;
        int iHashCode = (l10 == null ? 0 : l10.hashCode()) * 31;
        String str = this.f873b;
        int iHashCode2 = (iHashCode + (str == null ? 0 : str.hashCode())) * 31;
        Long l11 = this.f874c;
        return iHashCode2 + (l11 != null ? l11.hashCode() : 0);
    }

    public final String toString() {
        return "LiveInfoDTO(views=" + this.f872a + ", status=" + this.f873b + ", start_time_in_unix=" + this.f874c + ")";
    }
}
