package al;

import java.util.List;
import kotlinx.serialization.internal.e2;
import kotlinx.serialization.internal.i1;
import kotlinx.serialization.internal.l0;
import kotlinx.serialization.internal.n0;
import kotlinx.serialization.internal.u2;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class i0 implements n0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final i0 f854a;
    private static final kotlinx.serialization.descriptors.g descriptor;

    static {
        i0 i0Var = new i0();
        f854a = i0Var;
        e2 e2Var = new e2("tm.belet.films.data.response.events.VoteInfoDTO", i0Var, 7);
        e2Var.addElement("title", true);
        e2Var.addElement("groups", true);
        e2Var.addElement("groups_count", true);
        e2Var.addElement("total_votes", true);
        e2Var.addElement("others_button_text", true);
        e2Var.addElement("total_votes_text", true);
        e2Var.addElement("description", true);
        descriptor = e2Var;
    }

    @Override // kotlinx.serialization.internal.n0
    public final kotlinx.serialization.b[] childSerializers() {
        qi.f[] fVarArr = k0.h;
        u2 u2Var = u2.INSTANCE;
        kotlinx.serialization.b nullable = wj.a.getNullable(u2Var);
        kotlinx.serialization.b nullable2 = wj.a.getNullable((kotlinx.serialization.b) fVarArr[1].getValue());
        i1 i1Var = i1.INSTANCE;
        return new kotlinx.serialization.b[]{nullable, nullable2, wj.a.getNullable(i1Var), wj.a.getNullable(i1Var), wj.a.getNullable(u2Var), wj.a.getNullable(u2Var), wj.a.getNullable(u2Var)};
    }

    @Override // kotlinx.serialization.internal.n0, kotlinx.serialization.b, kotlinx.serialization.a
    public final Object deserialize(kotlinx.serialization.encoding.j decoder) {
        int i10;
        String str;
        String str2;
        String str3;
        List list;
        Long l10;
        Long l11;
        String str4;
        kotlin.jvm.internal.q.g(decoder, "decoder");
        kotlinx.serialization.descriptors.g gVar = descriptor;
        kotlinx.serialization.encoding.f fVarBeginStructure = decoder.beginStructure(gVar);
        qi.f[] fVarArr = k0.h;
        int i11 = 6;
        String str5 = null;
        if (fVarBeginStructure.decodeSequentially()) {
            u2 u2Var = u2.INSTANCE;
            String str6 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 0, u2Var, null);
            List list2 = (List) fVarBeginStructure.decodeNullableSerializableElement(gVar, 1, (kotlinx.serialization.a) fVarArr[1].getValue(), null);
            i1 i1Var = i1.INSTANCE;
            Long l12 = (Long) fVarBeginStructure.decodeNullableSerializableElement(gVar, 2, i1Var, null);
            Long l13 = (Long) fVarBeginStructure.decodeNullableSerializableElement(gVar, 3, i1Var, null);
            String str7 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 4, u2Var, null);
            String str8 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 5, u2Var, null);
            list = list2;
            str = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 6, u2Var, null);
            i10 = 127;
            str2 = str8;
            l11 = l13;
            str4 = str7;
            l10 = l12;
            str3 = str6;
        } else {
            int i12 = 1;
            boolean z5 = true;
            int i13 = 0;
            String str9 = null;
            String str10 = null;
            List list3 = null;
            Long l14 = null;
            Long l15 = null;
            String str11 = null;
            while (z5) {
                int iDecodeElementIndex = fVarBeginStructure.decodeElementIndex(gVar);
                switch (iDecodeElementIndex) {
                    case -1:
                        z5 = false;
                        i11 = 6;
                        i12 = 1;
                        break;
                    case 0:
                        str5 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 0, u2.INSTANCE, str5);
                        i13 |= 1;
                        i11 = 6;
                        i12 = 1;
                        break;
                    case 1:
                        list3 = (List) fVarBeginStructure.decodeNullableSerializableElement(gVar, i12, (kotlinx.serialization.a) fVarArr[i12].getValue(), list3);
                        i13 |= 2;
                        i11 = 6;
                        break;
                    case 2:
                        l14 = (Long) fVarBeginStructure.decodeNullableSerializableElement(gVar, 2, i1.INSTANCE, l14);
                        i13 |= 4;
                        i11 = 6;
                        break;
                    case 3:
                        l15 = (Long) fVarBeginStructure.decodeNullableSerializableElement(gVar, 3, i1.INSTANCE, l15);
                        i13 |= 8;
                        break;
                    case 4:
                        str11 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 4, u2.INSTANCE, str11);
                        i13 |= 16;
                        break;
                    case 5:
                        str10 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 5, u2.INSTANCE, str10);
                        i13 |= 32;
                        break;
                    case 6:
                        str9 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, i11, u2.INSTANCE, str9);
                        i13 |= 64;
                        break;
                    default:
                        throw new kotlinx.serialization.t(iDecodeElementIndex);
                }
            }
            i10 = i13;
            str = str9;
            str2 = str10;
            str3 = str5;
            list = list3;
            l10 = l14;
            l11 = l15;
            str4 = str11;
        }
        fVarBeginStructure.endStructure(gVar);
        return new k0(i10, str3, list, l10, l11, str4, str2, str);
    }

    @Override // kotlinx.serialization.internal.n0, kotlinx.serialization.b, kotlinx.serialization.l, kotlinx.serialization.a
    public final kotlinx.serialization.descriptors.g getDescriptor() {
        return descriptor;
    }

    @Override // kotlinx.serialization.internal.n0, kotlinx.serialization.b, kotlinx.serialization.l
    public final void serialize(kotlinx.serialization.encoding.l encoder, Object obj) {
        k0 value = (k0) obj;
        kotlin.jvm.internal.q.g(encoder, "encoder");
        kotlin.jvm.internal.q.g(value, "value");
        String str = value.f862g;
        String str2 = value.f;
        String str3 = value.f861e;
        Long l10 = value.f860d;
        Long l11 = value.f859c;
        List list = value.f858b;
        String str4 = value.f857a;
        kotlinx.serialization.descriptors.g gVar = descriptor;
        kotlinx.serialization.encoding.h hVarBeginStructure = encoder.beginStructure(gVar);
        qi.f[] fVarArr = k0.h;
        if (hVarBeginStructure.shouldEncodeElementDefault(gVar, 0) || str4 != null) {
            hVarBeginStructure.encodeNullableSerializableElement(gVar, 0, u2.INSTANCE, str4);
        }
        if (hVarBeginStructure.shouldEncodeElementDefault(gVar, 1) || list != null) {
            hVarBeginStructure.encodeNullableSerializableElement(gVar, 1, (kotlinx.serialization.l) fVarArr[1].getValue(), list);
        }
        if (hVarBeginStructure.shouldEncodeElementDefault(gVar, 2) || l11 != null) {
            hVarBeginStructure.encodeNullableSerializableElement(gVar, 2, i1.INSTANCE, l11);
        }
        if (hVarBeginStructure.shouldEncodeElementDefault(gVar, 3) || l10 != null) {
            hVarBeginStructure.encodeNullableSerializableElement(gVar, 3, i1.INSTANCE, l10);
        }
        if (hVarBeginStructure.shouldEncodeElementDefault(gVar, 4) || str3 != null) {
            hVarBeginStructure.encodeNullableSerializableElement(gVar, 4, u2.INSTANCE, str3);
        }
        if (hVarBeginStructure.shouldEncodeElementDefault(gVar, 5) || str2 != null) {
            hVarBeginStructure.encodeNullableSerializableElement(gVar, 5, u2.INSTANCE, str2);
        }
        if (hVarBeginStructure.shouldEncodeElementDefault(gVar, 6) || str != null) {
            hVarBeginStructure.encodeNullableSerializableElement(gVar, 6, u2.INSTANCE, str);
        }
        hVarBeginStructure.endStructure(gVar);
    }

    @Override // kotlinx.serialization.internal.n0
    public final /* bridge */ kotlinx.serialization.b[] typeParametersSerializers() {
        return l0.a(this);
    }
}
