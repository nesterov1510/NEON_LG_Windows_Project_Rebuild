package al;

import java.util.List;
import kotlinx.serialization.internal.e2;
import kotlinx.serialization.internal.i1;
import kotlinx.serialization.internal.l0;
import kotlinx.serialization.internal.n0;
import kotlinx.serialization.internal.u2;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class w implements n0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final w f879a;
    private static final kotlinx.serialization.descriptors.g descriptor;

    static {
        w wVar = new w();
        f879a = wVar;
        e2 e2Var = new e2("tm.belet.films.data.response.events.MembersDTO", wVar, 6);
        e2Var.addElement("title", true);
        e2Var.addElement("members", true);
        e2Var.addElement("total_votes", true);
        e2Var.addElement("total_votes_text", true);
        e2Var.addElement("description", true);
        e2Var.addElement("is_votable", true);
        descriptor = e2Var;
    }

    @Override // kotlinx.serialization.internal.n0
    public final kotlinx.serialization.b[] childSerializers() {
        qi.f[] fVarArr = y.f880g;
        u2 u2Var = u2.INSTANCE;
        return new kotlinx.serialization.b[]{wj.a.getNullable(u2Var), wj.a.getNullable((kotlinx.serialization.b) fVarArr[1].getValue()), wj.a.getNullable(i1.INSTANCE), wj.a.getNullable(u2Var), wj.a.getNullable(u2Var), wj.a.getNullable(kotlinx.serialization.internal.i.INSTANCE)};
    }

    @Override // kotlinx.serialization.internal.n0, kotlinx.serialization.b, kotlinx.serialization.a
    public final Object deserialize(kotlinx.serialization.encoding.j decoder) {
        int i10;
        String str;
        List list;
        Long l10;
        String str2;
        String str3;
        Boolean bool;
        kotlin.jvm.internal.q.g(decoder, "decoder");
        kotlinx.serialization.descriptors.g gVar = descriptor;
        kotlinx.serialization.encoding.f fVarBeginStructure = decoder.beginStructure(gVar);
        qi.f[] fVarArr = y.f880g;
        int i11 = 5;
        String str4 = null;
        if (fVarBeginStructure.decodeSequentially()) {
            u2 u2Var = u2.INSTANCE;
            String str5 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 0, u2Var, null);
            List list2 = (List) fVarBeginStructure.decodeNullableSerializableElement(gVar, 1, (kotlinx.serialization.a) fVarArr[1].getValue(), null);
            Long l11 = (Long) fVarBeginStructure.decodeNullableSerializableElement(gVar, 2, i1.INSTANCE, null);
            String str6 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 3, u2Var, null);
            list = list2;
            str3 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 4, u2Var, null);
            bool = (Boolean) fVarBeginStructure.decodeNullableSerializableElement(gVar, 5, kotlinx.serialization.internal.i.INSTANCE, null);
            str2 = str6;
            i10 = 63;
            l10 = l11;
            str = str5;
        } else {
            boolean z5 = true;
            int i12 = 0;
            List list3 = null;
            Long l12 = null;
            String str7 = null;
            String str8 = null;
            Boolean bool2 = null;
            while (z5) {
                int iDecodeElementIndex = fVarBeginStructure.decodeElementIndex(gVar);
                switch (iDecodeElementIndex) {
                    case -1:
                        z5 = false;
                        i11 = 5;
                        break;
                    case 0:
                        str4 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 0, u2.INSTANCE, str4);
                        i12 |= 1;
                        i11 = 5;
                        break;
                    case 1:
                        list3 = (List) fVarBeginStructure.decodeNullableSerializableElement(gVar, 1, (kotlinx.serialization.a) fVarArr[1].getValue(), list3);
                        i12 |= 2;
                        break;
                    case 2:
                        l12 = (Long) fVarBeginStructure.decodeNullableSerializableElement(gVar, 2, i1.INSTANCE, l12);
                        i12 |= 4;
                        break;
                    case 3:
                        str7 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 3, u2.INSTANCE, str7);
                        i12 |= 8;
                        break;
                    case 4:
                        str8 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 4, u2.INSTANCE, str8);
                        i12 |= 16;
                        break;
                    case 5:
                        bool2 = (Boolean) fVarBeginStructure.decodeNullableSerializableElement(gVar, i11, kotlinx.serialization.internal.i.INSTANCE, bool2);
                        i12 |= 32;
                        break;
                    default:
                        throw new kotlinx.serialization.t(iDecodeElementIndex);
                }
            }
            i10 = i12;
            str = str4;
            list = list3;
            l10 = l12;
            str2 = str7;
            str3 = str8;
            bool = bool2;
        }
        fVarBeginStructure.endStructure(gVar);
        return new y(i10, str, list, l10, str2, str3, bool);
    }

    @Override // kotlinx.serialization.internal.n0, kotlinx.serialization.b, kotlinx.serialization.l, kotlinx.serialization.a
    public final kotlinx.serialization.descriptors.g getDescriptor() {
        return descriptor;
    }

    @Override // kotlinx.serialization.internal.n0, kotlinx.serialization.b, kotlinx.serialization.l
    public final void serialize(kotlinx.serialization.encoding.l encoder, Object obj) {
        y value = (y) obj;
        kotlin.jvm.internal.q.g(encoder, "encoder");
        kotlin.jvm.internal.q.g(value, "value");
        Boolean bool = value.f;
        String str = value.f885e;
        String str2 = value.f884d;
        Long l10 = value.f883c;
        List list = value.f882b;
        String str3 = value.f881a;
        kotlinx.serialization.descriptors.g gVar = descriptor;
        kotlinx.serialization.encoding.h hVarBeginStructure = encoder.beginStructure(gVar);
        qi.f[] fVarArr = y.f880g;
        if (hVarBeginStructure.shouldEncodeElementDefault(gVar, 0) || str3 != null) {
            hVarBeginStructure.encodeNullableSerializableElement(gVar, 0, u2.INSTANCE, str3);
        }
        if (hVarBeginStructure.shouldEncodeElementDefault(gVar, 1) || list != null) {
            hVarBeginStructure.encodeNullableSerializableElement(gVar, 1, (kotlinx.serialization.l) fVarArr[1].getValue(), list);
        }
        if (hVarBeginStructure.shouldEncodeElementDefault(gVar, 2) || l10 != null) {
            hVarBeginStructure.encodeNullableSerializableElement(gVar, 2, i1.INSTANCE, l10);
        }
        if (hVarBeginStructure.shouldEncodeElementDefault(gVar, 3) || str2 != null) {
            hVarBeginStructure.encodeNullableSerializableElement(gVar, 3, u2.INSTANCE, str2);
        }
        if (hVarBeginStructure.shouldEncodeElementDefault(gVar, 4) || str != null) {
            hVarBeginStructure.encodeNullableSerializableElement(gVar, 4, u2.INSTANCE, str);
        }
        if (hVarBeginStructure.shouldEncodeElementDefault(gVar, 5) || !kotlin.jvm.internal.q.c(bool, Boolean.FALSE)) {
            hVarBeginStructure.encodeNullableSerializableElement(gVar, 5, kotlinx.serialization.internal.i.INSTANCE, bool);
        }
        hVarBeginStructure.endStructure(gVar);
    }

    @Override // kotlinx.serialization.internal.n0
    public final /* bridge */ kotlinx.serialization.b[] typeParametersSerializers() {
        return l0.a(this);
    }
}
