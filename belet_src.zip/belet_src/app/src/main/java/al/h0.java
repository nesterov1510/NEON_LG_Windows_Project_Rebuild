package al;

import com.google.protobuf.m0;
import kotlinx.serialization.internal.c2;
import okhttp3.internal.url._UrlKt;
import tm.belet.films.data.response.home.ImagesDTO;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
@kotlinx.serialization.j
public final class h0 {
    public static final g0 Companion = new g0();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f847a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f848b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final e0 f849c;

    public /* synthetic */ h0(int i10, String str, String str2, e0 e0Var) {
        if (7 != (i10 & 7)) {
            c2.throwMissingFieldException(i10, 7, f0.f845a.getDescriptor());
        }
        this.f847a = str;
        this.f848b = str2;
        this.f849c = e0Var;
    }

    public final nm.f a() {
        nm.e eVar = null;
        e0 e0Var = this.f849c;
        if (e0Var != null) {
            Long l10 = e0Var.f827a;
            String str = e0Var.f828b;
            ImagesDTO imagesDTO = e0Var.f829c;
            eVar = new nm.e(l10, str, imagesDTO != null ? imagesDTO.toImages() : null, e0Var.f830d, e0Var.f831e, e0Var.f);
        }
        String str2 = _UrlKt.FRAGMENT_ENCODE_SET;
        String str3 = this.f848b;
        if (str3 == null) {
            str3 = _UrlKt.FRAGMENT_ENCODE_SET;
        }
        String str4 = this.f847a;
        if (str4 != null) {
            str2 = str4;
        }
        return new nm.f(eVar, str3, str2);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof h0)) {
            return false;
        }
        h0 h0Var = (h0) obj;
        return kotlin.jvm.internal.q.c(this.f847a, h0Var.f847a) && kotlin.jvm.internal.q.c(this.f848b, h0Var.f848b) && kotlin.jvm.internal.q.c(this.f849c, h0Var.f849c);
    }

    public final int hashCode() {
        String str = this.f847a;
        int iHashCode = (str == null ? 0 : str.hashCode()) * 31;
        String str2 = this.f848b;
        int iHashCode2 = (iHashCode + (str2 == null ? 0 : str2.hashCode())) * 31;
        e0 e0Var = this.f849c;
        return iHashCode2 + (e0Var != null ? e0Var.hashCode() : 0);
    }

    public final String toString() {
        StringBuilder sbN = m0.n("TournamentInfoDTO(status=", this.f847a, ", message=", this.f848b, ", tournament=");
        sbN.append(this.f849c);
        sbN.append(")");
        return sbN.toString();
    }
}
