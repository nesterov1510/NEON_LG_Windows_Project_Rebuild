package al;

import kotlinx.serialization.internal.c2;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
@kotlinx.serialization.j
public final class c {
    public static final b Companion = new b();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f823a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final bl.o f824b;

    public /* synthetic */ c(int i10, String str, bl.o oVar) {
        if (3 != (i10 & 3)) {
            c2.throwMissingFieldException(i10, 3, a.f816a.getDescriptor());
        }
        this.f823a = str;
        this.f824b = oVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof c)) {
            return false;
        }
        c cVar = (c) obj;
        return kotlin.jvm.internal.q.c(this.f823a, cVar.f823a) && kotlin.jvm.internal.q.c(this.f824b, cVar.f824b);
    }

    public final int hashCode() {
        String str = this.f823a;
        int iHashCode = (str == null ? 0 : str.hashCode()) * 31;
        bl.o oVar = this.f824b;
        return iHashCode + (oVar != null ? oVar.hashCode() : 0);
    }

    public final String toString() {
        return "AgeRestrictionDTO(age=" + this.f823a + ", warning=" + this.f824b + ")";
    }
}
