package al;

import kotlinx.serialization.internal.e2;
import kotlinx.serialization.internal.l0;
import kotlinx.serialization.internal.n0;
import kotlinx.serialization.internal.u2;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class g implements n0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final g f846a;
    private static final kotlinx.serialization.descriptors.g descriptor;

    static {
        g gVar = new g();
        f846a = gVar;
        e2 e2Var = new e2("tm.belet.films.data.response.events.EventRespDTO", gVar, 4);
        e2Var.addElement("status", false);
        e2Var.addElement("message", false);
        e2Var.addElement("event", false);
        e2Var.addElement("vote_info_v2", true);
        descriptor = e2Var;
    }

    @Override // kotlinx.serialization.internal.n0
    public final kotlinx.serialization.b[] childSerializers() {
        u2 u2Var = u2.INSTANCE;
        return new kotlinx.serialization.b[]{wj.a.getNullable(u2Var), wj.a.getNullable(u2Var), wj.a.getNullable(d.f826a), wj.a.getNullable(i0.f854a)};
    }

    @Override // kotlinx.serialization.internal.n0, kotlinx.serialization.b, kotlinx.serialization.a
    public final Object deserialize(kotlinx.serialization.encoding.j decoder) {
        int i10;
        String str;
        String str2;
        f fVar;
        k0 k0Var;
        kotlin.jvm.internal.q.g(decoder, "decoder");
        kotlinx.serialization.descriptors.g gVar = descriptor;
        kotlinx.serialization.encoding.f fVarBeginStructure = decoder.beginStructure(gVar);
        String str3 = null;
        if (fVarBeginStructure.decodeSequentially()) {
            u2 u2Var = u2.INSTANCE;
            String str4 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 0, u2Var, null);
            String str5 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 1, u2Var, null);
            f fVar2 = (f) fVarBeginStructure.decodeNullableSerializableElement(gVar, 2, d.f826a, null);
            str2 = str5;
            k0Var = (k0) fVarBeginStructure.decodeNullableSerializableElement(gVar, 3, i0.f854a, null);
            fVar = fVar2;
            i10 = 15;
            str = str4;
        } else {
            boolean z5 = true;
            int i11 = 0;
            String str6 = null;
            f fVar3 = null;
            k0 k0Var2 = null;
            while (z5) {
                int iDecodeElementIndex = fVarBeginStructure.decodeElementIndex(gVar);
                if (iDecodeElementIndex == -1) {
                    z5 = false;
                } else if (iDecodeElementIndex == 0) {
                    str3 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 0, u2.INSTANCE, str3);
                    i11 |= 1;
                } else if (iDecodeElementIndex == 1) {
                    str6 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 1, u2.INSTANCE, str6);
                    i11 |= 2;
                } else if (iDecodeElementIndex == 2) {
                    fVar3 = (f) fVarBeginStructure.decodeNullableSerializableElement(gVar, 2, d.f826a, fVar3);
                    i11 |= 4;
                } else {
                    if (iDecodeElementIndex != 3) {
                        throw new kotlinx.serialization.t(iDecodeElementIndex);
                    }
                    k0Var2 = (k0) fVarBeginStructure.decodeNullableSerializableElement(gVar, 3, i0.f854a, k0Var2);
                    i11 |= 8;
                }
            }
            i10 = i11;
            str = str3;
            str2 = str6;
            fVar = fVar3;
            k0Var = k0Var2;
        }
        fVarBeginStructure.endStructure(gVar);
        return new i(i10, str, str2, fVar, k0Var);
    }

    @Override // kotlinx.serialization.internal.n0, kotlinx.serialization.b, kotlinx.serialization.l, kotlinx.serialization.a
    public final kotlinx.serialization.descriptors.g getDescriptor() {
        return descriptor;
    }

    @Override // kotlinx.serialization.internal.n0, kotlinx.serialization.b, kotlinx.serialization.l
    public final void serialize(kotlinx.serialization.encoding.l encoder, Object obj) {
        i value = (i) obj;
        kotlin.jvm.internal.q.g(encoder, "encoder");
        kotlin.jvm.internal.q.g(value, "value");
        kotlinx.serialization.descriptors.g gVar = descriptor;
        kotlinx.serialization.encoding.h hVarBeginStructure = encoder.beginStructure(gVar);
        u2 u2Var = u2.INSTANCE;
        String str = value.f850a;
        k0 k0Var = value.f853d;
        hVarBeginStructure.encodeNullableSerializableElement(gVar, 0, u2Var, str);
        hVarBeginStructure.encodeNullableSerializableElement(gVar, 1, u2Var, value.f851b);
        hVarBeginStructure.encodeNullableSerializableElement(gVar, 2, d.f826a, value.f852c);
        if (hVarBeginStructure.shouldEncodeElementDefault(gVar, 3) || k0Var != null) {
            hVarBeginStructure.encodeNullableSerializableElement(gVar, 3, i0.f854a, k0Var);
        }
        hVarBeginStructure.endStructure(gVar);
    }

    @Override // kotlinx.serialization.internal.n0
    public final /* bridge */ kotlinx.serialization.b[] typeParametersSerializers() {
        return l0.a(this);
    }
}
