package al;

import java.util.ArrayList;
import java.util.List;
import tm.belet.films.domain.models.events.Members;
import tm.belet.films.domain.models.events.Team;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
@kotlinx.serialization.j
public final class y {
    public static final x Companion = new x();

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static final qi.f[] f880g = {null, g0.c.v(qi.g.f17354e, new j(1)), null, null, null, null};

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f881a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final List f882b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Long f883c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final String f884d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final String f885e;
    public final Boolean f;

    public /* synthetic */ y(int i10, String str, List list, Long l10, String str2, String str3, Boolean bool) {
        if ((i10 & 1) == 0) {
            this.f881a = null;
        } else {
            this.f881a = str;
        }
        if ((i10 & 2) == 0) {
            this.f882b = null;
        } else {
            this.f882b = list;
        }
        if ((i10 & 4) == 0) {
            this.f883c = null;
        } else {
            this.f883c = l10;
        }
        if ((i10 & 8) == 0) {
            this.f884d = null;
        } else {
            this.f884d = str2;
        }
        if ((i10 & 16) == 0) {
            this.f885e = null;
        } else {
            this.f885e = str3;
        }
        if ((i10 & 32) == 0) {
            this.f = Boolean.FALSE;
        } else {
            this.f = bool;
        }
    }

    public final Members a() {
        ArrayList arrayList;
        List<b0> list = this.f882b;
        if (list != null) {
            ArrayList arrayList2 = new ArrayList(ri.o.S(list, 10));
            for (b0 b0Var : list) {
                arrayList2.add(b0Var != null ? new Team(b0Var.f817a, b0Var.f818b, b0Var.f819c, b0Var.f820d, b0Var.f821e, b0Var.f, b0Var.f822g, b0Var.h) : null);
            }
            arrayList = arrayList2;
        } else {
            arrayList = null;
        }
        return new Members(this.f881a, arrayList, this.f883c, this.f884d, this.f885e, this.f);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof y)) {
            return false;
        }
        y yVar = (y) obj;
        return kotlin.jvm.internal.q.c(this.f881a, yVar.f881a) && kotlin.jvm.internal.q.c(this.f882b, yVar.f882b) && kotlin.jvm.internal.q.c(this.f883c, yVar.f883c) && kotlin.jvm.internal.q.c(this.f884d, yVar.f884d) && kotlin.jvm.internal.q.c(this.f885e, yVar.f885e) && kotlin.jvm.internal.q.c(this.f, yVar.f);
    }

    public final int hashCode() {
        String str = this.f881a;
        int iHashCode = (str == null ? 0 : str.hashCode()) * 31;
        List list = this.f882b;
        int iHashCode2 = (iHashCode + (list == null ? 0 : list.hashCode())) * 31;
        Long l10 = this.f883c;
        int iHashCode3 = (iHashCode2 + (l10 == null ? 0 : l10.hashCode())) * 31;
        String str2 = this.f884d;
        int iHashCode4 = (iHashCode3 + (str2 == null ? 0 : str2.hashCode())) * 31;
        String str3 = this.f885e;
        int iHashCode5 = (iHashCode4 + (str3 == null ? 0 : str3.hashCode())) * 31;
        Boolean bool = this.f;
        return iHashCode5 + (bool != null ? bool.hashCode() : 0);
    }

    public final String toString() {
        return "MembersDTO(title=" + this.f881a + ", members=" + this.f882b + ", total_votes=" + this.f883c + ", total_votes_text=" + this.f884d + ", description=" + this.f885e + ", is_votable=" + this.f + ")";
    }
}
