package al;

import java.util.ArrayList;
import java.util.List;
import tm.belet.films.domain.models.events.Group;
import tm.belet.films.domain.models.events.VoteInfo;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
@kotlinx.serialization.j
public final class k0 {
    public static final j0 Companion = new j0();
    public static final qi.f[] h = {null, g0.c.v(qi.g.f17354e, new j(2)), null, null, null, null, null};

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f857a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final List f858b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Long f859c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Long f860d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final String f861e;
    public final String f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final String f862g;

    public /* synthetic */ k0(int i10, String str, List list, Long l10, Long l11, String str2, String str3, String str4) {
        if ((i10 & 1) == 0) {
            this.f857a = null;
        } else {
            this.f857a = str;
        }
        if ((i10 & 2) == 0) {
            this.f858b = null;
        } else {
            this.f858b = list;
        }
        if ((i10 & 4) == 0) {
            this.f859c = null;
        } else {
            this.f859c = l10;
        }
        if ((i10 & 8) == 0) {
            this.f860d = null;
        } else {
            this.f860d = l11;
        }
        if ((i10 & 16) == 0) {
            this.f861e = null;
        } else {
            this.f861e = str2;
        }
        if ((i10 & 32) == 0) {
            this.f = null;
        } else {
            this.f = str3;
        }
        if ((i10 & 64) == 0) {
            this.f862g = null;
        } else {
            this.f862g = str4;
        }
    }

    public final VoteInfo a() {
        ArrayList arrayList;
        List<p> list = this.f858b;
        if (list != null) {
            ArrayList arrayList2 = new ArrayList(ri.o.S(list, 10));
            for (p pVar : list) {
                arrayList2.add(pVar != null ? new Group(pVar.f868a, pVar.f869b, pVar.f870c) : null);
            }
            arrayList = arrayList2;
        } else {
            arrayList = null;
        }
        return new VoteInfo(this.f857a, arrayList, this.f859c, this.f860d, this.f861e, this.f, this.f862g);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof k0)) {
            return false;
        }
        k0 k0Var = (k0) obj;
        return kotlin.jvm.internal.q.c(this.f857a, k0Var.f857a) && kotlin.jvm.internal.q.c(this.f858b, k0Var.f858b) && kotlin.jvm.internal.q.c(this.f859c, k0Var.f859c) && kotlin.jvm.internal.q.c(this.f860d, k0Var.f860d) && kotlin.jvm.internal.q.c(this.f861e, k0Var.f861e) && kotlin.jvm.internal.q.c(this.f, k0Var.f) && kotlin.jvm.internal.q.c(this.f862g, k0Var.f862g);
    }

    public final int hashCode() {
        String str = this.f857a;
        int iHashCode = (str == null ? 0 : str.hashCode()) * 31;
        List list = this.f858b;
        int iHashCode2 = (iHashCode + (list == null ? 0 : list.hashCode())) * 31;
        Long l10 = this.f859c;
        int iHashCode3 = (iHashCode2 + (l10 == null ? 0 : l10.hashCode())) * 31;
        Long l11 = this.f860d;
        int iHashCode4 = (iHashCode3 + (l11 == null ? 0 : l11.hashCode())) * 31;
        String str2 = this.f861e;
        int iHashCode5 = (iHashCode4 + (str2 == null ? 0 : str2.hashCode())) * 31;
        String str3 = this.f;
        int iHashCode6 = (iHashCode5 + (str3 == null ? 0 : str3.hashCode())) * 31;
        String str4 = this.f862g;
        return iHashCode6 + (str4 != null ? str4.hashCode() : 0);
    }

    public final String toString() {
        StringBuilder sb2 = new StringBuilder("VoteInfoDTO(title=");
        sb2.append(this.f857a);
        sb2.append(", groups=");
        sb2.append(this.f858b);
        sb2.append(", groups_count=");
        sb2.append(this.f859c);
        sb2.append(", total_votes=");
        sb2.append(this.f860d);
        sb2.append(", others_button_text=");
        kotlin.jvm.internal.p.O(sb2, this.f861e, ", total_votes_text=", this.f, ", description=");
        return a0.f.r(sb2, this.f862g, ")");
    }
}
