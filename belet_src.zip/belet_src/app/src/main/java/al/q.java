package al;

import kotlinx.serialization.internal.e2;
import kotlinx.serialization.internal.i1;
import kotlinx.serialization.internal.l0;
import kotlinx.serialization.internal.n0;
import kotlinx.serialization.internal.u2;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class q implements n0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final q f871a;
    private static final kotlinx.serialization.descriptors.g descriptor;

    static {
        q qVar = new q();
        f871a = qVar;
        e2 e2Var = new e2("tm.belet.films.data.response.events.LiveInfoDTO", qVar, 3);
        e2Var.addElement("views", false);
        e2Var.addElement("status", false);
        e2Var.addElement("start_time_in_unix", false);
        descriptor = e2Var;
    }

    @Override // kotlinx.serialization.internal.n0
    public final kotlinx.serialization.b[] childSerializers() {
        i1 i1Var = i1.INSTANCE;
        return new kotlinx.serialization.b[]{wj.a.getNullable(i1Var), wj.a.getNullable(u2.INSTANCE), wj.a.getNullable(i1Var)};
    }

    @Override // kotlinx.serialization.internal.n0, kotlinx.serialization.b, kotlinx.serialization.a
    public final Object deserialize(kotlinx.serialization.encoding.j decoder) {
        int i10;
        Long l10;
        String str;
        Long l11;
        kotlin.jvm.internal.q.g(decoder, "decoder");
        kotlinx.serialization.descriptors.g gVar = descriptor;
        kotlinx.serialization.encoding.f fVarBeginStructure = decoder.beginStructure(gVar);
        Long l12 = null;
        if (fVarBeginStructure.decodeSequentially()) {
            i1 i1Var = i1.INSTANCE;
            l10 = (Long) fVarBeginStructure.decodeNullableSerializableElement(gVar, 0, i1Var, null);
            str = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 1, u2.INSTANCE, null);
            l11 = (Long) fVarBeginStructure.decodeNullableSerializableElement(gVar, 2, i1Var, null);
            i10 = 7;
        } else {
            boolean z5 = true;
            int i11 = 0;
            String str2 = null;
            Long l13 = null;
            while (z5) {
                int iDecodeElementIndex = fVarBeginStructure.decodeElementIndex(gVar);
                if (iDecodeElementIndex == -1) {
                    z5 = false;
                } else if (iDecodeElementIndex == 0) {
                    l12 = (Long) fVarBeginStructure.decodeNullableSerializableElement(gVar, 0, i1.INSTANCE, l12);
                    i11 |= 1;
                } else if (iDecodeElementIndex == 1) {
                    str2 = (String) fVarBeginStructure.decodeNullableSerializableElement(gVar, 1, u2.INSTANCE, str2);
                    i11 |= 2;
                } else {
                    if (iDecodeElementIndex != 2) {
                        throw new kotlinx.serialization.t(iDecodeElementIndex);
                    }
                    l13 = (Long) fVarBeginStructure.decodeNullableSerializableElement(gVar, 2, i1.INSTANCE, l13);
                    i11 |= 4;
                }
            }
            i10 = i11;
            l10 = l12;
            str = str2;
            l11 = l13;
        }
        fVarBeginStructure.endStructure(gVar);
        return new s(i10, l10, str, l11);
    }

    @Override // kotlinx.serialization.internal.n0, kotlinx.serialization.b, kotlinx.serialization.l, kotlinx.serialization.a
    public final kotlinx.serialization.descriptors.g getDescriptor() {
        return descriptor;
    }

    @Override // kotlinx.serialization.internal.n0, kotlinx.serialization.b, kotlinx.serialization.l
    public final void serialize(kotlinx.serialization.encoding.l encoder, Object obj) {
        s value = (s) obj;
        kotlin.jvm.internal.q.g(encoder, "encoder");
        kotlin.jvm.internal.q.g(value, "value");
        kotlinx.serialization.descriptors.g gVar = descriptor;
        kotlinx.serialization.encoding.h hVarBeginStructure = encoder.beginStructure(gVar);
        i1 i1Var = i1.INSTANCE;
        hVarBeginStructure.encodeNullableSerializableElement(gVar, 0, i1Var, value.f872a);
        hVarBeginStructure.encodeNullableSerializableElement(gVar, 1, u2.INSTANCE, value.f873b);
        hVarBeginStructure.encodeNullableSerializableElement(gVar, 2, i1Var, value.f874c);
        hVarBeginStructure.endStructure(gVar);
    }

    @Override // kotlinx.serialization.internal.n0
    public final /* bridge */ kotlinx.serialization.b[] typeParametersSerializers() {
        return l0.a(this);
    }
}
