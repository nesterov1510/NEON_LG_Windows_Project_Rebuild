package al;

import com.google.protobuf.m0;
import kotlinx.serialization.internal.c2;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
@kotlinx.serialization.j
public final class i {
    public static final h Companion = new h();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f850a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f851b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final f f852c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final k0 f853d;

    public /* synthetic */ i(int i10, String str, String str2, f fVar, k0 k0Var) {
        if (7 != (i10 & 7)) {
            c2.throwMissingFieldException(i10, 7, g.f846a.getDescriptor());
        }
        this.f850a = str;
        this.f851b = str2;
        this.f852c = fVar;
        if ((i10 & 8) == 0) {
            this.f853d = null;
        } else {
            this.f853d = k0Var;
        }
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof i)) {
            return false;
        }
        i iVar = (i) obj;
        return kotlin.jvm.internal.q.c(this.f850a, iVar.f850a) && kotlin.jvm.internal.q.c(this.f851b, iVar.f851b) && kotlin.jvm.internal.q.c(this.f852c, iVar.f852c) && kotlin.jvm.internal.q.c(this.f853d, iVar.f853d);
    }

    public final int hashCode() {
        String str = this.f850a;
        int iHashCode = (str == null ? 0 : str.hashCode()) * 31;
        String str2 = this.f851b;
        int iHashCode2 = (iHashCode + (str2 == null ? 0 : str2.hashCode())) * 31;
        f fVar = this.f852c;
        int iHashCode3 = (iHashCode2 + (fVar == null ? 0 : fVar.hashCode())) * 31;
        k0 k0Var = this.f853d;
        return iHashCode3 + (k0Var != null ? k0Var.hashCode() : 0);
    }

    public final String toString() {
        StringBuilder sbN = m0.n("EventRespDTO(status=", this.f850a, ", message=", this.f851b, ", event=");
        sbN.append(this.f852c);
        sbN.append(", vote_info_v2=");
        sbN.append(this.f853d);
        sbN.append(")");
        return sbN.toString();
    }
}
