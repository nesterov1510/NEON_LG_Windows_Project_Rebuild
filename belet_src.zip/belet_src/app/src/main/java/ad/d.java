package ad;

import java.util.Set;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public interface d {
    Object a(Class cls);

    Object d(u uVar);

    ae.b f(u uVar);

    ae.b g(Class cls);

    Set i(u uVar);

    s k(u uVar);
}
