package ad;

import android.os.StrictMode;
import com.google.firebase.concurrent.ExecutorsRegistrar;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.perf.session.gauges.GaugeManager;
import java.util.Collections;
import java.util.Random;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class g implements ae.b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f731a;

    public /* synthetic */ g(int i10) {
        this.f731a = i10;
    }

    @Override // ae.b
    public final Object get() {
        switch (this.f731a) {
            case 0:
                return Collections.EMPTY_SET;
            case 1:
                return null;
            case 2:
                return ExecutorsRegistrar.a();
            case 3:
                q qVar = ExecutorsRegistrar.f6311a;
                return new bd.g(Executors.newFixedThreadPool(Math.max(2, Runtime.getRuntime().availableProcessors()), new bd.a("Firebase Lite", 0, new StrictMode.ThreadPolicy.Builder().detectAll().penaltyLog().build())), (ScheduledExecutorService) ExecutorsRegistrar.f6314d.get());
            case 4:
                q qVar2 = ExecutorsRegistrar.f6311a;
                return new bd.g(Executors.newCachedThreadPool(new bd.a("Firebase Blocking", 11, null)), (ScheduledExecutorService) ExecutorsRegistrar.f6314d.get());
            case 5:
                q qVar3 = ExecutorsRegistrar.f6311a;
                return Executors.newSingleThreadScheduledExecutor(new bd.a("Firebase Scheduler", 0, null));
            case 6:
                gd.k kVar = FirebaseMessaging.f6322k;
                return null;
            case 7:
                return Executors.newSingleThreadScheduledExecutor();
            case 8:
                return GaugeManager.lambda$new$0();
            case 9:
                return GaugeManager.lambda$new$1();
            default:
                Random random = we.j.f21806j;
                return null;
        }
    }
}
