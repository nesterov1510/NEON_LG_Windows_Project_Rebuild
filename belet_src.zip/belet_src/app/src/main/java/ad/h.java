package ad;

import a0.y4;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import j$.util.DesugarCollections;
import java.util.HashSet;
import java.util.Set;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class h implements ae.b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f732a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f733b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f734c;

    public /* synthetic */ h(Object obj, Object obj2, int i10) {
        this.f732a = i10;
        this.f733b = obj;
        this.f734c = obj2;
    }

    @Override // ae.b
    public final Object get() {
        ApplicationInfo applicationInfo;
        Bundle bundle;
        switch (this.f732a) {
            case 0:
                i iVar = (i) this.f733b;
                c cVar = (c) this.f734c;
                f fVar = cVar.f;
                y4 y4Var = new y4();
                HashSet hashSet = new HashSet();
                HashSet hashSet2 = new HashSet();
                HashSet hashSet3 = new HashSet();
                HashSet hashSet4 = new HashSet();
                HashSet hashSet5 = new HashSet();
                Set<l> set = cVar.f725c;
                Set set2 = cVar.f728g;
                for (l lVar : set) {
                    int i10 = lVar.f746c;
                    int i11 = lVar.f745b;
                    boolean z5 = i10 == 0;
                    u uVar = lVar.f744a;
                    if (z5) {
                        if (i11 == 2) {
                            hashSet4.add(uVar);
                        } else {
                            hashSet.add(uVar);
                        }
                    } else if (i10 == 2) {
                        hashSet3.add(uVar);
                    } else if (i11 == 2) {
                        hashSet5.add(uVar);
                    } else {
                        hashSet2.add(uVar);
                    }
                }
                if (!set2.isEmpty()) {
                    hashSet.add(u.a(xd.b.class));
                }
                y4Var.f395e = DesugarCollections.unmodifiableSet(hashSet);
                y4Var.X = DesugarCollections.unmodifiableSet(hashSet2);
                y4Var.Y = DesugarCollections.unmodifiableSet(hashSet3);
                y4Var.Z = DesugarCollections.unmodifiableSet(hashSet4);
                DesugarCollections.unmodifiableSet(hashSet5);
                y4Var.f396r0 = iVar;
                return fVar.h(y4Var);
            case 1:
                tc.f fVar2 = (tc.f) this.f733b;
                Context contextC = (Context) this.f734c;
                String strD = fVar2.d();
                fe.a aVar = new fe.a();
                int i12 = Build.VERSION.SDK_INT;
                if (i12 >= 24) {
                    contextC = i12 >= 24 ? androidx.core.widget.i.c(contextC) : null;
                }
                SharedPreferences sharedPreferences = contextC.getSharedPreferences("com.google.firebase.common.prefs:" + strD, 0);
                boolean z6 = true;
                if (sharedPreferences.contains("firebase_data_collection_default_enabled")) {
                    z6 = sharedPreferences.getBoolean("firebase_data_collection_default_enabled", true);
                } else {
                    try {
                        PackageManager packageManager = contextC.getPackageManager();
                        if (packageManager != null && (applicationInfo = packageManager.getApplicationInfo(contextC.getPackageName(), 128)) != null && (bundle = applicationInfo.metaData) != null && bundle.containsKey("firebase_data_collection_default_enabled")) {
                            z6 = applicationInfo.metaData.getBoolean("firebase_data_collection_default_enabled");
                        }
                        break;
                    } catch (PackageManager.NameNotFoundException unused) {
                    }
                }
                aVar.f8102a = z6;
                return aVar;
            default:
                return new yd.g((Context) this.f733b, (String) this.f734c);
        }
    }
}
