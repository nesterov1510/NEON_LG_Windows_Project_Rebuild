package ad;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class u {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Class f760a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Class f761b;

    public u(Class cls, Class cls2) {
        this.f760a = cls;
        this.f761b = cls2;
    }

    public static u a(Class cls) {
        return new u(t.class, cls);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || u.class != obj.getClass()) {
            return false;
        }
        u uVar = (u) obj;
        if (this.f761b.equals(uVar.f761b)) {
            return this.f760a.equals(uVar.f760a);
        }
        return false;
    }

    public final int hashCode() {
        return this.f760a.hashCode() + (this.f761b.hashCode() * 31);
    }

    public final String toString() {
        Class cls = this.f761b;
        Class cls2 = this.f760a;
        if (cls2 == t.class) {
            return cls.getName();
        }
        return "@" + cls2.getName() + " " + cls.getName();
    }
}
