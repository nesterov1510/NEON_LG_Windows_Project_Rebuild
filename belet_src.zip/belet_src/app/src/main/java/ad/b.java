package ad;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public String f717a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f718b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f719c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Object f720d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public Object f721e;
    public Serializable f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public Object f722g;

    public b(byte[] bArr, String str, ArrayList arrayList, String str2) {
        this(bArr, str, arrayList, str2, -1, -1);
    }

    public void a(l lVar) {
        if (((HashSet) this.f720d).contains(lVar.f744a)) {
            throw new IllegalArgumentException("Components are not allowed to depend on interfaces they themselves provide.");
        }
        ((HashSet) this.f721e).add(lVar);
    }

    public c b() {
        if (((f) this.f722g) != null) {
            return new c(this.f717a, new HashSet((HashSet) this.f720d), new HashSet((HashSet) this.f721e), this.f718b, this.f719c, (f) this.f722g, (HashSet) this.f);
        }
        throw new IllegalStateException("Missing required property: factory.");
    }

    public void c(int i10) {
        if (!(this.f718b == 0)) {
            throw new IllegalStateException("Instantiation type has already been set.");
        }
        this.f718b = i10;
    }

    public b(byte[] bArr, String str, List list, String str2, int i10, int i11) {
        this.f720d = bArr;
        this.f717a = str;
        this.f721e = list;
        this.f = str2;
        this.f718b = i11;
        this.f719c = i10;
    }

    public b(Class cls, Class[] clsArr) {
        this.f717a = null;
        HashSet hashSet = new HashSet();
        this.f720d = hashSet;
        this.f721e = new HashSet();
        this.f718b = 0;
        this.f719c = 0;
        this.f = new HashSet();
        hashSet.add(u.a(cls));
        for (Class cls2 : clsArr) {
            ji.k.t(cls2, "Null interface");
            ((HashSet) this.f720d).add(u.a(cls2));
        }
    }
}
