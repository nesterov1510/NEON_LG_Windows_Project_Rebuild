package ad;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public class n extends RuntimeException {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f747e;

    private final synchronized Throwable a() {
        return this;
    }

    public static n b(String str, String str2, int i10, int i11) {
        return new n(d(str, str2, i10, i11), 4);
    }

    public static n c(String str, int i10, String str2) {
        return new n(d(str, str2, i10, i10 + 1), 4);
    }

    public static String d(String str, String str2, int i10, int i11) {
        if (i11 < 0) {
            i11 = str2.length();
        }
        StringBuilder sb2 = new StringBuilder(str);
        sb2.append(": ");
        if (i10 > 8) {
            sb2.append("...");
            sb2.append((CharSequence) str2, i10 - 5, i10);
        } else {
            sb2.append((CharSequence) str2, 0, i10);
        }
        sb2.append(kotlinx.serialization.json.internal.b.BEGIN_LIST);
        sb2.append(str2.substring(i10, i11));
        sb2.append(kotlinx.serialization.json.internal.b.END_LIST);
        if (str2.length() - i11 > 8) {
            sb2.append((CharSequence) str2, i11, i11 + 5);
            sb2.append("...");
        } else {
            sb2.append((CharSequence) str2, i11, str2.length());
        }
        return sb2.toString();
    }

    @Override // java.lang.Throwable
    public synchronized Throwable fillInStackTrace() {
        switch (this.f747e) {
            case 4:
                a();
                return this;
            default:
                return super.fillInStackTrace();
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ n(String str, int i10) {
        super(str);
        this.f747e = i10;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ n(String str, int i10, Throwable th2) {
        super(str, th2);
        this.f747e = i10;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ n(Throwable th2, int i10) {
        super(th2);
        this.f747e = i10;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public n(String str) {
        super(str.toString());
        this.f747e = 6;
    }
}
