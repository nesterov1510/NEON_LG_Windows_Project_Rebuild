package ad;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class k {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final u f742a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final boolean f743b;

    public k(u uVar, boolean z5) {
        this.f742a = uVar;
        this.f743b = z5;
    }

    public final boolean equals(Object obj) {
        if (obj instanceof k) {
            k kVar = (k) obj;
            if (kVar.f742a.equals(this.f742a) && kVar.f743b == this.f743b) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        return ((this.f742a.hashCode() ^ 1000003) * 1000003) ^ Boolean.valueOf(this.f743b).hashCode();
    }
}
