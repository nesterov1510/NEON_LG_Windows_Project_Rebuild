package ad;

import a4.x;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class s implements ae.b {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final a0.e f756c = new a0.e(10);

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final g f757d = new g(1);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public ae.a f758a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public volatile ae.b f759b;

    public s(a0.e eVar, ae.b bVar) {
        this.f758a = eVar;
        this.f759b = bVar;
    }

    public final void a(ae.a aVar) {
        ae.b bVar;
        ae.b bVar2;
        ae.b bVar3 = this.f759b;
        g gVar = f757d;
        if (bVar3 != gVar) {
            aVar.g(bVar3);
            return;
        }
        synchronized (this) {
            bVar = this.f759b;
            if (bVar != gVar) {
                bVar2 = bVar;
            } else {
                this.f758a = new x(this.f758a, aVar, 1);
                bVar2 = null;
            }
        }
        if (bVar2 != null) {
            aVar.g(bVar);
        }
    }

    @Override // ae.b
    public final Object get() {
        return this.f759b.get();
    }
}
