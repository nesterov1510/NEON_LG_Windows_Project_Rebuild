package ad;

import a0.y4;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class a implements f, l3.m {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ Object f716e;

    public /* synthetic */ a(Object obj) {
        this.f716e = obj;
    }

    @Override // ad.f
    public Object h(y4 y4Var) {
        return this.f716e;
    }

    @Override // l3.m
    public void invoke(Object obj) {
        ((t3.b) obj).getClass();
    }

    public /* synthetic */ a(t3.a aVar, Object obj, long j10) {
        this.f716e = obj;
    }
}
