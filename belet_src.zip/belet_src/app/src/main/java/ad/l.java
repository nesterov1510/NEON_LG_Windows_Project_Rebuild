package ad;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class l {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final u f744a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f745b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f746c;

    public l(int i10, int i11, Class cls) {
        this(u.a(cls), i10, i11);
    }

    public static l a(Class cls) {
        return new l(0, 1, cls);
    }

    public static l b(u uVar) {
        return new l(uVar, 1, 0);
    }

    public static l c(Class cls) {
        return new l(1, 0, cls);
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof l)) {
            return false;
        }
        l lVar = (l) obj;
        return this.f744a.equals(lVar.f744a) && this.f745b == lVar.f745b && this.f746c == lVar.f746c;
    }

    public final int hashCode() {
        return ((((this.f744a.hashCode() ^ 1000003) * 1000003) ^ this.f745b) * 1000003) ^ this.f746c;
    }

    public final String toString() {
        String str;
        String str2;
        StringBuilder sb2 = new StringBuilder("Dependency{anInterface=");
        sb2.append(this.f744a);
        sb2.append(", type=");
        int i10 = this.f745b;
        if (i10 == 1) {
            str = "required";
        } else {
            str = i10 == 0 ? "optional" : "set";
        }
        sb2.append(str);
        sb2.append(", injection=");
        int i11 = this.f746c;
        if (i11 == 0) {
            str2 = "direct";
        } else if (i11 == 1) {
            str2 = "provider";
        } else {
            if (i11 != 2) {
                throw new AssertionError(kotlin.jvm.internal.p.z(i11, "Unsupported injection: "));
            }
            str2 = "deferred";
        }
        return a0.f.r(sb2, str2, "}");
    }

    public l(u uVar, int i10, int i11) {
        ji.k.t(uVar, "Null dependency anInterface.");
        this.f744a = uVar;
        this.f745b = i10;
        this.f746c = i11;
    }
}
