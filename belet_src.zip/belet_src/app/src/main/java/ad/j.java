package ad;

import java.util.HashSet;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class j {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final c f739a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final HashSet f740b = new HashSet();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final HashSet f741c = new HashSet();

    public j(c cVar) {
        this.f739a = cVar;
    }
}
