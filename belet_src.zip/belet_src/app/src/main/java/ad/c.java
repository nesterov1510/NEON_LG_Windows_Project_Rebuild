package ad;

import j$.util.DesugarCollections;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f723a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Set f724b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Set f725c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f726d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int f727e;
    public final f f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final Set f728g;

    public c(String str, Set set, Set set2, int i10, int i11, f fVar, Set set3) {
        this.f723a = str;
        this.f724b = DesugarCollections.unmodifiableSet(set);
        this.f725c = DesugarCollections.unmodifiableSet(set2);
        this.f726d = i10;
        this.f727e = i11;
        this.f = fVar;
        this.f728g = DesugarCollections.unmodifiableSet(set3);
    }

    public static b a(u uVar) {
        u[] uVarArr = new u[0];
        b bVar = new b();
        bVar.f717a = null;
        HashSet hashSet = new HashSet();
        bVar.f720d = hashSet;
        bVar.f721e = new HashSet();
        bVar.f718b = 0;
        bVar.f719c = 0;
        bVar.f = new HashSet();
        hashSet.add(uVar);
        for (u uVar2 : uVarArr) {
            ji.k.t(uVar2, "Null interface");
        }
        Collections.addAll((HashSet) bVar.f720d, uVarArr);
        return bVar;
    }

    public static b b(Class cls) {
        return new b(cls, new Class[0]);
    }

    public static c c(Object obj, Class cls, Class... clsArr) {
        HashSet hashSet = new HashSet();
        HashSet hashSet2 = new HashSet();
        HashSet hashSet3 = new HashSet();
        hashSet.add(u.a(cls));
        for (Class cls2 : clsArr) {
            ji.k.t(cls2, "Null interface");
            hashSet.add(u.a(cls2));
        }
        return new c(null, new HashSet(hashSet), new HashSet(hashSet2), 0, 0, new a(obj), hashSet3);
    }

    public final String toString() {
        return "Component<" + Arrays.toString(this.f724b.toArray()) + ">{" + this.f726d + ", type=" + this.f727e + ", deps=" + Arrays.toString(this.f725c.toArray()) + "}";
    }
}
