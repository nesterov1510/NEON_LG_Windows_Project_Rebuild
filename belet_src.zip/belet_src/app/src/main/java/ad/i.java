package ad;

import android.util.Log;
import cb.x;
import com.google.firebase.components.ComponentRegistrar;
import j$.util.concurrent.ConcurrentHashMap;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;
import jd.t1;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class i implements d {
    public static final g u0 = new g(0);
    public final HashMap X;
    public final HashMap Y;
    public final HashSet Z;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final HashMap f735e;

    /* JADX INFO: renamed from: r0, reason: collision with root package name */
    public final o f736r0;

    /* JADX INFO: renamed from: s0, reason: collision with root package name */
    public final AtomicReference f737s0;

    /* JADX INFO: renamed from: t0, reason: collision with root package name */
    public final x f738t0;

    public i(ArrayList arrayList, ArrayList arrayList2, x xVar) {
        bd.m mVar = bd.m.f3488e;
        this.f735e = new HashMap();
        this.X = new HashMap();
        this.Y = new HashMap();
        this.Z = new HashSet();
        this.f737s0 = new AtomicReference();
        o oVar = new o();
        this.f736r0 = oVar;
        this.f738t0 = xVar;
        ArrayList arrayList3 = new ArrayList();
        int i10 = 0;
        arrayList3.add(c.c(oVar, o.class, xd.c.class, xd.b.class));
        arrayList3.add(c.c(this, i.class, new Class[0]));
        int size = arrayList2.size();
        int i11 = 0;
        while (i11 < size) {
            Object obj = arrayList2.get(i11);
            i11++;
            c cVar = (c) obj;
            if (cVar != null) {
                arrayList3.add(cVar);
            }
        }
        ArrayList arrayList4 = new ArrayList();
        int size2 = arrayList.size();
        int i12 = 0;
        while (i12 < size2) {
            Object obj2 = arrayList.get(i12);
            i12++;
            arrayList4.add(obj2);
        }
        ArrayList arrayList5 = new ArrayList();
        synchronized (this) {
            Iterator it = arrayList4.iterator();
            while (it.hasNext()) {
                try {
                    ComponentRegistrar componentRegistrar = (ComponentRegistrar) ((ae.b) it.next()).get();
                    if (componentRegistrar != null) {
                        arrayList3.addAll(this.f738t0.t(componentRegistrar));
                        it.remove();
                    }
                } catch (p e3) {
                    it.remove();
                    Log.w("ComponentDiscovery", "Invalid component registrar.", e3);
                }
            }
            Iterator it2 = arrayList3.iterator();
            while (it2.hasNext()) {
                for (Object obj3 : ((c) it2.next()).f724b.toArray()) {
                    if (obj3.toString().contains("kotlinx.coroutines.CoroutineDispatcher")) {
                        if (this.Z.contains(obj3.toString())) {
                            it2.remove();
                            break;
                        }
                        this.Z.add(obj3.toString());
                    }
                }
            }
            if (this.f735e.isEmpty()) {
                t1.k(arrayList3);
            } else {
                ArrayList arrayList6 = new ArrayList(this.f735e.keySet());
                arrayList6.addAll(arrayList3);
                t1.k(arrayList6);
            }
            int size3 = arrayList3.size();
            int i13 = 0;
            while (i13 < size3) {
                Object obj4 = arrayList3.get(i13);
                i13++;
                c cVar2 = (c) obj4;
                this.f735e.put(cVar2, new q(new h(this, cVar2, i10)));
            }
            arrayList5.addAll(e(arrayList3));
            arrayList5.addAll(h());
            c();
        }
        int size4 = arrayList5.size();
        while (i10 < size4) {
            Object obj5 = arrayList5.get(i10);
            i10++;
            ((Runnable) obj5).run();
        }
        Boolean bool = (Boolean) this.f737s0.get();
        if (bool != null) {
            b(this.f735e, bool.booleanValue());
        }
    }

    @Override // ad.d
    public final Object a(Class cls) {
        return d(u.a(cls));
    }

    public final void b(HashMap map, boolean z5) {
        ArrayDeque arrayDeque;
        for (Map.Entry entry : map.entrySet()) {
            c cVar = (c) entry.getKey();
            ae.b bVar = (ae.b) entry.getValue();
            int i10 = cVar.f726d;
            if (i10 == 1 || (i10 == 2 && z5)) {
                bVar.get();
            }
        }
        o oVar = this.f736r0;
        synchronized (oVar) {
            try {
                arrayDeque = oVar.f749b;
                if (arrayDeque != null) {
                    oVar.f749b = null;
                } else {
                    arrayDeque = null;
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
        if (arrayDeque != null) {
            Iterator it = arrayDeque.iterator();
            if (it.hasNext()) {
                throw a0.f.m(it);
            }
        }
    }

    public final void c() {
        HashMap map = this.X;
        HashMap map2 = this.Y;
        for (c cVar : this.f735e.keySet()) {
            for (l lVar : cVar.f725c) {
                boolean z5 = lVar.f745b == 2;
                u uVar = lVar.f744a;
                if (z5 && !map2.containsKey(uVar)) {
                    Set set = Collections.EMPTY_SET;
                    r rVar = new r();
                    rVar.f755b = null;
                    rVar.f754a = Collections.newSetFromMap(new ConcurrentHashMap());
                    rVar.f754a.addAll(set);
                    map2.put(uVar, rVar);
                } else if (map.containsKey(uVar)) {
                    continue;
                } else {
                    int i10 = lVar.f745b;
                    if (i10 == 1) {
                        throw new m("Unsatisfied dependency for component " + cVar + ": " + uVar, 0);
                    }
                    if (i10 != 2) {
                        map.put(uVar, new s(s.f756c, s.f757d));
                    }
                }
            }
        }
    }

    @Override // ad.d
    public final Object d(u uVar) {
        ae.b bVarF = f(uVar);
        if (bVarF == null) {
            return null;
        }
        return bVarF.get();
    }

    public final ArrayList e(ArrayList arrayList) {
        ArrayList arrayList2 = new ArrayList();
        int size = arrayList.size();
        int i10 = 0;
        while (i10 < size) {
            Object obj = arrayList.get(i10);
            i10++;
            c cVar = (c) obj;
            if (cVar.f727e == 0) {
                ae.b bVar = (ae.b) this.f735e.get(cVar);
                for (u uVar : cVar.f724b) {
                    HashMap map = this.X;
                    if (map.containsKey(uVar)) {
                        arrayList2.add(new a4.b((s) ((ae.b) map.get(uVar)), bVar, 2));
                    } else {
                        map.put(uVar, bVar);
                    }
                }
            }
        }
        return arrayList2;
    }

    @Override // ad.d
    public final synchronized ae.b f(u uVar) {
        ji.k.t(uVar, "Null interface requested.");
        return (ae.b) this.X.get(uVar);
    }

    @Override // ad.d
    public final ae.b g(Class cls) {
        return f(u.a(cls));
    }

    public final ArrayList h() {
        HashMap map = this.Y;
        ArrayList arrayList = new ArrayList();
        HashMap map2 = new HashMap();
        for (Map.Entry entry : this.f735e.entrySet()) {
            c cVar = (c) entry.getKey();
            if (cVar.f727e != 0) {
                ae.b bVar = (ae.b) entry.getValue();
                for (u uVar : cVar.f724b) {
                    if (!map2.containsKey(uVar)) {
                        map2.put(uVar, new HashSet());
                    }
                    ((Set) map2.get(uVar)).add(bVar);
                }
            }
        }
        for (Map.Entry entry2 : map2.entrySet()) {
            if (map.containsKey(entry2.getKey())) {
                r rVar = (r) map.get(entry2.getKey());
                Iterator it = ((Set) entry2.getValue()).iterator();
                while (it.hasNext()) {
                    arrayList.add(new a4.b(rVar, (ae.b) it.next(), 3));
                }
            } else {
                u uVar2 = (u) entry2.getKey();
                Set set = (Set) ((Collection) entry2.getValue());
                r rVar2 = new r();
                rVar2.f755b = null;
                rVar2.f754a = Collections.newSetFromMap(new ConcurrentHashMap());
                rVar2.f754a.addAll(set);
                map.put(uVar2, rVar2);
            }
        }
        return arrayList;
    }

    @Override // ad.d
    public final Set i(u uVar) {
        ae.b bVar;
        synchronized (this) {
            bVar = (r) this.Y.get(uVar);
            if (bVar == null) {
                bVar = u0;
            }
        }
        return (Set) bVar.get();
    }

    @Override // ad.d
    public final s k(u uVar) {
        ae.b bVarF = f(uVar);
        if (bVarF == null) {
            return new s(s.f756c, s.f757d);
        }
        return bVarF instanceof s ? (s) bVarF : new s(null, bVarF);
    }
}
