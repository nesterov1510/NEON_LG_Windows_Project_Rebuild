package ad;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class q implements ae.b {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final Object f751c = new Object();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public volatile Object f752a = f751c;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public volatile ae.b f753b;

    public q(ae.b bVar) {
        this.f753b = bVar;
    }

    @Override // ae.b
    public final Object get() {
        Object obj;
        Object obj2 = this.f752a;
        Object obj3 = f751c;
        if (obj2 != obj3) {
            return obj2;
        }
        synchronized (this) {
            try {
                obj = this.f752a;
                if (obj == obj3) {
                    obj = this.f753b.get();
                    this.f752a = obj;
                    this.f753b = null;
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
        return obj;
    }
}
