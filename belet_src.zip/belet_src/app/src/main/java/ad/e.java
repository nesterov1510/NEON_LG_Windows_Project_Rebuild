package ad;

import android.util.Log;
import com.google.firebase.components.ComponentRegistrar;
import java.lang.reflect.InvocationTargetException;
import w.x0;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class e implements ae.b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f729a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f730b;

    public /* synthetic */ e(int i10, Object obj) {
        this.f729a = i10;
        this.f730b = obj;
    }

    @Override // ae.b
    public final Object get() {
        switch (this.f729a) {
            case 0:
                String str = (String) this.f730b;
                try {
                    Class<?> cls = Class.forName(str);
                    if (ComponentRegistrar.class.isAssignableFrom(cls)) {
                        return (ComponentRegistrar) cls.getDeclaredConstructor(null).newInstance(null);
                    }
                    throw new p("Class " + str + " is not an instance of com.google.firebase.components.ComponentRegistrar");
                } catch (ClassNotFoundException unused) {
                    Log.w("ComponentDiscovery", "Class " + str + " is not an found.");
                    return null;
                } catch (IllegalAccessException e3) {
                    throw new p(p0.e.x("Could not instantiate ", str, "."), e3);
                } catch (InstantiationException e10) {
                    throw new p(p0.e.x("Could not instantiate ", str, "."), e10);
                } catch (NoSuchMethodException e11) {
                    throw new p(x0.u("Could not instantiate ", str), e11);
                } catch (InvocationTargetException e12) {
                    throw new p(x0.u("Could not instantiate ", str), e12);
                }
            case 1:
                return (ComponentRegistrar) this.f730b;
            default:
                return new ce.c((tc.f) this.f730b);
        }
    }
}
