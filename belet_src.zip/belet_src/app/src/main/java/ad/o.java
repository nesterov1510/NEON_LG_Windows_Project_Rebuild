package ad;

import j$.util.concurrent.ConcurrentHashMap;
import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.concurrent.Executor;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class o implements xd.c, xd.b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final HashMap f748a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public ArrayDeque f749b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final bd.m f750c;

    public o() {
        bd.m mVar = bd.m.f3488e;
        this.f748a = new HashMap();
        this.f749b = new ArrayDeque();
        this.f750c = mVar;
    }

    public final synchronized void a(Executor executor, xd.a aVar) {
        try {
            executor.getClass();
            if (!this.f748a.containsKey(tc.b.class)) {
                this.f748a.put(tc.b.class, new ConcurrentHashMap());
            }
            ((ConcurrentHashMap) this.f748a.get(tc.b.class)).put(aVar, executor);
        } catch (Throwable th2) {
            throw th2;
        }
    }
}
