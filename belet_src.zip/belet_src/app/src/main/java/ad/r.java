package ad;

import j$.util.DesugarCollections;
import j$.util.concurrent.ConcurrentHashMap;
import java.util.Collections;
import java.util.Iterator;
import java.util.Set;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class r implements ae.b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public volatile Set f754a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public volatile Set f755b;

    public final synchronized void a() {
        try {
            Iterator it = this.f754a.iterator();
            while (it.hasNext()) {
                this.f755b.add(((ae.b) it.next()).get());
            }
            this.f754a = null;
        } catch (Throwable th2) {
            throw th2;
        }
    }

    @Override // ae.b
    public final Object get() {
        if (this.f755b == null) {
            synchronized (this) {
                try {
                    if (this.f755b == null) {
                        this.f755b = Collections.newSetFromMap(new ConcurrentHashMap());
                        a();
                    }
                } catch (Throwable th2) {
                    throw th2;
                }
            }
        }
        return DesugarCollections.unmodifiableSet(this.f755b);
    }
}
