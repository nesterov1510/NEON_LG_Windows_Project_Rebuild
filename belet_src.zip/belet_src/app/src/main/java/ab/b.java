package ab;

import android.os.Bundle;
import cb.q2;
import java.util.List;
import java.util.Map;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class b extends c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final q2 f699a;

    public b(q2 q2Var) {
        this.f699a = q2Var;
    }

    @Override // cb.q2
    public final String c() {
        return this.f699a.c();
    }

    @Override // cb.q2
    public final long i() {
        return this.f699a.i();
    }

    @Override // cb.q2
    public final String j() {
        return this.f699a.j();
    }

    @Override // cb.q2
    public final void k(Bundle bundle) {
        this.f699a.k(bundle);
    }

    @Override // cb.q2
    public final void l(String str) {
        this.f699a.l(str);
    }

    @Override // cb.q2
    public final void m(String str, String str2, Bundle bundle) {
        this.f699a.m(str, str2, bundle);
    }

    @Override // cb.q2
    public final void n(String str) {
        this.f699a.n(str);
    }

    @Override // cb.q2
    public final void o(String str, String str2, Bundle bundle) {
        this.f699a.o(str, str2, bundle);
    }

    @Override // cb.q2
    public final List p(String str, String str2) {
        return this.f699a.p(str, str2);
    }

    @Override // cb.q2
    public final int q(String str) {
        return this.f699a.q(str);
    }

    @Override // cb.q2
    public final String r() {
        return this.f699a.r();
    }

    @Override // cb.q2
    public final String s() {
        return this.f699a.s();
    }

    @Override // cb.q2
    public final Map t(String str, String str2, boolean z5) {
        return this.f699a.t(str, str2, z5);
    }
}
