package ab;

import android.os.Bundle;
import android.os.SystemClock;
import androidx.media3.session.legacy.u;
import cb.b3;
import cb.e2;
import cb.j1;
import cb.j4;
import cb.k1;
import cb.p0;
import cb.p2;
import cb.s;
import cb.x2;
import com.google.android.gms.measurement.internal.zzpl;
import ga.r;
import j1.e;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class a extends c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final k1 f697a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final p2 f698b;

    public a(k1 k1Var) {
        r.g(k1Var);
        this.f697a = k1Var;
        p2 p2Var = k1Var.f4211z0;
        k1.g(p2Var);
        this.f698b = p2Var;
    }

    @Override // cb.q2
    public final String c() {
        b3 b3Var = ((k1) this.f698b.X).f4210y0;
        k1.g(b3Var);
        x2 x2Var = b3Var.Z;
        if (x2Var != null) {
            return x2Var.f4390a;
        }
        return null;
    }

    @Override // cb.q2
    public final long i() {
        j4 j4Var = this.f697a.f4207v0;
        k1.f(j4Var);
        return j4Var.H2();
    }

    @Override // cb.q2
    public final String j() {
        b3 b3Var = ((k1) this.f698b.X).f4210y0;
        k1.g(b3Var);
        x2 x2Var = b3Var.Z;
        if (x2Var != null) {
            return x2Var.f4391b;
        }
        return null;
    }

    @Override // cb.q2
    public final void k(Bundle bundle) {
        p2 p2Var = this.f698b;
        ((k1) p2Var.X).f4209x0.getClass();
        p2Var.U1(bundle, System.currentTimeMillis());
    }

    @Override // cb.q2
    public final void l(String str) {
        k1 k1Var = this.f697a;
        s sVar = k1Var.A0;
        k1.e(sVar);
        k1Var.f4209x0.getClass();
        sVar.J1(str, SystemClock.elapsedRealtime());
    }

    @Override // cb.q2
    public final void m(String str, String str2, Bundle bundle) {
        this.f698b.L1(str, str2, bundle);
    }

    @Override // cb.q2
    public final void n(String str) {
        k1 k1Var = this.f697a;
        s sVar = k1Var.A0;
        k1.e(sVar);
        k1Var.f4209x0.getClass();
        sVar.I1(str, SystemClock.elapsedRealtime());
    }

    @Override // cb.q2
    public final void o(String str, String str2, Bundle bundle) {
        p2 p2Var = this.f697a.f4211z0;
        k1.g(p2Var);
        p2Var.V1(str, str2, bundle);
    }

    @Override // cb.q2
    public final List p(String str, String str2) {
        p2 p2Var = this.f698b;
        k1 k1Var = (k1) p2Var.X;
        j1 j1Var = k1Var.f4206t0;
        p0 p0Var = k1Var.f4205s0;
        k1.h(j1Var);
        if (j1Var.N1()) {
            k1.h(p0Var);
            p0Var.f4284t0.a("Cannot get conditional user properties from analytics worker thread");
            return new ArrayList(0);
        }
        if (me.b.b()) {
            k1.h(p0Var);
            p0Var.f4284t0.a("Cannot get conditional user properties from main thread");
            return new ArrayList(0);
        }
        AtomicReference atomicReference = new AtomicReference();
        j1 j1Var2 = k1Var.f4206t0;
        k1.h(j1Var2);
        j1Var2.R1(atomicReference, 5000L, "get conditional user properties", new u(p2Var, atomicReference, str, str2));
        List list = (List) atomicReference.get();
        if (list != null) {
            return j4.D2(list);
        }
        k1.h(p0Var);
        p0Var.f4284t0.b(null, "Timed out waiting for get conditional user properties");
        return new ArrayList();
    }

    @Override // cb.q2
    public final int q(String str) {
        p2 p2Var = this.f698b;
        p2Var.getClass();
        r.d(str);
        ((k1) p2Var.X).getClass();
        return 25;
    }

    @Override // cb.q2
    public final String r() {
        return (String) this.f698b.u0.get();
    }

    @Override // cb.q2
    public final String s() {
        return this.f698b.W1();
    }

    @Override // cb.q2
    public final Map t(String str, String str2, boolean z5) {
        p2 p2Var = this.f698b;
        k1 k1Var = (k1) p2Var.X;
        j1 j1Var = k1Var.f4206t0;
        p0 p0Var = k1Var.f4205s0;
        k1.h(j1Var);
        if (j1Var.N1()) {
            k1.h(p0Var);
            p0Var.f4284t0.a("Cannot get user properties from analytics worker thread");
            return Collections.EMPTY_MAP;
        }
        if (me.b.b()) {
            k1.h(p0Var);
            p0Var.f4284t0.a("Cannot get user properties from main thread");
            return Collections.EMPTY_MAP;
        }
        AtomicReference atomicReference = new AtomicReference();
        j1 j1Var2 = k1Var.f4206t0;
        k1.h(j1Var2);
        j1Var2.R1(atomicReference, 5000L, "get user properties", new e2(p2Var, atomicReference, str, str2, z5));
        List<zzpl> list = (List) atomicReference.get();
        if (list == null) {
            k1.h(p0Var);
            p0Var.f4284t0.b(Boolean.valueOf(z5), "Timed out waiting for handle get user properties, includeInternal");
            return Collections.EMPTY_MAP;
        }
        e eVar = new e(list.size());
        for (zzpl zzplVar : list) {
            Object objB0 = zzplVar.b0();
            if (objB0 != null) {
                eVar.put(zzplVar.X, objB0);
            }
        }
        return eVar;
    }
}
