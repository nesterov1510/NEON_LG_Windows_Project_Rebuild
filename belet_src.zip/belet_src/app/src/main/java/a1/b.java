package a1;

import android.util.Rational;
import d0.c0;
import d0.f0;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;
import z.b0;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class b implements Comparator {
    public final Object X;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f404e;

    public /* synthetic */ b(int i10, Object obj) {
        this.f404e = i10;
        this.X = obj;
    }

    @Override // java.util.Comparator
    public final int compare(Object obj, Object obj2) {
        switch (this.f404e) {
            case 0:
                Rational rational = (Rational) obj2;
                Rational rational2 = (Rational) this.X;
                float fFloatValue = ((Rational) obj).floatValue();
                float fFloatValue2 = rational2.floatValue();
                float f = fFloatValue > fFloatValue2 ? fFloatValue2 / fFloatValue : fFloatValue / fFloatValue2;
                float fFloatValue3 = rational.floatValue();
                float fFloatValue4 = rational2.floatValue();
                return Float.compare(fFloatValue3 > fFloatValue4 ? fFloatValue4 / fFloatValue3 : fFloatValue3 / fFloatValue4, f);
            default:
                ArrayList arrayList = ((f0) this.X).f6541t0;
                Iterator it = ((c0) obj).f6511l.iterator();
                if (!it.hasNext()) {
                    throw new NoSuchElementException();
                }
                Integer numValueOf = Integer.valueOf(arrayList.indexOf((b0) it.next()));
                while (it.hasNext()) {
                    Integer numValueOf2 = Integer.valueOf(arrayList.indexOf((b0) it.next()));
                    if (numValueOf.compareTo(numValueOf2) > 0) {
                        numValueOf = numValueOf2;
                    }
                }
                Iterator it2 = ((c0) obj2).f6511l.iterator();
                if (!it2.hasNext()) {
                    throw new NoSuchElementException();
                }
                Integer numValueOf3 = Integer.valueOf(arrayList.indexOf((b0) it2.next()));
                while (it2.hasNext()) {
                    Integer numValueOf4 = Integer.valueOf(arrayList.indexOf((b0) it2.next()));
                    if (numValueOf3.compareTo(numValueOf4) > 0) {
                        numValueOf3 = numValueOf4;
                    }
                }
                return m7.f.f(numValueOf, numValueOf3);
        }
    }
}
