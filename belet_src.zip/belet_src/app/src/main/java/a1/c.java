package a1;

import android.graphics.Rect;
import android.graphics.RectF;
import android.util.Pair;
import android.util.Rational;
import android.util.Size;
import ge.o;
import j$.util.Objects;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import m0.a0;
import m0.c0;
import m0.q2;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class c {
    public static final double h = Math.sqrt(2.3703703703703702d);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Size f405a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Rational f406b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Rational f407c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final HashSet f408d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final o f409e;
    public final a0 f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final HashMap f410g;

    public c(c0 c0Var, HashSet hashSet) {
        Size sizeF = p0.g.f(c0Var.r().g());
        a0 a0VarR = c0Var.r();
        o oVar = new o(a0VarR, sizeF);
        this.f410g = new HashMap();
        this.f405a = sizeF;
        Rational rational = ((double) sizeF.getWidth()) / ((double) sizeF.getHeight()) > h ? p0.b.f16599c : p0.b.f16597a;
        y6.a.e("ResolutionsMerger", "The closer aspect ratio to the sensor size (" + sizeF + ") is " + rational + ".");
        this.f406b = rational;
        Rational rational2 = p0.b.f16597a;
        if (rational.equals(rational2)) {
            rational2 = p0.b.f16599c;
        } else if (!rational.equals(p0.b.f16599c)) {
            throw new IllegalArgumentException("Invalid sensor aspect-ratio: " + rational);
        }
        this.f407c = rational2;
        this.f = a0VarR;
        this.f408d = hashSet;
        this.f409e = oVar;
    }

    public static Rect a(Size size, Size size2) {
        RectF rectF;
        RectF rectF2;
        Rational rationalH = h(size2);
        int width = size.getWidth();
        int height = size.getHeight();
        Rational rationalH2 = h(size);
        if (rationalH.floatValue() == rationalH2.floatValue()) {
            rectF2 = new RectF(0.0f, 0.0f, width, height);
        } else {
            if (rationalH.floatValue() > rationalH2.floatValue()) {
                float f = width;
                float fFloatValue = f / rationalH.floatValue();
                float f10 = (height - fFloatValue) / 2.0f;
                rectF = new RectF(0.0f, f10, f, fFloatValue + f10);
            } else {
                float f11 = height;
                float fFloatValue2 = rationalH.floatValue() * f11;
                float f12 = (width - fFloatValue2) / 2.0f;
                rectF = new RectF(f12, 0.0f, fFloatValue2 + f12, f11);
            }
            rectF2 = rectF;
        }
        Rect rect = new Rect();
        rectF2.round(rect);
        return rect;
    }

    public static boolean d(Size size, Size size2) {
        return size.getHeight() > size2.getHeight() || size.getWidth() > size2.getWidth();
    }

    public static Rational h(Size size) {
        return new Rational(size.getWidth(), size.getHeight());
    }

    public final a b(q2 q2Var, Rect rect, int i10, boolean z5) {
        boolean z6;
        Size size;
        Size size2;
        Pair pairCreate;
        if (p0.g.c(i10)) {
            z6 = true;
            rect = new Rect(rect.top, rect.left, rect.bottom, rect.right);
        } else {
            z6 = false;
        }
        if (z5) {
            Size sizeF = p0.g.f(rect);
            Iterator it = c(q2Var).iterator();
            while (true) {
                if (!it.hasNext()) {
                    pairCreate = Pair.create(sizeF, sizeF);
                    break;
                }
                Size size3 = (Size) it.next();
                Size sizeF2 = p0.g.f(a(size3, sizeF));
                if (!d(sizeF2, sizeF)) {
                    pairCreate = Pair.create(size3, sizeF2);
                    break;
                }
            }
            size = (Size) pairCreate.first;
            size2 = (Size) pairCreate.second;
        } else {
            Size sizeF3 = p0.g.f(rect);
            List listC = c(q2Var);
            Iterator it2 = listC.iterator();
            while (true) {
                if (!it2.hasNext()) {
                    Iterator it3 = listC.iterator();
                    do {
                        if (!it3.hasNext()) {
                            size = sizeF3;
                            break;
                        }
                        size = (Size) it3.next();
                    } while (d(size, sizeF3));
                } else {
                    Size size4 = (Size) it2.next();
                    Rational rationalH = p0.b.f16597a;
                    if (!p0.b.a(rationalH, sizeF3)) {
                        rationalH = p0.b.f16599c;
                        if (!p0.b.a(rationalH, sizeF3)) {
                            rationalH = h(sizeF3);
                        }
                    }
                    if (!e(rationalH, size4) && !d(size4, sizeF3)) {
                        size = size4;
                        break;
                    }
                }
            }
            rect = a(sizeF3, size);
            size2 = size;
        }
        return z6 ? new a(new Rect(rect.top, rect.left, rect.bottom, rect.right), new Size(size2.getHeight(), size2.getWidth()), size) : new a(rect, size2, size);
    }

    public final List c(q2 q2Var) {
        Rational rationalH;
        if (!this.f408d.contains(q2Var)) {
            throw new IllegalArgumentException("Invalid child config: " + q2Var);
        }
        HashMap map = this.f410g;
        if (map.containsKey(q2Var)) {
            List list = (List) map.get(q2Var);
            Objects.requireNonNull(list);
            return list;
        }
        List listF = this.f409e.f(q2Var);
        HashMap map2 = new HashMap();
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = (ArrayList) listF;
        int size = arrayList2.size();
        int i10 = 0;
        while (i10 < size) {
            Object obj = arrayList2.get(i10);
            i10++;
            Size size2 = (Size) obj;
            Iterator it = map2.keySet().iterator();
            do {
                if (!it.hasNext()) {
                    rationalH = null;
                    break;
                }
                rationalH = (Rational) it.next();
            } while (!p0.b.a(rationalH, size2));
            if (rationalH != null) {
                Size size3 = (Size) map2.get(rationalH);
                Objects.requireNonNull(size3);
                if (size2.getHeight() > size3.getHeight() || size2.getWidth() > size3.getWidth() || (size2.getWidth() == size3.getWidth() && size2.getHeight() == size3.getHeight())) {
                }
            } else {
                rationalH = h(size2);
            }
            arrayList.add(size2);
            map2.put(rationalH, size2);
        }
        map.put(q2Var, arrayList);
        return arrayList;
    }

    public final boolean e(Rational rational, Size size) {
        Rational rational2 = this.f406b;
        if (rational2.equals(rational) || p0.b.a(rational, size)) {
            return false;
        }
        float fFloatValue = rational2.floatValue();
        float fFloatValue2 = rational.floatValue();
        Rational rationalH = p0.b.f16597a;
        if (!p0.b.a(rationalH, size)) {
            rationalH = p0.b.f16599c;
            if (!p0.b.a(rationalH, size)) {
                rationalH = h(size);
            }
        }
        float fFloatValue3 = rationalH.floatValue();
        if (fFloatValue == fFloatValue2 || fFloatValue2 == fFloatValue3) {
            return false;
        }
        if (fFloatValue > fFloatValue2) {
            return fFloatValue2 < fFloatValue3;
        }
        return fFloatValue2 > fFloatValue3;
    }

    public final ArrayList f(List list, boolean z5) {
        int i10;
        List arrayList;
        HashMap map = new HashMap();
        Rational rational = p0.b.f16597a;
        map.put(rational, new ArrayList());
        Rational rational2 = p0.b.f16599c;
        map.put(rational2, new ArrayList());
        ArrayList arrayList2 = new ArrayList();
        arrayList2.add(rational);
        arrayList2.add(rational2);
        Iterator it = list.iterator();
        while (true) {
            i10 = 0;
            if (!it.hasNext()) {
                break;
            }
            Size size = (Size) it.next();
            if (size.getHeight() > 0) {
                int size2 = arrayList2.size();
                while (true) {
                    if (i10 >= size2) {
                        arrayList = null;
                        break;
                    }
                    Object obj = arrayList2.get(i10);
                    i10++;
                    Rational rational3 = (Rational) obj;
                    if (p0.b.a(rational3, size)) {
                        arrayList = (List) map.get(rational3);
                        break;
                    }
                }
                if (arrayList == null) {
                    arrayList = new ArrayList();
                    Rational rationalH = h(size);
                    arrayList2.add(rationalH);
                    map.put(rationalH, arrayList);
                }
                arrayList.add(size);
            }
        }
        ArrayList arrayList3 = new ArrayList(map.keySet());
        Collections.sort(arrayList3, new b(0, h(this.f405a)));
        ArrayList arrayList4 = new ArrayList();
        int size3 = arrayList3.size();
        while (i10 < size3) {
            Object obj2 = arrayList3.get(i10);
            i10++;
            Rational rational4 = (Rational) obj2;
            if (!rational4.equals(p0.b.f16599c) && !rational4.equals(p0.b.f16597a)) {
                List list2 = (List) map.get(rational4);
                Objects.requireNonNull(list2);
                arrayList4.addAll(g(rational4, list2, z5));
            }
        }
        return arrayList4;
    }

    public final ArrayList g(Rational rational, List list, boolean z5) {
        ArrayList arrayList;
        ArrayList arrayList2 = new ArrayList();
        Iterator it = list.iterator();
        while (it.hasNext()) {
            Size size = (Size) it.next();
            if (p0.b.a(rational, size)) {
                arrayList2.add(size);
            }
        }
        Collections.sort(arrayList2, new p0.c(true));
        HashSet hashSet = new HashSet(arrayList2);
        Iterator it2 = this.f408d.iterator();
        while (true) {
            int i10 = 0;
            if (!it2.hasNext()) {
                ArrayList arrayList3 = new ArrayList();
                int size2 = arrayList2.size();
                while (i10 < size2) {
                    Object obj = arrayList2.get(i10);
                    i10++;
                    Size size3 = (Size) obj;
                    if (!hashSet.contains(size3)) {
                        arrayList3.add(size3);
                    }
                }
                return arrayList3;
            }
            List<Size> listC = c((q2) it2.next());
            if (!z5) {
                ArrayList arrayList4 = new ArrayList();
                for (Size size4 : listC) {
                    if (!e(rational, size4)) {
                        arrayList4.add(size4);
                    }
                }
                listC = arrayList4;
            }
            if (listC.isEmpty()) {
                return new ArrayList();
            }
            if (listC.isEmpty() || arrayList2.isEmpty()) {
                arrayList2 = new ArrayList();
            } else {
                ArrayList arrayList5 = new ArrayList();
                int size5 = arrayList2.size();
                int i11 = 0;
                while (i11 < size5) {
                    Object obj2 = arrayList2.get(i11);
                    i11++;
                    Size size6 = (Size) obj2;
                    Iterator it3 = listC.iterator();
                    while (it3.hasNext()) {
                        if (!d((Size) it3.next(), size6)) {
                            arrayList5.add(size6);
                            break;
                        }
                    }
                }
                arrayList2 = arrayList5;
            }
            if (listC.isEmpty() || arrayList2.isEmpty()) {
                arrayList = new ArrayList();
            } else {
                ArrayList arrayList6 = arrayList2.isEmpty() ? arrayList2 : new ArrayList(new LinkedHashSet(arrayList2));
                arrayList = new ArrayList();
                int size7 = arrayList6.size();
                while (i10 < size7) {
                    Object obj3 = arrayList6.get(i10);
                    i10++;
                    Size size8 = (Size) obj3;
                    Iterator it4 = listC.iterator();
                    do {
                        if (!it4.hasNext()) {
                            arrayList.add(size8);
                            break;
                        }
                    } while (!d((Size) it4.next(), size8));
                }
                if (!arrayList.isEmpty()) {
                    arrayList.remove(arrayList.size() - 1);
                }
            }
            hashSet.retainAll(arrayList);
        }
    }
}
