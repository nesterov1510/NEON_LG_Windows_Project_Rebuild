package a1;

import android.database.Cursor;
import android.database.sqlite.SQLiteException;
import cb.h4;
import cb.k1;
import cb.p0;
import com.google.android.gms.internal.measurement.o9;
import com.google.android.gms.internal.measurement.p9;
import ga.r;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import m0.m2;
import m0.q;
import m0.s;
import m0.t;
import okhttp3.internal.url._UrlKt;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class k implements t {
    public final Object X;
    public final Object Y;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public long f440e;

    public k(cb.j jVar, String str) {
        this.Y = jVar;
        r.d(str);
        this.X = str;
        this.f440e = -1L;
    }

    @Override // m0.t
    public m2 a() {
        return (m2) this.Y;
    }

    @Override // m0.t
    public int b() {
        t tVar = (t) this.X;
        if (tVar != null) {
            return tVar.b();
        }
        return 1;
    }

    @Override // m0.t
    public long c() {
        t tVar = (t) this.X;
        if (tVar != null) {
            return tVar.c();
        }
        long j10 = this.f440e;
        if (j10 != -1) {
            return j10;
        }
        throw new IllegalStateException("No timestamp is available.");
    }

    @Override // m0.t
    public s d() {
        t tVar = (t) this.X;
        return tVar != null ? tVar.d() : s.f14922e;
    }

    @Override // m0.t
    public q e() {
        t tVar = (t) this.X;
        return tVar != null ? tVar.e() : q.f14907e;
    }

    @Override // m0.t
    public m0.r f() {
        t tVar = (t) this.X;
        return tVar != null ? tVar.f() : m0.r.f14918e;
    }

    public List g() {
        List list;
        cb.j jVar = (cb.j) this.Y;
        ArrayList arrayList = new ArrayList();
        String str = (String) this.X;
        Cursor cursorQuery = null;
        try {
            try {
                cursorQuery = jVar.y2().query("raw_events", new String[]{"rowid", "name", "timestamp", "metadata_fingerprint", "data", "realtime", "elapsed_time"}, "app_id = ? and rowid > ?", new String[]{str, String.valueOf(this.f440e)}, null, null, "rowid", "1000");
                if (cursorQuery.moveToFirst()) {
                    do {
                        long j10 = cursorQuery.getLong(0);
                        long j11 = cursorQuery.getLong(3);
                        boolean z5 = cursorQuery.getLong(5) == 1;
                        long j12 = cursorQuery.getLong(6);
                        byte[] blob = cursorQuery.getBlob(4);
                        if (j10 > this.f440e) {
                            this.f440e = j10;
                        }
                        try {
                            o9 o9Var = (o9) h4.s2(p9.K(), blob);
                            String string = cursorQuery.getString(1);
                            if (string == null) {
                                string = _UrlKt.FRAGMENT_ENCODE_SET;
                            }
                            o9Var.o(string);
                            long j13 = cursorQuery.getLong(2);
                            o9Var.b();
                            ((p9) o9Var.X).R(j13);
                            o9Var.b();
                            ((p9) o9Var.X).u(j12);
                            arrayList.add(new cb.h(j10, j11, z5, (p9) o9Var.e()));
                        } catch (IOException e3) {
                            p0 p0Var = ((k1) jVar.X).f4205s0;
                            k1.h(p0Var);
                            p0Var.f4284t0.c(p0.P1(str), e3, "Data loss. Failed to merge raw event. appId");
                        }
                    } while (cursorQuery.moveToNext());
                    list = arrayList;
                } else {
                    list = Collections.EMPTY_LIST;
                }
            } finally {
                if (0 != 0) {
                    cursorQuery.close();
                }
            }
        } catch (SQLiteException e10) {
            p0 p0Var2 = ((k1) jVar.X).f4205s0;
            k1.h(p0Var2);
            p0Var2.f4284t0.c(p0.P1(str), e10, "Data loss. Error querying raw events batch. appId");
            list = arrayList;
        }
        return list;
    }

    public k(cb.j jVar, String str, long j10) {
        this.Y = jVar;
        r.d(str);
        this.X = str;
        this.f440e = jVar.e2("select rowid from raw_events where app_id = ? and timestamp < ? order by rowid desc limit 1", new String[]{str, String.valueOf(j10)}, -1L);
    }

    public k(t tVar, m2 m2Var, long j10) {
        this.X = tVar;
        this.Y = m2Var;
        this.f440e = j10;
    }
}
