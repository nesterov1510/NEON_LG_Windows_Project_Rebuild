package a1;

import java.util.UUID;
import m0.a0;
import m0.x0;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class m extends x0 {
    public final String X;
    public int Y;

    public m(a0 a0Var) {
        super(a0Var);
        this.X = "virtual-" + a0Var.e() + "-" + UUID.randomUUID().toString();
    }

    @Override // m0.x0, g0.r
    public final int c() {
        return n(0);
    }

    @Override // m0.x0, m0.a0
    public final String e() {
        return this.X;
    }

    @Override // m0.x0, g0.r
    public final int n(int i10) {
        return p0.g.i(this.f14960e.n(i10) - this.Y);
    }
}
