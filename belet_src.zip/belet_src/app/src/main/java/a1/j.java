package a1;

import android.graphics.Rect;
import android.util.Size;
import androidx.appcompat.widget.r3;
import d7.s;
import g0.a2;
import g0.b2;
import g0.k1;
import g0.w0;
import g6.y;
import j$.util.DesugarCollections;
import j$.util.Objects;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import m0.c0;
import m0.c1;
import m0.c2;
import m0.q2;
import m0.t0;
import m0.t2;
import m0.u0;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class j implements a2 {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final HashSet f432e;

    /* JADX INFO: renamed from: r0, reason: collision with root package name */
    public final t2 f433r0;

    /* JADX INFO: renamed from: s0, reason: collision with root package name */
    public final c0 f434s0;

    /* JADX INFO: renamed from: t0, reason: collision with root package name */
    public final c0 f435t0;

    /* JADX INFO: renamed from: v0, reason: collision with root package name */
    public final HashSet f436v0;

    /* JADX INFO: renamed from: w0, reason: collision with root package name */
    public final HashMap f437w0;

    /* JADX INFO: renamed from: x0, reason: collision with root package name */
    public final c f438x0;

    /* JADX INFO: renamed from: y0, reason: collision with root package name */
    public final c f439y0;
    public final HashMap X = new HashMap();
    public final HashMap Y = new HashMap();
    public final HashMap Z = new HashMap();
    public final i u0 = new i(this);

    public j(c0 c0Var, c0 c0Var2, HashSet hashSet, t2 t2Var, a0.e eVar) {
        this.f434s0 = c0Var;
        this.f435t0 = c0Var2;
        this.f433r0 = t2Var;
        this.f432e = hashSet;
        HashMap map = new HashMap();
        Iterator it = hashSet.iterator();
        while (it.hasNext()) {
            b2 b2Var = (b2) it.next();
            map.put(b2Var, b2Var.p(c0Var.r(), null, b2Var.g(true, t2Var)));
        }
        this.f437w0 = map;
        HashSet hashSet2 = new HashSet(map.values());
        this.f436v0 = hashSet2;
        this.f438x0 = new c(c0Var, hashSet2);
        if (this.f435t0 != null) {
            this.f439y0 = new c(this.f435t0, hashSet2);
        }
        Iterator it2 = hashSet.iterator();
        while (it2.hasNext()) {
            b2 b2Var2 = (b2) it2.next();
            this.Z.put(b2Var2, Boolean.FALSE);
            this.Y.put(b2Var2, new h(c0Var, this, eVar));
        }
    }

    public static void t(w0.k kVar, u0 u0Var, c2 c2Var) {
        kVar.d();
        try {
            y.b();
            kVar.a();
            w0.j jVar = kVar.f21531l;
            Objects.requireNonNull(jVar);
            jVar.g(u0Var, new w0.f(jVar, 0));
        } catch (t0 unused) {
            m0.a2 a2Var = c2Var.f;
            if (a2Var != null) {
                a2Var.a(c2Var);
            }
        }
    }

    public static u0 u(b2 b2Var) {
        List listB = b2Var instanceof w0 ? b2Var.f8318o.b() : DesugarCollections.unmodifiableList(b2Var.f8318o.f14779g.f14901a);
        s.k(null, listB.size() <= 1);
        if (listB.size() == 1) {
            return (u0) listB.get(0);
        }
        return null;
    }

    @Override // g0.a2
    public final void h(b2 b2Var) {
        y.b();
        if (w(b2Var)) {
            w0.k kVar = (w0.k) this.X.get(b2Var);
            Objects.requireNonNull(kVar);
            u0 u0VarU = u(b2Var);
            if (u0VarU != null) {
                t(kVar, u0VarU, b2Var.f8318o);
                return;
            }
            y.b();
            kVar.a();
            kVar.f21531l.a();
        }
    }

    @Override // g0.a2
    public final void i(b2 b2Var) {
        y.b();
        if (w(b2Var)) {
            this.Z.put(b2Var, Boolean.FALSE);
            w0.k kVar = (w0.k) this.X.get(b2Var);
            Objects.requireNonNull(kVar);
            y.b();
            kVar.a();
            kVar.f21531l.a();
        }
    }

    @Override // g0.a2
    public final void k(b2 b2Var) {
        u0 u0VarU;
        y.b();
        w0.k kVar = (w0.k) this.X.get(b2Var);
        Objects.requireNonNull(kVar);
        if (w(b2Var) && (u0VarU = u(b2Var)) != null) {
            t(kVar, u0VarU, b2Var.f8318o);
        }
    }

    @Override // g0.a2
    public final void m(b2 b2Var) {
        y.b();
        if (w(b2Var)) {
            return;
        }
        this.Z.put(b2Var, Boolean.TRUE);
        u0 u0VarU = u(b2Var);
        if (u0VarU != null) {
            w0.k kVar = (w0.k) this.X.get(b2Var);
            Objects.requireNonNull(kVar);
            t(kVar, u0VarU, b2Var.f8318o);
        }
    }

    public final y0.b s(b2 b2Var, c cVar, c0 c0Var, w0.k kVar, int i10, boolean z5) {
        int i11;
        int iN = c0Var.b().n(i10);
        boolean zE = p0.g.e(kVar.f21523b);
        q2 q2Var = (q2) this.f437w0.get(b2Var);
        Objects.requireNonNull(q2Var);
        a aVarB = cVar.b(q2Var, kVar.f21525d, p0.g.b(kVar.f21523b), z5);
        Rect rect = aVarB.f401a;
        Size size = aVarB.f402b;
        int i12 = p0.g.i((kVar.f21528i + c0Var.b().n(((c1) b2Var.h).Z(0))) - iN);
        boolean zO = b2Var.o(c0Var) ^ zE;
        if (b2Var instanceof k1) {
            i11 = 1;
        } else {
            i11 = b2Var instanceof w0 ? 4 : 2;
        }
        return new y0.b(UUID.randomUUID(), i11, b2Var instanceof w0 ? 256 : 34, rect, p0.g.g(i12, size), i12, zO);
    }

    public final HashMap v(w0.k kVar, boolean z5) {
        HashMap map = new HashMap();
        for (b2 b2Var : this.f432e) {
            q2 q2Var = (q2) this.f437w0.get(b2Var);
            Objects.requireNonNull(q2Var);
            Size size = this.f438x0.b(q2Var, kVar.f21525d, p0.g.b(kVar.f21523b), z5).f403c;
            map.put(b2Var, size);
            y6.a.e("VirtualCameraAdapter", "Selected child size: " + size + ", useCase: " + b2Var);
        }
        return map;
    }

    public final boolean w(b2 b2Var) {
        Boolean bool = (Boolean) this.Z.get(b2Var);
        Objects.requireNonNull(bool);
        return bool.booleanValue();
    }

    public final void x(HashMap map, HashMap map2) {
        HashMap map3 = this.X;
        map3.clear();
        map3.putAll(map);
        for (Map.Entry entry : map3.entrySet()) {
            b2 b2Var = (b2) entry.getKey();
            w0.k kVar = (w0.k) entry.getValue();
            b2Var.C(kVar.f21525d);
            b2Var.B(kVar.f21523b);
            r3 r3VarB = kVar.f21527g.b();
            Size size = (Size) map2.get(b2Var);
            if (size != null) {
                r3VarB.f1420c = size;
            }
            b2Var.F(r3VarB.a(), null);
            b2Var.s();
        }
    }
}
