package a1;

import g0.k1;
import java.util.UUID;
import m0.c1;
import m0.l1;
import m0.p1;
import m0.p2;
import m0.q1;
import m0.q2;
import m0.s2;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class f implements p2 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f426a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final l1 f427b;

    public f(l1 l1Var, int i10) {
        this.f426a = i10;
        switch (i10) {
            case 1:
                this.f427b = l1Var;
                m0.f fVar = s0.k.f18153h0;
                Class cls = (Class) l1Var.p(fVar, null);
                if (cls != null && !cls.equals(k1.class)) {
                    throw new IllegalArgumentException("Invalid target class configuration for " + this + ": " + cls);
                }
                l1Var.j(q2.V, s2.X);
                l1Var.j(fVar, k1.class);
                m0.f fVar2 = s0.k.f18152g0;
                if (l1Var.p(fVar2, null) == null) {
                    l1Var.j(fVar2, k1.class.getCanonicalName() + "-" + UUID.randomUUID());
                }
                m0.f fVar3 = c1.D;
                if (((Integer) l1Var.p(fVar3, -1)).intValue() == -1) {
                    l1Var.j(fVar3, 2);
                    return;
                }
                return;
            default:
                this.f427b = l1Var;
                m0.f fVar4 = s0.k.f18153h0;
                Class cls2 = (Class) l1Var.p(fVar4, null);
                if (cls2 != null && !cls2.equals(e.class)) {
                    throw new IllegalArgumentException("Invalid target class configuration for " + this + ": " + cls2);
                }
                l1Var.j(q2.V, s2.f14930r0);
                l1Var.j(fVar4, e.class);
                m0.f fVar5 = s0.k.f18152g0;
                if (l1Var.p(fVar5, null) == null) {
                    l1Var.j(fVar5, e.class.getCanonicalName() + "-" + UUID.randomUUID());
                    return;
                }
                return;
        }
    }

    @Override // g0.b0
    public final m0.k1 a() {
        switch (this.f426a) {
            case 0:
                break;
        }
        return this.f427b;
    }

    @Override // m0.p2
    public final q2 b() {
        switch (this.f426a) {
            case 0:
                return new g(p1.a(this.f427b));
            default:
                return new q1(p1.a(this.f427b));
        }
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public f() {
        this(l1.c(), 1);
        this.f426a = 1;
    }
}
