package a1;

import android.graphics.Rect;
import android.util.Size;
import kotlin.jvm.internal.q;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Rect f401a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Size f402b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Size f403c;

    public a(Rect rect, Size childSizeToScale, Size originalSelectedChildSize) {
        q.g(childSizeToScale, "childSizeToScale");
        q.g(originalSelectedChildSize, "originalSelectedChildSize");
        this.f401a = rect;
        this.f402b = childSizeToScale;
        this.f403c = originalSelectedChildSize;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof a)) {
            return false;
        }
        a aVar = (a) obj;
        return q.c(this.f401a, aVar.f401a) && q.c(this.f402b, aVar.f402b) && q.c(this.f403c, aVar.f403c);
    }

    public final int hashCode() {
        return this.f403c.hashCode() + ((this.f402b.hashCode() + (this.f401a.hashCode() * 31)) * 31);
    }

    public final String toString() {
        return "PreferredChildSize(cropRectBeforeScaling=" + this.f401a + ", childSizeToScale=" + this.f402b + ", originalSelectedChildSize=" + this.f403c + ')';
    }
}
