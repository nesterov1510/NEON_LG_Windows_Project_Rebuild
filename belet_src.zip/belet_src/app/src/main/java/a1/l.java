package a1;

import g0.u0;
import m0.r0;
import m0.y1;
import m0.z;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class l implements z {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final z f441b;

    public l(z zVar) {
        this.f441b = zVar;
    }

    @Override // m0.z
    public final void a() {
        this.f441b.a();
    }

    @Override // m0.z
    public final void b(y1 y1Var) {
        this.f441b.b(y1Var);
    }

    @Override // m0.z
    public final void c(r0 r0Var) {
        this.f441b.c(r0Var);
    }

    @Override // m0.z
    public final void d(u0 u0Var) {
        this.f441b.d(u0Var);
    }

    @Override // m0.z
    public final void e(int i10) {
        this.f441b.e(i10);
    }

    @Override // m0.z
    public final r0 f() {
        return this.f441b.f();
    }

    @Override // m0.z
    public final void g() {
        this.f441b.g();
    }
}
