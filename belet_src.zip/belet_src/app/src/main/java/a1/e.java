package a1;

import a0.y4;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.RectF;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraDevice;
import android.util.Log;
import android.util.Pair;
import android.util.Range;
import android.util.Rational;
import android.util.Size;
import androidx.appcompat.widget.r3;
import d0.v;
import d1.q;
import d7.s;
import g0.a0;
import g0.b2;
import g0.z;
import g6.y;
import j$.util.DesugarCollections;
import j$.util.Objects;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import kotlin.jvm.internal.p;
import m0.a1;
import m0.c0;
import m0.c1;
import m0.c2;
import m0.f2;
import m0.l1;
import m0.o;
import m0.p0;
import m0.p1;
import m0.p2;
import m0.q2;
import m0.r0;
import m0.t2;
import m0.y1;
import m0.z1;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class e extends b2 {
    public y1 A;
    public y1 B;
    public z1 C;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final g f416q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final j f417r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final z f418s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final z f419t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public ge.g f420u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public y4 f421v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public w0.k f422w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public w0.k f423x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public w0.k f424y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public w0.k f425z;

    public e(c0 c0Var, c0 c0Var2, z zVar, z zVar2, HashSet hashSet, t2 t2Var) {
        super(K(hashSet));
        this.f416q = K(hashSet);
        this.f418s = zVar;
        this.f419t = zVar2;
        this.f417r = new j(c0Var, c0Var2, hashSet, t2Var, new a0.e(7));
        HashSet hashSet2 = ((b2) hashSet.iterator().next()).f8311g;
        this.f8311g = hashSet2 != null ? new HashSet(hashSet2) : null;
    }

    public static g K(HashSet hashSet) {
        l1 l1VarC = l1.c();
        new f(l1VarC, 0);
        l1VarC.j(a1.f14759x, 34);
        ArrayList arrayList = new ArrayList();
        Iterator it = hashSet.iterator();
        while (it.hasNext()) {
            b2 b2Var = (b2) it.next();
            if (b2Var.h.b(q2.V)) {
                arrayList.add(b2Var.h.H());
            } else {
                Log.e("StreamSharing", "A child does not have capture type.");
            }
        }
        l1VarC.j(g.X, arrayList);
        l1VarC.j(c1.D, 2);
        l1VarC.j(q2.f14917d0, f2.PREVIEW_VIDEO_STILL);
        return new g(p1.a(l1VarC));
    }

    @Override // g0.b2
    public final void A() {
        G();
        j jVar = this.f417r;
        for (b2 b2Var : jVar.f432e) {
            h hVar = (h) jVar.Y.get(b2Var);
            Objects.requireNonNull(hVar);
            b2Var.D(hVar);
        }
    }

    public final void G() {
        z1 z1Var = this.C;
        if (z1Var != null) {
            z1Var.b();
            this.C = null;
        }
        w0.k kVar = this.f422w;
        if (kVar != null) {
            kVar.b();
            this.f422w = null;
        }
        w0.k kVar2 = this.f423x;
        if (kVar2 != null) {
            kVar2.b();
            this.f423x = null;
        }
        w0.k kVar3 = this.f424y;
        if (kVar3 != null) {
            kVar3.b();
            this.f424y = null;
        }
        w0.k kVar4 = this.f425z;
        if (kVar4 != null) {
            kVar4.b();
            this.f425z = null;
        }
        ge.g gVar = this.f420u;
        if (gVar != null) {
            ((w0.c) gVar.X).release();
            y.F(new t3.d(11, gVar));
            this.f420u = null;
        }
        y4 y4Var = this.f421v;
        if (y4Var != null) {
            ((w0.m) y4Var.f395e).release();
            y.F(new t3.d(15, y4Var));
            this.f421v = null;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final List H(String str, String str2, q2 q2Var, m0.m mVar, m0.m mVar2) {
        boolean z5;
        int i10;
        a0 a0Var = mVar.f14883c;
        y.b();
        j jVar = this.f417r;
        if (mVar2 == null) {
            w0.k kVarI = I(str, str2, q2Var, mVar, null);
            c0 c0VarD = d();
            Objects.requireNonNull(c0VarD);
            ge.g gVar = new ge.g(c0VarD, new w0.c(a0Var), 18);
            this.f420u = gVar;
            boolean z6 = this.f8314k != null;
            int iZ = ((c1) this.h).Z(0);
            jVar.getClass();
            HashMap map = new HashMap();
            for (b2 b2Var : jVar.f432e) {
                c cVar = jVar.f438x0;
                c0 c0Var = jVar.f434s0;
                j jVar2 = jVar;
                boolean z9 = z6;
                y0.b bVarS = jVar2.s(b2Var, cVar, c0Var, kVarI, iZ, z9);
                int iN = jVar2.f434s0.b().n(((c1) b2Var.h).Z(0));
                h hVar = (h) jVar2.Y.get(b2Var);
                Objects.requireNonNull(hVar);
                hVar.Y.Y = iN;
                map.put(b2Var, bVarS);
                jVar = jVar2;
                z6 = z9;
            }
            j jVar3 = jVar;
            boolean z10 = z6;
            ArrayList arrayList = new ArrayList(map.values());
            if (kVarI == null) {
                throw new NullPointerException("Null surfaceEdge");
            }
            w0.c cVar2 = (w0.c) gVar.X;
            y.b();
            y6.a.e("SurfaceProcessorNode", "[StreamSharing] SurfaceProcessorNode Transform (Processor=" + cVar2 + "\n   inputEdge = " + kVarI);
            int size = arrayList.size();
            int i11 = 0;
            while (i11 < size) {
                Object obj = arrayList.get(i11);
                i11++;
                y6.a.e("SurfaceProcessorNode", "   outputConfig = " + ((y0.b) obj));
            }
            gVar.Z = new ke.f();
            int size2 = arrayList.size();
            int i12 = 0;
            while (i12 < size2) {
                Object obj2 = arrayList.get(i12);
                int i13 = i12 + 1;
                y0.b bVar = (y0.b) obj2;
                ke.f fVar = (ke.f) gVar.Z;
                Rect rect = bVar.f22355d;
                int i14 = bVar.f;
                boolean z11 = bVar.f22357g;
                ArrayList arrayList2 = arrayList;
                Matrix matrix = new Matrix(kVarI.f21523b);
                RectF rectF = new RectF(rect);
                int i15 = size2;
                Size size3 = bVar.f22356e;
                matrix.postConcat(p0.g.a(rectF, p0.g.h(size3), i14, z11));
                s.f(p0.g.d(p0.g.g(i14, p0.g.f(rect)), false, size3));
                HashMap map2 = map;
                Rect rect2 = new Rect(0, 0, size3.getWidth(), size3.getHeight());
                r3 r3VarB = kVarI.f21527g.b();
                r3VarB.f1419b = size3;
                fVar.put(bVar, new w0.k(bVar.f22353b, bVar.f22354c, r3VarB.a(), matrix, false, rect2, kVarI.f21528i - i14, -1, kVarI.f21526e != z11));
                arrayList = arrayList2;
                size2 = i15;
                i12 = i13;
                map = map2;
            }
            HashMap map3 = map;
            cVar2.b(kVarI.c((c0) gVar.Y, true));
            Iterator it = ((ke.f) gVar.Z).entrySet().iterator();
            while (true) {
                i10 = 3;
                if (!it.hasNext()) {
                    break;
                }
                Map.Entry entry = (Map.Entry) it.next();
                gVar.t(kVarI, entry);
                w0.k kVar = (w0.k) entry.getValue();
                w.f fVar2 = new w.f(gVar, kVarI, entry, i10);
                kVar.getClass();
                y.b();
                kVar.a();
                kVar.f21532m.add(fVar2);
            }
            kVarI.f21534o.add(new q(i10, (ke.f) gVar.Z));
            ke.f fVar3 = (ke.f) gVar.Z;
            HashMap map4 = new HashMap();
            for (Map.Entry entry2 : map3.entrySet()) {
                map4.put((b2) entry2.getKey(), (w0.k) fVar3.get(entry2.getValue()));
            }
            jVar3.x(map4, jVar3.v(kVarI, z10));
            Object[] objArr = {this.A.c()};
            ArrayList arrayList3 = new ArrayList(1);
            Object obj3 = objArr[0];
            Objects.requireNonNull(obj3);
            arrayList3.add(obj3);
            return DesugarCollections.unmodifiableList(arrayList3);
        }
        w0.k kVarI2 = I(str, str2, q2Var, mVar, mVar2);
        Matrix matrix2 = this.f8315l;
        c0 c0VarJ = j();
        Objects.requireNonNull(c0VarJ);
        boolean zP = c0VarJ.p();
        Size size4 = mVar2.f14881a;
        Rect rect3 = this.f8314k;
        if (rect3 != null) {
            z5 = false;
        } else {
            z5 = false;
            rect3 = new Rect(0, 0, size4.getWidth(), size4.getHeight());
        }
        c0 c0VarJ2 = j();
        Objects.requireNonNull(c0VarJ2);
        int i16 = i(c0VarJ2, z5);
        c0 c0VarJ3 = j();
        Objects.requireNonNull(c0VarJ3);
        j jVar4 = jVar;
        w0.k kVar2 = new w0.k(3, 34, mVar2, matrix2, zP, rect3, i16, -1, o(c0VarJ3));
        this.f423x = kVar2;
        Objects.requireNonNull(j());
        this.f425z = kVar2;
        y1 y1VarJ = J(this.f423x, q2Var, mVar2);
        this.B = y1VarJ;
        z1 z1Var = this.C;
        if (z1Var != null) {
            z1Var.b();
        }
        z1 z1Var2 = new z1(new d(this, str, str2, q2Var, mVar, mVar2));
        this.C = z1Var2;
        y1VarJ.f = z1Var2;
        w0.k kVar3 = this.f425z;
        c0 c0VarD2 = d();
        c0 c0VarJ4 = j();
        x0.e eVar = new x0.e(a0Var, this.f418s, this.f419t);
        y4 y4Var = new y4();
        y4Var.X = c0VarD2;
        y4Var.Y = c0VarJ4;
        y4Var.f395e = eVar;
        this.f421v = y4Var;
        boolean z12 = this.f8314k != null;
        int iZ2 = ((c1) this.h).Z(0);
        jVar4.getClass();
        HashMap map5 = new HashMap();
        for (b2 b2Var2 : jVar4.f432e) {
            int i17 = iZ2;
            j jVar5 = jVar4;
            y0.b bVarS2 = jVar5.s(b2Var2, jVar4.f438x0, jVar4.f434s0, kVarI2, i17, z12);
            c cVar3 = jVar5.f439y0;
            Objects.requireNonNull(cVar3);
            c0 c0Var2 = jVar5.f435t0;
            Objects.requireNonNull(c0Var2);
            w0.k kVar4 = kVar3;
            y0.b bVarS3 = jVar5.s(b2Var2, cVar3, c0Var2, kVar4, i17, z12);
            int iN2 = jVar5.f434s0.b().n(((c1) b2Var2.h).Z(0));
            h hVar2 = (h) jVar5.Y.get(b2Var2);
            Objects.requireNonNull(hVar2);
            hVar2.Y.Y = iN2;
            map5.put(b2Var2, new x0.a(bVarS2, bVarS3));
            jVar4 = jVar5;
            kVar3 = kVar4;
            iZ2 = i17;
        }
        w0.k kVar5 = kVar3;
        j jVar6 = jVar4;
        y4 y4Var2 = this.f421v;
        ArrayList arrayList4 = new ArrayList(map5.values());
        x0.b bVar2 = new x0.b(kVarI2, kVar5, arrayList4);
        y4Var2.getClass();
        y.b();
        StringBuilder sb2 = new StringBuilder("[StreamSharing] DualSurfaceProcessorNode Transform Processor = ");
        w0.m mVar3 = (w0.m) y4Var2.f395e;
        sb2.append(mVar3);
        sb2.append("\n   primary input = ");
        sb2.append(kVarI2);
        sb2.append("\n   secondary input = ");
        sb2.append(kVar5);
        y6.a.e("DualSurfaceProcessorNode", sb2.toString());
        int size5 = arrayList4.size();
        int i18 = 0;
        while (i18 < size5) {
            Object obj4 = arrayList4.get(i18);
            i18++;
            y6.a.e("SurfaceProcessorNode", "   outputConfig = " + ((x0.a) obj4));
        }
        y4Var2.f396r0 = bVar2;
        y4Var2.Z = new ke.f();
        x0.b bVar3 = (x0.b) y4Var2.f396r0;
        w0.k kVar6 = bVar3.f21928a;
        w0.k kVar7 = bVar3.f21929b;
        ArrayList arrayList5 = bVar3.f21930c;
        int size6 = arrayList5.size();
        int i19 = 0;
        while (i19 < size6) {
            Object obj5 = arrayList5.get(i19);
            int i20 = i19 + 1;
            x0.a aVar = (x0.a) obj5;
            ke.f fVar4 = (ke.f) y4Var2.Z;
            y0.b bVar4 = aVar.f21926a;
            Rect rect4 = bVar4.f22355d;
            ArrayList arrayList6 = arrayList5;
            int i21 = bVar4.f;
            int i22 = size6;
            boolean z13 = bVar4.f22357g;
            HashMap map6 = map5;
            Matrix matrix3 = new Matrix(kVar6.f21523b);
            RectF rectF2 = new RectF(rect4);
            Size size7 = bVar4.f22356e;
            matrix3.postConcat(p0.g.a(rectF2, p0.g.h(size7), i21, z13));
            s.f(p0.g.d(p0.g.g(i21, p0.g.f(rect4)), false, size7));
            Rect rect5 = new Rect(0, 0, size7.getWidth(), size7.getHeight());
            r3 r3VarB2 = kVar6.f21527g.b();
            r3VarB2.f1419b = size7;
            fVar4.put(aVar, new w0.k(bVar4.f22353b, bVar4.f22354c, r3VarB2.a(), matrix3, false, rect5, kVar6.f21528i - i21, -1, kVar6.f21526e != z13));
            size6 = i22;
            map5 = map6;
            i19 = i20;
            arrayList5 = arrayList6;
        }
        HashMap map7 = map5;
        mVar3.b(kVar6.c((c0) y4Var2.X, true));
        mVar3.b(kVar7.c((c0) y4Var2.Y, false));
        c0 c0Var3 = (c0) y4Var2.X;
        c0 c0Var4 = (c0) y4Var2.Y;
        for (final Map.Entry entry3 : ((ke.f) y4Var2.Z).entrySet()) {
            final y4 y4Var3 = y4Var2;
            final w0.k kVar8 = kVar6;
            final w0.k kVar9 = kVar7;
            y4Var3.o(c0Var3, c0Var4, kVar8, kVar9, entry3);
            w0.k kVar10 = (w0.k) entry3.getValue();
            final c0 c0Var5 = c0Var4;
            final c0 c0Var6 = c0Var3;
            Runnable runnable = new Runnable() { // from class: x0.f
                @Override // java.lang.Runnable
                public final void run() {
                    y4Var3.o(c0Var6, c0Var5, kVar8, kVar9, entry3);
                }
            };
            c0Var3 = c0Var6;
            c0Var4 = c0Var5;
            kVar10.getClass();
            y.b();
            kVar10.a();
            kVar10.f21532m.add(runnable);
            y4Var2 = y4Var3;
            kVar6 = kVar8;
            kVar7 = kVar9;
        }
        ke.f fVar5 = (ke.f) y4Var2.Z;
        HashMap map8 = new HashMap();
        for (Map.Entry entry4 : map7.entrySet()) {
            map8.put((b2) entry4.getKey(), (w0.k) fVar5.get(entry4.getValue()));
        }
        jVar6.x(map8, jVar6.v(kVarI2, z12));
        Object[] objArr2 = {this.A.c(), this.B.c()};
        ArrayList arrayList7 = new ArrayList(2);
        for (int i23 = 0; i23 < 2; i23++) {
            Object obj6 = objArr2[i23];
            Objects.requireNonNull(obj6);
            arrayList7.add(obj6);
        }
        return DesugarCollections.unmodifiableList(arrayList7);
    }

    public final w0.k I(String str, String str2, q2 q2Var, m0.m mVar, m0.m mVar2) {
        Matrix matrix = this.f8315l;
        c0 c0VarD = d();
        Objects.requireNonNull(c0VarD);
        boolean zP = c0VarD.p();
        Size size = mVar.f14881a;
        Rect rect = this.f8314k;
        if (rect == null) {
            rect = new Rect(0, 0, size.getWidth(), size.getHeight());
        }
        c0 c0VarD2 = d();
        Objects.requireNonNull(c0VarD2);
        int i10 = i(c0VarD2, false);
        c0 c0VarD3 = d();
        Objects.requireNonNull(c0VarD3);
        w0.k kVar = new w0.k(3, 34, mVar, matrix, zP, rect, i10, -1, o(c0VarD3));
        this.f422w = kVar;
        Objects.requireNonNull(d());
        this.f424y = kVar;
        y1 y1VarJ = J(this.f422w, q2Var, mVar);
        this.A = y1VarJ;
        z1 z1Var = this.C;
        if (z1Var != null) {
            z1Var.b();
        }
        z1 z1Var2 = new z1(new d(this, str, str2, q2Var, mVar, mVar2));
        this.C = z1Var2;
        y1VarJ.f = z1Var2;
        return this.f424y;
    }

    public final y1 J(w0.k kVar, q2 q2Var, m0.m mVar) {
        y1 y1VarD = y1.d(q2Var, mVar.f14881a);
        v vVar = y1VarD.f14962b;
        j jVar = this.f417r;
        Iterator it = jVar.f432e.iterator();
        int i10 = -1;
        while (it.hasNext()) {
            int i11 = ((b2) it.next()).h.s().f14779g.f14903c;
            List list = c2.f14773j;
            if (list.indexOf(Integer.valueOf(i10)) < list.indexOf(Integer.valueOf(i11))) {
                i10 = i11;
            }
        }
        if (i10 != -1) {
            vVar.X = i10;
        }
        Size size = mVar.f14881a;
        Iterator it2 = jVar.f432e.iterator();
        while (it2.hasNext()) {
            c2 c2VarC = y1.d(((b2) it2.next()).h, size).c();
            p0 p0Var = c2VarC.f14779g;
            vVar.d(p0Var.f14904d);
            List<o> list2 = c2VarC.f14778e;
            ArrayList arrayList = y1VarD.f14965e;
            for (o oVar : list2) {
                vVar.e(oVar);
                if (!arrayList.contains(oVar)) {
                    arrayList.add(oVar);
                }
            }
            for (CameraCaptureSession.StateCallback stateCallback : c2VarC.f14777d) {
                ArrayList arrayList2 = y1VarD.f14964d;
                if (!arrayList2.contains(stateCallback)) {
                    arrayList2.add(stateCallback);
                }
            }
            for (CameraDevice.StateCallback stateCallback2 : c2VarC.f14776c) {
                ArrayList arrayList3 = y1VarD.f14963c;
                if (!arrayList3.contains(stateCallback2)) {
                    arrayList3.add(stateCallback2);
                }
            }
            vVar.f(p0Var.f14902b);
        }
        kVar.getClass();
        y.b();
        kVar.a();
        s.k("Consumer can only be linked once.", !kVar.f21529j);
        kVar.f21529j = true;
        y1VarD.b(kVar.f21531l, mVar.f14883c, -1);
        vVar.e(jVar.u0);
        r0 r0Var = mVar.f;
        if (r0Var != null) {
            vVar.f(r0Var);
        }
        y1VarD.h = mVar.f14884d;
        a(y1VarD, mVar);
        return y1VarD;
    }

    @Override // g0.b2
    public final q2 g(boolean z5, t2 t2Var) {
        g gVar = this.f416q;
        gVar.getClass();
        r0 r0VarA = t2Var.a(p.c(gVar), 1);
        if (z5) {
            r0VarA = p.Q(r0VarA, gVar.f428e);
        }
        if (r0VarA == null) {
            return null;
        }
        return ((f) m(r0VarA)).b();
    }

    @Override // g0.b2
    public final Set k(m0.a0 a0Var) {
        HashSet hashSet = this.f417r.f432e;
        HashSet hashSet2 = null;
        if (hashSet.isEmpty()) {
            return null;
        }
        Iterator it = hashSet.iterator();
        while (it.hasNext()) {
            Set setK = ((b2) it.next()).k(a0Var);
            if (setK != null) {
                if (hashSet2 == null) {
                    hashSet2 = new HashSet(setK);
                } else {
                    hashSet2.retainAll(setK);
                }
            }
        }
        return hashSet2;
    }

    @Override // g0.b2
    public final Set l() {
        HashSet hashSet = new HashSet();
        hashSet.add(3);
        return hashSet;
    }

    @Override // g0.b2
    public final p2 m(r0 r0Var) {
        return new f(l1.d(r0Var), 0);
    }

    @Override // g0.b2
    public final void t() {
        j jVar = this.f417r;
        for (b2 b2Var : jVar.f432e) {
            h hVar = (h) jVar.Y.get(b2Var);
            Objects.requireNonNull(hVar);
            b2Var.b(hVar, null, null, b2Var.g(true, jVar.f433r0));
        }
    }

    @Override // g0.b2
    public final void u() {
        Iterator it = this.f417r.f432e.iterator();
        while (it.hasNext()) {
            ((b2) it.next()).u();
        }
    }

    /* JADX WARN: Code duplicated, block: B:71:0x01ba  */
    @Override // g0.b2
    public final q2 v(m0.a0 a0Var, p2 p2Var) {
        a0 a0Var2;
        boolean z5;
        Object objA = p2Var.a();
        j jVar = this.f417r;
        HashSet hashSet = jVar.f436v0;
        c cVar = jVar.f438x0;
        List listQ = cVar.f.q(34);
        HashSet<q2> hashSet2 = cVar.f408d;
        for (q2 q2Var : hashSet2) {
            if (!q2Var.w() && (q2Var instanceof c1)) {
                ((c1) q2Var).y();
            }
        }
        List list = (List) ((p1) objA).p(c1.H, null);
        if (list != null) {
            Iterator it = list.iterator();
            while (true) {
                if (!it.hasNext()) {
                    listQ = new ArrayList();
                    break;
                }
                Pair pair = (Pair) it.next();
                if (((Integer) pair.first).equals(34)) {
                    listQ = Arrays.asList((Size[]) pair.second);
                    break;
                }
            }
        }
        Rational rational = cVar.f407c;
        ArrayList arrayList = new ArrayList();
        HashSet hashSet3 = new HashSet();
        Iterator it2 = hashSet2.iterator();
        while (it2.hasNext()) {
            hashSet3.addAll(cVar.c((q2) it2.next()));
        }
        Iterator it3 = hashSet3.iterator();
        while (it3.hasNext()) {
            if (!p0.b.a(rational, (Size) it3.next())) {
                arrayList.addAll(cVar.g(cVar.f406b, listQ, false));
                break;
            }
        }
        int size = arrayList.size();
        if (!hashSet2.isEmpty()) {
            Iterator it4 = hashSet2.iterator();
            loop4: do {
                if (!it4.hasNext()) {
                    size = 0;
                    break;
                }
                Iterator it5 = cVar.c((q2) it4.next()).iterator();
                z5 = false;
                boolean z6 = false;
                while (it5.hasNext()) {
                    boolean zA = p0.b.a(rational, (Size) it5.next());
                    if (zA) {
                        z5 = true;
                    }
                    if (z6 && zA) {
                        break loop4;
                    }
                    if (!zA) {
                        z6 = true;
                    }
                }
            } while (z5);
        }
        arrayList.addAll(size, cVar.g(rational, listQ, false));
        arrayList.addAll(cVar.f(listQ, false));
        if (arrayList.isEmpty()) {
            y6.a.D("ResolutionsMerger", "Failed to find a parent resolution that does not result in double-cropping, this might due to camera not supporting 4:3 and 16:9resolutions or a strict ResolutionSelector settings. Starting resolution selection process with resolutions that might have a smaller FOV.");
            arrayList.addAll(cVar.f(listQ, true));
        }
        y6.a.e("ResolutionsMerger", "Parent resolutions: " + arrayList);
        l1 l1Var = (l1) objA;
        l1Var.j(c1.J, arrayList);
        m0.f fVar = q2.O;
        Iterator it6 = hashSet.iterator();
        int iMax = 0;
        while (it6.hasNext()) {
            iMax = Math.max(iMax, ((q2) it6.next()).t());
        }
        l1Var.j(fVar, Integer.valueOf(iMax));
        ArrayList arrayList2 = new ArrayList();
        Iterator it7 = hashSet.iterator();
        while (it7.hasNext()) {
            arrayList2.add(((q2) it7.next()).e());
        }
        if (arrayList2.isEmpty()) {
            a0Var2 = null;
            break;
        }
        a0 a0Var3 = (a0) arrayList2.get(0);
        Integer numValueOf = Integer.valueOf(a0Var3.f8300a);
        Integer numValueOf2 = Integer.valueOf(a0Var3.f8301b);
        int i10 = 1;
        while (true) {
            if (i10 >= arrayList2.size()) {
                a0Var2 = new a0(numValueOf.intValue(), numValueOf2.intValue());
                break;
            }
            a0 a0Var4 = (a0) arrayList2.get(i10);
            Integer numValueOf3 = Integer.valueOf(a0Var4.f8300a);
            if (numValueOf.equals(0)) {
                numValueOf = numValueOf3;
            } else if (!numValueOf3.equals(0)) {
                if (numValueOf.equals(2) && !numValueOf3.equals(1)) {
                    numValueOf = numValueOf3;
                } else if ((!numValueOf3.equals(2) || numValueOf.equals(1)) && !numValueOf.equals(numValueOf3)) {
                    numValueOf = null;
                }
            }
            Integer numValueOf4 = Integer.valueOf(a0Var4.f8301b);
            if (numValueOf2.equals(0)) {
                numValueOf2 = numValueOf4;
            } else if (!numValueOf4.equals(0) && !numValueOf2.equals(numValueOf4)) {
                numValueOf2 = null;
            }
            if (numValueOf == null || numValueOf2 == null) {
                a0Var2 = null;
                break;
            }
            i10++;
        }
        if (a0Var2 == null) {
            throw new IllegalArgumentException("Failed to merge child dynamic ranges, can not find a dynamic range that satisfies all children.");
        }
        l1Var.j(a1.f14761z, a0Var2);
        m0.f fVar2 = q2.Q;
        Range rangeExtend = m0.m.h;
        Iterator it8 = hashSet.iterator();
        while (it8.hasNext()) {
            Range rangeL = ((q2) it8.next()).L(rangeExtend);
            Objects.requireNonNull(rangeL);
            if (m0.m.h.equals(rangeExtend)) {
                rangeExtend = rangeL;
            } else {
                try {
                    rangeExtend = rangeExtend.intersect(rangeL);
                } catch (IllegalArgumentException unused) {
                    y6.a.e("VirtualCameraAdapter", "No intersected frame rate can be found from the target frame rate settings of the UseCases! Resolved: " + rangeExtend + " <<>> " + rangeL);
                    rangeExtend = rangeExtend.extend(rangeL);
                }
            }
        }
        l1Var.j(fVar2, rangeExtend);
        Iterator it9 = jVar.f432e.iterator();
        while (it9.hasNext()) {
            q2 q2Var2 = (q2) jVar.f437w0.get((b2) it9.next());
            Objects.requireNonNull(q2Var2);
            if (q2Var2.I() != 0) {
                l1Var.j(q2.f14914a0, Integer.valueOf(q2Var2.I()));
            }
            if (q2Var2.R() != 0) {
                l1Var.j(q2.W, Integer.valueOf(q2Var2.R()));
            }
        }
        return p2Var.b();
    }

    @Override // g0.b2
    public final void w() {
        Iterator it = this.f417r.f432e.iterator();
        while (it.hasNext()) {
            ((b2) it.next()).w();
        }
    }

    @Override // g0.b2
    public final void x() {
        Iterator it = this.f417r.f432e.iterator();
        while (it.hasNext()) {
            ((b2) it.next()).x();
        }
    }

    @Override // g0.b2
    public final m0.m y(r0 r0Var) {
        this.A.a(r0Var);
        Object[] objArr = {this.A.c()};
        ArrayList arrayList = new ArrayList(1);
        Object obj = objArr[0];
        Objects.requireNonNull(obj);
        arrayList.add(obj);
        E(DesugarCollections.unmodifiableList(arrayList));
        r3 r3VarB = this.f8312i.b();
        r3VarB.f = r0Var;
        return r3VarB.a();
    }

    @Override // g0.b2
    public final m0.m z(m0.m mVar, m0.m mVar2) {
        y6.a.e("StreamSharing", "onSuggestedStreamSpecUpdated: primaryStreamSpec = " + mVar + ", secondaryStreamSpec " + mVar2);
        E(H(f(), j() == null ? null : j().r().e(), this.h, mVar, mVar2));
        q();
        return mVar;
    }
}
