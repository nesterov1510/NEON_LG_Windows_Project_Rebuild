package a1;

import android.util.Range;
import android.util.Size;
import g0.a0;
import go.a2;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import kotlin.jvm.internal.p;
import m0.a1;
import m0.b1;
import m0.c1;
import m0.c2;
import m0.f2;
import m0.o2;
import m0.p0;
import m0.p1;
import m0.q0;
import m0.q2;
import m0.r0;
import m0.s2;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class g implements q2, c1, s0.l {
    public static final m0.f X = new m0.f("camerax.core.streamSharing.captureTypes", List.class, null);

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final p1 f428e;

    public g(p1 p1Var) {
        this.f428e = p1Var;
    }

    @Override // s0.k
    public final /* synthetic */ String B(String str) {
        return p0.e.b(this, str);
    }

    @Override // m0.c1
    public final Size C() {
        int i10 = b1.f14766a;
        return (Size) p(c1.F, null);
    }

    @Override // m0.q2
    public final /* synthetic */ f2 F() {
        return p.j(this);
    }

    @Override // m0.c1
    public final Size G() {
        int i10 = b1.f14766a;
        return (Size) p(c1.E, null);
    }

    @Override // m0.q2
    public final /* synthetic */ s2 H() {
        return p.c(this);
    }

    @Override // m0.q2
    public final /* synthetic */ int I() {
        return p.m(this);
    }

    @Override // m0.q2
    public final /* synthetic */ int J(Size size) {
        return p.d(this, size);
    }

    @Override // m0.q2
    public final /* synthetic */ int K() {
        return p.i(this);
    }

    @Override // m0.q2
    public final Range L(Range range) {
        return (Range) p(q2.Q, range);
    }

    @Override // m0.q2
    public final p0 M() {
        return (p0) p(q2.L, null);
    }

    @Override // s0.k
    public final /* synthetic */ String N() {
        return p0.e.a(this);
    }

    @Override // m0.c1
    public final boolean O() {
        int i10 = b1.f14766a;
        return b(c1.A);
    }

    @Override // m0.c1
    public final int P() {
        int i10 = b1.f14766a;
        return ((Integer) U(c1.A)).intValue();
    }

    @Override // m0.r0
    public final /* synthetic */ Set Q(m0.f fVar) {
        return p.h(this, fVar);
    }

    @Override // m0.q2
    public final /* synthetic */ int R() {
        return p.g(this);
    }

    @Override // m0.r0
    public final /* synthetic */ Object S(m0.f fVar, q0 q0Var) {
        return p.u(this, fVar, q0Var);
    }

    @Override // m0.q2
    public final /* synthetic */ boolean T() {
        return p.p(this);
    }

    @Override // m0.r0
    public final /* synthetic */ Object U(m0.f fVar) {
        return p.s(this, fVar);
    }

    @Override // m0.r0
    public final /* synthetic */ void V(a2 a2Var) {
        p.b(this, a2Var);
    }

    @Override // m0.q2
    public final boolean W() {
        return b(q2.Q);
    }

    @Override // m0.c1
    public final Size X() {
        int i10 = b1.f14766a;
        return (Size) p(c1.G, null);
    }

    @Override // m0.q2
    public final /* synthetic */ boolean Y() {
        return p.q(this);
    }

    @Override // m0.c1
    public final /* synthetic */ int Z(int i10) {
        return b1.d(this, i10);
    }

    @Override // m0.c1
    public final /* synthetic */ int a0() {
        return b1.a(this);
    }

    @Override // m0.r0
    public final /* synthetic */ boolean b(m0.f fVar) {
        return p.a(this, fVar);
    }

    @Override // m0.a1
    public final /* synthetic */ a0 e() {
        return p.e(this);
    }

    @Override // m0.w1
    public final r0 f() {
        return this.f428e;
    }

    @Override // m0.r0
    public final /* synthetic */ q0 g(m0.f fVar) {
        return p.f(this, fVar);
    }

    @Override // m0.c1
    public final List h() {
        int i10 = b1.f14766a;
        return (List) p(c1.H, null);
    }

    @Override // m0.c1
    public final z0.b i() {
        int i10 = b1.f14766a;
        return (z0.b) U(c1.I);
    }

    @Override // m0.a1
    public final int k() {
        return ((Integer) U(a1.f14759x)).intValue();
    }

    @Override // m0.c1
    public final /* synthetic */ int m() {
        return b1.c(this);
    }

    @Override // m0.q2
    public final /* synthetic */ o2 n() {
        return p.l(this);
    }

    @Override // m0.a1
    public final boolean o() {
        return b(a1.f14761z);
    }

    @Override // m0.r0
    public final /* synthetic */ Object p(m0.f fVar, Object obj) {
        return p.t(this, fVar, obj);
    }

    @Override // m0.r0
    public final /* synthetic */ Set r() {
        return p.r(this);
    }

    @Override // m0.q2
    public final c2 s() {
        return (c2) U(q2.K);
    }

    @Override // m0.q2
    public final /* synthetic */ int t() {
        return p.k(this);
    }

    @Override // m0.q2
    public final r.p v() {
        return (r.p) p(q2.M, null);
    }

    @Override // m0.q2
    public final /* synthetic */ boolean w() {
        return p.n(this);
    }

    @Override // m0.c1
    public final /* synthetic */ ArrayList x() {
        return b1.b(this);
    }

    @Override // m0.c1
    public final z0.b y() {
        int i10 = b1.f14766a;
        return (z0.b) p(c1.I, null);
    }

    @Override // m0.q2
    public final c2 z() {
        return (c2) p(q2.K, null);
    }
}
