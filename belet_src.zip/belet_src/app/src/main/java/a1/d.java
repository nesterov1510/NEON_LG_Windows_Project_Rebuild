package a1;

import g0.b2;
import g6.y;
import java.util.Iterator;
import m0.a2;
import m0.c2;
import m0.q2;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class d implements a2 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ e f411a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ String f412b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ String f413c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ q2 f414d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ m0.m f415e;
    public final /* synthetic */ m0.m f;

    public /* synthetic */ d(e eVar, String str, String str2, q2 q2Var, m0.m mVar, m0.m mVar2) {
        this.f411a = eVar;
        this.f412b = str;
        this.f413c = str2;
        this.f414d = q2Var;
        this.f415e = mVar;
        this.f = mVar2;
    }

    @Override // m0.a2
    public final void a(c2 c2Var) {
        e eVar = this.f411a;
        if (eVar.d() == null) {
            return;
        }
        eVar.G();
        eVar.E(eVar.H(this.f412b, this.f413c, this.f414d, this.f415e, this.f));
        eVar.r();
        j jVar = eVar.f417r;
        jVar.getClass();
        y.b();
        Iterator it = jVar.f432e.iterator();
        while (it.hasNext()) {
            jVar.k((b2) it.next());
        }
    }
}
