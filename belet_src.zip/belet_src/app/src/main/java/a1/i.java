package a1;

import cb.u;
import g0.b2;
import g0.g1;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import m0.c2;
import m0.o;
import m0.p;
import m0.t;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class i extends o {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f430a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Object f431b;

    public /* synthetic */ i(int i10, Object obj) {
        this.f430a = i10;
        this.f431b = obj;
    }

    @Override // m0.o
    public void a(int i10) {
        switch (this.f430a) {
            case 3:
                ArrayList arrayList = (ArrayList) this.f431b;
                int size = arrayList.size();
                int i11 = 0;
                while (i11 < size) {
                    Object obj = arrayList.get(i11);
                    i11++;
                    ((o) obj).a(i10);
                }
                break;
        }
    }

    @Override // m0.o
    public void b(int i10, t tVar) {
        switch (this.f430a) {
            case 0:
                j jVar = (j) ((WeakReference) this.f431b).get();
                if (jVar != null) {
                    Iterator it = jVar.f432e.iterator();
                    while (it.hasNext()) {
                        c2 c2Var = ((b2) it.next()).f8318o;
                        Iterator it2 = c2Var.f14779g.f14904d.iterator();
                        while (it2.hasNext()) {
                            ((o) it2.next()).b(i10, new k(tVar, c2Var.f14779g.f14905e, -1L));
                        }
                    }
                    return;
                }
                return;
            case 1:
                g1 g1Var = (g1) this.f431b;
                synchronized (g1Var.f8342e) {
                    try {
                        if (g1Var.f8343r0) {
                            return;
                        }
                        g1Var.f8346v0.put(tVar.c(), new s0.b(tVar));
                        g1Var.m();
                        return;
                    } catch (Throwable th2) {
                        throw th2;
                    }
                }
            case 2:
            default:
                return;
            case 3:
                ArrayList arrayList = (ArrayList) this.f431b;
                int size = arrayList.size();
                int i11 = 0;
                while (i11 < size) {
                    Object obj = arrayList.get(i11);
                    i11++;
                    ((o) obj).b(i10, tVar);
                }
                return;
        }
    }

    @Override // m0.o
    public void c(int i10, u uVar) {
        switch (this.f430a) {
            case 3:
                ArrayList arrayList = (ArrayList) this.f431b;
                int size = arrayList.size();
                int i11 = 0;
                while (i11 < size) {
                    Object obj = arrayList.get(i11);
                    i11++;
                    ((o) obj).c(i10, uVar);
                }
                break;
        }
    }

    @Override // m0.o
    public void d(int i10, int i11) {
        switch (this.f430a) {
            case 2:
                tc.b.G().execute(new l0.d(this, i11));
                break;
            case 3:
                ArrayList arrayList = (ArrayList) this.f431b;
                int size = arrayList.size();
                int i12 = 0;
                while (i12 < size) {
                    Object obj = arrayList.get(i12);
                    i12++;
                    ((o) obj).d(i10, i11);
                }
                break;
        }
    }

    @Override // m0.o
    public void e(int i10) {
        switch (this.f430a) {
            case 2:
                tc.b.G().execute(new l0.d(this));
                break;
            case 3:
                ArrayList arrayList = (ArrayList) this.f431b;
                int size = arrayList.size();
                int i11 = 0;
                while (i11 < size) {
                    Object obj = arrayList.get(i11);
                    i11++;
                    ((o) obj).e(i10);
                }
                break;
        }
    }

    public i(j jVar) {
        this.f430a = 0;
        this.f431b = new WeakReference(jVar);
    }

    public i(List list) {
        this.f430a = 3;
        this.f431b = new ArrayList();
        Iterator it = list.iterator();
        while (it.hasNext()) {
            o oVar = (o) it.next();
            if (!(oVar instanceof p)) {
                ((ArrayList) this.f431b).add(oVar);
            }
        }
    }
}
