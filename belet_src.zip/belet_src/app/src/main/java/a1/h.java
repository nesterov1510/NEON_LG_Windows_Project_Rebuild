package a1;

import com.google.common.util.concurrent.ListenableFuture;
import g0.b2;
import g0.r;
import g6.y;
import java.util.ArrayList;
import java.util.Collection;
import m0.a0;
import m0.c0;
import m0.o1;
import m0.v;
import m0.x;
import m0.x0;
import m0.z;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class h implements c0 {
    public final l X;
    public final m Y;
    public final j Z;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final c0 f429e;

    public h(c0 c0Var, j jVar, a0.e eVar) {
        this.f429e = c0Var;
        this.Z = jVar;
        this.X = new l(c0Var.e());
        this.Y = new m(c0Var.r());
    }

    @Override // m0.c0
    public final o1 a() {
        return this.f429e.a();
    }

    @Override // m0.c0, g0.k
    public final r b() {
        return r();
    }

    @Override // m0.c0
    public final boolean c() {
        return ((x0) b()).k() == 0;
    }

    @Override // m0.c0
    public final z e() {
        return this.X;
    }

    @Override // m0.c0
    public final v f() {
        return x.f14959a;
    }

    @Override // g0.a2
    public final void h(b2 b2Var) {
        y.b();
        this.Z.h(b2Var);
    }

    @Override // g0.a2
    public final void i(b2 b2Var) {
        y.b();
        this.Z.i(b2Var);
    }

    @Override // m0.c0
    public final /* synthetic */ boolean j() {
        return false;
    }

    @Override // g0.a2
    public final void k(b2 b2Var) {
        y.b();
        this.Z.k(b2Var);
    }

    @Override // m0.c0
    public final void l(Collection collection) {
        throw new UnsupportedOperationException("Operation not supported by VirtualCamera.");
    }

    @Override // g0.a2
    public final void m(b2 b2Var) {
        y.b();
        this.Z.m(b2Var);
    }

    @Override // m0.c0
    public final void n(ArrayList arrayList) {
        throw new UnsupportedOperationException("Operation not supported by VirtualCamera.");
    }

    @Override // m0.c0
    public final boolean p() {
        return false;
    }

    @Override // m0.c0
    public final a0 r() {
        return this.Y;
    }

    @Override // m0.c0
    public final ListenableFuture release() {
        throw new UnsupportedOperationException("Operation not supported by VirtualCamera.");
    }

    @Override // m0.c0
    public final /* synthetic */ void o() {
    }

    @Override // m0.c0
    public final /* synthetic */ void d(v vVar) {
    }

    @Override // m0.c0
    public final /* synthetic */ void g(boolean z5) {
    }

    @Override // m0.c0
    public final /* synthetic */ void q(boolean z5) {
    }
}
