package ag;

import m7.f;
import vf.h;
import vf.n;
import zf.b;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f778a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f779b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f780c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f781d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f782e;
    public int f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public Object f783g;

    public a(b bVar, int i10, int i11, int i12) throws h {
        this.f783g = bVar;
        int i13 = bVar.X;
        this.f778a = i13;
        int i14 = bVar.f23531e;
        this.f779b = i14;
        int i15 = i10 / 2;
        int i16 = i11 - i15;
        this.f780c = i16;
        int i17 = i11 + i15;
        this.f781d = i17;
        int i18 = i12 - i15;
        this.f = i18;
        int i19 = i12 + i15;
        this.f782e = i19;
        if (i18 < 0 || i16 < 0 || i19 >= i13 || i17 >= i14) {
            throw h.Y;
        }
    }

    public boolean a(int i10, int i11, int i12, boolean z5) {
        b bVar = (b) this.f783g;
        if (z5) {
            while (i10 <= i11) {
                if (bVar.b(i10, i12)) {
                    return true;
                }
                i10++;
            }
            return false;
        }
        while (i10 <= i11) {
            if (bVar.b(i12, i10)) {
                return true;
            }
            i10++;
        }
        return false;
    }

    public n[] b() throws h {
        boolean z5;
        int i10 = this.f778a;
        int i11 = this.f779b;
        int i12 = this.f780c;
        int i13 = this.f781d;
        int i14 = this.f;
        int i15 = this.f782e;
        boolean z6 = false;
        boolean z9 = false;
        boolean z10 = false;
        boolean z11 = false;
        boolean z12 = false;
        boolean z13 = true;
        while (true) {
            if (!z13) {
                z5 = false;
                break;
            }
            boolean z14 = false;
            boolean zA = true;
            while (true) {
                if ((!zA && z6) || i13 >= i11) {
                    break;
                }
                zA = a(i14, i15, i13, false);
                if (zA) {
                    i13++;
                    z6 = true;
                    z14 = true;
                } else if (!z6) {
                    i13++;
                }
            }
            if (i13 < i11) {
                boolean zA2 = true;
                while (true) {
                    if ((!zA2 && z9) || i15 >= i10) {
                        break;
                    }
                    zA2 = a(i12, i13, i15, true);
                    if (zA2) {
                        i15++;
                        z9 = true;
                        z14 = true;
                    } else if (!z9) {
                        i15++;
                    }
                }
                if (i15 < i10) {
                    boolean zA3 = true;
                    while (true) {
                        if ((!zA3 && z10) || i12 < 0) {
                            break;
                        }
                        zA3 = a(i14, i15, i12, false);
                        if (zA3) {
                            i12--;
                            z10 = true;
                            z14 = true;
                        } else if (!z10) {
                            i12--;
                        }
                    }
                    if (i12 >= 0) {
                        z13 = z14;
                        boolean zA4 = true;
                        while (true) {
                            if ((!zA4 && z12) || i14 < 0) {
                                break;
                            }
                            zA4 = a(i12, i13, i14, true);
                            if (zA4) {
                                i14--;
                                z13 = true;
                                z12 = true;
                            } else if (!z12) {
                                i14--;
                            }
                        }
                        if (i14 >= 0) {
                            if (z13) {
                                z11 = true;
                            }
                        }
                    }
                }
            }
            z5 = true;
            break;
        }
        if (z5 || !z11) {
            throw h.Y;
        }
        int i16 = i13 - i12;
        n nVarC = null;
        n nVarC2 = null;
        for (int i17 = 1; nVarC2 == null && i17 < i16; i17++) {
            nVarC2 = c(i12, i15 - i17, i12 + i17, i15);
        }
        if (nVarC2 == null) {
            throw h.Y;
        }
        n nVarC3 = null;
        for (int i18 = 1; nVarC3 == null && i18 < i16; i18++) {
            nVarC3 = c(i12, i14 + i18, i12 + i18, i14);
        }
        if (nVarC3 == null) {
            throw h.Y;
        }
        n nVarC4 = null;
        for (int i19 = 1; nVarC4 == null && i19 < i16; i19++) {
            nVarC4 = c(i13, i14 + i19, i13 - i19, i14);
        }
        if (nVarC4 == null) {
            throw h.Y;
        }
        for (int i20 = 1; nVarC == null && i20 < i16; i20++) {
            nVarC = c(i13, i15 - i20, i13 - i20, i15);
        }
        if (nVarC == null) {
            throw h.Y;
        }
        float f = nVarC.f21234a;
        float f10 = nVarC.f21235b;
        float f11 = nVarC2.f21234a;
        float f12 = nVarC2.f21235b;
        float f13 = nVarC4.f21234a;
        float f14 = nVarC4.f21235b;
        float f15 = nVarC3.f21234a;
        float f16 = nVarC3.f21235b;
        return f < ((float) i11) / 2.0f ? new n[]{new n(f15 - 1.0f, f16 + 1.0f), new n(f11 + 1.0f, f12 + 1.0f), new n(f13 - 1.0f, f14 - 1.0f), new n(f + 1.0f, f10 - 1.0f)} : new n[]{new n(f15 + 1.0f, f16 + 1.0f), new n(f11 + 1.0f, f12 - 1.0f), new n(f13 - 1.0f, f14 + 1.0f), new n(f - 1.0f, f10 - 1.0f)};
    }

    public n c(float f, float f10, float f11, float f12) {
        float f13 = f - f11;
        float f14 = f10 - f12;
        int iU = f.u((float) Math.sqrt((f14 * f14) + (f13 * f13)));
        float f15 = iU;
        float f16 = (f11 - f) / f15;
        float f17 = (f12 - f10) / f15;
        for (int i10 = 0; i10 < iU; i10++) {
            float f18 = i10;
            int iU2 = f.u((f18 * f16) + f);
            int iU3 = f.u((f18 * f17) + f10);
            if (((b) this.f783g).b(iU2, iU3)) {
                return new n(iU2, iU3);
            }
        }
        return null;
    }

    public boolean d(int i10) {
        int i11;
        int i12;
        int i13;
        int i14;
        if ((i10 & (-2097152)) != -2097152 || (i11 = (i10 >>> 19) & 3) == 1 || (i12 = (i10 >>> 17) & 3) == 0 || (i13 = (i10 >>> 12) & 15) == 0 || i13 == 15 || (i14 = (i10 >>> 10) & 3) == 3) {
            return false;
        }
        this.f778a = i11;
        this.f783g = n4.b.f15663s[3 - i12];
        int i15 = n4.b.f15664t[i14];
        this.f780c = i15;
        if (i11 == 2) {
            this.f780c = i15 / 2;
        } else if (i11 == 0) {
            this.f780c = i15 / 4;
        }
        int i16 = (i10 >>> 9) & 1;
        int i17 = 1152;
        if (i12 != 1) {
            if (i12 != 2) {
                if (i12 != 3) {
                    throw new IllegalArgumentException();
                }
                i17 = 384;
            }
        } else if (i11 != 3) {
            i17 = 576;
        }
        this.f = i17;
        if (i12 == 3) {
            int i18 = i11 == 3 ? n4.b.f15665u[i13 - 1] : n4.b.f15666v[i13 - 1];
            this.f782e = i18;
            this.f779b = (((i18 * 12) / this.f780c) + i16) * 4;
        } else {
            if (i11 == 3) {
                int i19 = i12 == 2 ? n4.b.f15667w[i13 - 1] : n4.b.f15668x[i13 - 1];
                this.f782e = i19;
                this.f779b = ((i19 * 144) / this.f780c) + i16;
            } else {
                int i20 = n4.b.f15669y[i13 - 1];
                this.f782e = i20;
                this.f779b = (((i12 == 1 ? 72 : 144) * i20) / this.f780c) + i16;
            }
        }
        this.f781d = ((i10 >> 6) & 3) == 3 ? 1 : 2;
        return true;
    }

    public a(b bVar) {
        this(bVar, 10, bVar.f23531e / 2, bVar.X / 2);
    }
}
