package af;

import com.google.protobuf.m0;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public String f767a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public String f768b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public String f769c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public String f770d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public long f771e;
    public byte f;

    public final c a() {
        if (this.f == 1 && this.f767a != null && this.f768b != null && this.f769c != null && this.f770d != null) {
            return new c(this.f767a, this.f768b, this.f769c, this.f770d, this.f771e);
        }
        StringBuilder sb2 = new StringBuilder();
        if (this.f767a == null) {
            sb2.append(" rolloutId");
        }
        if (this.f768b == null) {
            sb2.append(" variantId");
        }
        if (this.f769c == null) {
            sb2.append(" parameterKey");
        }
        if (this.f770d == null) {
            sb2.append(" parameterValue");
        }
        if ((1 & this.f) == 0) {
            sb2.append(" templateVersion");
        }
        throw new IllegalStateException(m0.k(sb2, "Missing required properties:"));
    }
}
