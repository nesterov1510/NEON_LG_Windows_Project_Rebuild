package af;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class a implements td.d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final a f762a = new a();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final td.c f763b = td.c.a("rolloutId");

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final td.c f764c = td.c.a("variantId");

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final td.c f765d = td.c.a("parameterKey");

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final td.c f766e = td.c.a("parameterValue");
    public static final td.c f = td.c.a("templateVersion");

    @Override // td.a
    public final void a(Object obj, Object obj2) {
        td.e eVar = (td.e) obj2;
        c cVar = (c) ((e) obj);
        eVar.e(f763b, cVar.f772b);
        eVar.e(f764c, cVar.f773c);
        eVar.e(f765d, cVar.f774d);
        eVar.e(f766e, cVar.f775e);
        eVar.b(f, cVar.f);
    }
}
