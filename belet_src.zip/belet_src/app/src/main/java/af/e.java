package af;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public abstract class e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final /* synthetic */ int f777a = 0;

    static {
        vd.d dVar = new vd.d();
        a aVar = a.f762a;
        dVar.a(e.class, aVar);
        dVar.a(c.class, aVar);
    }
}
