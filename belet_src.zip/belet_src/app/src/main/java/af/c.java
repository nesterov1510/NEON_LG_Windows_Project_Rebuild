package af;

import a0.f;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class c extends e {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f772b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final String f773c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final String f774d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final String f775e;
    public final long f;

    public c(String str, String str2, String str3, String str4, long j10) {
        this.f772b = str;
        this.f773c = str2;
        this.f774d = str3;
        this.f775e = str4;
        this.f = j10;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof e) {
            c cVar = (c) ((e) obj);
            if (this.f772b.equals(cVar.f772b) && this.f773c.equals(cVar.f773c) && this.f774d.equals(cVar.f774d) && this.f775e.equals(cVar.f775e) && this.f == cVar.f) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        int iHashCode = (((((((this.f772b.hashCode() ^ 1000003) * 1000003) ^ this.f773c.hashCode()) * 1000003) ^ this.f774d.hashCode()) * 1000003) ^ this.f775e.hashCode()) * 1000003;
        long j10 = this.f;
        return iHashCode ^ ((int) (j10 ^ (j10 >>> 32)));
    }

    public final String toString() {
        StringBuilder sb2 = new StringBuilder("RolloutAssignment{rolloutId=");
        sb2.append(this.f772b);
        sb2.append(", variantId=");
        sb2.append(this.f773c);
        sb2.append(", parameterKey=");
        sb2.append(this.f774d);
        sb2.append(", parameterValue=");
        sb2.append(this.f775e);
        sb2.append(", templateVersion=");
        return f.q(sb2, this.f, "}");
    }
}
