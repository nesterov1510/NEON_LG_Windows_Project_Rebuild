package a8;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public abstract class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final m7.l f592a = m7.l.B("s", "a");

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final m7.l f593b = m7.l.B("s", "e", "o", "r");

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final m7.l f594c = m7.l.B("fc", "sc", "sw", "t", "o");
}
