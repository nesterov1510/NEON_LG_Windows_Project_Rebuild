package a8;

import android.graphics.PointF;
import java.util.ArrayList;
import java.util.Collections;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class y implements e0 {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final y f643e = new y();
    public static final m7.l X = m7.l.B("c", "v", "i", "o");

    @Override // a8.e0
    public final Object a(b8.a aVar, float f) {
        if (aVar.K() == 1) {
            aVar.a();
        }
        aVar.m();
        ArrayList arrayListC = null;
        ArrayList arrayListC2 = null;
        ArrayList arrayListC3 = null;
        boolean zD = false;
        while (aVar.C()) {
            int iP = aVar.P(X);
            if (iP == 0) {
                zD = aVar.D();
            } else if (iP == 1) {
                arrayListC = o.c(aVar, f);
            } else if (iP == 2) {
                arrayListC2 = o.c(aVar, f);
            } else if (iP != 3) {
                aVar.T();
                aVar.U();
            } else {
                arrayListC3 = o.c(aVar, f);
            }
        }
        aVar.v();
        if (aVar.K() == 2) {
            aVar.t();
        }
        if (arrayListC == null || arrayListC2 == null || arrayListC3 == null) {
            throw new IllegalArgumentException("Shape data was missing information.");
        }
        if (arrayListC.isEmpty()) {
            return new x7.k(new PointF(), false, Collections.EMPTY_LIST);
        }
        int size = arrayListC.size();
        PointF pointF = (PointF) arrayListC.get(0);
        ArrayList arrayList = new ArrayList(size);
        for (int i10 = 1; i10 < size; i10++) {
            PointF pointF2 = (PointF) arrayListC.get(i10);
            int i11 = i10 - 1;
            arrayList.add(new v7.a(c8.h.a((PointF) arrayListC.get(i11), (PointF) arrayListC3.get(i11)), c8.h.a(pointF2, (PointF) arrayListC2.get(i10)), pointF2));
        }
        if (zD) {
            PointF pointF3 = (PointF) arrayListC.get(0);
            int i12 = size - 1;
            arrayList.add(new v7.a(c8.h.a((PointF) arrayListC.get(i12), (PointF) arrayListC3.get(i12)), c8.h.a(pointF3, (PointF) arrayListC2.get(0)), pointF3));
        }
        return new x7.k(pointF, zD, arrayList);
    }
}
