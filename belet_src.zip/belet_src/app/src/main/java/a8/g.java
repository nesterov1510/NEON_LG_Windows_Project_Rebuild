package a8;

import android.graphics.Path;
import java.util.ArrayList;
import java.util.Collections;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public abstract class g {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final m7.l f608a = m7.l.B("ty", "d");

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code duplicated, block: B:124:0x01e0  */
    /* JADX WARN: Code duplicated, block: B:16:0x0041  */
    /* JADX WARN: Code duplicated, block: B:445:0x0774 A[LOOP:1: B:443:0x076e->B:445:0x0774, LOOP_END] */
    public static x7.b a(b8.b bVar, com.airbnb.lottie.k kVar) {
        String strH;
        x7.b aVar;
        x7.b lVar;
        x7.b mVar;
        x7.b eVar;
        int i10;
        int i11;
        bVar.m();
        int iF = 2;
        while (true) {
            if (!bVar.C()) {
                strH = null;
                break;
            }
            int iP = bVar.P(f608a);
            if (iP == 0) {
                strH = bVar.H();
                break;
            }
            if (iP != 1) {
                bVar.T();
                bVar.U();
            } else {
                iF = bVar.F();
            }
        }
        if (strH == null) {
            return null;
        }
        boolean zD = false;
        boolean zD2 = false;
        int i12 = 0;
        int i13 = 3;
        switch (strH) {
            case "el":
                m7.l lVar2 = e.f603a;
                boolean z5 = iF == 3;
                boolean zD3 = false;
                String strH2 = null;
                w7.e eVarB = null;
                w7.a aVarP = null;
                while (bVar.C()) {
                    int iP2 = bVar.P(e.f603a);
                    if (iP2 == 0) {
                        strH2 = bVar.H();
                    } else if (iP2 == 1) {
                        eVarB = a.b(bVar, kVar);
                    } else if (iP2 == 2) {
                        aVarP = d7.s.P(bVar, kVar);
                    } else if (iP2 == 3) {
                        zD3 = bVar.D();
                    } else if (iP2 != 4) {
                        bVar.T();
                        bVar.U();
                    } else {
                        z5 = bVar.F() == 3;
                    }
                }
                aVar = new x7.a(strH2, eVarB, aVarP, z5, zD3);
                lVar = aVar;
                while (bVar.C()) {
                    bVar.U();
                }
                bVar.v();
                return lVar;
            case "fl":
                m7.l lVar3 = z.f644a;
                int iF2 = 1;
                boolean zD4 = false;
                boolean zD5 = false;
                w7.a aVar2 = null;
                String strH3 = null;
                w7.a aVarL = null;
                while (bVar.C()) {
                    int iP3 = bVar.P(z.f644a);
                    if (iP3 == 0) {
                        strH3 = bVar.H();
                    } else if (iP3 == 1) {
                        aVarL = d7.s.L(bVar, kVar);
                    } else if (iP3 == 2) {
                        aVar2 = d7.s.O(bVar, kVar);
                    } else if (iP3 == 3) {
                        zD4 = bVar.D();
                    } else if (iP3 == 4) {
                        iF2 = bVar.F();
                    } else if (iP3 != 5) {
                        bVar.T();
                        bVar.U();
                    } else {
                        zD5 = bVar.D();
                    }
                }
                if (aVar2 == null) {
                    aVar2 = new w7.a(2, Collections.singletonList(new d8.a(100)));
                }
                lVar = new x7.l(strH3, zD4, iF2 == 1 ? Path.FillType.WINDING : Path.FillType.EVEN_ODD, aVarL, aVar2, zD5);
                while (bVar.C()) {
                    bVar.U();
                }
                bVar.v();
                return lVar;
            case "gf":
                m7.l lVar4 = m.f620a;
                Path.FillType fillType = Path.FillType.WINDING;
                int i14 = 0;
                boolean zD6 = false;
                w7.a aVar3 = null;
                String strH4 = null;
                w7.a aVarN = null;
                w7.a aVarP2 = null;
                w7.a aVarP3 = null;
                while (bVar.C()) {
                    switch (bVar.P(m.f620a)) {
                        case 0:
                            strH4 = bVar.H();
                            break;
                        case 1:
                            bVar.m();
                            int iF3 = -1;
                            while (bVar.C()) {
                                int iP4 = bVar.P(m.f621b);
                                if (iP4 == 0) {
                                    iF3 = bVar.F();
                                } else if (iP4 != 1) {
                                    bVar.T();
                                    bVar.U();
                                } else {
                                    aVarN = d7.s.N(bVar, kVar, iF3);
                                }
                            }
                            bVar.v();
                            break;
                        case 2:
                            aVar3 = d7.s.O(bVar, kVar);
                            break;
                        case 3:
                            i14 = bVar.F() != 1 ? 2 : 1;
                            break;
                        case 4:
                            aVarP2 = d7.s.P(bVar, kVar);
                            break;
                        case 5:
                            aVarP3 = d7.s.P(bVar, kVar);
                            break;
                        case 6:
                            fillType = bVar.F() == 1 ? Path.FillType.WINDING : Path.FillType.EVEN_ODD;
                            break;
                        case 7:
                            zD6 = bVar.D();
                            break;
                        default:
                            bVar.T();
                            bVar.U();
                            break;
                    }
                }
                if (aVar3 == null) {
                    aVar3 = new w7.a(2, Collections.singletonList(new d8.a(100)));
                }
                lVar = new x7.d(strH4, i14, fillType, aVarN, aVar3, aVarP2, aVarP3, zD6);
                while (bVar.C()) {
                    bVar.U();
                }
                bVar.v();
                return lVar;
            case "gr":
                m7.l lVar5 = a0.f591a;
                ArrayList arrayList = new ArrayList();
                String strH5 = null;
                while (bVar.C()) {
                    int iP5 = bVar.P(a0.f591a);
                    if (iP5 == 0) {
                        strH5 = bVar.H();
                    } else if (iP5 == 1) {
                        zD = bVar.D();
                    } else if (iP5 != 2) {
                        bVar.U();
                    } else {
                        bVar.a();
                        while (bVar.C()) {
                            x7.b bVarA = a(bVar, kVar);
                            if (bVarA != null) {
                                arrayList.add(bVarA);
                            }
                        }
                        bVar.t();
                    }
                }
                mVar = new x7.m(strH5, arrayList, zD);
                lVar = mVar;
                while (bVar.C()) {
                    bVar.U();
                }
                bVar.v();
                return lVar;
            case "gs":
                m7.l lVar6 = n.f622a;
                ArrayList arrayList2 = new ArrayList();
                int i15 = 0;
                int i16 = 0;
                int i17 = 0;
                boolean zD7 = false;
                w7.a aVar4 = null;
                String strH6 = null;
                w7.a aVarN2 = null;
                w7.a aVarP4 = null;
                w7.a aVarP5 = null;
                w7.b bVarM = null;
                w7.b bVar2 = null;
                float fE = 0.0f;
                while (bVar.C()) {
                    switch (bVar.P(n.f622a)) {
                        case 0:
                            strH6 = bVar.H();
                            break;
                        case 1:
                            bVar.m();
                            int iF4 = -1;
                            while (bVar.C()) {
                                int iP6 = bVar.P(n.f623b);
                                if (iP6 == 0) {
                                    iF4 = bVar.F();
                                } else if (iP6 != 1) {
                                    bVar.T();
                                    bVar.U();
                                } else {
                                    aVarN2 = d7.s.N(bVar, kVar, iF4);
                                }
                            }
                            bVar.v();
                            break;
                        case 2:
                            aVar4 = d7.s.O(bVar, kVar);
                            break;
                        case 3:
                            i15 = bVar.F() != 1 ? 2 : 1;
                            break;
                        case 4:
                            aVarP4 = d7.s.P(bVar, kVar);
                            break;
                        case 5:
                            aVarP5 = d7.s.P(bVar, kVar);
                            break;
                        case 6:
                            bVarM = d7.s.M(bVar, kVar, true);
                            break;
                        case 7:
                            i16 = g0.t.e(3)[bVar.F() - 1];
                            break;
                        case 8:
                            i17 = g0.t.e(3)[bVar.F() - 1];
                            break;
                        case 9:
                            fE = (float) bVar.E();
                            break;
                        case 10:
                            zD7 = bVar.D();
                            break;
                        case ue.r.NETWORK_CLIENT_ERROR_REASON_FIELD_NUMBER /* 11 */:
                            bVar.a();
                            while (bVar.C()) {
                                bVar.m();
                                String strH7 = null;
                                w7.b bVarM2 = null;
                                while (bVar.C()) {
                                    int iP7 = bVar.P(n.f624c);
                                    if (iP7 == 0) {
                                        strH7 = bVar.H();
                                    } else if (iP7 != 1) {
                                        bVar.T();
                                        bVar.U();
                                    } else {
                                        bVarM2 = d7.s.M(bVar, kVar, true);
                                    }
                                }
                                bVar.v();
                                if (strH7.equals("o")) {
                                    bVar2 = bVarM2;
                                } else if (strH7.equals("d") || strH7.equals("g")) {
                                    kVar.f4659o = true;
                                    arrayList2.add(bVarM2);
                                }
                            }
                            bVar.t();
                            if (arrayList2.size() == 1) {
                                arrayList2.add((w7.b) arrayList2.get(0));
                            }
                            break;
                        default:
                            bVar.T();
                            bVar.U();
                            break;
                    }
                }
                if (aVar4 == null) {
                    aVar4 = new w7.a(2, Collections.singletonList(new d8.a(100)));
                }
                eVar = new x7.e(strH6, i15, aVarN2, aVar4, aVarP4, aVarP5, bVarM, i16, i17, fE, arrayList2, bVar2, zD7);
                lVar = eVar;
                while (bVar.C()) {
                    bVar.U();
                }
                bVar.v();
                return lVar;
            case "mm":
                m7.l lVar7 = t.f638a;
                boolean zD8 = false;
                String strH8 = null;
                while (bVar.C()) {
                    int iP8 = bVar.P(t.f638a);
                    if (iP8 == 0) {
                        strH8 = bVar.H();
                    } else if (iP8 == 1) {
                        int iF5 = bVar.F();
                        if (iF5 != 1) {
                            if (iF5 == 2) {
                                i12 = 2;
                            } else if (iF5 == 3) {
                                i12 = 3;
                            } else if (iF5 == 4) {
                                i12 = 4;
                            } else if (iF5 == 5) {
                                i12 = 5;
                            }
                        }
                        i12 = 1;
                    } else if (iP8 != 2) {
                        bVar.T();
                        bVar.U();
                    } else {
                        zD8 = bVar.D();
                    }
                }
                x7.g gVar = new x7.g(strH8, zD8, i12);
                kVar.a("Animation contains merge paths. Merge paths are only supported on KitKat+ and must be manually enabled by calling enableMergePathsForKitKatAndAbove().");
                lVar = gVar;
                while (bVar.C()) {
                    bVar.U();
                }
                bVar.v();
                return lVar;
            case "rc":
                m7.l lVar8 = v.f640a;
                boolean zD9 = false;
                String strH9 = null;
                w7.e eVarB2 = null;
                w7.a aVarP6 = null;
                w7.b bVarM3 = null;
                while (bVar.C()) {
                    int iP9 = bVar.P(v.f640a);
                    if (iP9 == 0) {
                        strH9 = bVar.H();
                    } else if (iP9 == 1) {
                        eVarB2 = a.b(bVar, kVar);
                    } else if (iP9 == 2) {
                        aVarP6 = d7.s.P(bVar, kVar);
                    } else if (iP9 == 3) {
                        bVarM3 = d7.s.M(bVar, kVar, true);
                    } else if (iP9 != 4) {
                        bVar.U();
                    } else {
                        zD9 = bVar.D();
                    }
                }
                eVar = new x7.i(strH9, eVarB2, aVarP6, bVarM3, zD9);
                lVar = eVar;
                while (bVar.C()) {
                    bVar.U();
                }
                bVar.v();
                return lVar;
            case "rd":
                m7.l lVar9 = x.f642a;
                String strH10 = null;
                w7.b bVarM4 = null;
                while (bVar.C()) {
                    int iP10 = bVar.P(x.f642a);
                    if (iP10 == 0) {
                        strH10 = bVar.H();
                    } else if (iP10 == 1) {
                        bVarM4 = d7.s.M(bVar, kVar, true);
                    } else if (iP10 != 2) {
                        bVar.U();
                    } else {
                        zD2 = bVar.D();
                    }
                }
                lVar = zD2 ? null : new x7.j(strH10, bVarM4);
                while (bVar.C()) {
                    bVar.U();
                }
                bVar.v();
                return lVar;
            case "rp":
                m7.l lVar10 = w.f641a;
                boolean zD10 = false;
                String strH11 = null;
                w7.b bVarM5 = null;
                w7.b bVarM6 = null;
                w7.d dVarC = null;
                while (bVar.C()) {
                    int iP11 = bVar.P(w.f641a);
                    if (iP11 == 0) {
                        strH11 = bVar.H();
                    } else if (iP11 == 1) {
                        bVarM5 = d7.s.M(bVar, kVar, false);
                    } else if (iP11 == 2) {
                        bVarM6 = d7.s.M(bVar, kVar, false);
                    } else if (iP11 == 3) {
                        dVarC = c.c(bVar, kVar);
                    } else if (iP11 != 4) {
                        bVar.U();
                    } else {
                        zD10 = bVar.D();
                    }
                }
                eVar = new x7.i(strH11, bVarM5, bVarM6, dVarC, zD10);
                lVar = eVar;
                while (bVar.C()) {
                    bVar.U();
                }
                bVar.v();
                return lVar;
            case "sh":
                m7.l lVar11 = b0.f595a;
                int iF6 = 0;
                boolean zD11 = false;
                w7.a aVar5 = null;
                String strH12 = null;
                while (bVar.C()) {
                    int iP12 = bVar.P(b0.f595a);
                    if (iP12 == 0) {
                        strH12 = bVar.H();
                    } else if (iP12 == 1) {
                        iF6 = bVar.F();
                    } else if (iP12 == 2) {
                        aVar5 = new w7.a(5, q.a(bVar, kVar, c8.k.c(), y.f643e, false));
                    } else if (iP12 != 3) {
                        bVar.U();
                    } else {
                        zD11 = bVar.D();
                    }
                }
                mVar = new x7.n(strH12, iF6, aVar5, zD11);
                lVar = mVar;
                while (bVar.C()) {
                    bVar.U();
                }
                bVar.v();
                return lVar;
            case "sr":
                m7.l lVar12 = u.f639a;
                boolean z6 = iF == 3;
                int i18 = 0;
                boolean zD12 = false;
                String strH13 = null;
                w7.b bVarM7 = null;
                w7.e eVarB3 = null;
                w7.b bVarM8 = null;
                w7.b bVarM9 = null;
                w7.b bVarM10 = null;
                w7.b bVarM11 = null;
                w7.b bVarM12 = null;
                while (bVar.C()) {
                    switch (bVar.P(u.f639a)) {
                        case 0:
                            strH13 = bVar.H();
                            break;
                        case 1:
                            int iF7 = bVar.F();
                            int[] iArrE = g0.t.e(2);
                            int length = iArrE.length;
                            int i19 = 0;
                            while (true) {
                                if (i19 >= length) {
                                    i18 = 0;
                                }
                                int i20 = iArrE[i19];
                                if (i20 == 1) {
                                    i10 = 1;
                                } else {
                                    if (i20 != 2) {
                                        throw null;
                                    }
                                    i10 = 2;
                                }
                                if (i10 == iF7) {
                                    i18 = i20;
                                }
                                i19++;
                                break;
                                break;
                            }
                            break;
                        case 2:
                            bVarM7 = d7.s.M(bVar, kVar, false);
                            break;
                        case 3:
                            eVarB3 = a.b(bVar, kVar);
                            break;
                        case 4:
                            bVarM8 = d7.s.M(bVar, kVar, false);
                            break;
                        case 5:
                            bVarM10 = d7.s.M(bVar, kVar, true);
                            break;
                        case 6:
                            bVarM12 = d7.s.M(bVar, kVar, false);
                            break;
                        case 7:
                            bVarM9 = d7.s.M(bVar, kVar, true);
                            break;
                        case 8:
                            bVarM11 = d7.s.M(bVar, kVar, false);
                            break;
                        case 9:
                            zD12 = bVar.D();
                            break;
                        case 10:
                            z6 = bVar.F() == 3;
                            break;
                        default:
                            bVar.T();
                            bVar.U();
                            break;
                    }
                }
                eVar = new x7.h(strH13, i18, bVarM7, eVarB3, bVarM8, bVarM9, bVarM10, bVarM11, bVarM12, zD12, z6);
                lVar = eVar;
                while (bVar.C()) {
                    bVar.U();
                }
                bVar.v();
                return lVar;
            case "st":
                m7.l lVar13 = c0.f598a;
                ArrayList arrayList3 = new ArrayList();
                int i21 = 0;
                int i22 = 0;
                boolean zD13 = false;
                w7.a aVar6 = null;
                String strH14 = null;
                w7.b bVar3 = null;
                w7.a aVarL2 = null;
                w7.b bVarM13 = null;
                float fE2 = 0.0f;
                while (bVar.C()) {
                    switch (bVar.P(c0.f598a)) {
                        case 0:
                            strH14 = bVar.H();
                            continue;
                        case 1:
                            aVarL2 = d7.s.L(bVar, kVar);
                            continue;
                        case 2:
                            bVarM13 = d7.s.M(bVar, kVar, true);
                            continue;
                        case 3:
                            aVar6 = d7.s.O(bVar, kVar);
                            continue;
                        case 4:
                            i21 = g0.t.e(i13)[bVar.F() - 1];
                            continue;
                        case 5:
                            i22 = g0.t.e(i13)[bVar.F() - 1];
                            continue;
                        case 6:
                            i11 = i13;
                            fE2 = (float) bVar.E();
                            break;
                        case 7:
                            zD13 = bVar.D();
                            continue;
                        case 8:
                            bVar.a();
                            while (bVar.C()) {
                                bVar.m();
                                w7.b bVarM14 = null;
                                String strH15 = null;
                                while (bVar.C()) {
                                    int i23 = i13;
                                    int iP13 = bVar.P(c0.f599b);
                                    if (iP13 == 0) {
                                        strH15 = bVar.H();
                                    } else if (iP13 != 1) {
                                        bVar.T();
                                        bVar.U();
                                    } else {
                                        bVarM14 = d7.s.M(bVar, kVar, true);
                                    }
                                    i13 = i23;
                                }
                                int i24 = i13;
                                bVar.v();
                                strH15.getClass();
                                switch (strH15) {
                                    case "d":
                                    case "g":
                                        kVar.f4659o = true;
                                        arrayList3.add(bVarM14);
                                        break;
                                    case "o":
                                        bVar3 = bVarM14;
                                        break;
                                }
                                i13 = i24;
                            }
                            i11 = i13;
                            bVar.t();
                            if (arrayList3.size() == 1) {
                                arrayList3.add((w7.b) arrayList3.get(0));
                            }
                            break;
                        default:
                            bVar.U();
                            continue;
                    }
                    i13 = i11;
                }
                if (aVar6 == null) {
                    aVar6 = new w7.a(2, Collections.singletonList(new d8.a(100)));
                }
                lVar = new x7.o(strH14, bVar3, arrayList3, aVarL2, aVar6, bVarM13, i21 == 0 ? 1 : i21, i22 == 0 ? 1 : i22, fE2, zD13);
                while (bVar.C()) {
                    bVar.U();
                }
                bVar.v();
                return lVar;
            case "tm":
                m7.l lVar14 = d0.f602a;
                int i25 = 0;
                boolean zD14 = false;
                String strH16 = null;
                w7.b bVarM15 = null;
                w7.b bVarM16 = null;
                w7.b bVarM17 = null;
                while (bVar.C()) {
                    int iP14 = bVar.P(d0.f602a);
                    if (iP14 == 0) {
                        bVarM15 = d7.s.M(bVar, kVar, false);
                    } else if (iP14 == 1) {
                        bVarM16 = d7.s.M(bVar, kVar, false);
                    } else if (iP14 == 2) {
                        bVarM17 = d7.s.M(bVar, kVar, false);
                    } else if (iP14 == 3) {
                        strH16 = bVar.H();
                    } else if (iP14 == 4) {
                        int iF8 = bVar.F();
                        if (iF8 == 1) {
                            i25 = 1;
                        } else {
                            if (iF8 != 2) {
                                throw new IllegalArgumentException(kotlin.jvm.internal.p.z(iF8, "Unknown trim path type "));
                            }
                            i25 = 2;
                        }
                    } else if (iP14 != 5) {
                        bVar.U();
                    } else {
                        zD14 = bVar.D();
                    }
                }
                aVar = new x7.p(strH16, i25, bVarM15, bVarM16, bVarM17, zD14);
                lVar = aVar;
                while (bVar.C()) {
                    bVar.U();
                }
                bVar.v();
                return lVar;
            case "tr":
                lVar = c.c(bVar, kVar);
                while (bVar.C()) {
                    bVar.U();
                }
                bVar.v();
                return lVar;
            default:
                c8.d.b("Unknown shape type ".concat(strH));
                while (bVar.C()) {
                    bVar.U();
                }
                bVar.v();
                return lVar;
        }
    }
}
