package a8;

import android.graphics.Rect;
import io.ktor.utils.io.n0;
import java.io.EOFException;
import java.util.ArrayList;
import java.util.HashMap;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public abstract class s {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final m7.l f634a = m7.l.B("w", "h", "ip", "op", "fr", "v", "layers", "assets", "fonts", "chars", "markers");

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final m7.l f635b = m7.l.B("id", "layers", "w", "h", "p", "u");

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final m7.l f636c = m7.l.B("list");

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final m7.l f637d = m7.l.B("cm", "tm", "dr");

    public static com.airbnb.lottie.k a(b8.b bVar) throws n0, EOFException {
        float f;
        float f10;
        float f11;
        float f12;
        float fC = c8.k.c();
        j1.g gVar = new j1.g();
        ArrayList arrayList = new ArrayList();
        HashMap map = new HashMap();
        HashMap map2 = new HashMap();
        HashMap map3 = new HashMap();
        ArrayList arrayList2 = new ArrayList();
        j1.j jVar = new j1.j();
        com.airbnb.lottie.k kVar = new com.airbnb.lottie.k();
        bVar.m();
        float fE = 0.0f;
        int iE = 0;
        int iE2 = 0;
        float fE2 = 0.0f;
        float fE3 = 0.0f;
        while (bVar.C()) {
            fC = fC;
            switch (bVar.P(f634a)) {
                case 0:
                    iE = (int) bVar.E();
                    fE = fE;
                    break;
                case 1:
                    iE2 = (int) bVar.E();
                    fE = fE;
                    break;
                case 2:
                    fE2 = (float) bVar.E();
                    fE = fE;
                    break;
                case 3:
                    fE3 = ((float) bVar.E()) - 0.01f;
                    fE = fE;
                    break;
                case 4:
                    fE = (float) bVar.E();
                    fC = fC;
                    break;
                case 5:
                    fE = fE;
                    f = fE2;
                    f10 = fE3;
                    String[] strArrSplit = bVar.H().split("\\.");
                    int i10 = Integer.parseInt(strArrSplit[0]);
                    int i11 = Integer.parseInt(strArrSplit[1]);
                    int i12 = Integer.parseInt(strArrSplit[2]);
                    if (i10 < 4 || (i10 <= 4 && (i11 < 4 || (i11 <= 4 && i12 < 0)))) {
                        kVar.a("Lottie only supports bodymovin >= 4.4.0");
                    }
                    fE2 = f;
                    fE3 = f10;
                    fE = fE;
                    break;
                case 6:
                    fE = fE;
                    f = fE2;
                    f10 = fE3;
                    bVar.a();
                    int i13 = 0;
                    while (bVar.C()) {
                        y7.d dVarA = r.a(bVar, kVar);
                        if (dVarA.f22818e == 3) {
                            i13++;
                        }
                        arrayList.add(dVarA);
                        gVar.h(dVarA.f22817d, dVarA);
                        if (i13 > 4) {
                            c8.d.b("You have " + i13 + " images. Lottie should primarily be used with shapes. If you are using Adobe Illustrator, convert the Illustrator layers to shape layers.");
                        }
                    }
                    bVar.t();
                    fE2 = f;
                    fE3 = f10;
                    fE = fE;
                    break;
                case 7:
                    fE = fE;
                    f = fE2;
                    f10 = fE3;
                    bVar.a();
                    while (bVar.C()) {
                        ArrayList arrayList3 = new ArrayList();
                        j1.g gVar2 = new j1.g();
                        bVar.m();
                        String strH = null;
                        String strH2 = null;
                        String strH3 = null;
                        int iF = 0;
                        int iF2 = 0;
                        while (bVar.C()) {
                            int iP = bVar.P(f635b);
                            if (iP == 0) {
                                strH = bVar.H();
                            } else if (iP == 1) {
                                bVar.a();
                                while (bVar.C()) {
                                    y7.d dVarA2 = r.a(bVar, kVar);
                                    gVar2.h(dVarA2.f22817d, dVarA2);
                                    arrayList3.add(dVarA2);
                                }
                                bVar.t();
                            } else if (iP == 2) {
                                iF = bVar.F();
                            } else if (iP == 3) {
                                iF2 = bVar.F();
                            } else if (iP == 4) {
                                strH2 = bVar.H();
                            } else if (iP != 5) {
                                bVar.T();
                                bVar.U();
                            } else {
                                strH3 = bVar.H();
                            }
                        }
                        bVar.v();
                        if (strH2 != null) {
                            map2.put(strH, new com.airbnb.lottie.a0(iF, iF2, strH, strH2, strH3));
                        } else {
                            map.put(strH, arrayList3);
                        }
                    }
                    bVar.t();
                    fE2 = f;
                    fE3 = f10;
                    fE = fE;
                    break;
                case 8:
                    fE = fE;
                    f = fE2;
                    float f13 = fE3;
                    bVar.m();
                    while (bVar.C()) {
                        if (bVar.P(f636c) != 0) {
                            bVar.T();
                            bVar.U();
                        } else {
                            bVar.a();
                            while (bVar.C()) {
                                m7.l lVar = k.f618a;
                                bVar.m();
                                String strH4 = null;
                                String strH5 = null;
                                String strH6 = null;
                                while (bVar.C()) {
                                    int iP2 = bVar.P(k.f618a);
                                    if (iP2 != 0) {
                                        float f14 = f13;
                                        if (iP2 == 1) {
                                            strH5 = bVar.H();
                                        } else if (iP2 == 2) {
                                            strH6 = bVar.H();
                                        } else if (iP2 != 3) {
                                            bVar.T();
                                            bVar.U();
                                        } else {
                                            bVar.E();
                                        }
                                        f13 = f14;
                                    } else {
                                        strH4 = bVar.H();
                                    }
                                }
                                bVar.v();
                                map3.put(strH5, new v7.c(strH4, strH5, strH6));
                                f13 = f13;
                            }
                            bVar.t();
                        }
                    }
                    f10 = f13;
                    bVar.v();
                    fE2 = f;
                    fE3 = f10;
                    fE = fE;
                    break;
                case 9:
                    fE = fE;
                    f = fE2;
                    f11 = fE3;
                    bVar.a();
                    while (bVar.C()) {
                        m7.l lVar2 = j.f616a;
                        ArrayList arrayList4 = new ArrayList();
                        bVar.m();
                        double dE = 0.0d;
                        String strH7 = null;
                        String strH8 = null;
                        char cCharAt = 0;
                        while (bVar.C()) {
                            int iP3 = bVar.P(j.f616a);
                            if (iP3 == 0) {
                                cCharAt = bVar.H().charAt(0);
                            } else if (iP3 == 1) {
                                bVar.E();
                            } else if (iP3 == 2) {
                                dE = bVar.E();
                            } else if (iP3 == 3) {
                                strH7 = bVar.H();
                            } else if (iP3 == 4) {
                                strH8 = bVar.H();
                            } else if (iP3 != 5) {
                                bVar.T();
                                bVar.U();
                            } else {
                                bVar.m();
                                while (bVar.C()) {
                                    if (bVar.P(j.f617b) != 0) {
                                        bVar.T();
                                        bVar.U();
                                    } else {
                                        bVar.a();
                                        while (bVar.C()) {
                                            arrayList4.add((x7.m) g.a(bVar, kVar));
                                        }
                                        bVar.t();
                                    }
                                }
                                bVar.v();
                            }
                        }
                        bVar.v();
                        v7.d dVar = new v7.d(arrayList4, cCharAt, dE, strH7, strH8);
                        jVar.d(dVar.hashCode(), dVar);
                    }
                    bVar.t();
                    f10 = f11;
                    fE2 = f;
                    fE3 = f10;
                    fE = fE;
                    break;
                case 10:
                    bVar.a();
                    while (bVar.C()) {
                        bVar.m();
                        String strH9 = null;
                        float fE4 = 0.0f;
                        float fE5 = 0.0f;
                        while (bVar.C()) {
                            int iP4 = bVar.P(f637d);
                            if (iP4 != 0) {
                                f12 = fE;
                                if (iP4 == 1) {
                                    fE3 = fE3;
                                    fE4 = (float) bVar.E();
                                } else if (iP4 != 2) {
                                    bVar.T();
                                    bVar.U();
                                } else {
                                    fE3 = fE3;
                                    fE5 = (float) bVar.E();
                                }
                                fE = f12;
                                fE2 = fE2;
                            } else {
                                f12 = fE;
                                strH9 = bVar.H();
                            }
                            fE = f12;
                        }
                        bVar.v();
                        arrayList2.add(new v7.h(strH9, fE4, fE5));
                        fE3 = fE3;
                        fE2 = fE2;
                        fE = fE;
                    }
                    fE = fE;
                    f = fE2;
                    f11 = fE3;
                    bVar.t();
                    f10 = f11;
                    fE2 = f;
                    fE3 = f10;
                    fE = fE;
                    break;
                default:
                    bVar.T();
                    bVar.U();
                    fE = fE;
                    f = fE2;
                    f10 = fE3;
                    fE2 = f;
                    fE3 = f10;
                    fE = fE;
                    break;
            }
        }
        float f15 = fC;
        float f16 = fE;
        Rect rect = new Rect(0, 0, (int) (iE * f15), (int) (iE2 * f15));
        float fC2 = c8.k.c();
        kVar.f4655k = rect;
        kVar.f4656l = fE2;
        kVar.f4657m = fE3;
        kVar.f4658n = f16;
        kVar.f4654j = arrayList;
        kVar.f4653i = gVar;
        kVar.f4649c = map;
        kVar.f4650d = map2;
        kVar.f4651e = fC2;
        kVar.h = jVar;
        kVar.f = map3;
        kVar.f4652g = arrayList2;
        return kVar;
    }
}
