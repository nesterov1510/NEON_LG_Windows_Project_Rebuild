package a8;

import android.graphics.Matrix;
import android.graphics.PointF;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;
import android.view.animation.PathInterpolator;
import java.lang.ref.WeakReference;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public abstract class p {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static j1.j f627b;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final LinearInterpolator f626a = new LinearInterpolator();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final m7.l f628c = m7.l.B("t", "s", "e", "o", "i", "h", "to", "ti");

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final m7.l f629d = m7.l.B("x", "y");

    public static Interpolator a(PointF pointF, PointF pointF2) {
        WeakReference weakReference;
        Interpolator pathInterpolator;
        pointF.x = c8.h.b(pointF.x, -1.0f, 1.0f);
        pointF.y = c8.h.b(pointF.y, -100.0f, 100.0f);
        pointF2.x = c8.h.b(pointF2.x, -1.0f, 1.0f);
        float fB = c8.h.b(pointF2.y, -100.0f, 100.0f);
        pointF2.y = fB;
        float f = pointF.x;
        float f10 = pointF.y;
        float f11 = pointF2.x;
        Matrix matrix = c8.k.f3991a;
        int i10 = f != 0.0f ? (int) (527 * f) : 17;
        if (f10 != 0.0f) {
            i10 = (int) (i10 * 31 * f10);
        }
        if (f11 != 0.0f) {
            i10 = (int) (i10 * 31 * f11);
        }
        if (fB != 0.0f) {
            i10 = (int) (i10 * 31 * fB);
        }
        synchronized (p.class) {
            if (f627b == null) {
                f627b = new j1.j();
            }
            weakReference = (WeakReference) f627b.c(i10);
        }
        Interpolator interpolator = weakReference != null ? (Interpolator) weakReference.get() : null;
        if (weakReference != null && interpolator != null) {
            return interpolator;
        }
        try {
            pathInterpolator = new PathInterpolator(pointF.x, pointF.y, pointF2.x, pointF2.y);
        } catch (IllegalArgumentException e3) {
            pathInterpolator = "The Path cannot loop back on itself.".equals(e3.getMessage()) ? new PathInterpolator(Math.min(pointF.x, 1.0f), pointF.y, Math.max(pointF2.x, 0.0f), pointF2.y) : new LinearInterpolator();
        }
        try {
            c(i10, new WeakReference(pathInterpolator));
        } catch (ArrayIndexOutOfBoundsException unused) {
        }
        return pathInterpolator;
    }

    /* JADX WARN: Code duplicated, block: B:99:0x01f6  */
    /* JADX WARN: Failed to find 'out' block for switch in B:9:0x002d. Please report as an issue. */
    public static d8.a b(b8.a aVar, com.airbnb.lottie.k kVar, float f, e0 e0Var, boolean z5, boolean z6) {
        Object obj;
        Interpolator interpolatorA;
        Interpolator interpolatorA2;
        Interpolator interpolatorA3;
        Object obj2;
        d8.a aVar2;
        m7.l lVar;
        m7.l lVar2;
        PointF pointF;
        m7.l lVar3 = f628c;
        LinearInterpolator linearInterpolator = f626a;
        if (!z5 || !z6) {
            m7.l lVar4 = lVar3;
            if (!z5) {
                return new d8.a(e0Var.a(aVar, f));
            }
            aVar.m();
            PointF pointFB = null;
            PointF pointFB2 = null;
            PointF pointFB3 = null;
            PointF pointFB4 = null;
            boolean z9 = false;
            Object objA = null;
            float fE = 0.0f;
            Object objA2 = null;
            while (aVar.C()) {
                lVar4 = lVar4;
                switch (aVar.P(lVar4)) {
                    case 0:
                        fE = (float) aVar.E();
                        continue;
                    case 1:
                        objA = e0Var.a(aVar, f);
                        break;
                    case 2:
                        objA2 = e0Var.a(aVar, f);
                        break;
                    case 3:
                        pointFB4 = o.b(aVar, 1.0f);
                        break;
                    case 4:
                        pointFB = o.b(aVar, 1.0f);
                        break;
                    case 5:
                        z9 = aVar.F() == 1;
                        break;
                    case 6:
                        pointFB2 = o.b(aVar, f);
                        break;
                    case 7:
                        pointFB3 = o.b(aVar, f);
                        break;
                    default:
                        aVar.U();
                        break;
                }
            }
            aVar.v();
            if (!z9) {
                if (pointFB4 == null || pointFB == null) {
                    obj = objA2;
                } else {
                    interpolatorA = a(pointFB4, pointFB);
                    obj = objA2;
                }
                d8.a aVar3 = new d8.a(kVar, objA, obj, interpolatorA, fE, (Float) null);
                aVar3.f6724o = pointFB2;
                aVar3.f6725p = pointFB3;
                return aVar3;
            }
            obj = objA;
            interpolatorA = linearInterpolator;
            d8.a aVar4 = new d8.a(kVar, objA, obj, interpolatorA, fE, (Float) null);
            aVar4.f6724o = pointFB2;
            aVar4.f6725p = pointFB3;
            return aVar4;
        }
        aVar.m();
        PointF pointF2 = null;
        PointF pointFB5 = null;
        PointF pointFB6 = null;
        boolean z10 = false;
        PointF pointFB7 = null;
        PointF pointFB8 = null;
        PointF pointF3 = null;
        Object objA3 = null;
        PointF pointF4 = null;
        PointF pointF5 = null;
        float fE2 = 0.0f;
        Object objA4 = null;
        while (aVar.C()) {
            int iP = aVar.P(lVar3);
            m7.l lVar5 = f629d;
            linearInterpolator = linearInterpolator;
            switch (iP) {
                case 0:
                    lVar = lVar3;
                    fE2 = (float) aVar.E();
                    lVar3 = lVar;
                    break;
                case 1:
                    lVar = lVar3;
                    objA3 = e0Var.a(aVar, f);
                    lVar3 = lVar;
                    break;
                case 2:
                    lVar = lVar3;
                    objA4 = e0Var.a(aVar, f);
                    lVar3 = lVar;
                    break;
                case 3:
                    lVar = lVar3;
                    boolean z11 = z10;
                    Object obj3 = objA3;
                    PointF pointF6 = pointF4;
                    if (aVar.K() == 3) {
                        aVar.m();
                        float fE3 = 0.0f;
                        float fE4 = 0.0f;
                        float fE5 = 0.0f;
                        float fE6 = 0.0f;
                        while (aVar.C()) {
                            int iP2 = aVar.P(lVar5);
                            if (iP2 != 0) {
                                if (iP2 != 1) {
                                    aVar.U();
                                } else if (aVar.K() == 7) {
                                    fE6 = (float) aVar.E();
                                    fE4 = fE6;
                                } else {
                                    aVar.a();
                                    fE4 = (float) aVar.E();
                                    fE6 = aVar.K() == 7 ? (float) aVar.E() : fE4;
                                    aVar.t();
                                }
                            } else if (aVar.K() == 7) {
                                fE5 = (float) aVar.E();
                                fE3 = fE5;
                            } else {
                                aVar.a();
                                fE3 = (float) aVar.E();
                                fE5 = aVar.K() == 7 ? (float) aVar.E() : fE3;
                                aVar.t();
                            }
                        }
                        PointF pointF7 = new PointF(fE3, fE4);
                        pointF4 = new PointF(fE5, fE6);
                        aVar.v();
                        pointF3 = pointF7;
                    } else {
                        pointFB7 = o.b(aVar, f);
                        pointF4 = pointF6;
                    }
                    z10 = z11;
                    objA3 = obj3;
                    lVar3 = lVar;
                    break;
                case 4:
                    boolean z12 = z10;
                    if (aVar.K() == 3) {
                        aVar.m();
                        float fE7 = 0.0f;
                        float fE8 = 0.0f;
                        float fE9 = 0.0f;
                        float fE10 = 0.0f;
                        while (aVar.C()) {
                            Object obj4 = objA3;
                            int iP3 = aVar.P(lVar5);
                            if (iP3 != 0) {
                                lVar2 = lVar3;
                                if (iP3 != 1) {
                                    aVar.U();
                                } else if (aVar.K() == 7) {
                                    fE10 = (float) aVar.E();
                                    pointF4 = pointF4;
                                    fE8 = fE10;
                                } else {
                                    pointF = pointF4;
                                    aVar.a();
                                    fE8 = (float) aVar.E();
                                    fE10 = aVar.K() == 7 ? (float) aVar.E() : fE8;
                                    aVar.t();
                                    pointF4 = pointF;
                                }
                            } else {
                                lVar2 = lVar3;
                                pointF = pointF4;
                                if (aVar.K() == 7) {
                                    fE9 = (float) aVar.E();
                                    pointF4 = pointF;
                                    fE7 = fE9;
                                } else {
                                    aVar.a();
                                    fE7 = (float) aVar.E();
                                    fE9 = aVar.K() == 7 ? (float) aVar.E() : fE7;
                                    aVar.t();
                                    pointF4 = pointF;
                                }
                            }
                            objA3 = obj4;
                            lVar3 = lVar2;
                        }
                        lVar = lVar3;
                        PointF pointF8 = new PointF(fE7, fE8);
                        pointF2 = new PointF(fE9, fE10);
                        aVar.v();
                        pointF5 = pointF8;
                    } else {
                        lVar = lVar3;
                        pointFB8 = o.b(aVar, f);
                    }
                    z10 = z12;
                    lVar3 = lVar;
                    break;
                case 5:
                    z10 = aVar.F() == 1;
                    linearInterpolator = linearInterpolator;
                    break;
                case 6:
                    pointFB5 = o.b(aVar, f);
                    linearInterpolator = linearInterpolator;
                    break;
                case 7:
                    pointFB6 = o.b(aVar, f);
                    linearInterpolator = linearInterpolator;
                    break;
                default:
                    aVar.U();
                    linearInterpolator = linearInterpolator;
                    break;
            }
        }
        Interpolator interpolatorA4 = linearInterpolator;
        boolean z13 = z10;
        Object obj5 = objA3;
        PointF pointF9 = pointF4;
        aVar.v();
        if (z13) {
            obj2 = obj5;
        } else {
            if (pointFB7 == null || pointFB8 == null) {
                if (pointF3 != null && pointF9 != null && pointF5 != null && pointF2 != null) {
                    interpolatorA2 = a(pointF3, pointF5);
                    interpolatorA3 = a(pointF9, pointF2);
                    obj2 = objA4;
                    interpolatorA4 = null;
                }
                if (interpolatorA2 != null || interpolatorA3 == null) {
                    aVar2 = new d8.a(kVar, obj5, obj2, interpolatorA4, fE2, (Float) null);
                } else {
                    aVar2 = new d8.a(kVar, obj5, obj2, interpolatorA2, interpolatorA3, fE2);
                }
                aVar2.f6724o = pointFB5;
                aVar2.f6725p = pointFB6;
                return aVar2;
            }
            interpolatorA4 = a(pointFB7, pointFB8);
            obj2 = objA4;
        }
        interpolatorA2 = null;
        interpolatorA3 = null;
        if (interpolatorA2 != null) {
            aVar2 = new d8.a(kVar, obj5, obj2, interpolatorA4, fE2, (Float) null);
        } else {
            aVar2 = new d8.a(kVar, obj5, obj2, interpolatorA4, fE2, (Float) null);
        }
        aVar2.f6724o = pointFB5;
        aVar2.f6725p = pointFB6;
        return aVar2;
    }

    public static void c(int i10, WeakReference weakReference) {
        synchronized (p.class) {
            f627b.d(i10, weakReference);
        }
    }
}
