package a8;

import android.graphics.Color;
import android.graphics.PointF;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class f implements e0 {
    public static final f X = new f(0);
    public static final f Y = new f(1);
    public static final f Z = new f(2);

    /* JADX INFO: renamed from: r0, reason: collision with root package name */
    public static final f f604r0 = new f(3);

    /* JADX INFO: renamed from: s0, reason: collision with root package name */
    public static final f f605s0 = new f(4);

    /* JADX INFO: renamed from: t0, reason: collision with root package name */
    public static final f f606t0 = new f(5);

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f607e;

    public /* synthetic */ f(int i10) {
        this.f607e = i10;
    }

    @Override // a8.e0
    public final Object a(b8.a aVar, float f) {
        switch (this.f607e) {
            case 0:
                boolean z5 = aVar.K() == 1;
                if (z5) {
                    aVar.a();
                }
                double dE = aVar.E();
                double dE2 = aVar.E();
                double dE3 = aVar.E();
                double dE4 = aVar.K() == 7 ? aVar.E() : 1.0d;
                if (z5) {
                    aVar.t();
                }
                if (dE <= 1.0d && dE2 <= 1.0d && dE3 <= 1.0d) {
                    dE *= 255.0d;
                    dE2 *= 255.0d;
                    dE3 *= 255.0d;
                    if (dE4 <= 1.0d) {
                        dE4 *= 255.0d;
                    }
                }
                return Integer.valueOf(Color.argb((int) dE4, (int) dE, (int) dE2, (int) dE3));
            case 1:
                return Float.valueOf(o.d(aVar) * f);
            case 2:
                return Integer.valueOf(Math.round(o.d(aVar) * f));
            case 3:
                return o.b(aVar, f);
            case 4:
                int iK = aVar.K();
                if (iK == 1) {
                    return o.b(aVar, f);
                }
                if (iK == 3) {
                    return o.b(aVar, f);
                }
                if (iK != 7) {
                    throw new IllegalArgumentException("Cannot convert json to point. Next token is ".concat(a0.f.C(iK)));
                }
                PointF pointF = new PointF(((float) aVar.E()) * f, ((float) aVar.E()) * f);
                while (aVar.C()) {
                    aVar.U();
                }
                return pointF;
            default:
                boolean z6 = aVar.K() == 1;
                if (z6) {
                    aVar.a();
                }
                float fE = (float) aVar.E();
                float fE2 = (float) aVar.E();
                while (aVar.C()) {
                    aVar.U();
                }
                if (z6) {
                    aVar.t();
                }
                return new d8.c((fE / 100.0f) * f, (fE2 / 100.0f) * f);
        }
    }
}
