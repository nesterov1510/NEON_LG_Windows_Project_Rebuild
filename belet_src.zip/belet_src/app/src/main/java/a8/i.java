package a8;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class i {
    public static final m7.l f = m7.l.B("ef");

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static final m7.l f610g = m7.l.B("nm", "v");

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public w7.a f611a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public w7.b f612b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public w7.b f613c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public w7.b f614d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public w7.b f615e;
}
