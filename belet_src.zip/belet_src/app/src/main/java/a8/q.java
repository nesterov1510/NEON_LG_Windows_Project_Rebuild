package a8;

import java.util.ArrayList;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public abstract class q {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final m7.l f630a = m7.l.B("k");

    public static ArrayList a(b8.a aVar, com.airbnb.lottie.k kVar, float f, e0 e0Var, boolean z5) {
        b8.a aVar2;
        com.airbnb.lottie.k kVar2;
        float f10;
        e0 e0Var2;
        boolean z6;
        ArrayList arrayList = new ArrayList();
        if (aVar.K() == 6) {
            kVar.a("Lottie doesn't support expressions.");
            return arrayList;
        }
        aVar.m();
        while (aVar.C()) {
            if (aVar.P(f630a) != 0) {
                aVar.U();
            } else if (aVar.K() == 1) {
                aVar.a();
                if (aVar.K() == 7) {
                    b8.a aVar3 = aVar;
                    com.airbnb.lottie.k kVar3 = kVar;
                    float f11 = f;
                    e0 e0Var3 = e0Var;
                    boolean z9 = z5;
                    d8.a aVarB = p.b(aVar3, kVar3, f11, e0Var3, false, z9);
                    aVar2 = aVar3;
                    kVar2 = kVar3;
                    f10 = f11;
                    e0Var2 = e0Var3;
                    z6 = z9;
                    arrayList.add(aVarB);
                } else {
                    aVar2 = aVar;
                    kVar2 = kVar;
                    f10 = f;
                    e0Var2 = e0Var;
                    z6 = z5;
                    while (aVar2.C()) {
                        arrayList.add(p.b(aVar2, kVar2, f10, e0Var2, true, z6));
                    }
                }
                aVar2.t();
                aVar = aVar2;
                kVar = kVar2;
                f = f10;
                e0Var = e0Var2;
                z5 = z6;
            } else {
                b8.a aVar4 = aVar;
                arrayList.add(p.b(aVar4, kVar, f, e0Var, false, z5));
                aVar = aVar4;
            }
        }
        aVar.v();
        b(arrayList);
        return arrayList;
    }

    public static void b(ArrayList arrayList) {
        int i10;
        Object obj;
        int size = arrayList.size();
        int i11 = 0;
        while (true) {
            i10 = size - 1;
            if (i11 >= i10) {
                break;
            }
            d8.a aVar = (d8.a) arrayList.get(i11);
            i11++;
            d8.a aVar2 = (d8.a) arrayList.get(i11);
            aVar.h = Float.valueOf(aVar2.f6717g);
            if (aVar.f6714c == null && (obj = aVar2.f6713b) != null) {
                aVar.f6714c = obj;
                if (aVar instanceof t7.l) {
                    ((t7.l) aVar).d();
                }
            }
        }
        d8.a aVar3 = (d8.a) arrayList.get(i10);
        if ((aVar3.f6713b == null || aVar3.f6714c == null) && arrayList.size() > 1) {
            arrayList.remove(aVar3);
        }
    }
}
