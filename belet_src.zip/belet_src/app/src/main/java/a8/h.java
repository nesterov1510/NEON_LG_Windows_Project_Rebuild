package a8;

import android.graphics.PointF;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class h implements e0 {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final h f609e = new h();
    public static final m7.l X = m7.l.B("t", "f", "s", "j", "tr", "lh", "ls", "fc", "sc", "sw", "of", "ps", "sz");

    @Override // a8.e0
    public final Object a(b8.a aVar, float f) {
        aVar.m();
        String strH = null;
        float fE = 0.0f;
        float fE2 = 0.0f;
        float fE3 = 0.0f;
        float fE4 = 0.0f;
        int iF = 0;
        int iA = 0;
        int iA2 = 0;
        boolean zD = true;
        int i10 = 3;
        String strH2 = null;
        PointF pointF = null;
        PointF pointF2 = null;
        while (aVar.C()) {
            switch (aVar.P(X)) {
                case 0:
                    strH = aVar.H();
                    break;
                case 1:
                    strH2 = aVar.H();
                    break;
                case 2:
                    fE = (float) aVar.E();
                    pointF = pointF;
                    break;
                case 3:
                    PointF pointF3 = pointF;
                    int iF2 = aVar.F();
                    i10 = (iF2 > 2 || iF2 < 0) ? 3 : g0.t.e(3)[iF2];
                    pointF = pointF3;
                    pointF2 = pointF2;
                    break;
                case 4:
                    iF = aVar.F();
                    break;
                case 5:
                    fE2 = (float) aVar.E();
                    pointF = pointF;
                    break;
                case 6:
                    fE3 = (float) aVar.E();
                    pointF = pointF;
                    break;
                case 7:
                    iA = o.a(aVar);
                    break;
                case 8:
                    iA2 = o.a(aVar);
                    break;
                case 9:
                    fE4 = (float) aVar.E();
                    pointF = pointF;
                    break;
                case 10:
                    zD = aVar.D();
                    break;
                case ue.r.NETWORK_CLIENT_ERROR_REASON_FIELD_NUMBER /* 11 */:
                    aVar.a();
                    PointF pointF4 = new PointF(((float) aVar.E()) * f, ((float) aVar.E()) * f);
                    aVar.t();
                    pointF = pointF4;
                    pointF2 = pointF2;
                    break;
                case ue.r.CUSTOM_ATTRIBUTES_FIELD_NUMBER /* 12 */:
                    aVar.a();
                    pointF2 = new PointF(((float) aVar.E()) * f, ((float) aVar.E()) * f);
                    aVar.t();
                    pointF = pointF;
                    break;
                default:
                    aVar.T();
                    aVar.U();
                    break;
            }
        }
        aVar.v();
        v7.b bVar = new v7.b();
        bVar.f21104a = strH;
        bVar.f21105b = strH2;
        bVar.f21106c = fE;
        bVar.f21107d = i10;
        bVar.f21108e = iF;
        bVar.f = fE2;
        bVar.f21109g = fE3;
        bVar.h = iA;
        bVar.f21110i = iA2;
        bVar.f21111j = fE4;
        bVar.f21112k = zD;
        bVar.f21113l = pointF;
        bVar.f21114m = pointF2;
        return bVar;
    }
}
