package a8;

import io.ktor.utils.io.n0;
import java.io.EOFException;
import java.util.ArrayList;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public abstract class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final m7.l f590a = m7.l.B("k", "x", "y");

    public static ch.d a(b8.b bVar, com.airbnb.lottie.k kVar) throws n0, EOFException {
        ArrayList arrayList = new ArrayList();
        if (bVar.K() == 1) {
            bVar.a();
            while (bVar.C()) {
                b8.b bVar2 = bVar;
                com.airbnb.lottie.k kVar2 = kVar;
                arrayList.add(new t7.l(kVar2, p.b(bVar2, kVar2, c8.k.c(), f.f604r0, bVar.K() == 3, false)));
                bVar = bVar2;
                kVar = kVar2;
            }
            bVar.t();
            q.b(arrayList);
        } else {
            arrayList.add(new d8.a(o.b(bVar, c8.k.c())));
        }
        return new ch.d(arrayList);
    }

    public static w7.e b(b8.b bVar, com.airbnb.lottie.k kVar) throws n0, EOFException {
        bVar.m();
        ch.d dVarA = null;
        w7.b bVarM = null;
        boolean z5 = false;
        w7.b bVarM2 = null;
        while (bVar.K() != 4) {
            int iP = bVar.P(f590a);
            if (iP == 0) {
                dVarA = a(bVar, kVar);
            } else if (iP != 1) {
                if (iP != 2) {
                    bVar.T();
                    bVar.U();
                } else if (bVar.K() == 6) {
                    bVar.U();
                    z5 = true;
                } else {
                    bVarM = d7.s.M(bVar, kVar, true);
                }
            } else if (bVar.K() == 6) {
                bVar.U();
                z5 = true;
            } else {
                bVarM2 = d7.s.M(bVar, kVar, true);
            }
        }
        bVar.v();
        if (z5) {
            kVar.a("Lottie doesn't support expressions.");
        }
        return dVarA != null ? dVarA : new w7.c(bVarM2, bVarM);
    }
}
