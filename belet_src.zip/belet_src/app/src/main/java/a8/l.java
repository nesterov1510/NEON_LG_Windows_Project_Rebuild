package a8;

import android.content.Context;
import android.graphics.Color;
import java.util.ArrayList;
import java.util.Arrays;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class l implements e0, ta.c {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f619e;

    public /* synthetic */ l(int i10) {
        this.f619e = i10;
    }

    /* JADX WARN: Code duplicated, block: B:38:0x00d3  */
    @Override // a8.e0
    public Object a(b8.a aVar, float f) {
        int i10;
        int iArgb;
        float f10;
        int iArgb2;
        float f11;
        float f12;
        ArrayList arrayList = new ArrayList();
        int i11 = 1;
        int i12 = 0;
        boolean z5 = aVar.K() == 1;
        if (z5) {
            aVar.a();
        }
        while (aVar.C()) {
            arrayList.add(Float.valueOf((float) aVar.E()));
        }
        int i13 = 2;
        if (arrayList.size() == 4 && ((Float) arrayList.get(0)).floatValue() == 1.0f) {
            arrayList.set(0, Float.valueOf(0.0f));
            arrayList.add(Float.valueOf(1.0f));
            arrayList.add((Float) arrayList.get(1));
            arrayList.add((Float) arrayList.get(2));
            arrayList.add((Float) arrayList.get(3));
            this.f619e = 2;
        }
        if (z5) {
            aVar.t();
        }
        if (this.f619e == -1) {
            this.f619e = arrayList.size() / 4;
        }
        int i14 = this.f619e;
        float[] fArr = new float[i14];
        int[] iArr = new int[i14];
        int i15 = 0;
        int i16 = 0;
        int i17 = 0;
        while (true) {
            i10 = this.f619e * 4;
            if (i15 >= i10) {
                break;
            }
            int i18 = i15 / 4;
            double dFloatValue = ((Float) arrayList.get(i15)).floatValue();
            int i19 = i12;
            int i20 = i15 % 4;
            if (i20 != 0) {
                if (i20 == i11) {
                    i16 = (int) (dFloatValue * 255.0d);
                } else if (i20 == 2) {
                    i17 = (int) (dFloatValue * 255.0d);
                } else if (i20 == 3) {
                    iArr[i18] = Color.argb(255, i16, i17, (int) (dFloatValue * 255.0d));
                }
            } else if (i18 > 0) {
                float f13 = (float) dFloatValue;
                if (fArr[i18 - 1] >= f13) {
                    fArr[i18] = f13 + 0.01f;
                } else {
                    fArr[i18] = (float) dFloatValue;
                }
            } else {
                fArr[i18] = (float) dFloatValue;
            }
            i15++;
            i12 = i19;
            i11 = 1;
        }
        int i21 = i12;
        x7.c cVar = new x7.c(fArr, iArr);
        if (arrayList.size() <= i10) {
            return cVar;
        }
        int size = (arrayList.size() - i10) / 2;
        float[] fArr2 = new float[size];
        float[] fArr3 = new float[size];
        int i22 = i21;
        while (i10 < arrayList.size()) {
            if (i10 % 2 == 0) {
                fArr2[i22] = ((Float) arrayList.get(i10)).floatValue();
            } else {
                fArr3[i22] = ((Float) arrayList.get(i10)).floatValue();
                i22++;
            }
            i10++;
        }
        float[] fArrCopyOf = cVar.f22045a;
        if (fArrCopyOf.length == 0) {
            fArrCopyOf = fArr2;
        } else if (size != 0) {
            int length = fArrCopyOf.length + size;
            float[] fArr4 = new float[length];
            int i23 = i21;
            int i24 = i23;
            int i25 = i24;
            int i26 = i25;
            while (i23 < length) {
                float f14 = i25 < fArrCopyOf.length ? fArrCopyOf[i25] : Float.NaN;
                float f15 = i26 < size ? fArr2[i26] : Float.NaN;
                if (Float.isNaN(f15) || f14 < f15) {
                    fArr4[i23] = f14;
                    i25++;
                } else if (Float.isNaN(f14) || f15 < f14) {
                    fArr4[i23] = f15;
                    i26++;
                } else {
                    fArr4[i23] = f14;
                    i25++;
                    i26++;
                    i24++;
                }
                i23++;
            }
            fArrCopyOf = i24 == 0 ? fArr4 : Arrays.copyOf(fArr4, length - i24);
        }
        int length2 = fArrCopyOf.length;
        int[] iArr2 = new int[length2];
        int i27 = i21;
        while (i27 < length2) {
            float f16 = fArrCopyOf[i27];
            int iBinarySearch = Arrays.binarySearch(fArr, f16);
            int iBinarySearch2 = Arrays.binarySearch(fArr2, f16);
            if (iBinarySearch < 0 || iBinarySearch2 > 0) {
                if (iBinarySearch2 < 0) {
                    iBinarySearch2 = -(iBinarySearch2 + 1);
                }
                float f17 = fArr3[iBinarySearch2];
                if (i14 < 2 || f16 == fArr[i21]) {
                    iArgb = iArr[i21];
                } else {
                    int i28 = 1;
                    while (true) {
                        if (i28 >= i14) {
                            throw new IllegalArgumentException("Unreachable code.");
                        }
                        f10 = fArr[i28];
                        if (f10 >= f16 || i28 == i14 - 1) {
                            break;
                        }
                        i28++;
                    }
                    if (i28 != i14 - 1 || f16 < f10) {
                        int i29 = i28 - 1;
                        float f18 = fArr[i29];
                        int iO = com.bumptech.glide.c.o(iArr[i29], (f16 - f18) / (f10 - f18), iArr[i28]);
                        iArgb = Color.argb((int) (f17 * 255.0f), Color.red(iO), Color.green(iO), Color.blue(iO));
                    } else {
                        iArgb = Color.argb((int) (f17 * 255.0f), Color.red(iArr[i28]), Color.green(iArr[i28]), Color.blue(iArr[i28]));
                    }
                }
                iArr2[i27] = iArgb;
            } else {
                int i30 = iArr[iBinarySearch];
                if (size < i13 || f16 <= fArr2[i21]) {
                    iArgb2 = Color.argb((int) (fArr3[i21] * 255.0f), Color.red(i30), Color.green(i30), Color.blue(i30));
                } else {
                    int i31 = 1;
                    while (true) {
                        if (i31 >= size) {
                            throw new IllegalArgumentException("Unreachable code.");
                        }
                        f11 = fArr2[i31];
                        if (f11 >= f16 || i31 == size - 1) {
                            break;
                        }
                        i31++;
                    }
                    if (f11 <= f16) {
                        f12 = fArr3[i31];
                    } else {
                        int i32 = i31 - 1;
                        float f19 = fArr2[i32];
                        f12 = c8.h.f(fArr3[i32], fArr3[i31], (f16 - f19) / (f11 - f19));
                    }
                    iArgb2 = Color.argb((int) (f12 * 255.0f), Color.red(i30), Color.green(i30), Color.blue(i30));
                }
                iArr2[i27] = iArgb2;
            }
            i27++;
            i13 = 2;
        }
        return new x7.c(fArrCopyOf, iArr2);
    }

    @Override // ta.c
    public int c(Context context, String str, boolean z5) {
        return 0;
    }

    @Override // ta.c
    public int d(Context context, String str) {
        return this.f619e;
    }

    public l(int i10, z.n completionBehavior) {
        kotlin.jvm.internal.q.g(completionBehavior, "completionBehavior");
        this.f619e = i10;
    }
}
