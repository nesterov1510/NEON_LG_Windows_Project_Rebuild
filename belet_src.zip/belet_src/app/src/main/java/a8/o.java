package a8;

import android.graphics.Color;
import android.graphics.PointF;
import java.util.ArrayList;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public abstract class o {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final m7.l f625a = m7.l.B("x", "y");

    public static int a(b8.a aVar) {
        aVar.a();
        int iE = (int) (aVar.E() * 255.0d);
        int iE2 = (int) (aVar.E() * 255.0d);
        int iE3 = (int) (aVar.E() * 255.0d);
        while (aVar.C()) {
            aVar.U();
        }
        aVar.t();
        return Color.argb(255, iE, iE2, iE3);
    }

    public static PointF b(b8.a aVar, float f) {
        int iC = g0.t.c(aVar.K());
        if (iC == 0) {
            aVar.a();
            float fE = (float) aVar.E();
            float fE2 = (float) aVar.E();
            while (aVar.K() != 2) {
                aVar.U();
            }
            aVar.t();
            return new PointF(fE * f, fE2 * f);
        }
        if (iC != 2) {
            if (iC != 6) {
                throw new IllegalArgumentException("Unknown point starts with ".concat(a0.f.C(aVar.K())));
            }
            float fE3 = (float) aVar.E();
            float fE4 = (float) aVar.E();
            while (aVar.C()) {
                aVar.U();
            }
            return new PointF(fE3 * f, fE4 * f);
        }
        aVar.m();
        float fD = 0.0f;
        float fD2 = 0.0f;
        while (aVar.C()) {
            int iP = aVar.P(f625a);
            if (iP == 0) {
                fD = d(aVar);
            } else if (iP != 1) {
                aVar.T();
                aVar.U();
            } else {
                fD2 = d(aVar);
            }
        }
        aVar.v();
        return new PointF(fD * f, fD2 * f);
    }

    public static ArrayList c(b8.a aVar, float f) {
        ArrayList arrayList = new ArrayList();
        aVar.a();
        while (aVar.K() == 1) {
            aVar.a();
            arrayList.add(b(aVar, f));
            aVar.t();
        }
        aVar.t();
        return arrayList;
    }

    public static float d(b8.a aVar) {
        int iK = aVar.K();
        int iC = g0.t.c(iK);
        if (iC != 0) {
            if (iC == 6) {
                return (float) aVar.E();
            }
            throw new IllegalArgumentException("Unknown value for token of type ".concat(a0.f.C(iK)));
        }
        aVar.a();
        float fE = (float) aVar.E();
        while (aVar.C()) {
            aVar.U();
        }
        aVar.t();
        return fE;
    }
}
