package a8;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public abstract class m {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final m7.l f620a = m7.l.B("nm", "g", "o", "t", "s", "e", "r", "hd");

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final m7.l f621b = m7.l.B("p", "k");
}
