package a8;

import android.graphics.PointF;
import android.view.animation.Interpolator;
import java.util.List;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public abstract class c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final m7.l f596a = m7.l.B("a", "p", "s", "rz", "r", "o", "so", "eo", "sk", "sa", "rx", "ry");

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final m7.l f597b = m7.l.B("k");

    public static void a(w7.b bVar, com.airbnb.lottie.k kVar) {
        Float fValueOf = Float.valueOf(0.0f);
        List list = (List) bVar.X;
        if (list.isEmpty()) {
            list.add(new d8.a(kVar, fValueOf, fValueOf, (Interpolator) null, 0.0f, Float.valueOf(kVar.f4657m)));
        } else if (((d8.a) list.get(0)).f6713b == null) {
            list.set(0, new d8.a(kVar, fValueOf, fValueOf, (Interpolator) null, 0.0f, Float.valueOf(kVar.f4657m)));
        }
    }

    public static boolean b(w7.b bVar) {
        if (bVar != null) {
            return bVar.p1() && ((Float) ((d8.a) ((List) bVar.X).get(0)).f6713b).floatValue() == 0.0f;
        }
        return true;
    }

    /* JADX WARN: Code duplicated, block: B:65:0x0121  */
    public static w7.d c(b8.b bVar, com.airbnb.lottie.k kVar) {
        w7.a aVar;
        boolean z5 = bVar.K() == 3;
        if (z5) {
            bVar.m();
        }
        ch.d dVarA = null;
        w7.e eVarB = null;
        w7.b bVarM = null;
        w7.a aVar2 = null;
        w7.b bVarM2 = null;
        w7.b bVarM3 = null;
        w7.b bVarM4 = null;
        w7.b bVarM5 = null;
        w7.b bVarM6 = null;
        w7.a aVarO = null;
        w7.b bVarM7 = null;
        w7.b bVarM8 = null;
        while (bVar.C()) {
            switch (bVar.P(f596a)) {
                case 0:
                    bVar.m();
                    while (bVar.C()) {
                        if (bVar.P(f597b) != 0) {
                            bVar.T();
                            bVar.U();
                        } else {
                            dVarA = a.a(bVar, kVar);
                        }
                    }
                    bVar.v();
                    break;
                case 1:
                    eVarB = a.b(bVar, kVar);
                    break;
                case 2:
                    aVar2 = new w7.a(4, q.a(bVar, kVar, 1.0f, f.f606t0, false));
                    break;
                case 3:
                    bVarM6 = d7.s.M(bVar, kVar, false);
                    a(bVarM6, kVar);
                    break;
                case 4:
                    bVarM = d7.s.M(bVar, kVar, false);
                    a(bVarM, kVar);
                    break;
                case 5:
                    aVarO = d7.s.O(bVar, kVar);
                    break;
                case 6:
                    bVarM7 = d7.s.M(bVar, kVar, false);
                    break;
                case 7:
                    bVarM8 = d7.s.M(bVar, kVar, false);
                    break;
                case 8:
                    bVarM2 = d7.s.M(bVar, kVar, false);
                    break;
                case 9:
                    bVarM3 = d7.s.M(bVar, kVar, false);
                    break;
                case 10:
                    bVarM4 = d7.s.M(bVar, kVar, false);
                    a(bVarM4, kVar);
                    break;
                case ue.r.NETWORK_CLIENT_ERROR_REASON_FIELD_NUMBER /* 11 */:
                    bVarM5 = d7.s.M(bVar, kVar, false);
                    a(bVarM5, kVar);
                    break;
                default:
                    bVar.T();
                    bVar.U();
                    break;
            }
        }
        if (z5) {
            bVar.v();
        }
        if (dVarA == null || (dVarA.p1() && ((PointF) ((d8.a) dVarA.f4534e.get(0)).f6713b).equals(0.0f, 0.0f))) {
            dVarA = null;
        }
        w7.e eVar = (eVarB == null || (!(eVarB instanceof w7.c) && eVarB.p1() && ((PointF) ((d8.a) eVarB.n1().get(0)).f6713b).equals(0.0f, 0.0f))) ? null : eVarB;
        w7.b bVar2 = b(bVarM) ? null : bVarM;
        if (aVar2 == null) {
            aVar = null;
        } else {
            if (aVar2.p1()) {
                d8.c cVar = (d8.c) ((d8.a) ((List) aVar2.X).get(0)).f6713b;
                if (cVar.f6732a == 1.0f && cVar.f6733b == 1.0f) {
                    aVar = null;
                }
            }
            aVar = aVar2;
        }
        return new w7.d(dVarA, eVar, aVar, bVar2, aVarO, bVarM7, bVarM8, (bVarM2 == null || (bVarM2.p1() && ((Float) ((d8.a) ((List) bVarM2.X).get(0)).f6713b).floatValue() == 0.0f)) ? null : bVarM2, (bVarM3 == null || (bVarM3.p1() && ((Float) ((d8.a) ((List) bVarM3.X).get(0)).f6713b).floatValue() == 0.0f)) ? null : bVarM3, b(bVarM4) ? null : bVarM4, b(bVarM5) ? null : bVarM5, b(bVarM6) ? null : bVarM6);
    }
}
