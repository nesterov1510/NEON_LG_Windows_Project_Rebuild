package a;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.hardware.camera2.CameraAccessException;
import android.os.Build;
import android.text.TextUtils;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import androidx.appcompat.widget.o3;
import androidx.appcompat.widget.q3;
import androidx.lifecycle.x0;
import c0.h;
import ej.l;
import fk.j;
import g0.t;
import java.io.Closeable;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;
import java.net.Inet4Address;
import java.net.Inet6Address;
import java.net.InetAddress;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.MappedByteBuffer;
import java.util.Locale;
import jd.t1;
import kotlin.jvm.internal.q;
import l1.f;
import l1.g;
import m0.a0;
import mj.d;
import okhttp3.internal.ws.WebSocketProtocol;
import q6.c;
import ue.r;
import x2.b;
import z.o1;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public abstract class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static Thread f3a;

    public static b A(MappedByteBuffer mappedByteBuffer) throws IOException {
        long j10;
        ByteBuffer byteBufferDuplicate = mappedByteBuffer.duplicate();
        byteBufferDuplicate.order(ByteOrder.BIG_ENDIAN);
        byteBufferDuplicate.position(byteBufferDuplicate.position() + 4);
        int i10 = byteBufferDuplicate.getShort() & 65535;
        if (i10 > 100) {
            throw new IOException("Cannot read metadata.");
        }
        byteBufferDuplicate.position(byteBufferDuplicate.position() + 6);
        int i11 = 0;
        while (true) {
            if (i11 >= i10) {
                j10 = -1;
                break;
            }
            int i12 = byteBufferDuplicate.getInt();
            byteBufferDuplicate.position(byteBufferDuplicate.position() + 4);
            j10 = ((long) byteBufferDuplicate.getInt()) & 4294967295L;
            byteBufferDuplicate.position(byteBufferDuplicate.position() + 4);
            if (1835365473 == i12) {
                break;
            }
            i11++;
        }
        if (j10 != -1) {
            byteBufferDuplicate.position(byteBufferDuplicate.position() + ((int) (j10 - ((long) byteBufferDuplicate.position()))));
            byteBufferDuplicate.position(byteBufferDuplicate.position() + 12);
            long j11 = ((long) byteBufferDuplicate.getInt()) & 4294967295L;
            for (int i13 = 0; i13 < j11; i13++) {
                int i14 = byteBufferDuplicate.getInt();
                long j12 = ((long) byteBufferDuplicate.getInt()) & 4294967295L;
                byteBufferDuplicate.getInt();
                if (1164798569 == i14 || 1701669481 == i14) {
                    byteBufferDuplicate.position((int) (j12 + j10));
                    b bVar = new b();
                    byteBufferDuplicate.order(ByteOrder.LITTLE_ENDIAN);
                    int iPosition = byteBufferDuplicate.position() + byteBufferDuplicate.getInt(byteBufferDuplicate.position());
                    bVar.Z = byteBufferDuplicate;
                    bVar.f12650e = iPosition;
                    int i15 = iPosition - byteBufferDuplicate.getInt(iPosition);
                    bVar.X = i15;
                    bVar.Y = ((ByteBuffer) bVar.Z).getShort(i15);
                    return bVar;
                }
            }
        }
        throw new IOException("Cannot read metadata.");
    }

    public static void D(int i10, r7.a aVar) {
        PorterDuff.Mode mode;
        if (Build.VERSION.SDK_INT >= 29) {
            a2.a.m(aVar, i10 != 0 ? a2.a.j(i10) : null);
            return;
        }
        if (i10 == 0) {
            aVar.setXfermode(null);
            return;
        }
        switch (t.c(i10)) {
            case 0:
                mode = PorterDuff.Mode.CLEAR;
                break;
            case 1:
                mode = PorterDuff.Mode.SRC;
                break;
            case 2:
                mode = PorterDuff.Mode.DST;
                break;
            case 3:
                mode = PorterDuff.Mode.SRC_OVER;
                break;
            case 4:
                mode = PorterDuff.Mode.DST_OVER;
                break;
            case 5:
                mode = PorterDuff.Mode.SRC_IN;
                break;
            case 6:
                mode = PorterDuff.Mode.DST_IN;
                break;
            case 7:
                mode = PorterDuff.Mode.SRC_OUT;
                break;
            case 8:
                mode = PorterDuff.Mode.DST_OUT;
                break;
            case 9:
                mode = PorterDuff.Mode.SRC_ATOP;
                break;
            case 10:
                mode = PorterDuff.Mode.DST_ATOP;
                break;
            case r.NETWORK_CLIENT_ERROR_REASON_FIELD_NUMBER /* 11 */:
                mode = PorterDuff.Mode.XOR;
                break;
            case r.CUSTOM_ATTRIBUTES_FIELD_NUMBER /* 12 */:
                mode = PorterDuff.Mode.ADD;
                break;
            case r.PERF_SESSIONS_FIELD_NUMBER /* 13 */:
                mode = PorterDuff.Mode.MULTIPLY;
                break;
            case 14:
                mode = PorterDuff.Mode.SCREEN;
                break;
            case WebSocketProtocol.B0_MASK_OPCODE /* 15 */:
                mode = PorterDuff.Mode.OVERLAY;
                break;
            case WebSocketProtocol.B0_FLAG_RSV3 /* 16 */:
                mode = PorterDuff.Mode.DARKEN;
                break;
            case 17:
                mode = PorterDuff.Mode.LIGHTEN;
                break;
            default:
                mode = null;
                break;
        }
        aVar.setXfermode(mode != null ? new PorterDuffXfermode(mode) : null);
    }

    public static void F(View view, CharSequence charSequence) {
        if (Build.VERSION.SDK_INT >= 26) {
            o3.a(view, charSequence);
            return;
        }
        q3 q3Var = q3.f1409x0;
        if (q3Var != null && q3Var.f1411e == view) {
            q3.b(null);
        }
        if (!TextUtils.isEmpty(charSequence)) {
            new q3(view, charSequence);
            return;
        }
        q3 q3Var2 = q3.f1410y0;
        if (q3Var2 != null && q3Var2.f1411e == view) {
            q3Var2.a();
        }
        view.setOnLongClickListener(null);
        view.setLongClickable(false);
        view.setOnHoverListener(null);
    }

    public static byte[] G(int i10, String str) {
        int i11;
        byte[] bArrG;
        if (i10 == 1) {
            byte[] bArr = new byte[4];
            int length = str.length();
            int i12 = 0;
            int i13 = 0;
            int i14 = 0;
            for (int i15 = 0; i15 < length; i15++) {
                char cCharAt = str.charAt(i15);
                if (cCharAt < '0' || cCharAt > '9') {
                    if (cCharAt != '.' || i12 == 3 || i13 == 0) {
                        return null;
                    }
                    bArr[i12] = (byte) i14;
                    i14 = 0;
                    i12++;
                    i13 = 0;
                } else {
                    if (i13 == 3) {
                        return null;
                    }
                    if (i13 > 0 && i14 == 0) {
                        return null;
                    }
                    i13++;
                    int i16 = (cCharAt - '0') + (i14 * 10);
                    if (i16 > 255) {
                        return null;
                    }
                    i14 = i16;
                }
            }
            if (i12 != 3 || i13 == 0) {
                return null;
            }
            bArr[i12] = (byte) i14;
            return bArr;
        }
        if (i10 != 2) {
            throw new IllegalArgumentException("unknown address family");
        }
        byte[] bArr2 = new byte[16];
        int i17 = -1;
        String[] strArrSplit = str.split(":", -1);
        int length2 = strArrSplit.length;
        int i18 = length2 - 1;
        if (!strArrSplit[0].isEmpty()) {
            i11 = 0;
        } else {
            if (i18 <= 0 || !strArrSplit[1].isEmpty()) {
                return null;
            }
            i11 = 1;
        }
        if (strArrSplit[i18].isEmpty()) {
            if (i18 - i11 <= 0) {
                return null;
            }
            i18 = length2 - 2;
            if (!strArrSplit[i18].isEmpty()) {
                return null;
            }
        }
        if ((i18 - i11) + 1 > 8) {
            return null;
        }
        int i19 = 0;
        while (i11 <= i18) {
            if (strArrSplit[i11].isEmpty()) {
                if (i17 >= 0) {
                    return null;
                }
                i17 = i19;
            } else {
                if (strArrSplit[i11].indexOf(46) >= 0) {
                    if (i11 < i18 || i11 > 6 || (bArrG = G(1, strArrSplit[i11])) == null) {
                        return null;
                    }
                    int i20 = 0;
                    while (i20 < 4) {
                        bArr2[i19] = bArrG[i20];
                        i20++;
                        i19++;
                    }
                    break;
                }
                for (int i21 = 0; i21 < strArrSplit[i11].length(); i21++) {
                    try {
                        if (Character.digit(strArrSplit[i11].charAt(i21), 16) < 0) {
                            return null;
                        }
                    } catch (NumberFormatException unused) {
                        return null;
                    }
                }
                int i22 = Integer.parseInt(strArrSplit[i11], 16);
                if (!h.x(i22)) {
                    return null;
                }
                int i23 = i19 + 1;
                bArr2[i19] = (byte) (i22 >>> 8);
                i19 += 2;
                bArr2[i23] = (byte) (i22 & 255);
            }
            i11++;
        }
        if (i19 < 16 && i17 < 0) {
            return null;
        }
        if (i17 >= 0) {
            int i24 = (16 - i19) + i17;
            System.arraycopy(bArr2, i17, bArr2, i24, i19 - i17);
            while (i17 < i24) {
                bArr2[i17] = 0;
                i17++;
            }
        }
        return bArr2;
    }

    public static String H(byte[] bArr) {
        return (bArr[0] & 255) + "." + (bArr[1] & 255) + "." + (bArr[2] & 255) + "." + (bArr[3] & 255);
    }

    public static String I(byte[] bArr) {
        StringBuilder sb2 = new StringBuilder(bArr.length * 2);
        for (byte b10 : bArr) {
            short s8 = (short) (b10 & 255);
            sb2.append("0123456789ABCDEF".charAt((byte) (s8 >> 4)));
            sb2.append("0123456789ABCDEF".charAt((byte) (s8 & 15)));
        }
        return sb2.toString();
    }

    public static Object J(g0.r rVar, kotlin.jvm.internal.h hVar) {
        if (rVar instanceof o1) {
            return ((o1) rVar).D(hVar);
        }
        if (!(rVar instanceof a0)) {
            return null;
        }
        a0 a0Var = (a0) rVar;
        if (a0Var.f() == rVar) {
            return null;
        }
        a0 a0VarF = a0Var.f();
        q.f(a0VarF, "getImplementation(...)");
        return J(a0VarF, hVar);
    }

    public static final void K(String str, int i10, String str2) {
        throw new IllegalArgumentException("Expected " + str2 + " at index " + i10 + ", but was '" + str.charAt(i10) + '\'');
    }

    public static int a(int i10) {
        if (i10 == 1) {
            return 4;
        }
        if (i10 == 2) {
            return 16;
        }
        throw new IllegalArgumentException("unknown address family");
    }

    public static void b(StringBuilder sb2, Object obj, l lVar) {
        if (lVar != null) {
            sb2.append((CharSequence) lVar.invoke(obj));
            return;
        }
        if (obj == null ? true : obj instanceof CharSequence) {
            sb2.append((CharSequence) obj);
        } else if (obj instanceof Character) {
            sb2.append(((Character) obj).charValue());
        } else {
            sb2.append((CharSequence) obj.toString());
        }
    }

    public static final void f(Closeable closeable, Throwable th2) {
        if (closeable != null) {
            if (th2 == null) {
                closeable.close();
                return;
            }
            try {
                closeable.close();
            } catch (Throwable th3) {
                j.a(th2, th3);
            }
        }
    }

    public static x0 g(Class cls) throws InvocationTargetException {
        try {
            Constructor declaredConstructor = cls.getDeclaredConstructor(null);
            if (!Modifier.isPublic(declaredConstructor.getModifiers())) {
                throw new RuntimeException("Cannot create an instance of " + cls);
            }
            try {
                Object objNewInstance = declaredConstructor.newInstance(null);
                q.d(objNewInstance);
                return (x0) objNewInstance;
            } catch (IllegalAccessException e3) {
                throw new RuntimeException("Cannot create an instance of " + cls, e3);
            } catch (InstantiationException e10) {
                throw new RuntimeException("Cannot create an instance of " + cls, e10);
            }
        } catch (NoSuchMethodException e11) {
            throw new RuntimeException("Cannot create an instance of " + cls, e11);
        }
    }

    public static int h(InetAddress inetAddress) {
        if (inetAddress instanceof Inet4Address) {
            return 1;
        }
        if (inetAddress instanceof Inet6Address) {
            return 2;
        }
        throw new IllegalArgumentException("unknown address family");
    }

    public static final void i(long j10, byte[] bArr, int i10, int i11, int i12) {
        int i13 = 7 - i11;
        int i14 = 8 - i12;
        if (i14 > i13) {
            return;
        }
        while (true) {
            int i15 = d.f15485a[(int) ((j10 >> (i13 << 3)) & 255)];
            int i16 = i10 + 1;
            bArr[i10] = (byte) (i15 >> 8);
            i10 += 2;
            bArr[i16] = (byte) i15;
            if (i13 == i14) {
                return;
            } else {
                i13--;
            }
        }
    }

    public static int j(Exception exc) {
        boolean zC;
        boolean z5 = false;
        if (exc instanceof CameraAccessException) {
            CameraAccessException cameraAccessException = (CameraAccessException) exc;
            int reason = cameraAccessException.getReason();
            if (reason == 1) {
                return 3;
            }
            if (reason == 2) {
                return 6;
            }
            if (reason == 3) {
                return 0;
            }
            if (reason == 4) {
                return 1;
            }
            if (reason == 5) {
                return 2;
            }
            Log.w("CXCP", "Unexpected CameraAccessException: " + cameraAccessException);
            return 11;
        }
        if (exc instanceof IllegalArgumentException) {
            return 7;
        }
        if (exc instanceof SecurityException) {
            return 8;
        }
        if (Build.VERSION.SDK_INT == 28) {
            if (exc instanceof RuntimeException) {
                StackTraceElement[] stackTrace = ((RuntimeException) exc).getStackTrace();
                q.d(stackTrace);
                zC = q.c(stackTrace.length == 0 ? null : stackTrace[0].getMethodName(), "_enableShutterSound");
            } else {
                zC = false;
            }
            if (zC) {
                z5 = true;
            }
        }
        if (z5) {
            return 10;
        }
        Log.w("CXCP", "Unexpected throwable: " + exc);
        return 11;
    }

    public static final Object k(Context context, Class cls) {
        q.g(context, "context");
        return t1.m(cls, y6.a.h(context.getApplicationContext()));
    }

    public static int l(Context context, int i10) {
        return (int) TypedValue.applyDimension(1, i10, context.getResources().getDisplayMetrics());
    }

    public static c m(oh.b refHolder, SQLiteDatabase sQLiteDatabase) {
        q.g(refHolder, "refHolder");
        c cVar = (c) refHolder.f16489e;
        if (cVar != null && cVar.f17169e.equals(sQLiteDatabase)) {
            return cVar;
        }
        c cVar2 = new c(sQLiteDatabase);
        refHolder.f16489e = cVar2;
        return cVar2;
    }

    public static boolean p() {
        String MANUFACTURER = Build.MANUFACTURER;
        q.f(MANUFACTURER, "MANUFACTURER");
        if (!MANUFACTURER.equalsIgnoreCase("Huawei")) {
            String BRAND = Build.BRAND;
            q.f(BRAND, "BRAND");
            if (!BRAND.equalsIgnoreCase("Huawei")) {
                return false;
            }
        }
        return "HWANE".equalsIgnoreCase(Build.DEVICE);
    }

    public static boolean q() {
        String MANUFACTURER = Build.MANUFACTURER;
        q.f(MANUFACTURER, "MANUFACTURER");
        if (!MANUFACTURER.equalsIgnoreCase("Nokia")) {
            String BRAND = Build.BRAND;
            q.f(BRAND, "BRAND");
            if (!BRAND.equalsIgnoreCase("Nokia")) {
                return false;
            }
        }
        String str = Build.DEVICE;
        return "B2N".equalsIgnoreCase(str) || "B2N_sprout".equalsIgnoreCase(str);
    }

    public static boolean r() {
        String MANUFACTURER = Build.MANUFACTURER;
        q.f(MANUFACTURER, "MANUFACTURER");
        if (!MANUFACTURER.equalsIgnoreCase("OnePlus")) {
            String BRAND = Build.BRAND;
            q.f(BRAND, "BRAND");
            if (!BRAND.equalsIgnoreCase("OnePlus")) {
                return false;
            }
        }
        return "OnePlus6".equalsIgnoreCase(Build.DEVICE);
    }

    public static boolean s() {
        String MANUFACTURER = Build.MANUFACTURER;
        q.f(MANUFACTURER, "MANUFACTURER");
        if (!MANUFACTURER.equalsIgnoreCase("OnePlus")) {
            String BRAND = Build.BRAND;
            q.f(BRAND, "BRAND");
            if (!BRAND.equalsIgnoreCase("OnePlus")) {
                return false;
            }
        }
        return "OnePlus6T".equalsIgnoreCase(Build.DEVICE);
    }

    public static boolean t() {
        String MANUFACTURER = Build.MANUFACTURER;
        q.f(MANUFACTURER, "MANUFACTURER");
        if (!MANUFACTURER.equalsIgnoreCase("Redmi")) {
            String BRAND = Build.BRAND;
            q.f(BRAND, "BRAND");
            if (!BRAND.equalsIgnoreCase("Redmi")) {
                return false;
            }
        }
        return "joyeuse".equalsIgnoreCase(Build.DEVICE);
    }

    /* JADX WARN: Code duplicated, block: B:10:0x0041 A[RETURN] */
    /* JADX WARN: Code duplicated, block: B:6:0x001d  */
    /* JADX WARN: Code duplicated, block: B:8:0x0027  */
    public static boolean u() {
        String upperCase;
        String MANUFACTURER = Build.MANUFACTURER;
        q.f(MANUFACTURER, "MANUFACTURER");
        if (!MANUFACTURER.equalsIgnoreCase("Samsung")) {
            String BRAND = Build.BRAND;
            q.f(BRAND, "BRAND");
            if (BRAND.equalsIgnoreCase("Samsung")) {
                if ("a05s".equalsIgnoreCase(Build.DEVICE)) {
                    String MODEL = Build.MODEL;
                    q.f(MODEL, "MODEL");
                    upperCase = MODEL.toUpperCase(Locale.ROOT);
                    q.f(upperCase, "toUpperCase(...)");
                    if (mj.l.c0(upperCase, "SM-A057", false)) {
                        return true;
                    }
                }
            }
        } else if ("a05s".equalsIgnoreCase(Build.DEVICE)) {
            String MODEL2 = Build.MODEL;
            q.f(MODEL2, "MODEL");
            upperCase = MODEL2.toUpperCase(Locale.ROOT);
            q.f(upperCase, "toUpperCase(...)");
            if (mj.l.c0(upperCase, "SM-A057", false)) {
                return true;
            }
        }
        return false;
    }

    public static boolean v() {
        String MANUFACTURER = Build.MANUFACTURER;
        q.f(MANUFACTURER, "MANUFACTURER");
        if (!MANUFACTURER.equalsIgnoreCase("Samsung")) {
            String BRAND = Build.BRAND;
            q.f(BRAND, "BRAND");
            if (!BRAND.equalsIgnoreCase("Samsung")) {
                return false;
            }
        }
        return "J7XELTE".equalsIgnoreCase(Build.DEVICE) && Build.VERSION.SDK_INT >= 27;
    }

    public static boolean w() {
        String MANUFACTURER = Build.MANUFACTURER;
        q.f(MANUFACTURER, "MANUFACTURER");
        if (!MANUFACTURER.equalsIgnoreCase("Samsung")) {
            String BRAND = Build.BRAND;
            q.f(BRAND, "BRAND");
            if (!BRAND.equalsIgnoreCase("Samsung")) {
                return false;
            }
        }
        return "ON7XELTE".equalsIgnoreCase(Build.DEVICE) && Build.VERSION.SDK_INT >= 27;
    }

    public static boolean x() {
        String MANUFACTURER = Build.MANUFACTURER;
        q.f(MANUFACTURER, "MANUFACTURER");
        if (!MANUFACTURER.equalsIgnoreCase("Samsung")) {
            String BRAND = Build.BRAND;
            q.f(BRAND, "BRAND");
            if (!BRAND.equalsIgnoreCase("Samsung")) {
                return false;
            }
        }
        String str = Build.DEVICE;
        return "q4q".equalsIgnoreCase(str) || "SCG16".equalsIgnoreCase(str) || "SC-55C".equalsIgnoreCase(str);
    }

    public abstract void C(boolean z5);

    public abstract void E();

    public abstract boolean c(g gVar, l1.c cVar, l1.c cVar2);

    public abstract boolean d(g gVar, Object obj, Object obj2);

    public abstract boolean e(g gVar, f fVar, f fVar2);

    public abstract void n(int i10);

    public abstract boolean o();

    public abstract void y(f fVar, f fVar2);

    public abstract void z(f fVar, Thread thread);

    public void B(boolean z5) {
    }
}
