package a7;

import android.hardware.Camera;
import android.view.View;
import j2.q0;
import java.util.Comparator;
import java.util.Locale;
import java.util.Map;
import java.util.WeakHashMap;
import kotlin.jvm.internal.q;
import l6.k;
import l6.m;
import okhttp3.internal.url._UrlKt;
import okhttp3.internal.ws.WebSocketProtocol;
import tm.belet.films.domain.models.vote.MovieVoteMemberModel;
import ue.r;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class b implements Comparator {
    public static final /* synthetic */ b X = new b(3);

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f581e;

    public /* synthetic */ b(int i10) {
        this.f581e = i10;
    }

    @Override // java.util.Comparator
    public final int compare(Object obj, Object obj2) {
        switch (this.f581e) {
            case 0:
                return ((f) obj).f584a - ((f) obj2).f584a;
            case 1:
                return ((int[]) obj)[0] - ((int[]) obj2)[0];
            case 2:
                return m7.f.f((String) ((qi.i) obj).f17355e, (String) ((qi.i) obj2).f17355e);
            case 3:
                return Long.compare(((Long) obj).longValue(), ((Long) obj2).longValue());
            case 4:
                return ((View) obj).getTop() - ((View) obj2).getTop();
            case 5:
                return m7.f.f(Boolean.valueOf(((um.a) obj2).f20839j), Boolean.valueOf(((um.a) obj).f20839j));
            case 6:
                Camera.Size size = (Camera.Size) obj;
                Camera.Size size2 = (Camera.Size) obj2;
                return Integer.compare(size2.height * size2.width, size.height * size.width);
            case 7:
                int[] iArr = (int[]) obj;
                int[] iArr2 = (int[]) obj2;
                int iCompare = Integer.compare(iArr2[1], iArr[1]);
                return iCompare == 0 ? Integer.compare(iArr2[0], iArr[0]) : iCompare;
            case 8:
                return ((Comparable) obj).compareTo((Comparable) obj2);
            case 9:
                return m7.f.f((Integer) ((Map.Entry) obj).getKey(), (Integer) ((Map.Entry) obj2).getKey());
            case 10:
                return m7.f.f((Integer) ((Map.Entry) obj).getKey(), (Integer) ((Map.Entry) obj2).getKey());
            case r.NETWORK_CLIENT_ERROR_REASON_FIELD_NUMBER /* 11 */:
                return m7.f.f(((k) obj).f14321a, ((k) obj2).f14321a);
            case r.CUSTOM_ATTRIBUTES_FIELD_NUMBER /* 12 */:
                return m7.f.f(((m) obj).f14332a, ((m) obj2).f14332a);
            case r.PERF_SESSIONS_FIELD_NUMBER /* 13 */:
                return ((m1.e) obj).X - ((m1.e) obj2).X;
            case 14:
                WeakHashMap weakHashMap = q0.f12703a;
                float z5 = ((View) obj).getZ();
                float z6 = ((View) obj2).getZ();
                if (z5 > z6) {
                    return -1;
                }
                return z5 < z6 ? 1 : 0;
            case WebSocketProtocol.B0_MASK_OPCODE /* 15 */:
                return m7.f.f(Integer.valueOf(((om.d) obj2).f16555b), Integer.valueOf(((om.d) obj).f16555b));
            case WebSocketProtocol.B0_FLAG_RSV3 /* 16 */:
                String str = ((MovieVoteMemberModel) obj).X;
                String str2 = _UrlKt.FRAGMENT_ENCODE_SET;
                if (str == null) {
                    str = _UrlKt.FRAGMENT_ENCODE_SET;
                }
                Locale locale = Locale.ROOT;
                String lowerCase = str.toLowerCase(locale);
                q.f(lowerCase, "toLowerCase(...)");
                String str3 = ((MovieVoteMemberModel) obj2).X;
                if (str3 != null) {
                    str2 = str3;
                }
                String lowerCase2 = str2.toLowerCase(locale);
                q.f(lowerCase2, "toLowerCase(...)");
                return m7.f.f(lowerCase, lowerCase2);
            default:
                Integer num = ((MovieVoteMemberModel) obj2).Y;
                Integer numValueOf = Integer.valueOf(num != null ? num.intValue() : 0);
                Integer num2 = ((MovieVoteMemberModel) obj).Y;
                return m7.f.f(numValueOf, Integer.valueOf(num2 != null ? num2.intValue() : 0));
        }
    }
}
