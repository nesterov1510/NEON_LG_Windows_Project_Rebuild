package a7;

import android.os.Bundle;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import androidx.viewpager.widget.ViewPager;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.button.MaterialButtonToggleGroup;
import com.google.android.material.datepicker.r;
import com.google.android.material.internal.CheckableImageButton;
import com.google.android.material.internal.NavigationMenuItemView;
import gd.k;
import tm.belet.films.R;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class h extends j2.b {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f588d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ Object f589e;

    public /* synthetic */ h(int i10, Object obj) {
        this.f588d = i10;
        this.f589e = obj;
    }

    @Override // j2.b
    public void c(View view, AccessibilityEvent accessibilityEvent) {
        switch (this.f588d) {
            case 0:
                super.c(view, accessibilityEvent);
                accessibilityEvent.setClassName(ViewPager.class.getName());
                accessibilityEvent.setScrollable(false);
                accessibilityEvent.getEventType();
                break;
            case 3:
                super.c(view, accessibilityEvent);
                accessibilityEvent.setChecked(((CheckableImageButton) this.f589e).f5951t0);
                break;
            default:
                super.c(view, accessibilityEvent);
                break;
        }
    }

    @Override // j2.b
    public final void d(View view, k2.f fVar) {
        int i10 = this.f588d;
        Object obj = this.f589e;
        View.AccessibilityDelegate accessibilityDelegate = this.f12631a;
        switch (i10) {
            case 0:
                accessibilityDelegate.onInitializeAccessibilityNodeInfo(view, fVar.f13377a);
                fVar.j(ViewPager.class.getName());
                fVar.p(false);
                break;
            case 1:
                accessibilityDelegate.onInitializeAccessibilityNodeInfo(view, fVar.f13377a);
                MaterialButtonToggleGroup materialButtonToggleGroup = (MaterialButtonToggleGroup) obj;
                int i11 = MaterialButtonToggleGroup.G0;
                int i12 = -1;
                if (view instanceof MaterialButton) {
                    int i13 = 0;
                    for (int i14 = 0; i14 < materialButtonToggleGroup.getChildCount(); i14++) {
                        if (materialButtonToggleGroup.getChildAt(i14) == view) {
                            i12 = i13;
                        } else {
                            if ((materialButtonToggleGroup.getChildAt(i14) instanceof MaterialButton) && materialButtonToggleGroup.getChildAt(i14).getVisibility() != 8) {
                                i13++;
                            }
                        }
                    }
                }
                fVar.k(k.t(((MaterialButton) view).E0, 0, 1, i12, 1));
                break;
            case 2:
                accessibilityDelegate.onInitializeAccessibilityNodeInfo(view, fVar.f13377a);
                r rVar = (r) obj;
                fVar.b(new k2.c(16, rVar.y1.getVisibility() == 0 ? rVar.x(R.string.mtrl_picker_toggle_to_year_selection) : rVar.x(R.string.mtrl_picker_toggle_to_day_selection)));
                break;
            case 3:
                AccessibilityNodeInfo accessibilityNodeInfo = fVar.f13377a;
                accessibilityDelegate.onInitializeAccessibilityNodeInfo(view, accessibilityNodeInfo);
                CheckableImageButton checkableImageButton = (CheckableImageButton) obj;
                accessibilityNodeInfo.setCheckable(checkableImageButton.u0);
                accessibilityNodeInfo.setChecked(checkableImageButton.f5951t0);
                break;
            case 4:
                AccessibilityNodeInfo accessibilityNodeInfo2 = fVar.f13377a;
                accessibilityDelegate.onInitializeAccessibilityNodeInfo(view, accessibilityNodeInfo2);
                accessibilityNodeInfo2.setCheckable(((NavigationMenuItemView) obj).N0);
                break;
            default:
                AccessibilityNodeInfo accessibilityNodeInfo3 = fVar.f13377a;
                accessibilityDelegate.onInitializeAccessibilityNodeInfo(view, accessibilityNodeInfo3);
                if (((nb.c) obj).f15870w0) {
                    fVar.a(1048576);
                    accessibilityNodeInfo3.setDismissable(true);
                } else {
                    accessibilityNodeInfo3.setDismissable(false);
                }
                break;
        }
    }

    @Override // j2.b
    public boolean g(View view, int i10, Bundle bundle) {
        switch (this.f588d) {
            case 0:
                ViewPager viewPager = (ViewPager) this.f589e;
                if (super.g(view, i10, bundle)) {
                    return true;
                }
                if (i10 == 4096 || i10 == 8192) {
                    viewPager.getClass();
                }
                return false;
            case 5:
                if (i10 == 1048576) {
                    nb.c cVar = (nb.c) this.f589e;
                    if (cVar.f15870w0) {
                        cVar.cancel();
                        return true;
                    }
                }
                return super.g(view, i10, bundle);
            default:
                return super.g(view, i10, bundle);
        }
    }
}
