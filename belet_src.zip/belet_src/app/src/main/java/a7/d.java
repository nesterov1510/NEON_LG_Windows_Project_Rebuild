package a7;

import a4.c0;
import android.animation.ValueAnimator;
import android.content.ComponentName;
import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.Log;
import android.view.MotionEvent;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.InputMethodManager;
import androidx.appcompat.widget.ActionMenuView;
import androidx.appcompat.widget.SearchView$SearchAutoComplete;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.y1;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;
import androidx.recyclerview.widget.w;
import androidx.viewpager.widget.ViewPager;
import androidx.work.Worker;
import cb.b1;
import cb.b2;
import cb.c2;
import cb.e4;
import cb.f1;
import cb.f3;
import cb.f4;
import cb.i3;
import cb.j1;
import cb.j3;
import cb.j4;
import cb.k1;
import cb.k3;
import cb.m3;
import cb.p0;
import cb.p2;
import cb.q3;
import cb.r3;
import cb.s3;
import cb.t0;
import cb.t3;
import cb.v0;
import cb.x0;
import cb.x3;
import cb.y;
import cb.z;
import cb.z0;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.material.internal.CheckableImageButton;
import com.google.android.material.textfield.TextInputLayout;
import dm.s;
import ea.t;
import gb.j;
import gb.n;
import go.q4;
import j$.util.Objects;
import j2.q0;
import java.io.IOException;
import java.util.WeakHashMap;
import kotlin.jvm.internal.q;
import okhttp3.internal.ws.WebSocketProtocol;
import ue.r;

/* JADX INFO: compiled from: r8-map-id-6f9e708e0285d3e0276a4da8ca9885c16e58ba6ba02e0d77266b1a577d041f1c */
/* JADX INFO: loaded from: classes.dex */
public final class d implements Runnable {
    public final Object X;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f583e;

    public /* synthetic */ d(int i10, Object obj) {
        this.f583e = i10;
        this.X = obj;
    }

    private final void a() {
        n nVar = (n) this.X;
        synchronized (nVar.Y) {
            try {
                gb.c cVar = (gb.c) nVar.Z;
                if (cVar != null) {
                    cVar.c();
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:91:0x02e5  */
    @Override // java.lang.Runnable
    public final void run() {
        androidx.appcompat.widget.n nVar;
        int i10;
        int i11 = 3;
        int i12 = 1;
        int i13 = 0;
        switch (this.f583e) {
            case 0:
                ((ViewPager) this.X).setScrollState(0);
                return;
            case 1:
                y1 y1Var = (y1) this.X;
                y1Var.B0 = null;
                y1Var.drawableStateChanged();
                return;
            case 2:
                SearchView$SearchAutoComplete searchView$SearchAutoComplete = (SearchView$SearchAutoComplete) this.X;
                if (searchView$SearchAutoComplete.f1212v0) {
                    ((InputMethodManager) searchView$SearchAutoComplete.getContext().getSystemService("input_method")).showSoftInput(searchView$SearchAutoComplete, 0);
                    searchView$SearchAutoComplete.f1212v0 = false;
                    return;
                }
                return;
            case 3:
                ActionMenuView actionMenuView = ((Toolbar) this.X).f1236e;
                if (actionMenuView == null || (nVar = actionMenuView.J0) == null) {
                    return;
                }
                nVar.n();
                return;
            case 4:
                androidx.core.widget.d dVar = (androidx.core.widget.d) this.X;
                y1 y1Var2 = dVar.Y;
                androidx.core.widget.a aVar = dVar.f1619e;
                if (dVar.B0) {
                    if (dVar.f1627z0) {
                        dVar.f1627z0 = false;
                        long jCurrentAnimationTimeMillis = AnimationUtils.currentAnimationTimeMillis();
                        aVar.f1615e = jCurrentAnimationTimeMillis;
                        aVar.f1616g = -1L;
                        aVar.f = jCurrentAnimationTimeMillis;
                        aVar.h = 0.5f;
                    }
                    if ((aVar.f1616g > 0 && AnimationUtils.currentAnimationTimeMillis() > aVar.f1616g + ((long) aVar.f1617i)) || !dVar.e()) {
                        dVar.B0 = false;
                        return;
                    }
                    if (dVar.A0) {
                        dVar.A0 = false;
                        long jUptimeMillis = SystemClock.uptimeMillis();
                        MotionEvent motionEventObtain = MotionEvent.obtain(jUptimeMillis, jUptimeMillis, 3, 0.0f, 0.0f, 0);
                        y1Var2.onTouchEvent(motionEventObtain);
                        motionEventObtain.recycle();
                    }
                    if (aVar.f == 0) {
                        throw new RuntimeException("Cannot compute scroll delta before calling start()");
                    }
                    long jCurrentAnimationTimeMillis2 = AnimationUtils.currentAnimationTimeMillis();
                    float fA = aVar.a(jCurrentAnimationTimeMillis2);
                    long j10 = jCurrentAnimationTimeMillis2 - aVar.f;
                    aVar.f = jCurrentAnimationTimeMillis2;
                    dVar.D0.scrollListBy((int) (j10 * ((fA * 4.0f) + ((-4.0f) * fA * fA)) * aVar.f1614d));
                    WeakHashMap weakHashMap = q0.f12703a;
                    y1Var2.postOnAnimation(this);
                    return;
                }
                return;
            case 5:
                w wVar = (w) this.X;
                ValueAnimator valueAnimator = wVar.f3151z;
                int i14 = wVar.A;
                if (i14 == 1) {
                    valueAnimator.cancel();
                } else if (i14 != 2) {
                    return;
                }
                wVar.A = 3;
                valueAnimator.setFloatValues(((Float) valueAnimator.getAnimatedValue()).floatValue(), 0.0f);
                valueAnimator.setDuration(500);
                valueAnimator.start();
                return;
            case 6:
                ((StaggeredGridLayoutManager) this.X).D0();
                return;
            case 7:
                if (((j) this.X).c(new IOException("TIMEOUT"))) {
                    Log.w("Rpc", "No response");
                    return;
                }
                return;
            case 8:
                try {
                    super/*android.app.Activity*/.onBackPressed();
                    return;
                } catch (IllegalStateException e3) {
                    if (!TextUtils.equals(e3.getMessage(), "Can not perform this action after onSaveInstanceState")) {
                        throw e3;
                    }
                    return;
                } catch (NullPointerException e10) {
                    if (!TextUtils.equals(e10.getMessage(), "Attempt to invoke virtual method 'android.os.Handler android.app.FragmentHostCallback.getHandler()' on a null object reference")) {
                        throw e10;
                    }
                    return;
                }
            case 9:
                co.a aVar2 = (co.a) this.X;
                aVar2.f4577w0 = false;
                aVar2.C();
                return;
            case 10:
                cb.j jVar = (cb.j) this.X;
                try {
                    SQLiteDatabase sQLiteDatabaseY2 = jVar.y2();
                    ContentValues contentValues = new ContentValues();
                    contentValues.put("elapsed_time", (Long) 0L);
                    sQLiteDatabaseY2.update("raw_events", contentValues, null, null);
                    return;
                } catch (SQLiteException e11) {
                    p0 p0Var = ((k1) jVar.X).f4205s0;
                    k1.h(p0Var);
                    p0Var.f4284t0.b(e11, "Failed to remove elapsed times from raw events table");
                    return;
                }
            case r.NETWORK_CLIENT_ERROR_REASON_FIELD_NUMBER /* 11 */:
                ((v0) this.X).f4362a.I();
                return;
            case r.CUSTOM_ATTRIBUTES_FIELD_NUMBER /* 12 */:
                k3 k3Var = ((j3) this.X).Y;
                k3Var.S1(new ComponentName(((k1) k3Var.X).f4203e, "com.google.android.gms.measurement.AppMeasurementService"));
                return;
            case r.PERF_SESSIONS_FIELD_NUMBER /* 13 */:
                k3 k3Var2 = ((j3) ((r0.f) this.X).Y).Y;
                j1 j1Var = ((k1) k3Var2.X).f4206t0;
                k1.h(j1Var);
                j1Var.Q1(new i3(k3Var2, i13));
                return;
            case 14:
                q3 q3Var = (q3) this.X;
                t3 t3Var = (t3) q3Var.Y.Y;
                t3Var.H1();
                k1 k1Var = (k1) t3Var.X;
                p0 p0Var2 = k1Var.f4205s0;
                Context context = k1Var.f4203e;
                k1.h(p0Var2);
                p0Var2.A0.a("Application going to the background");
                z0 z0Var = k1Var.f4204r0;
                k1.f(z0Var);
                z0Var.G0.b(true);
                t3Var.H1();
                t3Var.f4327r0 = true;
                cb.e eVar = k1Var.Z;
                if (!eVar.W1()) {
                    long j11 = q3Var.X;
                    s3 s3Var = t3Var.f4329t0;
                    s3Var.a(j11, false, false);
                    ((r3) s3Var.Y).c();
                }
                long j12 = q3Var.f4313e;
                k1.h(p0Var2);
                p0Var2.f4289z0.b(Long.valueOf(j12), "Application backgrounded at: timestamp_millis");
                p2 p2Var = k1Var.f4211z0;
                k1.g(p2Var);
                p2Var.H1();
                k1 k1Var2 = (k1) p2Var.X;
                p2Var.I1();
                k3 k3VarK = k1Var2.k();
                k3VarK.H1();
                k3VarK.I1();
                if (k3VarK.O1()) {
                    j4 j4Var = ((k1) k3VarK.X).f4207v0;
                    k1.f(j4Var);
                    if (j4Var.u2() >= 242600) {
                        k3 k3VarK2 = k1Var2.k();
                        k3VarK2.H1();
                        k3VarK2.I1();
                        k3VarK2.V1(new f3(k3VarK2, k3VarK2.X1(true), i12));
                    }
                } else {
                    k3 k3VarK3 = k1Var2.k();
                    k3VarK3.H1();
                    k3VarK3.I1();
                    k3VarK3.V1(new f3(k3VarK3, k3VarK3.X1(true), i12));
                }
                if (eVar.S1(null, z.O0)) {
                    j4 j4Var2 = k1Var.f4207v0;
                    k1.f(j4Var2);
                    long jP1 = j4Var2.o2(context.getPackageName(), eVar.Z) ? 1000L : eVar.P1(context.getPackageName(), z.E);
                    k1.h(p0Var2);
                    p0Var2.B0.b(Long.valueOf(jP1), "[sgtm] Scheduling batch upload with minimum latency in millis");
                    k1.e(k1Var.H0);
                    k1Var.H0.L1(jP1);
                    return;
                }
                return;
            case WebSocketProtocol.B0_MASK_OPCODE /* 15 */:
                e4 e4Var = (e4) this.X;
                e4Var.j1().H1();
                e4Var.f4099x0 = new b1(e4Var);
                cb.j jVar2 = new cb.j(e4Var);
                jVar2.J1();
                e4Var.Y = jVar2;
                f1 f1Var = e4Var.f4093e;
                cb.e eVarA0 = e4Var.a0();
                ga.r.g(f1Var);
                eVarA0.f4084r0 = f1Var;
                m3 m3Var = new m3(e4Var);
                m3Var.J1();
                e4Var.f4097v0 = m3Var;
                cb.c cVar = new cb.c(e4Var);
                cVar.J1();
                e4Var.f4095s0 = cVar;
                t0 t0Var = new t0(e4Var, i12);
                t0Var.J1();
                e4Var.u0 = t0Var;
                x3 x3Var = new x3(e4Var);
                x3Var.J1();
                e4Var.f4094r0 = x3Var;
                e4Var.Z = new v0(e4Var);
                if (e4Var.E0 != e4Var.F0) {
                    e4Var.a1().f4284t0.c(Integer.valueOf(e4Var.E0), Integer.valueOf(e4Var.F0), "Not all upload components initialized");
                }
                e4Var.f4101z0.set(true);
                e4Var.a1().B0.a("UploadController is now fully initialized");
                e4Var.j1().H1();
                cb.j jVar3 = e4Var.Y;
                e4.P(jVar3);
                jVar3.R1();
                cb.j jVar4 = e4Var.Y;
                e4.P(jVar4);
                jVar4.H1();
                jVar4.I1();
                if (jVar4.s2()) {
                    y yVar = z.f4469v0;
                    if (((Long) yVar.a(null)).longValue() != 0) {
                        SQLiteDatabase sQLiteDatabaseY3 = jVar4.y2();
                        k1 k1Var3 = (k1) jVar4.X;
                        k1Var3.f4209x0.getClass();
                        int iDelete = sQLiteDatabaseY3.delete("trigger_uris", "abs(timestamp_millis - ?) > cast(? as integer)", new String[]{String.valueOf(System.currentTimeMillis()), String.valueOf(yVar.a(null))});
                        if (iDelete > 0) {
                            p0 p0Var3 = k1Var3.f4205s0;
                            k1.h(p0Var3);
                            p0Var3.B0.b(Integer.valueOf(iDelete), "Deleted stale trigger uris. rowsDeleted");
                        }
                    }
                }
                if (e4Var.f4097v0.f4250v0.e() == 0) {
                    x0 x0Var = e4Var.f4097v0.f4250v0;
                    e4Var.d1().getClass();
                    x0Var.f(System.currentTimeMillis());
                }
                e4Var.I();
                return;
            case WebSocketProtocol.B0_FLAG_RSV3 /* 16 */:
                k1 k1Var4 = (k1) ((androidx.appcompat.app.z) this.X).f1150b;
                k1.e(k1Var4.H0);
                k1Var4.H0.L1(((Long) z.D.a(null)).longValue());
                return;
            case 17:
                k1 k1Var5 = (k1) this.X;
                j4 j4Var3 = k1Var5.f4207v0;
                p2 p2Var2 = k1Var5.f4211z0;
                k1.f(j4Var3);
                j4Var3.H1();
                if (j4Var3.g2() != 1) {
                    p0 p0Var4 = k1Var5.f4205s0;
                    k1.h(p0Var4);
                    p0Var4.f4286w0.a("registerTrigger called but app not eligible");
                    return;
                }
                k1.g(p2Var2);
                p2Var2.H1();
                c2 c2Var = p2Var2.f4302z0;
                if (c2Var != null) {
                    c2Var.c();
                }
                k1.g(p2Var2);
                new Thread(new b2(p2Var2, i11)).start();
                return;
            case 18:
                com.bumptech.glide.n nVar2 = (com.bumptech.glide.n) this.X;
                nVar2.Y.f(nVar2);
                return;
            case 19:
                CheckableImageButton checkableImageButton = ((TextInputLayout) this.X).f6175s0.f6229w0;
                checkableImageButton.performClick();
                checkableImageButton.jumpDrawablesToCurrentState();
                return;
            case 20:
                Worker worker = (Worker) this.X;
                try {
                    worker.f3264r0.i(worker.g());
                    return;
                } catch (Throwable th2) {
                    worker.f3264r0.j(th2);
                    return;
                }
            case 21:
                ((ea.j) this.X).a();
                return;
            case 22:
                ea.j jVar5 = (ea.j) ((z7.c) this.X).X;
                ((ga.f) jVar5.f7717e).f(jVar5.f7717e.getClass().getName().concat(" disconnecting because it was signed out."));
                return;
            case 23:
                ((t) this.X).f7746k.d(new ConnectionResult(4, null, null));
                return;
            case 24:
                throw null;
            case 25:
                fb.a aVar3 = (fb.a) this.X;
                synchronized (aVar3.f8079a) {
                    try {
                        if (aVar3.b()) {
                            Log.e("WakeLock", String.valueOf(aVar3.f8086j).concat(" ** IS FORCE-RELEASED ON TIMEOUT **"));
                            aVar3.d();
                            if (aVar3.b()) {
                                aVar3.f8081c = 1;
                                aVar3.e();
                                return;
                            }
                            return;
                        }
                        return;
                    } catch (Throwable th3) {
                        throw th3;
                    }
                }
            case 26:
                a();
                return;
            case 27:
                q4 q4Var = (q4) this.X;
                yn.c cVar2 = q4Var.f9263x1;
                if (cVar2 != null && (i10 = cVar2.f23134t0) >= 0) {
                    ((RecyclerView) q4Var.h0().f7143m).h0(i10);
                }
                yn.c cVar3 = q4Var.f9263x1;
                if (cVar3 != null) {
                    cVar3.f23134t0 = -1;
                    return;
                }
                return;
            case 28:
                ((ho.z0) this.X).n0().e();
                return;
            default:
                s sVar = ((ho.b2) this.X).f10297q1;
                if (sVar != null) {
                    sVar.f7170z.scrollTo(0, 0);
                    return;
                } else {
                    q.n("binding");
                    throw null;
                }
        }
    }

    public d(v0 v0Var, boolean z5) {
        this.f583e = 11;
        this.X = v0Var;
    }

    public d(e4 e4Var, f4 f4Var) {
        this.f583e = 15;
        this.X = e4Var;
    }

    public d(ea.h hVar, c0 c0Var) {
        this.f583e = 24;
        Objects.requireNonNull(hVar);
        this.X = c0Var;
    }

    public d(t tVar) {
        this.f583e = 23;
        Objects.requireNonNull(tVar);
        this.X = tVar;
    }
}
