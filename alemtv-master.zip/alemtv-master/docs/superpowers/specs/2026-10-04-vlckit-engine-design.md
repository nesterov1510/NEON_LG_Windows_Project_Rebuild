# AlemTV для Apple TV: единый движок воспроизведения VLCKit

Дата: 2026-10-04
Статус: черновик на ревью
Дополняет: `2026-10-03-alemtv-tvos-design.md`. Заменяет его разделы §4.3 (форматы URL), §4.6 (плеер) и строки §5 про управление плеером.

## 1. Зачем

Проверка всех 225 каналов (`docs/owners/AlemTV-AppleTV-форматы-каналов.md`) показала, что AVPlayer на Apple TV не воспроизводит около 45 % каналов:

| Видео | Звук | Каналов | AVPlayer |
|---|---|---|---|
| HEVC | AAC | 108 | только через fMP4 (в TS — только звук) |
| H.264 | AAC | 13 | играет |
| HEVC | MP2 | 18 | не играет (MP2 не поддерживается Apple) |
| H.264 | MP2 | 79 | не играет |
| MPEG-2 | MP2 | 3 | не играет |

**Требования пользователя:**
1. Один движок для всех форматов, без переключения между движками.
2. Не обязательно повторять Android: выбрать лучшую практику для Apple TV.

**Спайк (2026-10-04).** VLCKit 4.0.0-a25 через официальный SPM в симуляторе tvOS 26.5 играет в TS все пять типов каналов, а также архив `index-S-D.m3u8` и таймшифт `video-timeshift_rel-B.m3u8`.

Рассмотрены и отклонены:
- TVVLCKit 3.7.4: только CocoaPods; остаётся запасным вариантом;
- KSPlayer: GPL, нужные функции платные;
- MPVKit: по словам авторов, «для обучения»;
- локальный ремукс с перекодированием для AVPlayer: дорого и хрупко.

## 2. Решения

- **Движок — VLCKit 4** (`https://github.com/videolan/vlckit.git`, `exactVersion: 4.0.0-a25`, продукт `VLCKit`). Лицензия LGPL 2.1+. Подключается **только к таргету приложения**: AlemCore не зависит от VLCKit, и `swift test` остаётся быстрым.
- **Все каналы в TS.** Эфир — `path` канала как есть (`…/video.m3u8`), архив — `{timeshift}/index-{S}-{D}.m3u8`, таймшифт — `{timeshift}/video-timeshift_rel-{B}.m3u8`. Токены прежние (составной `token`).
- **Удаляются:** `StreamFormat`, `StreamFormatResolver`, fMP4-адреса, `AVPlayerEngine`, `AVPlayerViewController`, `PlayerContainer` с распознавателями жестов и делегатом, политика «панель видна — пульт системе».
- **ATS** остаётся `NSAllowsArbitraryLoads` (порталы и стримеры только HTTP; VLC ходит в сеть сам, но приложение — через URLSession).

## 3. Архитектура

```
AlemCore
├─ Playback/PlayerEngine.swift      протокол (без AVFoundation)
├─ Playback/PlaybackPolicy.swift    пульт (новая схема), перемотка, фон
├─ Playback/ContentClock.swift      НОВОЕ: время показываемого кадра
├─ Playback/OverlayTimer.swift      НОВОЕ: автоскрытие панели
├─ Playback/AudioTrackChoice.swift  НОВОЕ: выбор дорожки по запомненному языку
├─ Playback/FreezeWatchdog.swift, IdleMonitor.swift   без изменений
└─ Streams/StreamURLBuilder.swift   только TS

App
├─ Features/Player/VLCPlayerEngine.swift   PlayerEngine на VLCMediaPlayer
├─ Features/Player/VideoSurface.swift      UIViewRepresentable (drawable, не фокусируется)
├─ Features/Player/PlayerScreen.swift      видео + оверлеи + обработка пульта
├─ Features/Player/TransportOverlay.swift  НОВОЕ: панель (верх, шкала, кнопки)
├─ Features/Player/ScheduleOverlay.swift   НОВОЕ: программа на сегодня поверх видео
├─ Features/Player/ChannelListOverlay.swift, PlayerModel.swift  адаптируются
└─ Features/Player/DisplayCriteria.swift   НОВОЕ: частота кадров экрана
```

### 3.1 PlayerEngine (протокол)

```swift
@MainActor public protocol PlayerEngine: AnyObject {
    var state: PlaybackState { get }              // idle, loading, playing, paused, failed(String), ended
    var mediaTime: TimeInterval { get }           // время плеера (только для seek в архиве)
    var videoSize: CGSize { get }
    var audioTracks: [AudioTrack] { get }         // AudioTrack: id, name, language
    var selectedAudioTrackID: String? { get }
    func load(_ url: URL)
    func play()
    func pause()
    func seek(to seconds: TimeInterval)
    func selectAudioTrack(id: String)
    func stop()
}
```

Колбэки: `onStateChange(PlaybackState)` и `onTracksChanged`. Сторож зависаний вызывается движком по таймеру (1 с): позиция берётся из `ContentClock`, а «буфер не успевает» — это состояние `buffering`.

### 3.2 ContentClock (чистая логика, тесты)

Состояние: режим запуска (`StreamMode`), `startedAt` (серверное время запуска), `played` (накопленное время воспроизведения).

- События `didStartPlaying(at:)` и `didStopPlaying(at:)` (пауза, буферизация, ошибка) накапливают `played` по часам.
- Время кадра:
  - архив `(S, D)`: `S + played` (после seek `played = позиция`);
  - таймшифт `B`: `startedAt − B + played`;
  - эфир: `now − liveLatency` (`liveLatency = 20 с`).
- Отставание от эфира: `now − время кадра`. В эфире оно равно `liveLatency`, и плашку не показываем.

`PlaybackPolicy.skip`, `referenceTime` и пауза в эфире работают от этого времени.

### 3.3 VLCPlayerEngine

- `VLCMediaPlayer` и `drawable` = `UIView` из `VideoSurface` (`isUserInteractionEnabled = false`, не фокусируется).
- Опции `VLCMedia`: `network-caching=1500`, `live-caching=1500`. Аппаратное декодирование по умолчанию (VideoToolbox).
- Состояния VLC переводятся в `PlaybackState`:
  - `opening` / `buffering` → `loading`;
  - `playing` → `playing`;
  - `paused` → `paused`;
  - `error` → `failed`;
  - `stopped` без нашей команды → `failed`, для архива — `ended`, если позиция у конца.
- `failed` сообщается один раз на загрузку (как сейчас).
- Аудиосессия: `.playback` активируется при `load`.

### 3.4 Частота кадров

После первого `videoSize > 0` выставляется `view.window.avDisplayManager.preferredDisplayCriteria = AVDisplayCriteria(refreshRate: 25, videoDynamicRange: .sdr)`; для HD-каналов частота — из потока, если VLC её отдаёт, иначе 25. При уходе из плеера (гид, фон) критерии сбрасываются.

## 4. Панель и пульт

Два состояния плеера: **просмотр** и **панель**. Оверлеи (список каналов, программа, ошибка, вопрос «Продолжить?») имеют приоритет над обоими.

**Просмотр:**

| Пульт | Действие |
|---|---|
| ↑ / ↓ | предыдущий / следующий канал рубрики (в архиве — ничего) |
| ← | боковой список каналов (в архиве — −10 с) |
| → | в архиве и таймшифте — +10 с, в эфире — ничего |
| Select | показать панель |
| Play/Pause | пауза; продолжение в эфире после паузы > 45 с — таймшифт |
| Menu | гид |

**Панель** (автоскрытие через 5 с без нажатий; Menu закрывает):
- **Верх:** логотип и номер канала, название передачи, её время.
- **Шкала:**
  - архив: позиция внутри передачи;
  - эфир и таймшифт: прогресс текущей передачи и метка «−ЧЧ:ММ:СС от эфира».
- **Кнопки** (фокус ←/→, нажатие Select): «−10 с», «⏯», «+10 с», «В эфир» (не в эфире), «С начала» (есть архив и текущая передача), «Звук» (дорожек > 1), «Программа».
- **«Звук»** открывает список дорожек с языком. Выбор запоминается (`UserDefaults`, `audio.language`) и применяется к следующим каналам, если язык есть (`AudioTrackChoice`).
- **«Программа»** открывает `ScheduleOverlay`: передачи канала на сегодня, текущая отмечена. Select на прошедшей в архиве передаче — запуск архива, на текущей — эфир.

## 5. Ошибки

Без изменений по сути (spec §6). Лестница повторов, сторож зависаний, оверлей «Канал недоступен» с «Повтор» и «Каналы», Menu в гид. В лог пишутся только хост и путь.

## 6. Тестирование

- **Юнит (AlemCore):**
  - `ContentClock`: архив, таймшифт, эфир, паузы и буферизация, seek;
  - `StreamURLBuilder` в TS;
  - `PlaybackPolicy` (новая таблица пульта для двух состояний и архива);
  - `AudioTrackChoice`;
  - `OverlayTimer`.
- **Симулятор (скрипт, `tools/smoke_channels.sh`):**
  - запуск с отладочным параметром `-debugChannelID <id>` (только DEBUG) по 5 типам каналов, архиву и таймшифту;
  - критерий: в логе «playing» и размер кадра > 0 за 15 с.
- **Живой тест:** PMT потока содержит видео и аудио, `scrambling_control = 0`.
- **Чек-лист устройства:** панель и пульт, звуковые дорожки (Т24), 20–30 каналов включая MP2, час HEVC 1080p (нагрев, плавность), частота кадров 25.

## 7. Риски

1. **VLCKit 4 — alpha.** API может меняться. Версия фиксирована, движок за протоколом. Запасной путь — TVVLCKit 3.7.4 (CocoaPods) с тем же протоколом.
2. **Размер приложения:** около +94 МБ в отладочной сборке; в релизной под arm64 меньше.
3. **Известные жалобы на HEVC в HLS на tvOS** в трекере VLCKit. На наших потоках в симуляторе не воспроизвелось; проверка на устройстве — пункт чек-листа.
4. **Время кадра в эфире — оценка** (задержка 20 с). Неточность в пределах одного сегмента на плашку не влияет: она показывается только в таймшифте.
5. **App Store:** обязательства LGPL (указать VLCKit, его лицензию и исходники используемой версии в «О приложении»).
