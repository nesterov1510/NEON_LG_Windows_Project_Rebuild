# AlemTV для Apple TV: план реализации

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Нативное tvOS-приложение для абонентов AlemTV (IPTVPORTAL) с эфиром, EPG, архивом и таймшифтом, функционально повторяющее Android-приложение `iptvportal.alemtv`.

**Architecture:** Логика лежит в локальном Swift Package `AlemCore` без UI:
- Ares-Cipher;
- JSON-RPC клиент портала;
- модели;
- сессия;
- EPG;
- сборка URL Flussonic;
- движок плеера на AVFoundation.

tvOS-таргет `AlemTV` на SwiftUI использует AlemCore через `@Observable` модели `AppModel` и `PlayerModel`. Видео играет `AVPlayerViewController`. Проект Xcode генерируется XcodeGen из `project.yml`.

**Tech Stack:** Swift 6, SwiftUI, AVKit/AVFoundation, CommonCrypto, Security.framework, Network.framework, Swift Testing, XcodeGen, Xcode 26.5. Python 3 только для служебных скриптов.

**Spec:** `docs/superpowers/specs/2026-10-03-alemtv-tvos-design.md`. Протокол: `reference/PORTAL_ANALYSIS.md`, `reference/WIKI_NOTES.md`.

## Global Constraints

- Платформа tvOS, deployment target `17.0`. Целевое устройство — Apple TV 4K.
- Swift language mode 6 (строгая конкурентность). Сторонних зависимостей нет: ни SPM-пакетов, ни VLCKit.
- Bundle ID `com.alexvamp.alemtv`. Команда подписи (`DEVELOPMENT_TEAM`) задаётся пользователем в Xcode, в репозиторий не коммитится.
- Языки интерфейса: `ru` (по умолчанию), `tk`, `en`.
- Портал по умолчанию `http://telecom.alemtv.tm`. Альтернативы: `astu.tmalem.tv`, `ark.alemtv.tm`, `local-astu.alemtv.tm`.
- `terminal_type` = `"appletv"`.
- Акцентный цвет `#FF8800`, тема тёмная.
- В лог (`os.Logger`) и в ответы никогда не попадают `session_id`, `token1/token2`, пароль и MAC.
- `.credentials`, `reference/samples/`, `reference/portal/`, `reference/x/`, `reference/decompiled/` и `*.xcodeproj` не коммитятся.
- Тесты AlemCore: `swift test --package-path Packages/AlemCore`. Сборка приложения: `xcodegen generate && xcodebuild -project AlemTV.xcodeproj -scheme AlemTV -destination 'generic/platform=tvOS Simulator' build`.
- Коммиты оформляются с атрибуцией:
  ```
  Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>
  Claude-Session: https://claude.ai/code/session_015tkg9WmfzBtZ6B6QQFpCUA
  ```

## Review Focus

1. **Плейлисты ссылаются на каналы, которых нет в `medialist`.** В реальном `tv` 314 id, а каналов 219. Такие id нужно молча пропускать, без падения и пустых карточек. Тест в Task 4: `channelsInPlaylistSkipUnknownIDs`.
2. **Протухшая сессия в `check_update`.** Сервер не возвращает ошибку, а просто опускает поле `authorized`. Это нужно считать «не авторизован» и выполнить повторный вход. Тест в Task 8: `refreshReauthorizesWhenAuthorizedMissing`.
3. **Ротация токенов при многочасовом просмотре.** Новые `tokens` из `check_update` должны попадать в следующий собранный URL без перезагрузки каталога. Тест в Task 8: `refreshReplacesTokensWithoutReload`.
4. **Канал без архива или без EPG.** Архив не предлагается, `StreamURLBuilder` бросает `.noArchive`, EPG — пустой список, а не ошибка. Тесты в Task 5 (`archiveWithoutTimeshiftURLThrows`) и Task 7 (`emptyDayIsCachedNotError`).
5. **Границы суток в зоне сервера +05:00 и не-ASCII в шифрованных запросах.** День EPG считается в зоне сервера, а не устройства; кириллица и туркменские буквы в логине и пароле шифруются как UTF-8. Тесты в Task 3 (`cyrillicIsUTF8`) и Task 4 (`dayStringUsesServerZone`).

---

## Структура файлов

```
AlemTV/
├─ project.yml                         XcodeGen-описание проекта
├─ README.md                           как собрать и запустить
├─ App/                                tvOS-таргет
│  ├─ Info.plist                       ATS, CFBundleLocalizations
│  ├─ AlemTVApp.swift                  @main, окружение
│  ├─ Brand.swift                      цвета
│  ├─ Strings.swift                    локализация с выбором языка в рантайме
│  ├─ PortalOption.swift               список порталов, логотипы каналов
│  ├─ AppModel.swift                   маршрут, сессия, каталог, избранное, язык, профиль, сеть
│  ├─ RootView.swift                   переключение экранов
│  ├─ Features/Launch/LaunchView.swift
│  ├─ Features/Launch/OfflineView.swift
│  ├─ Features/Login/LoginView.swift
│  ├─ Features/Login/PortalPickerView.swift
│  ├─ Features/Guide/GuideView.swift          таб-бар
│  ├─ Features/Channels/ChannelsTab.swift      плейлисты и сетка
│  ├─ Features/Channels/ChannelCard.swift
│  ├─ Features/Channels/ChannelLogo.swift
│  ├─ Features/Channels/FavoritesTab.swift
│  ├─ Features/EPG/ScheduleView.swift
│  ├─ Features/Player/PlayerModel.swift
│  ├─ Features/Player/PlayerScreen.swift       ZStack: плеер и оверлеи
│  ├─ Features/Player/PlayerContainer.swift    AVPlayerViewController-мост
│  ├─ Features/Player/ChannelListOverlay.swift
│  ├─ Features/Player/ProgramInfoView.swift
│  ├─ Features/Settings/SettingsView.swift
│  └─ Resources/Localizable.xcstrings, Assets.xcassets
├─ Packages/AlemCore/
│  ├─ Package.swift
│  ├─ Sources/AlemCore/
│  │  ├─ JSON/JSONValue.swift, JSON/CSVTable.swift
│  │  ├─ Crypto/AresCipher.swift
│  │  ├─ Time/PortalDate.swift, Time/ServerClock.swift
│  │  ├─ Models/Channel.swift, Playlist.swift, Program.swift, Account.swift, Responses.swift
│  │  ├─ API/HTTPTransport.swift, API/PortalError.swift, API/PortalClient.swift
│  │  ├─ Streams/StreamURLBuilder.swift
│  │  ├─ EPG/EPGStore.swift
│  │  ├─ Session/SecureStore.swift, Session/SessionStore.swift
│  │  └─ Playback/FreezeWatchdog.swift, IdleMonitor.swift, PlayerEngine.swift
│  └─ Tests/AlemCoreTests/
│     ├─ Fixtures/*.json               обезличенные ответы сервера (генерирует tools/anonymize.py)
│     ├─ Support/Fixture.swift, MockTransport.swift, MockPortalAPI.swift
│     └─ *Tests.swift
├─ tools/probe.py                      (есть) ручная проверка протокола
├─ tools/anonymize.py                  samples → фикстуры
├─ tools/gen_strings.py                таблица переводов → Localizable.xcstrings
├─ tools/make_brand_assets.py          alem.png → иконки и top shelf
└─ docs/manual-test-checklist.md
```

---

### Task 1: Каркас проекта: пакет AlemCore и tvOS-приложение

**Files:**
- Create: `Packages/AlemCore/Package.swift`
- Create: `Packages/AlemCore/Sources/AlemCore/AlemCore.swift`
- Create: `Packages/AlemCore/Tests/AlemCoreTests/SmokeTests.swift`
- Create: `project.yml`, `App/Info.plist`, `App/AlemTVApp.swift`, `README.md`
- Modify: `.gitignore`

**Interfaces:**
- Consumes: —
- Produces: модуль `AlemCore` (`public enum AlemCore { static let version: String }`), таргет `AlemTV`, схема `AlemTV`.

- [ ] **Step 1: Установить инструменты**

Run:
```bash
brew install xcodegen
xcodebuild -downloadPlatform tvOS   # runtime симулятора tvOS (~4–5 ГБ), нужен для запуска; для сборки не обязателен
```
Expected: `xcodegen --version` печатает версию. `xcrun simctl list runtimes | grep tvOS` показывает tvOS 26.x (после загрузки).

- [ ] **Step 2: Написать падающий smoke-тест**

`Packages/AlemCore/Tests/AlemCoreTests/SmokeTests.swift`:
```swift
import Testing
@testable import AlemCore

@Test func versionIsSet() {
    #expect(AlemCore.version == "0.1.0")
}
```

`Packages/AlemCore/Package.swift`:
```swift
// swift-tools-version: 6.0
import PackageDescription

let package = Package(
    name: "AlemCore",
    platforms: [.tvOS(.v17), .macOS(.v14)],
    products: [.library(name: "AlemCore", targets: ["AlemCore"])],
    targets: [
        .target(name: "AlemCore"),
        .testTarget(
            name: "AlemCoreTests",
            dependencies: ["AlemCore"],
            resources: [.copy("Fixtures")]
        ),
    ]
)
```
Создать пустую папку фикстур, чтобы `resources` не падал: `mkdir -p Packages/AlemCore/Tests/AlemCoreTests/Fixtures && touch Packages/AlemCore/Tests/AlemCoreTests/Fixtures/.keep`.

- [ ] **Step 3: Запустить тест и убедиться, что он падает**

Run: `swift test --package-path Packages/AlemCore`
Expected: ошибка компиляции `cannot find 'AlemCore' in scope` (нет исходников).

- [ ] **Step 4: Минимальная реализация**

`Packages/AlemCore/Sources/AlemCore/AlemCore.swift`:
```swift
/// Ядро tvOS-клиента AlemTV: протокол IPTVPORTAL, сессия, EPG, потоки.
public enum AlemCore {
    public static let version = "0.1.0"
}
```

- [ ] **Step 5: Тест проходит**

Run: `swift test --package-path Packages/AlemCore`
Expected: `Test versionIsSet() passed`.

- [ ] **Step 6: Каркас приложения**

`project.yml`:
```yaml
name: AlemTV
options:
  bundleIdPrefix: com.alexvamp
  developmentLanguage: ru
  deploymentTarget:
    tvOS: "17.0"
packages:
  AlemCore:
    path: Packages/AlemCore
targets:
  AlemTV:
    type: application
    platform: tvOS
    sources:
      - App
    dependencies:
      - package: AlemCore
    settings:
      base:
        PRODUCT_BUNDLE_IDENTIFIER: com.alexvamp.alemtv
        PRODUCT_NAME: AlemTV
        MARKETING_VERSION: "0.1.0"
        CURRENT_PROJECT_VERSION: "1"
        SWIFT_VERSION: "6.0"
        GENERATE_INFOPLIST_FILE: YES
        INFOPLIST_FILE: App/Info.plist
        INFOPLIST_KEY_CFBundleDisplayName: "ALEM TV"
        TARGETED_DEVICE_FAMILY: "3"
        CODE_SIGN_STYLE: Automatic
schemes:
  AlemTV:
    build:
      targets:
        AlemTV: all
    run:
      config: Debug
```

`App/Info.plist` (сливается со сгенерированным):
```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>CFBundleLocalizations</key>
    <array>
        <string>ru</string>
        <string>tk</string>
        <string>en</string>
    </array>
    <key>NSAppTransportSecurity</key>
    <dict>
        <key>NSAllowsArbitraryLoadsForMedia</key>
        <true/>
        <key>NSExceptionDomains</key>
        <dict>
            <key>alemtv.tm</key>
            <dict>
                <key>NSIncludesSubdomains</key>
                <true/>
                <key>NSExceptionAllowsInsecureHTTPLoads</key>
                <true/>
            </dict>
            <key>tmalem.tv</key>
            <dict>
                <key>NSIncludesSubdomains</key>
                <true/>
                <key>NSExceptionAllowsInsecureHTTPLoads</key>
                <true/>
            </dict>
        </dict>
    </dict>
</dict>
</plist>
```

`App/AlemTVApp.swift` (временная заглушка, заменяется в Task 10):
```swift
import SwiftUI
import AlemCore

@main
struct AlemTVApp: App {
    var body: some Scene {
        WindowGroup {
            Text("ALEM TV \(AlemCore.version)")
        }
    }
}
```

Дописать в `.gitignore`:
```
# Генерируется XcodeGen из project.yml
*.xcodeproj/
.build/
.swiftpm/
```

`README.md`:
````markdown
# AlemTV для Apple TV

Нативный tvOS-клиент для абонентов AlemTV (платформа IPTVPORTAL).

## Сборка

```bash
brew install xcodegen
xcodegen generate
open AlemTV.xcodeproj   # выбрать свою команду в Signing & Capabilities
```

Тесты ядра: `swift test --package-path Packages/AlemCore`.
Живой интеграционный тест (нужны `.credentials` и привязанный терминал):
`ALEMTV_LIVE=1 swift test --package-path Packages/AlemCore --filter LiveIntegrationTests`.

Документы: `docs/superpowers/specs/`, `docs/superpowers/plans/`, `reference/*.md`.
````

- [ ] **Step 7: Собрать приложение**

Run:
```bash
xcodegen generate && xcodebuild -project AlemTV.xcodeproj -scheme AlemTV -destination 'generic/platform=tvOS Simulator' build | tail -3
```
Expected: `** BUILD SUCCEEDED **`.

- [ ] **Step 8: Commit**

```bash
git add project.yml App Packages README.md .gitignore
git commit -m "Каркас: пакет AlemCore и tvOS-приложение (XcodeGen)

Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>
Claude-Session: https://claude.ai/code/session_015tkg9WmfzBtZ6B6QQFpCUA"
```

---

### Task 2: JSONValue и разбор CSV-таблиц

Сервер отвечает разнородным JSON, а таблицы (`medialist`, `programs`) приходят как `[[заголовки], [строка], …]` (`result_as:"csv"`).

**Files:**
- Create: `Packages/AlemCore/Sources/AlemCore/JSON/JSONValue.swift`
- Create: `Packages/AlemCore/Sources/AlemCore/JSON/CSVTable.swift`
- Test: `Packages/AlemCore/Tests/AlemCoreTests/JSONValueTests.swift`

**Interfaces:**
- Produces:
  - `public enum JSONValue: Sendable, Hashable, Codable` с кейсами `null, bool(Bool), int(Int), double(Double), string(String), array([JSONValue]), object([String: JSONValue])`;
  - `subscript(key: String) -> JSONValue?`;
  - свойства `string: String?`, `int: Int?`, `double: Double?`, `bool: Bool?`, `array: [JSONValue]?`, `object: [String: JSONValue]?`, `isNull: Bool`;
  - литералы `ExpressibleBy…`;
  - `public enum CSVTable { static func rows(_ value: JSONValue?) -> [[String: JSONValue]] }`.

- [ ] **Step 1: Написать падающие тесты**

`Packages/AlemCore/Tests/AlemCoreTests/JSONValueTests.swift`:
```swift
import Testing
import Foundation
@testable import AlemCore

@Suite struct JSONValueTests {
    @Test func decodesMixedObject() throws {
        let json = #"{"a":1,"b":"x","c":null,"d":true,"e":[1.5,2],"f":{"g":"h"}}"#
        let v = try JSONDecoder().decode(JSONValue.self, from: Data(json.utf8))
        #expect(v["a"]?.int == 1)
        #expect(v["b"]?.string == "x")
        #expect(v["c"]?.isNull == true)
        #expect(v["d"]?.bool == true)
        #expect(v["e"]?.array?.first?.double == 1.5)
        #expect(v["f"]?["g"]?.string == "h")
        #expect(v["missing"] == nil)
    }

    @Test func numericCoercions() {
        #expect(JSONValue.string("3600").int == 3600)
        #expect(JSONValue.int(259200).double == 259200)
        #expect(JSONValue.double(10).int == 10)
        #expect(JSONValue.double(10.5).int == nil)
        #expect(JSONValue.string("x").int == nil)
    }

    @Test func encodesRoundTrip() throws {
        let v: JSONValue = ["jsonrpc": "2.0", "id": 7, "params": ["macaddr": nil, "flag": true, "ids": [1, 2]]]
        let data = try JSONEncoder().encode(v)
        let back = try JSONDecoder().decode(JSONValue.self, from: data)
        #expect(back == v)
    }

    @Test func csvRowsMapHeaderToCells() {
        let table: JSONValue = [["id", "name"], [1, "Altyn Asyr"], [2, "Miras"], "garbage"]
        let rows = CSVTable.rows(table)
        #expect(rows.count == 2)
        #expect(rows[0]["id"]?.int == 1)
        #expect(rows[1]["name"]?.string == "Miras")
    }

    @Test func csvRowsOfNonTableIsEmpty() {
        #expect(CSVTable.rows(nil).isEmpty)
        #expect(CSVTable.rows(.string("x")).isEmpty)
        #expect(CSVTable.rows([["id"]]).isEmpty)
    }
}
```

- [ ] **Step 2: Тесты падают**

Run: `swift test --package-path Packages/AlemCore --filter JSONValueTests`
Expected: ошибка компиляции `cannot find type 'JSONValue'`.

- [ ] **Step 3: Реализация**

`Packages/AlemCore/Sources/AlemCore/JSON/JSONValue.swift`:
```swift
import Foundation

/// Произвольное JSON-значение ответа портала.
public enum JSONValue: Sendable, Hashable {
    case null
    case bool(Bool)
    case int(Int)
    case double(Double)
    case string(String)
    case array([JSONValue])
    case object([String: JSONValue])

    public subscript(key: String) -> JSONValue? {
        if case .object(let object) = self { return object[key] }
        return nil
    }

    public var string: String? {
        if case .string(let s) = self { return s }
        return nil
    }

    /// Целое; принимает и числовые строки ("3600"), и целые double.
    public var int: Int? {
        switch self {
        case .int(let i): return i
        case .double(let d): return d.rounded() == d ? Int(d) : nil
        case .string(let s): return Int(s)
        default: return nil
        }
    }

    public var double: Double? {
        switch self {
        case .int(let i): return Double(i)
        case .double(let d): return d
        case .string(let s): return Double(s)
        default: return nil
        }
    }

    public var bool: Bool? {
        switch self {
        case .bool(let b): return b
        case .int(let i): return i != 0
        default: return nil
        }
    }

    public var array: [JSONValue]? {
        if case .array(let a) = self { return a }
        return nil
    }

    public var object: [String: JSONValue]? {
        if case .object(let o) = self { return o }
        return nil
    }

    public var isNull: Bool { self == .null }
}

extension JSONValue: Codable {
    public init(from decoder: Decoder) throws {
        let c = try decoder.singleValueContainer()
        if c.decodeNil() { self = .null }
        else if let b = try? c.decode(Bool.self) { self = .bool(b) }
        else if let i = try? c.decode(Int.self) { self = .int(i) }
        else if let d = try? c.decode(Double.self) { self = .double(d) }
        else if let s = try? c.decode(String.self) { self = .string(s) }
        else if let a = try? c.decode([JSONValue].self) { self = .array(a) }
        else if let o = try? c.decode([String: JSONValue].self) { self = .object(o) }
        else {
            throw DecodingError.dataCorruptedError(in: c, debugDescription: "Unsupported JSON value")
        }
    }

    public func encode(to encoder: Encoder) throws {
        var c = encoder.singleValueContainer()
        switch self {
        case .null: try c.encodeNil()
        case .bool(let b): try c.encode(b)
        case .int(let i): try c.encode(i)
        case .double(let d): try c.encode(d)
        case .string(let s): try c.encode(s)
        case .array(let a): try c.encode(a)
        case .object(let o): try c.encode(o)
        }
    }
}

extension JSONValue: ExpressibleByNilLiteral, ExpressibleByBooleanLiteral, ExpressibleByIntegerLiteral,
    ExpressibleByFloatLiteral, ExpressibleByStringLiteral, ExpressibleByArrayLiteral, ExpressibleByDictionaryLiteral {
    public init(nilLiteral: ()) { self = .null }
    public init(booleanLiteral value: Bool) { self = .bool(value) }
    public init(integerLiteral value: Int) { self = .int(value) }
    public init(floatLiteral value: Double) { self = .double(value) }
    public init(stringLiteral value: String) { self = .string(value) }
    public init(arrayLiteral elements: JSONValue...) { self = .array(elements) }
    public init(dictionaryLiteral elements: (String, JSONValue)...) {
        self = .object(Dictionary(elements, uniquingKeysWith: { _, last in last }))
    }
}
```

`Packages/AlemCore/Sources/AlemCore/JSON/CSVTable.swift`:
```swift
/// Таблица `result_as:"csv"`: первая строка — имена колонок, остальные — значения.
public enum CSVTable {
    public static func rows(_ value: JSONValue?) -> [[String: JSONValue]] {
        guard let table = value?.array, let header = table.first?.array else { return [] }
        let names = header.map { $0.string ?? "" }
        return table.dropFirst().compactMap { row in
            guard let cells = row.array else { return nil }
            var dict: [String: JSONValue] = [:]
            for (i, name) in names.enumerated() where i < cells.count && !name.isEmpty {
                dict[name] = cells[i]
            }
            return dict
        }
    }
}
```

- [ ] **Step 4: Тесты проходят**

Run: `swift test --package-path Packages/AlemCore --filter JSONValueTests`
Expected: 5 тестов passed.

- [ ] **Step 5: Commit**

```bash
git add Packages/AlemCore
git commit -m "AlemCore: JSONValue и разбор CSV-таблиц портала

Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>
Claude-Session: https://claude.ai/code/session_015tkg9WmfzBtZ6B6QQFpCUA"
```

---

### Task 3: AresCipher: шифрование login и register_terminal

Схема (`PORTAL_ANALYSIS.md` §1.2):
1. Случайный 16-байтный ключ K.
2. 46-байтный заголовок `<H16s8s8sHHHHL` (`1,"aes","cbc","base64",128,16,46,62,unix_ts`), затем K, затем IV `"arescrypt"` и 7 пробелов. Итого 78 байт.
3. Эти 78 байт шифруются RSA-1024 PKCS#1 v1.5, результат в base64 уходит в заголовок `Ares-Cipher`.
4. Тело и ответ — AES-128-CBC (K, IV, PKCS7), base64.

Эталонные значения посчитаны Python-реализацией (`tools/probe.py`), которая работает с живым сервером.

**Files:**
- Create: `Packages/AlemCore/Sources/AlemCore/Crypto/AresCipher.swift`
- Test: `Packages/AlemCore/Tests/AlemCoreTests/AresCipherTests.swift`

**Interfaces:**
- Produces:
  - `public struct AresCipher: Sendable` с `init(key: [UInt8])`, `static func random() -> AresCipher`, `static let iv: [UInt8]`;
  - `static func headerBlock(key: [UInt8], timestamp: UInt32) -> [UInt8]`;
  - `func header(timestamp: UInt32 = …) throws -> String`;
  - `func encrypt(_ plain: Data) throws -> String`, `func decrypt(_ base64: String) throws -> Data`;
  - `public enum AresCipherError: Error, Equatable`.

- [ ] **Step 1: Написать падающие тесты**

`Packages/AlemCore/Tests/AlemCoreTests/AresCipherTests.swift`:
```swift
import Testing
import Foundation
@testable import AlemCore

@Suite struct AresCipherTests {
    let key: [UInt8] = (0..<16).map { UInt8($0) }
    var cipher: AresCipher { AresCipher(key: key) }

    private func hex(_ bytes: [UInt8]) -> String { bytes.map { String(format: "%02x", $0) }.joined() }

    @Test func headerBlockMatchesPythonReference() {
        let block = AresCipher.headerBlock(key: key, timestamp: 1_700_000_000)
        #expect(block.count == 78)
        #expect(hex(block) == "01006165730000000000000000000000000063626300000000006261736536340000800010002e003e0000f15365000102030405060708090a0b0c0d0e0f61726573637279707420202020202020")
    }

    @Test func encryptMatchesPythonReference() throws {
        let plain = Data(#"{"jsonrpc":"2.0","id":1,"method":"login","params":{"macaddr":null}}"#.utf8)
        #expect(try cipher.encrypt(plain) == "7nGcuIoK3zJZgGc/W5Zkqyxv0rKQDnS9Tre7G2e5oCmPXbw8qKjvTVRqHpAbxcOdYgTii11X5aGINF/XKxZpo5VKk0SPW78v/yeZ0EdvE4k=")
    }

    @Test func decryptRoundTrip() throws {
        let plain = Data("{\"result\":{\"session_id\":\"SID\"}}".utf8)
        #expect(try cipher.decrypt(cipher.encrypt(plain)) == plain)
    }

    @Test func cyrillicIsUTF8() throws {
        #expect(try cipher.encrypt(Data("Привет".utf8)) == "3sPPfhhXQCKpLVq6AyuboA==")
    }

    @Test func decryptRejectsGarbage() {
        #expect(throws: AresCipherError.self) { try cipher.decrypt("!!!не base64!!!") }
    }

    @Test func rsaHeaderIs128Bytes() throws {
        let header = try cipher.header(timestamp: 1_700_000_000)
        #expect(Data(base64Encoded: header)?.count == 128)
    }

    @Test func randomKeysDiffer() {
        #expect(AresCipher.random().key != AresCipher.random().key)
    }
}
```

- [ ] **Step 2: Тесты падают**

Run: `swift test --package-path Packages/AlemCore --filter AresCipherTests`
Expected: `cannot find 'AresCipher' in scope`.

- [ ] **Step 3: Реализация**

`Packages/AlemCore/Sources/AlemCore/Crypto/AresCipher.swift`:
```swift
import Foundation
import CommonCrypto
import Security

public enum AresCipherError: Error, Equatable {
    case rsa(String)
    case aes(Int32)
    case badBase64
}

/// Шифрование чувствительных JSON-RPC вызовов IPTVPORTAL (заголовок `Ares-Cipher`).
public struct AresCipher: Sendable {
    public static let iv: [UInt8] = Array("arescrypt       ".utf8)

    /// RSA-1024 модуль из system.js портала (e = 65537).
    static let modulusHex =
        "cf2cde3395737e94f0f0ca7474797d285170eb7acd41628a946f92a00138225a" +
        "23c2b7307da8c182536bfa325d7a111dc82eb0825c85614d807b46bdc0bea823" +
        "1dde941b2d435782dabed3381b48f30aa19bff261eec4086b56d5c45ea394b8f" +
        "386d1ad75b7e8c5d37d517e83e598719afb2b05b790e41f132858321f693c025"

    public let key: [UInt8]

    public init(key: [UInt8]) {
        precondition(key.count == 16, "AES-128 key must be 16 bytes")
        self.key = key
    }

    public static func random() -> AresCipher {
        var bytes = [UInt8](repeating: 0, count: 16)
        let status = SecRandomCopyBytes(kSecRandomDefault, bytes.count, &bytes)
        precondition(status == errSecSuccess, "SecRandomCopyBytes failed")
        return AresCipher(key: bytes)
    }

    /// 78 байт: struct `<H16s8s8sHHHHL` + ключ + IV.
    public static func headerBlock(key: [UInt8], timestamp: UInt32) -> [UInt8] {
        var out: [UInt8] = []
        out += le16(1)
        out += fixed("aes", 16)
        out += fixed("cbc", 8)
        out += fixed("base64", 8)
        out += le16(128) + le16(16) + le16(46) + le16(62)
        out += le32(timestamp)
        out += key
        out += iv
        return out
    }

    /// Значение HTTP-заголовка `Ares-Cipher`.
    public func header(timestamp: UInt32 = UInt32(Date().timeIntervalSince1970)) throws -> String {
        let block = Data(Self.headerBlock(key: key, timestamp: timestamp))
        var error: Unmanaged<CFError>?
        guard let encrypted = SecKeyCreateEncryptedData(try Self.publicKey(), .rsaEncryptionPKCS1, block as CFData, &error) else {
            throw AresCipherError.rsa(error.map { String(describing: $0.takeRetainedValue()) } ?? "encrypt failed")
        }
        return (encrypted as Data).base64EncodedString()
    }

    public func encrypt(_ plain: Data) throws -> String {
        try crypt(CCOperation(kCCEncrypt), plain).base64EncodedString()
    }

    public func decrypt(_ base64: String) throws -> Data {
        guard let data = Data(base64Encoded: base64, options: .ignoreUnknownCharacters), !data.isEmpty,
              data.count % kCCBlockSizeAES128 == 0 else {
            throw AresCipherError.badBase64
        }
        return try crypt(CCOperation(kCCDecrypt), data)
    }

    private func crypt(_ operation: CCOperation, _ input: Data) throws -> Data {
        var output = [UInt8](repeating: 0, count: input.count + kCCBlockSizeAES128)
        let outputCount = output.count
        var moved = 0
        let status = input.withUnsafeBytes { inBuffer in
            CCCrypt(operation, CCAlgorithm(kCCAlgorithmAES), CCOptions(kCCOptionPKCS7Padding),
                    key, key.count, Self.iv,
                    inBuffer.baseAddress, input.count,
                    &output, outputCount, &moved)
        }
        guard status == kCCSuccess else { throw AresCipherError.aes(status) }
        return Data(output.prefix(moved))
    }

    // MARK: - RSA

    static func publicKey() throws -> SecKey {
        let der = derSequence(derInteger(hexBytes(modulusHex)) + derInteger([0x01, 0x00, 0x01]))
        let attributes: [CFString: Any] = [
            kSecAttrKeyType: kSecAttrKeyTypeRSA,
            kSecAttrKeyClass: kSecAttrKeyClassPublic,
            kSecAttrKeySizeInBits: 1024,
        ]
        var error: Unmanaged<CFError>?
        guard let key = SecKeyCreateWithData(Data(der) as CFData, attributes as CFDictionary, &error) else {
            throw AresCipherError.rsa(error.map { String(describing: $0.takeRetainedValue()) } ?? "bad key")
        }
        return key
    }

    // MARK: - Байтовые помощники

    static func le16(_ v: UInt16) -> [UInt8] { [UInt8(v & 0xff), UInt8(v >> 8)] }
    static func le32(_ v: UInt32) -> [UInt8] { (0..<4).map { UInt8((v >> (8 * $0)) & 0xff) } }

    static func fixed(_ s: String, _ length: Int) -> [UInt8] {
        let bytes = Array(s.utf8.prefix(length))
        return bytes + [UInt8](repeating: 0, count: length - bytes.count)
    }

    static func hexBytes(_ hex: String) -> [UInt8] {
        var out: [UInt8] = []
        var index = hex.startIndex
        while index < hex.endIndex {
            let next = hex.index(index, offsetBy: 2)
            out.append(UInt8(hex[index..<next], radix: 16)!)
            index = next
        }
        return out
    }

    static func derLength(_ n: Int) -> [UInt8] {
        if n < 0x80 { return [UInt8(n)] }
        if n < 0x100 { return [0x81, UInt8(n)] }
        return [0x82, UInt8(n >> 8), UInt8(n & 0xff)]
    }

    static func derInteger(_ bytes: [UInt8]) -> [UInt8] {
        var body = Array(bytes.drop(while: { $0 == 0 }))
        if body.isEmpty || body[0] & 0x80 != 0 { body.insert(0, at: 0) }
        return [0x02] + derLength(body.count) + body
    }

    static func derSequence(_ content: [UInt8]) -> [UInt8] {
        [0x30] + derLength(content.count) + content
    }
}
```

- [ ] **Step 4: Тесты проходят**

Run: `swift test --package-path Packages/AlemCore --filter AresCipherTests`
Expected: 7 тестов passed.

- [ ] **Step 5: Commit**

```bash
git add Packages/AlemCore
git commit -m "AlemCore: AresCipher (RSA PKCS#1 + AES-128-CBC) со сверкой по эталону Python

Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>
Claude-Session: https://claude.ai/code/session_015tkg9WmfzBtZ6B6QQFpCUA"
```

---

### Task 4: Модели, время портала и обезличенные фикстуры

**Files:**
- Create: `tools/anonymize.py`
- Create (генерируются): `Packages/AlemCore/Tests/AlemCoreTests/Fixtures/{get_domain_config,login,register_terminal,authorize_terminal,check_update,check_update_unauthorized,get_epg_day,get_epg_now}.json`
- Create: `Packages/AlemCore/Sources/AlemCore/Time/PortalDate.swift`
- Create: `Packages/AlemCore/Sources/AlemCore/Models/Channel.swift`, `Playlist.swift`, `Program.swift`, `Account.swift`, `Responses.swift`
- Create: `Packages/AlemCore/Sources/AlemCore/API/PortalError.swift`
- Test: `Packages/AlemCore/Tests/AlemCoreTests/Support/Fixture.swift`, `ModelsTests.swift`, `PortalDateTests.swift`

**Interfaces:**
- Consumes: `JSONValue`, `CSVTable` (Task 2).
- Produces:
  - `public enum PortalDate { static let serverTimeZone: TimeZone; static func parse(_:) -> Date?; static func dayString(_:) -> String; static func startOfDay(_:) -> Date }`.
  - `public struct Channel: Sendable, Hashable, Identifiable`. Поля: `id, index, name, scheme, host, port, path, auth, key, encrypted, timeshiftURL, timeshiftArchiveLength, timeshiftOffset, timeshiftAuth, channelID, logoURL, ageLimit`. Плюс `hasArchive: Bool`, `init?(row:)` и memberwise `init(id:index:name:…)` со значениями по умолчанию.
  - `public struct Playlist: Sendable, Hashable, Identifiable { id, name, title, mediaIDs; isFavorites }`.
  - `public struct Program: Sendable, Hashable, Identifiable { mediaID, start, stop, title, ageLabel, summary; duration; isOnAir(at:); progress(at:) }` и `init?(row:defaultMediaID:)`.
  - `public struct Profile`, `Language`, `MediaToken`, `EPGInfo`.
  - `public struct DomainConfig { name, portalUpdatePeriod, autoPauseTimeout, allowTerminalReg, allowTerminalUnreg, useTimeshift, updatedOn, serverNow }`.
  - `public struct AuthorizeResult` с полями `channels, playlists, profiles, profile, languages, language, tokens (var), timeshiftEnabled, lastMediaID, epgInfo, serverNow, macaddr, subscriberUpdatedOn, terminalUpdatedOn`. Методы: `channel(id:)`, `channels(in:)`, `favorites`.
  - `public struct CheckUpdateResult { authorized, domainUpdatedOn, subscriberUpdatedOn, terminalUpdatedOn, tokens, epgInfo, serverNow }`.
  - `public struct LoginResult { sessionID, macaddr, userID }`.
  - `public struct EPGResponse { serverNow, programs }`.
  - `public enum PortalError: Error, Equatable, Sendable { unauthorized(String), notFound(String), server(code: Int, message: String), http(Int), transport(String), decoding(String) }`.

- [ ] **Step 1: Скрипт обезличивания фикстур**

`tools/anonymize.py`:
```python
#!/usr/bin/env python3
"""Делает обезличенные фикстуры для тестов AlemCore из reference/samples/ (результатов tools/probe.py).

Заменяет session_id, токены, логин/пароль, MAC и секрет домена; урезает каталог до 5 каналов.
"""
import json
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, "reference", "samples")
DST = os.path.join(ROOT, "Packages", "AlemCore", "Tests", "AlemCoreTests", "Fixtures")
KEEP = [1, 2, 33, 76, 108976]   # 108976 — канал без архива
MAC = "00:1A:79:00:00:01"


def load(name):
    with open(os.path.join(SRC, name), encoding="utf-8") as f:
        return json.load(f)


def dump(name, data):
    with open(os.path.join(DST, name), "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=1)


def anon_tokens(tokens):
    return {"Key-1": {**next(iter(tokens.values())), "name": "Key-1", "token1": "T1", "token2": "T2"}} if tokens else tokens


os.makedirs(DST, exist_ok=True)

d = load("get_domain_config.json")
d["result"]["auth_secret_key"] = ""
dump("get_domain_config.json", d)

dump("login.json", {"jsonrpc": "2.0", "id": 2, "result": {"session_id": "SID", "user_id": 1}})
dump("register_terminal.json", {"jsonrpc": "2.0", "id": 3, "result": {"session_id": "SID", "user_id": 1, "macaddr": MAC}})

a = load("authorize_terminal.json")
r = a["result"]
head, *rows = r["medialist"]
id_col, key_col = head.index("id"), head.index("key")
rows = [row for row in rows if row[id_col] in KEEP]
for row in rows:
    if row[key_col]:
        row[key_col] = "Key-1"
r["medialist"] = [head] + rows
r["tokens"] = anon_tokens(r.get("tokens"))
r["username"], r["password"], r["macaddr"] = "user", "pass", MAC
for k in ("personal_data", "guest", "room"):
    r.pop(k, None)
items = {"tv": [1, 2, 33, 76, 108976, 999999], "tv-national": [1, 2], "tv-favorites": [33]}
r["playlists"] = [p for p in r["playlists"] if p["name"] in items]
for p in r["playlists"]:
    p["playitems"] = items[p["name"]]
r["state"] = {**(r.get("state") or {}), "media_id": 33}
r["epg_info"] = [e for e in r.get("epg_info") or [] if e["id"] in KEEP]
if r.get("profile"):
    r["profile"]["password"] = None
for s in (r.get("services_enabled") or {}).values():
    s["username"] = s["password"] = s["session_id"] = None
dump("authorize_terminal.json", a)

c = load("check_update.json")
c["result"]["tokens"] = anon_tokens(c["result"].get("tokens"))
c["result"]["epg_info"] = [e for e in c["result"].get("epg_info") or [] if e["id"] in KEEP]
dump("check_update.json", c)
dump("check_update_unauthorized.json",
     {"jsonrpc": "2.0", "id": 2, "result": {"required": False, "critical": False, "domain_updated_on": 1790180081}})

dump("get_epg_day.json", load("get_epg_33_day.json"))
dump("get_epg_now.json", load("get_epg_nownext.json"))
print("fixtures written to", DST)
```

Run: `python3 tools/anonymize.py && rm -f Packages/AlemCore/Tests/AlemCoreTests/Fixtures/.keep && ls Packages/AlemCore/Tests/AlemCoreTests/Fixtures`
Expected: 8 json-файлов.

Проверить, что секреты не утекли (значения не печатаются):
```bash
L=$(grep ALEMTV_LOGIN .credentials | cut -d= -f2-); P=$(grep ALEMTV_PASSWORD .credentials | cut -d= -f2-)
M=$(python3 -c "import json;print(json.load(open('reference/samples/.terminal.json'))['macaddr'])")
for v in "$L" "$P" "$M"; do grep -rqF -- "$v" Packages/AlemCore/Tests/AlemCoreTests/Fixtures && echo LEAK || echo clean; done
```
Expected: три строки `clean`.

- [ ] **Step 2: Написать падающие тесты**

`Packages/AlemCore/Tests/AlemCoreTests/Support/Fixture.swift`:
```swift
import Foundation
@testable import AlemCore

enum Fixture {
    struct Missing: Error { let name: String }

    static func data(_ name: String) throws -> Data {
        guard let url = Bundle.module.url(forResource: name, withExtension: "json", subdirectory: "Fixtures") else {
            throw Missing(name: name)
        }
        return try Data(contentsOf: url)
    }

    /// Поле `result` JSON-RPC ответа.
    static func result(_ name: String) throws -> JSONValue {
        try JSONDecoder().decode(JSONValue.self, from: data(name))["result"] ?? .null
    }

    static func authorize() throws -> AuthorizeResult {
        try AuthorizeResult(json: result("authorize_terminal"))
    }
}
```

`Packages/AlemCore/Tests/AlemCoreTests/PortalDateTests.swift`:
```swift
import Testing
import Foundation
@testable import AlemCore

@Suite struct PortalDateTests {
    @Test func parsesWithZone() {
        #expect(PortalDate.parse("2026-10-02 22:50:00+0500")?.timeIntervalSince1970 == 1_790_963_400)
    }

    @Test func parsesWithoutZoneAsServerTime() {
        #expect(PortalDate.parse("2026-09-26 18:36:00")?.timeIntervalSince1970 == 1_790_429_760)
    }

    @Test func rejectsGarbage() {
        #expect(PortalDate.parse("вчера") == nil)
        #expect(PortalDate.parse("") == nil)
    }

    @Test func dayStringUsesServerZone() {
        // 2026-10-03 19:30 UTC = 2026-10-04 00:30 в Ашхабаде
        #expect(PortalDate.dayString(Date(timeIntervalSince1970: 1_791_055_800)) == "2026-10-04")
    }

    @Test func startOfDayInServerZone() {
        let start = PortalDate.startOfDay(Date(timeIntervalSince1970: 1_791_055_800))
        #expect(PortalDate.dayString(start) == "2026-10-04")
        #expect(start.timeIntervalSince1970 == 1_791_054_000)
    }
}
```

`Packages/AlemCore/Tests/AlemCoreTests/ModelsTests.swift`:
```swift
import Testing
import Foundation
@testable import AlemCore

@Suite struct ModelsTests {
    @Test func domainConfig() throws {
        let d = try DomainConfig(json: Fixture.result("get_domain_config"))
        #expect(d.name == "tmalem")
        #expect(d.portalUpdatePeriod == 300)
        #expect(d.autoPauseTimeout == 18000)
        #expect(d.allowTerminalReg)
        #expect(d.allowTerminalUnreg)
        #expect(d.useTimeshift)
        #expect(d.serverNow != nil)
    }

    @Test func authorizeParsesChannels() throws {
        let a = try Fixture.authorize()
        #expect(Set(a.channels.map(\.id)).isSuperset(of: [1, 33, 76, 108976]))
        let altyn = try #require(a.channel(id: 1))
        #expect(altyn.name == "Altyn Asyr")
        #expect(altyn.host == "119.235.117.209")
        #expect(altyn.port == 8010)
        #expect(altyn.path == "AltynAsyr/video.m3u8")
        #expect(altyn.auth == "iptvportal")
        #expect(altyn.key == "Key-1")
        #expect(altyn.encrypted)
        #expect(altyn.hasArchive)
        #expect(altyn.timeshiftArchiveLength == 259200)
        #expect(altyn.channelID == 9930001)
        let che = try #require(a.channel(id: 108976))
        #expect(!che.hasArchive)
    }

    @Test func channelsSortedByIndex() throws {
        let a = try Fixture.authorize()
        #expect(a.channels.map(\.index) == a.channels.map(\.index).sorted())
    }

    @Test func channelsInPlaylistSkipUnknownIDs() throws {
        let a = try Fixture.authorize()
        let tv = try #require(a.playlists.first { $0.name == "tv" })
        #expect(tv.mediaIDs.contains(999999))
        let ids = a.channels(in: tv).map(\.id)
        #expect(!ids.contains(999999))
        #expect(ids.first == 1)
    }

    @Test func favoritesAndState() throws {
        let a = try Fixture.authorize()
        #expect(a.favorites?.mediaIDs == [33])
        #expect(a.favorites?.isFavorites == true)
        #expect(a.lastMediaID == 33)
    }

    @Test func tokensLanguagesProfiles() throws {
        let a = try Fixture.authorize()
        #expect(a.tokens["Key-1"] == MediaToken(name: "Key-1", token1: "T1", token2: "T2"))
        #expect(a.timeshiftEnabled)
        #expect(a.languages.map(\.id) == [1, 2, 15])
        #expect(a.languages.map(\.code) == ["ru", "en", "tk"])
        #expect(a.language?.code == "ru")
        #expect(a.profiles.count == 2)
        #expect(a.profiles[1].requirePassword)
        #expect(a.profile?.id == 1)
        #expect(a.macaddr == "00:1A:79:00:00:01")
        #expect(a.epgInfo[33] != nil)
        #expect(a.serverNow != nil)
    }

    @Test func authorizeRejectsNonObject() {
        #expect(throws: PortalError.self) { try AuthorizeResult(json: .bool(false)) }
    }

    @Test func checkUpdate() throws {
        let u = try CheckUpdateResult(json: Fixture.result("check_update"))
        #expect(u.authorized)
        #expect(u.tokens?["Key-1"]?.token1 == "T1")
        #expect(u.subscriberUpdatedOn != nil)
        let bad = try CheckUpdateResult(json: Fixture.result("check_update_unauthorized"))
        #expect(!bad.authorized)
        #expect(bad.tokens == nil)
    }

    @Test func loginResults() throws {
        let l = try LoginResult(json: Fixture.result("login"))
        #expect(l.sessionID == "SID")
        #expect(l.macaddr == nil)
        let r = try LoginResult(json: Fixture.result("register_terminal"))
        #expect(r.macaddr == "00:1A:79:00:00:01")
        #expect(throws: PortalError.unauthorized("access denied")) { try LoginResult(json: .bool(false)) }
    }

    @Test func epgDay() throws {
        let e = try EPGResponse(json: Fixture.result("get_epg_day"), defaultMediaID: 33)
        #expect(e.programs.count == 22)
        let first = e.programs[0]
        #expect(first.mediaID == 33)
        #expect(first.start.timeIntervalSince1970 == 1_790_963_400)
        #expect(first.title == "Последний день Земли")
        #expect(first.ageLabel == "18+")
        #expect(e.programs.map(\.start) == e.programs.map(\.start).sorted())
    }

    @Test func epgNowUsesMediaIDColumn() throws {
        let e = try EPGResponse(json: Fixture.result("get_epg_now"), defaultMediaID: nil)
        #expect(Set(e.programs.map(\.mediaID)) == [33, 76])
    }

    @Test func programAgeSuffixIsSplit() {
        #expect(Program.splitAge("Вердикт за деньги (16+)") == ("Вердикт за деньги", "16+"))
        #expect(Program.splitAge("Новости") == ("Новости", nil))
        #expect(Program.splitAge("Шоу (live)") == ("Шоу (live)", nil))
    }

    @Test func programProgress() {
        let p = Program(mediaID: 1, start: Date(timeIntervalSince1970: 1000), stop: Date(timeIntervalSince1970: 2000), title: "x")
        #expect(p.isOnAir(at: Date(timeIntervalSince1970: 1500)))
        #expect(!p.isOnAir(at: Date(timeIntervalSince1970: 2000)))
        #expect(p.progress(at: Date(timeIntervalSince1970: 1250)) == 0.25)
        #expect(p.progress(at: Date(timeIntervalSince1970: 5000)) == 1)
    }
}
```

- [ ] **Step 3: Тесты падают**

Run: `swift test --package-path Packages/AlemCore --filter "ModelsTests|PortalDateTests"`
Expected: ошибки компиляции (нет `PortalDate`, `DomainConfig` и т. д.).

- [ ] **Step 4: Реализация**

`Packages/AlemCore/Sources/AlemCore/API/PortalError.swift`:
```swift
/// Ошибки обращения к порталу. Коды JSON-RPC: -32003 — нет доступа, -32002 — не найдено (терминал/сессия).
public enum PortalError: Error, Equatable, Sendable {
    case unauthorized(String)
    case notFound(String)
    case server(code: Int, message: String)
    case http(Int)
    case transport(String)
    case decoding(String)

    /// Сессия или терминал больше недействительны — нужен повторный вход.
    public var requiresSignIn: Bool {
        switch self {
        case .unauthorized, .notFound: return true
        default: return false
        }
    }

    /// Текст сервера для показа пользователю (если есть).
    public var serverMessage: String? {
        switch self {
        case .unauthorized(let m), .notFound(let m), .server(_, let m): return m.isEmpty ? nil : m
        default: return nil
        }
    }
}
```

`Packages/AlemCore/Sources/AlemCore/Time/PortalDate.swift`:
```swift
import Foundation

/// Время в ответах портала: "2026-10-03 21:00:00+0500" или без зоны (тогда — зона сервера, UTC+5).
public enum PortalDate {
    public static let serverTimeZone = TimeZone(secondsFromGMT: 5 * 3600)!

    private static func calendar(_ zone: TimeZone) -> Calendar {
        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = zone
        return calendar
    }

    public static func parse(_ text: String) -> Date? {
        let chars = Array(text)
        guard chars.count >= 19 else { return nil }
        func number(_ range: Range<Int>) -> Int? { Int(String(chars[range])) }
        guard let year = number(0..<4), let month = number(5..<7), let day = number(8..<10),
              let hour = number(11..<13), let minute = number(14..<16), let second = number(17..<19) else { return nil }
        var zone = serverTimeZone
        if chars.count >= 24, chars[19] == "+" || chars[19] == "-",
           let hh = number(20..<22), let mm = number(22..<24) {
            let sign = chars[19] == "-" ? -1 : 1
            zone = TimeZone(secondsFromGMT: sign * (hh * 3600 + mm * 60)) ?? serverTimeZone
        }
        let components = DateComponents(year: year, month: month, day: day, hour: hour, minute: minute, second: second)
        return calendar(zone).date(from: components)
    }

    /// "YYYY-MM-DD" дня в зоне сервера (так портал запрашивает EPG по дням).
    public static func dayString(_ date: Date) -> String {
        let c = calendar(serverTimeZone).dateComponents([.year, .month, .day], from: date)
        return String(format: "%04d-%02d-%02d", c.year ?? 0, c.month ?? 0, c.day ?? 0)
    }

    public static func startOfDay(_ date: Date) -> Date {
        calendar(serverTimeZone).startOfDay(for: date)
    }
}
```

`Packages/AlemCore/Sources/AlemCore/Models/Channel.swift`:
```swift
import Foundation

/// ТВ-канал из `medialist` ответа `authorize_terminal`.
public struct Channel: Sendable, Hashable, Identifiable {
    public var id: Int
    public var index: Int
    public var name: String
    public var scheme: String?
    public var host: String?
    public var port: Int?
    public var path: String?
    public var auth: String?
    public var key: String?
    public var encrypted: Bool
    public var timeshiftURL: String?
    public var timeshiftArchiveLength: TimeInterval?
    public var timeshiftOffset: TimeInterval?
    public var timeshiftAuth: String?
    public var channelID: Int?
    public var logoURL: String?
    public var ageLimit: Int?

    public init(id: Int, index: Int = 0, name: String, scheme: String? = "http", host: String? = nil,
                port: Int? = nil, path: String? = nil, auth: String? = nil, key: String? = nil,
                encrypted: Bool = false, timeshiftURL: String? = nil, timeshiftArchiveLength: TimeInterval? = nil,
                timeshiftOffset: TimeInterval? = nil, timeshiftAuth: String? = nil, channelID: Int? = nil,
                logoURL: String? = nil, ageLimit: Int? = nil) {
        self.id = id
        self.index = index
        self.name = name
        self.scheme = scheme
        self.host = host
        self.port = port
        self.path = path
        self.auth = auth
        self.key = key
        self.encrypted = encrypted
        self.timeshiftURL = timeshiftURL
        self.timeshiftArchiveLength = timeshiftArchiveLength
        self.timeshiftOffset = timeshiftOffset
        self.timeshiftAuth = timeshiftAuth
        self.channelID = channelID
        self.logoURL = logoURL
        self.ageLimit = ageLimit
    }

    public init?(row: [String: JSONValue]) {
        guard let id = row["id"]?.int else { return nil }
        self.init(
            id: id,
            index: row["index"]?.int ?? 0,
            name: row["title"]?.string ?? row["name"]?.string ?? "",
            scheme: row["protocol"]?.string,
            host: row["host"]?.string,
            port: row["port"]?.int,
            path: row["path"]?.string,
            auth: row["auth"]?.string,
            key: row["key"]?.string,
            encrypted: row["encrypted"]?.bool ?? false,
            timeshiftURL: row["timeshift_url"]?.string,
            timeshiftArchiveLength: row["timeshift_archive_length"]?.double,
            timeshiftOffset: row["timeshift_offset"]?.double,
            timeshiftAuth: row["timeshift_auth"]?.string,
            channelID: row["channel_id"]?.int,
            logoURL: row["logo_url"]?.string,
            ageLimit: row["age_limit"]?.int
        )
    }

    public var hasArchive: Bool { !(timeshiftURL ?? "").isEmpty }
}
```

`Packages/AlemCore/Sources/AlemCore/Models/Playlist.swift`:
```swift
/// ТВ-плейлист (рубрика). `tv-favorites` — избранное абонента.
public struct Playlist: Sendable, Hashable, Identifiable {
    public var id: Int
    public var name: String
    public var title: String
    public var mediaIDs: [Int]

    public init(id: Int, name: String, title: String, mediaIDs: [Int]) {
        self.id = id
        self.name = name
        self.title = title
        self.mediaIDs = mediaIDs
    }

    public init?(json: JSONValue) {
        guard let id = json["id"]?.int, json["is_tv"]?.bool == true else { return nil }
        self.init(
            id: id,
            name: json["name"]?.string ?? "",
            title: json["title"]?.string ?? json["name"]?.string ?? "",
            mediaIDs: json["playitems"]?.array?.compactMap(\.int) ?? []
        )
    }

    public var isFavorites: Bool { name == "tv-favorites" }
}
```

`Packages/AlemCore/Sources/AlemCore/Models/Program.swift`:
```swift
import Foundation

/// Передача из EPG.
public struct Program: Sendable, Hashable, Identifiable {
    public var mediaID: Int
    public var start: Date
    public var stop: Date
    public var title: String
    public var ageLabel: String?
    public var summary: String?

    public init(mediaID: Int, start: Date, stop: Date, title: String, ageLabel: String? = nil, summary: String? = nil) {
        self.mediaID = mediaID
        self.start = start
        self.stop = stop
        self.title = title
        self.ageLabel = ageLabel
        self.summary = summary
    }

    public init?(row: [String: JSONValue], defaultMediaID: Int?) {
        guard let start = row["start"]?.string.flatMap(PortalDate.parse),
              let stop = row["stop"]?.string.flatMap(PortalDate.parse),
              let mediaID = row["media_id"]?.int ?? defaultMediaID else { return nil }
        let (title, age) = Program.splitAge(row["title"]?.string ?? "")
        self.init(
            mediaID: mediaID,
            start: start,
            stop: stop,
            title: title,
            ageLabel: age ?? row["age_limit"]?.int.map { "\($0)+" },
            summary: row["description"]?.string
        )
    }

    public var id: String { "\(mediaID)-\(Int(start.timeIntervalSince1970))" }
    public var duration: TimeInterval { stop.timeIntervalSince(start) }

    public func isOnAir(at now: Date) -> Bool { start <= now && now < stop }

    public func progress(at now: Date) -> Double {
        guard duration > 0 else { return 0 }
        return min(1, max(0, now.timeIntervalSince(start) / duration))
    }

    /// "Фильм (16+)" → ("Фильм", "16+").
    static func splitAge(_ title: String) -> (String, String?) {
        guard title.hasSuffix("+)"), let open = title.lastIndex(of: "(") else { return (title, nil) }
        let inner = title[title.index(after: open)..<title.index(before: title.endIndex)]
        guard inner.count >= 2, inner.dropLast().allSatisfy(\.isNumber) else { return (title, nil) }
        return (title[..<open].trimmingCharacters(in: .whitespaces), String(inner))
    }
}
```

`Packages/AlemCore/Sources/AlemCore/Models/Account.swift`:
```swift
import Foundation

public struct Profile: Sendable, Hashable, Identifiable {
    public var id: Int
    public var title: String
    public var requirePassword: Bool
    public var ageLimit: Int?
    /// Пароль приходит только у текущего профиля (`authorize_terminal.profile.password`).
    public var password: String?

    public init(id: Int, title: String, requirePassword: Bool = false, ageLimit: Int? = nil, password: String? = nil) {
        self.id = id
        self.title = title
        self.requirePassword = requirePassword
        self.ageLimit = ageLimit
        self.password = password
    }

    init?(json: JSONValue) {
        guard let id = json["id"]?.int else { return nil }
        self.init(
            id: id,
            title: json["title"]?.string ?? json["name"]?.string ?? "",
            requirePassword: json["require_password"]?.bool ?? false,
            ageLimit: json["age_limit"]?.int,
            password: json["password"]?.string
        )
    }
}

public struct Language: Sendable, Hashable, Identifiable {
    public var id: Int
    /// ISO 639-1: ru, en, tk.
    public var code: String
    public var name: String

    public init(id: Int, code: String, name: String = "") {
        self.id = id
        self.code = code
        self.name = name
    }

    init?(json: JSONValue) {
        guard let id = json["id"]?.int, let code = json["iso639_1"]?.string else { return nil }
        self.init(id: id, code: code, name: json["name"]?.string ?? code)
    }
}

/// Токены для URL зашифрованных каналов (`tokens[key]`).
public struct MediaToken: Sendable, Hashable {
    public var name: String
    public var token1: String
    public var token2: String

    public init(name: String, token1: String, token2: String) {
        self.name = name
        self.token1 = token1
        self.token2 = token2
    }

    static func parseAll(_ value: JSONValue?) -> [String: MediaToken]? {
        guard let object = value?.object else { return nil }
        var out: [String: MediaToken] = [:]
        for (name, token) in object {
            if let t1 = token["token1"]?.string, let t2 = token["token2"]?.string {
                out[name] = MediaToken(name: name, token1: t1, token2: t2)
            }
        }
        return out
    }
}

/// Версия и диапазон EPG канала (`epg_info`).
public struct EPGInfo: Sendable, Hashable {
    public var mediaID: Int
    public var updatedOn: Int
    public var minStart: Date?
    public var maxStop: Date?

    public init(mediaID: Int, updatedOn: Int, minStart: Date? = nil, maxStop: Date? = nil) {
        self.mediaID = mediaID
        self.updatedOn = updatedOn
        self.minStart = minStart
        self.maxStop = maxStop
    }

    static func parseAll(_ value: JSONValue?) -> [Int: EPGInfo]? {
        guard let items = value?.array else { return nil }
        var out: [Int: EPGInfo] = [:]
        for item in items {
            guard let id = item["id"]?.int else { continue }
            out[id] = EPGInfo(
                mediaID: id,
                updatedOn: item["updated_on"]?.int ?? 0,
                minStart: item["min_start"]?.string.flatMap(PortalDate.parse),
                maxStop: item["max_stop"]?.string.flatMap(PortalDate.parse)
            )
        }
        return out
    }
}
```

`Packages/AlemCore/Sources/AlemCore/Models/Responses.swift`:
```swift
import Foundation

/// `get_domain_config`.
public struct DomainConfig: Sendable, Equatable {
    public var name: String
    public var portalUpdatePeriod: Int
    public var autoPauseTimeout: TimeInterval
    public var allowTerminalReg: Bool
    public var allowTerminalUnreg: Bool
    public var useTimeshift: Bool
    public var updatedOn: Int
    public var serverNow: Date?

    public init(name: String = "tmalem", portalUpdatePeriod: Int = 300, autoPauseTimeout: TimeInterval = 18000,
                allowTerminalReg: Bool = true, allowTerminalUnreg: Bool = true, useTimeshift: Bool = true,
                updatedOn: Int = 0, serverNow: Date? = nil) {
        self.name = name
        self.portalUpdatePeriod = portalUpdatePeriod
        self.autoPauseTimeout = autoPauseTimeout
        self.allowTerminalReg = allowTerminalReg
        self.allowTerminalUnreg = allowTerminalUnreg
        self.useTimeshift = useTimeshift
        self.updatedOn = updatedOn
        self.serverNow = serverNow
    }

    public init(json: JSONValue) throws {
        guard json.object != nil else { throw PortalError.decoding("get_domain_config: not an object") }
        var settings: JSONValue?
        if let text = json["settings"]?.string, let data = text.data(using: .utf8) {
            settings = try? JSONDecoder().decode(JSONValue.self, from: data)
        }
        self.init(
            name: json["name"]?.string ?? "tmalem",
            portalUpdatePeriod: json["portal_update_period"]?.int ?? 300,
            autoPauseTimeout: settings?["auto_pause_timeout"]?.double ?? 18000,
            allowTerminalReg: json["allow_terminal_reg"]?.bool ?? true,
            allowTerminalUnreg: json["allow_terminal_unreg"]?.bool ?? true,
            useTimeshift: json["use_timeshift"]?.bool ?? true,
            updatedOn: json["updated_on"]?.int ?? 0,
            serverNow: json["now"]?.string.flatMap(PortalDate.parse)
        )
    }
}

/// `login` / `register_terminal`.
public struct LoginResult: Sendable, Equatable {
    public var sessionID: String
    public var macaddr: String?
    public var userID: Int?

    public init(sessionID: String, macaddr: String? = nil, userID: Int? = nil) {
        self.sessionID = sessionID
        self.macaddr = macaddr
        self.userID = userID
    }

    public init(json: JSONValue) throws {
        if json == .bool(false) { throw PortalError.unauthorized("access denied") }
        guard let session = json["session_id"]?.string, !session.isEmpty else {
            throw PortalError.decoding("login: no session_id")
        }
        self.init(sessionID: session, macaddr: json["macaddr"]?.string, userID: json["user_id"]?.int)
    }
}

/// `authorize_terminal` — всё состояние абонента.
public struct AuthorizeResult: Sendable {
    public var channels: [Channel]
    public var playlists: [Playlist]
    public var profiles: [Profile]
    public var profile: Profile?
    public var languages: [Language]
    public var language: Language?
    public var tokens: [String: MediaToken]
    public var timeshiftEnabled: Bool
    public var lastMediaID: Int?
    public var epgInfo: [Int: EPGInfo]
    public var serverNow: Date?
    public var macaddr: String?
    public var subscriberUpdatedOn: Int
    public var terminalUpdatedOn: Int
    private var channelsByID: [Int: Channel]

    public init(channels: [Channel], playlists: [Playlist], profiles: [Profile] = [], profile: Profile? = nil,
                languages: [Language] = [], language: Language? = nil, tokens: [String: MediaToken] = [:],
                timeshiftEnabled: Bool = true, lastMediaID: Int? = nil, epgInfo: [Int: EPGInfo] = [:],
                serverNow: Date? = nil, macaddr: String? = nil, subscriberUpdatedOn: Int = 0, terminalUpdatedOn: Int = 0) {
        self.channels = channels.sorted { $0.index < $1.index }
        self.playlists = playlists
        self.profiles = profiles
        self.profile = profile
        self.languages = languages
        self.language = language
        self.tokens = tokens
        self.timeshiftEnabled = timeshiftEnabled
        self.lastMediaID = lastMediaID
        self.epgInfo = epgInfo
        self.serverNow = serverNow
        self.macaddr = macaddr
        self.subscriberUpdatedOn = subscriberUpdatedOn
        self.terminalUpdatedOn = terminalUpdatedOn
        self.channelsByID = Dictionary(channels.map { ($0.id, $0) }, uniquingKeysWith: { first, _ in first })
    }

    public init(json: JSONValue) throws {
        guard json.object != nil else { throw PortalError.decoding("authorize_terminal: not an object") }
        let enabled = json["medialist_enabled"]?.object
        let channels = CSVTable.rows(json["medialist"])
            .filter { $0["is_tv"]?.bool == true }
            .compactMap(Channel.init(row:))
            .filter { enabled == nil || enabled?[String($0.id)] != nil }
        let timeshiftServiceIDs = (json["services"]?.array ?? [])
            .filter { $0["name"]?.string == "timeshift" }
            .compactMap { $0["id"]?.int }
        let servicesEnabled = json["services_enabled"]?.object ?? [:]
        self.init(
            channels: channels,
            playlists: (json["playlists"]?.array ?? []).compactMap(Playlist.init(json:)),
            profiles: (json["profiles"]?.array ?? []).compactMap(Profile.init(json:)),
            profile: json["profile"].flatMap(Profile.init(json:)),
            languages: (json["languages"]?.array ?? []).compactMap(Language.init(json:)),
            language: json["language"].flatMap(Language.init(json:)),
            tokens: MediaToken.parseAll(json["tokens"]) ?? [:],
            timeshiftEnabled: timeshiftServiceIDs.contains { servicesEnabled[String($0)] != nil },
            lastMediaID: json["state"]?["media_id"]?.int,
            epgInfo: EPGInfo.parseAll(json["epg_info"]) ?? [:],
            serverNow: json["now"]?.string.flatMap(PortalDate.parse),
            macaddr: json["macaddr"]?.string,
            subscriberUpdatedOn: json["subscriber_updated_on"]?.int ?? 0,
            terminalUpdatedOn: json["terminal_updated_on"]?.int ?? 0
        )
    }

    public func channel(id: Int) -> Channel? { channelsByID[id] }

    /// Каналы плейлиста в его порядке; id, которых нет в medialist, пропускаются.
    public func channels(in playlist: Playlist) -> [Channel] {
        playlist.mediaIDs.compactMap { channelsByID[$0] }
    }

    public var favorites: Playlist? { playlists.first(where: \.isFavorites) }
}

/// `check_update`. Если сессия недействительна, сервер не ошибку возвращает, а опускает `authorized`.
public struct CheckUpdateResult: Sendable {
    public var authorized: Bool
    public var domainUpdatedOn: Int?
    public var subscriberUpdatedOn: Int?
    public var terminalUpdatedOn: Int?
    public var tokens: [String: MediaToken]?
    public var epgInfo: [Int: EPGInfo]?
    public var serverNow: Date?

    public init(authorized: Bool, domainUpdatedOn: Int? = nil, subscriberUpdatedOn: Int? = nil,
                terminalUpdatedOn: Int? = nil, tokens: [String: MediaToken]? = nil,
                epgInfo: [Int: EPGInfo]? = nil, serverNow: Date? = nil) {
        self.authorized = authorized
        self.domainUpdatedOn = domainUpdatedOn
        self.subscriberUpdatedOn = subscriberUpdatedOn
        self.terminalUpdatedOn = terminalUpdatedOn
        self.tokens = tokens
        self.epgInfo = epgInfo
        self.serverNow = serverNow
    }

    public init(json: JSONValue) throws {
        guard json.object != nil else { throw PortalError.decoding("check_update: not an object") }
        self.init(
            authorized: json["authorized"]?.bool ?? false,
            domainUpdatedOn: json["domain_updated_on"]?.int,
            subscriberUpdatedOn: json["subscriber_updated_on"]?.int,
            terminalUpdatedOn: json["terminal_updated_on"]?.int,
            tokens: MediaToken.parseAll(json["tokens"]),
            epgInfo: EPGInfo.parseAll(json["epg_info"]),
            serverNow: json["now"]?.string.flatMap(PortalDate.parse)
        )
    }
}

/// `get_epg`.
public struct EPGResponse: Sendable {
    public var serverNow: Date?
    public var programs: [Program]

    public init(serverNow: Date? = nil, programs: [Program]) {
        self.serverNow = serverNow
        self.programs = programs
    }

    public init(json: JSONValue, defaultMediaID: Int?) throws {
        guard json.object != nil else { throw PortalError.decoding("get_epg: not an object") }
        self.init(
            serverNow: json["now"]?.string.flatMap(PortalDate.parse),
            programs: CSVTable.rows(json["programs"])
                .compactMap { Program(row: $0, defaultMediaID: defaultMediaID) }
                .sorted { $0.start < $1.start }
        )
    }
}
```

Примечание для тестов: `ModelsTests.authorizeParsesChannels` проверяет наличие каналов 1, 33, 76 и 108976. Канал 2 в реальных данных может отсутствовать, поэтому на него проверки нет.

- [ ] **Step 5: Тесты проходят**

Run: `swift test --package-path Packages/AlemCore --filter "ModelsTests|PortalDateTests"`
Expected: все тесты passed. Если `epgDay` даёт не 22 передачи, значит, фикстуру `get_epg_day.json` сняли в другой день. Тогда заменить ожидаемое число на `jq '.result.programs | length - 1'` от фикстуры и снять проверку первой передачи заново через `python3 -c "import json;print(json.load(open('…/get_epg_day.json'))['result']['programs'][1][:3])"`.

- [ ] **Step 6: Commit**

```bash
git add tools/anonymize.py Packages/AlemCore
git commit -m "AlemCore: модели ответов портала, время сервера, обезличенные фикстуры

Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>
Claude-Session: https://claude.ai/code/session_015tkg9WmfzBtZ6B6QQFpCUA"
```

---

### Task 5: ServerClock и StreamURLBuilder

**Files:**
- Create: `Packages/AlemCore/Sources/AlemCore/Time/ServerClock.swift`
- Create: `Packages/AlemCore/Sources/AlemCore/Streams/StreamURLBuilder.swift`
- Test: `Packages/AlemCore/Tests/AlemCoreTests/StreamURLBuilderTests.swift`

**Interfaces:**
- Consumes: `Channel`, `Program`, `MediaToken` (Task 4).
- Produces:
  - `public struct ServerClock: Sendable, Equatable { offset; mutating sync(serverNow:deviceNow:); now(deviceNow:) -> Date }`.
  - `public enum StreamMode: Sendable, Equatable { live; archive(start: Date, duration: TimeInterval); timeshift(behind: TimeInterval) }`.
  - `public struct StreamContext: Sendable { sessionID, domain, tokens, serverNow }`.
  - `public enum StreamURLError: Error, Equatable { noLiveAddress, noArchive, invalidURL }`.
  - `public enum StreamURLBuilder` с `url(for:mode:context:) throws -> URL`, `mode(for:position:now:) -> StreamMode`, `isAvailableInArchive(_:channel:timeshiftEnabled:now:) -> Bool`, `floorMinute(_:)`, константами `liveThreshold = 10`, `archiveGrace = 1200`.

- [ ] **Step 1: Написать падающие тесты**

`Packages/AlemCore/Tests/AlemCoreTests/StreamURLBuilderTests.swift`:
```swift
import Testing
import Foundation
@testable import AlemCore

@Suite struct StreamURLBuilderTests {
    let altyn = Channel(id: 1, index: 1, name: "Altyn Asyr", scheme: "http", host: "119.235.117.209", port: 8010,
                        path: "AltynAsyr/video.m3u8", auth: "iptvportal", key: "Key-1", encrypted: true,
                        timeshiftURL: "http://119.235.117.213:8020/AltynAsyr", timeshiftArchiveLength: 259200,
                        timeshiftAuth: "iptvportal")
    let context = StreamContext(sessionID: "SID", domain: "tmalem",
                                tokens: ["Key-1": MediaToken(name: "Key-1", token1: "T1", token2: "T2")],
                                serverNow: Date(timeIntervalSince1970: 1_700_000_000))
    let compositeToken = "token=token%3DSID%26token1%3DT1%26token2%3DT2%26domain%3Dtmalem%26key%3DKey-1%26media_id%3D1%26timestamp%3D1700000000"

    @Test func liveWithCompositeToken() throws {
        let url = try StreamURLBuilder.url(for: altyn, mode: .live, context: context)
        #expect(url.absoluteString == "http://119.235.117.209:8010/AltynAsyr/video.m3u8?" + compositeToken)
    }

    @Test func archiveURL() throws {
        let url = try StreamURLBuilder.url(for: altyn, mode: .archive(start: Date(timeIntervalSince1970: 1_700_000_000), duration: 600), context: context)
        #expect(url.absoluteString == "http://119.235.117.213:8020/AltynAsyr/index-1700000000-600.m3u8?" + compositeToken)
    }

    @Test func timeshiftURL() throws {
        let url = try StreamURLBuilder.url(for: altyn, mode: .timeshift(behind: 300.7), context: context)
        #expect(url.absoluteString == "http://119.235.117.213:8020/AltynAsyr/video-timeshift_rel-300.m3u8?" + compositeToken)
    }

    @Test func timeshiftOffsetIsSubtracted() throws {
        var channel = altyn
        channel.timeshiftOffset = 3600
        let url = try StreamURLBuilder.url(for: channel, mode: .archive(start: Date(timeIntervalSince1970: 1_700_000_000), duration: 60), context: context)
        #expect(url.absoluteString.contains("/index-1699996400-60.m3u8"))
    }

    @Test func channelWithoutKeyUsesPlainToken() throws {
        var channel = altyn
        channel.key = nil
        let url = try StreamURLBuilder.url(for: channel, mode: .live, context: context)
        #expect(url.absoluteString == "http://119.235.117.209:8010/AltynAsyr/video.m3u8?token=SID")
    }

    @Test func channelWithoutAuthHasNoQuery() throws {
        var channel = altyn
        channel.auth = nil
        let url = try StreamURLBuilder.url(for: channel, mode: .live, context: context)
        #expect(url.absoluteString == "http://119.235.117.209:8010/AltynAsyr/video.m3u8")
    }

    @Test func absolutePathIsUsedAsIs() throws {
        var channel = altyn
        channel.path = "http://cdn.example/x/index.m3u8?a=1"
        channel.auth = "flussonic"
        channel.key = nil
        let url = try StreamURLBuilder.url(for: channel, mode: .live, context: context)
        #expect(url.absoluteString == "http://cdn.example/x/index.m3u8?a=1&token=SID")
    }

    @Test func missingSchemeDefaultsToHTTPAndNoPort() throws {
        var channel = altyn
        channel.scheme = nil
        channel.port = nil
        channel.auth = nil
        #expect(try StreamURLBuilder.url(for: channel, mode: .live, context: context).absoluteString == "http://119.235.117.209/AltynAsyr/video.m3u8")
    }

    @Test func archiveWithoutTimeshiftURLThrows() {
        var channel = altyn
        channel.timeshiftURL = nil
        #expect(throws: StreamURLError.noArchive) {
            try StreamURLBuilder.url(for: channel, mode: .timeshift(behind: 10), context: context)
        }
    }

    @Test func liveWithoutHostThrows() {
        var channel = altyn
        channel.host = nil
        #expect(throws: StreamURLError.noLiveAddress) { try StreamURLBuilder.url(for: channel, mode: .live, context: context) }
    }

    @Test func timeshiftBaseDropsFileAndQuery() throws {
        var channel = altyn
        channel.timeshiftURL = "http://h:1/Ch/index.m3u8?x=1"
        let url = try StreamURLBuilder.url(for: channel, mode: .timeshift(behind: 5), context: context)
        #expect(url.absoluteString.hasPrefix("http://h:1/Ch/video-timeshift_rel-5.m3u8?"))
    }

    // MARK: mode(for:)

    let program = Program(mediaID: 1, start: Date(timeIntervalSince1970: 10_000), stop: Date(timeIntervalSince1970: 13_600), title: "x")

    @Test func finishedLongAgoIsArchive() {
        let now = Date(timeIntervalSince1970: 13_600 + 1200)
        #expect(StreamURLBuilder.mode(for: program, position: 0, now: now) == .archive(start: Date(timeIntervalSince1970: 9_960), duration: 3_600))
        #expect(StreamURLBuilder.mode(for: program, position: 100, now: now) == .archive(start: Date(timeIntervalSince1970: 10_060), duration: 3_500))
    }

    @Test func recentlyFinishedIsTimeshift() {
        let now = Date(timeIntervalSince1970: 13_600 + 600)
        #expect(StreamURLBuilder.mode(for: program, position: 0, now: now) == .timeshift(behind: 4_240))
    }

    @Test func onAirFromStartIsTimeshiftAndNearNowIsLive() {
        let now = Date(timeIntervalSince1970: 11_000)
        #expect(StreamURLBuilder.mode(for: program, position: 0, now: now) == .timeshift(behind: 1_040))
        #expect(StreamURLBuilder.mode(for: program, position: 1_035, now: now) == .live)
    }

    @Test func archiveAvailability() {
        let now = Date(timeIntervalSince1970: 300_000)
        let old = Program(mediaID: 1, start: Date(timeIntervalSince1970: 300_000 - 259_201), stop: Date(timeIntervalSince1970: 300_000 - 255_000), title: "old")
        let recent = Program(mediaID: 1, start: Date(timeIntervalSince1970: 299_000), stop: Date(timeIntervalSince1970: 299_500), title: "recent")
        let future = Program(mediaID: 1, start: Date(timeIntervalSince1970: 300_100), stop: Date(timeIntervalSince1970: 301_000), title: "future")
        #expect(!StreamURLBuilder.isAvailableInArchive(old, channel: altyn, timeshiftEnabled: true, now: now))
        #expect(StreamURLBuilder.isAvailableInArchive(recent, channel: altyn, timeshiftEnabled: true, now: now))
        #expect(!StreamURLBuilder.isAvailableInArchive(future, channel: altyn, timeshiftEnabled: true, now: now))
        #expect(!StreamURLBuilder.isAvailableInArchive(recent, channel: altyn, timeshiftEnabled: false, now: now))
    }

    // MARK: ServerClock

    @Test func serverClockOffset() {
        var clock = ServerClock()
        clock.sync(serverNow: Date(timeIntervalSince1970: 1_000), deviceNow: Date(timeIntervalSince1970: 990))
        #expect(clock.offset == 10)
        #expect(clock.now(deviceNow: Date(timeIntervalSince1970: 2_000)) == Date(timeIntervalSince1970: 2_010))
    }
}
```
Арифметика в `finishedLongAgoIsArchive`: `floorMinute(10_000)` = 9_960, `floorMinute(13_600)` = 13_560, длительность 3_600. В `recentlyFinishedIsTimeshift` берётся `now − floorMinute(start)` = 14_200 − 9_960 = 4_240.

- [ ] **Step 2: Тесты падают**

Run: `swift test --package-path Packages/AlemCore --filter StreamURLBuilderTests`
Expected: `cannot find 'StreamURLBuilder' in scope`.

- [ ] **Step 3: Реализация**

`Packages/AlemCore/Sources/AlemCore/Time/ServerClock.swift`:
```swift
import Foundation

/// Смещение часов «сервер − устройство» по полю `now` из ответов портала.
public struct ServerClock: Sendable, Equatable {
    public private(set) var offset: TimeInterval

    public init(offset: TimeInterval = 0) {
        self.offset = offset
    }

    public mutating func sync(serverNow: Date, deviceNow: Date = Date()) {
        offset = serverNow.timeIntervalSince(deviceNow)
    }

    public func now(deviceNow: Date = Date()) -> Date {
        deviceNow.addingTimeInterval(offset)
    }
}
```

`Packages/AlemCore/Sources/AlemCore/Streams/StreamURLBuilder.swift`:
```swift
import Foundation

public enum StreamMode: Sendable, Equatable {
    case live
    /// Конечная запись: начало (UTC) и длительность в секундах.
    case archive(start: Date, duration: TimeInterval)
    /// Эфир с задержкой на `behind` секунд.
    case timeshift(behind: TimeInterval)
}

public struct StreamContext: Sendable {
    public var sessionID: String
    public var domain: String
    public var tokens: [String: MediaToken]
    public var serverNow: Date

    public init(sessionID: String, domain: String, tokens: [String: MediaToken], serverNow: Date) {
        self.sessionID = sessionID
        self.domain = domain
        self.tokens = tokens
        self.serverNow = serverNow
    }
}

public enum StreamURLError: Error, Equatable {
    case noLiveAddress
    case noArchive
    case invalidURL
}

/// URL потоков Flussonic по правилам портала IPTVPORTAL (`PORTAL_ANALYSIS.md` §3).
public enum StreamURLBuilder {
    /// Ближе этого к «сейчас» — играем эфир.
    public static let liveThreshold: TimeInterval = 10
    /// Передача, закончившаяся раньше этого, берётся как конечная запись.
    public static let archiveGrace: TimeInterval = 20 * 60

    public static func url(for channel: Channel, mode: StreamMode, context: StreamContext) throws -> URL {
        let base: String
        let auth: String?
        switch mode {
        case .live:
            base = try liveBase(channel)
            auth = channel.auth
        case .archive(let start, let duration):
            let startSeconds = Int(start.timeIntervalSince1970 - (channel.timeshiftOffset ?? 0))
            base = "\(try timeshiftBase(channel))/index-\(startSeconds)-\(max(0, Int(duration))).m3u8"
            auth = channel.timeshiftAuth ?? channel.auth
        case .timeshift(let behind):
            base = "\(try timeshiftBase(channel))/video-timeshift_rel-\(max(0, Int(behind))).m3u8"
            auth = channel.timeshiftAuth ?? channel.auth
        }
        let query = tokenQuery(channel: channel, auth: auth, context: context)
        let full = query.isEmpty ? base : base + (base.contains("?") ? "&" : "?") + query
        guard let url = URL(string: full) else { throw StreamURLError.invalidURL }
        return url
    }

    /// Режим для передачи EPG и позиции внутри неё (как `Fo` в портале).
    public static func mode(for program: Program, position: TimeInterval, now: Date) -> StreamMode {
        let start = floorMinute(program.start)
        let stop = floorMinute(program.stop)
        let at = start.addingTimeInterval(position)
        if stop.addingTimeInterval(archiveGrace) <= now {
            return .archive(start: at, duration: stop.timeIntervalSince(start) - position)
        }
        let behind = now.timeIntervalSince(at)
        return behind <= liveThreshold ? .live : .timeshift(behind: behind)
    }

    public static func isAvailableInArchive(_ program: Program, channel: Channel, timeshiftEnabled: Bool, now: Date) -> Bool {
        guard timeshiftEnabled, channel.hasArchive, let depth = channel.timeshiftArchiveLength else { return false }
        return program.start >= now.addingTimeInterval(-depth) && program.start < now
    }

    public static func floorMinute(_ date: Date) -> Date {
        Date(timeIntervalSince1970: (date.timeIntervalSince1970 / 60).rounded(.down) * 60)
    }

    // MARK: - Внутреннее

    static func liveBase(_ channel: Channel) throws -> String {
        if let path = channel.path, path.hasPrefix("http://") || path.hasPrefix("https://") { return path }
        guard let host = channel.host, !host.isEmpty else { throw StreamURLError.noLiveAddress }
        let scheme = (channel.scheme?.isEmpty == false) ? channel.scheme! : "http"
        let port = channel.port.map { ":\($0)" } ?? ""
        let path = String((channel.path ?? "").drop(while: { $0 == "/" }))
        return "\(scheme)://\(host)\(port)/\(path)"
    }

    static func timeshiftBase(_ channel: Channel) throws -> String {
        guard var base = channel.timeshiftURL, !base.isEmpty else { throw StreamURLError.noArchive }
        if let q = base.firstIndex(of: "?") { base = String(base[..<q]) }
        if base.hasSuffix(".m3u8"), let slash = base.lastIndex(of: "/") { base = String(base[..<slash]) }
        while base.hasSuffix("/") { base.removeLast() }
        return base
    }

    static func tokenQuery(channel: Channel, auth: String?, context: StreamContext) -> String {
        guard let auth else { return "" }
        let sessionAuth = auth.contains("iptvportal") || auth.contains("flussonic")
        var parts: [String] = []
        if sessionAuth { parts.append("token=\(context.sessionID)") }
        if auth.contains("iptvportal") || auth.contains("arescrypt"), let key = channel.key, let token = context.tokens[key] {
            parts += [
                "token1=\(token.token1)",
                "token2=\(token.token2)",
                "domain=\(context.domain)",
                "key=\(key)",
                "media_id=\(channel.id)",
                "timestamp=\(Int(context.serverNow.timeIntervalSince1970))",
            ]
            if auth.contains("iptvportal") {
                return "token=" + encodeURIComponent(parts.joined(separator: "&"))
            }
        }
        return parts.joined(separator: "&")
    }

    /// Как JS `encodeURIComponent`.
    static func encodeURIComponent(_ text: String) -> String {
        let allowed = CharacterSet(charactersIn: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_.!~*'()")
        return text.addingPercentEncoding(withAllowedCharacters: allowed) ?? text
    }
}
```

- [ ] **Step 4: Тесты проходят**

Run: `swift test --package-path Packages/AlemCore --filter StreamURLBuilderTests`
Expected: все тесты passed.

- [ ] **Step 5: Commit**

```bash
git add Packages/AlemCore
git commit -m "AlemCore: StreamURLBuilder (эфир/архив/таймшифт Flussonic) и ServerClock

Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>
Claude-Session: https://claude.ai/code/session_015tkg9WmfzBtZ6B6QQFpCUA"
```

---

### Task 6: PortalClient: JSON-RPC транспорт и методы

**Files:**
- Create: `Packages/AlemCore/Sources/AlemCore/API/HTTPTransport.swift`
- Create: `Packages/AlemCore/Sources/AlemCore/API/PortalClient.swift`
- Test: `Packages/AlemCore/Tests/AlemCoreTests/Support/MockTransport.swift`, `PortalClientTests.swift`

**Interfaces:**
- Consumes: `JSONValue`, `AresCipher`, модели и `PortalError` (Tasks 2–4).
- Produces:
  - `public protocol HTTPTransport: Sendable { func post(_ url: URL, headers: [String: String], body: Data) async throws -> (Data, Int) }` и `public struct URLSessionTransport: HTTPTransport`.
  - `public struct TerminalInfo: Sendable, Equatable { terminalType, firmwareVersion, userAgent; static func appleTV(appVersion:osVersion:) }`.
  - `public actor PortalClient` с методами:
    - `init(baseURL: URL, terminal: TerminalInfo, transport: HTTPTransport = URLSessionTransport(), cipherFactory: @escaping @Sendable () -> AresCipher = AresCipher.random)`;
    - `setSession(_ id: String?)`, `setMacaddr(_ mac: String?)`;
    - `call(_ method: String, _ params: [String: JSONValue], encrypted: Bool) async throws -> JSONValue`;
    - `getDomainConfig() -> DomainConfig`;
    - `login(macaddr: String?) -> LoginResult`;
    - `registerTerminal(username: String, password: String, macaddr: String?) -> LoginResult`;
    - `unregisterTerminal(macaddr: String)`;
    - `authorizeTerminal(nocache: Bool) -> AuthorizeResult`;
    - `checkUpdate() -> CheckUpdateResult`;
    - `epg(mediaIDs: [Int], languageID: Int?) -> EPGResponse`;
    - `epg(mediaID: Int, day: String, languageID: Int?) -> EPGResponse`;
    - `setFavorite(_ on: Bool, playlistID: Int, mediaID: Int)`;
    - `setTerminalParams(_ params: [String: JSONValue])`.

- [ ] **Step 1: Мок транспорта**

`Packages/AlemCore/Tests/AlemCoreTests/Support/MockTransport.swift`:
```swift
import Foundation
@testable import AlemCore

/// Отвечает заготовками по имени метода (последний компонент URL). Шифрованные вызовы
/// расшифровывает и шифрует ответ тем же фиксированным ключом, что отдаёт cipherFactory клиента.
final class MockTransport: HTTPTransport, @unchecked Sendable {
    struct Request {
        let url: URL
        let headers: [String: String]
        let body: Data
    }

    private let lock = NSLock()
    private var recorded: [Request] = []
    private let responses: [String: Data]
    private let status: Int
    let cipher: AresCipher

    init(responses: [String: Data], status: Int = 200, cipher: AresCipher = AresCipher(key: Array(repeating: 7, count: 16))) {
        self.responses = responses
        self.status = status
        self.cipher = cipher
    }

    var requests: [Request] { lock.withLock { recorded } }

    func post(_ url: URL, headers: [String: String], body: Data) async throws -> (Data, Int) {
        lock.withLock { recorded.append(Request(url: url, headers: headers, body: body)) }
        guard let data = responses[url.lastPathComponent] else { throw URLError(.badServerResponse) }
        if headers["Ares-Cipher"] != nil {
            return (Data(try cipher.encrypt(data).utf8), status)
        }
        return (data, status)
    }

    /// Тело запроса как JSON (расшифрованное, если вызов шифрованный).
    func json(_ request: Request) throws -> JSONValue {
        let plain = request.headers["Ares-Cipher"] != nil
            ? try cipher.decrypt(String(decoding: request.body, as: UTF8.self))
            : request.body
        return try JSONDecoder().decode(JSONValue.self, from: plain)
    }
}
```

- [ ] **Step 2: Написать падающие тесты**

`Packages/AlemCore/Tests/AlemCoreTests/PortalClientTests.swift`:
```swift
import Testing
import Foundation
@testable import AlemCore

@Suite struct PortalClientTests {
    let terminal = TerminalInfo.appleTV(appVersion: "0.1.0", osVersion: "17.0")

    func makeClient(_ responses: [String: Data], status: Int = 200) -> (PortalClient, MockTransport) {
        let transport = MockTransport(responses: responses, status: status)
        let client = PortalClient(baseURL: URL(string: "http://telecom.alemtv.tm")!, terminal: terminal,
                                  transport: transport, cipherFactory: { [cipher = transport.cipher] in cipher })
        return (client, transport)
    }

    @Test func terminalInfo() {
        #expect(terminal.terminalType == "appletv")
        #expect(terminal.firmwareVersion == "tvOS 17.0; AlemTV 0.1.0")
        #expect(terminal.userAgent == "AlemTV-tvOS/0.1.0 (AppleTV; tvOS 17.0)")
    }

    @Test func plainCallInjectsSessionAndHeaders() async throws {
        let (client, transport) = makeClient(["get_epg": try Fixture.data("get_epg_now")])
        await client.setSession("SID")
        let r = try await client.epg(mediaIDs: [33, 76], languageID: 1)
        #expect(r.programs.count == 2)
        let request = try #require(transport.requests.first)
        #expect(request.url.absoluteString == "http://telecom.alemtv.tm/jsonrpc/get_epg")
        #expect(request.headers["Content-Type"] == "application/x-www-form-urlencoded; charset=UTF-8")
        #expect(request.headers["User-Agent"] == terminal.userAgent)
        #expect(request.headers["Ares-Cipher"] == nil)
        let body = try transport.json(request)
        #expect(body["jsonrpc"]?.string == "2.0")
        #expect(body["method"]?.string == "get_epg")
        #expect(body["params"]?["session_id"]?.string == "SID")
        #expect(body["params"]?["media_id"] == [33, 76])
        #expect(body["params"]?["result_as"]?.string == "csv")
    }

    @Test func macaddrUsedWithoutSession() async throws {
        let (client, transport) = makeClient(["get_domain_config": try Fixture.data("get_domain_config")])
        await client.setMacaddr("00:1A:79:00:00:01")
        _ = try await client.getDomainConfig()
        let body = try transport.json(try #require(transport.requests.first))
        #expect(body["params"]?["macaddr"]?.string == "00:1A:79:00:00:01")
        #expect(body["params"]?["session_id"] == nil)
        #expect(body["params"]?["terminal_type"]?.string == "appletv")
    }

    @Test func encryptedLoginRoundTrip() async throws {
        let (client, transport) = makeClient(["login": try Fixture.data("login")])
        let r = try await client.login(macaddr: "00:1A:79:00:00:01")
        #expect(r.sessionID == "SID")
        let request = try #require(transport.requests.first)
        #expect(request.headers["Ares-Cipher"] != nil)
        let params = try transport.json(request)["params"]
        #expect(params?["macaddr"]?.string == "00:1A:79:00:00:01")
        #expect(params?["create_macaddr"] == false)
        #expect(params?["require_session"] == true)
        #expect(params?["terminal_type"]?.string == "appletv")
    }

    @Test func registerWithoutMacRequestsCreation() async throws {
        let (client, transport) = makeClient(["register_terminal": try Fixture.data("register_terminal")])
        let r = try await client.registerTerminal(username: "Ýazgyly", password: "пароль", macaddr: nil)
        #expect(r.macaddr == "00:1A:79:00:00:01")
        let params = try transport.json(try #require(transport.requests.first))["params"]
        #expect(params?["macaddr"] == JSONValue.null)
        #expect(params?["create_macaddr"] == true)
        #expect(params?["username"]?.string == "Ýazgyly")
        #expect(params?["password"]?.string == "пароль")
    }

    @Test func errorCodesAreMapped() async throws {
        let notFound = Data(#"{"jsonrpc":"2.0","id":1,"error":{"code":-32002,"message":"not found"}}"#.utf8)
        let (c1, _) = makeClient(["authorize_terminal": notFound])
        await #expect(throws: PortalError.notFound("not found")) { try await c1.authorizeTerminal(nocache: false) }

        let denied = Data(#"{"jsonrpc":"2.0","id":1,"error":{"code":-32003,"message":"Доступ запрещен"}}"#.utf8)
        let (c2, _) = makeClient(["check_update": denied])
        await #expect(throws: PortalError.unauthorized("Доступ запрещен")) { try await c2.checkUpdate() }

        let other = Data(#"{"jsonrpc":"2.0","id":1,"error":{"code":-1,"message":"limit"}}"#.utf8)
        let (c3, _) = makeClient(["check_update": other])
        await #expect(throws: PortalError.server(code: -1, message: "limit")) { try await c3.checkUpdate() }
    }

    @Test func httpErrorAndTransportError() async throws {
        let (c1, _) = makeClient(["check_update": Data("{}".utf8)], status: 502)
        await #expect(throws: PortalError.http(502)) { try await c1.checkUpdate() }
        let (c2, _) = makeClient([:])
        await #expect(throws: PortalError.self) { try await c2.checkUpdate() }
    }

    @Test func badJSONIsDecodingError() async throws {
        let (client, _) = makeClient(["check_update": Data("<html>".utf8)])
        do {
            _ = try await client.checkUpdate()
            Issue.record("expected error")
        } catch let error as PortalError {
            if case .decoding = error {} else { Issue.record("unexpected \(error)") }
        }
    }

    @Test func authorizeParamsAndFavorites() async throws {
        let ok = Data(#"{"jsonrpc":"2.0","id":1,"result":null}"#.utf8)
        let (client, transport) = makeClient([
            "authorize_terminal": try Fixture.data("authorize_terminal"),
            "insert_playlist_media": ok,
            "delete_playlist_media": ok,
            "set_terminal_params": ok,
        ])
        await client.setSession("SID")
        let a = try await client.authorizeTerminal(nocache: true)
        #expect(!a.channels.isEmpty)
        try await client.setFavorite(true, playlistID: 16, mediaID: 33)
        try await client.setFavorite(false, playlistID: 16, mediaID: 33)
        try await client.setTerminalParams(["media_id": 33])
        let methods = transport.requests.map(\.url.lastPathComponent)
        #expect(methods == ["authorize_terminal", "insert_playlist_media", "delete_playlist_media", "set_terminal_params"])
        let auth = try transport.json(transport.requests[0])["params"]
        #expect(auth?["version"] == 2)
        #expect(auth?["require_media_tokens"] == true)
        #expect(auth?["require_media_keys"] == false)
        #expect(auth?["nocache"] == true)
        let fav = try transport.json(transport.requests[1])["params"]
        #expect(fav?["playlist_id"] == 16)
        #expect(fav?["media_id"] == 33)
    }

    @Test func dayEPGParams() async throws {
        let (client, transport) = makeClient(["get_epg": try Fixture.data("get_epg_day")])
        await client.setSession("SID")
        let r = try await client.epg(mediaID: 33, day: "2026-10-03", languageID: 1)
        #expect(r.programs.allSatisfy { $0.mediaID == 33 })
        let params = try transport.json(try #require(transport.requests.first))["params"]
        #expect(params?["start"]?.string == "2026-10-03 00:00:00")
        #expect(params?["stop"]?.string == "2026-10-03 23:59:59")
        #expect(params?["language_id"] == 1)
    }
}
```

- [ ] **Step 3: Тесты падают**

Run: `swift test --package-path Packages/AlemCore --filter PortalClientTests`
Expected: `cannot find type 'HTTPTransport'`.

- [ ] **Step 4: Реализация**

`Packages/AlemCore/Sources/AlemCore/API/HTTPTransport.swift`:
```swift
import Foundation

public protocol HTTPTransport: Sendable {
    /// POST; возвращает тело и HTTP-статус.
    func post(_ url: URL, headers: [String: String], body: Data) async throws -> (Data, Int)
}

public struct URLSessionTransport: HTTPTransport {
    let session: URLSession
    let timeout: TimeInterval

    public init(session: URLSession = .shared, timeout: TimeInterval = 15) {
        self.session = session
        self.timeout = timeout
    }

    public func post(_ url: URL, headers: [String: String], body: Data) async throws -> (Data, Int) {
        var request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: timeout)
        request.httpMethod = "POST"
        for (name, value) in headers { request.setValue(value, forHTTPHeaderField: name) }
        request.httpBody = body
        let (data, response) = try await session.data(for: request)
        return (data, (response as? HTTPURLResponse)?.statusCode ?? 0)
    }
}

/// Как представляется терминал порталу.
public struct TerminalInfo: Sendable, Equatable {
    public var terminalType: String
    public var firmwareVersion: String
    public var userAgent: String

    public init(terminalType: String, firmwareVersion: String, userAgent: String) {
        self.terminalType = terminalType
        self.firmwareVersion = firmwareVersion
        self.userAgent = userAgent
    }

    public static func appleTV(appVersion: String, osVersion: String) -> TerminalInfo {
        TerminalInfo(
            terminalType: "appletv",
            firmwareVersion: "tvOS \(osVersion); AlemTV \(appVersion)",
            userAgent: "AlemTV-tvOS/\(appVersion) (AppleTV; tvOS \(osVersion))"
        )
    }
}
```

`Packages/AlemCore/Sources/AlemCore/API/PortalClient.swift`:
```swift
import Foundation

/// JSON-RPC 2.0 клиент портала IPTVPORTAL: `POST {base}/jsonrpc/{method}`.
public actor PortalClient {
    public let baseURL: URL
    public let terminal: TerminalInfo
    private let transport: HTTPTransport
    private let cipherFactory: @Sendable () -> AresCipher
    public private(set) var sessionID: String?
    public private(set) var macaddr: String?
    private var nextID = 0

    public init(baseURL: URL, terminal: TerminalInfo, transport: HTTPTransport = URLSessionTransport(),
                cipherFactory: @escaping @Sendable () -> AresCipher = { AresCipher.random() }) {
        self.baseURL = baseURL
        self.terminal = terminal
        self.transport = transport
        self.cipherFactory = cipherFactory
    }

    public func setSession(_ id: String?) { sessionID = id }
    public func setMacaddr(_ mac: String?) { macaddr = mac }

    public func call(_ method: String, _ params: [String: JSONValue] = [:], encrypted: Bool = false) async throws -> JSONValue {
        var params = params
        if params["macaddr"] == nil {
            if let sessionID { params["session_id"] = .string(sessionID) }
            else if let macaddr { params["macaddr"] = .string(macaddr) }
        }
        nextID += 1
        let envelope: JSONValue = ["jsonrpc": "2.0", "id": .int(nextID), "method": .string(method), "params": .object(params)]
        var body = try JSONEncoder().encode(envelope)
        var headers = [
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            "User-Agent": terminal.userAgent,
        ]
        var cipher: AresCipher?
        if encrypted {
            let c = cipherFactory()
            cipher = c
            headers["Ares-Cipher"] = try c.header()
            body = Data(try c.encrypt(body).utf8)
        }
        let url = baseURL.appendingPathComponent("jsonrpc").appendingPathComponent(method)
        let data: Data
        let status: Int
        do {
            (data, status) = try await transport.post(url, headers: headers, body: body)
        } catch {
            throw PortalError.transport(String(describing: type(of: error)))
        }
        guard (200..<300).contains(status) else { throw PortalError.http(status) }
        let response: JSONValue
        do {
            let plain = try cipher.map { try $0.decrypt(String(decoding: data, as: UTF8.self)) } ?? data
            response = try JSONDecoder().decode(JSONValue.self, from: plain)
        } catch {
            throw PortalError.decoding("\(method): \(error)")
        }
        if let error = response["error"], !error.isNull {
            let code = error["code"]?.int ?? 0
            let message = error["message"]?.string ?? ""
            switch code {
            case -32003: throw PortalError.unauthorized(message)
            case -32002: throw PortalError.notFound(message)
            default: throw PortalError.server(code: code, message: message)
            }
        }
        return response["result"] ?? .null
    }

    // MARK: - Методы

    public func getDomainConfig() async throws -> DomainConfig {
        try DomainConfig(json: await call("get_domain_config", ["terminal_type": .string(terminal.terminalType)]))
    }

    public func login(macaddr: String?) async throws -> LoginResult {
        try LoginResult(json: await call("login", terminalParams(macaddr: macaddr), encrypted: true))
    }

    public func registerTerminal(username: String, password: String, macaddr: String?) async throws -> LoginResult {
        var params = terminalParams(macaddr: macaddr)
        params["username"] = .string(username)
        params["password"] = .string(password)
        return try LoginResult(json: await call("register_terminal", params, encrypted: true))
    }

    public func unregisterTerminal(macaddr: String) async throws {
        _ = try await call("unregister_terminal", ["macaddr": .string(macaddr)], encrypted: true)
    }

    public func authorizeTerminal(nocache: Bool = false) async throws -> AuthorizeResult {
        var params: [String: JSONValue] = [
            "version": 2, "require_media_tokens": true, "require_media_keys": false, "result_as": "csv",
        ]
        if nocache {
            params["nocache"] = true
            params["require_domain_config"] = true
        }
        return try AuthorizeResult(json: await call("authorize_terminal", params))
    }

    public func checkUpdate() async throws -> CheckUpdateResult {
        try CheckUpdateResult(json: await call("check_update", ["program": "web browser", "require_media_tokens": true]))
    }

    /// Текущие передачи для списка каналов.
    public func epg(mediaIDs: [Int], languageID: Int?) async throws -> EPGResponse {
        var params: [String: JSONValue] = ["version": 2, "result_as": "csv", "media_id": .array(mediaIDs.map(JSONValue.int))]
        if let languageID { params["language_id"] = .int(languageID) }
        return try EPGResponse(json: await call("get_epg", params), defaultMediaID: nil)
    }

    /// Программа канала на день `YYYY-MM-DD` (зона сервера).
    public func epg(mediaID: Int, day: String, languageID: Int?) async throws -> EPGResponse {
        var params: [String: JSONValue] = [
            "version": 2, "result_as": "csv", "media_id": .int(mediaID),
            "start": .string("\(day) 00:00:00"), "stop": .string("\(day) 23:59:59"),
        ]
        if let languageID { params["language_id"] = .int(languageID) }
        return try EPGResponse(json: await call("get_epg", params), defaultMediaID: mediaID)
    }

    public func setFavorite(_ on: Bool, playlistID: Int, mediaID: Int) async throws {
        _ = try await call(on ? "insert_playlist_media" : "delete_playlist_media",
                           ["playlist_id": .int(playlistID), "media_id": .int(mediaID)])
    }

    public func setTerminalParams(_ params: [String: JSONValue]) async throws {
        _ = try await call("set_terminal_params", params)
    }

    private func terminalParams(macaddr: String?) -> [String: JSONValue] {
        [
            "macaddr": macaddr.map(JSONValue.string) ?? .null,
            "create_macaddr": .bool(macaddr == nil),
            "require_session": true,
            "require_user_id": true,
            "terminal_type": .string(terminal.terminalType),
            "firmware_version": .string(terminal.firmwareVersion),
        ]
    }
}
```

- [ ] **Step 5: Тесты проходят**

Run: `swift test --package-path Packages/AlemCore --filter PortalClientTests`
Expected: все тесты passed.

- [ ] **Step 6: Commit**

```bash
git add Packages/AlemCore
git commit -m "AlemCore: PortalClient — JSON-RPC, Ares-Cipher для входа, методы портала

Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>
Claude-Session: https://claude.ai/code/session_015tkg9WmfzBtZ6B6QQFpCUA"
```

---
### Task 7: EPGStore: кеш программы передач

**Files:**
- Create: `Packages/AlemCore/Sources/AlemCore/EPG/EPGStore.swift`
- Test: `Packages/AlemCore/Tests/AlemCoreTests/EPGStoreTests.swift`

**Interfaces:**
- Consumes: `PortalClient.epg(mediaIDs:languageID:)`, `PortalClient.epg(mediaID:day:languageID:)`, `EPGResponse`, `EPGInfo`, `Program` (Tasks 4, 6).
- Produces:
  - `public protocol EPGSource: Sendable` с теми же двумя методами `epg(...)`; `extension PortalClient: EPGSource`;
  - `public actor EPGStore` с методами:
    - `init(source: EPGSource)`;
    - `programs(mediaID: Int, day: String, languageID: Int?) async throws -> [Program]`;
    - `current(mediaIDs: [Int], languageID: Int?) async throws -> [Int: Program]`;
    - `apply(_ info: [Int: EPGInfo])`;
    - `clear()`.

- [ ] **Step 1: Написать падающие тесты**

`Packages/AlemCore/Tests/AlemCoreTests/EPGStoreTests.swift`:
```swift
import Testing
import Foundation
@testable import AlemCore

actor MockEPGSource: EPGSource {
    var dayCalls: [String] = []
    var currentCalls: [[Int]] = []
    var dayPrograms: [Program] = []
    var currentPrograms: [Program] = []

    func setDay(_ programs: [Program]) { dayPrograms = programs }
    func setCurrent(_ programs: [Program]) { currentPrograms = programs }

    func epg(mediaIDs: [Int], languageID: Int?) async throws -> EPGResponse {
        currentCalls.append(mediaIDs)
        return EPGResponse(programs: currentPrograms.filter { mediaIDs.contains($0.mediaID) })
    }

    func epg(mediaID: Int, day: String, languageID: Int?) async throws -> EPGResponse {
        dayCalls.append("\(mediaID)/\(day)/\(languageID ?? 0)")
        return EPGResponse(programs: dayPrograms)
    }
}

@Suite struct EPGStoreTests {
    func program(_ id: Int, _ start: TimeInterval) -> Program {
        Program(mediaID: id, start: Date(timeIntervalSince1970: start), stop: Date(timeIntervalSince1970: start + 600), title: "p\(id)")
    }

    @Test func dayIsCached() async throws {
        let source = MockEPGSource()
        await source.setDay([program(33, 0), program(33, 600)])
        let store = EPGStore(source: source)
        let first = try await store.programs(mediaID: 33, day: "2026-10-03", languageID: 1)
        let second = try await store.programs(mediaID: 33, day: "2026-10-03", languageID: 1)
        #expect(first.count == 2)
        #expect(first == second)
        #expect(await source.dayCalls == ["33/2026-10-03/1"])
    }

    @Test func languageIsPartOfCacheKey() async throws {
        let source = MockEPGSource()
        let store = EPGStore(source: source)
        _ = try await store.programs(mediaID: 33, day: "2026-10-03", languageID: 1)
        _ = try await store.programs(mediaID: 33, day: "2026-10-03", languageID: 2)
        #expect(await source.dayCalls.count == 2)
    }

    @Test func emptyDayIsCachedNotError() async throws {
        let source = MockEPGSource()
        let store = EPGStore(source: source)
        #expect(try await store.programs(mediaID: 1, day: "2026-10-03", languageID: 1).isEmpty)
        _ = try await store.programs(mediaID: 1, day: "2026-10-03", languageID: 1)
        #expect(await source.dayCalls.count == 1)
    }

    @Test func newerEPGInfoInvalidatesChannel() async throws {
        let source = MockEPGSource()
        let store = EPGStore(source: source)
        await store.apply([33: EPGInfo(mediaID: 33, updatedOn: 1)])
        _ = try await store.programs(mediaID: 33, day: "d", languageID: nil)
        _ = try await store.programs(mediaID: 76, day: "d", languageID: nil)
        await store.apply([33: EPGInfo(mediaID: 33, updatedOn: 2), 76: EPGInfo(mediaID: 76, updatedOn: 5)])
        _ = try await store.programs(mediaID: 33, day: "d", languageID: nil)   // перезапрос
        _ = try await store.programs(mediaID: 76, day: "d", languageID: nil)   // кеш: версии 76 раньше не было
        #expect(await source.dayCalls == ["33/d/0", "76/d/0", "33/d/0"])
    }

    @Test func currentIsKeyedByMediaIDAndChunked() async throws {
        let source = MockEPGSource()
        await source.setCurrent([program(33, 0), program(76, 0)])
        let store = EPGStore(source: source)
        let ids = Array(1...120) + [33, 76]
        let current = try await store.current(mediaIDs: ids, languageID: 1)
        #expect(current[33]?.title == "p33")
        #expect(current[76]?.title == "p76")
        #expect(await source.currentCalls.map(\.count) == [50, 50, 22])
    }

    @Test func currentWithNoIDsSkipsRequest() async throws {
        let source = MockEPGSource()
        let store = EPGStore(source: source)
        #expect(try await store.current(mediaIDs: [], languageID: nil).isEmpty)
        #expect(await source.currentCalls.isEmpty)
    }
}
```

- [ ] **Step 2: Тесты падают**

Run: `swift test --package-path Packages/AlemCore --filter EPGStoreTests`
Expected: `cannot find type 'EPGSource'`.

- [ ] **Step 3: Реализация**

`Packages/AlemCore/Sources/AlemCore/EPG/EPGStore.swift`:
```swift
import Foundation

public protocol EPGSource: Sendable {
    func epg(mediaIDs: [Int], languageID: Int?) async throws -> EPGResponse
    func epg(mediaID: Int, day: String, languageID: Int?) async throws -> EPGResponse
}

extension PortalClient: EPGSource {}

/// Кеш EPG по (канал, день, язык). Сбрасывается по `epg_info.updated_on`.
public actor EPGStore {
    private struct DayKey: Hashable {
        let mediaID: Int
        let day: String
        let languageID: Int?
    }

    static let chunkSize = 50

    private let source: EPGSource
    private var days: [DayKey: [Program]] = [:]
    private var versions: [Int: Int] = [:]

    public init(source: EPGSource) {
        self.source = source
    }

    public func programs(mediaID: Int, day: String, languageID: Int?) async throws -> [Program] {
        let key = DayKey(mediaID: mediaID, day: day, languageID: languageID)
        if let cached = days[key] { return cached }
        let programs = try await source.epg(mediaID: mediaID, day: day, languageID: languageID).programs
        days[key] = programs
        return programs
    }

    /// Текущая передача для каждого канала (запросы пачками по 50).
    public func current(mediaIDs: [Int], languageID: Int?) async throws -> [Int: Program] {
        var result: [Int: Program] = [:]
        var start = 0
        while start < mediaIDs.count {
            let chunk = Array(mediaIDs[start..<min(start + Self.chunkSize, mediaIDs.count)])
            for program in try await source.epg(mediaIDs: chunk, languageID: languageID).programs {
                result[program.mediaID] = program
            }
            start += Self.chunkSize
        }
        return result
    }

    public func apply(_ info: [Int: EPGInfo]) {
        for (id, item) in info {
            if let known = versions[id], known != item.updatedOn {
                days = days.filter { $0.key.mediaID != id }
            }
            versions[id] = item.updatedOn
        }
    }

    public func clear() {
        days.removeAll()
        versions.removeAll()
    }
}
```

- [ ] **Step 4: Тесты проходят**

Run: `swift test --package-path Packages/AlemCore --filter EPGStoreTests`
Expected: 6 тестов passed.

- [ ] **Step 5: Commit**

```bash
git add Packages/AlemCore
git commit -m "AlemCore: EPGStore — кеш по дням, текущие передачи пачками, инвалидация

Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>
Claude-Session: https://claude.ai/code/session_015tkg9WmfzBtZ6B6QQFpCUA"
```

---

### Task 8: SessionStore и Keychain

**Files:**
- Create: `Packages/AlemCore/Sources/AlemCore/Session/SecureStore.swift`
- Create: `Packages/AlemCore/Sources/AlemCore/Session/SessionStore.swift`
- Test: `Packages/AlemCore/Tests/AlemCoreTests/Support/MockPortalAPI.swift`, `SessionStoreTests.swift`

**Interfaces:**
- Consumes: `PortalClient` и его методы, модели, `ServerClock`, `StreamContext` (Tasks 4–6).
- Produces:
  - `public protocol SecureStore: Sendable { func string(forKey:) -> String?; func set(_:forKey:) }`, `public struct KeychainStore: SecureStore`, `public final class InMemorySecureStore: SecureStore`.
  - `public protocol PortalAPI: Sendable` (с ним совместим `PortalClient`) с методами:
    - `setSession(_:)`, `setMacaddr(_:)`;
    - `getDomainConfig()`, `login(macaddr:)`, `registerTerminal(username:password:macaddr:)`, `unregisterTerminal(macaddr:)`;
    - `authorizeTerminal(nocache:)`, `checkUpdate()`.
  - `public enum StartResult: Sendable { signedIn(AuthorizeResult), needsCredentials }`.
  - `public struct RefreshResult: Sendable { authorization: AuthorizeResult; epgInfo: [Int: EPGInfo]?; reloaded: Bool }`.
  - `public actor SessionStore` с методами:
    - `init(api: PortalAPI, store: SecureStore, macKey: String)`;
    - `domain`, `authorization`, `clock`, `macaddr`, `updatePeriod()`;
    - `start()`, `signIn(username:password:)`, `reauthorize()`, `reload()`, `refresh()`, `signOut()`;
    - `streamContext() -> StreamContext?`.

- [ ] **Step 1: Мок API**

`Packages/AlemCore/Tests/AlemCoreTests/Support/MockPortalAPI.swift`:
```swift
import Foundation
@testable import AlemCore

actor MockPortalAPI: PortalAPI {
    var calls: [String] = []
    var session: String?
    var mac: String?
    var loginResult: Result<LoginResult, PortalError> = .success(LoginResult(sessionID: "SID", userID: 1))
    var registerResult: Result<LoginResult, PortalError> = .success(LoginResult(sessionID: "SID2", macaddr: "00:1A:79:00:00:01", userID: 1))
    var authorization: AuthorizeResult
    var updates: [CheckUpdateResult] = []

    init(authorization: AuthorizeResult) {
        self.authorization = authorization
    }

    func setLogin(_ r: Result<LoginResult, PortalError>) { loginResult = r }
    func setUpdates(_ u: [CheckUpdateResult]) { updates = u }
    func setAuthorization(_ a: AuthorizeResult) { authorization = a }

    func setSession(_ id: String?) { session = id }
    func setMacaddr(_ m: String?) { mac = m }

    func getDomainConfig() async throws -> DomainConfig {
        calls.append("get_domain_config")
        return DomainConfig(name: "tmalem", updatedOn: 100, serverNow: Date(timeIntervalSince1970: 1_000_000))
    }

    func login(macaddr: String?) async throws -> LoginResult {
        calls.append("login")
        return try loginResult.get()
    }

    func registerTerminal(username: String, password: String, macaddr: String?) async throws -> LoginResult {
        calls.append("register_terminal")
        return try registerResult.get()
    }

    func unregisterTerminal(macaddr: String) async throws {
        calls.append("unregister_terminal")
    }

    func authorizeTerminal(nocache: Bool) async throws -> AuthorizeResult {
        calls.append(nocache ? "authorize_terminal(nocache)" : "authorize_terminal")
        return authorization
    }

    func checkUpdate() async throws -> CheckUpdateResult {
        calls.append("check_update")
        return updates.isEmpty ? CheckUpdateResult(authorized: true) : updates.removeFirst()
    }
}
```

- [ ] **Step 2: Написать падающие тесты**

`Packages/AlemCore/Tests/AlemCoreTests/SessionStoreTests.swift`:
```swift
import Testing
import Foundation
@testable import AlemCore

@Suite struct SessionStoreTests {
    let macKey = "terminal.macaddr.telecom.alemtv.tm"

    func make(mac: String? = nil) throws -> (SessionStore, MockPortalAPI, InMemorySecureStore) {
        let api = MockPortalAPI(authorization: try Fixture.authorize())
        let store = InMemorySecureStore()
        if let mac { store.set(mac, forKey: macKey) }
        return (SessionStore(api: api, store: store, macKey: macKey), api, store)
    }

    @Test func startWithoutMacNeedsCredentials() async throws {
        let (session, api, _) = try make()
        guard case .needsCredentials = try await session.start() else { Issue.record("expected needsCredentials"); return }
        #expect(await api.calls == ["get_domain_config"])
    }

    @Test func startWithMacSignsIn() async throws {
        let (session, api, _) = try make(mac: "00:1A:79:00:00:01")
        guard case .signedIn(let a) = try await session.start() else { Issue.record("expected signedIn"); return }
        #expect(!a.channels.isEmpty)
        #expect(await api.calls == ["get_domain_config", "login", "authorize_terminal"])
        #expect(await api.session == "SID")
        #expect(await api.mac == "00:1A:79:00:00:01")
        let context = try #require(await session.streamContext())
        #expect(context.sessionID == "SID")
        #expect(context.domain == "tmalem")
        #expect(context.tokens["Key-1"]?.token1 == "T1")
    }

    @Test func startWithStaleMacNeedsCredentials() async throws {
        let (session, api, _) = try make(mac: "00:1A:79:00:00:09")
        await api.setLogin(.failure(.notFound("not found")))
        guard case .needsCredentials = try await session.start() else { Issue.record("expected needsCredentials"); return }
    }

    @Test func startPropagatesNetworkErrors() async throws {
        let (session, api, _) = try make(mac: "00:1A:79:00:00:01")
        await api.setLogin(.failure(.transport("offline")))
        await #expect(throws: PortalError.transport("offline")) { try await session.start() }
    }

    @Test func signInStoresMac() async throws {
        let (session, api, store) = try make()
        _ = try await session.start()
        let a = try await session.signIn(username: "user", password: "pass")
        #expect(!a.channels.isEmpty)
        #expect(store.string(forKey: macKey) == "00:1A:79:00:00:01")
        #expect(await api.session == "SID2")
        #expect(await api.calls.suffix(2) == ["register_terminal", "authorize_terminal"])
    }

    @Test func refreshReplacesTokensWithoutReload() async throws {
        let (session, api, _) = try make(mac: "00:1A:79:00:00:01")
        _ = try await session.start()
        let current = try #require(await session.authorization)
        await api.setUpdates([CheckUpdateResult(
            authorized: true, domainUpdatedOn: 100,
            subscriberUpdatedOn: current.subscriberUpdatedOn, terminalUpdatedOn: current.terminalUpdatedOn,
            tokens: ["Key-1": MediaToken(name: "Key-1", token1: "T9", token2: "T8")],
            epgInfo: [33: EPGInfo(mediaID: 33, updatedOn: 42)]
        )])
        let r = try await session.refresh()
        #expect(!r.reloaded)
        #expect(r.epgInfo?[33]?.updatedOn == 42)
        #expect(await session.streamContext()?.tokens["Key-1"]?.token1 == "T9")
        #expect(await api.calls.last == "check_update")
    }

    @Test func refreshReauthorizesWhenAuthorizedMissing() async throws {
        let (session, api, _) = try make(mac: "00:1A:79:00:00:01")
        _ = try await session.start()
        await api.setUpdates([CheckUpdateResult(authorized: false)])
        let r = try await session.refresh()
        #expect(r.reloaded)
        #expect(await api.calls.suffix(3) == ["check_update", "login", "authorize_terminal"])
    }

    @Test func refreshReloadsWhenSubscriberChanged() async throws {
        let (session, api, _) = try make(mac: "00:1A:79:00:00:01")
        _ = try await session.start()
        let current = try #require(await session.authorization)
        await api.setUpdates([CheckUpdateResult(authorized: true, domainUpdatedOn: 100,
                                                subscriberUpdatedOn: current.subscriberUpdatedOn + 1,
                                                terminalUpdatedOn: current.terminalUpdatedOn)])
        let r = try await session.refresh()
        #expect(r.reloaded)
        #expect(await api.calls.last == "authorize_terminal(nocache)")
    }

    @Test func refreshSyncsClock() async throws {
        let (session, api, _) = try make(mac: "00:1A:79:00:00:01")
        _ = try await session.start()
        let serverNow = Date().addingTimeInterval(120)
        await api.setUpdates([CheckUpdateResult(authorized: true, domainUpdatedOn: 100, serverNow: serverNow)])
        _ = try await session.refresh()
        let offset = await session.clock.offset
        #expect(abs(offset - 120) < 2)
    }

    @Test func signOutClearsTerminal() async throws {
        let (session, api, store) = try make(mac: "00:1A:79:00:00:01")
        _ = try await session.start()
        await session.signOut()
        #expect(store.string(forKey: macKey) == nil)
        #expect(await session.streamContext() == nil)
        #expect(await api.session == nil)
        #expect(await api.calls.last == "unregister_terminal")
    }
}
```

- [ ] **Step 3: Тесты падают**

Run: `swift test --package-path Packages/AlemCore --filter SessionStoreTests`
Expected: `cannot find type 'PortalAPI'`.

- [ ] **Step 4: Реализация**

`Packages/AlemCore/Sources/AlemCore/Session/SecureStore.swift`:
```swift
import Foundation
import Security

public protocol SecureStore: Sendable {
    func string(forKey key: String) -> String?
    func set(_ value: String?, forKey key: String)
}

/// Keychain (generic password). Значение переживает переустановку приложения.
public struct KeychainStore: SecureStore {
    let service: String

    public init(service: String = "com.alexvamp.alemtv") {
        self.service = service
    }

    public func string(forKey key: String) -> String? {
        var query = base(key)
        query[kSecReturnData] = true
        query[kSecMatchLimit] = kSecMatchLimitOne
        var out: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &out) == errSecSuccess, let data = out as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }

    public func set(_ value: String?, forKey key: String) {
        SecItemDelete(base(key) as CFDictionary)
        guard let value else { return }
        var query = base(key)
        query[kSecValueData] = Data(value.utf8)
        query[kSecAttrAccessible] = kSecAttrAccessibleAfterFirstUnlock
        SecItemAdd(query as CFDictionary, nil)
    }

    private func base(_ key: String) -> [CFString: Any] {
        [kSecClass: kSecClassGenericPassword, kSecAttrService: service, kSecAttrAccount: key]
    }
}

/// Для тестов и превью.
public final class InMemorySecureStore: SecureStore, @unchecked Sendable {
    private let lock = NSLock()
    private var values: [String: String] = [:]

    public init() {}

    public func string(forKey key: String) -> String? {
        lock.withLock { values[key] }
    }

    public func set(_ value: String?, forKey key: String) {
        lock.withLock { values[key] = value }
    }
}
```

`Packages/AlemCore/Sources/AlemCore/Session/SessionStore.swift`:
```swift
import Foundation

public protocol PortalAPI: Sendable {
    func setSession(_ id: String?) async
    func setMacaddr(_ mac: String?) async
    func getDomainConfig() async throws -> DomainConfig
    func login(macaddr: String?) async throws -> LoginResult
    func registerTerminal(username: String, password: String, macaddr: String?) async throws -> LoginResult
    func unregisterTerminal(macaddr: String) async throws
    func authorizeTerminal(nocache: Bool) async throws -> AuthorizeResult
    func checkUpdate() async throws -> CheckUpdateResult
}

extension PortalClient: PortalAPI {}

public enum StartResult: Sendable {
    case signedIn(AuthorizeResult)
    case needsCredentials
}

public struct RefreshResult: Sendable {
    public var authorization: AuthorizeResult
    public var epgInfo: [Int: EPGInfo]?
    /// Каталог перезагружен (повторный вход или изменения на сервере).
    public var reloaded: Bool
}

/// Жизненный цикл терминала: MAC в Keychain, session_id в памяти, check_update.
public actor SessionStore {
    private let api: PortalAPI
    private let store: SecureStore
    private let macKey: String
    private var sessionID: String?

    public private(set) var domain: DomainConfig?
    public private(set) var authorization: AuthorizeResult?
    public private(set) var clock = ServerClock()

    public init(api: PortalAPI, store: SecureStore, macKey: String) {
        self.api = api
        self.store = store
        self.macKey = macKey
    }

    public var macaddr: String? { store.string(forKey: macKey) }

    public func updatePeriod() -> Int { domain?.portalUpdatePeriod ?? 300 }

    /// Холодный старт: конфиг домена и вход по сохранённому MAC.
    public func start() async throws -> StartResult {
        let config = try await api.getDomainConfig()
        domain = config
        if let now = config.serverNow { clock.sync(serverNow: now) }
        guard let mac = macaddr else { return .needsCredentials }
        do {
            return .signedIn(try await loginAndAuthorize(mac: mac))
        } catch let error as PortalError where error.requiresSignIn {
            return .needsCredentials
        }
    }

    /// Привязка терминала логином и паролем абонента.
    public func signIn(username: String, password: String) async throws -> AuthorizeResult {
        if domain == nil { domain = try await api.getDomainConfig() }
        let result = try await api.registerTerminal(username: username, password: password, macaddr: macaddr)
        if let mac = result.macaddr { store.set(mac, forKey: macKey) }
        guard let mac = result.macaddr ?? macaddr else { throw PortalError.decoding("register_terminal: no macaddr") }
        await api.setMacaddr(mac)
        sessionID = result.sessionID
        await api.setSession(result.sessionID)
        return try await authorize(nocache: false)
    }

    /// Новый session_id по MAC (после -32003, 403 стримера, смены сети).
    public func reauthorize() async throws -> AuthorizeResult {
        guard let mac = macaddr else { throw PortalError.unauthorized("no terminal") }
        return try await loginAndAuthorize(mac: mac)
    }

    /// Перечитать каталог (после смены языка или профиля).
    public func reload() async throws -> AuthorizeResult {
        try await authorize(nocache: true)
    }

    public func refresh() async throws -> RefreshResult {
        guard let current = authorization else { throw PortalError.unauthorized("not signed in") }
        let update = try await api.checkUpdate()
        if let now = update.serverNow { clock.sync(serverNow: now) }
        guard update.authorized else {
            let a = try await reauthorize()
            return RefreshResult(authorization: a, epgInfo: a.epgInfo, reloaded: true)
        }
        var domainChanged = false
        if let updated = update.domainUpdatedOn, updated > (domain?.updatedOn ?? 0) {
            domain = try await api.getDomainConfig()
            domainChanged = true
        }
        if domainChanged
            || (update.subscriberUpdatedOn ?? 0) > current.subscriberUpdatedOn
            || (update.terminalUpdatedOn ?? 0) > current.terminalUpdatedOn {
            let a = try await authorize(nocache: true)
            return RefreshResult(authorization: a, epgInfo: a.epgInfo, reloaded: true)
        }
        var a = current
        if let tokens = update.tokens { a.tokens = tokens }
        authorization = a
        return RefreshResult(authorization: a, epgInfo: update.epgInfo, reloaded: false)
    }

    public func signOut() async {
        if let mac = macaddr { try? await api.unregisterTerminal(macaddr: mac) }
        store.set(nil, forKey: macKey)
        sessionID = nil
        authorization = nil
        await api.setSession(nil)
        await api.setMacaddr(nil)
    }

    public func streamContext() -> StreamContext? {
        guard let sessionID, let authorization else { return nil }
        return StreamContext(sessionID: sessionID, domain: domain?.name ?? "tmalem",
                             tokens: authorization.tokens, serverNow: clock.now())
    }

    // MARK: - Внутреннее

    private func loginAndAuthorize(mac: String) async throws -> AuthorizeResult {
        await api.setSession(nil)
        await api.setMacaddr(mac)
        let result = try await api.login(macaddr: mac)
        sessionID = result.sessionID
        await api.setSession(result.sessionID)
        return try await authorize(nocache: false)
    }

    private func authorize(nocache: Bool) async throws -> AuthorizeResult {
        let a = try await api.authorizeTerminal(nocache: nocache)
        authorization = a
        if let now = a.serverNow { clock.sync(serverNow: now) }
        return a
    }
}
```

Расхождение со спецификацией §4.4, п. 2: если MAC нет, `login` с `create_macaddr` не вызывается, а сразу открывается экран «Вход». Новый MAC выдаёт `register_terminal`. Так на сервере не появляются непривязанные терминалы, а поведение для пользователя то же самое.

- [ ] **Step 5: Тесты проходят**

Run: `swift test --package-path Packages/AlemCore --filter SessionStoreTests`
Expected: 10 тестов passed.

- [ ] **Step 6: Commit**

```bash
git add Packages/AlemCore
git commit -m "AlemCore: SessionStore — вход по MAC, регистрация, check_update, ротация токенов

Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>
Claude-Session: https://claude.ai/code/session_015tkg9WmfzBtZ6B6QQFpCUA"
```

---

### Task 9: Движок воспроизведения: сторож зависаний, монитор бездействия, AVPlayerEngine

**Files:**
- Create: `Packages/AlemCore/Sources/AlemCore/Playback/FreezeWatchdog.swift`
- Create: `Packages/AlemCore/Sources/AlemCore/Playback/IdleMonitor.swift`
- Create: `Packages/AlemCore/Sources/AlemCore/Playback/PlayerEngine.swift`
- Test: `Packages/AlemCore/Tests/AlemCoreTests/PlaybackTests.swift`

**Interfaces:**
- Produces:
  - `public struct FreezeWatchdog: Sendable` с `init(threshold: TimeInterval = 6)`, `mutating observe(position:wantsToPlay:likelyToKeepUp:now:) -> Bool` и `mutating reset()`.
  - `public struct IdleMonitor: Sendable` с `init(timeout:now:)`, `mutating touch(now:)` и `isExpired(now:) -> Bool`.
  - `public enum PlaybackState: Sendable, Equatable { idle, loading, playing, paused, failed(String), ended }`.
  - `@MainActor public protocol PlayerEngine: AnyObject` с членами `state`, `currentTime`, `currentDate`, `load(_:startAt:)`, `play()`, `pause()`, `seek(to:)`, `stop()`.
  - `@MainActor @Observable public final class AVPlayerEngine: PlayerEngine`. Свойство `player: AVPlayer`. Колбэки: `onStarted`, `onFailed`, `onEnded`, `onStalled`, `onUserPause`, `onUserResume`.

- [ ] **Step 1: Написать падающие тесты**

`Packages/AlemCore/Tests/AlemCoreTests/PlaybackTests.swift`:
```swift
import Testing
import Foundation
@testable import AlemCore

@Suite struct PlaybackTests {
    func t(_ s: TimeInterval) -> Date { Date(timeIntervalSince1970: s) }

    @Test func frozenPositionTriggersAfterThreshold() {
        var w = FreezeWatchdog(threshold: 6)
        var fired: [Int] = []
        for second in 0...10 where w.observe(position: 42, wantsToPlay: true, likelyToKeepUp: false, now: t(Double(second))) {
            fired.append(second)
        }
        // 0: первое наблюдение; с 1 начинается заморозка; срабатывает на 7; затем отсчёт заново с 8
        #expect(fired == [7])
    }

    @Test func movingPositionNeverTriggers() {
        var w = FreezeWatchdog()
        for second in 0...20 {
            #expect(!w.observe(position: Double(second), wantsToPlay: true, likelyToKeepUp: false, now: t(Double(second))))
        }
    }

    @Test func pausedOrHealthyBufferNeverTriggers() {
        var w = FreezeWatchdog()
        for second in 0...20 {
            #expect(!w.observe(position: 5, wantsToPlay: false, likelyToKeepUp: false, now: t(Double(second))))
        }
        var h = FreezeWatchdog()
        for second in 0...20 {
            #expect(!h.observe(position: 5, wantsToPlay: true, likelyToKeepUp: true, now: t(Double(second))))
        }
    }

    @Test func resetForgetsHistory() {
        var w = FreezeWatchdog(threshold: 2)
        _ = w.observe(position: 1, wantsToPlay: true, likelyToKeepUp: false, now: t(0))
        _ = w.observe(position: 1, wantsToPlay: true, likelyToKeepUp: false, now: t(1))
        w.reset()
        #expect(!w.observe(position: 1, wantsToPlay: true, likelyToKeepUp: false, now: t(3)))
    }

    @Test func idleMonitor() {
        var m = IdleMonitor(timeout: 100, now: t(0))
        #expect(!m.isExpired(now: t(99)))
        #expect(m.isExpired(now: t(100)))
        m.touch(now: t(90))
        #expect(!m.isExpired(now: t(150)))
    }

    @MainActor @Test func engineStartsIdle() {
        let engine = AVPlayerEngine()
        #expect(engine.state == .idle)
        #expect(engine.currentTime == 0)
        #expect(engine.currentDate == nil)
    }
}
```

- [ ] **Step 2: Тесты падают**

Run: `swift test --package-path Packages/AlemCore --filter PlaybackTests`
Expected: `cannot find 'FreezeWatchdog' in scope`.

- [ ] **Step 3: Реализация**

`Packages/AlemCore/Sources/AlemCore/Playback/FreezeWatchdog.swift`:
```swift
import Foundation

/// Перезапуск зависшего потока (по образцу Controller.checkFreez Android-клиента):
/// воспроизведение запрошено, буфер не успевает, позиция не двигается `threshold` секунд.
public struct FreezeWatchdog: Sendable {
    public let threshold: TimeInterval
    private var lastPosition: Double?
    private var frozenSince: Date?

    public init(threshold: TimeInterval = 6) {
        self.threshold = threshold
    }

    /// true — поток пора перезапустить.
    public mutating func observe(position: Double, wantsToPlay: Bool, likelyToKeepUp: Bool, now: Date) -> Bool {
        defer { lastPosition = position }
        guard wantsToPlay, !likelyToKeepUp, let last = lastPosition, abs(position - last) < 0.05 else {
            frozenSince = nil
            return false
        }
        let since = frozenSince ?? now
        frozenSince = since
        if now.timeIntervalSince(since) >= threshold {
            frozenSince = nil
            return true
        }
        return false
    }

    public mutating func reset() {
        lastPosition = nil
        frozenSince = nil
    }
}
```

Проверка ожидания `[7]` в тесте: при `t=0` `last == nil`, срабатывания нет. При `t=1` `frozenSince = 1`. При `t=7` проходит 6 с, сторож срабатывает и сбрасывает `frozenSince`. При `t=8` отсчёт начинается заново (`frozenSince = 8`), и до `t=10` повторного срабатывания нет.

`Packages/AlemCore/Sources/AlemCore/Playback/IdleMonitor.swift`:
```swift
import Foundation

/// Автопауза: нет нажатий на пульте дольше `timeout` (auto_pause_timeout домена).
public struct IdleMonitor: Sendable {
    public let timeout: TimeInterval
    public private(set) var lastActivity: Date

    public init(timeout: TimeInterval, now: Date = Date()) {
        self.timeout = timeout
        self.lastActivity = now
    }

    public mutating func touch(now: Date = Date()) {
        lastActivity = now
    }

    public func isExpired(now: Date = Date()) -> Bool {
        now.timeIntervalSince(lastActivity) >= timeout
    }
}
```

`Packages/AlemCore/Sources/AlemCore/Playback/PlayerEngine.swift`:
```swift
import AVFoundation
import Foundation
import Observation

public enum PlaybackState: Sendable, Equatable {
    case idle
    case loading
    case playing
    case paused
    case failed(String)
    case ended
}

@MainActor
public protocol PlayerEngine: AnyObject {
    var state: PlaybackState { get }
    /// Секунды от начала текущего элемента.
    var currentTime: TimeInterval { get }
    /// Реальное время кадра по EXT-X-PROGRAM-DATE-TIME (есть у Flussonic во всех режимах).
    var currentDate: Date? { get }
    func load(_ url: URL, startAt: TimeInterval?)
    func play()
    func pause()
    func seek(to seconds: TimeInterval)
    func stop()
}

/// Единственная реализация движка — AVPlayer (HLS HEVC/AAC играется нативно).
@MainActor @Observable
public final class AVPlayerEngine: PlayerEngine {
    public let player = AVPlayer()
    public private(set) var state: PlaybackState = .idle

    @ObservationIgnored public var onStarted: (() -> Void)?
    @ObservationIgnored public var onFailed: ((String) -> Void)?
    @ObservationIgnored public var onEnded: (() -> Void)?
    @ObservationIgnored public var onStalled: (() -> Void)?
    /// Пауза/продолжение нажаты пользователем в системном плеере (а не нами).
    @ObservationIgnored public var onUserPause: (() -> Void)?
    @ObservationIgnored public var onUserResume: (() -> Void)?

    @ObservationIgnored private var wantsToPlay = false
    @ObservationIgnored private var watchdog = FreezeWatchdog()
    @ObservationIgnored private var timeControlObservation: NSKeyValueObservation?
    @ObservationIgnored private var itemObservation: NSKeyValueObservation?
    @ObservationIgnored private var notificationTokens: [NSObjectProtocol] = []

    public init() {
        timeControlObservation = player.observe(\.timeControlStatus, options: [.new]) { [weak self] player, _ in
            let status = player.timeControlStatus
            guard let engine = self else { return }
            Task { @MainActor in engine.timeControlChanged(status) }
        }
        Task { [weak self] in
            while true {
                try? await Task.sleep(for: .seconds(1))
                guard let self else { return }
                self.tick()
            }
        }
    }

    public var currentTime: TimeInterval {
        let seconds = player.currentTime().seconds
        return seconds.isFinite ? seconds : 0
    }

    public var currentDate: Date? { player.currentItem?.currentDate() }

    public func load(_ url: URL, startAt: TimeInterval? = nil) {
        watchdog.reset()
        let item = AVPlayerItem(url: url)
        observe(item)
        state = .loading
        wantsToPlay = true
        player.replaceCurrentItem(with: item)
        if let startAt, startAt > 0 {
            player.seek(to: CMTime(seconds: startAt, preferredTimescale: 600))
        }
        player.play()
    }

    public func play() {
        wantsToPlay = true
        player.play()
    }

    public func pause() {
        wantsToPlay = false
        player.pause()
        state = .paused
    }

    public func seek(to seconds: TimeInterval) {
        watchdog.reset()
        player.seek(to: CMTime(seconds: max(0, seconds), preferredTimescale: 600))
    }

    public func stop() {
        wantsToPlay = false
        player.replaceCurrentItem(with: nil)
        state = .idle
    }

    // MARK: - Наблюдение

    private func observe(_ item: AVPlayerItem) {
        itemObservation = item.observe(\.status, options: [.new]) { [weak self] item, _ in
            guard item.status == .failed, let engine = self else { return }
            let message = item.error?.localizedDescription ?? "playback failed"
            Task { @MainActor in engine.fail(message) }
        }
        notificationTokens.forEach(NotificationCenter.default.removeObserver)
        notificationTokens = [
            NotificationCenter.default.addObserver(forName: AVPlayerItem.didPlayToEndTimeNotification, object: item, queue: .main) { [weak self] _ in
                MainActor.assumeIsolated { self?.ended() }
            },
            NotificationCenter.default.addObserver(forName: AVPlayerItem.failedToPlayToEndTimeNotification, object: item, queue: .main) { [weak self] note in
                let error = note.userInfo?[AVPlayerItemFailedToPlayToEndTimeErrorKey] as? Error
                MainActor.assumeIsolated { self?.fail(error?.localizedDescription ?? "playback failed") }
            },
        ]
    }

    private func timeControlChanged(_ status: AVPlayer.TimeControlStatus) {
        switch state {
        case .failed, .ended, .idle: return
        default: break
        }
        switch status {
        case .playing:
            if !wantsToPlay {
                wantsToPlay = true
                onUserResume?()
            }
            if state != .playing {
                state = .playing
                onStarted?()
            }
        case .paused:
            if wantsToPlay, player.currentItem?.status == .readyToPlay {
                wantsToPlay = false
                state = .paused
                onUserPause?()
            }
        case .waitingToPlayAtSpecifiedRate:
            if wantsToPlay { state = .loading }
        @unknown default:
            break
        }
    }

    private func tick() {
        guard let item = player.currentItem, state == .playing || state == .loading else { return }
        if watchdog.observe(position: currentTime, wantsToPlay: wantsToPlay,
                            likelyToKeepUp: item.isPlaybackLikelyToKeepUp, now: Date()) {
            onStalled?()
        }
    }

    private func fail(_ message: String) {
        wantsToPlay = false
        state = .failed(message)
        onFailed?(message)
    }

    private func ended() {
        wantsToPlay = false
        state = .ended
        onEnded?()
    }
}
```

- [ ] **Step 4: Тесты проходят**

Run: `swift test --package-path Packages/AlemCore --filter PlaybackTests`
Expected: 6 тестов passed.

Run (все тесты пакета): `swift test --package-path Packages/AlemCore`
Expected: всё passed, предупреждений строгой конкурентности нет. В KVO-замыканиях `self` намеренно разворачивается в `let engine` до `Task`: вложенный `@Sendable`-замыкатель не может захватывать слабую переменную `self`. Если компилятор всё же ругается, вынести обработчик в `nonisolated static func` и не менять логику.

- [ ] **Step 5: Commit**

```bash
git add Packages/AlemCore
git commit -m "AlemCore: AVPlayerEngine, сторож зависаний и монитор бездействия

Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>
Claude-Session: https://claude.ai/code/session_015tkg9WmfzBtZ6B6QQFpCUA"
```

---

### Task 10: Каркас приложения: локализация, порталы, AppModel, запуск и вход

**Files:**
- Create: `tools/gen_strings.py`, `App/Resources/Localizable.xcstrings` (генерируется)
- Create: `App/Brand.swift`, `App/Strings.swift`, `App/PortalOption.swift`, `App/AppModel.swift`, `App/RootView.swift`
- Create: `App/Features/Launch/LaunchView.swift`, `App/Features/Launch/OfflineView.swift`
- Create: `App/Features/Login/LoginView.swift`, `App/Features/Login/PortalPickerView.swift`
- Create: `App/Features/Player/PlayerModel.swift` (минимальный: `configure`, `stop`, `playInitial`, `reloadCurrent`; полностью — в Task 12)
- Modify: `App/AlemTVApp.swift`

**Interfaces:**
- Consumes: весь AlemCore (Tasks 2–9).
- Produces:
  - `struct Strings` с `init(language:)` и `callAsFunction(_ key:)` / `callAsFunction(_ key:, _ args:)`.
  - `struct PortalOption` с полями `name`, `host`, `baseURL`, `logoURL(channelID:)`, `all`, `saved`, `save(_:)`.
  - `@MainActor @Observable final class AppModel`:
    - состояние: `route: Route`, `authorization`, `nowPlaying: [Int: Program]`, `clock: ServerClock`, `strings`, `portal`, `showGuide`, `loginError`, `isBusy`, `player: PlayerModel`;
    - методы: `start()`, `signIn(username:password:)`, `signOut()`, `refresh()`, `reauthorize()`, `becameActive()`, `switchPortal(_:)`, `loadNowPlaying(_:)`, `categoryPlaylists`, `logoURL(for:)`, `rememberLastChannel(_:)`;
    - избранное: `isFavorite(_:)`, `toggleFavorite(_:)`;
    - язык: `setLanguage(_:)`;
    - профиль: `selectProfile(_:)`, `confirmProfilePassword(_:)`, `cancelProfilePassword()`.
  - `enum AppModel.Route { launching, login, offline, main }`.

- [ ] **Step 1: Генератор строк**

`tools/gen_strings.py`:
```python
#!/usr/bin/env python3
"""Генерирует App/Resources/Localizable.xcstrings (ru — исходный язык, tk, en).

Туркменские строки частично взяты из локали портала (resources/portal/locale/tk.js);
помеченные «# tk?» — машинный перевод, требуют вычитки носителем.
"""
import json
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "App", "Resources", "Localizable.xcstrings")

STRINGS = {
    # key: (ru, en, tk)
    "login.title": ("Вход", "Login", "Girmek"),
    "login.username": ("Имя", "Username", "Ulanyjynyň ady"),
    "login.password": ("Пароль", "Password", "Açar sözi"),
    "login.submit": ("Войти", "Sign in", "Girmek"),
    "login.error.denied": ("Доступ запрещен", "Access denied", "Inkär edildi"),
    "login.changePortal": ("Сменить портал", "Change portal", "Portaly üýtgetmek"),  # tk?
    "error.network": ("Сервис недоступен! Проверьте подключение к сети.", "Service unavailable! Check your network connection.", "Hyzmat elýeterli däl! Ulgama birikmäni barlaň."),  # tk?
    "error.retry": ("Повтор", "Repeat", "Gaýtalamak"),
    "guide.channels": ("Каналы", "Channels", "Telekanallar"),  # tk?
    "guide.favorites": ("Избранное", "Favorites", "Saýlanan"),
    "guide.settings": ("Настройки", "Settings", "Sazlamalar"),
    "channel.schedule": ("Программа передач", "TV guide", "Teleýaýlymlaryň sanawy"),  # tk?
    "channel.addFavorite": ("В избранное", "Add to favorites", "Saýlanana goşmak"),  # tk?
    "channel.removeFavorite": ("Убрать из избранного", "Remove from favorites", "Saýlanandan aýyrmak"),  # tk?
    "epg.empty": ("Программа передач отсутствует", "TV listings not found", "Teleýaýlymlaryň sanawy ýok"),
    "epg.today": ("Сегодня", "Today", "Şu gün"),
    "epg.archive": ("В архиве", "In archive", "Arhiwde"),  # tk?
    "epg.live": ("Сейчас в эфире", "On air now", "Häzir efirde"),  # tk?
    "player.unavailable": ("Канал недоступен", "The channel is unavailable", "Telekanal elýeterli däl"),
    "player.recordingUnavailable": ("Видео недоступно", "The video is unavailable", "Wideo elýeterli däl"),
    "player.goLive": ("В эфир", "Go live", "Efire"),  # tk?
    "player.startOver": ("С начала", "Start over", "Başdan"),  # tk?
    "player.back10": ("−10 с", "−10 s", "−10 s"),
    "player.forward10": ("+10 с", "+10 s", "+10 s"),
    "player.behindLive": ("%@ от эфира", "%@ behind live", "efirden %@ yzda"),  # tk?
    "player.info": ("Программа", "Program", "Gepleşik"),  # tk?
    "player.continue.title": ("Продолжить просмотр?", "Continue watching?", "Tomaşa etmegi dowam etmelimi?"),  # tk?
    "player.continue": ("Продолжить", "Continue", "Dowam etmek"),
    "settings.profile": ("Профиль", "Profile", "Şahsy bölüm"),
    "settings.language": ("Язык", "Language", "Dil"),
    "settings.portal": ("Портал", "Portal", "Portal"),
    "settings.about": ("О приложении", "About", "Programma barada"),  # tk?
    "settings.version": ("Версия", "Version", "Wersiýa"),  # tk?
    "settings.terminal": ("Терминал (MAC)", "Terminal (MAC)", "Terminal (MAC)"),
    "settings.logout": ("Выход из аккаунта", "Logout", "Çykmak"),
    "settings.logout.confirm": ("Отвязать это устройство от аккаунта?", "Unlink this device from the account?", "Bu enjamy hasapdan aýyrmalymy?"),  # tk?
    "profile.enterPassword": ("Введите пароль для профиля", "Enter password for profile", "Şahsy bölümi üçin açar sözüni giriziň"),
    "profile.wrongPassword": ("Ошибка ввода", "Enter failure", "Girizişde ýalňyşlyk"),
    "portal.confirm": ("Сменить портал? Потребуется войти заново.", "Switch portal? You will need to sign in again.", "Portaly üýtgetmelimi? Täzeden girmeli bolarsyňyz."),  # tk?
    "common.cancel": ("Отмена", "Cancel", "Bes etmek"),
    "common.ok": ("OK", "OK", "OK"),
}


def unit(value):
    return {"stringUnit": {"state": "translated", "value": value}}


catalog = {
    "sourceLanguage": "ru",
    "strings": {
        key: {"localizations": {"ru": unit(ru), "en": unit(en), "tk": unit(tk)}}
        for key, (ru, en, tk) in sorted(STRINGS.items())
    },
    "version": "1.0",
}
os.makedirs(os.path.dirname(OUT), exist_ok=True)
with open(OUT, "w", encoding="utf-8") as f:
    json.dump(catalog, f, ensure_ascii=False, indent=2)
print(f"{len(STRINGS)} keys -> {OUT}")
```

Run: `python3 tools/gen_strings.py`
Expected: `41 keys -> …/Localizable.xcstrings`.

- [ ] **Step 2: Общие типы UI**

`App/Brand.swift`:
```swift
import SwiftUI

enum Brand {
    /// #FF8800 — акцент из Android-приложения AlemTV.
    static let accent = Color(red: 1.0, green: 0x88 / 255.0, blue: 0)
    static let background = Color.black
}
```

`App/Strings.swift`:
```swift
import Foundation

/// Локализованные строки с выбором языка в рантайме (язык терминала задаёт сервер: ru/tk/en).
struct Strings {
    let language: String
    private let bundle: Bundle

    init(language: String) {
        self.language = language
        bundle = Bundle.main.path(forResource: language, ofType: "lproj").flatMap(Bundle.init(path:)) ?? .main
    }

    func callAsFunction(_ key: String) -> String {
        bundle.localizedString(forKey: key, value: nil, table: nil)
    }

    func callAsFunction(_ key: String, _ args: CVarArg...) -> String {
        String(format: self(key), arguments: args)
    }

    var locale: Locale { Locale(identifier: language) }
}
```

`App/PortalOption.swift`:
```swift
import Foundation

/// Порталы оператора (Controller.setMultiPortalDefault в Android-клиенте).
struct PortalOption: Hashable, Identifiable {
    let name: String
    let host: String

    var id: String { host }
    var baseURL: URL { URL(string: "http://\(host)")! }

    func logoURL(channelID: Int) -> URL {
        baseURL.appendingPathComponent("resources/portal/images/logo96/\(channelID).png")
    }

    static let all = [
        PortalOption(name: "Turkmentelekom", host: "telecom.alemtv.tm"),
        PortalOption(name: "ASTU", host: "astu.tmalem.tv"),
        PortalOption(name: "Arkadag", host: "ark.alemtv.tm"),
        PortalOption(name: "ASTU Local", host: "local-astu.alemtv.tm"),
    ]

    private static let defaultsKey = "portal.host"

    static var saved: PortalOption {
        let host = UserDefaults.standard.string(forKey: defaultsKey)
        return all.first { $0.host == host } ?? all[0]
    }

    static func save(_ option: PortalOption) {
        UserDefaults.standard.set(option.host, forKey: defaultsKey)
    }
}
```

- [ ] **Step 3: PlayerModel (минимальный каркас)**

`App/Features/Player/PlayerModel.swift` (Task 12 заменит его целиком):
```swift
import Foundation
import Observation
import AlemCore

@MainActor @Observable
final class PlayerModel {
    let engine = AVPlayerEngine()
    @ObservationIgnored weak var app: AppModel?
    @ObservationIgnored private var session: SessionStore
    @ObservationIgnored private var epg: EPGStore

    init(session: SessionStore, epg: EPGStore) {
        self.session = session
        self.epg = epg
    }

    func configure(session: SessionStore, epg: EPGStore) {
        self.session = session
        self.epg = epg
    }

    func playInitial() {}
    func reloadCurrent() {}
    func stop() { engine.stop() }
}
```

- [ ] **Step 4: AppModel**

`App/AppModel.swift`:
```swift
import Foundation
import Network
import Observation
import UIKit
import os
import AlemCore

@MainActor @Observable
final class AppModel {
    enum Route: Equatable {
        case launching, login, offline, main
    }

    enum ProfileChange: Equatable {
        case done
        case needsPassword
        case failed(String)
    }

    var route: Route = .launching
    private(set) var authorization: AuthorizeResult?
    private(set) var nowPlaying: [Int: Program] = [:]
    private(set) var clock = ServerClock()
    private(set) var strings = Strings(language: "ru")
    private(set) var portal: PortalOption
    var showGuide = false
    var loginError: String?
    var isBusy = false
    let player: PlayerModel

    @ObservationIgnored private(set) var client: PortalClient
    @ObservationIgnored private(set) var session: SessionStore
    @ObservationIgnored private(set) var epg: EPGStore
    @ObservationIgnored private var refreshTask: Task<Void, Never>?
    @ObservationIgnored private let pathMonitor = NWPathMonitor()
    @ObservationIgnored private var networkWasSatisfied: Bool?
    @ObservationIgnored private let log = Logger(subsystem: "com.alexvamp.alemtv", category: "app")

    init(portal: PortalOption = .saved) {
        self.portal = portal
        let services = Self.makeServices(portal)
        client = services.client
        session = services.session
        epg = services.epg
        player = PlayerModel(session: services.session, epg: services.epg)
        player.app = self
        startNetworkMonitor()
    }

    private static func makeServices(_ portal: PortalOption) -> (client: PortalClient, session: SessionStore, epg: EPGStore) {
        let version = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "0"
        let terminal = TerminalInfo.appleTV(appVersion: version, osVersion: UIDevice.current.systemVersion)
        let client = PortalClient(baseURL: portal.baseURL, terminal: terminal)
        let session = SessionStore(api: client, store: KeychainStore(), macKey: "terminal.macaddr.\(portal.host)")
        return (client, session, EPGStore(source: client))
    }

    // MARK: - Вход

    func start() async {
        route = .launching
        do {
            switch try await session.start() {
            case .needsCredentials:
                clock = await session.clock
                route = .login
            case .signedIn(let a):
                await apply(a)
                route = .main
                player.playInitial()
            }
        } catch {
            log.error("start failed: \(String(describing: error), privacy: .public)")
            route = .offline
        }
    }

    func signIn(username: String, password: String) async {
        isBusy = true
        loginError = nil
        defer { isBusy = false }
        do {
            let a = try await session.signIn(username: username, password: password)
            await apply(a)
            route = .main
            player.playInitial()
        } catch let error as PortalError {
            switch error {
            case .unauthorized, .notFound, .server:
                loginError = error.serverMessage ?? strings("login.error.denied")
            default:
                loginError = strings("error.network")
            }
        } catch {
            loginError = strings("error.network")
        }
    }

    func signOut() async {
        refreshTask?.cancel()
        player.stop()
        await session.signOut()
        await epg.clear()
        authorization = nil
        nowPlaying = [:]
        showGuide = false
        route = .login
    }

    func switchPortal(_ option: PortalOption) async {
        refreshTask?.cancel()
        player.stop()
        PortalOption.save(option)
        portal = option
        let services = Self.makeServices(option)
        client = services.client
        session = services.session
        epg = services.epg
        player.configure(session: services.session, epg: services.epg)
        authorization = nil
        nowPlaying = [:]
        await start()
    }

    // MARK: - Обновление

    private func apply(_ a: AuthorizeResult) async {
        authorization = a
        clock = await session.clock
        if let code = a.language?.code, code != strings.language { strings = Strings(language: code) }
        await epg.apply(a.epgInfo)
        startRefreshLoop()
    }

    private func startRefreshLoop() {
        refreshTask?.cancel()
        refreshTask = Task { [weak self] in
            while !Task.isCancelled {
                guard let period = await self?.session.updatePeriod() else { return }
                try? await Task.sleep(for: .seconds(period))
                if Task.isCancelled { return }
                await self?.refresh()
            }
        }
    }

    func refresh() async {
        do {
            let r = try await session.refresh()
            authorization = r.authorization
            clock = await session.clock
            if let info = r.epgInfo { await epg.apply(info) }
        } catch let error as PortalError where error.requiresSignIn {
            log.notice("terminal no longer authorized")
            await signOutLocally()
        } catch {
            log.error("refresh failed: \(String(describing: error), privacy: .public)")
        }
    }

    /// Новый session_id (403 стримера, смена сети). Бросает, если терминал отвязан.
    func reauthorize() async throws {
        do {
            let a = try await session.reauthorize()
            await apply(a)
        } catch let error as PortalError where error.requiresSignIn {
            await signOutLocally()
            throw error
        }
    }

    func becameActive() async {
        guard route == .main else { return }
        await refresh()
    }

    private func signOutLocally() async {
        refreshTask?.cancel()
        player.stop()
        authorization = nil
        showGuide = false
        route = .login
    }

    // MARK: - Сеть

    private func startNetworkMonitor() {
        pathMonitor.pathUpdateHandler = { [weak self] path in
            let satisfied = path.status == .satisfied
            guard let model = self else { return }
            Task { @MainActor in model.networkChanged(satisfied: satisfied) }
        }
        pathMonitor.start(queue: DispatchQueue(label: "com.alexvamp.alemtv.network"))
    }

    private func networkChanged(satisfied: Bool) {
        defer { networkWasSatisfied = satisfied }
        guard satisfied, networkWasSatisfied == false else { return }
        Task {
            switch route {
            case .offline:
                await start()
            case .main:
                try? await reauthorize()
                player.reloadCurrent()
            default:
                break
            }
        }
    }

    // MARK: - Каталог

    /// Рубрики для гида: все ТВ-плейлисты кроме избранного и пустых.
    var categoryPlaylists: [Playlist] {
        guard let a = authorization else { return [] }
        return a.playlists.filter { !$0.isFavorites && !a.channels(in: $0).isEmpty }
    }

    func logoURL(for channel: Channel) -> URL? {
        if let logo = channel.logoURL, !logo.isEmpty, let url = URL(string: logo) { return url }
        return channel.channelID.map(portal.logoURL(channelID:))
    }

    func loadNowPlaying(_ channels: [Channel]) async {
        let ids = channels.map(\.id)
        guard !ids.isEmpty,
              let current = try? await epg.current(mediaIDs: ids, languageID: authorization?.language?.id) else { return }
        nowPlaying.merge(current) { _, new in new }
    }

    /// Текущая передача канала, если она ещё идёт.
    func program(onAir channel: Channel) -> Program? {
        guard let p = nowPlaying[channel.id], p.isOnAir(at: clock.now()) else { return nil }
        return p
    }

    func rememberLastChannel(_ channel: Channel) {
        Task { try? await client.setTerminalParams(["media_id": .int(channel.id)]) }
    }

    // MARK: - Избранное

    func isFavorite(_ channel: Channel) -> Bool {
        authorization?.favorites?.mediaIDs.contains(channel.id) ?? false
    }

    func toggleFavorite(_ channel: Channel) async {
        guard var a = authorization, let favorites = a.favorites,
              let index = a.playlists.firstIndex(where: { $0.id == favorites.id }) else { return }
        let add = !isFavorite(channel)
        do {
            try await client.setFavorite(add, playlistID: favorites.id, mediaID: channel.id)
            if add { a.playlists[index].mediaIDs.append(channel.id) }
            else { a.playlists[index].mediaIDs.removeAll { $0 == channel.id } }
            authorization = a
        } catch {
            log.error("favorite failed: \(String(describing: error), privacy: .public)")
        }
    }

    // MARK: - Язык и профиль

    func setLanguage(_ language: Language) async {
        do {
            try await client.setTerminalParams(["language_id": .int(language.id)])
            await epg.clear()
            nowPlaying = [:]
            await apply(try await session.reload())
        } catch {
            log.error("language failed: \(String(describing: error), privacy: .public)")
        }
    }

    func selectProfile(_ profile: Profile) async -> ProfileChange {
        do {
            try await client.setTerminalParams(["profile_id": .int(profile.id)])
            let a = try await session.reload()
            await apply(a)
            return a.profile?.requirePassword == true ? .needsPassword : .done
        } catch {
            return .failed(strings("error.network"))
        }
    }

    /// Пароль профиля сверяется с `profile.password` из authorize_terminal (как в портале).
    /// Если сервер пароль не прислал — принимаем (проверить на устройстве, см. чек-лист).
    func confirmProfilePassword(_ entered: String) async -> Bool {
        guard let expected = authorization?.profile?.password else { return true }
        if expected == entered { return true }
        await cancelProfilePassword()
        return false
    }

    func cancelProfilePassword() async {
        guard let fallback = authorization?.profiles.first(where: { !$0.requirePassword }) else { return }
        _ = await selectProfile(fallback)
    }
}
```

- [ ] **Step 5: Экраны запуска и входа**

`App/RootView.swift`:
```swift
import SwiftUI

struct RootView: View {
    @Environment(AppModel.self) private var app

    var body: some View {
        @Bindable var app = app
        Group {
            switch app.route {
            case .launching:
                LaunchView()
            case .login:
                LoginView()
            case .offline:
                OfflineView()
            case .main:
                PlayerScreen()
                    .fullScreenCover(isPresented: $app.showGuide) { GuideView() }
            }
        }
        .environment(\.locale, app.strings.locale)
    }
}
```
`PlayerScreen` и `GuideView` появятся в Tasks 11–12. До них в этом коммите — временные заглушки в конце `RootView.swift`:
```swift
// Временно: заменяются в Task 11/12.
struct PlayerScreen: View { var body: some View { Color.black } }
struct GuideView: View { var body: some View { Text("Guide") } }
```

`App/Features/Launch/LaunchView.swift`:
```swift
import SwiftUI

struct LaunchView: View {
    var body: some View {
        VStack(spacing: 40) {
            Text("ALEM TV")
                .font(.system(size: 96, weight: .heavy))
                .foregroundStyle(Brand.accent)
            ProgressView()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Brand.background)
    }
}
```

`App/Features/Launch/OfflineView.swift`:
```swift
import SwiftUI

struct OfflineView: View {
    @Environment(AppModel.self) private var app

    var body: some View {
        VStack(spacing: 40) {
            Image(systemName: "wifi.exclamationmark")
                .font(.system(size: 96))
                .foregroundStyle(Brand.accent)
            Text(app.strings("error.network"))
                .font(.title2)
                .multilineTextAlignment(.center)
            Button(app.strings("error.retry")) {
                Task { await app.start() }
            }
        }
        .padding(80)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Brand.background)
    }
}
```

`App/Features/Login/LoginView.swift`:
```swift
import SwiftUI

struct LoginView: View {
    @Environment(AppModel.self) private var app
    @State private var username = ""
    @State private var password = ""
    @State private var showPortals = false

    var body: some View {
        VStack(spacing: 32) {
            Text("ALEM TV")
                .font(.system(size: 72, weight: .heavy))
                .foregroundStyle(Brand.accent)
            Text(app.strings("login.title")).font(.title2)
            TextField(app.strings("login.username"), text: $username)
                .textContentType(.username)
                .autocorrectionDisabled()
                .textInputAutocapitalization(.never)
            SecureField(app.strings("login.password"), text: $password)
                .textContentType(.password)
            if let error = app.loginError {
                Text(error).foregroundStyle(.red)
            }
            Button {
                Task { await app.signIn(username: username, password: password) }
            } label: {
                if app.isBusy { ProgressView() } else { Text(app.strings("login.submit")) }
            }
            .disabled(username.isEmpty || password.isEmpty || app.isBusy)
            Button(app.strings("login.changePortal") + " · " + app.portal.name) { showPortals = true }
                .font(.callout)
        }
        .frame(width: 900)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Brand.background)
        .sheet(isPresented: $showPortals) { PortalPickerView() }
    }
}
```

`App/Features/Login/PortalPickerView.swift`:
```swift
import SwiftUI

struct PortalPickerView: View {
    @Environment(AppModel.self) private var app
    @Environment(\.dismiss) private var dismiss
    @State private var pending: PortalOption?

    var body: some View {
        List(PortalOption.all) { option in
            Button {
                if option != app.portal { pending = option } else { dismiss() }
            } label: {
                HStack {
                    VStack(alignment: .leading) {
                        Text(option.name)
                        Text(option.host).font(.caption).foregroundStyle(.secondary)
                    }
                    Spacer()
                    if option == app.portal { Image(systemName: "checkmark") }
                }
            }
        }
        .navigationTitle(app.strings("settings.portal"))
        .confirmationDialog(app.strings("portal.confirm"), isPresented: Binding(get: { pending != nil }, set: { if !$0 { pending = nil } })) {
            Button(app.strings("common.ok")) {
                if let option = pending {
                    dismiss()
                    Task { await app.switchPortal(option) }
                }
            }
            Button(app.strings("common.cancel"), role: .cancel) { pending = nil }
        }
    }
}
```

`App/AlemTVApp.swift`:
```swift
import SwiftUI

@main
struct AlemTVApp: App {
    @State private var model = AppModel()
    @Environment(\.scenePhase) private var scenePhase

    var body: some Scene {
        WindowGroup {
            RootView()
                .environment(model)
                .preferredColorScheme(.dark)
                .tint(Brand.accent)
                .task { await model.start() }
                .onChange(of: scenePhase) { _, phase in
                    if phase == .active { Task { await model.becameActive() } }
                }
        }
    }
}
```

Добавить ресурсы в `project.yml`: таргет `AlemTV` уже берёт всю папку `App`, поэтому `.xcstrings` подхватится сам. Проверить, что `knownRegions` содержит языки. Если после `xcodegen generate` в `AlemTV.xcodeproj/project.pbxproj` нет `tk`, добавить в `project.yml` в `options` ключ `knownRegions: [ru, en, tk, Base]` (поддерживается XcodeGen ≥ 2.38).

- [ ] **Step 6: Сборка**

Run:
```bash
xcodegen generate && xcodebuild -project AlemTV.xcodeproj -scheme AlemTV -destination 'generic/platform=tvOS Simulator' build 2>&1 | grep -E "error:|warning: .*concurrency|BUILD" | head -20
```
Expected: `** BUILD SUCCEEDED **`, ошибок нет.

Проверить, что языки скомпилировались:
```bash
APP=$(find ~/Library/Developer/Xcode/DerivedData -path "*Debug-appletvsimulator/AlemTV.app" -maxdepth 6 | head -1); ls "$APP" | grep lproj
```
Expected: `en.lproj`, `ru.lproj`, `tk.lproj`.

- [ ] **Step 7: Ручная проверка в симуляторе**

Run: `xcrun simctl boot "Apple TV 4K (3rd generation)" 2>/dev/null; open -a Simulator`, затем Product → Run в Xcode.
Expected:
- при первом запуске заставка ALEM TV сменяется экраном «Вход»;
- после ввода логина и пароля из `.credentials` экран становится чёрным: это заглушка `PlayerScreen`;
- при повторном запуске экран «Вход» не появляется, вход идёт по MAC из Keychain.

- [ ] **Step 8: Commit**

```bash
git add tools/gen_strings.py App project.yml
git commit -m "Приложение: AppModel, локализация ru/tk/en, запуск, вход, выбор портала

Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>
Claude-Session: https://claude.ai/code/session_015tkg9WmfzBtZ6B6QQFpCUA"
```

---
### Task 11: Гид: каналы, избранное, программа передач

**Files:**
- Create: `App/Features/Guide/GuideView.swift`
- Create: `App/Features/Channels/ChannelsTab.swift`, `ChannelGrid.swift`, `ChannelCard.swift`, `ChannelLogo.swift`, `FavoritesTab.swift`
- Create: `App/Features/EPG/ScheduleView.swift`
- Modify: `App/RootView.swift` (удалить заглушку `GuideView`)
- Modify: `App/Features/Player/PlayerModel.swift` (добавить `play(_:in:)`, `play(_:on:)`, `playlist` в каркас, чтобы гид компилировался; полная логика — в Task 12)

**Interfaces:**
- Consumes:
  - из `AppModel`: `categoryPlaylists`, `authorization`, `loadNowPlaying(_:)`, `program(onAir:)`, `logoURL(for:)`, `isFavorite(_:)`, `toggleFavorite(_:)`, `clock`, `strings`, `epg`, `showGuide`, `player`;
  - из `PlayerModel`: `play(_ channel: Channel, in playlist: Playlist?)`, `play(_ program: Program, on channel: Channel)`, `playlist: Playlist?`;
  - из AlemCore: `StreamURLBuilder.isAvailableInArchive`, `PortalDate`.
- Produces: `GuideView`, `ChannelLogo(channel:)` (переиспользуется оверлеем плеера), `ScheduleView(channel:)`.

- [ ] **Step 1: Дополнить каркас PlayerModel**

Добавить в `App/Features/Player/PlayerModel.swift` внутрь класса:
```swift
    private(set) var channel: Channel?
    private(set) var playlist: Playlist?

    func play(_ channel: Channel, in playlist: Playlist?) {
        self.channel = channel
        if let playlist { self.playlist = playlist }
    }

    func play(_ program: Program, on channel: Channel) {
        self.channel = channel
    }
```

- [ ] **Step 2: Экраны гида**

`App/Features/Guide/GuideView.swift`:
```swift
import SwiftUI

struct GuideView: View {
    @Environment(AppModel.self) private var app

    var body: some View {
        TabView {
            ChannelsTab().tabItem { Text(app.strings("guide.channels")) }
            FavoritesTab().tabItem { Text(app.strings("guide.favorites")) }
            SettingsView().tabItem { Text(app.strings("guide.settings")) }
        }
        .background(Brand.background)
    }
}
```
`SettingsView` появится в Task 13. До неё добавить заглушку в конец `GuideView.swift`: `struct SettingsView: View { var body: some View { Text("Settings") } }`.

`App/Features/Channels/ChannelLogo.swift`:
```swift
import SwiftUI
import AlemCore

/// Логотип канала с портала (`logo96/<channel_id>.png`); если нет — название.
struct ChannelLogo: View {
    @Environment(AppModel.self) private var app
    let channel: Channel

    var body: some View {
        AsyncImage(url: app.logoURL(for: channel)) { phase in
            if let image = phase.image {
                image.resizable().scaledToFit()
            } else {
                Text(channel.name)
                    .font(.title3.bold())
                    .foregroundStyle(Brand.accent)
                    .multilineTextAlignment(.center)
                    .minimumScaleFactor(0.5)
            }
        }
    }
}
```

`App/Features/Channels/ChannelCard.swift`:
```swift
import SwiftUI
import AlemCore

struct ChannelCard: View {
    @Environment(AppModel.self) private var app
    let channel: Channel

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            ChannelLogo(channel: channel)
                .frame(maxWidth: .infinity)
                .frame(height: 110)
            HStack {
                Text("\(channel.index). \(channel.name)").font(.headline).lineLimit(1)
                Spacer()
                if app.isFavorite(channel) { Image(systemName: "star.fill").foregroundStyle(Brand.accent) }
            }
            if let program = app.program(onAir: channel) {
                Text(program.title).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                ProgressView(value: program.progress(at: app.clock.now())).tint(Brand.accent)
            } else {
                Text(" ").font(.caption)
            }
        }
        .padding(20)
        .frame(width: 340, height: 250)
    }
}
```

`App/Features/Channels/ChannelGrid.swift`:
```swift
import SwiftUI
import AlemCore

struct ChannelGrid: View {
    @Environment(AppModel.self) private var app
    let channels: [Channel]
    let playlist: Playlist?
    let onSchedule: (Channel) -> Void

    private let columns = [GridItem(.adaptive(minimum: 340), spacing: 40)]

    var body: some View {
        ScrollView {
            LazyVGrid(columns: columns, spacing: 50) {
                ForEach(channels) { channel in
                    Button {
                        app.player.play(channel, in: playlist)
                        app.showGuide = false
                    } label: {
                        ChannelCard(channel: channel)
                    }
                    .buttonStyle(.card)
                    .contextMenu {
                        Button(app.strings("channel.schedule")) { onSchedule(channel) }
                        Button(app.isFavorite(channel) ? app.strings("channel.removeFavorite") : app.strings("channel.addFavorite")) {
                            Task { await app.toggleFavorite(channel) }
                        }
                    }
                }
            }
            .padding(40)
        }
        .task(id: channels.map(\.id)) {
            await app.loadNowPlaying(channels)
            while !Task.isCancelled {
                try? await Task.sleep(for: .seconds(60))
                await app.loadNowPlaying(channels)
            }
        }
    }
}
```

`App/Features/Channels/ChannelsTab.swift`:
```swift
import SwiftUI
import AlemCore

struct ChannelsTab: View {
    @Environment(AppModel.self) private var app
    @State private var selectedID: Int?
    @State private var path: [Channel] = []
    @FocusState private var focusedPlaylist: Int?

    private var selected: Playlist? {
        app.categoryPlaylists.first { $0.id == selectedID } ?? app.categoryPlaylists.first
    }

    var body: some View {
        NavigationStack(path: $path) {
            HStack(alignment: .top, spacing: 30) {
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 12) {
                        ForEach(app.categoryPlaylists) { playlist in
                            Button { selectedID = playlist.id } label: {
                                Text(playlist.title)
                                    .frame(maxWidth: .infinity, alignment: .leading)
                                    .foregroundStyle(playlist.id == selected?.id ? Brand.accent : .primary)
                            }
                            .focused($focusedPlaylist, equals: playlist.id)
                        }
                    }
                    .padding(.vertical, 40)
                }
                .frame(width: 420)
                .focusSection()
                .onChange(of: focusedPlaylist) { _, id in if let id { selectedID = id } }

                ChannelGrid(channels: selected.map { app.authorization?.channels(in: $0) ?? [] } ?? [],
                            playlist: selected,
                            onSchedule: { path.append($0) })
                    .focusSection()
            }
            .navigationDestination(for: Channel.self) { ScheduleView(channel: $0) }
        }
        .onAppear {
            if selectedID == nil { selectedID = app.player.playlist?.id ?? app.categoryPlaylists.first?.id }
        }
    }
}
```

`App/Features/Channels/FavoritesTab.swift`:
```swift
import SwiftUI
import AlemCore

struct FavoritesTab: View {
    @Environment(AppModel.self) private var app
    @State private var path: [Channel] = []

    var body: some View {
        let favorites = app.authorization?.favorites
        let channels = favorites.map { app.authorization?.channels(in: $0) ?? [] } ?? []
        NavigationStack(path: $path) {
            Group {
                if channels.isEmpty {
                    Label(app.strings("channel.addFavorite"), systemImage: "star")
                        .foregroundStyle(.secondary)
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else {
                    ChannelGrid(channels: channels, playlist: favorites, onSchedule: { path.append($0) })
                }
            }
            .navigationDestination(for: Channel.self) { ScheduleView(channel: $0) }
        }
    }
}
```

`App/Features/EPG/ScheduleView.swift`:
```swift
import SwiftUI
import AlemCore

struct ScheduleView: View {
    @Environment(AppModel.self) private var app
    let channel: Channel
    @State private var day = PortalDate.startOfDay(Date())
    @State private var programs: [Program] = []
    @State private var loaded = false

    private var now: Date { app.clock.now() }

    /// Дни: назад — глубина архива, вперёд — до max_stop из epg_info.
    private var days: [Date] {
        let today = PortalDate.startOfDay(now)
        let info = app.authorization?.epgInfo[channel.id]
        let back = channel.hasArchive ? Int(((channel.timeshiftArchiveLength ?? 0) / 86_400).rounded(.up)) : 0
        let forward = info?.maxStop.map { max(0, Int($0.timeIntervalSince(today) / 86_400)) } ?? 0
        let earliest = info?.minStart.map(PortalDate.startOfDay) ?? today
        return (-back...forward)
            .map { today.addingTimeInterval(Double($0) * 86_400) }
            .filter { $0 >= earliest || $0 == today }
    }

    var body: some View {
        HStack(alignment: .top, spacing: 30) {
            ScrollView {
                LazyVStack(spacing: 12) {
                    ForEach(days, id: \.self) { d in
                        Button { day = d } label: {
                            Text(title(for: d))
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .foregroundStyle(d == day ? Brand.accent : .primary)
                        }
                    }
                }
                .padding(.vertical, 40)
            }
            .frame(width: 380)
            .focusSection()

            ScrollViewReader { proxy in
                List(programs) { program in
                    Button { select(program) } label: { row(program) }
                        .disabled(!playable(program))
                        .id(program.id)
                }
                .overlay {
                    if loaded && programs.isEmpty {
                        Text(app.strings("epg.empty")).foregroundStyle(.secondary)
                    }
                }
                .onChange(of: programs) { _, list in
                    if let current = list.first(where: { $0.isOnAir(at: now) }) { proxy.scrollTo(current.id, anchor: .center) }
                }
            }
            .focusSection()
        }
        .navigationTitle(channel.name)
        .onAppear { day = PortalDate.startOfDay(now) }
        .task(id: PortalDate.dayString(day)) {
            loaded = false
            programs = (try? await app.epg.programs(mediaID: channel.id, day: PortalDate.dayString(day),
                                                     languageID: app.authorization?.language?.id)) ?? []
            loaded = true
        }
    }

    private func row(_ program: Program) -> some View {
        HStack(spacing: 24) {
            Text(program.start.formatted(timeStyle))
                .monospacedDigit()
                .frame(width: 110, alignment: .leading)
            Text(program.title).lineLimit(1)
            if let age = program.ageLabel { Text(age).font(.caption).foregroundStyle(.secondary) }
            Spacer()
            if program.isOnAir(at: now) {
                Label(app.strings("epg.live"), systemImage: "dot.radiowaves.left.and.right").foregroundStyle(Brand.accent)
            } else if inArchive(program) {
                Image(systemName: "backward.circle").accessibilityLabel(app.strings("epg.archive"))
            }
        }
    }

    private var timeStyle: Date.FormatStyle {
        var style = Date.FormatStyle(date: .omitted, time: .shortened).locale(app.strings.locale)
        style.timeZone = PortalDate.serverTimeZone
        return style
    }

    private func title(for d: Date) -> String {
        if d == PortalDate.startOfDay(now) { return app.strings("epg.today") }
        var style = Date.FormatStyle().weekday(.abbreviated).day().month(.abbreviated).locale(app.strings.locale)
        style.timeZone = PortalDate.serverTimeZone
        return d.formatted(style)
    }

    private func inArchive(_ program: Program) -> Bool {
        StreamURLBuilder.isAvailableInArchive(program, channel: channel,
                                              timeshiftEnabled: app.authorization?.timeshiftEnabled ?? false, now: now)
    }

    private func playable(_ program: Program) -> Bool {
        program.isOnAir(at: now) || inArchive(program)
    }

    private func select(_ program: Program) {
        if program.isOnAir(at: now) {
            app.player.play(channel, in: app.player.playlist)
        } else {
            app.player.play(program, on: channel)
        }
        app.showGuide = false
    }
}
```

Удалить из `App/RootView.swift` строку `struct GuideView: View { … }`.

- [ ] **Step 3: Сборка**

Run: `xcodegen generate && xcodebuild -project AlemTV.xcodeproj -scheme AlemTV -destination 'generic/platform=tvOS Simulator' build 2>&1 | grep -E "error:|BUILD" | head -20`
Expected: `** BUILD SUCCEEDED **`.

- [ ] **Step 4: Ручная проверка в симуляторе**

Чтобы увидеть гид до Task 12, временно поставить `showGuide = true` в `AppModel.start()` после `route = .main`, затем вернуть как было.
Expected:
- слева рубрики с сервера («Все», «Национальные», «Русские»…), справа сетка карточек с логотипами;
- у каналов с EPG видны текущая передача и полоса прогресса;
- долгое нажатие открывает меню с пунктами «Программа передач» и «В избранное»;
- «Программа передач» показывает дни и передачи, сегодняшняя текущая отмечена «Сейчас в эфире», у прошедших значок архива;
- у «Че (+7)» значков архива нет, будущие передачи неактивны.

- [ ] **Step 5: Commit**

```bash
git add App
git commit -m "Гид: рубрики, сетка каналов с текущими передачами, избранное, программа передач

Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>
Claude-Session: https://claude.ai/code/session_015tkg9WmfzBtZ6B6QQFpCUA"
```

---

### Task 12: Плеер: эфир, переключение каналов, таймшифт, архив, оверлеи

**Files:**
- Modify (полная замена): `App/Features/Player/PlayerModel.swift`
- Create: `App/Features/Player/PlayerContainer.swift`, `PlayerScreen.swift`, `ChannelListOverlay.swift`, `ProgramInfoView.swift`
- Modify: `App/RootView.swift` (удалить заглушку `PlayerScreen`)
- Modify: `App/AppModel.swift` (в `apply(_:)` передать таймаут автопаузы)

**Interfaces:**
- Consumes:
  - из AlemCore: `AVPlayerEngine` и колбэки, `StreamURLBuilder`, `StreamMode`, `IdleMonitor`, `PortalDate`, `SessionStore.streamContext()`, `EPGStore.programs`;
  - из `AppModel`: `clock`, `authorization`, `strings`, `reauthorize()`, `rememberLastChannel(_:)`, `showGuide`, `categoryPlaylists`.
- Produces:
  - `PlayerModel`:
    - состояние: `mode: Mode (.live/.timeshift/.archive(Program))`, `channel`, `playlist`, `currentProgram`, `errorMessage`, `showChannelList`, `askContinue`, `behindLive`, `canTimeshift`, `canStartOver`;
    - воспроизведение: `play(_:in:)`, `play(_:on:)`, `playInitial()`, `switchChannel(by:)`, `skip(_:)`, `goLive()`, `startOver()`, `retry()`, `reloadCurrent()`, `stop()`, `configure(session:epg:)`;
    - пульт и бездействие: `intercepts(_:)`, `perform(_:)`, `userActivity()`, `continueAfterIdle()`, `setIdleTimeout(_:)`.

- [ ] **Step 1: PlayerModel целиком**

`App/Features/Player/PlayerModel.swift`:
```swift
import Foundation
import Observation
import UIKit
import os
import AlemCore

@MainActor @Observable
final class PlayerModel {
    enum Mode: Equatable {
        case live
        case timeshift
        case archive(Program)
    }

    /// Задержка HLS-эфира (~3 сегмента по 6 с) + запас: ближе этого к «сейчас» считаем эфиром.
    static let liveSnap: TimeInterval = 45

    let engine = AVPlayerEngine()
    private(set) var channel: Channel?
    private(set) var playlist: Playlist?
    private(set) var mode: Mode = .live
    private(set) var currentProgram: Program?
    private(set) var errorMessage: String?
    var showChannelList = false
    var askContinue = false

    @ObservationIgnored weak var app: AppModel?
    @ObservationIgnored private var session: SessionStore
    @ObservationIgnored private var epg: EPGStore
    @ObservationIgnored private var lastStreamMode: StreamMode = .live
    @ObservationIgnored private var retryCount = 0
    @ObservationIgnored private var pausedAt: Date?
    @ObservationIgnored private var idle = IdleMonitor(timeout: 18_000)
    @ObservationIgnored private var loadTask: Task<Void, Never>?
    @ObservationIgnored private let log = Logger(subsystem: "com.alexvamp.alemtv", category: "player")

    init(session: SessionStore, epg: EPGStore) {
        self.session = session
        self.epg = epg
        engine.onStarted = { [weak self] in
            self?.retryCount = 0
            self?.errorMessage = nil
        }
        engine.onFailed = { [weak self] message in
            self?.log.error("playback failed: \(message, privacy: .public)")
            self?.handleFailure()
        }
        engine.onStalled = { [weak self] in
            self?.log.notice("stream frozen, restarting")
            self?.reload()
        }
        engine.onEnded = { [weak self] in self?.playNextProgram() }
        engine.onUserPause = { [weak self] in self?.userPaused() }
        engine.onUserResume = { [weak self] in self?.userResumed() }
        startTicker()
    }

    func configure(session: SessionStore, epg: EPGStore) {
        self.session = session
        self.epg = epg
    }

    func setIdleTimeout(_ timeout: TimeInterval) {
        idle = IdleMonitor(timeout: timeout)
    }

    // MARK: - Состояние

    private var now: Date { app?.clock.now() ?? Date() }

    /// Реальное время показываемого кадра (EXT-X-PROGRAM-DATE-TIME), иначе — оценка.
    var contentTime: Date {
        if let date = engine.currentDate { return date }
        switch mode {
        case .live:
            return now
        case .timeshift:
            if case .timeshift(let behind) = lastStreamMode { return now.addingTimeInterval(-behind) }
            return now
        case .archive(let program):
            return StreamURLBuilder.floorMinute(program.start).addingTimeInterval(engine.currentTime)
        }
    }

    var behindLive: TimeInterval? {
        guard mode == .timeshift else { return nil }
        return max(0, now.timeIntervalSince(contentTime))
    }

    var isArchive: Bool {
        if case .archive = mode { return true }
        return false
    }

    var canTimeshift: Bool {
        channel?.hasArchive == true && app?.authorization?.timeshiftEnabled == true
    }

    var canStartOver: Bool { canTimeshift && currentProgram != nil }

    // MARK: - Запуск

    func playInitial() {
        guard let a = app?.authorization else { return }
        let all = a.playlists.first { $0.name == "tv" } ?? app?.categoryPlaylists.first
        let channel = a.lastMediaID.flatMap(a.channel(id:))
            ?? all.flatMap { a.channels(in: $0).first }
            ?? a.channels.first
        if let channel { play(channel, in: all) }
    }

    func play(_ channel: Channel, in playlist: Playlist?) {
        self.channel = channel
        if let playlist { self.playlist = playlist }
        mode = .live
        pausedAt = nil
        retryCount = 0
        app?.rememberLastChannel(channel)
        load(.live)
        Task { await refreshProgram() }
    }

    func play(_ program: Program, on channel: Channel) {
        self.channel = channel
        start(program, position: 0)
    }

    func switchChannel(by delta: Int) {
        guard let a = app?.authorization, let channel else { return }
        let list = playlist.map { a.channels(in: $0) } ?? a.channels
        guard !list.isEmpty else { return }
        let index = list.firstIndex { $0.id == channel.id } ?? 0
        play(list[(index + delta % list.count + list.count) % list.count], in: playlist)
    }

    func goLive() {
        mode = .live
        pausedAt = nil
        retryCount = 0
        load(.live)
        Task { await refreshProgram() }
    }

    /// ±секунды: в архиве — нативный seek, в эфире/таймшифте — новый URL.
    func skip(_ seconds: TimeInterval) {
        if isArchive {
            engine.seek(to: engine.currentTime + seconds)
            return
        }
        guard canTimeshift, let channel else { return }
        var target = contentTime.addingTimeInterval(seconds)
        if let depth = channel.timeshiftArchiveLength { target = max(target, now.addingTimeInterval(-depth)) }
        let behind = now.timeIntervalSince(target)
        if behind <= Self.liveSnap {
            goLive()
        } else {
            mode = .timeshift
            load(.timeshift(behind: behind))
        }
    }

    func startOver() {
        guard canStartOver, let program = currentProgram, let channel else { return }
        play(program, on: channel)
    }

    func retry() {
        retryCount = 0
        reload()
    }

    func reloadCurrent() {
        guard channel != nil else { return }
        reload()
    }

    func stop() {
        loadTask?.cancel()
        engine.stop()
        channel = nil
        currentProgram = nil
        errorMessage = nil
    }

    // MARK: - Пульт

    /// Какие нажатия забираем у AVPlayerViewController.
    func intercepts(_ type: UIPress.PressType) -> Bool {
        guard !showChannelList, errorMessage == nil else { return false }
        switch type {
        case .menu: return true
        case .upArrow, .downArrow, .leftArrow: return !isArchive
        default: return false
        }
    }

    func perform(_ type: UIPress.PressType) {
        userActivity()
        switch type {
        case .menu: app?.showGuide = true
        case .upArrow: switchChannel(by: -1)
        case .downArrow: switchChannel(by: 1)
        case .leftArrow: showChannelList = true
        default: break
        }
    }

    func userActivity() {
        idle.touch()
    }

    func continueAfterIdle() {
        askContinue = false
        idle.touch()
        if mode == .live { goLive() } else { engine.play() }
    }

    // MARK: - Внутреннее

    private func start(_ program: Program, position: TimeInterval) {
        let streamMode = StreamURLBuilder.mode(for: program, position: position, now: now)
        switch streamMode {
        case .live: mode = .live
        case .timeshift: mode = .timeshift
        case .archive: mode = .archive(program)
        }
        pausedAt = nil
        retryCount = 0
        load(streamMode)
        Task { await refreshProgram() }
    }

    private func load(_ streamMode: StreamMode) {
        guard let channel else { return }
        lastStreamMode = streamMode
        errorMessage = nil
        loadTask?.cancel()
        loadTask = Task { [weak self] in
            guard let self, let context = await self.session.streamContext(), !Task.isCancelled else { return }
            do {
                let url = try StreamURLBuilder.url(for: channel, mode: streamMode, context: context)
                self.engine.load(url, startAt: nil)
            } catch {
                self.showError()
            }
        }
    }

    private func reload() {
        switch mode {
        case .live:
            load(.live)
        case .timeshift:
            load(.timeshift(behind: max(0, now.timeIntervalSince(contentTime))))
        case .archive(let program):
            let position = contentTime.timeIntervalSince(StreamURLBuilder.floorMinute(program.start))
            start(program, position: max(0, position))
        }
    }

    /// 1-я ошибка — новый URL; 2-я — повторный вход и новый URL; дальше — сообщение.
    private func handleFailure() {
        retryCount += 1
        switch retryCount {
        case 1:
            reload()
        case 2:
            Task { [weak self] in
                try? await self?.app?.reauthorize()
                self?.reload()
            }
        default:
            engine.stop()
            showError()
        }
    }

    private func showError() {
        errorMessage = app?.strings(isArchive ? "player.recordingUnavailable" : "player.unavailable")
    }

    private func userPaused() {
        pausedAt = contentTime
    }

    private func userResumed() {
        defer { pausedAt = nil }
        guard let pausedAt, !isArchive, canTimeshift else { return }
        let behind = now.timeIntervalSince(pausedAt)
        if behind > Self.liveSnap {
            mode = .timeshift
            load(.timeshift(behind: behind))
        }
    }

    private func playNextProgram() {
        guard case .archive(let finished) = mode, let channel else { return }
        Task { [weak self] in
            guard let self else { return }
            let language = self.app?.authorization?.language?.id
            var list = (try? await self.epg.programs(mediaID: channel.id, day: PortalDate.dayString(finished.start), languageID: language)) ?? []
            if !list.contains(where: { $0.start >= finished.stop }) {
                list += (try? await self.epg.programs(mediaID: channel.id, day: PortalDate.dayString(finished.stop.addingTimeInterval(60)), languageID: language)) ?? []
            }
            if let next = list.first(where: { $0.start >= finished.stop }) {
                self.start(next, position: 0)
            } else {
                self.goLive()
            }
        }
    }

    func refreshProgram() async {
        guard let channel else {
            currentProgram = nil
            return
        }
        let at = contentTime
        let list = (try? await epg.programs(mediaID: channel.id, day: PortalDate.dayString(at),
                                            languageID: app?.authorization?.language?.id)) ?? []
        currentProgram = list.first { $0.isOnAir(at: at) }
    }

    private func startTicker() {
        Task { [weak self] in
            while true {
                try? await Task.sleep(for: .seconds(30))
                guard let self else { return }
                await self.refreshProgram()
                if self.engine.state == .playing, self.idle.isExpired() {
                    self.engine.pause()
                    self.askContinue = true
                }
            }
        }
    }
}
```

В `App/AppModel.swift`, в конец `apply(_:)`, добавить:
```swift
        player.setIdleTimeout(await session.domain?.autoPauseTimeout ?? 18_000)
```

- [ ] **Step 2: Мост к AVPlayerViewController**

`App/Features/Player/PlayerContainer.swift`:
```swift
import SwiftUI
import AVKit
import AlemCore

/// AVPlayerViewController с перехватом стрелок и Menu (только когда это разрешает PlayerModel).
final class PlayerViewController: AVPlayerViewController, UIGestureRecognizerDelegate {
    var intercepts: (UIPress.PressType) -> Bool = { _ in false }
    var perform: (UIPress.PressType) -> Void = { _ in }
    var onActivity: () -> Void = {}

    override func viewDidLoad() {
        super.viewDidLoad()
        for type in [UIPress.PressType.upArrow, .downArrow, .leftArrow, .menu] {
            let recognizer = UITapGestureRecognizer(target: self, action: #selector(pressed(_:)))
            recognizer.allowedPressTypes = [NSNumber(value: type.rawValue)]
            recognizer.delegate = self
            view.addGestureRecognizer(recognizer)
        }
    }

    @objc private func pressed(_ recognizer: UITapGestureRecognizer) {
        if let type = Self.pressType(of: recognizer) { perform(type) }
    }

    func gestureRecognizerShouldBegin(_ recognizer: UIGestureRecognizer) -> Bool {
        guard let type = Self.pressType(of: recognizer) else { return true }
        return intercepts(type)
    }

    override func pressesBegan(_ presses: Set<UIPress>, with event: UIPressesEvent?) {
        onActivity()
        super.pressesBegan(presses, with: event)
    }

    private static func pressType(of recognizer: UIGestureRecognizer) -> UIPress.PressType? {
        guard let raw = (recognizer as? UITapGestureRecognizer)?.allowedPressTypes.first?.intValue else { return nil }
        return UIPress.PressType(rawValue: raw)
    }
}

struct PlayerContainer: UIViewControllerRepresentable {
    let player: PlayerModel
    let app: AppModel

    final class Coordinator {
        var info: UIHostingController<AnyView>?
    }

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIViewController(context: Context) -> PlayerViewController {
        let controller = PlayerViewController()
        controller.player = player.engine.player
        controller.intercepts = { player.intercepts($0) }
        controller.perform = { player.perform($0) }
        controller.onActivity = { player.userActivity() }
        let info = UIHostingController(rootView: AnyView(ProgramInfoView().environment(app).environment(player)))
        info.preferredContentSize = CGSize(width: 0, height: 360)
        context.coordinator.info = info
        controller.customInfoViewControllers = [info]
        return controller
    }

    func updateUIViewController(_ controller: PlayerViewController, context: Context) {
        context.coordinator.info?.title = app.strings("player.info")
        controller.transportBarCustomMenuItems = menuItems()
        controller.view.isUserInteractionEnabled = !player.showChannelList && player.errorMessage == nil
    }

    private func menuItems() -> [UIMenuElement] {
        let s = app.strings
        var items: [UIMenuElement] = []
        if player.canTimeshift || player.isArchive {
            items.append(UIAction(title: s("player.back10"), image: UIImage(systemName: "gobackward.10")) { _ in player.skip(-10) })
            if player.mode != .live {
                items.append(UIAction(title: s("player.forward10"), image: UIImage(systemName: "goforward.10")) { _ in player.skip(10) })
            }
        }
        if player.canStartOver {
            items.append(UIAction(title: s("player.startOver"), image: UIImage(systemName: "backward.end")) { _ in player.startOver() })
        }
        if player.mode != .live {
            items.append(UIAction(title: s("player.goLive"), image: UIImage(systemName: "dot.radiowaves.left.and.right")) { _ in player.goLive() })
        }
        return items
    }
}
```

- [ ] **Step 3: Экран плеера и оверлеи**

`App/Features/Player/PlayerScreen.swift`:
```swift
import SwiftUI
import AlemCore

struct PlayerScreen: View {
    @Environment(AppModel.self) private var app

    var body: some View {
        @Bindable var player = app.player
        ZStack(alignment: .topTrailing) {
            PlayerContainer(player: player, app: app)
                .ignoresSafeArea()
            if player.mode == .timeshift {
                TimeshiftBadge().padding(60)
            }
            if let message = player.errorMessage {
                ErrorOverlay(message: message)
            }
            if player.showChannelList {
                ChannelListOverlay()
                    .transition(.move(edge: .leading))
            }
        }
        .background(Color.black)
        .animation(.easeOut(duration: 0.2), value: player.showChannelList)
        .alert(app.strings("player.continue.title"), isPresented: $player.askContinue) {
            Button(app.strings("player.continue")) { player.continueAfterIdle() }
        }
    }
}

private struct TimeshiftBadge: View {
    @Environment(AppModel.self) private var app

    var body: some View {
        TimelineView(.periodic(from: .now, by: 1)) { _ in
            if let behind = app.player.behindLive {
                Text(app.strings("player.behindLive", "−" + Duration.seconds(Int(behind)).formatted(.time(pattern: .hourMinuteSecond))))
                    .font(.headline.monospacedDigit())
                    .padding(.horizontal, 24)
                    .padding(.vertical, 12)
                    .background(.ultraThinMaterial, in: Capsule())
            }
        }
    }
}

private struct ErrorOverlay: View {
    @Environment(AppModel.self) private var app
    let message: String

    var body: some View {
        VStack(spacing: 30) {
            Image(systemName: "exclamationmark.tv").font(.system(size: 80)).foregroundStyle(Brand.accent)
            Text(message).font(.title2)
            HStack(spacing: 40) {
                Button(app.strings("error.retry")) { app.player.retry() }
                Button(app.strings("guide.channels")) { app.showGuide = true }
            }
        }
        .padding(60)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 30))
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}
```

`App/Features/Player/ChannelListOverlay.swift`:
```swift
import SwiftUI
import AlemCore

/// Боковой список каналов поверх видео (клик влево в эфире).
struct ChannelListOverlay: View {
    @Environment(AppModel.self) private var app
    @State private var selectedPlaylistID: Int?
    @FocusState private var focus: Focus?

    enum Focus: Hashable {
        case playlist(Int)
        case channel(Int)
    }

    private var playlists: [Playlist] {
        app.categoryPlaylists + (app.authorization?.favorites.map { [$0] } ?? [])
    }

    private var current: Playlist? {
        playlists.first { $0.id == selectedPlaylistID } ?? app.player.playlist ?? playlists.first
    }

    var body: some View {
        let channels = current.map { app.authorization?.channels(in: $0) ?? [] } ?? []
        HStack(spacing: 0) {
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 10) {
                    ForEach(playlists) { playlist in
                        Button { selectedPlaylistID = playlist.id } label: {
                            Text(playlist.isFavorites ? app.strings("guide.favorites") : playlist.title)
                                .foregroundStyle(playlist.id == current?.id ? Brand.accent : .primary)
                                .frame(maxWidth: .infinity, alignment: .leading)
                        }
                        .focused($focus, equals: .playlist(playlist.id))
                    }
                }
                .padding(40)
            }
            .frame(width: 400)
            .focusSection()

            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 8) {
                        ForEach(channels) { channel in
                            Button {
                                app.player.play(channel, in: current)
                                app.player.showChannelList = false
                            } label: {
                                ChannelRow(channel: channel, isCurrent: channel.id == app.player.channel?.id)
                            }
                            .focused($focus, equals: .channel(channel.id))
                            .id(channel.id)
                        }
                    }
                    .padding(40)
                }
                .onAppear { if let id = app.player.channel?.id { proxy.scrollTo(id, anchor: .center) } }
            }
            .frame(width: 760)
            .focusSection()

            Spacer()
        }
        .background(LinearGradient(colors: [.black.opacity(0.95), .black.opacity(0.6), .clear], startPoint: .leading, endPoint: .trailing))
        .onExitCommand { app.player.showChannelList = false }
        .onAppear {
            selectedPlaylistID = app.player.playlist?.id
            if let id = app.player.channel?.id { focus = .channel(id) }
        }
        .task(id: current?.id) { await app.loadNowPlaying(channels) }
    }
}

private struct ChannelRow: View {
    @Environment(AppModel.self) private var app
    let channel: Channel
    let isCurrent: Bool

    var body: some View {
        HStack(spacing: 20) {
            ChannelLogo(channel: channel).frame(width: 96, height: 54)
            VStack(alignment: .leading, spacing: 4) {
                Text("\(channel.index). \(channel.name)")
                    .font(.headline)
                    .foregroundStyle(isCurrent ? Brand.accent : .primary)
                if let program = app.program(onAir: channel) {
                    Text(program.title).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                    ProgressView(value: program.progress(at: app.clock.now())).tint(Brand.accent)
                }
            }
        }
    }
}
```

`App/Features/Player/ProgramInfoView.swift`:
```swift
import SwiftUI
import AlemCore

/// Вкладка «Программа» в инфопанели плеера (свайп вниз).
struct ProgramInfoView: View {
    @Environment(AppModel.self) private var app
    @Environment(PlayerModel.self) private var player

    var body: some View {
        HStack(alignment: .top, spacing: 40) {
            VStack(alignment: .leading, spacing: 12) {
                Text(player.channel?.name ?? "").font(.headline).foregroundStyle(Brand.accent)
                if let program = player.currentProgram {
                    Text(program.title).font(.title3)
                    Text("\(program.start.formatted(date: .omitted, time: .shortened)) – \(program.stop.formatted(date: .omitted, time: .shortened))")
                        .foregroundStyle(.secondary)
                    if let summary = program.summary {
                        Text(summary).font(.callout).lineLimit(3)
                    }
                } else {
                    Text(app.strings("epg.empty")).foregroundStyle(.secondary)
                }
            }
            Spacer()
            VStack(spacing: 20) {
                if player.canStartOver {
                    Button(app.strings("player.startOver")) { player.startOver() }
                }
                if let channel = player.channel {
                    Button(app.isFavorite(channel) ? app.strings("channel.removeFavorite") : app.strings("channel.addFavorite")) {
                        Task { await app.toggleFavorite(channel) }
                    }
                }
            }
        }
        .padding(40)
    }
}
```

Удалить из `App/RootView.swift` заглушку `struct PlayerScreen …`.

- [ ] **Step 4: Сборка**

Run: `xcodegen generate && xcodebuild -project AlemTV.xcodeproj -scheme AlemTV -destination 'generic/platform=tvOS Simulator' build 2>&1 | grep -E "error:|BUILD" | head -20`
Expected: `** BUILD SUCCEEDED **`.

- [ ] **Step 5: Ручная проверка в симуляторе**

Стрелки на клавиатуре Mac — это стрелки пульта, Esc — Menu, пробел — Play/Pause.
Expected:
- после запуска играет последний канал или первый канал «Все» (видео HEVC 1080p);
- ↑ и ↓ переключают каналы;
- ← открывает боковой список, выбор канала его закрывает, Esc закрывает без выбора;
- Esc в эфире открывает гид, выбор канала в гиде возвращает в плеер;
- пауза на 1 минуту и продолжение дают плашку «−00:01:0x от эфира»; в транспортной панели появляются «−10 с», «+10 с», «В эфир», «С начала»; «В эфир» убирает плашку;
- передача из архива в «Программе передач» открывается с полной шкалой перемотки, ←/→ на шкале работают нативно.

Если стрелки не перехватываются (гид или список не открываются), значит, `AVPlayerViewController` забирает нажатия раньше распознавателей. Нужно перенести распознаватели на `controller.view.superview` в `didMove(toParent:)` и проверить снова.

- [ ] **Step 6: Commit**

```bash
git add App
git commit -m "Плеер: эфир, переключение каналов, список поверх видео, таймшифт, архив, автоповтор

Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>
Claude-Session: https://claude.ai/code/session_015tkg9WmfzBtZ6B6QQFpCUA"
```

---

### Task 13: Настройки: профиль, язык, портал, о приложении, выход

**Files:**
- Create: `App/Features/Settings/SettingsView.swift`
- Modify: `App/Features/Guide/GuideView.swift` (удалить заглушку `SettingsView`)

**Interfaces:**
- Consumes:
  - из `AppModel`: `authorization`, `selectProfile(_:) -> ProfileChange`, `confirmProfilePassword(_:)`, `cancelProfilePassword()`, `setLanguage(_:)`, `portal`, `session.macaddr`, `signOut()`, `strings`;
  - `PortalPickerView` из Task 10.
- Produces: `SettingsView`.

- [ ] **Step 1: Экран настроек**

`App/Features/Settings/SettingsView.swift`:
```swift
import SwiftUI
import AlemCore

struct SettingsView: View {
    @Environment(AppModel.self) private var app
    @State private var confirmLogout = false
    @State private var askPassword = false
    @State private var password = ""
    @State private var wrongPassword = false
    @State private var mac: String?

    private static let languageNames = ["ru": "Русский", "tk": "Türkmençe", "en": "English"]

    var body: some View {
        let s = app.strings
        NavigationStack {
            List {
                Section(s("settings.profile")) {
                    ForEach(app.authorization?.profiles ?? []) { profile in
                        Button {
                            Task {
                                if await app.selectProfile(profile) == .needsPassword { askPassword = true }
                            }
                        } label: {
                            row(profile.title, selected: app.authorization?.profile?.id == profile.id)
                        }
                    }
                }
                Section(s("settings.language")) {
                    ForEach(app.authorization?.languages ?? []) { language in
                        Button {
                            Task { await app.setLanguage(language) }
                        } label: {
                            row(Self.languageNames[language.code] ?? language.name,
                                selected: app.authorization?.language?.id == language.id)
                        }
                    }
                }
                Section(s("settings.portal")) {
                    NavigationLink(app.portal.name) { PortalPickerView() }
                }
                Section(s("settings.about")) {
                    LabeledContent(s("settings.version"),
                                   value: Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "—")
                    LabeledContent(s("settings.terminal"), value: mac ?? "—")
                }
                Section {
                    Button(s("settings.logout"), role: .destructive) { confirmLogout = true }
                }
            }
            .task { mac = await app.session.macaddr }
            .confirmationDialog(s("settings.logout.confirm"), isPresented: $confirmLogout) {
                Button(s("settings.logout"), role: .destructive) { Task { await app.signOut() } }
                Button(s("common.cancel"), role: .cancel) {}
            }
            .alert(s("profile.enterPassword"), isPresented: $askPassword) {
                SecureField(s("login.password"), text: $password)
                Button(s("common.ok")) {
                    let entered = password
                    password = ""
                    Task { wrongPassword = !(await app.confirmProfilePassword(entered)) }
                }
                Button(s("common.cancel"), role: .cancel) {
                    password = ""
                    Task { await app.cancelProfilePassword() }
                }
            }
            .alert(s("profile.wrongPassword"), isPresented: $wrongPassword) {
                Button(s("common.ok")) {}
            }
        }
    }

    private func row(_ title: String, selected: Bool) -> some View {
        HStack {
            Text(title)
            Spacer()
            if selected { Image(systemName: "checkmark").foregroundStyle(Brand.accent) }
        }
    }
}
```

Удалить заглушку `struct SettingsView …` из `App/Features/Guide/GuideView.swift`.

- [ ] **Step 2: Сборка**

Run: `xcodegen generate && xcodebuild -project AlemTV.xcodeproj -scheme AlemTV -destination 'generic/platform=tvOS Simulator' build 2>&1 | grep -E "error:|BUILD" | head -20`
Expected: `** BUILD SUCCEEDED **`.

- [ ] **Step 3: Ручная проверка в симуляторе**

Expected:
- «Настройки → Язык → Türkmençe» переводит интерфейс на туркменский («Telekanallar», «Saýlanan», «Sazlamalar»), названия рубрик с сервера тоже меняются, EPG перезагружается; возврат на «Русский» возвращает всё назад;
- «Профиль → 18+» запрашивает пароль: неверный даёт «Ошибка ввода» и возврат на «0+», «Отмена» тоже возвращает «0+». Если сервер не присылает пароль профиля, «18+» включается сразу. Это записать в чек-лист как наблюдение;
- в «О приложении» видны версия и MAC терминала;
- «Выход из аккаунта» после подтверждения открывает экран «Вход». **Не выполнять** на основном аккаунте без нужды: терминал отвяжется, повторный вход привяжет новый.

- [ ] **Step 4: Commit**

```bash
git add App
git commit -m "Настройки: профиль с паролем, язык ru/tk/en, портал, о приложении, выход

Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>
Claude-Session: https://claude.ai/code/session_015tkg9WmfzBtZ6B6QQFpCUA"
```

---

### Task 14: Брендинг: иконка, Top Shelf и акцентный цвет

**Files:**
- Create: `tools/make_brand_assets.py`
- Create (генерируется): `App/Resources/Assets.xcassets/**`
- Modify: `project.yml`

**Interfaces:**
- Consumes: `reference/decompiled/resources/res/drawable-xhdpi/alem.png` (320×180, баннер Android TV из APK).
- Produces: каталог ресурсов с `App Icon & Top Shelf Image.brandassets` и `AccentColor`.

- [ ] **Step 1: Генератор**

`tools/make_brand_assets.py`:
```python
#!/usr/bin/env python3
"""Иконка tvOS (слои), Top Shelf и AccentColor из баннера Android-приложения AlemTV.

Временная графика (исходник 320x180 масштабируется вверх): заменить исходниками от владельцев AlemTV.
Требует Pillow: pip3 install pillow.
"""
import json
import os
from PIL import Image

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, "reference", "decompiled", "resources", "res", "drawable-xhdpi", "alem.png")
ASSETS = os.path.join(ROOT, "App", "Resources", "Assets.xcassets")
BRAND = os.path.join(ASSETS, "App Icon & Top Shelf Image.brandassets")
INFO = {"author": "xcode", "version": 1}

banner = Image.open(SRC).convert("RGBA")


def write_json(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        json.dump(data, f, indent=2)


def back(size):
    return Image.new("RGBA", size, (0, 0, 0, 255))


def front(size, scale=0.8):
    w, h = size
    ratio = min(w * scale / banner.width, h * scale / banner.height)
    logo = banner.resize((int(banner.width * ratio), int(banner.height * ratio)), Image.LANCZOS)
    layer = Image.new("RGBA", size, (0, 0, 0, 0))
    layer.paste(logo, ((w - logo.width) // 2, (h - logo.height) // 2), logo)
    return layer


def flat(size):
    image = back(size)
    image.alpha_composite(front(size, 0.6))
    return image.convert("RGB")


def imageset(directory, sizes, make):
    images = []
    for scale, size in sizes:
        name = f"image@{scale}.png"
        os.makedirs(directory, exist_ok=True)
        make(size).save(os.path.join(directory, name))
        images.append({"idiom": "tv", "scale": scale, "filename": name})
    write_json(os.path.join(directory, "Contents.json"), {"images": images, "info": INFO})


def imagestack(name, sizes):
    stack = os.path.join(BRAND, f"{name}.imagestack")
    write_json(os.path.join(stack, "Contents.json"),
               {"info": INFO, "layers": [{"filename": "Front.imagestacklayer"}, {"filename": "Back.imagestacklayer"}]})
    for layer, make in (("Front", front), ("Back", back)):
        directory = os.path.join(stack, f"{layer}.imagestacklayer")
        write_json(os.path.join(directory, "Contents.json"), {"info": INFO})
        imageset(os.path.join(directory, "Content.imageset"), sizes, make)


write_json(os.path.join(ASSETS, "Contents.json"), {"info": INFO})
imagestack("App Icon", [("1x", (400, 240)), ("2x", (800, 480))])
imagestack("App Icon - App Store", [("1x", (1280, 768))])
imageset(os.path.join(BRAND, "Top Shelf Image.imageset"), [("1x", (1920, 720)), ("2x", (3840, 1440))], flat)
imageset(os.path.join(BRAND, "Top Shelf Image Wide.imageset"), [("1x", (2320, 720)), ("2x", (4640, 1440))], flat)
write_json(os.path.join(BRAND, "Contents.json"), {
    "assets": [
        {"filename": "App Icon - App Store.imagestack", "idiom": "tv", "role": "primary-app-icon", "size": "1280x768"},
        {"filename": "App Icon.imagestack", "idiom": "tv", "role": "primary-app-icon", "size": "400x240"},
        {"filename": "Top Shelf Image Wide.imageset", "idiom": "tv", "role": "top-shelf-image-wide", "size": "2320x720"},
        {"filename": "Top Shelf Image.imageset", "idiom": "tv", "role": "top-shelf-image", "size": "1920x720"},
    ],
    "info": INFO,
})
write_json(os.path.join(ASSETS, "AccentColor.colorset", "Contents.json"), {
    "colors": [{"idiom": "universal", "color": {"color-space": "srgb",
                "components": {"red": "1.000", "green": "0.533", "blue": "0.000", "alpha": "1.000"}}}],
    "info": INFO,
})
print("assets ->", ASSETS)
```

Run: `python3 tools/make_brand_assets.py`
Expected: `assets -> …/App/Resources/Assets.xcassets`.

- [ ] **Step 2: Подключить в проект**

В `project.yml`, в `targets.AlemTV.settings.base`, добавить:
```yaml
        ASSETCATALOG_COMPILER_APPICON_NAME: "App Icon & Top Shelf Image"
        ASSETCATALOG_COMPILER_GLOBAL_ACCENT_COLOR_NAME: AccentColor
```

- [ ] **Step 3: Сборка без предупреждений каталога**

Run: `xcodegen generate && xcodebuild -project AlemTV.xcodeproj -scheme AlemTV -destination 'generic/platform=tvOS Simulator' build 2>&1 | grep -iE "actool|xcassets|error:|BUILD" | head -20`
Expected: `** BUILD SUCCEEDED **`, ошибок `actool` нет. Если `actool` требует idiom `tv-marketing` для слоёв «App Icon - App Store», заменить в `imagestack("App Icon - App Store", …)` idiom на `tv-marketing` (добавить параметр `idiom` в `imageset`) и перегенерировать.

- [ ] **Step 4: Ручная проверка**

Expected: в симуляторе на домашнем экране tvOS у приложения иконка ALEM TV на чёрном фоне, при фокусе виден параллакс слоёв.

- [ ] **Step 5: Commit**

```bash
git add tools/make_brand_assets.py App/Resources/Assets.xcassets project.yml
git commit -m "Брендинг: иконка tvOS, Top Shelf и акцентный цвет AlemTV

Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>
Claude-Session: https://claude.ai/code/session_015tkg9WmfzBtZ6B6QQFpCUA"
```

---

### Task 15: Живой интеграционный тест и чек-лист для Apple TV

**Files:**
- Create: `Packages/AlemCore/Tests/AlemCoreTests/LiveIntegrationTests.swift`
- Create: `docs/manual-test-checklist.md`

**Interfaces:**
- Consumes:
  - `PortalClient`, `SessionStore`, `InMemorySecureStore`, `StreamURLBuilder`, `EPGStore`;
  - уже привязанный терминал из `reference/samples/.terminal.json`, который создал `tools/probe.py`.
- Produces: ручная проверка протокола против реального сервера и чек-лист приёмки на устройстве.

- [ ] **Step 1: Тест**

`Packages/AlemCore/Tests/AlemCoreTests/LiveIntegrationTests.swift`:
```swift
import Testing
import Foundation
@testable import AlemCore

/// Живой прогон против telecom.alemtv.tm. Новых терминалов не создаёт: берёт MAC из reference/samples/.terminal.json.
/// Запуск: ALEMTV_LIVE=1 swift test --package-path Packages/AlemCore --filter LiveIntegrationTests
@Suite(.enabled(if: ProcessInfo.processInfo.environment["ALEMTV_LIVE"] == "1"), .serialized)
struct LiveIntegrationTests {
    static let root = URL(fileURLWithPath: #filePath)
        .deletingLastPathComponent()   // AlemCoreTests
        .deletingLastPathComponent()   // Tests
        .deletingLastPathComponent()   // AlemCore
        .deletingLastPathComponent()   // Packages
        .deletingLastPathComponent()   // корень репозитория

    func make() throws -> (SessionStore, PortalClient) {
        let data = try Data(contentsOf: Self.root.appendingPathComponent("reference/samples/.terminal.json"))
        let mac = try #require(try JSONDecoder().decode([String: String].self, from: data)["macaddr"])
        let store = InMemorySecureStore()
        store.set(mac, forKey: "mac")
        let client = PortalClient(baseURL: URL(string: "http://telecom.alemtv.tm")!,
                                  terminal: .appleTV(appVersion: "0.1.0", osVersion: "17.0"))
        return (SessionStore(api: client, store: store, macKey: "mac"), client)
    }

    @Test func signInWithBoundTerminal() async throws {
        let (session, _) = try make()
        guard case .signedIn(let a) = try await session.start() else {
            Issue.record("терминал не авторизован — перепривязать через tools/probe.py")
            return
        }
        #expect(a.channels.count > 100)
        #expect(a.timeshiftEnabled)
        #expect(!a.tokens.isEmpty)
        #expect(a.languages.map(\.code).contains("tk"))
    }

    @Test func streamsAreCleanHLS() async throws {
        let (session, _) = try make()
        guard case .signedIn(let a) = try await session.start() else { Issue.record("not signed in"); return }
        let channel = try #require(a.channels.first { $0.hasArchive && $0.key != nil })
        let context = try #require(await session.streamContext())
        let now = await session.clock.now()
        let modes: [StreamMode] = [
            .live,
            .timeshift(behind: 600),
            .archive(start: StreamURLBuilder.floorMinute(now.addingTimeInterval(-7_200)), duration: 600),
        ]
        for mode in modes {
            let url = try StreamURLBuilder.url(for: channel, mode: mode, context: context)
            let segment = try await firstSegment(of: url)
            #expect(segment.count > 188 * 100, "\(mode): сегмент слишком мал")
            #expect(scrambledPackets(segment) == 0, "\(mode): поток скремблирован")
        }
    }

    @Test func epgHasProgramsForREN() async throws {
        let (session, client) = try make()
        _ = try await session.start()
        let epg = EPGStore(source: client)
        let programs = try await epg.programs(mediaID: 33, day: PortalDate.dayString(Date()), languageID: 1)
        #expect(!programs.isEmpty)
        let current = try await epg.current(mediaIDs: [33, 76], languageID: 1)
        #expect(current[33] != nil)
    }

    // MARK: - Помощники

    /// Спуск по master → media плейлисту до первого сегмента; 404 повторяется один раз (холодный архив Flussonic).
    func firstSegment(of url: URL) async throws -> Data {
        var current = url
        for _ in 0..<3 {
            let data = try await get(current)
            guard let text = String(data: data, encoding: .utf8), text.hasPrefix("#EXTM3U") else { return data }
            let line = try #require(text.split(separator: "\n").first { !$0.hasPrefix("#") && !$0.isEmpty })
            current = try #require(URL(string: String(line), relativeTo: current)?.absoluteURL)
        }
        return try await get(current)
    }

    func get(_ url: URL, retry: Bool = true) async throws -> Data {
        var request = URLRequest(url: url)
        request.setValue("bytes=0-199999", forHTTPHeaderField: "Range")
        let (data, response) = try await URLSession.shared.data(for: request)
        let status = (response as? HTTPURLResponse)?.statusCode ?? 0
        if status == 404 && retry {
            try await Task.sleep(for: .seconds(2))
            return try await get(url, retry: false)
        }
        try #require((200..<300).contains(status), "HTTP \(status)")
        return data
    }

    /// TS-пакеты с payload и ненулевыми scrambling_control битами.
    func scrambledPackets(_ data: Data) -> Int {
        let bytes = [UInt8](data)
        var index = bytes.firstIndex(of: 0x47) ?? bytes.count
        var scrambled = 0
        while index + 188 <= bytes.count {
            guard bytes[index] == 0x47 else { index += 1; continue }
            let pid = (Int(bytes[index + 1] & 0x1f) << 8) | Int(bytes[index + 2])
            if pid != 0, pid != 0x1fff, bytes[index + 3] & 0x10 != 0, bytes[index + 3] & 0xc0 != 0 {
                scrambled += 1
            }
            index += 188
        }
        return scrambled
    }
}
```

- [ ] **Step 2: Запуск**

Run: `swift test --package-path Packages/AlemCore`
Expected: все юнит-тесты passed, `LiveIntegrationTests` пропущены (skipped).

Run: `ALEMTV_LIVE=1 swift test --package-path Packages/AlemCore --filter LiveIntegrationTests`
Expected: 3 теста passed. Если `signInWithBoundTerminal` пишет «терминал не авторизован», это не ошибка кода: терминал отвязан. Нужно перезапустить `python3 tools/probe.py`, он заново привяжет терминал.

- [ ] **Step 3: Чек-лист приёмки на устройстве**

`docs/manual-test-checklist.md`:
```markdown
# AlemTV tvOS: приёмка на Apple TV 4K

Сборка: Xcode → схема AlemTV → устройство Apple TV (или TestFlight). Отметить ✅/❌ и записать наблюдения.

## Вход
- [ ] Первый запуск: экран «Вход», логин/пароль из аккаунта → играет канал.
- [ ] Перезапуск приложения: входа нет, сразу играет последний канал.
- [ ] Неверный пароль: текст ошибки сервера под формой, поля не стёрты.
- [ ] Удаление и повторная установка приложения: вход без пароля (MAC в Keychain). Если просит пароль — записать.

## Эфир
- [ ] ↑/↓ на пульте переключают каналы в текущей рубрике.
- [ ] ← открывает список каналов поверх видео; Menu закрывает; выбор канала играет его.
- [ ] Menu в эфире открывает гид; Menu в гиде возвращает к видео.
- [ ] HEVC 1080p без артефактов на 5 разных каналах (национальные, русские, 4K).

## Гид и EPG
- [ ] Рубрики с сервера, логотипы каналов загружаются.
- [ ] «Сейчас в эфире» и прогресс на карточках, обновляются раз в минуту.
- [ ] Долгое нажатие → «В избранное» → канал во вкладке «Избранное»; на Android-приложении того же аккаунта канал тоже в избранном.
- [ ] Программа передач: дни назад (3 дня архива) и вперёд, значки архива, будущие неактивны.

## Архив и таймшифт
- [ ] Передача вчерашнего дня открывается с полной шкалой, перемотка работает.
- [ ] По окончании архивной передачи включается следующая.
- [ ] Пауза в эфире 2 минуты → продолжение показывает плашку «−00:02:xx от эфира».
- [ ] «−10 с»/«+10 с»/«В эфир»/«С начала» в транспортной панели работают.
- [ ] Канал без архива (например «Че (+7)»): кнопок таймшифта нет, пауза не ломает эфир.

## Устойчивость
- [ ] Просмотр одного канала > 1 часа без остановок (ротация токенов). Если поток оборвался через ~1–3 ч — записать время.
- [ ] Выключить Wi-Fi/кабель на 30 с и вернуть: поток восстанавливается сам.
- [ ] Уход в фон (Home) на 10 минут и возврат: видео продолжается.
- [ ] 5 часов без нажатий → «Продолжить просмотр?».

## Настройки
- [ ] Язык Türkmençe/English/Русский: интерфейс и названия рубрик меняются.
- [ ] Профиль 18+: запрос пароля; неверный → «Ошибка ввода» и возврат на 0+. Записать: прислал ли сервер пароль профиля (если 18+ включается без проверки — пароль не приходит).
- [ ] О приложении: версия и MAC.
- [ ] Выход из аккаунта → «Вход» (проверять в последнюю очередь: отвязывает терминал).
```

- [ ] **Step 4: Commit**

```bash
git add Packages/AlemCore/Tests docs/manual-test-checklist.md
git commit -m "Живой интеграционный тест протокола и чек-лист приёмки на Apple TV

Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>
Claude-Session: https://claude.ai/code/session_015tkg9WmfzBtZ6B6QQFpCUA"
```

---

## Покрытие спецификации

| Раздел спецификации | Задачи |
|---|---|
| §4.1 AresCipher | 3 |
| §4.2 PortalClient | 6 (без `update_profile`: смены пароля профиля нет в объёме экранов, YAGNI) |
| §4.3 StreamURLBuilder | 5 |
| §4.4 SessionStore | 8 (отличие: при пустом MAC сразу «Вход», без `login{create_macaddr}`) |
| §4.5 EPGStore, ServerClock | 4, 5, 7 |
| §4.6 Плеер, сторож, ATS | 1 (ATS), 9, 12 |
| §5 Экраны и управление | 10, 11, 12, 13 |
| §5 Локализация, брендинг, автопауза | 10, 14, 12 |
| §6 Ошибки | 6, 8, 10 (offline, вход), 12 (плеер) |
| §7 Тестирование | 2–9 (юнит), 15 (живой тест и чек-лист) |
