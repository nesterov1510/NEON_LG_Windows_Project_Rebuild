# Единый движок VLCKit: план реализации

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Заменить AVPlayer единым движком VLCKit 4, который воспроизводит все каналы AlemTV (HEVC/H.264/MPEG-2, звук AAC/MP2) в TS, и добавить собственную панель плеера с управлением пультом.

**Architecture:** AlemCore остаётся без VLCKit. Он содержит:
- протокол `PlayerEngine`;
- `ContentClock` — время показываемого кадра;
- `PlaybackPolicy` — таблицу «кнопка пульта → действие»;
- `AudioTrackChoice`;
- `StreamURLBuilder`, теперь только для TS.

Таргет приложения подключает VLCKit через SPM. В нём:
- `VLCPlayerEngine` — реализация протокола;
- `VideoSurface` — UIView для отрисовки, без фокуса;
- `PlayerScreen` — ловит пульт через `onMoveCommand`/`onPlayPauseCommand`/`onExitCommand`;
- `TransportOverlay` и `ScheduleOverlay` — свои оверлеи.

**Tech Stack:** Swift 6, SwiftUI (tvOS 17+), VLCKit 4.0.0-a25 (SPM), AVKit (только `AVDisplayManager`), Swift Testing, XcodeGen.

**Spec:** `docs/superpowers/specs/2026-10-04-vlckit-engine-design.md` (дополняет `docs/superpowers/specs/2026-10-03-alemtv-tvos-design.md`).

## Global Constraints

- tvOS deployment target `17.0`, Swift 6 (строгая конкурентность), Xcode 26.5.
- VLCKit: `https://github.com/videolan/vlckit.git`, **`exactVersion: 4.0.0-a25`**, продукт `VLCKit`. Подключается **только к таргету `AlemTV`**. В `Packages/AlemCore/Package.swift` VLCKit не добавляется.
- Все каналы в TS:
  - эфир: `path` канала как есть;
  - архив: `{timeshift}/index-{S}-{D}.m3u8`;
  - таймшифт: `{timeshift}/video-timeshift_rel-{B}.m3u8`.
- `ContentClock.liveLatency = 20` с; `PlaybackPolicy.liveSnap = 45` с; шаг перемотки 10 с; автоскрытие панели 5 с.
- `network-caching=1500`, `live-caching=1500` (опции `VLCMedia`).
- В лог — только хост и путь URL, никогда не query (токены), session_id, пароль, MAC.
- ATS остаётся `NSAllowsArbitraryLoads = YES`.
- Тесты ядра: `swift test --package-path Packages/AlemCore`. Сборка: `xcodegen generate && xcodebuild -project AlemTV.xcodeproj -scheme AlemTV -destination 'generic/platform=tvOS Simulator' build`.
- Коммиты с атрибуцией:
  ```
  Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>
  Claude-Session: https://claude.ai/code/session_015tkg9WmfzBtZ6B6QQFpCUA
  ```

## Review Focus

1. **Пауза и буферизация в архиве и таймшифте.** Время кадра не должно «убегать» вперёд, пока поток стоит: `played` накапливается только в состоянии «играет». Тест в Task 2: `pausesAndBufferingDoNotAdvanceTime`.
2. **Канал с двумя звуковыми дорожками и запомненный язык, которого нет у следующего канала.** Дорожка не меняется, ошибки нет. Тест в Task 3: `preferredLanguageMissingKeepsDefault`.
3. **Нажатия пульта при открытом оверлее** (панель, список, программа, ошибка). Стрелки не переключают каналы, Menu закрывает верхний оверлей, а не открывает гид. Тест в Task 3: таблица `remoteTable`.
4. **Архив: ← и → перематывают, ↑ и ↓ ничего не делают.** В эфире → ничего не делает. Тест в Task 3.
5. **Повторный `stopped` от VLC после нашего `stop()` или смены канала.** Не должен засчитываться как ошибка и запускать повторы. Проверка смоук-скриптом в Task 4: переключение канала не даёт «Канал недоступен».

---

## Структура файлов

```
Packages/AlemCore/Sources/AlemCore/
├─ Streams/StreamURLBuilder.swift        изменить: только TS (удалить StreamFormat, fmp4)
├─ Streams/StreamFormatResolver.swift    удалить
├─ Playback/ContentClock.swift           создать
├─ Playback/AudioTrackChoice.swift       создать (AudioTrack + выбор)
├─ Playback/PlaybackPolicy.swift         изменить: новая таблица пульта
└─ Playback/PlayerEngine.swift           изменить: протокол без AVFoundation, удалить AVPlayerEngine
Packages/AlemCore/Tests/AlemCoreTests/
├─ StreamURLBuilderTests.swift           изменить ожидания на TS
├─ StreamFormatTests.swift               удалить
├─ ContentClockTests.swift               создать
├─ PlaybackPolicyTests.swift             изменить (новая таблица)
├─ AudioTrackChoiceTests.swift           создать
├─ PlaybackTests.swift                   изменить: убрать тесты AVPlayerEngine
└─ LiveIntegrationTests.swift            изменить: проверка TS (PMT) вместо fMP4
project.yml                              добавить пакет VLCKit к таргету AlemTV
App/Features/Player/
├─ VLCPlayerEngine.swift                 создать
├─ VideoSurface.swift                    создать
├─ DisplayCriteria.swift                 создать
├─ PlayerModel.swift                     переписать на VLCPlayerEngine + ContentClock + PlaybackPolicy
├─ PlayerScreen.swift                    переписать: видео + ловец пульта + оверлеи
├─ TransportOverlay.swift                создать
├─ ScheduleOverlay.swift                 создать
├─ ChannelListOverlay.swift              без изменений
├─ PlayerContainer.swift                 удалить
└─ ProgramInfoView.swift                 удалить
App/Features/Settings/SettingsView.swift добавить строку «Воспроизведение: VLCKit (LGPL 2.1)»
tools/gen_strings.py                     новые строки
tools/smoke_channels.sh                  создать
docs/manual-test-checklist.md            обновить
```

---

### Task 1: Потоки только в TS

**Files:**
- Modify: `Packages/AlemCore/Sources/AlemCore/Streams/StreamURLBuilder.swift`
- Delete: `Packages/AlemCore/Sources/AlemCore/Streams/StreamFormatResolver.swift`, `Packages/AlemCore/Tests/AlemCoreTests/StreamFormatTests.swift`
- Modify: `Packages/AlemCore/Tests/AlemCoreTests/StreamURLBuilderTests.swift`, `Packages/AlemCore/Tests/AlemCoreTests/LiveIntegrationTests.swift`
- Modify: `App/Features/Player/PlayerModel.swift` (убрать `formats` и аргумент `format:`)

**Interfaces:**
- Produces: `StreamURLBuilder.url(for: Channel, mode: StreamMode, context: StreamContext) throws -> URL` без параметра `format`. Эфир — `path` как есть, архив — `index-S-D.m3u8`, таймшифт — `video-timeshift_rel-B.m3u8`.

- [ ] **Step 1: Обновить ожидания тестов (RED)**

В `StreamURLBuilderTests.swift` заменить ожидаемые строки ровно так:

| Тест | Было | Стало |
|---|---|---|
| `liveWithCompositeToken` | `…/AltynAsyr/index.fmp4.m3u8?` | `…/AltynAsyr/video.m3u8?` |
| `archiveURL` | `…/index-1700000000-600.fmp4.m3u8?` | `…/index-1700000000-600.m3u8?` |
| `timeshiftURL` | `…/AltynAsyr/timeshift_rel-300.fmp4.m3u8?` | `…/AltynAsyr/video-timeshift_rel-300.m3u8?` |
| `timeshiftOffsetIsSubtracted` | `/index-1699996400-60.fmp4.m3u8` | `/index-1699996400-60.m3u8` |
| `channelWithoutKeyUsesPlainToken` | `…/AltynAsyr/index.fmp4.m3u8?token=SID` | `…/AltynAsyr/video.m3u8?token=SID` |
| `channelWithoutAuthHasNoQuery` | `…/AltynAsyr/index.fmp4.m3u8` | `…/AltynAsyr/video.m3u8` |
| `missingSchemeDefaultsToHTTPAndNoPort` | `http://119.235.117.209/AltynAsyr/index.fmp4.m3u8` | `http://119.235.117.209/AltynAsyr/video.m3u8` |
| `timeshiftBaseDropsFileAndQuery` | `http://h:1/Ch/timeshift_rel-5.fmp4.m3u8?` | `http://h:1/Ch/video-timeshift_rel-5.m3u8?` |

Тест `liveUsesFMP4PlaylistInChannelDirectory` заменить на:
```swift
    /// Эфир — путь канала как есть (VLC играет TS с любыми кодеками).
    @Test func livePathIsUsedAsIs() throws {
        var channel = altyn
        channel.auth = nil
        channel.path = "/Some/Deep/mono.m3u8"
        #expect(try StreamURLBuilder.url(for: channel, mode: .live, context: context).absoluteString == "http://119.235.117.209:8010/Some/Deep/mono.m3u8")
    }
```
Удалить `Packages/AlemCore/Tests/AlemCoreTests/StreamFormatTests.swift`: `git rm Packages/AlemCore/Tests/AlemCoreTests/StreamFormatTests.swift`.

Run: `swift test --package-path Packages/AlemCore --filter StreamURLBuilderTests`
Expected: FAIL. Ожидается `video.m3u8`, а получен `index.fmp4.m3u8` (8+ проверок).

- [ ] **Step 2: Реализация**

В `StreamURLBuilder.swift`:
1. Удалить `public enum StreamFormat` целиком и константу `fmp4Playlist`.
2. Сигнатура: `public static func url(for channel: Channel, mode: StreamMode, context: StreamContext) throws -> URL`.
3. Тело `switch mode`:
```swift
        case .live:
            base = try liveBase(channel)
            auth = channel.auth
        case .archive(let start, let duration):
            let startSeconds = Int(start.timeIntervalSince1970 - (channel.timeshiftOffset ?? 0))
            base = "\(try timeshiftBase(channel))/index-\(startSeconds)-\(max(0, Int(duration))).m3u8"
            auth = channel.timeshiftAuth ?? channel.auth
        case .timeshift(let behind):
            base = "\(try timeshiftBase(channel))/video-timeshift_rel-\(max(0, Int(behind))).m3u8"
            auth = channel.timeshiftAuth ?? channel.auth
```
4. `liveBase`:
```swift
    static func liveBase(_ channel: Channel) throws -> String {
        if let path = channel.path, path.hasPrefix("http://") || path.hasPrefix("https://") { return path }
        guard let host = channel.host, !host.isEmpty else { throw StreamURLError.noLiveAddress }
        let scheme = (channel.scheme?.isEmpty == false) ? channel.scheme! : "http"
        let port = channel.port.map { ":\($0)" } ?? ""
        let path = String((channel.path ?? "").drop(while: { $0 == "/" }))
        return "\(scheme)://\(host)\(port)/\(path)"
    }
```
Удалить `Streams/StreamFormatResolver.swift`: `git rm Packages/AlemCore/Sources/AlemCore/Streams/StreamFormatResolver.swift`.

В `App/Features/Player/PlayerModel.swift`:
- удалить строку `@ObservationIgnored private let formats = StreamFormatResolver()`;
- в `load(_:)` заменить
```swift
                let format = try await self.formats.format(for: channel, context: context)
                guard !Task.isCancelled else { return }
                let url = try StreamURLBuilder.url(for: channel, mode: streamMode, context: context, format: format)
```
на
```swift
                let url = try StreamURLBuilder.url(for: channel, mode: streamMode, context: context)
```

- [ ] **Step 3: Тесты проходят**

Run: `swift test --package-path Packages/AlemCore`
Expected: всё passed.

- [ ] **Step 4: Живой тест — TS вместо fMP4**

В `LiveIntegrationTests.swift` заменить тест `streamsAreCleanFMP4` и помощники `MediaPlaylist`/`mediaPlaylist(from:)` на:
```swift
    /// Эфир, таймшифт и архив — TS с видео- и аудиодорожкой, без скремблирования.
    @Test func streamsAreCleanTS() async throws {
        let (session, _) = try make()
        guard case .signedIn(let a) = try await session.start() else { Issue.record("not signed in"); return }
        let channel = try #require(a.channels.first { $0.hasArchive && $0.key != nil })
        let context = try #require(await session.streamContext())
        let now = await session.clock.now()
        let modes: [StreamMode] = [
            .live,
            .timeshift(behind: 600),
            .archive(start: StreamURLBuilder.floorMinute(now.addingTimeInterval(-7_200)), duration: 600),
        ]
        for mode in modes {
            let url = try StreamURLBuilder.url(for: channel, mode: mode, context: context)
            let segment = try await firstSegment(of: url)
            let types = streamTypes(segment)
            #expect(!types.isDisjoint(with: [0x1b, 0x24, 0x02]), "\(mode): нет видео (\(types))")
            #expect(!types.isDisjoint(with: [0x0f, 0x11, 0x03, 0x04, 0x81, 0x06]), "\(mode): нет звука (\(types))")
            #expect(scrambledPackets(segment) == 0, "\(mode): поток скремблирован")
        }
    }

    /// Спуск master → media → первый сегмент; 404 повторяется один раз (холодный архив Flussonic).
    func firstSegment(of url: URL) async throws -> Data {
        var current = url
        for _ in 0..<3 {
            let data = try await get(current)
            guard let text = String(data: data, encoding: .utf8), text.hasPrefix("#EXTM3U") else { return data }
            let line = try #require(text.split(separator: "\n").first { !$0.hasPrefix("#") && !$0.isEmpty })
            current = try #require(URL(string: String(line), relativeTo: current)?.absoluteURL)
        }
        return try await get(current)
    }

    /// stream_type элементарных потоков из PMT.
    func streamTypes(_ data: Data) -> Set<UInt8> {
        let bytes = [UInt8](data)
        var pmtPIDs = Set<Int>()
        var types = Set<UInt8>()
        var index = 0
        while index + 188 <= bytes.count {
            defer { index += 188 }
            guard bytes[index] == 0x47, bytes[index + 1] & 0x40 != 0 else { continue }
            let pid = (Int(bytes[index + 1] & 0x1f) << 8) | Int(bytes[index + 2])
            var offset = index + 4
            if bytes[index + 3] & 0x20 != 0 { offset += 1 + Int(bytes[index + 4]) }
            guard offset < index + 188 else { continue }
            offset += 1 + Int(bytes[offset])   // pointer_field
            guard offset + 12 < index + 188 else { continue }
            let sectionLength = (Int(bytes[offset + 1] & 0x0f) << 8) | Int(bytes[offset + 2])
            let end = min(offset + 3 + sectionLength - 4, index + 188)
            if pid == 0 {
                var j = offset + 8
                while j + 4 <= end {
                    let program = (Int(bytes[j]) << 8) | Int(bytes[j + 1])
                    if program != 0 { pmtPIDs.insert((Int(bytes[j + 2] & 0x1f) << 8) | Int(bytes[j + 3])) }
                    j += 4
                }
            } else if pmtPIDs.contains(pid) {
                var j = offset + 12 + ((Int(bytes[offset + 10] & 0x0f) << 8) | Int(bytes[offset + 11]))
                while j + 5 <= end {
                    types.insert(bytes[j])
                    j += 5 + ((Int(bytes[j + 3] & 0x0f) << 8) | Int(bytes[j + 4]))
                }
            }
        }
        return types
    }

    /// TS-пакеты с payload и ненулевыми scrambling_control битами.
    func scrambledPackets(_ data: Data) -> Int {
        let bytes = [UInt8](data)
        var index = bytes.firstIndex(of: 0x47) ?? bytes.count
        var scrambled = 0
        while index + 188 <= bytes.count {
            guard bytes[index] == 0x47 else { index += 1; continue }
            let pid = (Int(bytes[index + 1] & 0x1f) << 8) | Int(bytes[index + 2])
            if pid != 0, pid != 0x1fff, bytes[index + 3] & 0x10 != 0, bytes[index + 3] & 0xc0 != 0 {
                scrambled += 1
            }
            index += 188
        }
        return scrambled
    }
```
Функция `get(_:retry:)` остаётся как есть.

Run: `ALEMTV_LIVE=1 swift test --package-path Packages/AlemCore --filter LiveIntegrationTests`
Expected: 3 теста passed.

- [ ] **Step 5: Сборка приложения и коммит**

Run: `xcodegen generate && xcodebuild -project AlemTV.xcodeproj -scheme AlemTV -destination 'generic/platform=tvOS Simulator' build 2>&1 | grep -E "error:|BUILD"`
Expected: `** BUILD SUCCEEDED **`. Приложение пока на AVPlayer, HEVC-каналы в TS играют только звук; это временно до Task 4.

```bash
git add -A Packages App
git commit -m "Потоки только в TS: убран выбор fMP4 (подготовка к VLCKit)

Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>
Claude-Session: https://claude.ai/code/session_015tkg9WmfzBtZ6B6QQFpCUA"
```

---

### Task 2: ContentClock — время показываемого кадра

**Files:**
- Create: `Packages/AlemCore/Sources/AlemCore/Playback/ContentClock.swift`
- Test: `Packages/AlemCore/Tests/AlemCoreTests/ContentClockTests.swift`

**Interfaces:**
- Consumes: `StreamMode` (live / archive(start:duration:) / timeshift(behind:)).
- Produces: `public struct ContentClock: Sendable, Equatable`:
  - `static let liveLatency: TimeInterval = 20`;
  - `init(mode: StreamMode, startedAt: Date)`, `mode`;
  - `mutating didStartPlaying(at:)`, `mutating didStopPlaying(at:)`, `mutating didSeek(toPosition:at:)`;
  - `playedTime(at:) -> TimeInterval`, `contentTime(at:) -> Date`, `behindLive(at:) -> TimeInterval`.

- [ ] **Step 1: Падающие тесты**

`Packages/AlemCore/Tests/AlemCoreTests/ContentClockTests.swift`:
```swift
import Testing
import Foundation
@testable import AlemCore

@Suite struct ContentClockTests {
    func t(_ s: TimeInterval) -> Date { Date(timeIntervalSince1970: 1_000_000 + s) }
    let programStart = Date(timeIntervalSince1970: 900_000)

    @Test func archiveTimeIsStartPlusPlayed() {
        var clock = ContentClock(mode: .archive(start: programStart, duration: 3600), startedAt: t(0))
        clock.didStartPlaying(at: t(2))
        #expect(clock.contentTime(at: t(32)) == programStart.addingTimeInterval(30))
    }

    @Test func pausesAndBufferingDoNotAdvanceTime() {
        var clock = ContentClock(mode: .archive(start: programStart, duration: 3600), startedAt: t(0))
        clock.didStartPlaying(at: t(0))
        clock.didStopPlaying(at: t(40))            // пауза или буферизация
        #expect(clock.playedTime(at: t(100)) == 40)
        clock.didStartPlaying(at: t(100))
        #expect(clock.contentTime(at: t(110)) == programStart.addingTimeInterval(50))
    }

    @Test func repeatedStartOrStopIsIdempotent() {
        var clock = ContentClock(mode: .archive(start: programStart, duration: 3600), startedAt: t(0))
        clock.didStartPlaying(at: t(0))
        clock.didStartPlaying(at: t(5))            // повторное «играет» не сбрасывает отсчёт
        clock.didStopPlaying(at: t(10))
        clock.didStopPlaying(at: t(20))            // повторная остановка ничего не добавляет
        #expect(clock.playedTime(at: t(30)) == 10)
    }

    @Test func archiveSeekSetsPosition() {
        var clock = ContentClock(mode: .archive(start: programStart, duration: 3600), startedAt: t(0))
        clock.didStartPlaying(at: t(0))
        clock.didSeek(toPosition: 120, at: t(10))
        #expect(clock.contentTime(at: t(15)) == programStart.addingTimeInterval(125))
        clock.didSeek(toPosition: -5, at: t(20))
        #expect(clock.playedTime(at: t(20)) == 0)
    }

    @Test func timeshiftStartsBehindAndAdvances() {
        var clock = ContentClock(mode: .timeshift(behind: 300), startedAt: t(0))
        clock.didStartPlaying(at: t(2))             // 2 с на открытие потока
        #expect(clock.contentTime(at: t(12)) == t(-300 + 10))
        #expect(clock.behindLive(at: t(12)) == 302)
    }

    @Test func liveIsNowMinusLatency() {
        let clock = ContentClock(mode: .live, startedAt: t(0))
        #expect(clock.contentTime(at: t(500)) == t(500 - ContentClock.liveLatency))
        #expect(clock.behindLive(at: t(500)) == ContentClock.liveLatency)
    }
}
```

- [ ] **Step 2: Тесты падают**

Run: `swift test --package-path Packages/AlemCore --filter ContentClockTests`
Expected: `cannot find 'ContentClock' in scope`.

- [ ] **Step 3: Реализация**

`Packages/AlemCore/Sources/AlemCore/Playback/ContentClock.swift`:
```swift
import Foundation

/// Реальное время показываемого кадра. VLC не отдаёт EXT-X-PROGRAM-DATE-TIME, а его собственное
/// время у части каналов — метки потока, поэтому время считается из режима запуска и проигранного.
public struct ContentClock: Sendable, Equatable {
    /// Типичная задержка HLS-эфира: 3 сегмента по 6 с + запас.
    public static let liveLatency: TimeInterval = 20

    public let mode: StreamMode
    public let startedAt: Date
    private var played: TimeInterval = 0
    private var runningSince: Date?

    public init(mode: StreamMode, startedAt: Date) {
        self.mode = mode
        self.startedAt = startedAt
    }

    public mutating func didStartPlaying(at now: Date) {
        if runningSince == nil { runningSince = now }
    }

    public mutating func didStopPlaying(at now: Date) {
        guard let since = runningSince else { return }
        played += max(0, now.timeIntervalSince(since))
        runningSince = nil
    }

    /// Перемотка внутри записи: позиция от начала записи.
    public mutating func didSeek(toPosition position: TimeInterval, at now: Date) {
        played = max(0, position)
        if runningSince != nil { runningSince = now }
    }

    public func playedTime(at now: Date) -> TimeInterval {
        played + (runningSince.map { max(0, now.timeIntervalSince($0)) } ?? 0)
    }

    public func contentTime(at now: Date) -> Date {
        switch mode {
        case .live:
            return now.addingTimeInterval(-Self.liveLatency)
        case .archive(let start, _):
            return start.addingTimeInterval(playedTime(at: now))
        case .timeshift(let behind):
            return startedAt.addingTimeInterval(-behind + playedTime(at: now))
        }
    }

    public func behindLive(at now: Date) -> TimeInterval {
        max(0, now.timeIntervalSince(contentTime(at: now)))
    }
}
```

- [ ] **Step 4: Тесты проходят**

Run: `swift test --package-path Packages/AlemCore --filter ContentClockTests`
Expected: 6 тестов passed.

- [ ] **Step 5: Commit**

```bash
git add Packages/AlemCore
git commit -m "AlemCore: ContentClock — время показываемого кадра без PDT

Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>
Claude-Session: https://claude.ai/code/session_015tkg9WmfzBtZ6B6QQFpCUA"
```

---

### Task 3: Таблица пульта и выбор звуковой дорожки

**Files:**
- Modify: `Packages/AlemCore/Sources/AlemCore/Playback/PlaybackPolicy.swift`
- Create: `Packages/AlemCore/Sources/AlemCore/Playback/AudioTrackChoice.swift`
- Modify: `Packages/AlemCore/Tests/AlemCoreTests/PlaybackPolicyTests.swift`
- Test: `Packages/AlemCore/Tests/AlemCoreTests/AudioTrackChoiceTests.swift`

**Interfaces:**
- Produces:
  - `public enum RemoteKey: CaseIterable, Sendable { up, down, left, right, select, playPause, menu }`.
  - `public enum PlayerOverlay: Sendable, Equatable { none, panel, channelList, schedule, error }`.
  - `public enum PlaybackKind: Sendable { live, timeshift, archive }`.
  - `public enum PlayerAction: Sendable, Equatable { previousChannel, nextChannel, showChannelList, showPanel, hidePanel, togglePause, skip(TimeInterval), openGuide, ignore }`.
  - `PlaybackPolicy.action(for: RemoteKey, overlay: PlayerOverlay, kind: PlaybackKind) -> PlayerAction`.
  - `PlaybackPolicy.skip(by:contentTime:now:archiveDepth:)`, `referenceTime(for:now:)`, `resumeAfterBackground(isLive:)`, `liveSnap` — без изменений.
  - `public struct AudioTrack: Sendable, Equatable, Identifiable { id: String; name: String; language: String? }`.
  - `public enum AudioTrackChoice { static func preferred(_ tracks: [AudioTrack], language: String?) -> AudioTrack? }`.
- Удаляются: `PlaybackPolicy.UIState`, `PlaybackPolicy.intercepts(_:_:)`.

- [ ] **Step 1: Падающие тесты**

В `PlaybackPolicyTests.swift` удалить тесты `noInterceptionWhileTransportBarVisible`, `interceptionInLiveWithHiddenBar`, `menuOpensGuideFromErrorOverlay`. Добавить в начало `@Suite struct PlaybackPolicyTests`:
```swift
    /// Таблица пульта (spec §4). Review Focus 3 и 4.
    @Test func remoteTable() {
        typealias P = PlaybackPolicy
        // Просмотр, эфир
        #expect(P.action(for: .up, overlay: .none, kind: .live) == .previousChannel)
        #expect(P.action(for: .down, overlay: .none, kind: .live) == .nextChannel)
        #expect(P.action(for: .left, overlay: .none, kind: .live) == .showChannelList)
        #expect(P.action(for: .right, overlay: .none, kind: .live) == .ignore)
        #expect(P.action(for: .select, overlay: .none, kind: .live) == .showPanel)
        #expect(P.action(for: .playPause, overlay: .none, kind: .live) == .togglePause)
        #expect(P.action(for: .menu, overlay: .none, kind: .live) == .openGuide)
        // Просмотр, таймшифт: → перематывает, ← — список
        #expect(P.action(for: .right, overlay: .none, kind: .timeshift) == .skip(10))
        #expect(P.action(for: .left, overlay: .none, kind: .timeshift) == .showChannelList)
        #expect(P.action(for: .up, overlay: .none, kind: .timeshift) == .previousChannel)
        // Просмотр, архив: ←/→ перематывают, ↑/↓ ничего
        #expect(P.action(for: .left, overlay: .none, kind: .archive) == .skip(-10))
        #expect(P.action(for: .right, overlay: .none, kind: .archive) == .skip(10))
        #expect(P.action(for: .up, overlay: .none, kind: .archive) == .ignore)
        #expect(P.action(for: .down, overlay: .none, kind: .archive) == .ignore)
        // Панель: навигация — фокусу, Menu закрывает панель, Play/Pause работает
        for key in [RemoteKey.up, .down, .left, .right, .select] {
            #expect(P.action(for: key, overlay: .panel, kind: .live) == .ignore)
        }
        #expect(P.action(for: .menu, overlay: .panel, kind: .live) == .hidePanel)
        #expect(P.action(for: .playPause, overlay: .panel, kind: .archive) == .togglePause)
        // Список каналов и программа сами обрабатывают пульт
        for key in RemoteKey.allCases {
            #expect(P.action(for: key, overlay: .channelList, kind: .live) == .ignore)
            #expect(P.action(for: key, overlay: .schedule, kind: .live) == .ignore)
        }
        // Ошибка: Menu — в гид, остальное — фокусу оверлея
        #expect(P.action(for: .menu, overlay: .error, kind: .live) == .openGuide)
        #expect(P.action(for: .down, overlay: .error, kind: .live) == .ignore)
    }
```

`Packages/AlemCore/Tests/AlemCoreTests/AudioTrackChoiceTests.swift`:
```swift
import Testing
@testable import AlemCore

@Suite struct AudioTrackChoiceTests {
    let rus = AudioTrack(id: "a1", name: "rus a1", language: "rus")
    let kaz = AudioTrack(id: "a2", name: "kaz a2", language: "kaz")

    @Test func picksRememberedLanguage() {
        #expect(AudioTrackChoice.preferred([rus, kaz], language: "kaz") == kaz)
        #expect(AudioTrackChoice.preferred([rus, kaz], language: "KAZ") == kaz)
    }

    @Test func preferredLanguageMissingKeepsDefault() {
        #expect(AudioTrackChoice.preferred([rus, kaz], language: "tuk") == nil)
    }

    @Test func singleTrackOrNoPreferenceKeepsDefault() {
        #expect(AudioTrackChoice.preferred([rus], language: "rus") == nil)
        #expect(AudioTrackChoice.preferred([rus, kaz], language: nil) == nil)
        #expect(AudioTrackChoice.preferred([], language: "rus") == nil)
    }
}
```

- [ ] **Step 2: Тесты падают**

Run: `swift test --package-path Packages/AlemCore --filter "PlaybackPolicyTests|AudioTrackChoiceTests"`
Expected: ошибки компиляции: нет `PlaybackPolicy.action`, `.right`, `AudioTrack`.

- [ ] **Step 3: Реализация**

В `PlaybackPolicy.swift` заменить начало файла (от `import Foundation` до конца `intercepts`) на:
```swift
import Foundation

/// Кнопки пульта Siri Remote.
public enum RemoteKey: CaseIterable, Sendable {
    case up, down, left, right, select, playPause, menu
}

/// Что сейчас поверх видео (по приоритету: ошибка > список > программа > панель > ничего).
public enum PlayerOverlay: Sendable, Equatable {
    case none, panel, channelList, schedule, error
}

public enum PlaybackKind: Sendable {
    case live, timeshift, archive
}

public enum PlayerAction: Sendable, Equatable {
    case previousChannel, nextChannel, showChannelList, showPanel, hidePanel, togglePause
    case skip(TimeInterval)
    case openGuide
    case ignore
}

/// Решения плеера без движка: пульт, перемотка эфира, опорное время EPG, возврат из фона.
public enum PlaybackPolicy {
    /// Задержка HLS-эфира (~3 сегмента по 6 с) + запас: ближе этого к «сейчас» при движении вперёд — эфир.
    public static let liveSnap: TimeInterval = 45
    public static let skipStep: TimeInterval = 10

    /// Таблица пульта (spec §4). `.ignore` — нажатие обрабатывает фокус оверлея.
    public static func action(for key: RemoteKey, overlay: PlayerOverlay, kind: PlaybackKind) -> PlayerAction {
        switch overlay {
        case .channelList, .schedule:
            return .ignore
        case .error:
            return key == .menu ? .openGuide : .ignore
        case .panel:
            switch key {
            case .menu: return .hidePanel
            case .playPause: return .togglePause
            default: return .ignore
            }
        case .none:
            switch key {
            case .up: return kind == .archive ? .ignore : .previousChannel
            case .down: return kind == .archive ? .ignore : .nextChannel
            case .left: return kind == .archive ? .skip(-skipStep) : .showChannelList
            case .right: return kind == .live ? .ignore : .skip(skipStep)
            case .select: return .showPanel
            case .playPause: return .togglePause
            case .menu: return .openGuide
            }
        }
    }
```
Функции `skip(by:contentTime:now:archiveDepth:)`, `referenceTime(for:now:)`, `ResumeAction`, `resumeAfterBackground(isLive:)` и закрывающая скобка остаются без изменений.

`Packages/AlemCore/Sources/AlemCore/Playback/AudioTrackChoice.swift`:
```swift
/// Звуковая дорожка потока (у части каналов их две: rus/kaz).
public struct AudioTrack: Sendable, Equatable, Identifiable {
    public var id: String
    public var name: String
    public var language: String?

    public init(id: String, name: String, language: String?) {
        self.id = id
        self.name = name
        self.language = language
    }
}

public enum AudioTrackChoice {
    /// Дорожка запомненного языка, если дорожек несколько и такая есть; иначе — оставить выбор движка.
    public static func preferred(_ tracks: [AudioTrack], language: String?) -> AudioTrack? {
        guard tracks.count > 1, let language = language?.lowercased() else { return nil }
        return tracks.first { $0.language?.lowercased() == language }
    }
}
```

`App/Features/Player/PlayerModel.swift` использует старый `PlaybackPolicy.intercepts`/`UIState` в `intercepts(_:)`. Чтобы приложение собиралось до Task 4, временно заменить тело `intercepts(_:)` на `false` (вся функция удаляется в Task 4):
```swift
    func intercepts(_ type: UIPress.PressType) -> Bool { false }
```

- [ ] **Step 4: Тесты проходят**

Run: `swift test --package-path Packages/AlemCore`
Expected: всё passed.

Run: `xcodebuild -project AlemTV.xcodeproj -scheme AlemTV -destination 'generic/platform=tvOS Simulator' build 2>&1 | grep -E "error:|BUILD"`
Expected: `** BUILD SUCCEEDED **`.

- [ ] **Step 5: Commit**

```bash
git add Packages/AlemCore App/Features/Player/PlayerModel.swift
git commit -m "AlemCore: таблица пульта для своей панели и выбор звуковой дорожки

Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>
Claude-Session: https://claude.ai/code/session_015tkg9WmfzBtZ6B6QQFpCUA"
```

---

### Task 4: Движок VLCKit и экран плеера без AVPlayer

**Files:**
- Modify: `Packages/AlemCore/Sources/AlemCore/Playback/PlayerEngine.swift` (протокол, удалить `AVPlayerEngine`)
- Modify: `Packages/AlemCore/Tests/AlemCoreTests/PlaybackTests.swift` (удалить тесты `AVPlayerEngine`)
- Modify: `project.yml`
- Create: `App/Features/Player/VLCPlayerEngine.swift`, `App/Features/Player/VideoSurface.swift`, `tools/smoke_channels.sh`
- Modify (полная замена): `App/Features/Player/PlayerModel.swift`, `App/Features/Player/PlayerScreen.swift`
- Delete: `App/Features/Player/PlayerContainer.swift`, `App/Features/Player/ProgramInfoView.swift`

**Interfaces:**
- Consumes: `ContentClock` (Task 2), `PlaybackPolicy.action`, `PlayerOverlay`, `PlaybackKind`, `RemoteKey`, `AudioTrack`, `AudioTrackChoice` (Task 3), `StreamURLBuilder.url(for:mode:context:)` (Task 1).
- Produces:
  - `@MainActor protocol PlayerEngine`: `state`, `mediaTime`, `videoSize`, `audioTracks`, `selectedAudioTrackID`, `load(_:)`, `play()`, `pause()`, `seek(to:)`, `selectAudioTrack(id:)`, `stop()`.
  - `@MainActor @Observable final class VLCPlayerEngine: NSObject, PlayerEngine`:
    - `attach(_ view: UIView)`;
    - колбэки `onStateChange: ((PlaybackState) -> Void)?`, `onTracksChanged: (() -> Void)?`, `onStalled: (() -> Void)?`.
  - `PlayerModel`:
    - состояние: `overlay: PlayerOverlay`, `kind: PlaybackKind`, `panelVisible`, `showSchedule`, `showChannelList`, `contentTime`, `behindLive`, `archiveProgress: (position: TimeInterval, duration: TimeInterval)?`, `isPaused`;
    - методы: `handle(_ key: RemoteKey)`, `showPanel()`, `userActivity()`, `togglePause()`, `skip(_:)`, `goLive()`, `startOver()`, `selectAudioTrack(_ track: AudioTrack)`.

- [ ] **Step 1: Протокол движка в AlemCore**

В `Packages/AlemCore/Sources/AlemCore/Playback/PlayerEngine.swift`:
- заменить `import AVFoundation` на `import CoreGraphics`;
- оставить `import Foundation`, `PlaybackFailure` и `PlaybackState`;
- удалить `import Observation` и весь класс `AVPlayerEngine`;
- протокол заменить на:
```swift
@MainActor
public protocol PlayerEngine: AnyObject {
    var state: PlaybackState { get }
    /// Время плеера в секундах (для seek внутри записи; для «реального» времени — ContentClock).
    var mediaTime: TimeInterval { get }
    var videoSize: CGSize { get }
    var audioTracks: [AudioTrack] { get }
    var selectedAudioTrackID: String? { get }
    func load(_ url: URL)
    func play()
    func pause()
    func seek(to seconds: TimeInterval)
    func selectAudioTrack(id: String)
    func stop()
}
```
В `PlaybackTests.swift` удалить тесты `repeatedFailureOfSameItemReportedOnce` и `engineStartsIdle`: движок теперь в приложении. Защита «одна ошибка на загрузку» сохраняется в `VLCPlayerEngine` (флаг `failureReported`). Это отмечается ruling в журнале.

Run: `swift test --package-path Packages/AlemCore`
Expected: всё passed.

- [ ] **Step 2: Подключить VLCKit**

В `project.yml`:
```yaml
packages:
  AlemCore:
    path: Packages/AlemCore
  VLCKit:
    url: https://github.com/videolan/vlckit.git
    exactVersion: 4.0.0-a25
```
и в `targets.AlemTV.dependencies`:
```yaml
      - package: AlemCore
      - package: VLCKit
        product: VLCKit
```
Run: `xcodegen generate && xcodebuild -resolvePackageDependencies -project AlemTV.xcodeproj -scheme AlemTV 2>&1 | tail -3`
Expected: `VLCKit: https://github.com/videolan/vlckit.git @ 4.0.0-a25`. Первая загрузка — около 900 МБ.

- [ ] **Step 3: VLCPlayerEngine и VideoSurface**

`App/Features/Player/VLCPlayerEngine.swift`:
```swift
import AVFoundation
import Foundation
import Observation
import UIKit
import VLCKit
import AlemCore

/// Единственный движок воспроизведения: VLCKit (HEVC/H.264/MPEG-2, AAC/MP2/AC-3 в TS).
@MainActor @Observable
final class VLCPlayerEngine: NSObject, PlayerEngine {
    @ObservationIgnored let player = VLCMediaPlayer()
    private(set) var state: PlaybackState = .idle
    private(set) var audioTracks: [AudioTrack] = []

    @ObservationIgnored var onStateChange: ((PlaybackState) -> Void)?
    @ObservationIgnored var onTracksChanged: (() -> Void)?
    @ObservationIgnored var onStalled: (() -> Void)?

    @ObservationIgnored private var failureReported = false
    @ObservationIgnored private var watchdog = FreezeWatchdog()

    override init() {
        super.init()
        player.delegate = self
        Task { [weak self] in
            while true {
                try? await Task.sleep(for: .seconds(1))
                guard let self else { return }
                self.tick()
            }
        }
    }

    func attach(_ view: UIView) {
        player.drawable = view
    }

    var mediaTime: TimeInterval { TimeInterval(player.time.intValue) / 1000 }
    var videoSize: CGSize { player.videoSize }
    var selectedAudioTrackID: String? { player.audioTracks.first(where: \.isSelected)?.trackId }

    func load(_ url: URL) {
        guard let media = VLCMedia(url: url) else {
            report(.failed("bad url"))
            return
        }
        media.addOptions(["network-caching": 1500, "live-caching": 1500])
        try? AVAudioSession.sharedInstance().setCategory(.playback, mode: .moviePlayback)
        try? AVAudioSession.sharedInstance().setActive(true)
        failureReported = false
        watchdog.reset()
        audioTracks = []
        setState(.loading)            // до смены media: асинхронный stopped старого потока придёт в .loading и будет проигнорирован
        player.media = media
        player.play()
    }

    func play() { player.play() }

    func pause() { player.pause() }

    func seek(to seconds: TimeInterval) {
        watchdog.reset()
        player.time = VLCTime(int: Int32(max(0, seconds) * 1000))
    }

    func selectAudioTrack(id: String) {
        player.audioTracks.first { $0.trackId == id }?.isSelectedExclusively = true
    }

    func stop() {
        setState(.idle)               // stopped после нашей остановки придёт в .idle и будет проигнорирован
        player.stop()
    }

    // MARK: - Внутреннее

    fileprivate func stateChanged(_ vlc: VLCMediaPlayerState) {
        switch vlc {
        case .opening:
            setState(.loading)
        case .playing:
            refreshTracks()
            setState(.playing)
        case .paused:
            setState(.paused)
        case .error:
            report(.failed("VLC error"))
        case .stopped:
            // Обрыв — только если поток играл (или стоял на паузе). Stopped при смене канала
            // (мы уже в .loading) или после stop() (.idle) — ожидаемый, не ошибка. Review Focus 5.
            guard state == .playing || state == .paused else { return }
            // Конец записи архива — `ended`, иначе обрыв — ошибка.
            report(player.position >= 0.98 ? .ended : .failed("stopped"))
        default:
            break
        }
    }

    fileprivate func refreshTracks() {
        let tracks = player.audioTracks.map {
            AudioTrack(id: $0.trackId, name: $0.trackName, language: $0.language)
        }
        if tracks != audioTracks {
            audioTracks = tracks
            onTracksChanged?()
        }
    }

    private func report(_ newState: PlaybackState) {
        if case .failed = newState {
            guard !failureReported else { return }
            failureReported = true
        }
        setState(newState)
    }

    private func setState(_ newState: PlaybackState) {
        guard newState != state else { return }
        state = newState
        onStateChange?(newState)
    }

    private func tick() {
        guard state == .playing || state == .loading else { return }
        if watchdog.observe(position: mediaTime, wantsToPlay: true, likelyToKeepUp: false, now: Date()) {
            onStalled?()
        }
    }
}

extension VLCPlayerEngine: @preconcurrency VLCMediaPlayerDelegate {
    nonisolated func mediaPlayerStateChanged(_ newState: VLCMediaPlayerState) {
        Task { @MainActor [weak self] in self?.stateChanged(newState) }
    }

    nonisolated func mediaPlayerTrackAdded(_ trackId: String, with trackType: VLCMedia.TrackType) {
        Task { @MainActor [weak self] in self?.refreshTracks() }
    }
}
```
Если компилятор не находит `mediaPlayerTrackAdded(_:with:)` с такой Swift-сигнатурой, имя берётся из заголовка `VLCMediaPlayer.h:150` (`mediaPlayerTrackAdded:withType:`). Сверить через `grep -n "mediaPlayerTrackAdded" -A2` в Headers xcframework и записать ruling.

`App/Features/Player/VideoSurface.swift`:
```swift
import SwiftUI
import UIKit

/// Поверхность для видео VLC. Фокус не берёт: пульт обрабатывает PlayerScreen.
struct VideoSurface: UIViewRepresentable {
    let engine: VLCPlayerEngine

    func makeUIView(context: Context) -> UIView {
        let view = UIView()
        view.backgroundColor = .black
        view.isUserInteractionEnabled = false
        engine.attach(view)
        return view
    }

    func updateUIView(_ uiView: UIView, context: Context) {}
}
```

- [ ] **Step 4: PlayerModel на VLCPlayerEngine**

Заменить `App/Features/Player/PlayerModel.swift` целиком:
```swift
import Foundation
import Observation
import os
import AlemCore

@MainActor @Observable
final class PlayerModel {
    enum Mode: Equatable {
        case live
        case timeshift
        case archive(Program)
    }

    let engine = VLCPlayerEngine()
    private(set) var channel: Channel?
    private(set) var playlist: Playlist?
    private(set) var mode: Mode = .live
    private(set) var currentProgram: Program?
    private(set) var errorMessage: String?
    var showChannelList = false
    var showSchedule = false
    var panelVisible = false
    var askContinue = false

    @ObservationIgnored weak var app: AppModel?
    @ObservationIgnored private var session: SessionStore
    @ObservationIgnored private var epg: EPGStore
    @ObservationIgnored private var lastStreamMode: StreamMode = .live
    @ObservationIgnored private var clock = ContentClock(mode: .live, startedAt: Date())
    @ObservationIgnored private var retryCount = 0
    @ObservationIgnored private var pausedAt: Date?
    @ObservationIgnored private var idle = IdleMonitor(timeout: 18_000)
    @ObservationIgnored private var panelIdle = IdleMonitor(timeout: 5)
    @ObservationIgnored private var loadTask: Task<Void, Never>?
    @ObservationIgnored private let log = Logger(subsystem: "com.alexvamp.alemtv", category: "player")

    private static let audioLanguageKey = "audio.language"

    init(session: SessionStore, epg: EPGStore) {
        self.session = session
        self.epg = epg
        engine.onStateChange = { [weak self] in self?.engineStateChanged($0) }
        engine.onTracksChanged = { [weak self] in self?.applyPreferredAudio() }
        engine.onStalled = { [weak self] in
            self?.log.notice("stream frozen, restarting")
            self?.reload()
        }
        startTicker()
    }

    func configure(session: SessionStore, epg: EPGStore) {
        self.session = session
        self.epg = epg
    }

    func setIdleTimeout(_ timeout: TimeInterval) {
        idle = IdleMonitor(timeout: timeout)
    }

    // MARK: - Состояние

    private var now: Date { app?.clock.now() ?? Date() }

    var overlay: PlayerOverlay {
        if errorMessage != nil { return .error }
        if showChannelList { return .channelList }
        if showSchedule { return .schedule }
        if panelVisible { return .panel }
        return .none
    }

    var kind: PlaybackKind {
        switch mode {
        case .live: return .live
        case .timeshift: return .timeshift
        case .archive: return .archive
        }
    }

    var contentTime: Date { clock.contentTime(at: now) }

    var behindLive: TimeInterval? {
        guard mode == .timeshift else { return nil }
        return clock.behindLive(at: now)
    }

    /// Позиция и длительность записи (шкала архива).
    var archiveProgress: (position: TimeInterval, duration: TimeInterval)? {
        guard case .archive(let program) = mode else { return nil }
        let start = StreamURLBuilder.floorMinute(program.start)
        return (max(0, contentTime.timeIntervalSince(start)), StreamURLBuilder.floorMinute(program.stop).timeIntervalSince(start))
    }

    var isArchive: Bool { kind == .archive }
    var isPaused: Bool { engine.state == .paused }

    var canTimeshift: Bool {
        channel?.hasArchive == true && app?.authorization?.timeshiftEnabled == true
    }

    var canStartOver: Bool { canTimeshift && currentProgram != nil }

    // MARK: - Запуск

    func playInitial() {
        guard let a = app?.authorization else { return }
        let all = a.playlists.first { $0.name == "tv" } ?? app?.categoryPlaylists.first
        #if DEBUG
        if playDebugChannel(a, playlist: all) { return }
        #endif
        let channel = a.lastMediaID.flatMap(a.channel(id:))
            ?? all.flatMap { a.channels(in: $0).first }
            ?? a.channels.first
        if let channel { play(channel, in: all) }
    }

    func play(_ channel: Channel, in playlist: Playlist?) {
        self.channel = channel
        if let playlist { self.playlist = playlist }
        mode = .live
        pausedAt = nil
        retryCount = 0
        app?.rememberLastChannel(channel)
        load(.live)
    }

    func play(_ program: Program, on channel: Channel) {
        self.channel = channel
        start(program, position: 0)
    }

    /// Каталог перезагружен (например, сменилась подписка): если текущий канал или рубрика
    /// пропали — переключиться на доступные; иначе обновить данные канала и продолжить.
    func catalogChanged() {
        guard let a = app?.authorization, let current = channel else { return }
        let resolved = a.resolve(channelID: current.id, playlistID: playlist?.id)
        playlist = resolved.playlist
        guard let next = resolved.channel else {
            log.notice("no channels left after catalog change")
            stop()
            return
        }
        if next.id != current.id {
            log.notice("channel no longer available, switching")
            play(next, in: resolved.playlist)
        } else {
            channel = next
        }
    }

    func switchChannel(by delta: Int) {
        guard let a = app?.authorization, let channel else { return }
        let list = playlist.map { a.channels(in: $0) } ?? a.channels
        guard !list.isEmpty else { return }
        let index = list.firstIndex { $0.id == channel.id } ?? 0
        play(list[(index + delta % list.count + list.count) % list.count], in: playlist)
    }

    func goLive() {
        mode = .live
        pausedAt = nil
        retryCount = 0
        load(.live)
    }

    /// ±секунды: в архиве — seek внутри записи, в эфире/таймшифте — новый URL.
    func skip(_ seconds: TimeInterval) {
        if isArchive {
            let target = max(0, clock.playedTime(at: now) + seconds)
            engine.seek(to: target)
            clock.didSeek(toPosition: target, at: now)
            return
        }
        guard canTimeshift, let channel else { return }
        switch PlaybackPolicy.skip(by: seconds, contentTime: contentTime, now: now, archiveDepth: channel.timeshiftArchiveLength) {
        case .live:
            goLive()
        case let target:
            mode = .timeshift
            load(target)
        }
    }

    func startOver() {
        guard canStartOver, let program = currentProgram, let channel else { return }
        play(program, on: channel)
    }

    func togglePause() {
        switch engine.state {
        case .playing, .loading:
            if !isArchive { pausedAt = contentTime }
            engine.pause()
        case .paused:
            resumeFromPause()
        default:
            break
        }
    }

    func selectAudioTrack(_ track: AudioTrack) {
        engine.selectAudioTrack(id: track.id)
        if let language = track.language { UserDefaults.standard.set(language, forKey: Self.audioLanguageKey) }
    }

    func retry() {
        retryCount = 0
        reload()
    }

    func reloadCurrent() {
        guard channel != nil else { return }
        reload()
    }

    func stop() {
        loadTask?.cancel()
        engine.stop()
        channel = nil
        currentProgram = nil
        errorMessage = nil
        panelVisible = false
        showSchedule = false
    }

    // MARK: - Пульт

    func handle(_ key: RemoteKey) {
        userActivity()
        switch PlaybackPolicy.action(for: key, overlay: overlay, kind: kind) {
        case .previousChannel: switchChannel(by: -1)
        case .nextChannel: switchChannel(by: 1)
        case .showChannelList: showChannelList = true
        case .showPanel: showPanel()
        case .hidePanel: panelVisible = false
        case .togglePause: togglePause()
        case .skip(let seconds): skip(seconds)
        case .openGuide: app?.showGuide = true
        case .ignore: break
        }
    }

    func showPanel() {
        panelVisible = true
        panelIdle.touch()
    }

    func userActivity() {
        idle.touch()
        panelIdle.touch()
    }

    /// Возврат из фона: эфир продолжаем с live-edge, запись — с места.
    func resumeAfterBackground() {
        guard channel != nil, errorMessage == nil else { return }
        pausedAt = nil
        switch PlaybackPolicy.resumeAfterBackground(isLive: mode == .live) {
        case .reloadLive: goLive()
        case .play: engine.play()
        }
    }

    func continueAfterIdle() {
        askContinue = false
        idle.touch()
        if mode == .live { goLive() } else { engine.play() }
    }

    // MARK: - Внутреннее

    private func engineStateChanged(_ state: PlaybackState) {
        switch state {
        case .playing:
            clock.didStartPlaying(at: now)
            retryCount = 0
            errorMessage = nil
            logPlaying()
        case .failed(let message):
            clock.didStopPlaying(at: now)
            log.error("playback failed: \(message, privacy: .public)")
            handleFailure()
        case .ended:
            clock.didStopPlaying(at: now)
            playNextProgram()
        case .idle, .loading, .paused:
            clock.didStopPlaying(at: now)
        }
    }

    private func logPlaying() {
        Task { [weak self] in
            try? await Task.sleep(for: .seconds(5))
            guard let self else { return }
            let size = self.engine.videoSize
            self.log.info("playing \(Int(size.width))x\(Int(size.height)) audio=\(self.engine.audioTracks.count)")
        }
    }

    private func applyPreferredAudio() {
        let language = UserDefaults.standard.string(forKey: Self.audioLanguageKey)
        if let track = AudioTrackChoice.preferred(engine.audioTracks, language: language),
           track.id != engine.selectedAudioTrackID {
            engine.selectAudioTrack(id: track.id)
        }
    }

    private func resumeFromPause() {
        defer { pausedAt = nil }
        if let pausedAt, !isArchive, canTimeshift {
            let behind = now.timeIntervalSince(pausedAt)
            if behind > PlaybackPolicy.liveSnap {
                log.info("resume after pause, \(Int(behind)) s behind live")
                mode = .timeshift
                load(.timeshift(behind: behind))
                return
            }
        }
        engine.play()
    }

    private func start(_ program: Program, position: TimeInterval) {
        let streamMode = StreamURLBuilder.mode(for: program, position: position, now: now)
        switch streamMode {
        case .live: mode = .live
        case .timeshift: mode = .timeshift
        case .archive: mode = .archive(program)
        }
        pausedAt = nil
        retryCount = 0
        load(streamMode)
    }

    private func load(_ streamMode: StreamMode) {
        guard let channel else { return }
        lastStreamMode = streamMode
        errorMessage = nil
        clock = ContentClock(mode: streamMode, startedAt: now)
        let reference = PlaybackPolicy.referenceTime(for: streamMode, now: now)
        Task { await refreshProgram(at: reference) }
        loadTask?.cancel()
        loadTask = Task { [weak self] in
            guard let self, let context = await self.session.streamContext(), !Task.isCancelled else { return }
            do {
                let url = try StreamURLBuilder.url(for: channel, mode: streamMode, context: context)
                self.log.info("load \(url.host ?? "", privacy: .public)\(url.path, privacy: .public)")
                self.engine.load(url)
            } catch {
                self.showError()
            }
        }
    }

    private func reload() {
        switch mode {
        case .live:
            load(.live)
        case .timeshift:
            load(.timeshift(behind: max(0, now.timeIntervalSince(contentTime))))
        case .archive(let program):
            let position = contentTime.timeIntervalSince(StreamURLBuilder.floorMinute(program.start))
            start(program, position: max(0, position))
        }
    }

    /// 1-я ошибка — новый URL; 2-я — повторный вход (он же перечитает каталог) и новый URL; дальше — сообщение.
    private func handleFailure() {
        retryCount += 1
        switch retryCount {
        case 1:
            reload()
        case 2:
            Task { [weak self] in
                try? await self?.app?.reauthorize()
                self?.reload()
            }
        default:
            engine.stop()
            showError()
        }
    }

    private func showError() {
        errorMessage = app?.strings(isArchive ? "player.recordingUnavailable" : "player.unavailable")
    }

    private func playNextProgram() {
        guard case .archive(let finished) = mode, let channel else { return }
        Task { [weak self] in
            guard let self else { return }
            let language = self.app?.authorization?.language?.id
            var list = (try? await self.epg.programs(mediaID: channel.id, day: PortalDate.dayString(finished.start), languageID: language)) ?? []
            if !list.contains(where: { $0.start >= finished.stop }) {
                list += (try? await self.epg.programs(mediaID: channel.id, day: PortalDate.dayString(finished.stop.addingTimeInterval(60)), languageID: language)) ?? []
            }
            if let next = list.first(where: { $0.start >= finished.stop }) {
                self.start(next, position: 0)
            } else {
                self.goLive()
            }
        }
    }

    /// `at` — время показываемого кадра; сразу после запуска потока передаётся явно.
    func refreshProgram(at time: Date? = nil) async {
        guard let channel else {
            currentProgram = nil
            return
        }
        let at = time ?? contentTime
        let list = (try? await epg.programs(mediaID: channel.id, day: PortalDate.dayString(at),
                                            languageID: app?.authorization?.language?.id)) ?? []
        currentProgram = list.first { $0.isOnAir(at: at) }
    }

    private func startTicker() {
        Task { [weak self] in
            var tick = 0
            while true {
                try? await Task.sleep(for: .seconds(1))
                guard let self else { return }
                tick += 1
                if self.panelVisible, self.panelIdle.isExpired() { self.panelVisible = false }
                guard tick % 30 == 0 else { continue }
                await self.refreshProgram()
                if self.engine.state == .playing, self.idle.isExpired() {
                    self.engine.pause()
                    self.askContinue = true
                }
            }
        }
    }

    #if DEBUG
    /// Отладка: `-debugChannelID <id> [-debugMode live|archive|timeshift]` (смоук-скрипт).
    private func playDebugChannel(_ a: AuthorizeResult, playlist: Playlist?) -> Bool {
        guard let raw = UserDefaults.standard.string(forKey: "debugChannelID"), let id = Int(raw),
              let channel = a.channel(id: id) else { return false }
        self.channel = channel
        self.playlist = playlist
        switch UserDefaults.standard.string(forKey: "debugMode") {
        case "archive":
            let start = StreamURLBuilder.floorMinute(now.addingTimeInterval(-7_200))
            mode = .archive(Program(mediaID: id, start: start, stop: start.addingTimeInterval(600), title: "debug"))
            load(.archive(start: start, duration: 600))
        case "timeshift":
            mode = .timeshift
            load(.timeshift(behind: 600))
        default:
            play(channel, in: playlist)
        }
        return true
    }
    #endif
}
```

- [ ] **Step 5: PlayerScreen без AVPlayerViewController**

Удалить: `git rm App/Features/Player/PlayerContainer.swift App/Features/Player/ProgramInfoView.swift`.

Заменить `App/Features/Player/PlayerScreen.swift` целиком:
```swift
import SwiftUI
import AlemCore

struct PlayerScreen: View {
    @Environment(AppModel.self) private var app

    var body: some View {
        @Bindable var player = app.player
        ZStack(alignment: .topTrailing) {
            VideoSurface(engine: player.engine)
                .ignoresSafeArea()
            if player.overlay == .none {
                RemoteCatcher()
            }
            if player.mode == .timeshift && !player.panelVisible {
                TimeshiftBadge().padding(60)
            }
            if player.panelVisible && player.overlay == .panel {
                TransportOverlay()
            }
            if player.showSchedule {
                ScheduleOverlay()
            }
            if let message = player.errorMessage {
                ErrorOverlay(message: message)
            }
            if player.showChannelList {
                ChannelListOverlay()
                    .transition(.move(edge: .leading))
            }
        }
        .background(Color.black)
        .animation(.easeOut(duration: 0.2), value: player.showChannelList)
        .animation(.easeOut(duration: 0.2), value: player.panelVisible)
        .onMoveCommand { direction in
            if let key = RemoteKey(direction) { player.handle(key) }
        }
        .onPlayPauseCommand { player.handle(.playPause) }
        .onExitCommand { player.handle(.menu) }
        .alert(app.strings("player.continue.title"), isPresented: $player.askContinue) {
            Button(app.strings("player.continue")) { player.continueAfterIdle() }
        }
    }
}

extension RemoteKey {
    init?(_ direction: MoveCommandDirection) {
        switch direction {
        case .up: self = .up
        case .down: self = .down
        case .left: self = .left
        case .right: self = .right
        @unknown default: return nil
        }
    }
}

/// Единственный фокусируемый элемент в режиме просмотра: Select показывает панель,
/// стрелки уходят в onMoveCommand экрана.
private struct RemoteCatcher: View {
    @Environment(AppModel.self) private var app
    @FocusState private var focused: Bool

    var body: some View {
        Button { app.player.handle(.select) } label: {
            Color.clear.frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .buttonStyle(.plain)
        .focused($focused)
        .onAppear { focused = true }
    }
}

private struct TimeshiftBadge: View {
    @Environment(AppModel.self) private var app

    var body: some View {
        TimelineView(.periodic(from: .now, by: 1)) { _ in
            if let behind = app.player.behindLive {
                Text(app.strings("player.behindLive", "−" + Duration.seconds(Int(behind)).formatted(.time(pattern: .hourMinuteSecond))))
                    .font(.headline.monospacedDigit())
                    .padding(.horizontal, 24)
                    .padding(.vertical, 12)
                    .background(.ultraThinMaterial, in: Capsule())
            }
        }
    }
}

private struct ErrorOverlay: View {
    @Environment(AppModel.self) private var app
    let message: String

    var body: some View {
        VStack(spacing: 30) {
            Image(systemName: "exclamationmark.tv").font(.system(size: 80)).foregroundStyle(Brand.accent)
            Text(message).font(.title2)
            HStack(spacing: 40) {
                Button(app.strings("error.retry")) { app.player.retry() }
                Button(app.strings("guide.channels")) { app.showGuide = true }
            }
        }
        .padding(60)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 30))
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .focusSection()
    }
}
```
`TransportOverlay` и `ScheduleOverlay` появятся в Task 5. В этом коммите — временные заглушки в конце `PlayerScreen.swift`:
```swift
// Временно: заменяются в Task 5.
struct TransportOverlay: View { var body: some View { EmptyView() } }
struct ScheduleOverlay: View { var body: some View { EmptyView() } }
```

В `App/AppModel.swift` поиск `player.reloadCurrent()`, `player.resumeAfterBackground()`, `player.catalogChanged()` и `player.setIdleTimeout` должен найти существующие методы. Ничего не менять.

- [ ] **Step 6: Сборка**

Run: `xcodegen generate && xcodebuild -project AlemTV.xcodeproj -scheme AlemTV -destination 'generic/platform=tvOS Simulator' build 2>&1 | grep -E "error:|BUILD" | sort -u`
Expected: `** BUILD SUCCEEDED **`.

- [ ] **Step 7: Смоук-скрипт**

`tools/smoke_channels.sh`:
```bash
#!/bin/bash
# Смоук-проверка движка в симуляторе: каждый тип канала должен заиграть (кадр > 0) за 15 с.
# Терминал уже должен быть в Keychain симулятора; первый запуск: SEED_MAC=<mac> tools/smoke_channels.sh
set -u
DEVICE="${DEVICE:-Apple TV 4K (3rd generation)}"
APP=$(find ~/Library/Developer/Xcode/DerivedData -path "*Debug-appletvsimulator/AlemTV.app" -maxdepth 6 -type d | head -1)
xcrun simctl boot "$DEVICE" 2>/dev/null
xcrun simctl bootstatus "$DEVICE" -b >/dev/null
xcrun simctl install "$DEVICE" "$APP"
fail=0
while read -r name id mode; do
  xcrun simctl terminate "$DEVICE" com.alexvamp.alemtv 2>/dev/null
  xcrun simctl launch "$DEVICE" com.alexvamp.alemtv -debugChannelID "$id" -debugMode "$mode" ${SEED_MAC:+-seedMAC "$SEED_MAC"} >/dev/null
  sleep 15
  line=$(xcrun simctl spawn "$DEVICE" log show --last 15s --info \
    --predicate 'subsystem == "com.alexvamp.alemtv" AND category == "player"' --style compact 2>/dev/null \
    | grep -o 'playing [0-9]*x[0-9]* audio=[0-9]*' | tail -1)
  if [[ "$line" =~ playing\ [1-9][0-9]*x[1-9] ]]; then
    echo "OK   $name ($mode): $line"
  else
    echo "FAIL $name ($mode): ${line:-нет воспроизведения}"
    fail=1
  fi
done <<'EOF'
HEVC+AAC 1 live
H.264+AAC 11 live
H.264+MP2 116 live
HEVC+MP2 10 live
MPEG-2+MP2 41 live
HEVC+AAC 1 archive
HEVC+AAC 1 timeshift
EOF
xcrun simctl terminate "$DEVICE" com.alexvamp.alemtv 2>/dev/null
exit $fail
```
Run: `chmod +x tools/smoke_channels.sh && SEED_MAC=$(python3 -c "import json;print(json.load(open('reference/samples/.terminal.json'))['macaddr'])") tools/smoke_channels.sh`
Expected: 7 строк `OK`. У H.264+MP2 (Т24, id 116) `audio=2`.

Переключение канала без ложной ошибки (Review Focus 5): запустить `xcrun simctl launch "Apple TV 4K (3rd generation)" com.alexvamp.alemtv -debugChannelID 1`, через 12 с нажать ↓ (`osascript -e 'tell application "Simulator" to activate' -e 'tell application "System Events" to key code 125'`), через 10 с проверить лог.
Expected: `load …/Yashlyk/video.m3u8`, затем `playing 1920x1080`, и ни одного `playback failed`.

- [ ] **Step 8: Commit**

```bash
git add -A project.yml App Packages tools/smoke_channels.sh
git commit -m "Единый движок VLCKit: все каналы в TS, свой экран плеера, смоук-скрипт

Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>
Claude-Session: https://claude.ai/code/session_015tkg9WmfzBtZ6B6QQFpCUA"
```

---

### Task 5: Панель плеера и программа передач поверх видео

**Files:**
- Create: `App/Features/Player/TransportOverlay.swift`, `App/Features/Player/ScheduleOverlay.swift`
- Modify: `App/Features/Player/PlayerScreen.swift` (удалить заглушки)
- Modify: `tools/gen_strings.py` (+ перегенерировать `App/Resources/Localizable.xcstrings`)

**Interfaces:**
- Consumes (из `PlayerModel`, Task 4):
  - состояние: `channel`, `currentProgram`, `mode`, `kind`, `archiveProgress`, `behindLive`, `contentTime`, `isPaused`, `canTimeshift`, `canStartOver`, `engine.audioTracks`, `engine.selectedAudioTrackID`;
  - методы: `skip(_:)`, `togglePause()`, `goLive()`, `startOver()`, `selectAudioTrack(_:)`, `userActivity()`, `play(_:on:)`;
  - флаги: `panelVisible`, `showSchedule`.
- Consumes (из AppModel): `strings`, `logoURL(for:)` через `ChannelLogo`, `epg`, `authorization`, `clock`.
- Produces: `TransportOverlay`, `ScheduleOverlay` (без параметров, читают `AppModel` из окружения).

- [ ] **Step 1: Строки**

В `tools/gen_strings.py`, в словарь `STRINGS`, добавить:
```python
    "player.audio": ("Звук", "Audio", "Ses"),  # tk?
    "player.live": ("Эфир", "Live", "Efir"),  # tk?
    "player.pause": ("Пауза", "Pause", "Pauza"),
    "player.play": ("Смотреть", "Play", "Görmek"),  # tk?
    "settings.engine": ("Воспроизведение: VLCKit (LGPL 2.1)", "Playback: VLCKit (LGPL 2.1)", "Görkezmek: VLCKit (LGPL 2.1)"),  # tk?
```
Run: `python3 tools/gen_strings.py`
Expected: `46 keys -> …`.

- [ ] **Step 2: TransportOverlay**

`App/Features/Player/TransportOverlay.swift`:
```swift
import SwiftUI
import AlemCore

/// Панель плеера: канал и передача, шкала, кнопки. Фокус — между кнопками; Menu закрывает (PlaybackPolicy).
struct TransportOverlay: View {
    @Environment(AppModel.self) private var app
    @FocusState private var focus: Control?
    @State private var chooseAudio = false

    enum Control: Hashable {
        case back, playPause, forward, live, startOver, audio, schedule
    }

    var body: some View {
        let player = app.player
        let s = app.strings
        VStack(spacing: 0) {
            header
            Spacer()
            VStack(alignment: .leading, spacing: 28) {
                TimelineView(.periodic(from: .now, by: 1)) { _ in progress }
                HStack(spacing: 30) {
                    if player.canTimeshift || player.isArchive {
                        iconButton("gobackward.10", s("player.back10"), .back) { player.skip(-PlaybackPolicy.skipStep) }
                    }
                    iconButton(player.isPaused ? "play.fill" : "pause.fill",
                               player.isPaused ? s("player.play") : s("player.pause"), .playPause) { player.togglePause() }
                    if player.kind != .live {
                        iconButton("goforward.10", s("player.forward10"), .forward) { player.skip(PlaybackPolicy.skipStep) }
                        textButton(s("player.goLive"), .live) { player.goLive() }
                    }
                    if player.canStartOver {
                        textButton(s("player.startOver"), .startOver) { player.startOver() }
                    }
                    if player.engine.audioTracks.count > 1 {
                        textButton(s("player.audio"), .audio) { chooseAudio = true }
                    }
                    textButton(s("player.info"), .schedule) {
                        player.panelVisible = false
                        player.showSchedule = true
                    }
                }
                .focusSection()
            }
            .padding(60)
            .background(LinearGradient(colors: [.clear, .black.opacity(0.85)], startPoint: .top, endPoint: .bottom))
        }
        .onAppear { focus = .playPause }
        .onChange(of: focus) { _, _ in player.userActivity() }
        .confirmationDialog(s("player.audio"), isPresented: $chooseAudio) {
            ForEach(player.engine.audioTracks) { track in
                Button(track.name + (track.id == player.engine.selectedAudioTrackID ? " ✓" : "")) {
                    player.selectAudioTrack(track)
                }
            }
            Button(s("common.cancel"), role: .cancel) {}
        }
    }

    private var header: some View {
        let player = app.player
        return HStack(spacing: 24) {
            if let channel = player.channel {
                ChannelLogo(channel: channel).frame(width: 120, height: 68)
                VStack(alignment: .leading, spacing: 6) {
                    Text("\(channel.index). \(channel.name)").font(.headline).foregroundStyle(Brand.accent)
                    if let program = player.currentProgram {
                        Text(program.title).font(.title3).lineLimit(1)
                        Text("\(program.start.formatted(timeStyle)) – \(program.stop.formatted(timeStyle))")
                            .foregroundStyle(.secondary)
                    } else {
                        Text(app.strings("epg.empty")).foregroundStyle(.secondary)
                    }
                }
            }
            Spacer()
        }
        .padding(60)
        .background(LinearGradient(colors: [.black.opacity(0.85), .clear], startPoint: .top, endPoint: .bottom))
    }

    @ViewBuilder private var progress: some View {
        let player = app.player
        if let archive = player.archiveProgress {
            ProgressView(value: min(archive.position, archive.duration), total: max(archive.duration, 1))
                .tint(Brand.accent)
            HStack {
                Text(Duration.seconds(Int(archive.position)).formatted(.time(pattern: .hourMinuteSecond)))
                Spacer()
                Text(Duration.seconds(Int(archive.duration)).formatted(.time(pattern: .hourMinuteSecond)))
            }
            .font(.caption.monospacedDigit())
            .foregroundStyle(.secondary)
        } else {
            if let program = player.currentProgram {
                ProgressView(value: program.progress(at: player.contentTime)).tint(Brand.accent)
            }
            HStack {
                Spacer()
                if let behind = player.behindLive {
                    Text(app.strings("player.behindLive", "−" + Duration.seconds(Int(behind)).formatted(.time(pattern: .hourMinuteSecond))))
                } else {
                    Label(app.strings("player.live"), systemImage: "dot.radiowaves.left.and.right")
                        .foregroundStyle(Brand.accent)
                }
            }
            .font(.caption.monospacedDigit())
        }
    }

    private var timeStyle: Date.FormatStyle {
        var style = Date.FormatStyle(date: .omitted, time: .shortened).locale(app.strings.locale)
        style.timeZone = PortalDate.serverTimeZone
        return style
    }

    private func iconButton(_ symbol: String, _ label: String, _ control: Control, action: @escaping () -> Void) -> some View {
        Button(action: action) { Image(systemName: symbol).font(.title2) }
            .accessibilityLabel(label)
            .focused($focus, equals: control)
    }

    private func textButton(_ title: String, _ control: Control, action: @escaping () -> Void) -> some View {
        Button(title, action: action).focused($focus, equals: control)
    }
}
```

- [ ] **Step 3: ScheduleOverlay**

`App/Features/Player/ScheduleOverlay.swift`:
```swift
import SwiftUI
import AlemCore

/// Программа текущего канала на день показываемого кадра, поверх видео справа.
struct ScheduleOverlay: View {
    @Environment(AppModel.self) private var app
    @State private var programs: [Program] = []

    var body: some View {
        let player = app.player
        let now = app.clock.now()
        HStack {
            Spacer()
            ScrollViewReader { proxy in
                List(programs) { program in
                    Button { select(program, now: now) } label: {
                        HStack(spacing: 20) {
                            Text(program.start.formatted(timeStyle)).monospacedDigit().frame(width: 100, alignment: .leading)
                            Text(program.title).lineLimit(1)
                            Spacer()
                            if program.isOnAir(at: player.contentTime) {
                                Image(systemName: "play.fill").foregroundStyle(Brand.accent)
                            }
                        }
                    }
                    .disabled(!playable(program, now: now))
                    .id(program.id)
                }
                .overlay {
                    if programs.isEmpty { Text(app.strings("epg.empty")).foregroundStyle(.secondary) }
                }
                .onChange(of: programs) { _, list in
                    if let current = list.first(where: { $0.isOnAir(at: player.contentTime) }) {
                        proxy.scrollTo(current.id, anchor: .center)
                    }
                }
            }
            .frame(width: 900)
            .background(.ultraThinMaterial)
        }
        .onExitCommand { player.showSchedule = false }
        .task(id: player.channel?.id) {
            guard let channel = player.channel else { return }
            programs = (try? await app.epg.programs(mediaID: channel.id, day: PortalDate.dayString(player.contentTime),
                                                     languageID: app.authorization?.language?.id)) ?? []
        }
    }

    private var timeStyle: Date.FormatStyle {
        var style = Date.FormatStyle(date: .omitted, time: .shortened).locale(app.strings.locale)
        style.timeZone = PortalDate.serverTimeZone
        return style
    }

    private func playable(_ program: Program, now: Date) -> Bool {
        guard let channel = app.player.channel else { return false }
        return program.isOnAir(at: now) || StreamURLBuilder.isAvailableInArchive(
            program, channel: channel, timeshiftEnabled: app.authorization?.timeshiftEnabled ?? false, now: now)
    }

    private func select(_ program: Program, now: Date) {
        let player = app.player
        player.showSchedule = false
        if program.isOnAir(at: now) {
            player.goLive()
        } else if let channel = player.channel {
            player.play(program, on: channel)
        }
    }
}
```

Удалить из `PlayerScreen.swift` три строки заглушек (`// Временно: заменяются в Task 5.` и два `struct … EmptyView()`).

- [ ] **Step 4: Сборка и ручная проверка**

Run: `xcodegen generate && xcodebuild -project AlemTV.xcodeproj -scheme AlemTV -destination 'generic/platform=tvOS Simulator' build 2>&1 | grep -E "error:|BUILD" | sort -u`
Expected: `** BUILD SUCCEEDED **`.

Запустить `-debugChannelID 116` (Т24, две дорожки). Нажать Return (Select): должна появиться панель. Снять скриншот (`xcrun simctl io … screenshot`).
Expected:
- сверху логотип, «Т24» и передача;
- снизу шкала, кнопки ⏸, «Звук», «Программа»;
- через 5 с без нажатий панель скрывается.

Если Return в симуляторе не равен Select, вызвать панель через временный DEBUG-аргумент `-debugShowPanel`: в `playDebugChannel` добавить `panelVisible = UserDefaults.standard.bool(forKey: "debugShowPanel")` и записать ruling.

Run: `tools/smoke_channels.sh`
Expected: 7 `OK`.

- [ ] **Step 5: Commit**

```bash
git add App tools/gen_strings.py
git commit -m "Своя панель плеера: шкала, ±10 с, эфир, с начала, выбор звука, программа поверх видео

Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>
Claude-Session: https://claude.ai/code/session_015tkg9WmfzBtZ6B6QQFpCUA"
```

---

### Task 6: Частота кадров экрана, лицензия VLCKit, чек-лист

**Files:**
- Create: `App/Features/Player/DisplayCriteria.swift`
- Modify: `App/Features/Player/VLCPlayerEngine.swift` (применение и сброс критериев)
- Modify: `App/Features/Settings/SettingsView.swift` (строка про VLCKit)
- Modify: `docs/manual-test-checklist.md`

**Interfaces:**
- Consumes: `VLCPlayerEngine` (Task 4), строка `settings.engine` (Task 5).
- Produces: `@MainActor enum DisplayCriteria { static func apply(window: UIWindow?, frameRate: Float, size: CGSize); static func reset(window: UIWindow?) }`.

- [ ] **Step 1: DisplayCriteria**

`App/Features/Player/DisplayCriteria.swift`:
```swift
import AVFoundation
import AVKit
import CoreMedia
import UIKit

/// Согласование частоты кадров экрана с контентом (системный плеер делает это сам; VLC — нет).
@MainActor
enum DisplayCriteria {
    static func apply(window: UIWindow?, frameRate: Float, size: CGSize) {
        guard let manager = window?.avDisplayManager, manager.isDisplayCriteriaMatchingEnabled,
              size.width > 0, size.height > 0 else { return }
        var description: CMVideoFormatDescription?
        CMVideoFormatDescriptionCreate(allocator: nil, codecType: kCMVideoCodecType_H264,
                                       width: Int32(size.width), height: Int32(size.height),
                                       extensions: nil, formatDescriptionOut: &description)
        guard let description else { return }
        manager.preferredDisplayCriteria = AVDisplayCriteria(refreshRate: frameRate, formatDescription: description)
    }

    static func reset(window: UIWindow?) {
        window?.avDisplayManager.preferredDisplayCriteria = nil
    }
}
```

В `VLCPlayerEngine.swift`:
- добавить свойство `@ObservationIgnored private var criteriaApplied = false`;
- в `load(_:)` перед `player.play()` добавить `criteriaApplied = false`;
- в `stateChanged(_:)` в ветке `.playing` после `refreshTracks()` добавить вызов `applyDisplayCriteria()`;
- в `stop()` перед `setState(.idle)` добавить `DisplayCriteria.reset(window: (player.drawable as? UIView)?.window)`;
- добавить метод:
```swift
    private func applyDisplayCriteria() {
        guard !criteriaApplied, player.videoSize.width > 0 else { return }
        criteriaApplied = true
        var rate: Float = 25
        if let video = player.videoTracks.first?.video, video.frameRate > 0 {
            rate = Float(video.frameRate) / Float(max(1, video.frameRateDenominator))
        }
        DisplayCriteria.apply(window: (player.drawable as? UIView)?.window, frameRate: rate, size: player.videoSize)
    }
```

- [ ] **Step 2: Лицензия в настройках**

В `App/Features/Settings/SettingsView.swift`, в секции `Section(s("settings.about"))` после строки `LabeledContent(s("settings.terminal"), …)` добавить:
```swift
                    Text(s("settings.engine")).font(.caption).foregroundStyle(.secondary)
```

- [ ] **Step 3: Чек-лист**

В `docs/manual-test-checklist.md`:
- раздел «Каналы со звуком MP2 ⚠» заменить на:
```markdown
## Единый движок (VLCKit) ⚠
- [ ] 20–30 разных каналов из всех рубрик, включая Первый, Россия 24, НТВ, ТНТ, СТС, Т24, 5 Канал: картинка и звук.
- [ ] Т24: «Звук» → kaz → звук переключился; следующий канал с двумя дорожками стартует с kaz.
- [ ] Час просмотра HEVC 1080p (Altyn Asyr): без рывков, приставка не перегревается, звук не уходит из синхрона.
- [ ] Частота кадров: при «Согласовании частоты кадров» в настройках tvOS экран переключается на 25 Гц, без рывков на движении.
```
- в разделе «Архив и таймшифт ⚠» строку про транспортную панель заменить на:
```markdown
- [ ] Select → панель; «−10 с»/«+10 с»/«В эфир»/«С начала»/«Программа» работают; через 5 с без нажатий панель скрывается; Menu закрывает панель.
- [ ] В архиве ←/→ перематывают на 10 с, ↑/↓ ничего не делают; в эфире → ничего не делает, ← открывает список.
```

- [ ] **Step 4: Сборка, тесты, смоук**

Run: `swift test --package-path Packages/AlemCore 2>&1 | tail -1`
Expected: всё passed.

Run: `xcodegen generate && xcodebuild -project AlemTV.xcodeproj -scheme AlemTV -destination 'generic/platform=tvOS Simulator' build 2>&1 | grep -E "error:|BUILD" | sort -u`
Expected: `** BUILD SUCCEEDED **`.

Run: `tools/smoke_channels.sh`
Expected: 7 `OK`.

Run: `ALEMTV_LIVE=1 swift test --package-path Packages/AlemCore --filter LiveIntegrationTests 2>&1 | tail -1`
Expected: 3 теста passed.

- [ ] **Step 5: Commit**

```bash
git add App docs/manual-test-checklist.md
git commit -m "Частота кадров экрана под контент, лицензия VLCKit в «О приложении», чек-лист

Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>
Claude-Session: https://claude.ai/code/session_015tkg9WmfzBtZ6B6QQFpCUA"
```

---

## Покрытие спецификации

| Раздел spec | Задачи |
|---|---|
| §2 VLCKit только в приложении, TS, удаление fMP4/AVPlayer | 1, 4 |
| §3.1 протокол PlayerEngine | 4 |
| §3.2 ContentClock | 2, 4 |
| §3.3 VLCPlayerEngine (опции, состояния, одна ошибка, аудиосессия) | 4 |
| §3.4 частота кадров | 6 |
| §4 пульт и панель, звуковые дорожки, программа | 3, 4, 5 |
| §5 ошибки | 4 (без изменений по сути) |
| §6 тесты: юнит, смоук, живой, чек-лист | 1, 2, 3, 4, 6 |
| §7 риски: LGPL | 6 |

Отличие от spec §3: файл `OverlayTimer.swift` не создаётся. Автоскрытие панели сделано на существующем `IdleMonitor(timeout: 5)` (YAGNI, тот же тип уже покрыт тестами).
