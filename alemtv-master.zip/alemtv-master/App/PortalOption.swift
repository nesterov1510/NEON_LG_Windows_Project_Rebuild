import Foundation

/// Порталы оператора (Controller.setMultiPortalDefault в Android-клиенте).
struct PortalOption: Hashable, Identifiable {
    let name: String
    let host: String

    var id: String { host }
    var baseURL: URL { URL(string: "http://\(host)")! }

    func logoURL(channelID: Int) -> URL {
        baseURL.appendingPathComponent("resources/portal/images/logo96/\(channelID).png")
    }

    static let all = [
        PortalOption(name: "Turkmentelekom", host: "telecom.alemtv.tm"),
        PortalOption(name: "ASTU", host: "astu.tmalem.tv"),
        PortalOption(name: "Arkadag", host: "ark.alemtv.tm"),
        PortalOption(name: "ASTU Local", host: "local-astu.alemtv.tm"),
    ]

    private static let defaultsKey = "portal.host"

    static var saved: PortalOption {
        let host = UserDefaults.standard.string(forKey: defaultsKey)
        return all.first { $0.host == host } ?? all[0]
    }

    static func save(_ option: PortalOption) {
        UserDefaults.standard.set(option.host, forKey: defaultsKey)
    }
}
