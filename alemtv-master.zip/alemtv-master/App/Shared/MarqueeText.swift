import SwiftUI

/// Строка, которая при `active` (фокус) прокручивается, если не помещается: пауза, плавный
/// сдвиг до конца, пауза, возврат. Без фокуса или если текст влезает — обычная строка с многоточием.
struct MarqueeText: View {
    let text: String
    var active: Bool

    /// Скорость прокрутки, точек в секунду.
    private static let speed: Double = 60
    private static let pause: Duration = .seconds(1.2)

    @State private var textWidth: CGFloat = 0
    @State private var boxWidth: CGFloat = 0
    @State private var offset: CGFloat = 0

    private var overflow: CGFloat { max(0, textWidth - boxWidth) }
    private var scrolling: Bool { active && overflow > 1 }

    var body: some View {
        // Невидимая строка задаёт высоту и ширину; поверх — обрезанная или прокручиваемая.
        Text(text)
            .lineLimit(1)
            .opacity(0)
            .frame(maxWidth: .infinity, alignment: .leading)
            .overlay(alignment: .leading) {
                GeometryReader { box in
                    Group {
                        if scrolling {
                            Text(text)
                                .fixedSize()
                                .offset(x: offset)
                        } else {
                            Text(text).lineLimit(1)
                        }
                    }
                    .frame(width: box.size.width, alignment: .leading)
                    .onAppear { boxWidth = box.size.width }
                    .onChange(of: box.size.width) { _, width in boxWidth = width }
                }
                .clipped()
            }
            .background {
                // Полная ширина текста в одну строку.
                Text(text)
                    .fixedSize()
                    .hidden()
                    .background(GeometryReader { full in
                        Color.clear
                            .onAppear { textWidth = full.size.width }
                            .onChange(of: full.size.width) { _, width in textWidth = width }
                    })
            }
            .task(id: scrolling) {
                offset = 0
                guard scrolling else { return }
                let duration = Double(overflow) / Self.speed
                while !Task.isCancelled {
                    try? await Task.sleep(for: Self.pause)
                    guard !Task.isCancelled else { return }
                    withAnimation(.linear(duration: duration)) { offset = -overflow }
                    try? await Task.sleep(for: .seconds(duration) + Self.pause)
                    guard !Task.isCancelled else { return }
                    offset = 0
                }
            }
    }
}
