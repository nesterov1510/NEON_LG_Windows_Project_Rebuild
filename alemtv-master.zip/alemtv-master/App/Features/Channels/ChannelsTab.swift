import SwiftUI
import AlemCore

struct ChannelsTab: View {
    @Environment(AppModel.self) private var app
    @State private var selectedID: Int?
    @State private var path: [Channel] = []

    /// Если рубрика пропала (смена подписки) — первая доступная.
    private var selected: Playlist? {
        app.categoryPlaylists.first { $0.id == selectedID } ?? app.categoryPlaylists.first
    }

    var body: some View {
        NavigationStack(path: $path) {
            HStack(alignment: .top, spacing: 30) {
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 12) {
                        ForEach(app.categoryPlaylists) { playlist in
                            Button { selectedID = playlist.id } label: {
                                Text(playlist.title)
                                    .frame(maxWidth: .infinity, alignment: .leading)
                                    .foregroundStyle(playlist.id == selected?.id ? Brand.accent : .primary)
                            }
                        }
                    }
                    .padding(.vertical, 40)
                }
                .frame(width: 420)
                .focusSection()
                // Рубрика меняется только нажатием (Button), не движением фокуса.

                ChannelGrid(channels: selected.map { app.authorization?.channels(in: $0) ?? [] } ?? [],
                            playlist: selected,
                            onSchedule: { path.append($0) })
                    .focusSection()
            }
            .navigationDestination(for: Channel.self) { ScheduleView(channel: $0) }
        }
        .onAppear {
            if selectedID == nil { selectedID = app.player.playlist?.id ?? app.categoryPlaylists.first?.id }
            #if DEBUG
            // Отладка: `-debugGuidePlaylist tv-movie` — открыть гид на рубрике по её имени на портале.
            if let name = UserDefaults.standard.string(forKey: "debugGuidePlaylist"),
               let playlist = app.categoryPlaylists.first(where: { $0.name == name }) {
                selectedID = playlist.id
            }
            #endif
        }
    }
}
