import SwiftUI
import AlemCore

struct FavoritesTab: View {
    @Environment(AppModel.self) private var app
    @State private var path: [Channel] = []

    var body: some View {
        let favorites = app.authorization?.favorites
        let channels = favorites.map { app.authorization?.channels(in: $0) ?? [] } ?? []
        NavigationStack(path: $path) {
            Group {
                if channels.isEmpty {
                    Label(app.strings("channel.addFavorite"), systemImage: "star")
                        .foregroundStyle(.secondary)
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else {
                    ChannelGrid(channels: channels, playlist: favorites, onSchedule: { path.append($0) })
                }
            }
            .navigationDestination(for: Channel.self) { ScheduleView(channel: $0) }
        }
    }
}
