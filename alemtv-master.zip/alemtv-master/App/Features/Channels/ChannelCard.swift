import SwiftUI
import AlemCore

struct ChannelCard: View {
    @Environment(AppModel.self) private var app
    @Environment(\.isFocused) private var isFocused
    let channel: Channel

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            ChannelLogo(channel: channel)
                .frame(maxWidth: .infinity)
                .frame(height: 110)
            HStack {
                // Название целиком: шрифт уменьшается под ширину плитки вместо многоточия.
                Text("\(channel.index). \(channel.name)").font(.headline).lineLimit(1).minimumScaleFactor(0.5)
                Spacer()
                if app.isFavorite(channel) { Image(systemName: "star.fill").foregroundStyle(Brand.accent) }
            }
            if let program = app.program(onAir: channel) {
                // Не помещается — бежит при фокусе на плитке.
                MarqueeText(text: program.title, active: isFocused).font(.caption).foregroundStyle(.secondary)
                TimelineView(.periodic(from: .now, by: 30)) { _ in
                    ProgressView(value: program.progress(at: app.clock.now())).tint(Brand.accent)
                }
            } else {
                Text(" ").font(.caption)
            }
        }
        .padding(20)
        .frame(width: 340, height: 250)
    }
}
