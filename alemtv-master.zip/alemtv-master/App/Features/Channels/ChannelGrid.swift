import SwiftUI
import AlemCore

struct ChannelGrid: View {
    @Environment(AppModel.self) private var app
    let channels: [Channel]
    let playlist: Playlist?
    let onSchedule: (Channel) -> Void

    private let columns = [GridItem(.adaptive(minimum: 340), spacing: 40)]
    @FocusState private var focused: Int?

    /// Канал, который сейчас играет, если он есть в этой рубрике: на нём фокус при открытии гида.
    private var playingID: Int? {
        guard let id = app.player.channel?.id, channels.contains(where: { $0.id == id }) else { return nil }
        return id
    }

    var body: some View {
        ScrollViewReader { proxy in
        ScrollView {
            LazyVGrid(columns: columns, spacing: 50) {
                ForEach(channels) { channel in
                    Button {
                        app.player.play(channel, in: playlist)
                        app.showGuide = false
                    } label: {
                        ChannelCard(channel: channel)
                    }
                    .buttonStyle(.card)
                    .focused($focused, equals: channel.id)
                    .id(channel.id)
                    .contextMenu {
                        Button(app.strings("channel.schedule")) { onSchedule(channel) }
                        Button(app.isFavorite(channel) ? app.strings("channel.removeFavorite") : app.strings("channel.addFavorite")) {
                            Task { await app.toggleFavorite(channel) }
                        }
                    }
                }
            }
            .padding(40)
        }
        .defaultFocus($focused, playingID)
        .task {
            // Сетка открывается на текущем канале, а не с первого. Ждём раскладку ленивой сетки:
            // сразу при появлении scrollTo не находит ячейку, а tvOS ставит фокус на вкладки.
            guard let id = playingID else { return }
            try? await Task.sleep(for: .milliseconds(150))
            proxy.scrollTo(id, anchor: .center)
            try? await Task.sleep(for: .milliseconds(150))
            focused = id
        }
        }
        .task(id: channels.map(\.id)) { await app.keepNowPlayingFresh(channels) }
    }
}
