import SwiftUI
import AlemCore

/// Логотип канала с портала (`logo96/<channel_id>.png`); если нет — название.
struct ChannelLogo: View {
    @Environment(AppModel.self) private var app
    let channel: Channel

    var body: some View {
        AsyncImage(url: app.logoURL(for: channel)) { phase in
            if let image = phase.image {
                image.resizable().scaledToFit()
            } else {
                Text(channel.name)
                    .font(.title3.bold())
                    .foregroundStyle(Brand.accent)
                    .multilineTextAlignment(.center)
                    .minimumScaleFactor(0.5)
            }
        }
    }
}
