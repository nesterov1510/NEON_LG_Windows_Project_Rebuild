import SwiftUI

struct OfflineView: View {
    @Environment(AppModel.self) private var app
    @State private var showPortals = false

    var body: some View {
        VStack(spacing: 40) {
            Image(systemName: "wifi.exclamationmark")
                .font(.system(size: 96))
                .foregroundStyle(Brand.accent)
            Text(app.strings("error.network"))
                .font(.title2)
                .multilineTextAlignment(.center)
            Button(app.strings("error.retry")) {
                Task { await app.start() }
            }
            // Выбранный портал может быть недоступен из этой сети — без смены портала отсюда не выйти.
            Button(app.strings("login.changePortal") + " · " + app.portal.name) { showPortals = true }
                .font(.callout)
        }
        .padding(80)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Brand.background)
        .sheet(isPresented: $showPortals) { PortalPickerView() }
    }
}
