import SwiftUI

struct LaunchView: View {
    var body: some View {
        VStack(spacing: 40) {
            Text("ALEM TV")
                .font(.system(size: 96, weight: .heavy))
                .foregroundStyle(Brand.accent)
            ProgressView()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Brand.background)
    }
}
