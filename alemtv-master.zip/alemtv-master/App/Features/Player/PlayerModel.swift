import Foundation
import Observation
import os
import AlemCore

@MainActor @Observable
final class PlayerModel {
    enum Mode: Equatable {
        case live
        case timeshift
        case archive(Program)
    }

    let engine = VLCPlayerEngine()
    private(set) var channel: Channel?
    private(set) var playlist: Playlist?
    private(set) var mode: Mode = .live
    private(set) var currentProgram: Program?
    private(set) var errorMessage: String?
    var showChannelList = false
    var showSchedule = false
    var panelVisible = false
    /// Открыт выбор звуковой дорожки — панель не скрывается автоматически.
    var showAudioChoice = false
    var askContinue = false

    @ObservationIgnored weak var app: AppModel?
    @ObservationIgnored private var session: SessionStore
    @ObservationIgnored private var epg: EPGStore
    @ObservationIgnored private var lastStreamMode: StreamMode = .live
    @ObservationIgnored private var clock = ContentClock(mode: .live, startedAt: Date())
    @ObservationIgnored private var retryCount = 0
    @ObservationIgnored private var pausedAt: Date?
    @ObservationIgnored private var stoppedForBackground = false
    @ObservationIgnored private var idle = IdleMonitor(timeout: 18_000)
    @ObservationIgnored private var panelIdle = IdleMonitor(timeout: 5)
    @ObservationIgnored private var loadTask: Task<Void, Never>?
    @ObservationIgnored private var loggedThisLoad = false
    @ObservationIgnored private let log = Logger(subsystem: "com.alexvamp.alemtv", category: "player")

    private static let audioLanguageKey = "audio.language"

    init(session: SessionStore, epg: EPGStore) {
        self.session = session
        self.epg = epg
        engine.onStateChange = { [weak self] in self?.engineStateChanged($0) }
        engine.onTracksChanged = { [weak self] in self?.applyPreferredAudio() }
        engine.onStalled = { [weak self] in
            // Через лестницу повторов: бесконечная загрузка не должна перезапускаться бесконечно.
            self?.log.notice("stream stalled")
            self?.handleFailure()
        }
        startTicker()
    }

    func configure(session: SessionStore, epg: EPGStore) {
        self.session = session
        self.epg = epg
    }

    func setIdleTimeout(_ timeout: TimeInterval) {
        idle = IdleMonitor(timeout: timeout)
    }

    // MARK: - Состояние

    private var now: Date { app?.clock.now() ?? Date() }

    var overlay: PlayerOverlay {
        if errorMessage != nil { return .error }
        if showChannelList { return .channelList }
        if showSchedule { return .schedule }
        if panelVisible { return .panel }
        return .none
    }

    var kind: PlaybackKind {
        switch mode {
        case .live: return .live
        case .timeshift: return .timeshift
        case .archive: return .archive
        }
    }

    var contentTime: Date { clock.contentTime(at: now) }

    var behindLive: TimeInterval? {
        guard mode == .timeshift else { return nil }
        return clock.behindLive(at: now)
    }

    /// Позиция и длительность записи (шкала архива).
    var archiveProgress: (position: TimeInterval, duration: TimeInterval)? {
        guard case .archive(let program) = mode else { return nil }
        let start = StreamURLBuilder.floorMinute(program.start)
        return (max(0, contentTime.timeIntervalSince(start)), StreamURLBuilder.floorMinute(program.stop).timeIntervalSince(start))
    }

    var isArchive: Bool { kind == .archive }
    var isPaused: Bool { engine.state == .paused }

    var canTimeshift: Bool {
        channel?.hasArchive == true && app?.authorization?.timeshiftEnabled == true
    }

    var canStartOver: Bool { canTimeshift && currentProgram != nil }

    // MARK: - Запуск

    func playInitial() {
        guard let a = app?.authorization else { return }
        let all = a.playlists.first { $0.name == "tv" } ?? app?.categoryPlaylists.first
        #if DEBUG
        if playDebugChannel(a, playlist: all) { return }
        #endif
        let channel = a.lastMediaID.flatMap(a.channel(id:))
            ?? all.flatMap { a.channels(in: $0).first }
            ?? a.channels.first
        if let channel { play(channel, in: all) }
    }

    func play(_ channel: Channel, in playlist: Playlist?) {
        self.channel = channel
        if let playlist { self.playlist = playlist }
        mode = .live
        pausedAt = nil
        retryCount = 0
        app?.rememberLastChannel(channel)
        load(.live)
    }

    func play(_ program: Program, on channel: Channel) {
        self.channel = channel
        start(program, position: 0)
    }

    /// Каталог перезагружен (например, сменилась подписка): если текущий канал или рубрика
    /// пропали — переключиться на доступные; иначе обновить данные канала и продолжить.
    func catalogChanged() {
        guard let a = app?.authorization, let current = channel else { return }
        let resolved = a.resolve(channelID: current.id, playlistID: playlist?.id)
        playlist = resolved.playlist
        guard let next = resolved.channel else {
            log.notice("no channels left after catalog change")
            stop()
            return
        }
        if next.id != current.id {
            log.notice("channel no longer available, switching")
            play(next, in: resolved.playlist)
        } else {
            channel = next
        }
    }

    func switchChannel(by delta: Int) {
        guard let a = app?.authorization, let channel else { return }
        let list = playlist.map { a.channels(in: $0) } ?? a.channels
        guard !list.isEmpty else { return }
        let index = list.firstIndex { $0.id == channel.id } ?? 0
        play(list[(index + delta % list.count + list.count) % list.count], in: playlist)
    }

    func goLive() {
        mode = .live
        pausedAt = nil
        retryCount = 0
        load(.live)
    }

    /// ±секунды: в архиве — seek внутри записи, в эфире/таймшифте — новый URL.
    func skip(_ seconds: TimeInterval) {
        if let archive = archiveProgress {
            let current = clock.playedTime(at: now)
            let target = min(max(0, current + seconds), max(0, archive.duration - 1))
            engine.seek(by: target - current)
            clock.didSeek(toPosition: target, at: now)
            return
        }
        guard canTimeshift, let channel else { return }
        switch PlaybackPolicy.skip(by: seconds, contentTime: contentTime, now: now, archiveDepth: channel.timeshiftArchiveLength) {
        case .live:
            goLive()
        case let target:
            mode = .timeshift
            load(target)
        }
    }

    func startOver() {
        guard canStartOver, let program = currentProgram, let channel else { return }
        play(program, on: channel)
    }

    func togglePause() {
        switch engine.state {
        case .playing, .loading:
            if !isArchive { pausedAt = contentTime }
            engine.pause()
        case .paused:
            resumeFromPause()
        default:
            break
        }
    }

    func selectAudioTrack(_ track: AudioTrack) {
        engine.selectAudioTrack(id: track.id)
        if let language = track.language { UserDefaults.standard.set(language, forKey: Self.audioLanguageKey) }
    }

    func retry() {
        retryCount = 0
        reload()
    }

    func reloadCurrent() {
        guard channel != nil else { return }
        reload()
    }

    func stop() {
        loadTask?.cancel()
        engine.stop()
        channel = nil
        currentProgram = nil
        errorMessage = nil
        panelVisible = false
        showSchedule = false
    }

    // MARK: - Пульт

    func handle(_ key: RemoteKey) {
        userActivity()
        switch PlaybackPolicy.action(for: key, overlay: overlay, kind: kind) {
        case .previousChannel: switchChannel(by: -1)
        case .nextChannel: switchChannel(by: 1)
        case .showChannelList: showChannelList = true
        case .showPanel: showPanel()
        case .hidePanel: panelVisible = false
        case .closeOverlay:
            showSchedule = false
            showChannelList = false
        case .togglePause: togglePause()
        case .skip(let seconds): skip(seconds)
        case .openGuide: app?.showGuide = true
        case .ignore: break
        }
    }

    func showPanel() {
        panelVisible = true
        panelIdle.touch()
    }

    func userActivity() {
        idle.touch()
        panelIdle.touch()
    }

    /// Возврат из фона: эфир продолжаем с live-edge, запись — с места.
    /// Уход в фон: поток останавливается сразу (без фонового режима tvOS всё равно заморозит
    /// приложение, но несколько секунд VLC ещё качал бы). Время кадра запоминается часами.
    func enterBackground() {
        guard channel != nil, errorMessage == nil, engine.state != .idle else { return }
        stoppedForBackground = true
        log.info("background: stream stopped")
        engine.stop()
    }

    func resumeAfterBackground() {
        guard channel != nil, errorMessage == nil else { return }
        let wasStopped = stoppedForBackground
        stoppedForBackground = false
        pausedAt = nil
        switch PlaybackPolicy.resumeAfterBackground(isLive: mode == .live) {
        case .reloadLive: goLive()
        case .reloadAtPosition:
            if wasStopped { reload() } else { engine.play() }
        }
    }

    func continueAfterIdle() {
        askContinue = false
        idle.touch()
        if mode == .live { goLive() } else { engine.play() }
    }

    // MARK: - Внутреннее

    private func engineStateChanged(_ state: PlaybackState) {
        switch state {
        case .playing:
            clock.didStartPlaying(at: now)
            retryCount = 0
            errorMessage = nil
            if !loggedThisLoad {
                loggedThisLoad = true
                logPlaying()
            }
        case .failed(let message):
            clock.didStopPlaying(at: now)
            log.error("playback failed: \(message, privacy: .public)")
            handleFailure()
        case .ended:
            clock.didStopPlaying(at: now)
            playNextProgram()
        case .idle, .loading, .paused:
            clock.didStopPlaying(at: now)
        }
    }

    private func logPlaying() {
        Task { [weak self] in
            try? await Task.sleep(for: .seconds(5))
            guard let self else { return }
            let size = self.engine.videoSize
            let tracks = self.engine.audioTracks.map { "\($0.name)/\($0.language ?? "-")" }.joined(separator: ",")
            self.log.info("playing \(Int(size.width))x\(Int(size.height)) audio=\(self.engine.audioTracks.count) [\(tracks, privacy: .public)]")
        }
    }

    private func applyPreferredAudio() {
        let language = UserDefaults.standard.string(forKey: Self.audioLanguageKey)
        if let track = AudioTrackChoice.preferred(engine.audioTracks, language: language),
           track.id != engine.selectedAudioTrackID {
            engine.selectAudioTrack(id: track.id)
        }
    }

    private func resumeFromPause() {
        defer { pausedAt = nil }
        if let pausedAt, !isArchive, canTimeshift {
            let behind = now.timeIntervalSince(pausedAt)
            if behind > PlaybackPolicy.liveSnap {
                log.info("resume after pause, \(Int(behind)) s behind live")
                mode = .timeshift
                load(.timeshift(behind: behind))
                return
            }
        }
        engine.play()
    }

    private func start(_ program: Program, position: TimeInterval) {
        let streamMode = StreamURLBuilder.mode(for: program, position: position, now: now)
        switch streamMode {
        case .live: mode = .live
        case .timeshift: mode = .timeshift
        case .archive: mode = .archive(program)
        }
        pausedAt = nil
        retryCount = 0
        load(streamMode)
    }

    private func load(_ streamMode: StreamMode) {
        guard let channel else { return }
        lastStreamMode = streamMode
        errorMessage = nil
        clock = ContentClock(mode: streamMode, startedAt: now)
        loggedThisLoad = false
        let reference = PlaybackPolicy.referenceTime(for: streamMode, now: now)
        Task { await refreshProgram(at: reference) }
        loadTask?.cancel()
        loadTask = Task { [weak self] in
            guard let self, let context = await self.session.streamContext(), !Task.isCancelled else { return }
            do {
                let url = try StreamURLBuilder.url(for: channel, mode: streamMode, context: context)
                self.log.info("load \(url.host ?? "", privacy: .public)\(url.path, privacy: .public)")
                let finite: Bool
                if case .archive = streamMode { finite = true } else { finite = false }
                self.engine.load(url, finite: finite)
            } catch {
                self.showError()
            }
        }
    }

    private func reload() {
        switch mode {
        case .live:
            load(.live)
        case .timeshift:
            load(.timeshift(behind: max(0, now.timeIntervalSince(contentTime))))
        case .archive(let program):
            let position = contentTime.timeIntervalSince(StreamURLBuilder.floorMinute(program.start))
            start(program, position: max(0, position))
        }
    }

    /// 1-я ошибка — новый URL; 2-я — повторный вход (он же перечитает каталог) и новый URL; дальше — сообщение.
    private func handleFailure() {
        retryCount += 1
        switch retryCount {
        case 1:
            reload()
        case 2:
            Task { [weak self] in
                try? await self?.app?.reauthorize()
                self?.reload()
            }
        default:
            engine.stop()
            showError()
        }
    }

    private func showError() {
        errorMessage = app?.strings(isArchive ? "player.recordingUnavailable" : "player.unavailable")
    }

    private func playNextProgram() {
        guard case .archive(let finished) = mode, let channel else { return }
        Task { [weak self] in
            guard let self else { return }
            let language = self.app?.authorization?.language?.id
            var list = (try? await self.epg.programs(mediaID: channel.id, day: PortalDate.dayString(finished.start), languageID: language)) ?? []
            if !list.contains(where: { $0.start >= finished.stop }) {
                list += (try? await self.epg.programs(mediaID: channel.id, day: PortalDate.dayString(finished.stop.addingTimeInterval(60)), languageID: language)) ?? []
            }
            if let next = list.first(where: { $0.start >= finished.stop }) {
                self.start(next, position: 0)
            } else {
                self.goLive()
            }
        }
    }

    /// `at` — время показываемого кадра; сразу после запуска потока передаётся явно.
    func refreshProgram(at time: Date? = nil) async {
        guard let channel else {
            currentProgram = nil
            return
        }
        let at = time ?? contentTime
        let list = (try? await epg.programs(mediaID: channel.id, day: PortalDate.dayString(at),
                                            languageID: app?.authorization?.language?.id)) ?? []
        currentProgram = list.first { $0.isOnAir(at: at) }
    }

    private func startTicker() {
        Task { [weak self] in
            var tick = 0
            while true {
                try? await Task.sleep(for: .seconds(1))
                guard let self else { return }
                tick += 1
                if self.panelVisible, !self.showAudioChoice, self.panelIdle.isExpired() { self.panelVisible = false }
                guard tick % 30 == 0 else { continue }
                await self.refreshProgram()
                if self.engine.state == .playing, self.idle.isExpired() {
                    self.engine.pause()
                    self.askContinue = true
                }
            }
        }
    }

    #if DEBUG
    /// Отладка: `-debugChannelID <id> [-debugMode live|archive|timeshift]` (смоук-скрипт).
    private func playDebugChannel(_ a: AuthorizeResult, playlist: Playlist?) -> Bool {
        guard let raw = UserDefaults.standard.string(forKey: "debugChannelID"), let id = Int(raw),
              let channel = a.channel(id: id) else { return false }
        self.channel = channel
        self.playlist = playlist
        switch UserDefaults.standard.string(forKey: "debugMode") {
        case "archive":
            let start = StreamURLBuilder.floorMinute(now.addingTimeInterval(-7_200))
            mode = .archive(Program(mediaID: id, start: start, stop: start.addingTimeInterval(600), title: "debug"))
            load(.archive(start: start, duration: 600))
        case "timeshift":
            mode = .timeshift
            load(.timeshift(behind: 600))
        default:
            play(channel, in: playlist)
        }
        return true
    }
    #endif
}
