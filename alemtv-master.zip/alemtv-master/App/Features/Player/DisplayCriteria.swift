import AVFoundation
import AVKit
import CoreMedia
import UIKit

/// Согласование частоты кадров экрана с контентом (системный плеер делает это сам; VLC — нет).
@MainActor
enum DisplayCriteria {
    static func apply(window: UIWindow?, frameRate: Float, size: CGSize) {
        guard let manager = window?.avDisplayManager, manager.isDisplayCriteriaMatchingEnabled,
              size.width > 0, size.height > 0 else { return }
        var description: CMVideoFormatDescription?
        CMVideoFormatDescriptionCreate(allocator: nil, codecType: kCMVideoCodecType_H264,
                                       width: Int32(size.width), height: Int32(size.height),
                                       extensions: nil, formatDescriptionOut: &description)
        guard let description else { return }
        manager.preferredDisplayCriteria = AVDisplayCriteria(refreshRate: frameRate, formatDescription: description)
    }

    static func reset(window: UIWindow?) {
        window?.avDisplayManager.preferredDisplayCriteria = nil
    }
}
