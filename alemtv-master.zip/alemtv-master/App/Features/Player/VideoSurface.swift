import SwiftUI
import UIKit

/// Контейнер для постоянной поверхности VLC (`engine.surface`). Фокус не берёт: пульт обрабатывает PlayerScreen.
struct VideoSurface: UIViewRepresentable {
    let engine: VLCPlayerEngine

    func makeUIView(context: Context) -> UIView {
        let container = UIView()
        container.backgroundColor = .black
        container.isUserInteractionEnabled = false
        let surface = engine.surface
        surface.removeFromSuperview()           // из прежнего экрана плеера, если он ещё жив
        surface.frame = container.bounds
        container.addSubview(surface)
        return container
    }

    func updateUIView(_ uiView: UIView, context: Context) {}
}
