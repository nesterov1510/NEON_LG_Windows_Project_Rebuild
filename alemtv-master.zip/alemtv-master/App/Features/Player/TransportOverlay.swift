import SwiftUI
import AlemCore

/// Панель плеера: канал и передача, шкала, кнопки. Фокус — между кнопками; Menu закрывает (PlaybackPolicy).
struct TransportOverlay: View {
    @Environment(AppModel.self) private var app
    @FocusState private var focus: Control?

    enum Control: Hashable {
        case back, playPause, forward, live, startOver, audio, schedule
    }

    var body: some View {
        let player = app.player
        let s = app.strings
        VStack(spacing: 0) {
            header
            Spacer()
            VStack(alignment: .leading, spacing: 28) {
                TimelineView(.periodic(from: .now, by: 1)) { _ in progress }
                HStack(spacing: 30) {
                    if player.canTimeshift || player.isArchive {
                        iconButton("gobackward.10", s("player.back10"), .back) { player.skip(-PlaybackPolicy.skipStep) }
                    }
                    iconButton(player.isPaused ? "play.fill" : "pause.fill",
                               player.isPaused ? s("player.play") : s("player.pause"), .playPause) { player.togglePause() }
                    if player.kind != .live {
                        iconButton("goforward.10", s("player.forward10"), .forward) { player.skip(PlaybackPolicy.skipStep) }
                        textButton(s("player.goLive"), .live) { player.goLive() }
                    }
                    if player.canStartOver {
                        textButton(s("player.startOver"), .startOver) { player.startOver() }
                    }
                    if !AudioTrackChoice.selectable(player.engine.audioTracks).isEmpty {
                        textButton(s("player.audio"), .audio) { player.showAudioChoice = true }
                    }
                    textButton(s("player.info"), .schedule) {
                        player.panelVisible = false
                        player.showSchedule = true
                    }
                }
                .focusSection()
            }
            .padding(60)
            .background(LinearGradient(colors: [.clear, .black.opacity(0.85)], startPoint: .top, endPoint: .bottom))
        }
        .onAppear { focus = .playPause }
        .onChange(of: focus) { _, _ in player.userActivity() }
        .confirmationDialog(s("player.audio"), isPresented: Binding(get: { player.showAudioChoice }, set: { player.showAudioChoice = $0; player.userActivity() })) {
            ForEach(AudioTrackChoice.selectable(player.engine.audioTracks)) { track in
                Button(track.name + (track.id == player.engine.selectedAudioTrackID ? " ✓" : "")) {
                    player.selectAudioTrack(track)
                }
            }
            Button(s("common.cancel"), role: .cancel) {}
        }
    }

    private var header: some View {
        let player = app.player
        return HStack(spacing: 24) {
            if let channel = player.channel {
                ChannelLogo(channel: channel).frame(width: 120, height: 68)
                VStack(alignment: .leading, spacing: 6) {
                    Text("\(channel.index). \(channel.name)").font(.headline).foregroundStyle(Brand.accent)
                    if let program = player.currentProgram {
                        Text(program.title).font(.title3).lineLimit(1)
                        Text("\(program.start.formatted(timeStyle)) – \(program.stop.formatted(timeStyle))")
                            .foregroundStyle(.secondary)
                    } else {
                        Text(app.strings("epg.empty")).foregroundStyle(.secondary)
                    }
                }
            }
            Spacer()
        }
        .padding(60)
        .background(LinearGradient(colors: [.black.opacity(0.85), .clear], startPoint: .top, endPoint: .bottom))
    }

    @ViewBuilder private var progress: some View {
        let player = app.player
        if let archive = player.archiveProgress {
            ProgressView(value: min(archive.position, archive.duration), total: max(archive.duration, 1))
                .tint(Brand.accent)
            HStack {
                Text(Duration.seconds(Int(archive.position)).formatted(.time(pattern: .hourMinuteSecond)))
                Spacer()
                Text(Duration.seconds(Int(archive.duration)).formatted(.time(pattern: .hourMinuteSecond)))
            }
            .font(.caption.monospacedDigit())
            .foregroundStyle(.secondary)
        } else {
            if let program = player.currentProgram {
                ProgressView(value: program.progress(at: player.contentTime)).tint(Brand.accent)
            }
            HStack {
                Spacer()
                if let behind = player.behindLive {
                    Text(app.strings("player.behindLive", "−" + Duration.seconds(Int(behind)).formatted(.time(pattern: .hourMinuteSecond))))
                } else {
                    Label(app.strings("player.live"), systemImage: "dot.radiowaves.left.and.right")
                        .foregroundStyle(Brand.accent)
                }
            }
            .font(.caption.monospacedDigit())
        }
    }

    private var timeStyle: Date.FormatStyle {
        var style = Date.FormatStyle(date: .omitted, time: .shortened).locale(app.strings.locale)
        style.timeZone = PortalDate.serverTimeZone
        return style
    }

    private func iconButton(_ symbol: String, _ label: String, _ control: Control, action: @escaping () -> Void) -> some View {
        Button(action: action) { Image(systemName: symbol).font(.title2) }
            .accessibilityLabel(label)
            .focused($focus, equals: control)
    }

    private func textButton(_ title: String, _ control: Control, action: @escaping () -> Void) -> some View {
        Button(title, action: action).focused($focus, equals: control)
    }
}
