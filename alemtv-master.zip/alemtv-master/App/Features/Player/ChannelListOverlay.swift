import SwiftUI
import AlemCore

/// Боковой список каналов поверх видео (клик влево в эфире).
struct ChannelListOverlay: View {
    @Environment(AppModel.self) private var app
    @State private var selectedPlaylistID: Int?
    @FocusState private var focus: Focus?

    enum Focus: Hashable {
        case playlist(Int)
        case channel(Int)
    }

    private var playlists: [Playlist] {
        app.categoryPlaylists + (app.authorization?.favorites.map { [$0] } ?? [])
    }

    private var current: Playlist? {
        playlists.first { $0.id == selectedPlaylistID } ?? app.player.playlist ?? playlists.first
    }

    var body: some View {
        let channels = current.map { app.authorization?.channels(in: $0) ?? [] } ?? []
        HStack(spacing: 0) {
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 10) {
                    ForEach(playlists) { playlist in
                        Button { selectedPlaylistID = playlist.id } label: {
                            Text(playlist.isFavorites ? app.strings("guide.favorites") : playlist.title)
                                .foregroundStyle(playlist.id == current?.id ? Brand.accent : .primary)
                                .frame(maxWidth: .infinity, alignment: .leading)
                        }
                        .focused($focus, equals: .playlist(playlist.id))
                    }
                }
                .padding(40)
            }
            .frame(width: 400)
            .focusSection()

            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 8) {
                        ForEach(channels) { channel in
                            Button {
                                app.player.play(channel, in: current)
                                app.player.showChannelList = false
                            } label: {
                                ChannelRow(channel: channel, isCurrent: channel.id == app.player.channel?.id)
                            }
                            .focused($focus, equals: .channel(channel.id))
                            .id(channel.id)
                        }
                    }
                    .padding(40)
                }
                .onAppear { if let id = app.player.channel?.id { proxy.scrollTo(id, anchor: .center) } }
            }
            .frame(width: 760)
            .focusSection()

            Spacer()
        }
        .background(LinearGradient(colors: [.black.opacity(0.95), .black.opacity(0.6), .clear], startPoint: .leading, endPoint: .trailing))
        .onExitCommand { app.player.showChannelList = false }
        .onAppear {
            selectedPlaylistID = app.player.playlist?.id
            if let id = app.player.channel?.id { focus = .channel(id) }
        }
        .task(id: current?.id) { await app.keepNowPlayingFresh(channels) }
    }
}

private struct ChannelRow: View {
    @Environment(AppModel.self) private var app
    @Environment(\.isFocused) private var isFocused
    let channel: Channel
    let isCurrent: Bool

    var body: some View {
        HStack(spacing: 20) {
            ChannelLogo(channel: channel).frame(width: 96, height: 54)
            VStack(alignment: .leading, spacing: 4) {
                Text("\(channel.index). \(channel.name)")
                    .font(.headline)
                    .lineLimit(1)
                    .minimumScaleFactor(0.5)
                    .foregroundStyle(isCurrent ? Brand.accent : .primary)
                if let program = app.program(onAir: channel) {
                    MarqueeText(text: program.title, active: isFocused).font(.caption).foregroundStyle(.secondary)
                    TimelineView(.periodic(from: .now, by: 30)) { _ in
                        ProgressView(value: program.progress(at: app.clock.now())).tint(Brand.accent)
                    }
                }
            }
        }
    }
}
