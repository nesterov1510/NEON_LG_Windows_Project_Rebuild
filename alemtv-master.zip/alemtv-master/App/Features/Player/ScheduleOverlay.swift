import SwiftUI
import AlemCore

/// Программа текущего канала на день показываемого кадра, поверх видео справа.
struct ScheduleOverlay: View {
    @Environment(AppModel.self) private var app
    @State private var programs: [Program] = []

    var body: some View {
        let player = app.player
        let now = app.clock.now()
        HStack {
            Spacer()
            ScrollViewReader { proxy in
                List(programs) { program in
                    Button { select(program, now: now) } label: {
                        HStack(spacing: 20) {
                            Text(program.start.formatted(timeStyle)).monospacedDigit().frame(width: 100, alignment: .leading)
                            Text(program.title).lineLimit(1)
                            Spacer()
                            if program.isOnAir(at: player.contentTime) {
                                Image(systemName: "play.fill").foregroundStyle(Brand.accent)
                            }
                        }
                    }
                    .disabled(!playable(program, now: now))
                    .id(program.id)
                }
                .overlay {
                    // Пустая программа: без фокусируемого элемента пульт «застревает» — кнопка закрывает оверлей.
                    if programs.isEmpty {
                        Button(app.strings("epg.empty")) { player.showSchedule = false }
                    }
                }
                .onChange(of: programs) { _, list in
                    if let current = list.first(where: { $0.isOnAir(at: player.contentTime) }) {
                        proxy.scrollTo(current.id, anchor: .center)
                    }
                }
            }
            .frame(width: 900)
            .background(.ultraThinMaterial)
        }
        .onExitCommand { player.showSchedule = false }
        .task(id: player.channel?.id) {
            guard let channel = player.channel else { return }
            programs = (try? await app.epg.programs(mediaID: channel.id, day: PortalDate.dayString(player.contentTime),
                                                     languageID: app.authorization?.language?.id)) ?? []
        }
    }

    private var timeStyle: Date.FormatStyle {
        var style = Date.FormatStyle(date: .omitted, time: .shortened).locale(app.strings.locale)
        style.timeZone = PortalDate.serverTimeZone
        return style
    }

    private func playable(_ program: Program, now: Date) -> Bool {
        guard let channel = app.player.channel else { return false }
        return program.isOnAir(at: now) || StreamURLBuilder.isAvailableInArchive(
            program, channel: channel, timeshiftEnabled: app.authorization?.timeshiftEnabled ?? false, now: now)
    }

    private func select(_ program: Program, now: Date) {
        let player = app.player
        player.showSchedule = false
        if program.isOnAir(at: now) {
            player.goLive()
        } else if let channel = player.channel {
            player.play(program, on: channel)
        }
    }
}
