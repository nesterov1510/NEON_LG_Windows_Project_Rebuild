import AVFoundation
import Foundation
import Observation
import UIKit
import os
import VLCKit
import AlemCore

/// Единственный движок воспроизведения: VLCKit (HEVC/H.264/MPEG-2, AAC/MP2/AC-3 в TS).
/// Переходы состояний — в EngineStateMachine (AlemCore, покрыта тестами).
@MainActor @Observable
final class VLCPlayerEngine: NSObject, PlayerEngine {
    @ObservationIgnored let player = VLCMediaPlayer()
    /// Единственная поверхность VLC на всё время жизни движка. Экран плеера пересоздаётся
    /// (выход → вход), а смену drawable во время асинхронной остановки VLC 4 пропускает:
    /// после повторного входа шёл только звук. Поэтому drawable задаётся один раз.
    @ObservationIgnored let surface: UIView = {
        let view = UIView()
        view.backgroundColor = .black
        view.isUserInteractionEnabled = false
        view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        return view
    }()
    private(set) var state: PlaybackState = .idle
    private(set) var audioTracks: [AudioTrack] = []

    @ObservationIgnored var onStateChange: ((PlaybackState) -> Void)?
    @ObservationIgnored var onTracksChanged: (() -> Void)?
    @ObservationIgnored var onStalled: (() -> Void)?

    @ObservationIgnored private var machine = EngineStateMachine()
    @ObservationIgnored private var criteriaApplied = false
    @ObservationIgnored private let log = Logger(subsystem: "com.alexvamp.alemtv", category: "engine")

    override init() {
        super.init()
        player.delegate = self
        player.drawable = surface
        // Один раз и не на главном потоке: синхронная настройка аудиосессии при каждой
        // загрузке канала давала в консоли «AVAudioSession Hang Risk» (риск подвисания UI).
        Task.detached(priority: .userInitiated) {
            let session = AVAudioSession.sharedInstance()
            try? session.setCategory(.playback, mode: .moviePlayback)
            try? session.setActive(true)
        }
        Task { [weak self] in
            while true {
                try? await Task.sleep(for: .seconds(1))
                guard let self else { return }
                self.tick()
            }
        }
    }

    /// Время VLC у некоторых каналов стоит на месте при идущем видео (Аркадаг) — сторож смотрит на счётчики вывода.
    var outputProgress: Double {
        guard let stats = player.media?.statistics else { return 0 }
        return Double(stats.displayedPictures + stats.playedAudioBuffers)
    }
    var videoSize: CGSize { player.videoSize }
    var selectedAudioTrackID: String? { player.audioTracks.first(where: \.isSelected)?.trackId }

    func load(_ url: URL, finite: Bool) {
        guard let media = VLCMedia(url: url) else {
            apply(machine.load(finite: finite, at: Date()))
            apply(machine.handle(.error, at: Date()))
            return
        }
        media.addOptions(["network-caching": 1500, "live-caching": 1500])
        criteriaApplied = false
        audioTracks = []
        // До смены media: асинхронный stopped старого потока придёт в .loading и будет проигнорирован.
        apply(machine.load(finite: finite, at: Date()))
        player.media = media
        player.play()
    }

    func play() { player.play() }

    func pause() { player.pause() }

    func seek(by offset: TimeInterval) {
        player.jump(withOffset: Int32(offset * 1000))
    }

    func selectAudioTrack(id: String) {
        player.audioTracks.first { $0.trackId == id }?.isSelectedExclusively = true
    }

    func stop() {
        DisplayCriteria.reset(window: surface.window)
        apply(machine.stop())          // stopped после нашей остановки придёт в .idle и будет проигнорирован
        player.stop()
    }

    // MARK: - Внутреннее

    fileprivate func handle(_ vlc: VLCMediaPlayerState) {
        let event: EngineEvent
        switch vlc {
        case .opening: event = .opening
        case .playing: event = .playing; refreshTracks()
        case .paused: event = .paused
        case .error: event = .error
        case .stopped: event = .stopped(position: Double(player.position))
        default: return
        }
        log.info("vlc \(String(describing: event), privacy: .public) → \(String(describing: self.machine.state), privacy: .public)")
        apply(machine.handle(event, at: Date()))
    }

    fileprivate func buffering(_ progress: Float) {
        if let changed = machine.handle(.buffering(progress), at: Date()) {
            log.info("buffering \(progress) → \(String(describing: changed), privacy: .public)")
            apply(changed)
        }
    }

    fileprivate func refreshTracks() {
        let tracks = player.audioTracks.map {
            AudioTrack(id: $0.trackId, name: $0.trackName, language: $0.language)
        }
        if tracks != audioTracks {
            audioTracks = tracks
            onTracksChanged?()
        }
    }

    private func apply(_ newState: PlaybackState?) {
        guard let newState else { return }
        state = newState
        onStateChange?(newState)
    }

    private func tick() {
        if state == .playing { applyDisplayCriteria() }
        if machine.isStalled(progress: outputProgress, at: Date()) {
            log.info("stalled in \(String(describing: self.state), privacy: .public), output \(self.outputProgress)")
            onStalled?()
        }
    }

    /// Частота кадров экрана под контент (25 к/с у ТВ-каналов), если в tvOS включено согласование.
    /// По тику: VLC сообщает «играет» раньше, чем узнаёт размер кадра.
    private func applyDisplayCriteria() {
        guard !criteriaApplied, player.videoSize.width > 0 else { return }
        criteriaApplied = true
        var rate: Float = 25
        if let video = player.videoTracks.first?.video, video.frameRate > 0 {
            rate = Float(video.frameRate) / Float(max(1, video.frameRateDenominator))
        }
        let view: UIView? = surface
        let screen = view?.window?.screen
        let video = player.videoSize
        log.info("""
            display: video \(Int(video.width))x\(Int(video.height)) @\(rate) fps, \
            view \(Int(view?.bounds.width ?? 0))x\(Int(view?.bounds.height ?? 0)), \
            screen \(Int(screen?.nativeBounds.width ?? 0))x\(Int(screen?.nativeBounds.height ?? 0)) scale \(screen?.scale ?? 0), \
            matching \(view?.window?.avDisplayManager.isDisplayCriteriaMatchingEnabled ?? false)
            """)
        DisplayCriteria.apply(window: view?.window, frameRate: rate, size: video)
    }
}

extension VLCPlayerEngine: VLCMediaPlayerDelegate {
    nonisolated func mediaPlayerStateChanged(_ newState: VLCMediaPlayerState) {
        Task { @MainActor [weak self] in self?.handle(newState) }
    }

    nonisolated func mediaPlayerBufferingChanged(_ progress: Float) {
        Task { @MainActor [weak self] in self?.buffering(progress) }
    }

    nonisolated func mediaPlayerTrackAdded(_ trackId: String, with trackType: VLCMedia.TrackType) {
        Task { @MainActor [weak self] in self?.refreshTracks() }
    }
}
