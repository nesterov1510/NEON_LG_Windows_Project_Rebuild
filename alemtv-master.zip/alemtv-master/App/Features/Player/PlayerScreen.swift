import SwiftUI
import AlemCore

struct PlayerScreen: View {
    @Environment(AppModel.self) private var app

    var body: some View {
        @Bindable var player = app.player
        ZStack(alignment: .topTrailing) {
            VideoSurface(engine: player.engine)
                .ignoresSafeArea()
            if player.overlay == .none {
                RemoteCatcher()
            }
            if player.mode == .timeshift && !player.panelVisible {
                TimeshiftBadge().padding(60)
            }
            if player.panelVisible && player.overlay == .panel {
                TransportOverlay()
            }
            if player.showSchedule {
                ScheduleOverlay()
            }
            if let message = player.errorMessage {
                ErrorOverlay(message: message)
            }
            if player.showChannelList {
                ChannelListOverlay()
                    .transition(.move(edge: .leading))
            }
        }
        .background(Color.black)
        .animation(.easeOut(duration: 0.2), value: player.showChannelList)
        .animation(.easeOut(duration: 0.2), value: player.panelVisible)
        .onMoveCommand { direction in
            if let key = RemoteKey(direction) { player.handle(key) }
        }
        .onPlayPauseCommand { player.handle(.playPause) }
        .onExitCommand { player.handle(.menu) }
        .alert(app.strings("player.continue.title"), isPresented: $player.askContinue) {
            Button(app.strings("player.continue")) { player.continueAfterIdle() }
        }
    }
}

extension RemoteKey {
    init?(_ direction: MoveCommandDirection) {
        switch direction {
        case .up: self = .up
        case .down: self = .down
        case .left: self = .left
        case .right: self = .right
        @unknown default: return nil
        }
    }
}

/// Единственный фокусируемый элемент в режиме просмотра: Select показывает панель,
/// стрелки уходят в onMoveCommand экрана.
private struct RemoteCatcher: View {
    @Environment(AppModel.self) private var app
    @FocusState private var focused: Bool

    var body: some View {
        // Не Button: у кнопки tvOS рисует белую подложку фокуса на весь экран.
        Color.clear
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .contentShape(Rectangle())
            .focusable()
            .focusEffectDisabled()
            .focused($focused)
            .onTapGesture { app.player.handle(.select) }
            .onAppear { focused = true }
    }
}

private struct TimeshiftBadge: View {
    @Environment(AppModel.self) private var app

    var body: some View {
        TimelineView(.periodic(from: .now, by: 1)) { _ in
            if let behind = app.player.behindLive {
                Text(app.strings("player.behindLive", "−" + Duration.seconds(Int(behind)).formatted(.time(pattern: .hourMinuteSecond))))
                    .font(.headline.monospacedDigit())
                    .padding(.horizontal, 24)
                    .padding(.vertical, 12)
                    .background(.ultraThinMaterial, in: Capsule())
            }
        }
    }
}

private struct ErrorOverlay: View {
    @Environment(AppModel.self) private var app
    let message: String

    var body: some View {
        VStack(spacing: 30) {
            Image(systemName: "exclamationmark.tv").font(.system(size: 80)).foregroundStyle(Brand.accent)
            Text(message).font(.title2)
            HStack(spacing: 40) {
                Button(app.strings("error.retry")) { app.player.retry() }
                Button(app.strings("guide.channels")) { app.showGuide = true }
            }
        }
        .padding(60)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 30))
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .focusSection()
    }
}

