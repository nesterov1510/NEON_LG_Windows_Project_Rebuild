import SwiftUI
import AlemCore

struct SettingsView: View {
    @Environment(AppModel.self) private var app
    @State private var confirmLogout = false
    @State private var askPassword = false
    @State private var password = ""
    @State private var wrongPassword = false
    @State private var mac: String?
    @State private var passwordSubmitted = false

    private static let languageNames = ["ru": "Русский", "tk": "Türkmençe", "en": "English"]

    var body: some View {
        let s = app.strings
        NavigationStack {
            List {
                Section(s("settings.profile")) {
                    ForEach(app.authorization?.profiles ?? []) { profile in
                        Button {
                            Task {
                                if await app.selectProfile(profile) == .needsPassword {
                                    passwordSubmitted = false
                                    askPassword = true
                                }
                            }
                        } label: {
                            row(profile.title, selected: app.authorization?.profile?.id == profile.id)
                        }
                    }
                }
                Section(s("settings.language")) {
                    ForEach(app.authorization?.languages ?? []) { language in
                        Button {
                            Task { await app.setLanguage(language) }
                        } label: {
                            row(Self.languageNames[language.code] ?? language.name,
                                selected: app.authorization?.language?.id == language.id)
                        }
                    }
                }
                Section(s("settings.portal")) {
                    NavigationLink(app.portal.name) { PortalPickerView() }
                }
                Section(s("settings.about")) {
                    LabeledContent(s("settings.version"),
                                   value: Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "—")
                    LabeledContent(s("settings.terminal"), value: mac ?? "—")
                    Text(s("settings.engine")).font(.caption).foregroundStyle(.secondary)
                }
                Section {
                    Button(s("settings.logout"), role: .destructive) { confirmLogout = true }
                }
            }
            .task { mac = await app.session.macaddr }
            .onDisappear { Task { await app.abandonProfilePasswordIfPending() } }
            .confirmationDialog(s("settings.logout.confirm"), isPresented: $confirmLogout) {
                Button(s("settings.logout"), role: .destructive) { Task { await app.signOut() } }
                Button(s("common.cancel"), role: .cancel) {}
            }
            .alert(s("profile.enterPassword"), isPresented: $askPassword) {
                SecureField(s("login.password"), text: $password)
                Button(s("common.ok")) {
                    passwordSubmitted = true
                    let entered = password
                    password = ""
                    Task { wrongPassword = !(await app.confirmProfilePassword(entered)) }
                }
                Button(s("common.cancel"), role: .cancel) { password = "" }
            }
            // Окно пароля закрыто без «OK» (Menu и т. п.) — профиль откатывается.
            .onChange(of: askPassword) { _, shown in
                if !shown && !passwordSubmitted { Task { await app.cancelProfilePassword() } }
            }
            .alert(app.actionError ?? "", isPresented: Binding(get: { app.actionError != nil }, set: { if !$0 { app.actionError = nil } })) {
                Button(s("common.ok")) {}
            }
            .alert(s("profile.wrongPassword"), isPresented: $wrongPassword) {
                Button(s("common.ok")) {}
            }
        }
    }

    private func row(_ title: String, selected: Bool) -> some View {
        HStack {
            Text(title)
            Spacer()
            if selected { Image(systemName: "checkmark").foregroundStyle(Brand.accent) }
        }
    }
}
