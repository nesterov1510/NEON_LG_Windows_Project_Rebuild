import SwiftUI

struct GuideView: View {
    @Environment(AppModel.self) private var app

    var body: some View {
        TabView {
            ChannelsTab().tabItem { Text(app.strings("guide.channels")) }
            FavoritesTab().tabItem { Text(app.strings("guide.favorites")) }
            SettingsView().tabItem { Text(app.strings("guide.settings")) }
        }
        .background(Brand.background)
    }
}
