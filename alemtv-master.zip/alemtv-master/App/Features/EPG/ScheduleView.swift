import SwiftUI
import AlemCore

struct ScheduleView: View {
    @Environment(AppModel.self) private var app
    let channel: Channel
    @State private var day = PortalDate.startOfDay(Date())
    @State private var programs: [Program] = []
    @State private var loaded = false

    private var now: Date { app.clock.now() }

    /// Дни: назад — глубина архива, вперёд — до max_stop из epg_info.
    private var days: [Date] {
        let today = PortalDate.startOfDay(now)
        let info = app.authorization?.epgInfo[channel.id]
        let back = channel.hasArchive ? Int(((channel.timeshiftArchiveLength ?? 0) / 86_400).rounded(.up)) : 0
        let forward = info?.maxStop.map { max(0, Int($0.timeIntervalSince(today) / 86_400)) } ?? 0
        let earliest = info?.minStart.map(PortalDate.startOfDay) ?? today
        return (-back...forward)
            .map { today.addingTimeInterval(Double($0) * 86_400) }
            .filter { $0 >= earliest || $0 == today }
    }

    var body: some View {
        HStack(alignment: .top, spacing: 30) {
            ScrollView {
                LazyVStack(spacing: 12) {
                    ForEach(days, id: \.self) { d in
                        Button { day = d } label: {
                            Text(title(for: d))
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .foregroundStyle(d == day ? Brand.accent : .primary)
                        }
                    }
                }
                .padding(.vertical, 40)
            }
            .frame(width: 380)
            .focusSection()

            ScrollViewReader { proxy in
                List(programs) { program in
                    Button { select(program) } label: { row(program) }
                        .disabled(!playable(program))
                        .id(program.id)
                }
                .overlay {
                    if loaded && programs.isEmpty {
                        Text(app.strings("epg.empty")).foregroundStyle(.secondary)
                    }
                }
                .onChange(of: programs) { _, list in
                    if let current = list.first(where: { $0.isOnAir(at: now) }) { proxy.scrollTo(current.id, anchor: .center) }
                }
            }
            .focusSection()
        }
        .navigationTitle(channel.name)
        .onAppear { day = PortalDate.startOfDay(now) }
        .task(id: PortalDate.dayString(day)) {
            loaded = false
            programs = (try? await app.epg.programs(mediaID: channel.id, day: PortalDate.dayString(day),
                                                     languageID: app.authorization?.language?.id)) ?? []
            loaded = true
        }
    }

    private func row(_ program: Program) -> some View {
        HStack(spacing: 24) {
            Text(program.start.formatted(timeStyle))
                .monospacedDigit()
                .frame(width: 110, alignment: .leading)
            Text(program.title).lineLimit(1)
            if let age = program.ageLabel { Text(age).font(.caption).foregroundStyle(.secondary) }
            Spacer()
            if program.isOnAir(at: now) {
                Label(app.strings("epg.live"), systemImage: "dot.radiowaves.left.and.right").foregroundStyle(Brand.accent)
            } else if inArchive(program) {
                Image(systemName: "backward.circle").accessibilityLabel(app.strings("epg.archive"))
            }
        }
    }

    private var timeStyle: Date.FormatStyle {
        var style = Date.FormatStyle(date: .omitted, time: .shortened).locale(app.strings.locale)
        style.timeZone = PortalDate.serverTimeZone
        return style
    }

    private func title(for d: Date) -> String {
        if d == PortalDate.startOfDay(now) { return app.strings("epg.today") }
        var style = Date.FormatStyle().weekday(.abbreviated).day().month(.abbreviated).locale(app.strings.locale)
        style.timeZone = PortalDate.serverTimeZone
        return d.formatted(style)
    }

    private func inArchive(_ program: Program) -> Bool {
        StreamURLBuilder.isAvailableInArchive(program, channel: channel,
                                              timeshiftEnabled: app.authorization?.timeshiftEnabled ?? false, now: now)
    }

    private func playable(_ program: Program) -> Bool {
        program.isOnAir(at: now) || inArchive(program)
    }

    private func select(_ program: Program) {
        if program.isOnAir(at: now) {
            app.player.play(channel, in: app.player.playlist)
        } else {
            app.player.play(program, on: channel)
        }
        app.showGuide = false
    }
}
