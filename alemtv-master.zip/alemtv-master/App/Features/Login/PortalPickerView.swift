import SwiftUI

struct PortalPickerView: View {
    @Environment(AppModel.self) private var app
    @Environment(\.dismiss) private var dismiss
    @State private var pending: PortalOption?

    var body: some View {
        List(PortalOption.all) { option in
            Button {
                if option != app.portal { pending = option } else { dismiss() }
            } label: {
                HStack {
                    VStack(alignment: .leading) {
                        Text(option.name)
                        Text(option.host).font(.caption).foregroundStyle(.secondary)
                    }
                    Spacer()
                    if option == app.portal { Image(systemName: "checkmark") }
                }
            }
        }
        .navigationTitle(app.strings("settings.portal"))
        .confirmationDialog(app.strings("portal.confirm"), isPresented: Binding(get: { pending != nil }, set: { if !$0 { pending = nil } })) {
            Button(app.strings("common.ok")) {
                if let option = pending {
                    dismiss()
                    Task { await app.switchPortal(option) }
                }
            }
            Button(app.strings("common.cancel"), role: .cancel) { pending = nil }
        }
    }
}
