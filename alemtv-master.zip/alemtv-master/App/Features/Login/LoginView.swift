import SwiftUI

struct LoginView: View {
    @Environment(AppModel.self) private var app
    @State private var username = ""
    @State private var password = ""
    @State private var showPortals = false

    var body: some View {
        VStack(spacing: 32) {
            Text("ALEM TV")
                .font(.system(size: 72, weight: .heavy))
                .foregroundStyle(Brand.accent)
            Text(app.strings("login.title")).font(.title2)
            TextField(app.strings("login.username"), text: $username)
                .textContentType(.username)
                .autocorrectionDisabled()
                .textInputAutocapitalization(.never)
            SecureField(app.strings("login.password"), text: $password)
                .textContentType(.password)
            if let error = app.loginError {
                Text(error).foregroundStyle(.red)
            }
            Button {
                Task { await app.signIn(username: username, password: password) }
            } label: {
                if app.isBusy { ProgressView() } else { Text(app.strings("login.submit")) }
            }
            .disabled(username.isEmpty || password.isEmpty || app.isBusy)
            Button(app.strings("login.changePortal") + " · " + app.portal.name) { showPortals = true }
                .font(.callout)
        }
        .frame(width: 900)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Brand.background)
        .sheet(isPresented: $showPortals) { PortalPickerView() }
    }
}
