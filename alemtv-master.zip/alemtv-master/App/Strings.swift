import Foundation

/// Локализованные строки с выбором языка в рантайме (язык терминала задаёт сервер: ru/tk/en).
struct Strings {
    let language: String
    private let bundle: Bundle

    init(language: String) {
        self.language = language
        bundle = Bundle.main.path(forResource: language, ofType: "lproj").flatMap(Bundle.init(path:)) ?? .main
    }

    func callAsFunction(_ key: String) -> String {
        bundle.localizedString(forKey: key, value: nil, table: nil)
    }

    func callAsFunction(_ key: String, _ args: CVarArg...) -> String {
        String(format: self(key), arguments: args)
    }

    var locale: Locale { Locale(identifier: language) }
}
