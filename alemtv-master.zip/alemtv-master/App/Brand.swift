import SwiftUI

enum Brand {
    /// #FF8800 — акцент из Android-приложения AlemTV.
    static let accent = Color(red: 1.0, green: 0x88 / 255.0, blue: 0)
    static let background = Color.black
}
