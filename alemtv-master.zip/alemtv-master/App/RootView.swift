import SwiftUI

struct RootView: View {
    @Environment(AppModel.self) private var app

    var body: some View {
        @Bindable var app = app
        Group {
            switch app.route {
            case .launching:
                LaunchView()
            case .login:
                LoginView()
            case .offline:
                OfflineView()
            case .main:
                PlayerScreen()
                    .fullScreenCover(isPresented: $app.showGuide) { GuideView().preferredColorScheme(.dark) }
            }
        }
        .environment(\.locale, app.strings.locale)
    }
}

