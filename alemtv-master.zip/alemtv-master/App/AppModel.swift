import Foundation
import Network
import Observation
import UIKit
import os
import AlemCore

@MainActor @Observable
final class AppModel {
    enum Route: Equatable {
        case launching, login, offline, main
    }

    enum ProfileChange: Equatable {
        case done
        case needsPassword
        case failed(String)
    }

    var route: Route = .launching
    private(set) var authorization: AuthorizeResult?
    private(set) var nowPlaying: [Int: Program] = [:]
    private(set) var clock = ServerClock()
    private(set) var strings = Strings(language: "ru")
    private(set) var portal: PortalOption
    var showGuide = false
    var loginError: String?
    /// Сообщение об ошибке действия в гиде/настройках (например, выход без сети).
    var actionError: String?
    var isBusy = false
    let player: PlayerModel

    @ObservationIgnored private(set) var client: PortalClient
    @ObservationIgnored private(set) var session: SessionStore
    @ObservationIgnored private(set) var epg: EPGStore
    @ObservationIgnored private var refreshTask: Task<Void, Never>?
    @ObservationIgnored private let pathMonitor = NWPathMonitor()
    @ObservationIgnored private var networkWasSatisfied: Bool?
    /// Профиль с паролем, разблокированный в этом сеансе (только в памяти).
    @ObservationIgnored private var unlockedProfileID: Int?
    @ObservationIgnored private var awaitingProfilePassword = false
    @ObservationIgnored private let log = Logger(subsystem: "com.alexvamp.alemtv", category: "app")

    init(portal: PortalOption = .saved) {
        self.portal = portal
        let services = Self.makeServices(portal)
        client = services.client
        session = services.session
        epg = services.epg
        player = PlayerModel(session: services.session, epg: services.epg)
        player.app = self
        startNetworkMonitor()
    }

    private static func makeServices(_ portal: PortalOption) -> (client: PortalClient, session: SessionStore, epg: EPGStore) {
        let version = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "0"
        let terminal = TerminalInfo.appleTV(appVersion: version, osVersion: UIDevice.current.systemVersion)
        let client = PortalClient(baseURL: portal.baseURL, terminal: terminal)
        let macKey = "terminal.macaddr.\(portal.host)"
        #if DEBUG
        // Отладка в симуляторе: `-seedMAC <mac>` подставляет уже привязанный терминал,
        // чтобы не привязывать к аккаунту новый при каждом входе.
        if let seed = UserDefaults.standard.string(forKey: "seedMAC"), !seed.isEmpty {
            KeychainStore().set(seed, forKey: macKey)
        }
        #endif
        let session = SessionStore(api: client, store: KeychainStore(), macKey: macKey)
        return (client, session, EPGStore(source: client))
    }

    // MARK: - Вход

    func start() async {
        route = .launching
        unlockedProfileID = nil
        awaitingProfilePassword = false
        do {
            switch try await session.start() {
            case .needsCredentials:
                clock = await session.clock
                route = .login
            case .signedIn(let a):
                #if DEBUG
                // Отладка пути «первый вход»: экран входа, затем тот же переход, что в signIn,
                // но с уже привязанным терминалом (новый терминал не регистрируется).
                if UserDefaults.standard.bool(forKey: "debugLoginFlow") {
                    route = .login
                    try? await Task.sleep(for: .seconds(3))
                    await apply(a)
                    route = .main
                    player.playInitial()
                    return
                }
                #endif
                await apply(a)
                route = .main
                player.playInitial()
                #if DEBUG
                // Отладка: открыть гид (после того как экран плеера появился — иначе показ игнорируется).
                if UserDefaults.standard.bool(forKey: "debugOpenGuide") {
                    Task { try? await Task.sleep(for: .seconds(1)); showGuide = true }
                }
                #endif
            }
        } catch {
            log.error("start failed: \(String(describing: error), privacy: .public)")
            route = .offline
        }
    }

    func signIn(username: String, password: String) async {
        isBusy = true
        loginError = nil
        defer { isBusy = false }
        do {
            let a = try await session.signIn(username: username, password: password)
            await apply(a)
            route = .main
            player.playInitial()
        } catch let error as PortalError {
            switch error {
            case .unauthorized, .notFound, .server:
                loginError = error.serverMessage ?? strings("login.error.denied")
            default:
                loginError = strings("error.network")
            }
        } catch {
            loginError = strings("error.network")
        }
    }

    func signOut() async {
        do {
            try await session.signOut()
        } catch {
            // Терминал остаётся привязанным — не теряем MAC, остаёмся в аккаунте.
            actionError = strings("error.network")
            return
        }
        refreshTask?.cancel()
        player.stop()
        await epg.clear()
        authorization = nil
        nowPlaying = [:]
        showGuide = false
        route = .login
    }

    func switchPortal(_ option: PortalOption) async {
        refreshTask?.cancel()
        player.stop()
        PortalOption.save(option)
        portal = option
        let services = Self.makeServices(option)
        client = services.client
        session = services.session
        epg = services.epg
        player.configure(session: services.session, epg: services.epg)
        authorization = nil
        nowPlaying = [:]
        await start()
    }

    // MARK: - Обновление

    private func apply(_ a: AuthorizeResult) async {
        authorization = a
        clock = await session.clock
        if let code = a.language?.code, code != strings.language { strings = Strings(language: code) }
        await epg.apply(a.epgInfo)
        player.setIdleTimeout(await session.domain?.autoPauseTimeout ?? 18_000)
        startRefreshLoop()
        if !awaitingProfilePassword, let fallback = a.profileNeedsRevert(unlockedProfileID: unlockedProfileID) {
            log.notice("locked profile without unlock, reverting")
            Task { _ = await selectProfile(fallback) }
        }
    }

    /// Каталог перезагружен (смена подписки, языка, профиля, повторный вход):
    /// убрать пропавшие каналы и дать плееру переключиться, если текущий канал недоступен.
    private func applyCatalog(_ a: AuthorizeResult) async {
        await apply(a)
        nowPlaying = nowPlaying.filter { a.channel(id: $0.key) != nil }
        player.catalogChanged()
    }

    private func startRefreshLoop() {
        refreshTask?.cancel()
        refreshTask = Task { [weak self] in
            while !Task.isCancelled {
                guard let period = await self?.session.updatePeriod() else { return }
                try? await Task.sleep(for: .seconds(period))
                if Task.isCancelled { return }
                await self?.refresh()
            }
        }
    }

    func refresh() async {
        do {
            let r = try await session.refresh()
            clock = await session.clock
            if r.reloaded {
                log.notice("catalog reloaded")
                await applyCatalog(r.authorization)
            } else {
                authorization = r.authorization
                if let info = r.epgInfo { await epg.apply(info) }
            }
        } catch let error as PortalError where error.requiresSignIn {
            log.notice("terminal no longer authorized")
            signOutLocally()
        } catch {
            log.error("refresh failed: \(String(describing: error), privacy: .public)")
        }
    }

    /// Новый session_id (403 стримера, смена сети). Бросает, если терминал отвязан.
    func reauthorize() async throws {
        do {
            let a = try await session.reauthorize()
            await applyCatalog(a)
        } catch let error as PortalError where error.requiresSignIn {
            signOutLocally()
            throw error
        }
    }

    func enteredBackground() {
        guard route == .main else { return }
        player.enterBackground()
    }

    func becameActive() async {
        guard route == .main else { return }
        if awaitingProfilePassword { await cancelProfilePassword() }
        await refresh()
        player.resumeAfterBackground()
    }

    /// Ввод пароля профиля начат, но не завершён (экран закрыт иным путём) — откат.
    func abandonProfilePasswordIfPending() async {
        if awaitingProfilePassword { await cancelProfilePassword() }
    }

    private func signOutLocally() {
        refreshTask?.cancel()
        player.stop()
        authorization = nil
        showGuide = false
        route = .login
    }

    // MARK: - Сеть

    private func startNetworkMonitor() {
        pathMonitor.pathUpdateHandler = { [weak self] path in
            let satisfied = path.status == .satisfied
            guard let model = self else { return }
            Task { @MainActor in model.networkChanged(satisfied: satisfied) }
        }
        pathMonitor.start(queue: DispatchQueue(label: "com.alexvamp.alemtv.network"))
    }

    private func networkChanged(satisfied: Bool) {
        defer { networkWasSatisfied = satisfied }
        guard satisfied, networkWasSatisfied == false else { return }
        Task {
            switch route {
            case .offline:
                await start()
            case .main:
                try? await reauthorize()
                player.reloadCurrent()
            default:
                break
            }
        }
    }

    // MARK: - Каталог

    /// Рубрики для гида: все ТВ-плейлисты кроме избранного и пустых.
    var categoryPlaylists: [Playlist] {
        guard let a = authorization else { return [] }
        return a.playlists.filter { !$0.isFavorites && !a.channels(in: $0).isEmpty }
    }

    func logoURL(for channel: Channel) -> URL? {
        if let logo = channel.logoURL, !logo.isEmpty, let url = URL(string: logo) { return url }
        return channel.channelID.map(portal.logoURL(channelID:))
    }

    /// «Сейчас в эфире» для списка: из расписания на день (см. EPGStore.nowPlaying).
    /// Каналы, у которых сейчас ничего не идёт, из словаря убираются — без устаревших передач.
    func loadNowPlaying(_ channels: [Channel]) async {
        let ids = channels.map(\.id)
        guard !ids.isEmpty else { return }
        let current = await epg.nowPlaying(mediaIDs: ids, languageID: authorization?.language?.id, now: clock.now())
        for id in ids { nowPlaying[id] = current[id] }
    }

    /// Держит «сейчас в эфире» свежим, пока виден список: перезапрос сразу после окончания
    /// самой ранней передачи и не реже раза в минуту. Вызывать из `.task` экрана.
    func keepNowPlayingFresh(_ channels: [Channel]) async {
        while !Task.isCancelled {
            await loadNowPlaying(channels)
            let shown = channels.compactMap { nowPlaying[$0.id] }.filter { $0.isOnAir(at: clock.now()) }
            let delay = NowPlayingRefresh.delay(after: shown, now: clock.now())
            log.info("now playing: \(shown.count)/\(channels.count) on air, next refresh in \(Int(delay)) s")
            try? await Task.sleep(for: .seconds(delay))
        }
    }

    /// Текущая передача канала, если она ещё идёт.
    func program(onAir channel: Channel) -> Program? {
        guard let p = nowPlaying[channel.id], p.isOnAir(at: clock.now()) else { return nil }
        return p
    }

    func rememberLastChannel(_ channel: Channel) {
        Task { try? await client.setTerminalParams(["media_id": .int(channel.id)]) }
    }

    // MARK: - Избранное

    func isFavorite(_ channel: Channel) -> Bool {
        authorization?.favorites?.mediaIDs.contains(channel.id) ?? false
    }

    func toggleFavorite(_ channel: Channel) async {
        guard let favorites = authorization?.favorites else { return }
        let add = !isFavorite(channel)
        do {
            try await client.setFavorite(add, playlistID: favorites.id, mediaID: channel.id)
            await session.applyFavorite(add, playlistID: favorites.id, mediaID: channel.id)
            authorization = await session.authorization
        } catch {
            log.error("favorite failed: \(String(describing: error), privacy: .public)")
        }
    }

    // MARK: - Язык и профиль

    func setLanguage(_ language: Language) async {
        do {
            try await client.setTerminalParams(["language_id": .int(language.id)])
            await epg.clear()
            nowPlaying = [:]
            await applyCatalog(try await session.reload())
        } catch {
            log.error("language failed: \(String(describing: error), privacy: .public)")
        }
    }

    func selectProfile(_ profile: Profile) async -> ProfileChange {
        awaitingProfilePassword = profile.requirePassword && profile.id != unlockedProfileID
        do {
            try await client.setTerminalParams(["profile_id": .int(profile.id)])
            let a = try await session.reload()
            await applyCatalog(a)
            return awaitingProfilePassword && a.profile?.requirePassword == true ? .needsPassword : .done
        } catch {
            awaitingProfilePassword = false
            return .failed(strings("error.network"))
        }
    }

    /// Пароль профиля сверяется с `profile.password` из authorize_terminal (как в портале).
    /// Нет пароля от сервера или неверный ввод — возврат на профиль без пароля.
    func confirmProfilePassword(_ entered: String) async -> Bool {
        guard let profile = authorization?.profile else { return false }
        if profile.accepts(password: entered) {
            unlockedProfileID = profile.id
            awaitingProfilePassword = false
            return true
        }
        await cancelProfilePassword()
        return false
    }

    func cancelProfilePassword() async {
        awaitingProfilePassword = false
        guard let fallback = authorization?.profiles.first(where: { !$0.requirePassword }) else { return }
        _ = await selectProfile(fallback)
    }
}
