import SwiftUI

@main
struct AlemTVApp: App {
    @State private var model = AppModel()
    @Environment(\.scenePhase) private var scenePhase
    /// Был уход в фон: из фона tvOS возвращает через inactive, поэтому смотреть только на
    /// предыдущую фазу нельзя. Запуск приложения (inactive → active) канал не перезапускает.
    @State private var wasInBackground = false

    var body: some Scene {
        WindowGroup {
            RootView()
                .environment(model)
                .preferredColorScheme(.dark)
                .task { await model.start() }
                .onChange(of: scenePhase) { _, phase in
                    switch phase {
                    case .background:
                        wasInBackground = true
                        model.enteredBackground()
                    case .active where wasInBackground:
                        wasInBackground = false
                        Task { await model.becameActive() }
                    default:
                        break
                    }
                }
        }
    }
}
