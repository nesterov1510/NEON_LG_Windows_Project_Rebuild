# IPTVPORTAL: что есть в публичной документации (wiki + ftp)

Дата: 2026-10-03.
Источники:
- весь контент http://wiki.iptvportal.ru: 5 страниц и 52 записи, выгружены через `wp-json/wp/v2/{pages,posts}`;
- публичный ftp, на который ссылается wiki: http://ftp.iptvportal.cloud/doc/ (API PDF v0.3r1, AdminManual v2.1, примеры скриптов) и сборка PC-плеера `ip-tv_player/50.3-2023.01.10/custom/DistrMaker.zip` (смотрел только `Provider.ini` и строки двух DLL).

Нигде не авторизовался. К порталам операторов (в том числе AlemTV, go.iptvportal.ru) запросов не было.

## Резюме: что нового и что расходится с PORTAL_ANALYSIS.md

1. **Клиентский терминальный JSON-RPC в wiki не описан вообще.** Методов `login`, `authorize_terminal`, `get_epg` и других там нет. Документирован только административный JSONSQL (`select/insert/update/delete`), авторизация `authorize_user` и заголовок `Iptvportal-Authorization: sessionid=<sid>`. Восстановленный из JS протокол остаётся единственным источником по клиентскому API.
2. **«Закодирован» + ключ не обязательно означает скремблированный поток (уточнение к §3.5).** Wiki описывает «CAS HLS (контроль сессии)» на Flussonic:
   - у канала `auth="iptvportal"`, ключ (ARESSTREAM/SM/1472 бит/1 ч) и флаг «закодирован»;
   - Flussonic проверяет каждую сессию через `http://DOMAIN.iptvportal.ru/auth/iptvportal/` (`soft_limitation=true`);
   - сам поток не шифруется, ключ нужен только для генерации и ротации токенов.

   Это и есть ветка `iptvportal + key → token=<urlencoded(token1,token2,domain,key,media_id,timestamp)>` из §3.1. Значит, для HLS-каналов AVPlayer, скорее всего, сможет играть поток напрямую, если подставлять свежие токены.
3. **Реальное скремблирование описано только для multicast** (CAS-Encoder, «шифрование Multicast») и для клиентов с дескремблером: VLC-плагин `access_ca` в PC-плеере, arescam на MAG.
4. **Новые методы и параметры** из строк DLL PC-плеера: `get_profiles`, `get_terminal_params`, `registration_id`/`require_registration_id`, `serial_number`, `profile_require_password`, `arescrypt-udpxy`. PC-плеер получает каналы M3U-плейлистом `http://go.iptvportal.ru/playlist.m3u`.
5. **Типы устройств (pprofile):** `smarttv` (все SmartTV, а также Android и iOS с приложением из магазина), `pc`, `stb`, `html-5`. Для каждого типа можно задать серверный udpxy (udp→http). Формат HLS сервер подбирает по типу плеера («Настройки hls» у терминала).
6. **Лимиты терминалов:** `max_terminal_per_subscriber` на домене и `max_terminal` у абонента. Есть опция «Проверять IP при авторизации на видео сервере»: токен привязан к IP терминала.
7. **Про Apple TV/tvOS в документации ничего нет.** Есть только запись «iOS 9.3+».

---

## 1. Клиентский / терминальный API

### 1.1 Что есть в документации
Источники: http://wiki.iptvportal.ru/documentation-api/ (≈ http://iptvportal.ru/doc/api/) и PDF http://ftp.iptvportal.cloud/doc/API/iptvportal_API_v0.3r1.pdf («Протокол IPTVPORTAL JSON-SQL ver.0.3 (07.07.2013)»).

**Сущности:**

| Сущность | Что это |
|---|---|
| `subscriber` | абонент |
| `terminal` | устройство (STB, PC-плеер) |
| `media` | ТВ-канал, VOD и т.п. |
| `service` | timeshift, youtube, ivi… |
| `package` | пакет медиа |
| `key` | ключ условного доступа для закрытого медиа |
| `playlist` | рубрикатор |
| `profile` | возрастной профиль |
| `pprofile` | «профиль плеера, разграничивает медиа по типу терминала (pc, stb, smarttv)» |
| `sprofile` | системный профиль |
| `user` | администратор |
| `domain` | настройки системы |

**Алгоритм работы терминала (текст документации и рис. 2 «Диаграмма взаимодействия» в PDF):**
1. Регистрация: `username, password, mac_addr, inet_addr` → `registration_id`.
2. Аутентификация: `mac_addr, inet_addr, registration_id` → `session_id`.
3. Авторизация: `session_id` → «медиа, ключи, пакеты, …».

Это соответствует `register_terminal` → `login` → `authorize_terminal` в PORTAL_ANALYSIS. Новое здесь — `registration_id`: в JS-портале он не используется, а в PC-плеере есть (см. 1.3). Платный ресурс может иметь `expired_on`, а срок действия контролируется периодом обновления ключа (`update_period`).

**Админ JSONSQL:**
- `POST https://DOMAIN.admin.iptvportal.ru/api/jsonsql/` (в PDF: `admin.DOMAIN.iptvportal.ru`) с заголовком `Iptvportal-Authorization: sessionid=<sid>`;
- сессию выдаёт `POST https://DOMAIN.admin.iptvportal.ru/api/jsonrpc/` → `{"method":"authorize_user","params":{"username","password"}}` → `{"result":{"session_id":"sid"}}`;
- методы `select/insert/update/delete` (PostgreSQL-диалект);
- операторы `and/or/not`, `is/is_not/eq/neq/lt/gt/lte/gte`, `add/sub/mul/div/mod`, `like/ilike`, `in/not_in`;
- подзапросы `{"select":{…}}`, `"from":[{"table":…,"as":…}]`, `{"values":[…],"as":[…]}`, `{"cast":["7 days","interval"]}`.

В Python-примере закомментирован заголовок `Iptvportal-Jsonsql: no-modify`. JS-портал использует для терминала `Iptvportal-Authorization: terminal-sessionid=<sid>`. Это **не противоречит** документации: у администратора префикс `sessionid=`, у терминала `terminal-sessionid=`.

### 1.2 Схема БД (рис. 1 в PDF; таблица `media` также в примерах)
Источник: http://ftp.iptvportal.cloud/doc/API/iptvportal_API_v0.3r1.pdf, стр. 10.

**`domain`:**
- `require_macaddr_auth`, `require_inetaddr_auth`, `require_registration_id`;
- `allow_terminal_reg`, `allow_terminal_unreg`, `allow_anonymous`;
- `show_unavailable_media`;
- `max_terminal_per_subscriber`;
- `parent_id`.

**`terminal`:**
- `subscriber_id`, `mac_addr`, `inet_addr`;
- `profile_id`, `sprofile_id`, `language_id`;
- `registration_id`, `session_id`;
- `registered`, `registered_on`, `logined`, `logined_on`, `anonymous`;
- `type`, `disabled`.

**`subscriber`:**
- `username`, `password`, `max_terminal`, `sprofile_id`, `language_id`;
- ФИО, `email`, `address`, `phone`, `disabled`;
- в расширенной версии также `account_balance`.

**`media`:**
- `name`, `inet_addr`, `protocol`, `port`, `path`, `username`, `password`, `channel_id`;
- `key_id`, `encrypted`, `paid`, `cost`;
- `is_tv`, `is_vod`, `is_nvod`, `is_radio`, `disabled`;
- из примеров: `index`, `timeshift_url`, `timeshift_archive_length` (interval), `is_folder`, `parent_id`, `auth`, `duration` (interval);
- метаданные VOD: `country`, `year`, `director`, `stars`, `genre`, `description`, `rating`, `kp_rating`, `imdb_rating`, `thumbnail_url`, `image_url`, `trailer_url`, `trailer_duration`, `age_limit`, `comment`.

**`key`:** `name`, `algorithm`, `mode`, `size`, `update_period` (interval).

**Связи:**
- `terminal_media`/`subscriber_media` (`expired_on`, `enabled`);
- `terminal_package`/`subscriber_package` (`expired_on`, `enabled`; в расширенной версии `demanded`, `canceled`);
- `package` (`paid`, `cost`, `expiration_period`, `hidden`);
- `package_media`, `package_service`;
- `playlist(is_tv/is_vod/is_nvod/is_radio)` + `playlist_media(index)`;
- `profile` + `profile_media` + `terminal_profile(password)`;
- `pprofile` + `pprofile_media`;
- `sprofile` + `sprofile_media`/`sprofile_service`/`sprofile_inetnum(inetnum_first, inetnum_last)`.

Медиа доступно терминалу, если оно бесплатное, либо входит в пакеты абонента или терминала, и при этом проходит фильтры pprofile/sprofile/profile.

**Пример VOD из PHP-скрипта:** HLS-фильм `http://streamer.net/ch_name_1/index.m3u8` с **`auth:"arescrypt"`**. Значит, `arescrypt` применяется и к HTTP/HLS-контенту, а не только к multicast. Источник: http://ftp.iptvportal.cloud/doc/API/examples/iptvportal-api-example-2020-01-23.php

### 1.3 Методы терминала, найденные в публичном PC-плеере
Источник: http://ftp.iptvportal.cloud/ip-tv_player/50.3-2023.01.10/custom/DistrMaker.zip → `Custom/IpTvPlayer.Plugin.Arescrypt.dll`, Delphi; это строки из бинарника, а не документация.

- **Методы и поля:**
  - `register_terminal`, `check_update`, `get_profiles`, `get_terminal_params`, `set_terminal_params`;
  - `macaddr`, `require_session`, `session_id`, `registration_id`, `require_registration_id`, `serial_number`, `firmware_version`, `language_id`;
  - `profile_id`, `profile_password`, `profile_require_password`, `require_password`, `anonymous`.
- **Тот же механизм `Ares-Cipher`:**
  - строки `Ares-Cipher: `, `arescrypt       ` (IV), AES-CFB/AES, RSA PKCS#1 v1.5;
  - `Content-Type: application/json`, `?sessionid=`.

  Это подтверждает §1.2 PORTAL_ANALYSIS. Кроме того, плагин умеет AES-CFB; возможно, это режим для CA-обмена.
- **Параметры плагина VLC:** `arescrypt-authuri`, `arescrypt-registration-id`, `arescrypt-udpxy`.
- **`Provider.ini`:**
  - плейлист `1um3u="http://go.iptvportal.ru/playlist.m3u"` — **на портале есть M3U-эндпоинт**. Как он авторизуется (по IP или MAC), не описано, и я не проверял;
  - `arescrypt-authuri=https://go.iptvportal.ru/ca/`. У AlemTV по аналогии `ca_auth_uri: https://iptv.tmalem.tv/ca/`.

Сама wiki упоминает это в http://wiki.iptvportal.ru/iptv-player-for-windows/: «заменить в параметрах "1um3u" и "arescrypt-authuri" адрес Middleware».

### 1.4 Push-сообщения
Источник: http://wiki.iptvportal.ru/sending-messages-to-subscribers/ и `send_message_example.php`.

- **Отправка (сервер):** `POST http://DOMAIN.iptvportal.ru/pub?id=<all|user-XXXX|term-0123456789AB>`, тело `text=…|r=10`, `image=URL|t=30`, `video=URL`, `stream=URL`, заголовок `Iptvportal-Authorization: sessionid=…`.
- **Как получает терминал, не описано.** По схеме `pub?id=` похоже на nchan/push-stream, тогда подписка была бы `sub?id=term-<MAC без двоеточий, верхний регистр>`. Это гипотеза.
- В JS-портале на это похожи `msg_queue`/`accept_msg`.
- Опция «расширенной версии», по умолчанию выключена. Работает только на терминалах «с абонентским интерфейсом IPTVPORTAL».

## 2. Шифрование / CA

### 2.1 CAS HLS (контроль сессии) на Flussonic — главный факт
Источник: http://wiki.iptvportal.ru/setup-cas-hls-session-control-using/

> 1. В админке IPTVPORTAL — Ключи — создать любой ключ (например «k1», алгоритм «ARESSTREAM», режим «SM», длина «1472 бит», период обновления «1:00:00»). Ключ может быть один на все каналы, т.к. доступ абонента к каждому каналу всё равно проверяется на стороне IPTVPORTAL.
> 2. ТВ — у каналов в поле Auth (и/или Timeshift Auth) прописать «iptvportal», указать ключ и установить галку «закодирован».
> 3. Flussonic — Auth: Custom, Auth path = `http://DOMAIN.iptvportal.ru/auth/iptvportal/`, extra param `soft_limitation=true` (в конфиге: `auth http://DOMAIN.iptvportal.ru/auth/iptvportal/ soft_limitation=true;`). Для локального Middleware: `http://SERVER_MIDDLEWARE/auth/iptvportal/`.
> Примерное время смены сессии = 3 × время смены ключа. Рекомендуемое время смены ключа — не менее 1 часа.

**Вывод.** В этом режиме Flussonic отдаёт **обычный, нешифрованный HLS**. Каждую сессию он проверяет запросом к IPTVPORTAL по `token`. Токен — это `urlencoded(token1, token2, domain, key, media_id, timestamp)` (§3.1 PORTAL_ANALYSIS, ветка `iptvportal` + `key`).

`token1/token2` выводятся из ключа и меняются с его периодом. Токен остаётся валидным примерно 3 периода, то есть около 3 ч при периоде в 1 ч. Значит, клиент должен регулярно брать свежие `tokens` из `check_update`/`authorize_terminal` и пересобирать URL.

Флаг `encrypted=true` и `key` в medialist у таких каналов **не означают TS-скремблирование**. Это уточнение к §3.5 PORTAL_ANALYSIS: если у канала AlemTV в `auth` стоит `iptvportal` (или `flussonic`) и путь HLS, дескремблер, скорее всего, не нужен. Проверять по-прежнему по `byte[3] & 0xC0` в TS-сегменте.

**ARESSTREAM / SM / 1472 бит:** 1472 бит = 184 байта, ровно столько занимает payload TS-пакета (188 − 4). Это согласуется с потоковым xor-шифром `xxor2` (режим `sm`, ключ до 188 байт) из mpegts.js. Вероятно, на клиенте ARESSTREAM приходит как `ctxxor2`/`aresfast2`; это гипотеза. Рекомендуемая конфигурация ключа в руководстве та же: http://wiki.iptvportal.ru/operator-version-manual/ (раздел «Ключи»), AdminManual v2.1, стр. ~18.

### 2.2 Поле Auth (руководство администратора)
Источник: http://wiki.iptvportal.ru/operator-version-manual/

- **Auth / Timeshift auth:** «Тип авторизации (запроса ключей), используемый на стримере, указывается при настройке CAS HLS (контроля сессии). Если CAS HLS не используется — оставить пустым». Задаётся для ТВ, VOD, NVOD, радио и камер.
- **«Закодирован»:** «Если ВКЛ, то терминал будет передавать канал на декодирование модулю CAS». **«Ключ»:** «ключ, которым будет закодирован канал».
- Список допустимых значений Auth в wiki не приведён. Из JS (PORTAL_ANALYSIS §3.1) известны `flussonic`, `iptvportal`, `wowza`, `nimble`, `wmsAuthSign`, `arescrypt`, `custom`. В PHP-примере VOD с `auth:"arescrypt"`.
- **Настройки → «Проверять IP при авторизации на видео сервере»:** «авторизация на видео сервере будет разрешена только если IP при запросе к видеосерверу совпадает с IP терминала в БД». Если оператор это включил, а «Автообновление IP адреса» выключено, токен работает только с IP регистрации.
  - Для tvOS это значит: сеть запросов JSON-RPC и сеть видеозапросов должны совпадать, без разных путей IPv4/IPv6.
  - При смене сети нужен повторный `login`.

### 2.3 CAS для multicast (настоящее скремблирование)
Источники: http://wiki.iptvportal.ru/server-parameters-cas/, руководство (разделы CAS → Стримеры/Кодеры/Ключи/Кодирование).

- CAS-Encoder — отдельный сервер. Он берёт входной поток (адрес, порт, интерфейс), шифрует ключом и выдаёт на выходной интерфейс.
- Wiki приводит требования к серверу: 1 ядро и 1 ГБ на 200 Мбит/с, Intel NIC с multi-queue.
- Декодирование на клиенте: MAG — arescam плюс `arescrypt.ko`; PC-плеер — VLC-модуль `libaccess_ca_plugin` со строками `ARESCRYPT … sm_decrypt`, `ca-cascade`, `truncated cap header found`. То есть PC-плеер дескремблирует сам, ключи берёт из CA (`arescrypt-authuri`).
- **Как работают SmartTV- и мобильные приложения с зашифрованным multicast, wiki не описывает.** Единственная подсказка — серверный udpxy для каждого типа устройства (раздел 4). Описанного сценария «сервер сам дешифрует для мобильных» в документации **нет**.

### 2.4 Что не нашлось
- aresproxy, `token1/token2`, `Ares-Cipher`, HTML5-дескремблер, `/ca/` API: в wiki не описаны.
- Отдаёт ли Flussonic расшифрованный поток по arescrypt-токенам: документально не подтверждено. Подтверждено лишь, что в схеме «iptvportal + ключ + закодирован» с Flussonic поток изначально не шифруется, а ключ служит для контроля сессий.

## 3. Таймшифт / архив / EPG

**Flussonic** (источник: http://wiki.iptvportal.ru/setting-timeshift-catchup-using-flussonic/):
- в Настройках включить «Использовать TimeShift»;
- у канала задать `timeshift url` вида `http://FLUSSONIC_SERVER:PORT/MEDIA_NAME` (без имени файла) и «глубину архива» вида `7 days, 0:00:00` (тип interval);
- сервису `timeshift` назначить пакеты (и sprofile).

Это **подтверждает** §3.3 PORTAL_ANALYSIS: клиент сам дописывает `index-<start>-<dur>.m3u8` / `timeshift_rel-…`, а доступ к архиву даёт сервис `timeshift` в `services_enabled`. В PHP-примере `timeshift_url = "http://streamer.net:80/ch_name_1"` и `timeshift_archive_length = {"cast":["7 days","interval"]}`.

**Руководство** (http://wiki.iptvportal.ru/operator-version-manual/):
- `Timeshift offset` — сдвиг архива в часах, например при записи в другой зоне;
- `Epg tz` / `Epg offset` / `Ignore epg tz` / `Epg провайдер` / `Epg channel id` (XMLTV custom EPG) настраиваются на стороне сервера, клиент получает уже приведённое время;
- `Stream backend` / `Timeshift backend` (flussonic, astra): «запросы контента будут идти по API этого стримера»;
- «Использовать таймшифт thumbnails» и «таймшифт thumbnails прокси»;
- «Использовать Timeshift прокси»: подмена адреса timeshift-стримера (глобально или в системном профиле).

**Рекомендуемый формат контента:** HLS, H.264 + AAC (http://wiki.iptvportal.ru/recommended-content-format/). Это подходит для AVPlayer.

**Юникаст-прокси и sprofile** (http://wiki.iptvportal.ru/clustering-streamers-for-groups-ab/): сервер подменяет адрес стримера в выдаче по системному профилю (по IP абонента). Клиенту не нужно ничего переписывать, URL приходят уже подменёнными.

## 4. Устройства, Apple TV / iOS, SmartTV, pprofile

**Устройства просмотра (pprofile)**, раздел «Устройства просмотра» руководства (http://wiki.iptvportal.ru/operator-version-manual/):

> Типы устройств: **smarttv** — все смарттв, Android и iOS, где используется приложение IPTVPORTAL из маркета; **pc** — PC-плееры и некоторые приставки с собственным интерфейсом; **stb** — приставки, кроме Android; **html-5** — веб-браузеры.
> Для каждого типа: «Использовать udpxy» + «Адрес udpxy» (ip:порт) — udp-потоки преобразуются в http.

Отсюда:
- нативное iOS/tvOS-приложение по классификации платформы относится к **`smarttv`**;
- если оператор задал udpxy для smarttv, multicast-каналы придут уже в виде HTTP;
- в JS значение `"html5"`, а в админке тип называется `html-5`;
- Настройки → «Использовать профили устройств просмотра»: медиа видны только терминалам подходящего типа. Набор каналов для smarttv и stb может отличаться.

**Терминал** (руководство, раздел «Терминалы»):
- «Тип» и «Прошивка» определяются автоматически; это `terminal_type` и `firmware_version` из `login`/`register_terminal`;
- «Устройство просмотра» определяется автоматически, но его можно задать принудительно;
- «Настройки hls»: «Платформа автоматически определяет тип плеера и подбирает оптимальный формат HLS, если указан stream/timeshift backend (Flussonic или Astra). При необходимости формат можно указать принудительно». Это `settings`/`hls_profile` (`index|video|mono|apple`) из `authorize_terminal`. Значение `apple` в JS говорит о том, что для Apple-плееров есть отдельный профиль.

**Приложения:**
- **iOS:** «Поддерживаются мобильные устройства с версией iOS 9.3 и выше» (http://wiki.iptvportal.ru/ios-mobile/). Про **tvOS/Apple TV в wiki ничего нет**.
- **Android / Android TV:** приложение `ru.iptvportal.stb`, Android 4.0+. APK в вариантах `launcher`/`market`/`stb`/`rustore`, последняя версия v1.262 от 2026-03-12: http://ftp.iptvportal.cloud/android/. См. http://wiki.iptvportal.ru/android-mobile/ и http://wiki.iptvportal.ru/android-tv-platform/.
- **Samsung:** с 2012 года (Orsay, Tizen); Orsay не обновляется с 2018 года. **LG:** Netcast 4.0/4.5 и webOS. **FOXXUM:** Sharp, Toshiba, Hisense и др. User-Agent и `terminal_type` для этих приложений не указаны.
- **PC (Windows):** IP-TV Player (borpas) + VLC с CA-плагином; Middleware `go.iptvportal.ru` (cloud) или `go.iptvportal.local` (local).
- Общий портал `go.iptvportal.ru` перенаправляет на `DOMAIN.iptvportal.ru` по «Диапазонам IP».
- По http://wiki.iptvportal.ru/difference-platform-cloud-from-platform-local/: в локальной версии «бытовым смартТВ, где приложение ставится через маркет, всё равно требуется выход в интернет». AlemTV, судя по `telecom.alemtv.tm` / `iptv.tmalem.tv`, — Local-инсталляция.

## 5. Терминалы: лимиты, регистрация, отвязка

Источники: http://wiki.iptvportal.ru/documentation-api/, http://wiki.iptvportal.ru/operator-version-manual/, http://wiki.iptvportal.ru/types-of-authorization-and-their-settings/

**Лимиты:**
- **`max_terminal_per_subscriber`** (домен): «Максимальное количество авторизованных терминалов для одного абонента», значение по умолчанию;
- **`max_terminal`** (абонент): «Макс. терминалов», переопределяет доменное значение.

Конкретных значений для AlemTV в `get_domain_config` нет: поле не отдаётся, его видно только в админке. При превышении лимита `register_terminal` откажет; текст ошибки в документации не описан.

**Регистрация и отвязка:**
- **`allow_terminal_reg`:** регистрация терминала логином и паролем с устройства. Если выключено, регистрирует только админ, в том числе вручную по MAC.
- **`allow_terminal_unreg`** («Разрешить перерегистрацию»): на устройстве показывается кнопка «Выход», и абонент сам снимает регистрацию («смена оборудования»). Это `unregister_terminal`. У AlemTV `true`, значит место в лимите можно освободить из приложения.

**Виды авторизации:**
1. Анонимный вход: только бесплатные пакеты; `allow_anonymous`, у AlemTV `false`.
2. Логин и пароль.
3. По MAC: терминал заранее заведён в админке.
4. По IP: у абонента задан IP или диапазон, и терминал с этого IP авто-регистрируется без пароля.

**MAC и IP:**
- «MAC-адрес — именно MAC сетевого интерфейса терминала». Платформа считает MAC идентификатором терминала. Для tvOS это серверный псевдо-MAC (`create_macaddr`), хранить его в Keychain (как в PORTAL_ANALYSIS).
- «Автообновление IP адреса»: IP терминала обновляется при каждом подключении либо фиксируется при регистрации. Важно вместе с проверкой IP на видеосервере (раздел 2.2).

**Поля терминала в админке:** «Последнее время активности», «Время авторизации», «Время регистрации», «Анонимный вход», «Отключен», «Профили» (сохранённый пароль 18+ сбрасывается удалением записи).

## 6. Практические выводы для tvOS
1. Тип клиента — `smarttv`. В `login` передавать стабильный `terminal_type` и `firmware_version`: платформа показывает их админу и по ним выбирает HLS-профиль.
2. **Первое, что проверить на реальных данных** после `authorize_terminal`: значения `auth`/`timeshift_auth`/`encrypted`/`key` у каналов.
   - Если `auth` содержит `iptvportal` (или `flussonic`) и путь HLS, это, по всей видимости, «CAS HLS (контроль сессии)»: поток чистый, нужен только `token=` с актуальными `tokens` (обновлять по `check_update`, укладываясь в окно около 3 × `update_period` ключа).
   - Если `arescrypt` или multicast, вероятно настоящее скремблирование, и тогда нужен путь с дескремблером.
3. Учитывать возможную привязку токена к IP: после смены сети повторять `login`/`authorize_terminal`.
4. Лимит терминалов и самостоятельная отвязка: в настройках приложения держать «Выйти из аккаунта» (`unregister_terminal`), чтобы освобождать слот.
5. Есть публичные источники для дальнейшего реверса без обращения к оператору: Android APK `ru.iptvportal.stb` v1.262 (UA, `terminal_type`, работа с arescrypt в нативном коде) и CA-плагины PC-плеера.
