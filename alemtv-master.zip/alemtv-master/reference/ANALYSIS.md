# AlemTV (iptvportal.alemtv 1.266.0-modern): статический анализ Android-клиента

Дата: 2026-10-03. Метод: только статика (jadx 1.5.6 + Temurin JDK 21 в scratchpad; `strings`/`file` для нативного бинарника). APK и aresproxy не запускались, сетевых запросов к бэкенду не было.
- Декомпиляция: `reference/decompiled/` (`sources/`, `resources/`).
- Код приложения: `decompiled/sources/ru/iptvportal/stblib/` (24 файла, ~16,5 тыс. строк; ~5,7 тыс. в MainActivity.java).

## 0. Главный вывод
APK — тонкая WebView-оболочка для серверного веб-портала IPTVPORTAL. В APK нет экранов эфира, EPG, архива, VOD, избранного, родительского контроля, профилей и поиска, и нет клиента API: ни Retrofit, ни моделей, ни JSON-запросов к порталу. Весь UI и вся логика — HTML/JS с сервера:

    http://telecom.alemtv.tm/?screen=1280x720&manufacturer=..&brand=..&product=..&model=..[&fullscreen][&mobile]
      &apk_id=iptvportal.alemtv&apk_version=1.266.0-modern&apk_type=market[&debug][&aresproxy][&engine=mpegts]&dc=<ms>[&media_id=..]
(MainActivity.getParameters() стр. 2242, webViewLoadUrl() стр. 4910)

Нативная часть:
1. JS-мост `window.stb`, совместимый с Infomir MAG250;
2. нативные настройки;
3. дешифрующий релей aresproxy (Astra 0.2.115 + arescrypt).

API портала по APK не восстановить, см. раздел 4.4.

## 1. Структура
- Application: com.pairip.application.Application (Google Play integrity/licensecheck; VM-обфускации app-кода нет).
- ru.iptvportal.stblib.MainActivity: WebView, SurfaceView, мост stb, сцены SceneW {Loading, Settings, Web, ConnectError, Error, StopLoading}.
- Settings.SettingsActivity/SettingsFragment (res/xml/settings_screen.xml); Receivers.BootReceiver.
- Players: Media3 (по умолчанию), ExoPlayer (exoplayer2), VLCPlayer (libVLC), NativePlayer/NativePlayerExt (MediaPlayer), IJK (через reflection, класса нет), HTML5 (mpegts.js в портале).
- Controller.Controller: мультипорталы, детект фризов, перезапуск потока.
- WebInteraction.WebRunnable: javascript:stb_onEvent('ended|seeked|canplay|error|sleep|wakeup').
- AppLogReader: http://log.iptvportal.cloud/?log_id=<MAC>.
- Нативные либы (сплиты): libvlc.so (43 МБ), libvlcjni, libffmpegJNI (Media3 FFmpeg ext), libavcodec/avutil/swresample/avresample, libc++_shared.
- assets/aresproxy: ELF32 ARM EABI5, static, stripped, 1 111 400 байт.
- Manifest: одна Activity с LAUNCHER и LEANBACK_LAUNCHER, leanback required=false, баннер @drawable/alem. Отдельного Leanback-UI нет: на TV и mobile один портал (отличия — &fullscreen/&mobile, UA ..._TV_/_Mobile_, IFaceType {NON_TV, TV, TV_Multicast}).
- network_security_config: cleartext разрешён, доверие к user CA. Портал работает по http:// (https только для go.kootv.ru).

## 2. Конфигурация оператора
strings.xml:
- app_name=ALEM TV; default_portal_url=telecom.alemtv.tm; enable_multi_portal=yes; enable_edit_portal_url=yes.
- url_update_config=http://iptv.tmalem.tv/download/android_update_config.json (резерв http://update.iptvportal.cloud/android/tmalem/).
- player_type=Media3; interface_type=auto.
- enable_aresButton=no (DRM-переключатель скрыт, ENABLE_ARESPROXY=false); aresproxy_version=aresproxy v0.2.115.
- app_settings_password_default=1412.

Мультипорталы (Controller.setMultiPortalDefault):
- 0 Turkmentelekom telecom.alemtv.tm (default)
- 1 АSTU astu.tmalem.tv
- 2 Arkadag ark.alemtv.tm
- 3 АSTU Local local-astu.alemtv.tm

Конфиг: {"multi_portal":[{portal_name, portal_url, is_default, config_url}]}, обновления: [{apk_id, apk_type, <версия>, apk_url, downgrade}]. К запросу добавляются &portal_url=..&mac_addr=..
Демо-портал: nextouch.iptvportal.ru.
Брендинг: mipmap-*/alem.png, alem_round.png, drawable/alem.png; тема — чёрный фон, акцент holo_orange_dark (#FF8800). Остальное приходит с портала.

## 3. Карта функций
3.1 Нативные (TV и mobile):
- загрузка портала, сплэш и ошибки;
- мультипортал и ручной URL;
- выбор плеера (Media3/Exo/VLC/Native/EXT/HTML5), HW/SW-рендер, задержка создания, OkHttp HTTP/1.1/2, туннелирование;
- автозамена плеера (use_auto_player);
- автоперезапуск при фризе (Controller.checkFreez: 6 тиков без движения позиции);
- тип устройства Mobile/TV/STB-мультикаст;
- автозапуск (TV);
- пароль на настройки;
- ярлык (mobile);
- удалённые логи;
- deep link ?media_id=;
- TalkBack/TTS (mobile);
- громкость UP/DOWN (TV);
- цветные кнопки → F1–F4 (131–134), долгое OK → F4;
- режим лаунчера: getApps/launchApp/installApp/checkApp/getAppIcon.

3.2 Функции портала (по мосту stb):
- live: play(url,"stream") — repeat, детект фризов, переподключение;
- VOD/архив: play(url, mime≠stream), getPosition/setPosition(сек)/GetMediaLen, события seeked/ended;
- перемотка: playSpeed(url, 0<speed≤2);
- таймшифт: отдельного API нет (портал переключает на архивный URL);
- pause/continuePlay/stop;
- аудиодорожки: getAudioLanguages/getAudioPID/setAudioPID;
- субтитры: заглушки;
- SetAspect/SetViewport (мини-окно), SetWinAlphaLevel;
- playBg(url,state,type,speed) + bgPlayerPrepared(): фоновый второй плеер для бесшовного переключения;
- громкость и mute;
- storagePut/Get/Remove/GetAll/GetAllJSON;
- getMacAddress/RDir("MACAddress")/setMacAddress, RDir("Model")="MAG250";
- checkAres/aresproxyAvailable/arescamAvailable/getPathAresproxy/execCmd/jsonRpc;
- isMulticastAvailable;
- finish/openSettings.

EPG, избранное, родительский контроль, профили, поиск и ЛК в APK отсутствуют — проверять на портале.

## 4. Бэкенд
4.1 Хосты (подтверждено):
- портал telecom.alemtv.tm (+3 альтернативных);
- конфиг iptv.tmalem.tv, резерв update.iptvportal.cloud;
- логи log.iptvportal.cloud;
- CAS https://go.iptvportal.ru/ca/ (из aresproxy).

UA WebView: "IPTVPORTAL - ARES_Android_TV_v001 - Android - <ver>! &apk_id=iptvportal.alemtv&apk_version=1.266.0-modern&apk_type=market&<UA>".
UA плеера: Util.getUserAgent(ctx,"app"). Токенов, заголовков и cookie к медиа нативный код не добавляет. Портал грузится с LOAD_NO_CACHE; cookie и WebStorage стираются при выходе.

4.2 Авторизация:
- терминал = MAC. getHW(): NetworkInterface eth0→wlan0→любой; /sys/class/net/eth0/address (баг: ветка wlan0 недостижима — eth0 проверяется дважды); кеш SETTINGS:HW; портал может задать MAC через setMacAddress. На Android 10+ MAC скрыт → вероятно, портал назначает свой;
- эмуляция MAG250 (Img_Ver 0.2.18-r8-250, "…-ares-5");
- логин/пароль вводятся в форме портала. aresproxy-команды login/register_terminal(-u,-p)/unregister_terminal/get_media_keys(macaddr) → абонент привязывает MAC к аккаунту;
- activation code не найден;
- проверок IP/гео в APK нет (возможны на сервере).

4.3 Публичные сведения IPTVPORTAL (не из APK, гипотеза): JSON-RPC 2.0 authorize_user (/api/jsonrpc/) → session_id; JSONSQL /api/jsonsql/ (select/insert/update/delete, params {data, from, where, order_by, limit}) с заголовком Iptvportal-Authorization: sessionid=… — в основном админский API; клиентский может отличаться.

4.4 Как снять реальный протокол: WebView.setWebContentsDebuggingEnabled(true) включён без условий (MainActivity:4675). На своём Android-устройстве — chrome://inspect → Network/Sources: авторизация, каналы, EPG, архив, VOD, вызовы stb.play/playSpeed/execCmd (URL потоков, схема архива, аргументы aresproxy).

## 5. Потоки
- HLS → Media3 HlsMediaSource (TS flags 17);
- udp:// и rtp:// multicast → Media3 UdpDataSource+Progressive / VLC "udp://@" (--udp-timeout=10000 --ttl=1 --ts-cc-check --demux=avformat);
- HTTP MPEG-TS progressive (&engine=mpegts для HTML5);
- через aresproxy: http://127.0.0.1:<port>/udp|rtp|http/...;
- RTSP-модуль есть, но не используется; DASH и Widevine/PlayReady отсутствуют;
- URL нативно не меняется. Архив — конечный ресурс с seek в секундах и скоростью ≤2x, параметры времени задаёт портал. Таймшифт — тем же механизмом.
- FFmpeg ext (программно): ac3, eac3-joc, dts, mp2/mpeg-L2, amr-wb, vorbis, mp4a-latm, avc, hevc.
- VLC (--avcodec-hw any/none, deinterlace, caching 1000/6000): для MPEG-2 SD interlaced и битого UDP-TS.
- Автовыбор плеера: udp без aresproxy → Media3; mime h264/mp4 → Native; mpeg/mp2 → Exo.

## 6. aresproxy
Запуск: installAresproxy() копирует ассет в files/aresproxy и делает chmod +x; checkAresproxyVer по --version. Командную строку формирует портал через stb.execCmd или stb.jsonRpc({"method":"exec","params":[cmd]}) → Runtime.exec (только в сцене Web). arescam — внешний бинарник на STB.
Состав: Astra 0.2.115 (Lua 5.2), libcurl+PolarSSL, c-ares, json-c, встроенный Lua-скрипт.
Опции:
- --relay, --relay-addr (0.0.0.0), --relay-port (8000), -i iface;
- --relay-buffer-size 1024K / --relay-buffer-fill 128K;
- --auth-uri (default https://go.iptvportal.ru/ca/), --macaddr;
- -l/-r/-U/-k, -u/-p, -d, --log, --debug, -v.
Маршруты: /udp/[iface@]addr:port, /rtp/addr:port, /http/host[:port]/path (UA "Aresproxy", 301/302, Basic-auth).
CAS: JSON-RPC (login, register_terminal, unregister_terminal, get_media_keys; macaddr, version, username, password). Тело — AES+base64, заголовок Ares-Cipher. В бинарнике RSA-1024 модуль cf2cde33…c025 и e=10001. Ответ: medialist/keymap/values/update_period/algorithm/mode/blocksize; protocol/daddr/dport/path/key_name.
Алгоритмы: ctxxor, ctxxor2, aresfast, aresfast2, gost89 — проприетарный скремблинг TS с периодической сменой ключей.
Для AlemTV DRM-кнопка скрыта, флаг &aresproxy не передаётся; использование шифрования неизвестно (смотреть execCmd в JS портала).

## 7. Риски для tvOS
1. На tvOS нет WKWebView → нативный UI и своя реализация API портала.
2. API неизвестен → снять по 4.4.
3. MAC/MAG-идентификация → псевдо-MAC в Keychain, тот же UA и параметры, привязка терминала через логин/пароль; учитывать лимит устройств.
4. UDP multicast → AVPlayer не умеет; нужен entitlement com.apple.developer.networking.multicast + VLCKit. Лучше брать HTTP/HLS (isMulticastAvailable=false).
5. Сырой HTTP-TS → AVPlayer не играет; TVVLCKit либо свой ремукс TS→HLS/fMP4 (локальный сервер / AVAssetResourceLoader).
6. Кодеки: MPEG-2 video, MP2, DTS, interlaced — не для AVPlayer → TVVLCKit. Гибрид: AVPlayer (HLS H.264/HEVC/AAC/AC-3) + VLCKit fallback.
7. Проприетарное шифрование arescrypt: бинарник на tvOS не запустить (нет exec). Если каналы зашифрованы — только переписывать arescrypt на Swift (юридически рискованно, нужно разрешение оператора) или просить HLS у оператора. Главный критерий «делать или нет».
8. Архив/таймшифт: схема неизвестна. HLS VOD → AVPlayer; HTTP-TS → VLCKit.
9. Геоблок/сеть провайдера (.tm, local-astu, мультикаст) → проверить доступность, возможно VPN в TM.
10. HTTP без TLS → ATS-исключения (alemtv.tm, tmalem.tv, iptvportal.cloud) или NSAllowsArbitraryLoads(ForMedia).
11. Пульт: D-pad и цветные F1–F4 → focus engine и контекстные меню.
12. Субтитры не нужны (в оригинале заглушки).

## 8. Ключевые файлы
- MainActivity.java: мост 346–1240; aresproxy 1263–1565; MAC 1568–1669, 2298; плееры 2103–2240; URL 2242; init 2357–2610; WebView 4620–4860; loadUrl 4910; клавиши 5300–5490.
- Controller/Controller.java; Players/Media3.java, VLCPlayer.java, ExoPlayer.java; WebInteraction/WebRunnable.java.
- resources/res/values/strings.xml, arrays.xml, xml/network_security_config.xml, xml/settings_screen.xml; resources/assets/aresproxy.
