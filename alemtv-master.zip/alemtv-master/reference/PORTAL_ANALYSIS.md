# AlemTV / IPTVPORTAL: клиентский протокол веб-портала (статический анализ)

Дата: 2026-10-03.
Источники:
- `portal/static/portal/terminal/mag200/system.js` — сборка для MAG;
- `portal/static/portal/terminal/iptvportal/system.js` — сборка, которую сервер отдаёт Android-приложению по UA `IPTVPORTAL - ARES_Android_TV…`; эту же сборку использует iOS-обёртка IPTVPORTAL;
- кастомные `hls.js` и `mpegts.js`;
- локали, CSS;
- один анонимный `get_domain_config`.

Сеть: только GET статики плюс один анонимный POST `get_domain_config`. Авторизации не было, к CA не обращался.
Строки вида «sys.js:NNNN» указывают на номер строки в prettier-версии system.js (mag200), если не сказано иное. Чтобы получить её: `npx prettier@3 --parser babel system.js`.

## Резюме

- **Транспорт.** JSON-RPC 2.0, `POST http://telecom.alemtv.tm/jsonrpc/<method>`, тело `{"jsonrpc":"2.0","id":N,"method":M,"params":{…}}`.
  - До логина в params подставляется `macaddr`, после логина — `session_id`. Отдельного заголовка авторизации нет; исключение — JSONSQL `./jsonsql/` с заголовком `Iptvportal-Authorization: terminal-sessionid=<sid>`.
  - Чувствительные вызовы (`login`, `register_terminal`, `unregister_terminal`, `update_profile`) идут зашифрованными: AES-128-CBC + base64, сессионный ключ передаётся в заголовке `Ares-Cipher` под RSA-1024. Ключ тот же, что в aresproxy.
- **Авторизация.** Цепочка: `get_domain_config` → `login` (по MAC; если MAC нет — `create_macaddr:true`, сервер выдаёт MAC) → при отказе форма логин/пароль → `register_terminal` → `session_id` → `authorize_terminal` (version 2, result_as csv). Последний одним ответом отдаёт всё: каналы, пакеты, плейлисты, меню, профили, языки, токены и ключи дескремблирования. Затем каждые 300 с вызывается `check_update`.
- **Потоки.** Используется Flussonic (`stream_backend`/`timeshift_backend` = `flussonic`).
  - Live: `protocol://host:port/path[?token=<session_id>]`.
  - Архив: `<timeshift_url>/index-<startUTC>-<duration>.m3u8`.
  - Таймшифт: `<base>/timeshift_rel-<секунд_назад>.m3u8`.
  - Мультикаст определяется по host 224–239.x и может перенаправляться через `mcast_proxy_url`.
- **Шифрование.** У домена `use_ca: true`, `ca_auth_uri: https://iptv.tmalem.tv/ca/`. Часть каналов зашифрована: флаг `encrypted` и `key` в medialist.
  - Скремблирование — TS-level (биты transport_scrambling_control), ключи нечётный/чётный.
  - Алгоритмы: aes / gost89 / csa / arc4 / ctxxor2 / aresfast2; режимы ecb/cbc/cfb/ofb/sm.
  - Полная реализация дескремблера есть **в JavaScript** (кастомные mpegts.js/hls.js, опция `ts_cipher`). Ключи приходят в `authorize_terminal`/`check_update`, если передать `require_media_keys:true`. Значит, на tvOS дескремблирование переносимо в Swift без aresproxy, но для этого нужен собственный TS-конвейер (AVPlayer сам не справится).
  - Android-сборка помечает зашифрованные каналы auth=`arescrypt` и добавляет к URL `token1/token2/domain/key/media_id/timestamp` (см. п. 3.5). aresproxy запускается только при `&aresproxy` в URL, а AlemTV его не передаёт.
- **EPG.** `get_epg` по `media_id` и дню. Время приходит строками `YYYY-MM-DD HH:MM:SS+ZZZZ`, у Туркменистана `+0500`. Глубина архива: `timeshift_archive_length` (секунды) канала или `timeshift_available_since` аккаунта.
- **Языки.** ru (по умолчанию), en, tk (туркменский), файлы `/resources/portal/locale/<iso>.js`. Названия меню и плейлистов приходят с сервера (`use_language_translation: true`).
- **Брендинг.** Шрифт Noto Sans, акцент `#ffb000`, тёмная тема (`#000`/`#444`/`#eee`). Логотипы каналов: `/resources/portal/images/logo{44|56|84|96}/<channel_id>.png` или `logo_url`.

---

## 0. Скачанные файлы (reference/portal/)

| Файл | Что это |
|---|---|
| `index.html` | страница портала для UA MAG (`terminal/mag200/system.js`) |
| `index.android.html` | та же страница для UA Android-APK: грузит **`terminal/iptvportal/system.js`** |
| `index.browser.html` | для десктоп-Safari: `terminal/vlc/system.js` (не скачивал) |
| `static/portal/terminal/mag200/system.js` | 587 КБ, сборка MAG (gSTB, arescam) |
| `static/portal/terminal/iptvportal/system.js` | 577 КБ, сборка для Android-APK и iOS-обёртки (`window.stb` / `webkit.messageHandlers`) |
| `static/portal/player/hls/hls.js`, `.../mpegts/mpegts.js` | кастомные плееры с дескремблером `ts_cipher` |
| `jsonrpc/get_domain_config.json` | ответ анонимного `get_domain_config` |
| `download/startup.js` | `startup_url` домена: блок-лист UA |
| `resources/portal/locale/{ru,en,tk}.js` | локали: JSON, 227/228/226 ключей |
| `resources/portal/portal-*.css`, `portal-fonts-*.css` | темы classic/modern/mobile/apps, шрифты |

---

## 1. API

### 1.1 Транспорт JSON-RPC (sys.js:11083–11190, `I.jsonRpc`)

```
POST http://telecom.alemtv.tm/jsonrpc/<method>
Content-Type: application/x-www-form-urlencoded; charset=UTF-8   (тело — сырой JSON; application/json сервер тоже принимает)
[Ares-Cipher: <base64>]   — только для шифрованных вызовов
```
Тело:
```json
{"jsonrpc":"2.0","id":7,"method":"get_epg","params":{"session_id":"…", "...": "..."}}
```
- URL относительный: `"./jsonrpc/" + method`. Если задан `Iptv.standalone_domain`, к нему добавляется домен. Для внешних сервисов в `url` может стоять абсолютный адрес.
- Подстановка идентификатора (sys.js:11096):
  ```js
  if (!params || !params.macaddr)
    if (u.Ic /*session_id*/) params = {session_id: u.Ic, ...params}
    else params = {macaddr: V.ae() /*MAC*/, ...params}
  ```
- Для одиночного вызова в params добавляется `pprofile`:
  - `?pprofile=` из URL;
  - `"html5"`, если домен задаёт `pprofiles` с ключом html5 и движок mpegts/videojs;
  - `"smarttv"`;
  - `"stb"`, если доступен мультикаст.

  Видимо, от `pprofile` зависит, какие URL потоков вернёт сервер.
- Batch: если method — массив, отправляется массив запросов.
- Ошибки: `error.code == -32003` означает «не авторизован / доступ запрещён». Портал показывает `error.message` и при `allow_terminal_reg` открывает форму входа (`u.ei()`).
- JSONSQL (sys.js:11180):
  ```
  POST ./jsonsql/   Iptvportal-Authorization: terminal-sessionid=<session_id>
  {"jsonrpc":"2.0","method":"select","params":{"data":[…],"from":[…],"where":{…},"order_by":[…],"limit":N,"offset":M}}
  ```
  Используется только приложением iRadio (таблицы `radio_station`, `radio_directory`, `radio_station_genre`, `radio_genre`). Каналы и VOD через JSONSQL не запрашиваются.

### 1.2 Шифрование запросов `Ares-Cipher` (sys.js:10997–11050, 4462)

Включается шестым аргументом `jsonRpc(..., true)` при `Q.crypto=true` (по умолчанию true в обеих сборках). Шифруются вызовы `login`, `register_terminal`, `unregister_terminal`, `update_profile`.

1. Генерируется случайный 16-байтный ключ `K`.
2. Собирается заголовок по struct `"<H16s8s8sHHHHL"`: `[1, "aes", "cbc", "base64", 128, 16, 46, 62, unix_ts]` (46 байт). С offset 46 идёт `K` (16 байт), с offset 62 — IV `"arescrypt       "` (`61 72 65 73 63 72 79 70 74` + 7 пробелов). Итого 78 байт.
3. Блок шифруется RSA PKCS#1 v1.5 (чанками), публичный ключ:
   - n = `cf2cde3395737e94f0f0ca7474797d285170eb7acd41628a946f92a00138225a23c2b7307da8c182536bfa325d7a111dc82eb0825c85614d807b46bdc0bea8231dde941b2d435782dabed3381b48f30aa19bff261eec4086b56d5c45ea394b8f386d1ad75b7e8c5d37d517e83e598719afb2b05b790e41f132858321f693c025`;
   - e = 65537.

   Результат в base64 уходит в заголовок `Ares-Cipher`.
4. Тело — JSON (UTF-8), зашифрованный AES-128-CBC ключом K с тем же IV, в base64.
5. Ответ расшифровывается так же (AES-128-CBC, K, IV `arescrypt␠×7`), затем декодируется UTF-8.

Принимает ли сервер `login` без шифрования, неизвестно. `get_domain_config` сервер принимает открытым текстом.

### 1.3 Все вызываемые методы

| Метод | Когда | params (из кода) | Ответ (используемые поля) |
|---|---|---|---|
| `get_domain_config` | старт, до логина | `{terminal_type}` (+`macaddr`) | конфиг домена, §1.4 |
| `login` (шифр.) | автологин по MAC | `{macaddr|null, create_macaddr: true если MAC нет, require_session:true, require_user_id:true, terminal_type, firmware_version}` | `{session_id, user_id, macaddr?}`; ошибка → `extra.macaddr` |
| `register_terminal` (шифр.) | форма логин/пароль | `{username, password, macaddr|null, create_macaddr, require_session:true, require_user_id:true, terminal_type, firmware_version}` | `{session_id, user_id, macaddr?}`; `false`/error → «Доступ запрещен» |
| `unregister_terminal` (шифр.) | «Выход из аккаунта» | `{macaddr}` | → перезагрузка |
| `authorize_terminal` | после login/register и при изменениях | `{version:2, require_media_tokens:true, require_media_keys:<bool>, result_as:"csv", [require_domain_config, nocache]}` | всё состояние абонента, §1.5 |
| `check_update` | каждые `portal_update_period` = 300 с | `{program:"web browser", [require_media_tokens], [require_media_keys]}` | §1.6 |
| `get_epg` | EPG канала | `{version:2, result_as:"csv", media_id, language_id, start:"YYYY-MM-DD 00:00:00", stop:"YYYY-MM-DD 23:59:59"}`; для «сейчас/далее» по списку: `media_id:[ids]` без start/stop | `{now, programs:[[header…],[row…]]}` |
| `get_playlists` | VOD/NVOD/radio/cam, ленивая загрузка ТВ | `{is_vod|is_nvod|is_radio|is_tv|is_cam:true, media_items:false, media_count:true}` | `{count, playlists:[{id, playlist, name, count, settings}]}` |
| `get_playlist_media` | содержимое плейлиста | `{result_as:"csv", playlist_id, age_limit, where:"*поиск*"|null, order_by, offset, limit, is_<type>:true, is_favorite}` | `{count, offset, items:[[header],[row]…]}` |
| `get_media_by_id` | сериал/папка VOD | `{result_as:"csv", parent_id, age_limit, order_by:"index nulls last, id desc", offset, limit}` | как выше |
| `insert_playlist_media` / `delete_playlist_media` | избранное | `{playlist_id:<id плейлиста tv-favorites>, media_id}` | — |
| `set_terminal_params` | язык, профиль, UI, состояние | `{language_id}` / `{profile_id}` / `{view, osd_alpha, font_scale, show_epg_day_panel, show_channel_logo, params:"<json>"}` / `{use_mcast_proxy, mcast_proxy_url}` / `{aspect, audio_volume, media_id, pwd}` | — |
| `update_profile` (шифр.) | пароль профиля | `{profile_id, profile_password}` | — |
| `purchase_package` / `unsubscribe_package` | подписка | `{cost, package_id, package, expiration_period, expired_on}` | → `authorize_terminal{nocache}` |
| `purchase_media` | покупка VOD | `{cost, media_id, media}` | — |
| `view_bill` | «Счёт» | `null` | `{balance, items:[{description, cost, display}]}` |
| `accept_msg` | очередь сообщений | `{msg_id}` | — |
| `get_categories` / `get_items` / `add_list_item` / `remove_list_item` / `order` | «приложения» (магазин, корзина) | `{app, …}` | — |

Сортировки VOD (значение уходит в `order_by`):
- `"index desc nulls last, id desc"`;
- `"coalesce (rating, kp_rating, imdb_rating) desc, id desc"`;
- `"year desc, id desc"`;
- `"name, id desc"`.

### 1.4 `get_domain_config` (реальный ответ, сокращённо)

```json
{"default_language":"ru","use_language_translation":true,"startup_url":"/download/startup.js",
 "use_ca":true,"ca_auth_uri":"https://iptv.tmalem.tv/ca/","use_multiple_epg_provider":true,"epg_provider_id":1,
 "stream_backend":"flussonic","use_timeshift":true,"timeshift_backend":"flussonic","timeshift_thumbnails":false,
 "use_aprofile":true,"hide_password":true,"allow_terminal_reg":true,"allow_terminal_unreg":true,"allow_anonymous":false,
 "play_tv_on_ok":true,"epg_menu_limit":2,"audio_volume":50,"show_unsubscribed_media":false,"allow_playlist_customizing":true,
 "channel_logo_available":true,"show_channel_logo":true,"use_virtual_keyboard":true,"allow_portal_exit":true,
 "portal_host":"iptv.tmalem.tv","portal_logo":null,"portal_theme":null,"view":"classic",
 "portal_update_period":300,"playlog_report_period":600,"playlog_min_duration":10,
 "updated_on":1790180081,"epg_updated_on":1529258491,"save_terminal_state":true,
 "settings":"{\"auto_pause\": true, \"font_scale\": 100, \"auto_pause_timeout\": 18000, \"hide_channel_index\": false, \"hide_empty_video_thumbnails\": true}",
 "name":"tmalem","now":"2026-10-03 20:48:45+0500"}
```
Разбор полей — функция `gd()`, sys.js:27796. Что важно для клиента:
- `name`="tmalem" — домен; он же уходит параметром `domain=` в URL с arescrypt-токенами;
- `use_ca`/`ca_auth_uri` — CAS (arescam/aresproxy `-a <uri>`);
- `allow_anonymous:false` — без регистрации терминала смотреть нельзя;
- `auto_pause_timeout` 18000 с: через 5 часов без нажатий пауза с вопросом «Продолжить»;
- `use_aprofile:true` — возрастные профили;
- `hide_password:true` — пароль вводится маскированным полем.

### 1.5 `authorize_terminal` — структура ответа (`bd()`, sys.js:27931–28482)

`result_as:"csv"` означает, что `medialist` — массив массивов, где первая строка содержит имена колонок.

```jsonc
{
 "now": "2026-10-03 20:48:45+0500",          // синхронизация часов
 "es": { /* domain config, как get_domain_config */ },
 "proxy_url": "...",
 "settings": "[\"hls_mono\"]" | "{\"hls_profile\":\"mono\"}",   // профиль HLS: index|video|mono|apple
 "authorized": true, "anonymous": false,
 "username": "...", "password": "...", "terminal_id": 123, "macaddr": "XX:XX:..",
 "account_balance": 0, "tz": "...", "view": "classic", "player": "...",
 "font_scale": 100, "show_channel_logo": true, "show_epg_day_panel": null, "osd_alpha": ...,
 "language": {"id":1,"iso639_1":"ru"},
 "languages": [{"id","name","iso639_1","iso639_2"}],
 "profile": {"id","name","require_password","require_password_period","password","age_limit"},
 "profiles": [{"id","name","title","require_password","require_password_period","password","age_limit","items":[media_id…]}],
 "sprofile": {"id","name"},
 "personal_data": {"surname","first_name","middle_name"}, "guest": [...], "room": ...,
 "state": {"aspect":"<json>","audio_volume":50,"media_id":123,"pwd":"/tv/#0/..."},
 "params": "<json>", "account_params": "<json>",
   // auto_hide_ui, auto_hide_ui_timeout, fast_channel_change, font_weight, hide_channel_index,
   // hide_empty_video_thumbnails, show_channel_live, timeshift_available_since (unix),
   // typography, video_quality, use_pointing_device, watchdog_playing, background_media
 "medialist": [["id","index","name","title","description","expiration_period","age_limit","paid","cost",
                "protocol","host","port","path","username","password","mime_type","auth",
                "is_tv","is_vod","is_nvod","is_radio","channel_id","epg_provider_id","msg_id","logo_url",
                "encrypted","key","stream_backend","timeshift_backend","timeshift_url",
                "timeshift_archive_length","timeshift_offset","timeshift_auth","timeshift_thumbnails_proxy",
                "teletext_subtitles_page"], [ …row… ], …],
 "medialist_enabled": {"<media_id>": {"expired_on","time_until_expiration"}},
 "packages": [{"id","name","title","description","expiration_period","age_limit","paid","cost","hidden","medialist":[media_id…]}],
 "packages_enabled": {"<pkg_id>": {"subscribed_on","expired_on","time_until_expiration","demanded","canceled"}},
 "services": [{"id","name","paid","cost","ads","expiration_period","use_portal_proxy","url","api_params","settings"}],
 "services_enabled": {"<svc_id>": {"expired_on","time_until_expiration","packages","username","password","session_id"}},
   // сервис "timeshift" должен быть в services_enabled, иначе архив выключен
 "playlists": [{"id","name":"tv|tv-news|…","title","age_limit","is_tv","is_vod","is_nvod","is_radio","is_share","is_cam","settings","playitems":[media_id…]}],
 "menu": [{"id","parent_id":"menu"|<id>,"title","age_limit","app","app_type","service","settings":{"thumbnail_url","logo_url",…},"playlist"}],
 "msglist": [{"id","name","data","disabled"}], "msg_queue": [{"id","is_cmd","msg"}],
 "tokens": {"<key_name>": {"token1":"…","token2":"…"}}, "tokens_update_period": N, "tokens_updated_on": T,
 "keys": {"<key_name>": {"algorithm":"aes|gost89|csa|arc4|ctxxor2|aresfast2","mode":"ecb|cbc|cfb|ofb|sm",
                         "size":16,"values":{"1":"HEX","2":"HEX"},"iv":"HEX","update_period":N}},
 "epg_info": [{"id":<media_id>,"updated_on":T}],
 "use_mcast_proxy": false, "mcast_proxy_url": "http://…",
 "weather": …, "subscriber_updated_on","terminal_updated_on","weather_updated_on"
}
```
Логика:
- Если `medialist_enabled[id]` отсутствует, канал скрывается (`show_unsubscribed_media=false`).
- Плейлист ТВ (`playlists[].playitems`) — список `media_id`. Плейлист `tv-favorites` — избранное.
- Пункты главного меню берутся из `menu` с `parent_id=="menu"`. Если у пункта есть `app`, это приложение (`vod`, `radio`, `nvod`, `cam`, `settings`, `profile`, `language`, `subscription`, `bill`, `fs`, `market`, `html`, `cinema`, `playlist`, `blogertv`, `videoteka`…). Дочерние пункты (`parent_id=<id>`) — рубрики с `playlist`.
- После ответа скачивается локаль `/resources/portal/locale/<language.iso639_1>.js`.
- Если у профиля `require_password`, запрашивается пароль. При отказе вызывается `set_terminal_params{profile_id:1}`, затем повторный `authorize_terminal`.

### 1.6 `check_update` (sys.js:28483)

- В ответе приходят `authorized`/`anonymous` и `now`. Если `authorized` изменился, страница перезагружается.
- Если `domain_updated_on`, `subscriber_updated_on` или `terminal_updated_on` больше сохранённых, повторно вызывается `authorize_terminal{require_domain_config:true, nocache:true}`.
- Иначе обновляются `epg_info` (инвалидация кеша EPG по каналу), `tokens` и `keys` (ротация ключей дескремблирования) и `weather`.
- Если `allow_terminal_reg`, регистрация повторяется каждые `reg_update_period` (иначе по `portal_update_period`).

### 1.7 Прочие обращения
- Статистика просмотра (playlog), каждые `playlog_report_period` = 600 с и при переключении:
  `GET /stat/<mac_без_двоеточий_lower>/<media_id>/<prev_media_id>?c=<channel_id>&t=<unix>&p=<prev_channel_id>&pt=<unix>&pid=<id>&_dc=<ms>` (`new Image().src`, sys.js:11690). Если у плейлиста задан `stat_url`, используется он.
- `startup_url` (`/download/startup.js`) подключается как JSONP при старте. Сейчас там **блок-лист UA**: строки `X3 Build/PPR1`, `X96Q PRO`, `LX352`, `ANNKEL`, `SUT-55S7L`, `ITVQ8 Build`. На таких устройствах окно авторизации закрывается баннером `/download/banner2.png`. Учитывать при выборе UA для tvOS.
- Сторонние приложения в коде: Megogo, OKKO (`iptvp.okko.tv/?domain=&session_id=`), YouTube, «pangolin», реклама teletarget/adstream (`/ad/`). Для AlemTV, судя по конфигу, не используются (`use_teletarget:null`).

---

## 2. Авторизация (sys.js:19296–19560, 29498–29560)

1. Загрузка страницы. Параметры URL (`screen`, `fullscreen`, `mobile`, `engine`/`player`, `aresproxy`, `media_id`, `pprofile`, `pwd`, `view`, `size`, `debug`, `logout`…) разбираются в sys.js:6020.
2. `get_domain_config {terminal_type}`, затем `startup.js`, CSS и шрифты, затем **`u.login()`**.
3. **MAC** (`V.ae()`):
   - MAG: `gSTB.RDir("MACAddress")`;
   - Android-сборка: `stb.getMacAddress()`;
   - iOS-обёртка: `webkit.messageHandlers.getMacAddress`;
   - иначе `localStorage.mac_addr`.
4. `login {macaddr, create_macaddr, require_session, require_user_id, terminal_type, firmware_version}`.
   - Если MAC нет, передаётся `macaddr:null, create_macaddr:true`, и **сервер сам генерирует MAC**. Он возвращается в `result.macaddr` (или `extra.macaddr` при ошибке), портал сохраняет его в `localStorage.mac_addr` и `stb.setMacAddress`. Для tvOS это главный путь: псевдо-MAC выдаёт сервер, хранить его надо в Keychain.
   - Успех: `session_id` → `u.Ic`, `user_id` → `u.io`. Дальше `authorize_terminal`.
   - Отказ (терминал не привязан): при `allow_terminal_reg` открывается форма «Имя / Пароль» (`auth-username-input`, `auth-password-input`).
5. `register_terminal {username, password, macaddr, create_macaddr, require_session:true, require_user_id:true, terminal_type, firmware_version}` (шифрованный). Привязывает MAC к аккаунту абонента и сразу отдаёт `session_id`. Затем `authorize_terminal`.
   - `terminal_type`: в MAG-сборке `RDir("Model").toLowerCase()` (`mag250`); в Android-сборке параметр `model` из URL.
   - `firmware_version`: MAG — `"<ImageVersion> (<ImageDescription>)"`; Android — строка из скобок UA.
6. `session_id` живёт, пока сервер его принимает. Явного TTL или refresh нет. Ответ `-32003` (или `authorized:false` в `check_update`) ведёт к перезагрузке или форме входа. После перезагрузки снова выполняется `login` по MAC, поэтому пароль повторно не нужен.
7. Выход: `unregister_terminal {macaddr}` отвязывает терминал.
8. Регистрация по телефону или e-mail (`use_telephone_registration`, `use_email_registration`) у AlemTV выключена.

---

## 3. URL потоков

### 3.1 Live (общий `$Player.nd`, sys.js:6945–7100)
Из полей medialist собирается `protocol://[user:pass@]host[:port]/path`:
- если `path` — полный URL, используется он;
- если `protocol` пуст, подставляется `http`.

Затем добавляются query-параметры по полю `auth` (строка с ключевыми словами):

| `auth` содержит | добавляется |
|---|---|
| `flussonic` или `iptvportal` | `token=<session_id>` |
| `wowza` | `UserID=<user_id>` |
| `nimble` | `salt=<rand>&hash=<md5(salt/auth_secret_key)>` |
| `wmsAuthSign` | wowza-подпись |
| `arescrypt` (+ у media есть `key`) | `token1=&token2=` (из `tokens[key]`), `domain=tmalem&key=<key>&media_id=<id>&timestamp=<unix>` |
| `iptvportal` + `key` | всё из строки выше, завёрнутое в `token=<urlencoded(...)>` |
| `custom` | шаблон `${mac_addr} ${session_id} ${terminal_id} ${username} ${password}` в URL |

К мультикастным URL токены не добавляются. Для `stream_backend=="flussonic"` с HLS-путём имя плейлиста подменяется по `hls_profile`: `index.m3u8` / `video.m3u8` / `mono.m3u8`. Android-сборка (не iOS) жёстко ставит `mono` и `query filter=tracks:v1a1` (ip.js:6327).

Пример live (гипотетический):
```
http://<host>:<port>/<channel>/mono.m3u8?filter=tracks:v1a1&token=<session_id>
```

### 3.2 Мультикаст / юникаст
- Канал считается мультикастом (`Vg`), если `host` в диапазоне 224–239.x.x.x. Флаг `Gk` ставится, если `path` начинается с `udp/` или `rtp/`.
- MAG: `rtp udp://@239.x.x.x:port`. Android: `udp://239…:port` в Media3.
- Если у терминала `use_mcast_proxy` и `mcast_proxy_url` (из authorize, или выставлены в «Настройки → Сеть»), URL переписывается в `http://<proxy>/udp/<addr>:<port>` (схема udpxy/astra).
- Для tvOS нужны каналы с HTTP/HLS. Если все ТВ-каналы окажутся мультикастом, понадобится свой `mcast_proxy_url`; его возможно задать через `set_terminal_params`, проверить на данных.

### 3.3 Архив / таймшифт (`$Player.fc`, sys.js:7936–8008; `Fo`, sys.js:24557)
База: `timeshift_url` канала, от которой отрезается имя файла и query. Время в секундах UTC. `timeshift_offset` (если > 0) вычитается из start.

| backend | архивная передача (start, dur) | live (≤10 с от now) | таймшифт (start в прошлом, без dur) |
|---|---|---|---|
| **flussonic** (AlemTV) | `<base>/index-<start>-<dur>.m3u8` (`index` → `video`/`mono` по профилю) | `<base>/index.m3u8` | `<base>/timeshift_rel-<now-start>.m3u8` |
| nimble | `playlist_dvr_range-<start>-<dur>.m3u8` | `playlist.m3u8` | `playlist_dvr_timeshift-<now-start>.m3u8` |
| astra | `vod.m3u8?start=<s>&duration=<d>` | `index.m3u8` | `index.m3u8?start=-<now-s>` |
| microimpuls | `pvr/playlist?channel_id=&start_timestamp=&end_timestamp=&type=0` | | `ts?timestamp=` |

Логика по программе EPG (`Fo`):
- start округляется вниз до минуты, stop тоже; `dur = stop - start`.
- Если программа закончилась более 20 минут назад (`start+dur+1200 <= now`), используется VOD-URL `index-<start+pos>-<dur-pos>.m3u8`. Перемотка внутри передачи делается пересозданием URL с новым start.
- Если программа идёт сейчас, а позиция в пределах 10 с от live, играется live.
- В остальных случаях — `timeshift_rel-<now-(start+pos)>.m3u8`.

Авторизация архива: используется `timeshift_auth` канала (или `auth`), токены те же, что в 3.1.

Доступность архива для передачи: `media.timeshift_url` не пуст, сервис `timeshift` включён, и `start >= now - timeshift_archive_length` (или `>= timeshift_available_since`). Такие передачи получают CSS-класс `timeshift`.

Миниатюры (выключены, `timeshift_thumbnails:false`): `<base>/YYYY/MM/DD/HH/MM/SS.jpg` или `preview.jpg`, через `timeshift_thumbnails_proxy/<180x144>`.

Таймшифт на live (sys.js:28880): если у канала есть `timeshift_url`, кнопки Pause/Play/Rew/FF/←/→ переключают воспроизведение на текущую передачу со смещением `now - start`. Перемотка шагом 10 с (`rewPosition`/`ffwdPosition(…,10)`).

### 3.4 VOD
Элемент из `get_playlist_media`/`get_media_by_id` (csv):
- `id`, `title`, `is_folder`, `description`, **`url`**, `auth`, `key`, `duration`;
- `front_cover`, `image_url`, `landscape_url`;
- `country`, `year`, `director`, `stars`, `genre`, `age_limit`;
- `rating`, `kp_rating`, `imdb_rating`;
- `trailer_url`, `trailer_duration`.

Воспроизводится `url` с токенами по `auth`. Сериалы — папки (`is_folder`), их содержимое через `get_media_by_id{parent_id}`. Есть и NVOD («Кинозал»).

### 3.5 Шифрование — ключевой вопрос
- У домена `use_ca:true`, `ca_auth_uri:"https://iptv.tmalem.tv/ca/"`. В medialist у каналов есть поля `encrypted` и `key` (имя ключа). Какая доля каналов зашифрована, видно только после авторизации.
- **MAG** (sys.js:6614): при старте `arescam -a https://iptv.tmalem.tv/ca/ -k -d [-y mcproxy:port]` плюс модуль ядра `arescrypt.ko`. Дескремблирование мультикаста идёт на приставке.
- **Android-APK** (ip.js:6378–6420, вызов в `ed()` при `use_ca`):
  - если в URL есть `&aresproxy` и `stb.checkAres()=="aresproxy"`, выполняется `stb.jsonRpc({"method":"exec","params":["<getPathAresproxy()> -a https://iptv.tmalem.tv/ca/ -k -d --relay --relay-port 12345 --macaddr <MAC>"]})`. URL зашифрованных каналов (`encrypted && key` и мультикаст или `udp/`/`rtp/`-путь) тогда превращаются в `http://127.0.0.1:12345/udp/<addr>:<port>` или `/<proto>/<host>[:port]/<path>`;
  - иначе выполняется `stb.execCmd("killall arescam")` + `"arescam -a … -k -d"`, что на Android вхолостую. Так работает AlemTV: `&aresproxy` не передаётся.
- В Android/iOS-сборке `Q.arescrypt=false`. Поэтому для `encrypted && key` (если канал не мультикаст без прокси) к `auth` дописывается `"arescrypt"`, и URL получает `token1, token2, domain=tmalem, key, media_id, timestamp` (ip.js:21795). Вывод: в нативных клиентах IPTVPORTAL зашифрованные каналы, по всей видимости, отдаются с токенами, которые сервер проверяет. Отдаёт ли сервер при валидных токенах уже дескремблированный поток или токены служат только для доступа, а поток остаётся скремблированным, из кода не видно. **Это главный вопрос для проверки на реальном потоке**: признак — биты scrambling_control (`byte[3] & 0xC0`) в TS-пакетах.
- **HTML5-движок** (`engine=mpegts|videojs`) дескремблирует в браузере, и код дескремблера открыт:
  - флаг `require_media_keys` ставится, если движок mpegts/videojs и есть MSE;
  - сервер возвращает `keys{name:{algorithm, mode, size, values{"1","2"}, iv, update_period}}`; они обновляются в `check_update` (videojs каждые `update_period/2` шлёт `setAresCipher`);
  - алгоритм в `mpegts.js` (prettier, стр. ~5300):
    ```
    for each 188-byte TS packet:
      if (pkt[3] & 0x80):                       // scrambled
         key = (pkt[3] & 0x40) ? values["1"] : values["2"]   // odd/even
         crypter.setkey(key, size)               // для xxor2 сбрасывает состояние на каждый пакет
         crypter.decrypt(pkt[4..188], pkt[4..188], 184, iv)  // ВЕСЬ остаток после 4-байтного заголовка
         pkt[3] &= 0x3F
    ```
  - Шифры:
    - `aes` (16/16–32);
    - `gost89` (8/32, S-блоки в коде);
    - `csa` (8/8);
    - `arc4`;
    - `ctxxor2`/`aresfast2` → `xxor2` (stream-режим `sm`: `out[r] = in[r] ^ key[r % keylen] ^ v; v ^= out[r]`, ключ 1..188 байт).

    `xor`/`ctxxor`/`aresfast` в JS не реализованы: cipher остаётся undefined.
  - Режимы `ecb`, `cbc`, `cfb`, `ofb`, `sm`.
- **Вывод для tvOS.** Если AlemTV реально скремблирует каналы, есть два варианта:
  - (а) повторить HTML5-путь: запрашивать `require_media_keys:true`, читать HLS/TS, дескремблировать на Swift (код короткий: AES через CommonCrypto, остальное перенести из mpegts.js), отдавать в AVPlayer через локальный HLS-ремукс или в VLCKit;
  - (б) проверить, отдаёт ли сервер чистый поток по URL с `arescrypt`-токенами (путь iOS-обёртки).

  aresproxy не нужен. Юридически это DRM оператора, поэтому нужно разрешение AlemTV.

---

## 4. EPG
- Метод `get_epg`, загрузка по дням: `start:"YYYY-MM-DD 00:00:00"`, `stop:"YYYY-MM-DD 23:59:59"` (дата локальная серверная), `language_id`, `media_id`, `version:2`, `result_as:"csv"`.
- Для «текущая/следующая» в списке каналов `media_id` передаётся массивом видимых каналов без start/stop (sys.js:21430).
- Ответ: `{now:"YYYY-MM-DD HH:MM:SS+0500", programs:[["start","stop","title","description","age_limit","media_id","media_url","updated_on"…],[…]]}`. Колонки определяются по заголовку.
  - `media_url` — запись передачи для `timeshift_url=="//epg"`; это альтернативный режим «архив по ссылкам из EPG» с миниатюрами `thumbnails/<sec>_<w>x<h>.jpg`.
  - Возраст в конце `title` вида `(16+)` отрезается.
- Время: строки с зоной. Для UTC: `Date.parse("MM/DD/YYYY HH:MM:SS +0500")`. Для «настенного» времени зона отбрасывается. Часы синхронизируются по `now` (смещение сервер−устройство хранится, sys.js:11272). Туркменистан UTC+5, `now` приходит с `+0500`.
- Дыры между передачами заполняются пустыми слотами по 60 минут.
- Кеш инвалидируется по `epg_info[media_id].updated_on` из authorize и check_update.
- `epg_menu_limit: 2`; `epg_provider_id: 1`, у канала может быть свой.
- Глубина архива: `timeshift_archive_length` канала (сек), либо `params.timeshift_available_since` (unix), либо `timeshift_offset` (сдвиг).

---

## 5. Карта экранов и функций

Меню формируется сервером (`menu`). Порядок типичный: **ТВ → Видео → Кинозал → Радио → Камеры → Приложения → Профиль → Язык → Подписка → Счёт → Настройки → Выход**. У AlemTV состав виден только после авторизации.

- **ТВ** (`tv`):
  - рубрики-плейлисты: Все, Избранное, Эфирные, Региональные, Новости, Детские, Познавательные, Кино, Спорт, Музыка, HD…; названия с сервера;
  - список каналов: номер (`index`), логотип, текущая передача с прогресс-баром;
  - EPG по дням с метками live/timeshift; play по OK (`play_tv_on_ok`);
  - D-pad вверх/вниз переключает каналы, цифры набирают номер.
- **Плеер (OSD)**:
  - название, начало и длительность, слайдер позиции, полоса миниатюр;
  - контекстное меню (F1–F4 / цветные / ContextMenu): **Звуковая дорожка**, **Субтитры**, **Телетекст**, **Аспект** (1:1, 4:3, 16:9, 16:10, 221:100, 5:4), **Качество** (`video_quality`, по умолчанию 720), **Избранное**;
  - Info, Back, Home, Refresh.
- **Видео** (`vod`): категории, сортировка (новые / рейтинг / год / алфавит), поиск (`where:"*текст*"`), карточка (постер, год, страна, жанр, режиссёр, в ролях, рейтинги, КиноПоиск/IMDb, трейлер), сериалы (сезоны/эпизоды), «похожие».
- **Кинозал** (`nvod`), **Радио** (`radio`), **Камеры** (`cam`): так же через плейлисты.
- **Приложения**: сервисы из `services` (Megogo, YouTube, iRadio, магазин с корзиной и заказом и т.п.).
- **Профиль**: возрастные профили (`age_limit`, по умолчанию 17), пароль профиля, автосброс на профиль 1 через `require_password_period`.
- **Язык**: `languages` из authorize → `set_terminal_params{language_id}`.
- **Подписка**: пакеты, состав, стоимость, покупка или отключение с вводом кода подтверждения.
- **Счёт**: `view_bill`, итог — баланс (валюта `currency_symbol`, по умолчанию ₽).
- **Настройки**:
  - Интерфейс: дизайн classic/modern, прозрачность OSD, размер и толщина шрифта, скрывать номера каналов, логотипы, текущие передачи, навигация EPG по дням, автоскрытие UI и таймаут;
  - Плеер: watchdog;
  - Сеть: мультикаст-прокси вкл. и адрес; на MAG также IP/DNS/IGMP/видеорежим.
- **Сообщения/тикер** (`use_msg:false`), погода (`show_weather:null`): у AlemTV выключены.
- **Выход** (`allow_portal_exit`), **Выход из аккаунта** (`allow_terminal_unreg`).
- Сохранение состояния (`save_terminal_state:true`): последний канал (`media_id`), путь меню (`pwd`), громкость, аспект → `set_terminal_params`. При старте восстанавливается последний канал.

**Языки и строки.**
- `/resources/portal/locale/{ru,en,tk}.js` — JSON без обёртки. Туркменский есть: «Telewideniýe», «Wideo», «Sazlamalar»…
- Язык по умолчанию: `ru`.
- Так как `use_language_translation:true`, заголовки меню и плейлистов берутся с сервера (`title`/`name`), а локаль даёт кнопки, сообщения, дни и месяцы.
- Часть текстов захардкожена на русском («Качество», «Обновление», «канал недоступен…»).

## 6. Брендинг
- CSS: `/resources/portal/portal-<WxH|mobile>-<classic|modern>[-big].css` и `portal-apps-…`. Тема `classic`, `portal_theme:null`, то есть стандартная тема IPTVPORTAL без кастомизации AlemTV.
- Цвета (classic 1280x720): акцент **`#ffb000`** (61 вхождение), текст `#eee`, фон `#000`/`#444`, полупрозрачные `rgba(238,238,238,.1–.7)`, `rgba(0,0,0,.7)`. В APK акцент `#FF8800`.
- Шрифты: `/resources/portal/portal-fonts-{300|400}.css` → Noto Sans (Thin…Black, Mono) в `resources/portal/fonts/*.woff2`; иконки — шрифт `fonts/iptvportal.woff`.
- Логотип портала: `portal_logo:null`. Логотипы каналов: `logo_url` из medialist или `/resources/portal/images/logo{44|56|84|96}/<channel_id>.png` (размер зависит от высоты экрана 576/720/1080). Иконки приложений: `/resources/portal/images/icon/128/<name>.png`. Бренд ALEM TV — только из APK (`alem.png`).

## 7. Прочее важное для tvOS
- **Идентичность клиента.**
  - Сервер выбирает сборку по UA (`mag200` / `iptvportal` / `vlc`), и `terminal_type` (модель) уходит в `login`/`register_terminal`.
  - Разумный вариант: представляться так же, как Android-APK, или как iOS-обёртка IPTVPORTAL (`iptvportal iphone mobile` в UA), с `pprofile` по ситуации. В iOS-ветке нет `mono`/`filter=tracks:v1a1`, то есть по умолчанию полный `index.m3u8`, что хорошо подходит AVPlayer.
  - Не попадать в блок-лист `startup.js`.
- **Лимит терминалов.** `register_terminal` привязывает новый MAC к аккаунту. Сервер может ограничивать число терминалов; выход — `unregister_terminal`.
- **Таймеры.** `check_update` каждые 300 с; playlog каждые 600 с (минимальная длительность 10 с); автопауза через 18000 с бездействия.
- **Ротация ключей и токенов.** `tokens_update_period`, `keys[].update_period`. URL с токенами нужно пересобирать по таймеру. `timestamp` в URL — текущее серверное время (`Dc()`), синхронизированное по `now`.
- **ATS.** Нужен http для `telecom.alemtv.tm`, `iptv.tmalem.tv` и хостов потоков.
- **Кеш.** `authorize_terminal` грузит весь medialist разом: клиенту хватит одного вызова плюс EPG по запросу.

## 8. Ключевые места в коде (prettier, mag200 sys.js)
- jsonRpc/jsonsql: 11083–11190; шифрование: 10997–11050; RSA: 4462.
- Auth: 19296–19560 (Lw/Eg/ei/dr/login/Mu); старт: 29498.
- Домен-конфиг `gd`: 27796; разбор authorize `bd`: 27931–28482; `check_update`: 28483.
- Сборка URL: 6945–7100; таймшифт `fc`: 7936; миниатюры `wo`: 8009.
- Плееры: MAG 10433; mpegts/hls 9330; videojs 9640.
- Медиа и флаги шифрования: 22390–22510; EPG: 21430, 23700–23900; архив по программе `Fo`: 24557.
- VOD: 24654–24870; избранное: 22732; настройки: 25130–25620; подписка: 26087; профиль и язык: 26398–26620; счёт: 27727.
- Android-сборка (iptvportal/system.js, prettier): платформа и мост stb 6280–6460, aresproxy 6378–6420, флаги arescrypt 21790–21805.
- Дескремблер: mpegts.js (prettier) 4560–5130 (шифры) и 5296–5320 (обработка TS-пакета).
