# AlemTV для Apple TV

Нативный tvOS-клиент для абонентов AlemTV (платформа IPTVPORTAL).

## Сборка

```bash
brew install xcodegen
xcodegen generate
open AlemTV.xcodeproj   # выбрать свою команду в Signing & Capabilities
```

Тесты ядра: `swift test --package-path Packages/AlemCore`.
Живой интеграционный тест (нужны `.credentials` и привязанный терминал):
`ALEMTV_LIVE=1 swift test --package-path Packages/AlemCore --filter LiveIntegrationTests`.

Документы: `docs/superpowers/specs/`, `docs/superpowers/plans/`, `reference/*.md`.
