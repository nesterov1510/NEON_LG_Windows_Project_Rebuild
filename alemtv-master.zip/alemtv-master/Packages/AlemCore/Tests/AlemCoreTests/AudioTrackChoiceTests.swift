import Testing
@testable import AlemCore

@Suite struct AudioTrackChoiceTests {
    let rus = AudioTrack(id: "a1", name: "rus a1", language: "rus")
    let kaz = AudioTrack(id: "a2", name: "kaz a2", language: "kaz")

    @Test func picksRememberedLanguage() {
        #expect(AudioTrackChoice.preferred([rus, kaz], language: "kaz") == kaz)
        #expect(AudioTrackChoice.preferred([rus, kaz], language: "KAZ") == kaz)
    }

    @Test func preferredLanguageMissingKeepsDefault() {
        #expect(AudioTrackChoice.preferred([rus, kaz], language: "tuk") == nil)
    }

    @Test func singleTrackOrNoPreferenceKeepsDefault() {
        #expect(AudioTrackChoice.preferred([rus], language: "rus") == nil)
        #expect(AudioTrackChoice.preferred([rus, kaz], language: nil) == nil)
        #expect(AudioTrackChoice.preferred([], language: "rus") == nil)
    }

    /// VLC раздваивает единственную дорожку (Altyn Asyr: «Track 1» без языка + «Track 2 [Turkmen]»):
    /// выбор показывается только для разных языков.
    @Test func selectableNeedsTwoDistinctLanguages() {
        let unnamed = AudioTrack(id: "1", name: "Track 1", language: nil)
        let tuk = AudioTrack(id: "2", name: "Track 2 - [Turkmen]", language: "tuk")
        #expect(AudioTrackChoice.selectable([unnamed, tuk]).isEmpty)
        #expect(AudioTrackChoice.selectable([rus, kaz]) == [rus, kaz])
        #expect(AudioTrackChoice.selectable([rus, AudioTrack(id: "a3", name: "rus 2", language: "RUS"), kaz]) == [rus, kaz])
        #expect(AudioTrackChoice.selectable([rus]).isEmpty)
    }
}
