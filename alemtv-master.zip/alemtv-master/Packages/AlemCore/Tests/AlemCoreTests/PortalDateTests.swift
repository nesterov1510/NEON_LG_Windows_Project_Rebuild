import Testing
import Foundation
@testable import AlemCore

@Suite struct PortalDateTests {
    @Test func parsesWithZone() {
        #expect(PortalDate.parse("2026-10-02 22:50:00+0500")?.timeIntervalSince1970 == 1_790_963_400)
    }

    @Test func parsesWithoutZoneAsServerTime() {
        #expect(PortalDate.parse("2026-09-26 18:36:00")?.timeIntervalSince1970 == 1_790_429_760)
    }

    @Test func rejectsGarbage() {
        #expect(PortalDate.parse("вчера") == nil)
        #expect(PortalDate.parse("") == nil)
    }

    @Test func dayStringUsesServerZone() {
        // 2026-10-03 19:30 UTC = 2026-10-04 00:30 в Ашхабаде
        #expect(PortalDate.dayString(Date(timeIntervalSince1970: 1_791_055_800)) == "2026-10-04")
    }

    @Test func startOfDayInServerZone() {
        let start = PortalDate.startOfDay(Date(timeIntervalSince1970: 1_791_055_800))
        #expect(PortalDate.dayString(start) == "2026-10-04")
        #expect(start.timeIntervalSince1970 == 1_791_054_000)
    }
}
