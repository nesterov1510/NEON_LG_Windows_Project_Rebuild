import Testing
import Foundation
@testable import AlemCore

@Suite struct SessionStoreTests {
    let macKey = "terminal.macaddr.telecom.alemtv.tm"

    func make(mac: String? = nil) throws -> (SessionStore, MockPortalAPI, InMemorySecureStore) {
        let api = MockPortalAPI(authorization: try Fixture.authorize())
        let store = InMemorySecureStore()
        if let mac { store.set(mac, forKey: macKey) }
        return (SessionStore(api: api, store: store, macKey: macKey), api, store)
    }

    @Test func startWithoutMacNeedsCredentials() async throws {
        let (session, api, _) = try make()
        guard case .needsCredentials = try await session.start() else { Issue.record("expected needsCredentials"); return }
        #expect(await api.calls == ["get_domain_config"])
    }

    @Test func startWithMacSignsIn() async throws {
        let (session, api, _) = try make(mac: "00:1A:79:00:00:01")
        guard case .signedIn(let a) = try await session.start() else { Issue.record("expected signedIn"); return }
        #expect(!a.channels.isEmpty)
        #expect(await api.calls == ["get_domain_config", "login", "authorize_terminal"])
        #expect(await api.session == "SID")
        #expect(await api.mac == "00:1A:79:00:00:01")
        let context = try #require(await session.streamContext())
        #expect(context.sessionID == "SID")
        #expect(context.domain == "tmalem")
        #expect(context.tokens["Key-1"]?.token1 == "T1")
    }

    @Test func startWithStaleMacNeedsCredentials() async throws {
        let (session, api, _) = try make(mac: "00:1A:79:00:00:09")
        await api.setLogin(.failure(.notFound("not found")))
        guard case .needsCredentials = try await session.start() else { Issue.record("expected needsCredentials"); return }
    }

    @Test func startPropagatesNetworkErrors() async throws {
        let (session, api, _) = try make(mac: "00:1A:79:00:00:01")
        await api.setLogin(.failure(.transport("offline")))
        await #expect(throws: PortalError.transport("offline")) { try await session.start() }
    }

    @Test func signInStoresMac() async throws {
        let (session, api, store) = try make()
        _ = try await session.start()
        let a = try await session.signIn(username: "user", password: "pass")
        #expect(!a.channels.isEmpty)
        #expect(store.string(forKey: macKey) == "00:1A:79:00:00:01")
        #expect(await api.session == "SID2")
        #expect(await api.calls.suffix(2) == ["register_terminal", "authorize_terminal"])
    }

    @Test func refreshReplacesTokensWithoutReload() async throws {
        let (session, api, _) = try make(mac: "00:1A:79:00:00:01")
        _ = try await session.start()
        let current = try #require(await session.authorization)
        await api.setUpdates([CheckUpdateResult(
            authorized: true, domainUpdatedOn: 100,
            subscriberUpdatedOn: current.subscriberUpdatedOn, terminalUpdatedOn: current.terminalUpdatedOn,
            tokens: ["Key-1": MediaToken(name: "Key-1", token1: "T9", token2: "T8")],
            epgInfo: [33: EPGInfo(mediaID: 33, updatedOn: 42)]
        )])
        let r = try await session.refresh()
        #expect(!r.reloaded)
        #expect(r.epgInfo?[33]?.updatedOn == 42)
        #expect(await session.streamContext()?.tokens["Key-1"]?.token1 == "T9")
        #expect(await api.calls.last == "check_update")
    }

    @Test func refreshReauthorizesWhenAuthorizedMissing() async throws {
        let (session, api, _) = try make(mac: "00:1A:79:00:00:01")
        _ = try await session.start()
        await api.setUpdates([CheckUpdateResult(authorized: false)])
        let r = try await session.refresh()
        #expect(r.reloaded)
        #expect(await api.calls.suffix(3) == ["check_update", "login", "authorize_terminal"])
    }

    @Test func refreshReloadsWhenSubscriberChanged() async throws {
        let (session, api, _) = try make(mac: "00:1A:79:00:00:01")
        _ = try await session.start()
        let current = try #require(await session.authorization)
        await api.setUpdates([CheckUpdateResult(authorized: true, domainUpdatedOn: 100,
                                                subscriberUpdatedOn: current.subscriberUpdatedOn + 1,
                                                terminalUpdatedOn: current.terminalUpdatedOn)])
        let r = try await session.refresh()
        #expect(r.reloaded)
        #expect(await api.calls.last == "authorize_terminal(nocache)")
    }

    @Test func subscriptionChangeDeliversNewChannelList() async throws {
        let (session, api, _) = try make(mac: "00:1A:79:00:00:01")
        _ = try await session.start()
        let current = try #require(await session.authorization)
        // Подписку сменили: канал 33 больше недоступен.
        var reduced = AuthorizeResult(channels: current.channels.filter { $0.id != 33 }, playlists: current.playlists,
                                      tokens: current.tokens, subscriberUpdatedOn: current.subscriberUpdatedOn + 1,
                                      terminalUpdatedOn: current.terminalUpdatedOn)
        reduced.timeshiftEnabled = current.timeshiftEnabled
        await api.setAuthorization(reduced)
        await api.setUpdates([CheckUpdateResult(authorized: true, domainUpdatedOn: 100,
                                                subscriberUpdatedOn: current.subscriberUpdatedOn + 1,
                                                terminalUpdatedOn: current.terminalUpdatedOn)])
        let r = try await session.refresh()
        #expect(r.reloaded)
        #expect(r.authorization.channel(id: 33) == nil)
        #expect(await session.authorization?.channel(id: 33) == nil)
    }

    @Test func refreshSyncsClock() async throws {
        let (session, api, _) = try make(mac: "00:1A:79:00:00:01")
        _ = try await session.start()
        let serverNow = Date().addingTimeInterval(120)
        await api.setUpdates([CheckUpdateResult(authorized: true, domainUpdatedOn: 100, serverNow: serverNow)])
        _ = try await session.refresh()
        let offset = await session.clock.offset
        #expect(abs(offset - 120) < 2)
    }

    // Final review Important 3: -32003 от самого check_update — тихий повторный вход по MAC.
    @Test func refreshReauthorizesWhenCheckUpdateIsUnauthorized() async throws {
        let (session, api, _) = try make(mac: "00:1A:79:00:00:01")
        _ = try await session.start()
        await api.setCheckUpdateError(.unauthorized("Доступ запрещен"))
        let r = try await session.refresh()
        #expect(r.reloaded)
        #expect(await api.calls.suffix(3) == ["check_update", "login", "authorize_terminal"])
    }

    // Final review Important 4: SessionStore — единственный владелец каталога; избранное переживает refresh.
    @Test func favoriteSurvivesRefreshWithoutReload() async throws {
        let (session, api, _) = try make(mac: "00:1A:79:00:00:01")
        _ = try await session.start()
        let current = try #require(await session.authorization)
        let favorites = try #require(current.favorites)
        await session.applyFavorite(true, playlistID: favorites.id, mediaID: 76)
        await api.setUpdates([CheckUpdateResult(authorized: true, domainUpdatedOn: 100,
                                                subscriberUpdatedOn: current.subscriberUpdatedOn,
                                                terminalUpdatedOn: current.terminalUpdatedOn)])
        let r = try await session.refresh()
        #expect(!r.reloaded)
        #expect(r.authorization.favorites?.mediaIDs == [33, 76])
        await session.applyFavorite(false, playlistID: favorites.id, mediaID: 33)
        #expect(await session.authorization?.favorites?.mediaIDs == [76])
    }

    // Final review Important 5: при сбое unregister_terminal MAC не теряется (иначе лишний терминал на сервере).
    @Test func failedSignOutKeepsTerminal() async throws {
        let (session, api, store) = try make(mac: "00:1A:79:00:00:01")
        _ = try await session.start()
        await api.setUnregisterError(.transport("offline"))
        await #expect(throws: PortalError.transport("offline")) { try await session.signOut() }
        #expect(store.string(forKey: macKey) == "00:1A:79:00:00:01")
        #expect(await session.streamContext() != nil)
    }

    @Test func signOutClearsTerminal() async throws {
        let (session, api, store) = try make(mac: "00:1A:79:00:00:01")
        _ = try await session.start()
        try await session.signOut()
        #expect(store.string(forKey: macKey) == nil)
        #expect(await session.streamContext() == nil)
        #expect(await api.session == nil)
        #expect(await api.calls.last == "unregister_terminal")
    }
}

/// Требование пользователя: каталог меняется при смене подписки — плеер должен продолжить на доступном канале.
@Suite struct CatalogChangeTests {
    let a1 = Channel(id: 1, index: 1, name: "A")
    let a2 = Channel(id: 2, index: 2, name: "B")
    let a3 = Channel(id: 3, index: 3, name: "C")

    func catalog(_ channels: [Channel], sport: [Int]) -> AuthorizeResult {
        AuthorizeResult(channels: channels, playlists: [
            Playlist(id: 10, name: "tv", title: "Все", mediaIDs: [1, 2, 3]),
            Playlist(id: 11, name: "tv-sports", title: "Спорт", mediaIDs: sport),
            Playlist(id: 12, name: "tv-favorites", title: "Избранное", mediaIDs: [3]),
        ])
    }

    @Test func availableChannelAndPlaylistAreKept() {
        let r = catalog([a1, a2, a3], sport: [2, 3]).resolve(channelID: 3, playlistID: 11)
        #expect(r.channel?.id == 3)
        #expect(r.playlist?.id == 11)
    }

    @Test func removedChannelFallsBackToFirstInPlaylist() {
        let r = catalog([a1, a2], sport: [2, 3]).resolve(channelID: 3, playlistID: 11)
        #expect(r.channel?.id == 2)
        #expect(r.playlist?.id == 11)
    }

    @Test func emptiedPlaylistFallsBackToAll() {
        let r = catalog([a1], sport: [2, 3]).resolve(channelID: 3, playlistID: 11)
        #expect(r.playlist?.name == "tv")
        #expect(r.channel?.id == 1)
    }

    @Test func channelOutsidePlaylistSwitchesPlaylistToAll() {
        let r = catalog([a1, a2, a3], sport: [2]).resolve(channelID: 1, playlistID: 11)
        #expect(r.channel?.id == 1)
        #expect(r.playlist?.name == "tv")
    }

    @Test func nothingLeftGivesNil() {
        let r = catalog([], sport: []).resolve(channelID: 1, playlistID: 10)
        #expect(r.channel == nil)
    }
}
