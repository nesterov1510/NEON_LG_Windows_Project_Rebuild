import Testing
import Foundation
@testable import AlemCore

@Suite struct StreamURLBuilderTests {
    let altyn = Channel(id: 1, index: 1, name: "Altyn Asyr", scheme: "http", host: "119.235.117.209", port: 8010,
                        path: "AltynAsyr/video.m3u8", auth: "iptvportal", key: "Key-1", encrypted: true,
                        timeshiftURL: "http://119.235.117.213:8020/AltynAsyr", timeshiftArchiveLength: 259200,
                        timeshiftAuth: "iptvportal")
    let context = StreamContext(sessionID: "SID", domain: "tmalem",
                                tokens: ["Key-1": MediaToken(name: "Key-1", token1: "T1", token2: "T2")],
                                serverNow: Date(timeIntervalSince1970: 1_700_000_000))
    let compositeToken = "token=token%3DSID%26token1%3DT1%26token2%3DT2%26domain%3Dtmalem%26key%3DKey-1%26media_id%3D1%26timestamp%3D1700000000"

    @Test func liveWithCompositeToken() throws {
        let url = try StreamURLBuilder.url(for: altyn, mode: .live, context: context)
        #expect(url.absoluteString == "http://119.235.117.209:8010/AltynAsyr/video.m3u8?" + compositeToken)
    }

    @Test func archiveURL() throws {
        let url = try StreamURLBuilder.url(for: altyn, mode: .archive(start: Date(timeIntervalSince1970: 1_700_000_000), duration: 600), context: context)
        #expect(url.absoluteString == "http://119.235.117.213:8020/AltynAsyr/index-1700000000-600.m3u8?" + compositeToken)
    }

    @Test func timeshiftURL() throws {
        let url = try StreamURLBuilder.url(for: altyn, mode: .timeshift(behind: 300.7), context: context)
        #expect(url.absoluteString == "http://119.235.117.213:8020/AltynAsyr/video-timeshift_rel-300.m3u8?" + compositeToken)
    }

    @Test func timeshiftOffsetIsSubtracted() throws {
        var channel = altyn
        channel.timeshiftOffset = 3600
        let url = try StreamURLBuilder.url(for: channel, mode: .archive(start: Date(timeIntervalSince1970: 1_700_000_000), duration: 60), context: context)
        #expect(url.absoluteString.contains("/index-1699996400-60.m3u8"))
    }

    @Test func channelWithoutKeyUsesPlainToken() throws {
        var channel = altyn
        channel.key = nil
        let url = try StreamURLBuilder.url(for: channel, mode: .live, context: context)
        #expect(url.absoluteString == "http://119.235.117.209:8010/AltynAsyr/video.m3u8?token=SID")
    }

    @Test func channelWithoutAuthHasNoQuery() throws {
        var channel = altyn
        channel.auth = nil
        let url = try StreamURLBuilder.url(for: channel, mode: .live, context: context)
        #expect(url.absoluteString == "http://119.235.117.209:8010/AltynAsyr/video.m3u8")
    }

    @Test func absolutePathIsUsedAsIs() throws {
        var channel = altyn
        channel.path = "http://cdn.example/x/index.m3u8?a=1"
        channel.auth = "flussonic"
        channel.key = nil
        let url = try StreamURLBuilder.url(for: channel, mode: .live, context: context)
        #expect(url.absoluteString == "http://cdn.example/x/index.m3u8?a=1&token=SID")
    }

    @Test func missingSchemeDefaultsToHTTPAndNoPort() throws {
        var channel = altyn
        channel.scheme = nil
        channel.port = nil
        channel.auth = nil
        #expect(try StreamURLBuilder.url(for: channel, mode: .live, context: context).absoluteString == "http://119.235.117.209/AltynAsyr/video.m3u8")
    }

    /// Эфир — путь канала как есть (VLC играет TS с любыми кодеками).
    @Test func livePathIsUsedAsIs() throws {
        var channel = altyn
        channel.auth = nil
        channel.path = "/Some/Deep/mono.m3u8"
        #expect(try StreamURLBuilder.url(for: channel, mode: .live, context: context).absoluteString == "http://119.235.117.209:8010/Some/Deep/mono.m3u8")
    }

    @Test func archiveWithoutTimeshiftURLThrows() {
        var channel = altyn
        channel.timeshiftURL = nil
        #expect(throws: StreamURLError.noArchive) {
            try StreamURLBuilder.url(for: channel, mode: .timeshift(behind: 10), context: context)
        }
    }

    @Test func liveWithoutHostThrows() {
        var channel = altyn
        channel.host = nil
        #expect(throws: StreamURLError.noLiveAddress) { try StreamURLBuilder.url(for: channel, mode: .live, context: context) }
    }

    @Test func timeshiftBaseDropsFileAndQuery() throws {
        var channel = altyn
        channel.timeshiftURL = "http://h:1/Ch/index.m3u8?x=1"
        let url = try StreamURLBuilder.url(for: channel, mode: .timeshift(behind: 5), context: context)
        #expect(url.absoluteString.hasPrefix("http://h:1/Ch/video-timeshift_rel-5.m3u8?"))
    }

    // MARK: mode(for:)

    let program = Program(mediaID: 1, start: Date(timeIntervalSince1970: 10_000), stop: Date(timeIntervalSince1970: 13_600), title: "x")

    @Test func finishedLongAgoIsArchive() {
        let now = Date(timeIntervalSince1970: 13_600 + 1200)
        #expect(StreamURLBuilder.mode(for: program, position: 0, now: now) == .archive(start: Date(timeIntervalSince1970: 9_960), duration: 3_600))
        #expect(StreamURLBuilder.mode(for: program, position: 100, now: now) == .archive(start: Date(timeIntervalSince1970: 10_060), duration: 3_500))
    }

    @Test func recentlyFinishedIsTimeshift() {
        let now = Date(timeIntervalSince1970: 13_600 + 600)
        #expect(StreamURLBuilder.mode(for: program, position: 0, now: now) == .timeshift(behind: 4_240))
    }

    @Test func onAirFromStartIsTimeshiftAndNearNowIsLive() {
        let now = Date(timeIntervalSince1970: 11_000)
        #expect(StreamURLBuilder.mode(for: program, position: 0, now: now) == .timeshift(behind: 1_040))
        #expect(StreamURLBuilder.mode(for: program, position: 1_035, now: now) == .live)
    }

    @Test func archiveAvailability() {
        let now = Date(timeIntervalSince1970: 300_000)
        let old = Program(mediaID: 1, start: Date(timeIntervalSince1970: 300_000 - 259_201), stop: Date(timeIntervalSince1970: 300_000 - 255_000), title: "old")
        let recent = Program(mediaID: 1, start: Date(timeIntervalSince1970: 299_000), stop: Date(timeIntervalSince1970: 299_500), title: "recent")
        let future = Program(mediaID: 1, start: Date(timeIntervalSince1970: 300_100), stop: Date(timeIntervalSince1970: 301_000), title: "future")
        #expect(!StreamURLBuilder.isAvailableInArchive(old, channel: altyn, timeshiftEnabled: true, now: now))
        #expect(StreamURLBuilder.isAvailableInArchive(recent, channel: altyn, timeshiftEnabled: true, now: now))
        #expect(!StreamURLBuilder.isAvailableInArchive(future, channel: altyn, timeshiftEnabled: true, now: now))
        #expect(!StreamURLBuilder.isAvailableInArchive(recent, channel: altyn, timeshiftEnabled: false, now: now))
    }

    // MARK: ServerClock

    @Test func serverClockOffset() {
        var clock = ServerClock()
        clock.sync(serverNow: Date(timeIntervalSince1970: 1_000), deviceNow: Date(timeIntervalSince1970: 990))
        #expect(clock.offset == 10)
        #expect(clock.now(deviceNow: Date(timeIntervalSince1970: 2_000)) == Date(timeIntervalSince1970: 2_010))
    }
}
