import Testing
import Foundation
@testable import AlemCore

actor MockEPGSource: EPGSource {
    var dayCalls: [String] = []
    var currentCalls: [[Int]] = []
    var dayPrograms: [Program] = []
    var currentPrograms: [Program] = []

    func setDay(_ programs: [Program]) { dayPrograms = programs }
    func setCurrent(_ programs: [Program]) { currentPrograms = programs }

    func epg(mediaIDs: [Int], languageID: Int?) async throws -> EPGResponse {
        currentCalls.append(mediaIDs)
        return EPGResponse(programs: currentPrograms.filter { mediaIDs.contains($0.mediaID) })
    }

    func epg(mediaID: Int, day: String, languageID: Int?) async throws -> EPGResponse {
        dayCalls.append("\(mediaID)/\(day)/\(languageID ?? 0)")
        return EPGResponse(programs: dayPrograms)
    }
}

@Suite struct EPGStoreTests {
    func program(_ id: Int, _ start: TimeInterval) -> Program {
        Program(mediaID: id, start: Date(timeIntervalSince1970: start), stop: Date(timeIntervalSince1970: start + 600), title: "p\(id)")
    }

    @Test func dayIsCached() async throws {
        let source = MockEPGSource()
        await source.setDay([program(33, 0), program(33, 600)])
        let store = EPGStore(source: source)
        let first = try await store.programs(mediaID: 33, day: "2026-10-03", languageID: 1)
        let second = try await store.programs(mediaID: 33, day: "2026-10-03", languageID: 1)
        #expect(first.count == 2)
        #expect(first == second)
        #expect(await source.dayCalls == ["33/2026-10-03/1"])
    }

    @Test func languageIsPartOfCacheKey() async throws {
        let source = MockEPGSource()
        let store = EPGStore(source: source)
        _ = try await store.programs(mediaID: 33, day: "2026-10-03", languageID: 1)
        _ = try await store.programs(mediaID: 33, day: "2026-10-03", languageID: 2)
        #expect(await source.dayCalls.count == 2)
    }

    @Test func emptyDayIsCachedNotError() async throws {
        let source = MockEPGSource()
        let store = EPGStore(source: source)
        #expect(try await store.programs(mediaID: 1, day: "2026-10-03", languageID: 1).isEmpty)
        _ = try await store.programs(mediaID: 1, day: "2026-10-03", languageID: 1)
        #expect(await source.dayCalls.count == 1)
    }

    @Test func newerEPGInfoInvalidatesChannel() async throws {
        let source = MockEPGSource()
        let store = EPGStore(source: source)
        await store.apply([33: EPGInfo(mediaID: 33, updatedOn: 1)])
        _ = try await store.programs(mediaID: 33, day: "d", languageID: nil)
        _ = try await store.programs(mediaID: 76, day: "d", languageID: nil)
        await store.apply([33: EPGInfo(mediaID: 33, updatedOn: 2), 76: EPGInfo(mediaID: 76, updatedOn: 5)])
        _ = try await store.programs(mediaID: 33, day: "d", languageID: nil)   // перезапрос
        _ = try await store.programs(mediaID: 76, day: "d", languageID: nil)   // кеш: версии 76 раньше не было
        #expect(await source.dayCalls == ["33/d/0", "76/d/0", "33/d/0"])
    }

    @Test func currentIsKeyedByMediaIDAndChunked() async throws {
        let source = MockEPGSource()
        await source.setCurrent([program(33, 0), program(76, 0)])
        let store = EPGStore(source: source)
        let ids = Array(1...120) + [33, 76]
        let current = try await store.current(mediaIDs: ids, languageID: 1)
        #expect(current[33]?.title == "p33")
        #expect(current[76]?.title == "p76")
        #expect(await source.currentCalls.map(\.count) == [50, 50, 22])
    }

    @Test func currentWithNoIDsSkipsRequest() async throws {
        let source = MockEPGSource()
        let store = EPGStore(source: source)
        #expect(try await store.current(mediaIDs: [], languageID: nil).isEmpty)
        #expect(await source.currentCalls.isEmpty)
    }
}

/// Отчёт пользователя: в списке каналов «текущие» передачи не менялись со временем.
@Suite struct NowPlayingRefreshTests {
    let now = Date(timeIntervalSince1970: 10_000)

    func program(_ id: Int, start: TimeInterval, stop: TimeInterval) -> Program {
        Program(mediaID: id, start: now.addingTimeInterval(start), stop: now.addingTimeInterval(stop), title: "p\(id)")
    }

    @Test func refreshesWhenEarliestProgramEnds() {
        let programs = [program(1, start: -600, stop: 20), program(2, start: -60, stop: 1_000)]
        #expect(NowPlayingRefresh.delay(after: programs, now: now) == 20 + NowPlayingRefresh.margin)
    }

    @Test func refreshesAtLeastEveryMinute() {
        let programs = [program(1, start: -600, stop: 3_600)]
        #expect(NowPlayingRefresh.delay(after: programs, now: now) == NowPlayingRefresh.maxDelay)
        #expect(NowPlayingRefresh.delay(after: [], now: now) == NowPlayingRefresh.maxDelay)
    }

    @Test func alreadyEndedProgramDoesNotSpin() {
        let programs = [program(1, start: -600, stop: -5)]
        #expect(NowPlayingRefresh.delay(after: programs, now: now) == NowPlayingRefresh.minDelay)
    }
}

actor FlakyEPGSource: EPGSource {
    func epg(mediaIDs: [Int], languageID: Int?) async throws -> EPGResponse {
        if mediaIDs.contains(1) { throw PortalError.decoding("chunk failed") }
        return EPGResponse(programs: mediaIDs.map {
            Program(mediaID: $0, start: Date(timeIntervalSince1970: 0), stop: Date(timeIntervalSince1970: 600), title: "p\($0)")
        })
    }
    func epg(mediaID: Int, day: String, languageID: Int?) async throws -> EPGResponse { EPGResponse(programs: []) }
}

@Suite struct EPGCurrentChunkTests {
    // Сбой одной пачки не выбрасывает остальные: раньше весь ответ терялся и в списке оставались старые передачи.
    @Test func failedChunkKeepsOtherChunks() async throws {
        let store = EPGStore(source: FlakyEPGSource())
        let ids = Array(1...(EPGStore.chunkSize + 3))
        let current = try await store.current(mediaIDs: ids, languageID: nil)
        #expect(current[1] == nil)
        #expect(current[EPGStore.chunkSize + 1] != nil)
        #expect(current.count == 3)
    }
}

/// Живой эфир (05.10.2026): общий запрос «сейчас» у 40 каналов расходится с расписанием на день
/// (CineMan и др. — на +2 ч), титры в кадре совпадают с расписанием на день. Поэтому «сейчас»
/// берётся из расписания на день, общий запрос — только для каналов без расписания.
actor BothSource: EPGSource {
    var days: [String: [Program]] = [:]
    var bulk: [Program] = []
    var bulkCalls: [[Int]] = []
    var dayCalls = 0
    func set(day: String, _ programs: [Program]) { days[day] = programs }
    func set(bulk programs: [Program]) { bulk = programs }
    func epg(mediaIDs: [Int], languageID: Int?) async throws -> EPGResponse {
        bulkCalls.append(mediaIDs)
        return EPGResponse(programs: bulk.filter { mediaIDs.contains($0.mediaID) })
    }
    func epg(mediaID: Int, day: String, languageID: Int?) async throws -> EPGResponse {
        dayCalls += 1
        return EPGResponse(programs: (days[day] ?? []).filter { $0.mediaID == mediaID })
    }
}

@Suite struct NowPlayingFromScheduleTests {
    let now = PortalDate.parse("2026-10-05 13:00:00+0500")!

    func p(_ id: Int, _ start: String, _ stop: String, _ title: String) -> Program {
        Program(mediaID: id, start: PortalDate.parse("2026-10-05 \(start):00+0500")!,
                stop: PortalDate.parse("2026-10-05 \(stop):00+0500")!, title: title)
    }

    @Test func dayScheduleWinsOverBulk() async {
        let source = BothSource()
        await source.set(day: "2026-10-05", [p(100, "12:10", "13:50", "Летят журавли")])
        await source.set(bulk: [p(100, "12:08", "14:41", "Бесславные ублюдки")])
        let current = await EPGStore(source: source).nowPlaying(mediaIDs: [100], languageID: nil, now: now)
        #expect(current[100]?.title == "Летят журавли")
    }

    @Test func channelWithoutDayScheduleFallsBackToBulk() async {
        let source = BothSource()
        await source.set(bulk: [p(5, "12:30", "13:30", "Новости")])
        let current = await EPGStore(source: source).nowPlaying(mediaIDs: [5], languageID: nil, now: now)
        #expect(current[5]?.title == "Новости")
        #expect(await source.bulkCalls == [[5]])
    }

    // Расписание есть, но сейчас пусто — передачи нет; общий запрос не подставляется.
    @Test func gapInDayScheduleIsNotFilledFromBulk() async {
        let source = BothSource()
        await source.set(day: "2026-10-05", [p(7, "09:00", "11:00", "Утро")])
        await source.set(bulk: [p(7, "12:00", "14:00", "Не то")])
        let current = await EPGStore(source: source).nowPlaying(mediaIDs: [7], languageID: nil, now: now)
        #expect(current[7] == nil)
        #expect(await source.bulkCalls.isEmpty)
    }

    @Test func dayScheduleIsCachedBetweenRefreshes() async {
        let source = BothSource()
        await source.set(day: "2026-10-05", [p(1, "12:00", "14:00", "A"), p(2, "12:00", "14:00", "B")])
        let store = EPGStore(source: source)
        _ = await store.nowPlaying(mediaIDs: [1, 2], languageID: nil, now: now)
        _ = await store.nowPlaying(mediaIDs: [1, 2], languageID: nil, now: now.addingTimeInterval(60))
        #expect(await source.dayCalls == 2)
    }
}

@Suite struct NowPlayingMidnightTests {
    @Test func programFromPreviousDayCrossingMidnight() async {
        let source = BothSource()
        await source.set(day: "2026-10-04", [Program(mediaID: 8, start: PortalDate.parse("2026-10-04 23:00:00+0500")!,
                                                    stop: PortalDate.parse("2026-10-05 01:00:00+0500")!, title: "Время")])
        let early = PortalDate.parse("2026-10-05 00:30:00+0500")!
        let current = await EPGStore(source: source).nowPlaying(mediaIDs: [8], languageID: nil, now: early)
        #expect(current[8]?.title == "Время")
    }
}
