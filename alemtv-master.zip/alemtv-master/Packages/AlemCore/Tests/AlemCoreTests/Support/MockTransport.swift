import Foundation
@testable import AlemCore

/// Отвечает заготовками по имени метода (последний компонент URL). Шифрованные вызовы
/// расшифровывает и шифрует ответ тем же фиксированным ключом, что отдаёт cipherFactory клиента.
final class MockTransport: HTTPTransport, @unchecked Sendable {
    struct Request {
        let url: URL
        let headers: [String: String]
        let body: Data
    }

    private let lock = NSLock()
    private var recorded: [Request] = []
    private let responses: [String: Data]
    private let status: Int
    let cipher: AresCipher

    init(responses: [String: Data], status: Int = 200, cipher: AresCipher = AresCipher(key: Array(repeating: 7, count: 16))) {
        self.responses = responses
        self.status = status
        self.cipher = cipher
    }

    var requests: [Request] { lock.withLock { recorded } }

    func post(_ url: URL, headers: [String: String], body: Data) async throws -> (Data, Int) {
        lock.withLock { recorded.append(Request(url: url, headers: headers, body: body)) }
        guard let data = responses[url.lastPathComponent] else { throw URLError(.badServerResponse) }
        if headers["Ares-Cipher"] != nil {
            return (Data(try cipher.encrypt(data).utf8), status)
        }
        return (data, status)
    }

    /// Тело запроса как JSON (расшифрованное, если вызов шифрованный).
    func json(_ request: Request) throws -> JSONValue {
        let plain = request.headers["Ares-Cipher"] != nil
            ? try cipher.decrypt(String(decoding: request.body, as: UTF8.self))
            : request.body
        return try JSONDecoder().decode(JSONValue.self, from: plain)
    }
}
