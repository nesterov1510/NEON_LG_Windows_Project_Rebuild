import Foundation
@testable import AlemCore

enum Fixture {
    struct Missing: Error { let name: String }

    static func data(_ name: String) throws -> Data {
        guard let url = Bundle.module.url(forResource: name, withExtension: "json", subdirectory: "Fixtures") else {
            throw Missing(name: name)
        }
        return try Data(contentsOf: url)
    }

    /// Поле `result` JSON-RPC ответа.
    static func result(_ name: String) throws -> JSONValue {
        try JSONDecoder().decode(JSONValue.self, from: data(name))["result"] ?? .null
    }

    static func authorize() throws -> AuthorizeResult {
        try AuthorizeResult(json: result("authorize_terminal"))
    }
}
