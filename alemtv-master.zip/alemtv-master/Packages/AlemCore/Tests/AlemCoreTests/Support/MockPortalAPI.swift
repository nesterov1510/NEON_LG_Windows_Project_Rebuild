import Foundation
@testable import AlemCore

actor MockPortalAPI: PortalAPI {
    var calls: [String] = []
    var session: String?
    var mac: String?
    var loginResult: Result<LoginResult, PortalError> = .success(LoginResult(sessionID: "SID", userID: 1))
    var registerResult: Result<LoginResult, PortalError> = .success(LoginResult(sessionID: "SID2", macaddr: "00:1A:79:00:00:01", userID: 1))
    var authorization: AuthorizeResult
    var updates: [CheckUpdateResult] = []
    var checkUpdateError: PortalError?
    var unregisterError: PortalError?

    init(authorization: AuthorizeResult) {
        self.authorization = authorization
    }

    func setLogin(_ r: Result<LoginResult, PortalError>) { loginResult = r }
    func setUpdates(_ u: [CheckUpdateResult]) { updates = u }
    func setAuthorization(_ a: AuthorizeResult) { authorization = a }
    func setCheckUpdateError(_ e: PortalError?) { checkUpdateError = e }
    func setUnregisterError(_ e: PortalError?) { unregisterError = e }

    func setSession(_ id: String?) { session = id }
    func setMacaddr(_ m: String?) { mac = m }

    func getDomainConfig() async throws -> DomainConfig {
        calls.append("get_domain_config")
        return DomainConfig(name: "tmalem", updatedOn: 100, serverNow: Date(timeIntervalSince1970: 1_000_000))
    }

    func login(macaddr: String?) async throws -> LoginResult {
        calls.append("login")
        return try loginResult.get()
    }

    func registerTerminal(username: String, password: String, macaddr: String?) async throws -> LoginResult {
        calls.append("register_terminal")
        return try registerResult.get()
    }

    func unregisterTerminal(macaddr: String) async throws {
        calls.append("unregister_terminal")
        if let unregisterError { throw unregisterError }
    }

    func authorizeTerminal(nocache: Bool) async throws -> AuthorizeResult {
        calls.append(nocache ? "authorize_terminal(nocache)" : "authorize_terminal")
        return authorization
    }

    func checkUpdate() async throws -> CheckUpdateResult {
        calls.append("check_update")
        if let checkUpdateError {
            self.checkUpdateError = nil
            throw checkUpdateError
        }
        return updates.isEmpty ? CheckUpdateResult(authorized: true) : updates.removeFirst()
    }
}
