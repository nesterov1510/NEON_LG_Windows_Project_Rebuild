import Testing
import Foundation
@testable import AlemCore

@Suite struct PlaybackPolicyTests {
    let now = Date(timeIntervalSince1970: 100_000)

    /// Таблица пульта (spec §4). Review Focus 3 и 4.
    @Test func remoteTable() {
        typealias P = PlaybackPolicy
        // Просмотр, эфир
        #expect(P.action(for: .up, overlay: .none, kind: .live) == .previousChannel)
        #expect(P.action(for: .down, overlay: .none, kind: .live) == .nextChannel)
        #expect(P.action(for: .left, overlay: .none, kind: .live) == .showChannelList)
        #expect(P.action(for: .right, overlay: .none, kind: .live) == .ignore)
        #expect(P.action(for: .select, overlay: .none, kind: .live) == .showPanel)
        #expect(P.action(for: .playPause, overlay: .none, kind: .live) == .togglePause)
        #expect(P.action(for: .menu, overlay: .none, kind: .live) == .openGuide)
        // Просмотр, таймшифт: → перематывает, ← — список
        #expect(P.action(for: .right, overlay: .none, kind: .timeshift) == .skip(10))
        #expect(P.action(for: .left, overlay: .none, kind: .timeshift) == .showChannelList)
        #expect(P.action(for: .up, overlay: .none, kind: .timeshift) == .previousChannel)
        // Просмотр, архив: ←/→ перематывают, ↑/↓ ничего
        #expect(P.action(for: .left, overlay: .none, kind: .archive) == .skip(-10))
        #expect(P.action(for: .right, overlay: .none, kind: .archive) == .skip(10))
        #expect(P.action(for: .up, overlay: .none, kind: .archive) == .ignore)
        #expect(P.action(for: .down, overlay: .none, kind: .archive) == .ignore)
        // Панель: навигация — фокусу, Menu закрывает панель, Play/Pause работает
        for key in [RemoteKey.up, .down, .left, .right, .select] {
            #expect(P.action(for: key, overlay: .panel, kind: .live) == .ignore)
        }
        #expect(P.action(for: .menu, overlay: .panel, kind: .live) == .hidePanel)
        #expect(P.action(for: .playPause, overlay: .panel, kind: .archive) == .togglePause)
        // Список каналов и программа: навигация — фокусу, Menu закрывает оверлей
        for key in [RemoteKey.up, .down, .left, .right, .select, .playPause] {
            #expect(P.action(for: key, overlay: .channelList, kind: .live) == .ignore)
            #expect(P.action(for: key, overlay: .schedule, kind: .live) == .ignore)
        }
        #expect(P.action(for: .menu, overlay: .channelList, kind: .live) == .closeOverlay)
        #expect(P.action(for: .menu, overlay: .schedule, kind: .live) == .closeOverlay)
        // Ошибка: Menu — в гид, ←/→ — кнопкам оверлея
        #expect(P.action(for: .menu, overlay: .error, kind: .live) == .openGuide)
        #expect(P.action(for: .left, overlay: .error, kind: .live) == .ignore)
        #expect(P.action(for: .right, overlay: .error, kind: .live) == .ignore)
    }

    // Отчёт пользователя: канал не показывает, программы нет — нельзя уйти с канала.
    // С экрана ошибки ↑/↓ переключают канал, как при просмотре (в архиве — нет).
    @Test func errorScreenDoesNotTrapOnChannel() {
        typealias P = PlaybackPolicy
        #expect(P.action(for: .up, overlay: .error, kind: .live) == .previousChannel)
        #expect(P.action(for: .down, overlay: .error, kind: .live) == .nextChannel)
        #expect(P.action(for: .down, overlay: .error, kind: .timeshift) == .nextChannel)
        #expect(P.action(for: .down, overlay: .error, kind: .archive) == .ignore)
    }

    // Final review Important 1: «−10 с» из эфира должен уйти в таймшифт, а не перезапустить эфир.
    @Test func backwardSkipFromLiveGoesToTimeshift() {
        let shown = now.addingTimeInterval(-20)   // задержка HLS
        #expect(PlaybackPolicy.skip(by: -10, contentTime: shown, now: now, archiveDepth: 259_200) == .timeshift(behind: 30))
    }

    @Test func forwardSkipNearLiveSnapsToLive() {
        let shown = now.addingTimeInterval(-40)
        #expect(PlaybackPolicy.skip(by: 10, contentTime: shown, now: now, archiveDepth: 259_200) == .live)
        let deep = now.addingTimeInterval(-600)
        #expect(PlaybackPolicy.skip(by: 10, contentTime: deep, now: now, archiveDepth: 259_200) == .timeshift(behind: 590))
    }

    @Test func backwardSkipIsClampedToArchiveDepth() {
        let shown = now.addingTimeInterval(-995)
        #expect(PlaybackPolicy.skip(by: -10, contentTime: shown, now: now, archiveDepth: 1_000) == .timeshift(behind: 1_000))
    }

    // Final review Important 6: «текущая передача» считается по времени нового потока, а не старого кадра.
    @Test func programReferenceTimeFollowsRequestedMode() {
        #expect(PlaybackPolicy.referenceTime(for: .live, now: now) == now)
        #expect(PlaybackPolicy.referenceTime(for: .timeshift(behind: 300), now: now) == now.addingTimeInterval(-300))
        let start = Date(timeIntervalSince1970: 50_000)
        #expect(PlaybackPolicy.referenceTime(for: .archive(start: start, duration: 600), now: now) == start)
    }

    // Final review Important 7: после возврата из фона эфир возобновляется на live-edge, запись — с места.
    @Test func resumeAfterBackground() {
        #expect(PlaybackPolicy.resumeAfterBackground(isLive: true) == .reloadLive)
        // Поток останавливается при уходе в фон (трафик не тратится) — запись и таймшифт
        // загружаются заново с места, где остановились, а не «продолжить» закрытый поток.
        #expect(PlaybackPolicy.resumeAfterBackground(isLive: false) == .reloadAtPosition)
    }
}
