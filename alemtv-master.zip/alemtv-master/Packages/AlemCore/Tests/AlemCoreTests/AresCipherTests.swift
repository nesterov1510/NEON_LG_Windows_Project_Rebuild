import Testing
import Foundation
@testable import AlemCore

@Suite struct AresCipherTests {
    let key: [UInt8] = (0..<16).map { UInt8($0) }
    var cipher: AresCipher { AresCipher(key: key) }

    private func hex(_ bytes: [UInt8]) -> String { bytes.map { String(format: "%02x", $0) }.joined() }

    @Test func headerBlockMatchesPythonReference() {
        let block = AresCipher.headerBlock(key: key, timestamp: 1_700_000_000)
        #expect(block.count == 78)
        #expect(hex(block) == "01006165730000000000000000000000000063626300000000006261736536340000800010002e003e0000f15365000102030405060708090a0b0c0d0e0f61726573637279707420202020202020")
    }

    @Test func encryptMatchesPythonReference() throws {
        let plain = Data(#"{"jsonrpc":"2.0","id":1,"method":"login","params":{"macaddr":null}}"#.utf8)
        #expect(try cipher.encrypt(plain) == "7nGcuIoK3zJZgGc/W5Zkqyxv0rKQDnS9Tre7G2e5oCmPXbw8qKjvTVRqHpAbxcOdYgTii11X5aGINF/XKxZpo5VKk0SPW78v/yeZ0EdvE4k=")
    }

    @Test func decryptRoundTrip() throws {
        let plain = Data("{\"result\":{\"session_id\":\"SID\"}}".utf8)
        #expect(try cipher.decrypt(cipher.encrypt(plain)) == plain)
    }

    @Test func cyrillicIsUTF8() throws {
        #expect(try cipher.encrypt(Data("Привет".utf8)) == "3sPPfhhXQCKpLVq6AyuboA==")
    }

    @Test func decryptRejectsGarbage() {
        #expect(throws: AresCipherError.self) { try cipher.decrypt("!!!не base64!!!") }
    }

    @Test func rsaHeaderIs128Bytes() throws {
        let header = try cipher.header(timestamp: 1_700_000_000)
        #expect(Data(base64Encoded: header)?.count == 128)
    }

    @Test func randomKeysDiffer() {
        #expect(AresCipher.random().key != AresCipher.random().key)
    }
}
