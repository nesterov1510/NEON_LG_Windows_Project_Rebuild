import Testing
@testable import AlemCore

@Test func versionIsSet() {
    #expect(AlemCore.version == "0.1.0")
}
