import Testing
import Foundation
@testable import AlemCore

@Suite struct PlaybackTests {
    func t(_ s: TimeInterval) -> Date { Date(timeIntervalSince1970: s) }

    @Test func frozenPositionTriggersAfterThreshold() {
        var w = FreezeWatchdog(threshold: 6)
        var fired: [Int] = []
        for second in 0...10 where w.observe(position: 42, wantsToPlay: true, likelyToKeepUp: false, now: t(Double(second))) {
            fired.append(second)
        }
        // 0: первое наблюдение; с 1 начинается заморозка; срабатывает на 7; затем отсчёт заново с 8
        #expect(fired == [7])
    }

    @Test func movingPositionNeverTriggers() {
        var w = FreezeWatchdog()
        for second in 0...20 {
            let fired = w.observe(position: Double(second), wantsToPlay: true, likelyToKeepUp: false, now: t(Double(second)))
            #expect(!fired)
        }
    }

    @Test func pausedOrHealthyBufferNeverTriggers() {
        var w = FreezeWatchdog()
        for second in 0...20 {
            let fired = w.observe(position: 5, wantsToPlay: false, likelyToKeepUp: false, now: t(Double(second)))
            #expect(!fired)
        }
        var h = FreezeWatchdog()
        for second in 0...20 {
            let fired = h.observe(position: 5, wantsToPlay: true, likelyToKeepUp: true, now: t(Double(second)))
            #expect(!fired)
        }
    }

    @Test func resetForgetsHistory() {
        var w = FreezeWatchdog(threshold: 2)
        _ = w.observe(position: 1, wantsToPlay: true, likelyToKeepUp: false, now: t(0))
        _ = w.observe(position: 1, wantsToPlay: true, likelyToKeepUp: false, now: t(1))
        w.reset()
        let fired = w.observe(position: 1, wantsToPlay: true, likelyToKeepUp: false, now: t(3))
        #expect(!fired)
    }

    @Test func idleMonitor() {
        var m = IdleMonitor(timeout: 100, now: t(0))
        #expect(!m.isExpired(now: t(99)))
        #expect(m.isExpired(now: t(100)))
        m.touch(now: t(90))
        #expect(!m.isExpired(now: t(150)))
    }

    @Test func failureSummaryNeverContainsURLOrToken() {
        let url = "http://119.235.117.209:8010/AltynAsyr/index.fmp4.m3u8?token=token%3DSECRET"
        let underlying = NSError(domain: NSURLErrorDomain, code: -1022,
                                 userInfo: [NSURLErrorFailingURLStringErrorKey: url, NSLocalizedDescriptionKey: "failed \(url)"])
        let error = NSError(domain: "CoreMediaErrorDomain", code: -1022, userInfo: [NSUnderlyingErrorKey: underlying])
        let summary = PlaybackFailure.summary(error: error, log: [(NSURLErrorDomain, -1022, "ATS \(url)")])
        #expect(!summary.contains("SECRET"))
        #expect(!summary.contains("http"))
        #expect(summary.contains("CoreMediaErrorDomain -1022"))
        #expect(summary.contains("\(NSURLErrorDomain) -1022"))
    }
}
