import Testing
import Foundation
@testable import AlemCore

@Suite struct PortalClientTests {
    let terminal = TerminalInfo.appleTV(appVersion: "0.1.0", osVersion: "17.0")

    func makeClient(_ responses: [String: Data], status: Int = 200) -> (PortalClient, MockTransport) {
        let transport = MockTransport(responses: responses, status: status)
        let client = PortalClient(baseURL: URL(string: "http://telecom.alemtv.tm")!, terminal: terminal,
                                  transport: transport, cipherFactory: { [cipher = transport.cipher] in cipher })
        return (client, transport)
    }

    @Test func terminalInfo() {
        #expect(terminal.terminalType == "appletv")
        #expect(terminal.firmwareVersion == "tvOS 17.0; AlemTV 0.1.0")
        #expect(terminal.userAgent == "AlemTV-tvOS/0.1.0 (AppleTV; tvOS 17.0)")
    }

    @Test func plainCallInjectsSessionAndHeaders() async throws {
        let (client, transport) = makeClient(["get_epg": try Fixture.data("get_epg_now")])
        await client.setSession("SID")
        let r = try await client.epg(mediaIDs: [33, 76], languageID: 1)
        #expect(r.programs.count == 2)
        let request = try #require(transport.requests.first)
        #expect(request.url.absoluteString == "http://telecom.alemtv.tm/jsonrpc/get_epg")
        #expect(request.headers["Content-Type"] == "application/x-www-form-urlencoded; charset=UTF-8")
        #expect(request.headers["User-Agent"] == terminal.userAgent)
        #expect(request.headers["Ares-Cipher"] == nil)
        let body = try transport.json(request)
        #expect(body["jsonrpc"]?.string == "2.0")
        #expect(body["method"]?.string == "get_epg")
        #expect(body["params"]?["session_id"]?.string == "SID")
        #expect(body["params"]?["media_id"] == [33, 76])
        #expect(body["params"]?["result_as"]?.string == "csv")
    }

    @Test func macaddrUsedWithoutSession() async throws {
        let (client, transport) = makeClient(["get_domain_config": try Fixture.data("get_domain_config")])
        await client.setMacaddr("00:1A:79:00:00:01")
        _ = try await client.getDomainConfig()
        let body = try transport.json(try #require(transport.requests.first))
        #expect(body["params"]?["macaddr"]?.string == "00:1A:79:00:00:01")
        #expect(body["params"]?["session_id"] == nil)
        #expect(body["params"]?["terminal_type"]?.string == "appletv")
    }

    @Test func encryptedLoginRoundTrip() async throws {
        let (client, transport) = makeClient(["login": try Fixture.data("login")])
        let r = try await client.login(macaddr: "00:1A:79:00:00:01")
        #expect(r.sessionID == "SID")
        let request = try #require(transport.requests.first)
        #expect(request.headers["Ares-Cipher"] != nil)
        let params = try transport.json(request)["params"]
        #expect(params?["macaddr"]?.string == "00:1A:79:00:00:01")
        #expect(params?["create_macaddr"] == false)
        #expect(params?["require_session"] == true)
        #expect(params?["terminal_type"]?.string == "appletv")
    }

    @Test func registerWithoutMacRequestsCreation() async throws {
        let (client, transport) = makeClient(["register_terminal": try Fixture.data("register_terminal")])
        let r = try await client.registerTerminal(username: "Ýazgyly", password: "пароль", macaddr: nil)
        #expect(r.macaddr == "00:1A:79:00:00:01")
        let params = try transport.json(try #require(transport.requests.first))["params"]
        #expect(params?["macaddr"] == JSONValue.null)
        #expect(params?["create_macaddr"] == true)
        #expect(params?["username"]?.string == "Ýazgyly")
        #expect(params?["password"]?.string == "пароль")
    }

    @Test func errorCodesAreMapped() async throws {
        let notFound = Data(#"{"jsonrpc":"2.0","id":1,"error":{"code":-32002,"message":"not found"}}"#.utf8)
        let (c1, _) = makeClient(["authorize_terminal": notFound])
        await #expect(throws: PortalError.notFound("not found")) { try await c1.authorizeTerminal(nocache: false) }

        let denied = Data(#"{"jsonrpc":"2.0","id":1,"error":{"code":-32003,"message":"Доступ запрещен"}}"#.utf8)
        let (c2, _) = makeClient(["check_update": denied])
        await #expect(throws: PortalError.unauthorized("Доступ запрещен")) { try await c2.checkUpdate() }

        let other = Data(#"{"jsonrpc":"2.0","id":1,"error":{"code":-1,"message":"limit"}}"#.utf8)
        let (c3, _) = makeClient(["check_update": other])
        await #expect(throws: PortalError.server(code: -1, message: "limit")) { try await c3.checkUpdate() }
    }

    @Test func httpErrorAndTransportError() async throws {
        let (c1, _) = makeClient(["check_update": Data("{}".utf8)], status: 502)
        await #expect(throws: PortalError.http(502)) { try await c1.checkUpdate() }
        let (c2, _) = makeClient([:])
        await #expect(throws: PortalError.self) { try await c2.checkUpdate() }
    }

    @Test func badJSONIsDecodingError() async throws {
        let (client, _) = makeClient(["check_update": Data("<html>".utf8)])
        do {
            _ = try await client.checkUpdate()
            Issue.record("expected error")
        } catch let error as PortalError {
            if case .decoding = error {} else { Issue.record("unexpected \(error)") }
        }
    }

    @Test func authorizeParamsAndFavorites() async throws {
        let ok = Data(#"{"jsonrpc":"2.0","id":1,"result":null}"#.utf8)
        let (client, transport) = makeClient([
            "authorize_terminal": try Fixture.data("authorize_terminal"),
            "insert_playlist_media": ok,
            "delete_playlist_media": ok,
            "set_terminal_params": ok,
        ])
        await client.setSession("SID")
        let a = try await client.authorizeTerminal(nocache: true)
        #expect(!a.channels.isEmpty)
        try await client.setFavorite(true, playlistID: 16, mediaID: 33)
        try await client.setFavorite(false, playlistID: 16, mediaID: 33)
        try await client.setTerminalParams(["media_id": 33])
        let methods = transport.requests.map(\.url.lastPathComponent)
        #expect(methods == ["authorize_terminal", "insert_playlist_media", "delete_playlist_media", "set_terminal_params"])
        let auth = try transport.json(transport.requests[0])["params"]
        #expect(auth?["version"] == 2)
        #expect(auth?["require_media_tokens"] == true)
        #expect(auth?["require_media_keys"] == false)
        #expect(auth?["nocache"] == true)
        let fav = try transport.json(transport.requests[1])["params"]
        #expect(fav?["playlist_id"] == 16)
        #expect(fav?["media_id"] == 33)
    }

    @Test func dayEPGParams() async throws {
        let (client, transport) = makeClient(["get_epg": try Fixture.data("get_epg_day")])
        await client.setSession("SID")
        let r = try await client.epg(mediaID: 33, day: "2026-10-03", languageID: 1)
        #expect(r.programs.allSatisfy { $0.mediaID == 33 })
        let params = try transport.json(try #require(transport.requests.first))["params"]
        #expect(params?["start"]?.string == "2026-10-03 00:00:00")
        #expect(params?["stop"]?.string == "2026-10-03 23:59:59")
        #expect(params?["language_id"] == 1)
    }
}
