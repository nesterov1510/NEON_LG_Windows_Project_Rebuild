import Testing
import Foundation
@testable import AlemCore

/// Переходы состояний движка по событиям VLC (final review: Important 1, 2, Minor 3 → Important).
/// Мутирующие вызовы вынесены из `#expect`: макрос не допускает мутацию.
@Suite struct EngineStateMachineTests {
    func t(_ s: TimeInterval) -> Date { Date(timeIntervalSince1970: 1_000 + s) }

    func playing(finite: Bool = false) -> EngineStateMachine {
        var m = EngineStateMachine()
        _ = m.load(finite: finite, at: t(0))
        _ = m.handle(.playing, at: t(1))
        return m
    }

    @Test func stoppedAfterStopOrDuringLoadIsNotAnError() {
        var m = EngineStateMachine()
        _ = m.load(finite: false, at: t(0))
        let duringLoad = m.handle(.stopped(position: 0), at: t(1))      // stopped старого потока при смене канала
        #expect(duringLoad == nil)
        var p = playing()
        _ = p.stop()
        let afterStop = p.handle(.stopped(position: 0.5), at: t(2))
        #expect(afterStop == nil)
        #expect(p.state == .idle)
    }

    @Test func liveStopIsFailureEvenNearEnd() {
        var m = playing(finite: false)
        let r = m.handle(.stopped(position: 0.99), at: t(5))
        #expect(r == .failed("stopped"))
    }

    @Test func archiveStopNearEndIsEnded() {
        var m = playing(finite: true)
        let end = m.handle(.stopped(position: 0.99), at: t(5))
        #expect(end == .ended)
        var early = playing(finite: true)
        let broken = early.handle(.stopped(position: 0.5), at: t(5))
        #expect(broken == .failed("stopped"))
    }

    @Test func failureReportedOncePerLoad() {
        var m = playing()
        let first = m.handle(.error, at: t(2))
        let second = m.handle(.error, at: t(3))
        #expect(first == .failed("error"))
        #expect(second == nil)
        _ = m.load(finite: false, at: t(4))
        _ = m.handle(.playing, at: t(5))
        let afterReload = m.handle(.error, at: t(6))
        #expect(afterReload == .failed("error"))
    }

    @Test func rebufferingPausesAndResumes() {
        var m = playing()
        let start = m.handle(.buffering(0.3), at: t(2))
        let middle = m.handle(.buffering(0.6), at: t(3))
        let done = m.handle(.buffering(1.0), at: t(4))
        #expect(start == .loading)
        #expect(middle == nil)
        #expect(done == .playing)
        // Буфер заполнен во время загрузки — показ пошёл, даже без события «играет».
        var fresh = EngineStateMachine()
        _ = fresh.load(finite: false, at: t(0))
        let b0 = fresh.handle(.buffering(0), at: t(1))
        let b1 = fresh.handle(.buffering(1), at: t(2))
        #expect(b0 == nil)
        #expect(b1 == .playing)
    }

    // Apple TV: при смене канала VLC 4 остаётся в «играет» и шлёт только буферизацию —
    // без этого машина навсегда застревала в загрузке и через 20 с перезапускала живой поток.
    @Test func channelSwitchWithoutPlayingEventReachesPlaying() {
        var m = playing()
        _ = m.load(finite: false, at: t(10))
        let zero = m.handle(.buffering(0), at: t(11))
        let full = m.handle(.buffering(1), at: t(12))
        #expect(zero == nil)
        #expect(full == .playing)
    }

    // Новая загрузка во время загрузки заново отсчитывает таймаут.
    @Test func reloadWhileLoadingRestartsTimeout() {
        var m = EngineStateMachine()
        _ = m.load(finite: false, at: t(0))
        _ = m.load(finite: false, at: t(15))
        let beforeTimeout = m.isStalled(progress: 0, at: t(25))
        let afterTimeout = m.isStalled(progress: 0, at: t(35))
        #expect(!beforeTimeout)
        #expect(afterTimeout)
    }

    @Test func stuckLoadingIsReportedAfterTimeout() {
        var m = EngineStateMachine()
        _ = m.load(finite: false, at: t(0))
        let early = m.isStalled(progress: 0, at: t(19))
        let timeout = m.isStalled(progress: 0, at: t(20))
        let again = m.isStalled(progress: 0, at: t(21))          // одно срабатывание на эпизод
        #expect(!early)
        #expect(timeout)
        #expect(!again)
    }

    @Test func frozenPlaybackIsReported() {
        var m = playing()
        var fired = false
        for second in 2...12 where m.isStalled(progress: 42, at: t(Double(second))) { fired = true }
        #expect(fired)
        var moving = playing()
        var any = false
        for second in 2...30 where moving.isStalled(progress: Double(second), at: t(Double(second))) { any = true }
        #expect(!any)
    }

    @Test func pausedIsNeverStalled() {
        var m = playing()
        _ = m.handle(.paused, at: t(2))
        var any = false
        for second in 3...40 where m.isStalled(progress: 0, at: t(Double(second))) { any = true }
        #expect(!any)
    }
}
