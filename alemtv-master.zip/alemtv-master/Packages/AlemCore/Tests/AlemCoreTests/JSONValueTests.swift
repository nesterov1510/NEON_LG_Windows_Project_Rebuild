import Testing
import Foundation
@testable import AlemCore

@Suite struct JSONValueTests {
    @Test func decodesMixedObject() throws {
        let json = #"{"a":1,"b":"x","c":null,"d":true,"e":[1.5,2],"f":{"g":"h"}}"#
        let v = try JSONDecoder().decode(JSONValue.self, from: Data(json.utf8))
        #expect(v["a"]?.int == 1)
        #expect(v["b"]?.string == "x")
        #expect(v["c"]?.isNull == true)
        #expect(v["d"]?.bool == true)
        #expect(v["e"]?.array?.first?.double == 1.5)
        #expect(v["f"]?["g"]?.string == "h")
        #expect(v["missing"] == nil)
    }

    @Test func numericCoercions() {
        #expect(JSONValue.string("3600").int == 3600)
        #expect(JSONValue.int(259200).double == 259200)
        #expect(JSONValue.double(10).int == 10)
        #expect(JSONValue.double(10.5).int == nil)
        #expect(JSONValue.string("x").int == nil)
    }

    @Test func outOfRangeDoubleIsNotIntInsteadOfCrashing() {
        #expect(JSONValue.double(1e300).int == nil)
        #expect(JSONValue.double(-1e300).int == nil)
        #expect(JSONValue.double(.infinity).int == nil)
        #expect(JSONValue.double(.nan).int == nil)
    }

    @Test func encodesRoundTrip() throws {
        let v: JSONValue = ["jsonrpc": "2.0", "id": 7, "params": ["macaddr": nil, "flag": true, "ids": [1, 2]]]
        let data = try JSONEncoder().encode(v)
        let back = try JSONDecoder().decode(JSONValue.self, from: data)
        #expect(back == v)
    }

    @Test func csvRowsMapHeaderToCells() {
        let table: JSONValue = [["id", "name"], [1, "Altyn Asyr"], [2, "Miras"], "garbage"]
        let rows = CSVTable.rows(table)
        #expect(rows.count == 2)
        #expect(rows[0]["id"]?.int == 1)
        #expect(rows[1]["name"]?.string == "Miras")
    }

    @Test func csvRowsOfNonTableIsEmpty() {
        #expect(CSVTable.rows(nil).isEmpty)
        #expect(CSVTable.rows(.string("x")).isEmpty)
        #expect(CSVTable.rows([["id"]]).isEmpty)
    }
}
