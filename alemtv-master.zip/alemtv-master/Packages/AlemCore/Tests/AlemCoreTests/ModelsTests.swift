import Testing
import Foundation
@testable import AlemCore

@Suite struct ModelsTests {
    @Test func domainConfig() throws {
        let d = try DomainConfig(json: Fixture.result("get_domain_config"))
        #expect(d.name == "tmalem")
        #expect(d.portalUpdatePeriod == 300)
        #expect(d.autoPauseTimeout == 18000)
        #expect(d.allowTerminalReg)
        #expect(d.allowTerminalUnreg)
        #expect(d.useTimeshift)
        #expect(d.serverNow != nil)
    }

    @Test func authorizeParsesChannels() throws {
        let a = try Fixture.authorize()
        #expect(Set(a.channels.map(\.id)).isSuperset(of: [1, 33, 76, 108976]))
        let altyn = try #require(a.channel(id: 1))
        #expect(altyn.name == "Altyn Asyr")
        #expect(altyn.host == "119.235.117.209")
        #expect(altyn.port == 8010)
        #expect(altyn.path == "AltynAsyr/video.m3u8")
        #expect(altyn.auth == "iptvportal")
        #expect(altyn.key == "Key-1")
        #expect(altyn.encrypted)
        #expect(altyn.hasArchive)
        #expect(altyn.timeshiftArchiveLength == 259200)
        #expect(altyn.channelID == 9930001)
        let che = try #require(a.channel(id: 108976))
        #expect(!che.hasArchive)
    }

    @Test func channelsSortedByIndex() throws {
        let a = try Fixture.authorize()
        #expect(a.channels.map(\.index) == a.channels.map(\.index).sorted())
    }

    @Test func channelsInPlaylistSkipUnknownIDs() throws {
        let a = try Fixture.authorize()
        let tv = try #require(a.playlists.first { $0.name == "tv" })
        #expect(tv.mediaIDs.contains(999999))
        let ids = a.channels(in: tv).map(\.id)
        #expect(!ids.contains(999999))
        #expect(ids.first == 1)
    }

    @Test func favoritesAndState() throws {
        let a = try Fixture.authorize()
        #expect(a.favorites?.mediaIDs == [33])
        #expect(a.favorites?.isFavorites == true)
        #expect(a.lastMediaID == 33)
    }

    @Test func tokensLanguagesProfiles() throws {
        let a = try Fixture.authorize()
        #expect(a.tokens["Key-1"] == MediaToken(name: "Key-1", token1: "T1", token2: "T2"))
        #expect(a.timeshiftEnabled)
        #expect(a.languages.map(\.id) == [1, 2, 15])
        #expect(a.languages.map(\.code) == ["ru", "en", "tk"])
        #expect(a.language?.code == "ru")
        #expect(a.profiles.count == 2)
        #expect(a.profiles[1].requirePassword)
        #expect(a.profile?.id == 1)
        #expect(a.macaddr == "00:1A:79:00:00:01")
        #expect(a.epgInfo[33] != nil)
        #expect(a.serverNow != nil)
    }

    @Test func authorizeRejectsNonObject() {
        #expect(throws: PortalError.self) { try AuthorizeResult(json: .bool(false)) }
    }

    @Test func checkUpdate() throws {
        let u = try CheckUpdateResult(json: Fixture.result("check_update"))
        #expect(u.authorized)
        #expect(u.tokens?["Key-1"]?.token1 == "T1")
        #expect(u.subscriberUpdatedOn != nil)
        let bad = try CheckUpdateResult(json: Fixture.result("check_update_unauthorized"))
        #expect(!bad.authorized)
        #expect(bad.tokens == nil)
    }

    @Test func loginResults() throws {
        let l = try LoginResult(json: Fixture.result("login"))
        #expect(l.sessionID == "SID")
        #expect(l.macaddr == nil)
        let r = try LoginResult(json: Fixture.result("register_terminal"))
        #expect(r.macaddr == "00:1A:79:00:00:01")
        #expect(throws: PortalError.unauthorized("access denied")) { try LoginResult(json: .bool(false)) }
    }

    @Test func epgDay() throws {
        let e = try EPGResponse(json: Fixture.result("get_epg_day"), defaultMediaID: 33)
        #expect(e.programs.count == 22)
        let first = e.programs[0]
        #expect(first.mediaID == 33)
        #expect(first.start.timeIntervalSince1970 == 1_790_963_400)
        #expect(first.title == "Последний день Земли")
        #expect(first.ageLabel == "18+")
        #expect(e.programs.map(\.start) == e.programs.map(\.start).sorted())
    }

    @Test func epgNowUsesMediaIDColumn() throws {
        let e = try EPGResponse(json: Fixture.result("get_epg_now"), defaultMediaID: nil)
        #expect(Set(e.programs.map(\.mediaID)) == [33, 76])
    }

    @Test func programAgeSuffixIsSplit() {
        #expect(Program.splitAge("Вердикт за деньги (16+)") == ("Вердикт за деньги", "16+"))
        #expect(Program.splitAge("Новости") == ("Новости", nil))
        #expect(Program.splitAge("Шоу (live)") == ("Шоу (live)", nil))
    }

    @Test func profilePasswordFailsClosed() {
        let locked = Profile(id: 2, title: "18+", requirePassword: true, password: "1234")
        #expect(locked.accepts(password: "1234"))
        #expect(!locked.accepts(password: "0000"))
        #expect(!locked.accepts(password: ""))
        let unknown = Profile(id: 2, title: "18+", requirePassword: true, password: nil)
        #expect(!unknown.accepts(password: "1234"))
        #expect(!unknown.accepts(password: ""))
        let open = Profile(id: 1, title: "0+", requirePassword: false)
        #expect(open.accepts(password: ""))
    }

    @Test func lockedProfileMustBeRevertedUnlessUnlockedThisSession() {
        let adult = Profile(id: 2, title: "18+", requirePassword: true, password: "1234")
        let kids = Profile(id: 1, title: "0+")
        var a = AuthorizeResult(channels: [], playlists: [], profiles: [kids, adult], profile: adult)
        #expect(a.profileNeedsRevert(unlockedProfileID: nil) == kids)
        #expect(a.profileNeedsRevert(unlockedProfileID: 3) == kids)
        #expect(a.profileNeedsRevert(unlockedProfileID: 2) == nil)
        a.profile = kids
        #expect(a.profileNeedsRevert(unlockedProfileID: nil) == nil)
    }

    @Test func programProgress() {
        let p = Program(mediaID: 1, start: Date(timeIntervalSince1970: 1000), stop: Date(timeIntervalSince1970: 2000), title: "x")
        #expect(p.isOnAir(at: Date(timeIntervalSince1970: 1500)))
        #expect(!p.isOnAir(at: Date(timeIntervalSince1970: 2000)))
        #expect(p.progress(at: Date(timeIntervalSince1970: 1250)) == 0.25)
        #expect(p.progress(at: Date(timeIntervalSince1970: 5000)) == 1)
    }
}
