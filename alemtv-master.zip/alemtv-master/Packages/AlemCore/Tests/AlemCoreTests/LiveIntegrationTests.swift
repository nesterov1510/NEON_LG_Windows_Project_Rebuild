import Testing
import Foundation
@testable import AlemCore

/// Живой прогон против telecom.alemtv.tm. Новых терминалов не создаёт: берёт MAC из reference/samples/.terminal.json.
/// Запуск: ALEMTV_LIVE=1 swift test --package-path Packages/AlemCore --filter LiveIntegrationTests
@Suite(.enabled(if: ProcessInfo.processInfo.environment["ALEMTV_LIVE"] == "1"), .serialized)
struct LiveIntegrationTests {
    static let root = URL(fileURLWithPath: #filePath)
        .deletingLastPathComponent()   // AlemCoreTests
        .deletingLastPathComponent()   // Tests
        .deletingLastPathComponent()   // AlemCore
        .deletingLastPathComponent()   // Packages
        .deletingLastPathComponent()   // корень репозитория

    func make() throws -> (SessionStore, PortalClient) {
        let data = try Data(contentsOf: Self.root.appendingPathComponent("reference/samples/.terminal.json"))
        let mac = try #require(try JSONDecoder().decode([String: String].self, from: data)["macaddr"])
        let store = InMemorySecureStore()
        store.set(mac, forKey: "mac")
        let client = PortalClient(baseURL: URL(string: "http://telecom.alemtv.tm")!,
                                  terminal: .appleTV(appVersion: "0.1.0", osVersion: "17.0"))
        return (SessionStore(api: client, store: store, macKey: "mac"), client)
    }

    @Test func signInWithBoundTerminal() async throws {
        let (session, _) = try make()
        guard case .signedIn(let a) = try await session.start() else {
            Issue.record("терминал не авторизован — перепривязать через tools/probe.py")
            return
        }
        #expect(a.channels.count > 100)
        #expect(a.timeshiftEnabled)
        #expect(!a.tokens.isEmpty)
        #expect(a.languages.map(\.code).contains("tk"))
    }

    /// Эфир, таймшифт и архив — TS с видео- и аудиодорожкой, без скремблирования.
    @Test func streamsAreCleanTS() async throws {
        let (session, _) = try make()
        guard case .signedIn(let a) = try await session.start() else { Issue.record("not signed in"); return }
        let channel = try #require(a.channels.first { $0.hasArchive && $0.key != nil })
        let context = try #require(await session.streamContext())
        let now = await session.clock.now()
        let modes: [StreamMode] = [
            .live,
            .timeshift(behind: 600),
            .archive(start: StreamURLBuilder.floorMinute(now.addingTimeInterval(-7_200)), duration: 600),
        ]
        for mode in modes {
            let url = try StreamURLBuilder.url(for: channel, mode: mode, context: context)
            let segment = try await firstSegment(of: url)
            let types = streamTypes(segment)
            #expect(!types.isDisjoint(with: [0x1b, 0x24, 0x02]), "\(mode): нет видео (\(types))")
            #expect(!types.isDisjoint(with: [0x0f, 0x11, 0x03, 0x04, 0x81, 0x06]), "\(mode): нет звука (\(types))")
            #expect(scrambledPackets(segment) == 0, "\(mode): поток скремблирован")
        }
    }

    @Test func epgHasProgramsForREN() async throws {
        let (session, client) = try make()
        _ = try await session.start()
        let epg = EPGStore(source: client)
        let programs = try await epg.programs(mediaID: 33, day: PortalDate.dayString(Date()), languageID: 1)
        #expect(!programs.isEmpty)
        let current = try await epg.current(mediaIDs: [33, 76], languageID: 1)
        #expect(current[33] != nil)
    }

    // MARK: - Помощники

    /// Спуск master → media → первый сегмент.
    func firstSegment(of url: URL) async throws -> Data {
        var current = url
        for _ in 0..<3 {
            let data = try await get(current)
            guard let text = String(data: data, encoding: .utf8), text.hasPrefix("#EXTM3U") else { return data }
            let line = try #require(text.split(separator: "\n").first { !$0.hasPrefix("#") && !$0.isEmpty })
            current = try #require(URL(string: String(line), relativeTo: current)?.absoluteURL)
        }
        return try await get(current)
    }

    /// stream_type элементарных потоков из PMT.
    func streamTypes(_ data: Data) -> Set<UInt8> {
        let bytes = [UInt8](data)
        var pmtPIDs = Set<Int>()
        var types = Set<UInt8>()
        var index = 0
        while index + 188 <= bytes.count {
            defer { index += 188 }
            guard bytes[index] == 0x47, bytes[index + 1] & 0x40 != 0 else { continue }
            let pid = (Int(bytes[index + 1] & 0x1f) << 8) | Int(bytes[index + 2])
            var offset = index + 4
            if bytes[index + 3] & 0x20 != 0 { offset += 1 + Int(bytes[index + 4]) }
            guard offset < index + 188 else { continue }
            offset += 1 + Int(bytes[offset])   // pointer_field
            guard offset + 12 < index + 188 else { continue }
            let sectionLength = (Int(bytes[offset + 1] & 0x0f) << 8) | Int(bytes[offset + 2])
            let end = min(offset + 3 + sectionLength - 4, index + 188)
            if pid == 0 {
                var j = offset + 8
                while j + 4 <= end {
                    let program = (Int(bytes[j]) << 8) | Int(bytes[j + 1])
                    if program != 0 { pmtPIDs.insert((Int(bytes[j + 2] & 0x1f) << 8) | Int(bytes[j + 3])) }
                    j += 4
                }
            } else if pmtPIDs.contains(pid) {
                var j = offset + 12 + ((Int(bytes[offset + 10] & 0x0f) << 8) | Int(bytes[offset + 11]))
                while j + 5 <= end {
                    types.insert(bytes[j])
                    j += 5 + ((Int(bytes[j + 3] & 0x0f) << 8) | Int(bytes[j + 4]))
                }
            }
        }
        return types
    }

    /// TS-пакеты с payload и ненулевыми scrambling_control битами.
    func scrambledPackets(_ data: Data) -> Int {
        let bytes = [UInt8](data)
        var index = bytes.firstIndex(of: 0x47) ?? bytes.count
        var scrambled = 0
        while index + 188 <= bytes.count {
            guard bytes[index] == 0x47 else { index += 1; continue }
            let pid = (Int(bytes[index + 1] & 0x1f) << 8) | Int(bytes[index + 2])
            if pid != 0, pid != 0x1fff, bytes[index + 3] & 0x10 != 0, bytes[index + 3] & 0xc0 != 0 {
                scrambled += 1
            }
            index += 188
        }
        return scrambled
    }

    /// 404 повторяется один раз (холодный архив Flussonic).
    func get(_ url: URL, retry: Bool = true) async throws -> Data {
        var request = URLRequest(url: url)
        request.setValue("bytes=0-199999", forHTTPHeaderField: "Range")
        let (data, response) = try await URLSession.shared.data(for: request)
        let status = (response as? HTTPURLResponse)?.statusCode ?? 0
        if status == 404 && retry {
            try await Task.sleep(for: .seconds(2))
            return try await get(url, retry: false)
        }
        try #require((200..<300).contains(status), "HTTP \(status)")
        return data
    }
}
