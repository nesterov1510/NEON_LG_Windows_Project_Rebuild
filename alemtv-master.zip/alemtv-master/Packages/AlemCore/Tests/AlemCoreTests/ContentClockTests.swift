import Testing
import Foundation
@testable import AlemCore

@Suite struct ContentClockTests {
    func t(_ s: TimeInterval) -> Date { Date(timeIntervalSince1970: 1_000_000 + s) }
    let programStart = Date(timeIntervalSince1970: 900_000)

    @Test func archiveTimeIsStartPlusPlayed() {
        var clock = ContentClock(mode: .archive(start: programStart, duration: 3600), startedAt: t(0))
        clock.didStartPlaying(at: t(2))
        #expect(clock.contentTime(at: t(32)) == programStart.addingTimeInterval(30))
    }

    @Test func pausesAndBufferingDoNotAdvanceTime() {
        var clock = ContentClock(mode: .archive(start: programStart, duration: 3600), startedAt: t(0))
        clock.didStartPlaying(at: t(0))
        clock.didStopPlaying(at: t(40))            // пауза или буферизация
        #expect(clock.playedTime(at: t(100)) == 40)
        clock.didStartPlaying(at: t(100))
        #expect(clock.contentTime(at: t(110)) == programStart.addingTimeInterval(50))
    }

    @Test func repeatedStartOrStopIsIdempotent() {
        var clock = ContentClock(mode: .archive(start: programStart, duration: 3600), startedAt: t(0))
        clock.didStartPlaying(at: t(0))
        clock.didStartPlaying(at: t(5))            // повторное «играет» не сбрасывает отсчёт
        clock.didStopPlaying(at: t(10))
        clock.didStopPlaying(at: t(20))            // повторная остановка ничего не добавляет
        #expect(clock.playedTime(at: t(30)) == 10)
    }

    @Test func archiveSeekSetsPosition() {
        var clock = ContentClock(mode: .archive(start: programStart, duration: 3600), startedAt: t(0))
        clock.didStartPlaying(at: t(0))
        clock.didSeek(toPosition: 120, at: t(10))
        #expect(clock.contentTime(at: t(15)) == programStart.addingTimeInterval(125))
        clock.didSeek(toPosition: -5, at: t(20))
        #expect(clock.playedTime(at: t(20)) == 0)
    }

    @Test func timeshiftStartsBehindAndAdvances() {
        var clock = ContentClock(mode: .timeshift(behind: 300), startedAt: t(0))
        clock.didStartPlaying(at: t(2))             // 2 с на открытие потока
        #expect(clock.contentTime(at: t(12)) == t(-300 + 10))
        #expect(clock.behindLive(at: t(12)) == 302)
    }

    @Test func liveIsNowMinusLatency() {
        let clock = ContentClock(mode: .live, startedAt: t(0))
        #expect(clock.contentTime(at: t(500)) == t(500 - ContentClock.liveLatency))
        #expect(clock.behindLive(at: t(500)) == ContentClock.liveLatency)
    }
}
