// swift-tools-version: 6.0
import PackageDescription

let package = Package(
    name: "AlemCore",
    platforms: [.tvOS(.v17), .macOS(.v14)],
    products: [.library(name: "AlemCore", targets: ["AlemCore"])],
    targets: [
        .target(name: "AlemCore"),
        .testTarget(
            name: "AlemCoreTests",
            dependencies: ["AlemCore"],
            resources: [.copy("Fixtures")]
        ),
    ]
)
