import Foundation

public enum StreamMode: Sendable, Equatable {
    case live
    /// Конечная запись: начало (UTC) и длительность в секундах.
    case archive(start: Date, duration: TimeInterval)
    /// Эфир с задержкой на `behind` секунд.
    case timeshift(behind: TimeInterval)
}

public struct StreamContext: Sendable {
    public var sessionID: String
    public var domain: String
    public var tokens: [String: MediaToken]
    public var serverNow: Date

    public init(sessionID: String, domain: String, tokens: [String: MediaToken], serverNow: Date) {
        self.sessionID = sessionID
        self.domain = domain
        self.tokens = tokens
        self.serverNow = serverNow
    }
}

public enum StreamURLError: Error, Equatable {
    case noLiveAddress
    case noArchive
    case invalidURL
}

/// URL потоков Flussonic по правилам портала IPTVPORTAL (`PORTAL_ANALYSIS.md` §3).
public enum StreamURLBuilder {
    /// Ближе этого к «сейчас» — играем эфир.
    public static let liveThreshold: TimeInterval = 10
    /// Передача, закончившаяся раньше этого, берётся как конечная запись.
    public static let archiveGrace: TimeInterval = 20 * 60

    public static func url(for channel: Channel, mode: StreamMode, context: StreamContext) throws -> URL {
        let base: String
        let auth: String?
        switch mode {
        case .live:
            base = try liveBase(channel)
            auth = channel.auth
        case .archive(let start, let duration):
            let startSeconds = Int(start.timeIntervalSince1970 - (channel.timeshiftOffset ?? 0))
            base = "\(try timeshiftBase(channel))/index-\(startSeconds)-\(max(0, Int(duration))).m3u8"
            auth = channel.timeshiftAuth ?? channel.auth
        case .timeshift(let behind):
            base = "\(try timeshiftBase(channel))/video-timeshift_rel-\(max(0, Int(behind))).m3u8"
            auth = channel.timeshiftAuth ?? channel.auth
        }
        let query = tokenQuery(channel: channel, auth: auth, context: context)
        let full = query.isEmpty ? base : base + (base.contains("?") ? "&" : "?") + query
        guard let url = URL(string: full) else { throw StreamURLError.invalidURL }
        return url
    }

    /// Режим для передачи EPG и позиции внутри неё (как `Fo` в портале).
    public static func mode(for program: Program, position: TimeInterval, now: Date) -> StreamMode {
        let start = floorMinute(program.start)
        let stop = floorMinute(program.stop)
        let at = start.addingTimeInterval(position)
        if stop.addingTimeInterval(archiveGrace) <= now {
            return .archive(start: at, duration: stop.timeIntervalSince(start) - position)
        }
        let behind = now.timeIntervalSince(at)
        return behind <= liveThreshold ? .live : .timeshift(behind: behind)
    }

    public static func isAvailableInArchive(_ program: Program, channel: Channel, timeshiftEnabled: Bool, now: Date) -> Bool {
        guard timeshiftEnabled, channel.hasArchive, let depth = channel.timeshiftArchiveLength else { return false }
        return program.start >= now.addingTimeInterval(-depth) && program.start < now
    }

    public static func floorMinute(_ date: Date) -> Date {
        Date(timeIntervalSince1970: (date.timeIntervalSince1970 / 60).rounded(.down) * 60)
    }

    // MARK: - Внутреннее

    static func liveBase(_ channel: Channel) throws -> String {
        if let path = channel.path, path.hasPrefix("http://") || path.hasPrefix("https://") { return path }
        guard let host = channel.host, !host.isEmpty else { throw StreamURLError.noLiveAddress }
        let scheme = (channel.scheme?.isEmpty == false) ? channel.scheme! : "http"
        let port = channel.port.map { ":\($0)" } ?? ""
        let path = String((channel.path ?? "").drop(while: { $0 == "/" }))
        return "\(scheme)://\(host)\(port)/\(path)"
    }

    static func timeshiftBase(_ channel: Channel) throws -> String {
        guard var base = channel.timeshiftURL, !base.isEmpty else { throw StreamURLError.noArchive }
        if let q = base.firstIndex(of: "?") { base = String(base[..<q]) }
        if base.hasSuffix(".m3u8"), let slash = base.lastIndex(of: "/") { base = String(base[..<slash]) }
        while base.hasSuffix("/") { base.removeLast() }
        return base
    }

    static func tokenQuery(channel: Channel, auth: String?, context: StreamContext) -> String {
        guard let auth else { return "" }
        let sessionAuth = auth.contains("iptvportal") || auth.contains("flussonic")
        var parts: [String] = []
        if sessionAuth { parts.append("token=\(context.sessionID)") }
        if auth.contains("iptvportal") || auth.contains("arescrypt"), let key = channel.key, let token = context.tokens[key] {
            parts += [
                "token1=\(token.token1)",
                "token2=\(token.token2)",
                "domain=\(context.domain)",
                "key=\(key)",
                "media_id=\(channel.id)",
                "timestamp=\(Int(context.serverNow.timeIntervalSince1970))",
            ]
            if auth.contains("iptvportal") {
                return "token=" + encodeURIComponent(parts.joined(separator: "&"))
            }
        }
        return parts.joined(separator: "&")
    }

    /// Как JS `encodeURIComponent`.
    static func encodeURIComponent(_ text: String) -> String {
        let allowed = CharacterSet(charactersIn: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_.!~*'()")
        return text.addingPercentEncoding(withAllowedCharacters: allowed) ?? text
    }
}
