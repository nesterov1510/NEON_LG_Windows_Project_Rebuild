import Foundation

/// `get_domain_config`.
public struct DomainConfig: Sendable, Equatable {
    public var name: String
    public var portalUpdatePeriod: Int
    public var autoPauseTimeout: TimeInterval
    public var allowTerminalReg: Bool
    public var allowTerminalUnreg: Bool
    public var useTimeshift: Bool
    public var updatedOn: Int
    public var serverNow: Date?

    public init(name: String = "tmalem", portalUpdatePeriod: Int = 300, autoPauseTimeout: TimeInterval = 18000,
                allowTerminalReg: Bool = true, allowTerminalUnreg: Bool = true, useTimeshift: Bool = true,
                updatedOn: Int = 0, serverNow: Date? = nil) {
        self.name = name
        self.portalUpdatePeriod = portalUpdatePeriod
        self.autoPauseTimeout = autoPauseTimeout
        self.allowTerminalReg = allowTerminalReg
        self.allowTerminalUnreg = allowTerminalUnreg
        self.useTimeshift = useTimeshift
        self.updatedOn = updatedOn
        self.serverNow = serverNow
    }

    public init(json: JSONValue) throws {
        guard json.object != nil else { throw PortalError.decoding("get_domain_config: not an object") }
        var settings: JSONValue?
        if let text = json["settings"]?.string, let data = text.data(using: .utf8) {
            settings = try? JSONDecoder().decode(JSONValue.self, from: data)
        }
        self.init(
            name: json["name"]?.string ?? "tmalem",
            portalUpdatePeriod: json["portal_update_period"]?.int ?? 300,
            autoPauseTimeout: settings?["auto_pause_timeout"]?.double ?? 18000,
            allowTerminalReg: json["allow_terminal_reg"]?.bool ?? true,
            allowTerminalUnreg: json["allow_terminal_unreg"]?.bool ?? true,
            useTimeshift: json["use_timeshift"]?.bool ?? true,
            updatedOn: json["updated_on"]?.int ?? 0,
            serverNow: json["now"]?.string.flatMap(PortalDate.parse)
        )
    }
}

/// `login` / `register_terminal`.
public struct LoginResult: Sendable, Equatable {
    public var sessionID: String
    public var macaddr: String?
    public var userID: Int?

    public init(sessionID: String, macaddr: String? = nil, userID: Int? = nil) {
        self.sessionID = sessionID
        self.macaddr = macaddr
        self.userID = userID
    }

    public init(json: JSONValue) throws {
        if json == .bool(false) { throw PortalError.unauthorized("access denied") }
        guard let session = json["session_id"]?.string, !session.isEmpty else {
            throw PortalError.decoding("login: no session_id")
        }
        self.init(sessionID: session, macaddr: json["macaddr"]?.string, userID: json["user_id"]?.int)
    }
}

/// `authorize_terminal` — всё состояние абонента.
public struct AuthorizeResult: Sendable {
    public var channels: [Channel]
    public var playlists: [Playlist]
    public var profiles: [Profile]
    public var profile: Profile?
    public var languages: [Language]
    public var language: Language?
    public var tokens: [String: MediaToken]
    public var timeshiftEnabled: Bool
    public var lastMediaID: Int?
    public var epgInfo: [Int: EPGInfo]
    public var serverNow: Date?
    public var macaddr: String?
    public var subscriberUpdatedOn: Int
    public var terminalUpdatedOn: Int
    private var channelsByID: [Int: Channel]

    public init(channels: [Channel], playlists: [Playlist], profiles: [Profile] = [], profile: Profile? = nil,
                languages: [Language] = [], language: Language? = nil, tokens: [String: MediaToken] = [:],
                timeshiftEnabled: Bool = true, lastMediaID: Int? = nil, epgInfo: [Int: EPGInfo] = [:],
                serverNow: Date? = nil, macaddr: String? = nil, subscriberUpdatedOn: Int = 0, terminalUpdatedOn: Int = 0) {
        self.channels = channels.sorted { $0.index < $1.index }
        self.playlists = playlists
        self.profiles = profiles
        self.profile = profile
        self.languages = languages
        self.language = language
        self.tokens = tokens
        self.timeshiftEnabled = timeshiftEnabled
        self.lastMediaID = lastMediaID
        self.epgInfo = epgInfo
        self.serverNow = serverNow
        self.macaddr = macaddr
        self.subscriberUpdatedOn = subscriberUpdatedOn
        self.terminalUpdatedOn = terminalUpdatedOn
        self.channelsByID = Dictionary(channels.map { ($0.id, $0) }, uniquingKeysWith: { first, _ in first })
    }

    public init(json: JSONValue) throws {
        guard json.object != nil else { throw PortalError.decoding("authorize_terminal: not an object") }
        let enabled = json["medialist_enabled"]?.object
        let channels = CSVTable.rows(json["medialist"])
            .filter { $0["is_tv"]?.bool == true }
            .compactMap(Channel.init(row:))
            .filter { enabled == nil || enabled?[String($0.id)] != nil }
        let timeshiftServiceIDs = (json["services"]?.array ?? [])
            .filter { $0["name"]?.string == "timeshift" }
            .compactMap { $0["id"]?.int }
        let servicesEnabled = json["services_enabled"]?.object ?? [:]
        self.init(
            channels: channels,
            playlists: (json["playlists"]?.array ?? []).compactMap(Playlist.init(json:)),
            profiles: (json["profiles"]?.array ?? []).compactMap(Profile.init(json:)),
            profile: json["profile"].flatMap(Profile.init(json:)),
            languages: (json["languages"]?.array ?? []).compactMap(Language.init(json:)),
            language: json["language"].flatMap(Language.init(json:)),
            tokens: MediaToken.parseAll(json["tokens"]) ?? [:],
            timeshiftEnabled: timeshiftServiceIDs.contains { servicesEnabled[String($0)] != nil },
            lastMediaID: json["state"]?["media_id"]?.int,
            epgInfo: EPGInfo.parseAll(json["epg_info"]) ?? [:],
            serverNow: json["now"]?.string.flatMap(PortalDate.parse),
            macaddr: json["macaddr"]?.string,
            subscriberUpdatedOn: json["subscriber_updated_on"]?.int ?? 0,
            terminalUpdatedOn: json["terminal_updated_on"]?.int ?? 0
        )
    }

    public func channel(id: Int) -> Channel? { channelsByID[id] }

    /// Каналы плейлиста в его порядке; id, которых нет в medialist, пропускаются.
    public func channels(in playlist: Playlist) -> [Channel] {
        playlist.mediaIDs.compactMap { channelsByID[$0] }
    }

    public var favorites: Playlist? { playlists.first(where: \.isFavorites) }

    /// Профиль с паролем, не разблокированный в этом сеансе (пароль не введён, окно закрыто,
    /// приложение перезапущено), откатывается на профиль без пароля — родительский контроль не обходится.
    public func profileNeedsRevert(unlockedProfileID: Int?) -> Profile? {
        guard let current = profile, current.requirePassword, current.id != unlockedProfileID else { return nil }
        return profiles.first { !$0.requirePassword }
    }

    /// Что показывать после перезагрузки каталога (смена подписки): сохраняем канал и рубрику,
    /// если они ещё доступны; иначе — первый канал рубрики, затем рубрика «Все».
    public func resolve(channelID: Int?, playlistID: Int?) -> (channel: Channel?, playlist: Playlist?) {
        let all = playlists.first { $0.name == "tv" }
        var playlist = playlists.first { $0.id == playlistID }
        if let current = playlist, channels(in: current).isEmpty { playlist = nil }
        if let id = channelID, let channel = channel(id: id) {
            if let current = playlist, current.mediaIDs.contains(id) { return (channel, current) }
            return (channel, all ?? playlist)
        }
        let target = playlist ?? all
        return (target.flatMap { channels(in: $0).first } ?? channels.first, target)
    }
}

/// `check_update`. Если сессия недействительна, сервер не ошибку возвращает, а опускает `authorized`.
public struct CheckUpdateResult: Sendable {
    public var authorized: Bool
    public var domainUpdatedOn: Int?
    public var subscriberUpdatedOn: Int?
    public var terminalUpdatedOn: Int?
    public var tokens: [String: MediaToken]?
    public var epgInfo: [Int: EPGInfo]?
    public var serverNow: Date?

    public init(authorized: Bool, domainUpdatedOn: Int? = nil, subscriberUpdatedOn: Int? = nil,
                terminalUpdatedOn: Int? = nil, tokens: [String: MediaToken]? = nil,
                epgInfo: [Int: EPGInfo]? = nil, serverNow: Date? = nil) {
        self.authorized = authorized
        self.domainUpdatedOn = domainUpdatedOn
        self.subscriberUpdatedOn = subscriberUpdatedOn
        self.terminalUpdatedOn = terminalUpdatedOn
        self.tokens = tokens
        self.epgInfo = epgInfo
        self.serverNow = serverNow
    }

    public init(json: JSONValue) throws {
        guard json.object != nil else { throw PortalError.decoding("check_update: not an object") }
        self.init(
            authorized: json["authorized"]?.bool ?? false,
            domainUpdatedOn: json["domain_updated_on"]?.int,
            subscriberUpdatedOn: json["subscriber_updated_on"]?.int,
            terminalUpdatedOn: json["terminal_updated_on"]?.int,
            tokens: MediaToken.parseAll(json["tokens"]),
            epgInfo: EPGInfo.parseAll(json["epg_info"]),
            serverNow: json["now"]?.string.flatMap(PortalDate.parse)
        )
    }
}

/// `get_epg`.
public struct EPGResponse: Sendable {
    public var serverNow: Date?
    public var programs: [Program]

    public init(serverNow: Date? = nil, programs: [Program]) {
        self.serverNow = serverNow
        self.programs = programs
    }

    public init(json: JSONValue, defaultMediaID: Int?) throws {
        guard json.object != nil else { throw PortalError.decoding("get_epg: not an object") }
        self.init(
            serverNow: json["now"]?.string.flatMap(PortalDate.parse),
            programs: CSVTable.rows(json["programs"])
                .compactMap { Program(row: $0, defaultMediaID: defaultMediaID) }
                .sorted { $0.start < $1.start }
        )
    }
}
