/// ТВ-плейлист (рубрика). `tv-favorites` — избранное абонента.
public struct Playlist: Sendable, Hashable, Identifiable {
    public var id: Int
    public var name: String
    public var title: String
    public var mediaIDs: [Int]

    public init(id: Int, name: String, title: String, mediaIDs: [Int]) {
        self.id = id
        self.name = name
        self.title = title
        self.mediaIDs = mediaIDs
    }

    public init?(json: JSONValue) {
        guard let id = json["id"]?.int, json["is_tv"]?.bool == true else { return nil }
        self.init(
            id: id,
            name: json["name"]?.string ?? "",
            title: json["title"]?.string ?? json["name"]?.string ?? "",
            mediaIDs: json["playitems"]?.array?.compactMap(\.int) ?? []
        )
    }

    public var isFavorites: Bool { name == "tv-favorites" }
}
