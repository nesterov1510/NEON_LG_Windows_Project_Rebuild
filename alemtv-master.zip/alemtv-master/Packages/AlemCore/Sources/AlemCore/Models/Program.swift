import Foundation

/// Передача из EPG.
public struct Program: Sendable, Hashable, Identifiable {
    public var mediaID: Int
    public var start: Date
    public var stop: Date
    public var title: String
    public var ageLabel: String?
    public var summary: String?

    public init(mediaID: Int, start: Date, stop: Date, title: String, ageLabel: String? = nil, summary: String? = nil) {
        self.mediaID = mediaID
        self.start = start
        self.stop = stop
        self.title = title
        self.ageLabel = ageLabel
        self.summary = summary
    }

    public init?(row: [String: JSONValue], defaultMediaID: Int?) {
        guard let start = row["start"]?.string.flatMap(PortalDate.parse),
              let stop = row["stop"]?.string.flatMap(PortalDate.parse),
              let mediaID = row["media_id"]?.int ?? defaultMediaID else { return nil }
        let (title, age) = Program.splitAge(row["title"]?.string ?? "")
        self.init(
            mediaID: mediaID,
            start: start,
            stop: stop,
            title: title,
            ageLabel: age ?? row["age_limit"]?.int.map { "\($0)+" },
            summary: row["description"]?.string
        )
    }

    public var id: String { "\(mediaID)-\(Int(start.timeIntervalSince1970))" }
    public var duration: TimeInterval { stop.timeIntervalSince(start) }

    public func isOnAir(at now: Date) -> Bool { start <= now && now < stop }

    public func progress(at now: Date) -> Double {
        guard duration > 0 else { return 0 }
        return min(1, max(0, now.timeIntervalSince(start) / duration))
    }

    /// "Фильм (16+)" → ("Фильм", "16+").
    static func splitAge(_ title: String) -> (String, String?) {
        guard title.hasSuffix("+)"), let open = title.lastIndex(of: "(") else { return (title, nil) }
        let inner = title[title.index(after: open)..<title.index(before: title.endIndex)]
        guard inner.count >= 2, inner.dropLast().allSatisfy(\.isNumber) else { return (title, nil) }
        return (title[..<open].trimmingCharacters(in: .whitespaces), String(inner))
    }
}
