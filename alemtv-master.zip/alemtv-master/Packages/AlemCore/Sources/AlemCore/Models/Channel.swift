import Foundation

/// ТВ-канал из `medialist` ответа `authorize_terminal`.
public struct Channel: Sendable, Hashable, Identifiable {
    public var id: Int
    public var index: Int
    public var name: String
    public var scheme: String?
    public var host: String?
    public var port: Int?
    public var path: String?
    public var auth: String?
    public var key: String?
    public var encrypted: Bool
    public var timeshiftURL: String?
    public var timeshiftArchiveLength: TimeInterval?
    public var timeshiftOffset: TimeInterval?
    public var timeshiftAuth: String?
    public var channelID: Int?
    public var logoURL: String?
    public var ageLimit: Int?

    public init(id: Int, index: Int = 0, name: String, scheme: String? = "http", host: String? = nil,
                port: Int? = nil, path: String? = nil, auth: String? = nil, key: String? = nil,
                encrypted: Bool = false, timeshiftURL: String? = nil, timeshiftArchiveLength: TimeInterval? = nil,
                timeshiftOffset: TimeInterval? = nil, timeshiftAuth: String? = nil, channelID: Int? = nil,
                logoURL: String? = nil, ageLimit: Int? = nil) {
        self.id = id
        self.index = index
        self.name = name
        self.scheme = scheme
        self.host = host
        self.port = port
        self.path = path
        self.auth = auth
        self.key = key
        self.encrypted = encrypted
        self.timeshiftURL = timeshiftURL
        self.timeshiftArchiveLength = timeshiftArchiveLength
        self.timeshiftOffset = timeshiftOffset
        self.timeshiftAuth = timeshiftAuth
        self.channelID = channelID
        self.logoURL = logoURL
        self.ageLimit = ageLimit
    }

    public init?(row: [String: JSONValue]) {
        guard let id = row["id"]?.int else { return nil }
        self.init(
            id: id,
            index: row["index"]?.int ?? 0,
            name: row["title"]?.string ?? row["name"]?.string ?? "",
            scheme: row["protocol"]?.string,
            host: row["host"]?.string,
            port: row["port"]?.int,
            path: row["path"]?.string,
            auth: row["auth"]?.string,
            key: row["key"]?.string,
            encrypted: row["encrypted"]?.bool ?? false,
            timeshiftURL: row["timeshift_url"]?.string,
            timeshiftArchiveLength: row["timeshift_archive_length"]?.double,
            timeshiftOffset: row["timeshift_offset"]?.double,
            timeshiftAuth: row["timeshift_auth"]?.string,
            channelID: row["channel_id"]?.int,
            logoURL: row["logo_url"]?.string,
            ageLimit: row["age_limit"]?.int
        )
    }

    public var hasArchive: Bool { !(timeshiftURL ?? "").isEmpty }

}
