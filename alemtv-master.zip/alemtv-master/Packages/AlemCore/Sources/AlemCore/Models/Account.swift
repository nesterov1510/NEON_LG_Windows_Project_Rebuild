import Foundation

public struct Profile: Sendable, Hashable, Identifiable {
    public var id: Int
    public var title: String
    public var requirePassword: Bool
    public var ageLimit: Int?
    /// Пароль приходит только у текущего профиля (`authorize_terminal.profile.password`).
    public var password: String?

    public init(id: Int, title: String, requirePassword: Bool = false, ageLimit: Int? = nil, password: String? = nil) {
        self.id = id
        self.title = title
        self.requirePassword = requirePassword
        self.ageLimit = ageLimit
        self.password = password
    }

    /// Проверка пароля профиля. Закрыто по умолчанию: если профиль требует пароль,
    /// а сервер его не прислал, доступ не даётся (родительский контроль не обходится).
    public func accepts(password entered: String) -> Bool {
        guard requirePassword else { return true }
        guard let password, !password.isEmpty else { return false }
        return entered == password
    }

    init?(json: JSONValue) {
        guard let id = json["id"]?.int else { return nil }
        self.init(
            id: id,
            title: json["title"]?.string ?? json["name"]?.string ?? "",
            requirePassword: json["require_password"]?.bool ?? false,
            ageLimit: json["age_limit"]?.int,
            password: json["password"]?.string
        )
    }
}

public struct Language: Sendable, Hashable, Identifiable {
    public var id: Int
    /// ISO 639-1: ru, en, tk.
    public var code: String
    public var name: String

    public init(id: Int, code: String, name: String = "") {
        self.id = id
        self.code = code
        self.name = name
    }

    init?(json: JSONValue) {
        guard let id = json["id"]?.int, let code = json["iso639_1"]?.string else { return nil }
        self.init(id: id, code: code, name: json["name"]?.string ?? code)
    }
}

/// Токены для URL зашифрованных каналов (`tokens[key]`).
public struct MediaToken: Sendable, Hashable {
    public var name: String
    public var token1: String
    public var token2: String

    public init(name: String, token1: String, token2: String) {
        self.name = name
        self.token1 = token1
        self.token2 = token2
    }

    static func parseAll(_ value: JSONValue?) -> [String: MediaToken]? {
        guard let object = value?.object else { return nil }
        var out: [String: MediaToken] = [:]
        for (name, token) in object {
            if let t1 = token["token1"]?.string, let t2 = token["token2"]?.string {
                out[name] = MediaToken(name: name, token1: t1, token2: t2)
            }
        }
        return out
    }
}

/// Версия и диапазон EPG канала (`epg_info`).
public struct EPGInfo: Sendable, Hashable {
    public var mediaID: Int
    public var updatedOn: Int
    public var minStart: Date?
    public var maxStop: Date?

    public init(mediaID: Int, updatedOn: Int, minStart: Date? = nil, maxStop: Date? = nil) {
        self.mediaID = mediaID
        self.updatedOn = updatedOn
        self.minStart = minStart
        self.maxStop = maxStop
    }

    static func parseAll(_ value: JSONValue?) -> [Int: EPGInfo]? {
        guard let items = value?.array else { return nil }
        var out: [Int: EPGInfo] = [:]
        for item in items {
            guard let id = item["id"]?.int else { continue }
            out[id] = EPGInfo(
                mediaID: id,
                updatedOn: item["updated_on"]?.int ?? 0,
                minStart: item["min_start"]?.string.flatMap(PortalDate.parse),
                maxStop: item["max_stop"]?.string.flatMap(PortalDate.parse)
            )
        }
        return out
    }
}
