/// Ядро tvOS-клиента AlemTV: протокол IPTVPORTAL, сессия, EPG, потоки.
public enum AlemCore {
    public static let version = "0.1.0"
}
