import Foundation

/// Автопауза: нет нажатий на пульте дольше `timeout` (auto_pause_timeout домена).
public struct IdleMonitor: Sendable {
    public let timeout: TimeInterval
    public private(set) var lastActivity: Date

    public init(timeout: TimeInterval, now: Date = Date()) {
        self.timeout = timeout
        self.lastActivity = now
    }

    public mutating func touch(now: Date = Date()) {
        lastActivity = now
    }

    public func isExpired(now: Date = Date()) -> Bool {
        now.timeIntervalSince(lastActivity) >= timeout
    }
}
