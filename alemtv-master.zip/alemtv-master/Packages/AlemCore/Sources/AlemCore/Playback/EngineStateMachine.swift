import Foundation

/// События плеера VLC, переведённые в наши термины (VLCMediaPlayerState + буферизация).
public enum EngineEvent: Sendable, Equatable {
    case opening
    case playing
    case paused
    case error
    /// `position` — доля проигранного (0…1); у живого HLS близка к 1 и не означает конец.
    case stopped(position: Double)
    /// Прогресс буферизации 0…1. В libVLC 4 нет состояния «буферизация»: при подкачке и при
    /// смене media state остаётся playing, а сигнал приходит только этим событием.
    case buffering(Float)
}

/// Состояние движка по событиям VLC: одна ошибка на загрузку, stopped после нашей остановки
/// или при смене канала — не ошибка, «конец» — только у конечной записи, подкачка останавливает
/// часы, зависание и бесконечная загрузка — сигнал к перезапуску.
public struct EngineStateMachine: Sendable {
    public static let loadingTimeout: TimeInterval = 20

    public private(set) var state: PlaybackState = .idle
    private var finite = false
    private var failureReported = false
    private var rebuffering = false
    private var loadingSince: Date?
    private var watchdog = FreezeWatchdog()

    public init() {}

    /// Новая загрузка. `finite` — конечная запись (архив): только у неё stopped у конца — `.ended`.
    public mutating func load(finite: Bool, at now: Date) -> PlaybackState? {
        self.finite = finite
        failureReported = false
        rebuffering = false
        watchdog.reset()
        loadingSince = now          // и при загрузке поверх загрузки: таймаут считается заново
        return set(.loading, at: now)
    }

    public mutating func stop() -> PlaybackState? {
        rebuffering = false
        return set(.idle, at: nil)
    }

    public mutating func handle(_ event: EngineEvent, at now: Date) -> PlaybackState? {
        guard state != .idle else { return nil }
        switch event {
        case .opening:
            return state == .playing ? nil : set(.loading, at: now)
        case .playing:
            rebuffering = false
            return set(.playing, at: now)
        case .paused:
            return set(.paused, at: now)
        case .error:
            return fail("error", at: now)
        case .stopped(let position):
            guard state == .playing || state == .paused || rebuffering else { return nil }
            if finite && position >= 0.98 { return set(.ended, at: now) }
            return fail("stopped", at: now)
        case .buffering(let progress):
            if progress < 1, state == .playing {
                rebuffering = true
                return set(.loading, at: now)
            }
            // Буфер заполнен — показ идёт. При смене канала VLC 4 не покидает «играет»
            // и события playing не шлёт: это единственный сигнал, что новый поток пошёл.
            if progress >= 1, state == .loading {
                rebuffering = false
                return set(.playing, at: now)
            }
            return nil
        }
    }

    /// true — поток пора перезапустить: вывод стоит при «играет» или загрузка длится дольше `loadingTimeout`.
    /// `progress` — растущий счётчик вывода (кадры + звук), не время потока: время у VLC бывает неподвижным.
    public mutating func isStalled(progress: Double, at now: Date) -> Bool {
        switch state {
        case .loading:
            guard let since = loadingSince, now.timeIntervalSince(since) >= Self.loadingTimeout else { return false }
            loadingSince = nil          // одно срабатывание на эпизод загрузки
            return true
        case .playing:
            return watchdog.observe(position: progress, wantsToPlay: true, likelyToKeepUp: false, now: now)
        default:
            watchdog.reset()
            return false
        }
    }

    private mutating func set(_ newState: PlaybackState, at now: Date?) -> PlaybackState? {
        guard newState != state else { return nil }
        state = newState
        loadingSince = newState == .loading ? now : nil
        if newState != .playing { watchdog.reset() }
        return newState
    }

    private mutating func fail(_ reason: String, at now: Date) -> PlaybackState? {
        guard !failureReported else { return nil }
        failureReported = true
        return set(.failed(reason), at: now)
    }
}
