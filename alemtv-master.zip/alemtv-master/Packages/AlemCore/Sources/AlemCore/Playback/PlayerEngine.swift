import CoreGraphics
import Foundation

/// Текст ошибки воспроизведения для логов: только домены и коды.
/// URL потока (с токенами сессии) из описаний и userInfo сюда не попадает.
public enum PlaybackFailure {
    public static func summary(error: Error?, log: [(domain: String, code: Int, comment: String)]) -> String {
        var parts: [String] = []
        var current = error as NSError?
        while let e = current {
            parts.append("\(e.domain) \(e.code)")
            current = e.userInfo[NSUnderlyingErrorKey] as? NSError
        }
        parts += log.map { "\($0.domain) \($0.code)" }
        return parts.isEmpty ? "playback failed" : parts.joined(separator: "; ")
    }
}

public enum PlaybackState: Sendable, Equatable {
    case idle
    case loading
    case playing
    case paused
    case failed(String)
    case ended
}

@MainActor
public protocol PlayerEngine: AnyObject {
    var state: PlaybackState { get }
    /// Время плеера в секундах (только для сторожа; «реальное» время — ContentClock).
    /// Растущий счётчик вывода (показанные кадры + проигранный звук) — только для сторожа зависаний.
    var outputProgress: Double { get }
    var videoSize: CGSize { get }
    var audioTracks: [AudioTrack] { get }
    var selectedAudioTrackID: String? { get }
    /// `finite` — конечная запись (архив): только у неё остановка у конца означает «конец».
    func load(_ url: URL, finite: Bool)
    func play()
    func pause()
    /// Относительная перемотка (ось времени VLC у части потоков — метки потока, не 0).
    func seek(by offset: TimeInterval)
    func selectAudioTrack(id: String)
    func stop()
}
