import Foundation

/// Реальное время показываемого кадра. VLC не отдаёт EXT-X-PROGRAM-DATE-TIME, а его собственное
/// время у части каналов — метки потока, поэтому время считается из режима запуска и проигранного.
public struct ContentClock: Sendable, Equatable {
    /// Типичная задержка HLS-эфира: 3 сегмента по 6 с + запас.
    public static let liveLatency: TimeInterval = 20

    public let mode: StreamMode
    public let startedAt: Date
    private var played: TimeInterval = 0
    private var runningSince: Date?

    public init(mode: StreamMode, startedAt: Date) {
        self.mode = mode
        self.startedAt = startedAt
    }

    public mutating func didStartPlaying(at now: Date) {
        if runningSince == nil { runningSince = now }
    }

    public mutating func didStopPlaying(at now: Date) {
        guard let since = runningSince else { return }
        played += max(0, now.timeIntervalSince(since))
        runningSince = nil
    }

    /// Перемотка внутри записи: позиция от начала записи.
    public mutating func didSeek(toPosition position: TimeInterval, at now: Date) {
        played = max(0, position)
        if runningSince != nil { runningSince = now }
    }

    public func playedTime(at now: Date) -> TimeInterval {
        played + (runningSince.map { max(0, now.timeIntervalSince($0)) } ?? 0)
    }

    public func contentTime(at now: Date) -> Date {
        switch mode {
        case .live:
            return now.addingTimeInterval(-Self.liveLatency)
        case .archive(let start, _):
            return start.addingTimeInterval(playedTime(at: now))
        case .timeshift(let behind):
            return startedAt.addingTimeInterval(-behind + playedTime(at: now))
        }
    }

    public func behindLive(at now: Date) -> TimeInterval {
        max(0, now.timeIntervalSince(contentTime(at: now)))
    }
}
