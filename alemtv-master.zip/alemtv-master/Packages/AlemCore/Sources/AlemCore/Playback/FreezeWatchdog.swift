import Foundation

/// Перезапуск зависшего потока (по образцу Controller.checkFreez Android-клиента):
/// воспроизведение запрошено, буфер не успевает, позиция не двигается `threshold` секунд.
public struct FreezeWatchdog: Sendable {
    public let threshold: TimeInterval
    private var lastPosition: Double?
    private var frozenSince: Date?

    public init(threshold: TimeInterval = 6) {
        self.threshold = threshold
    }

    /// true — поток пора перезапустить.
    public mutating func observe(position: Double, wantsToPlay: Bool, likelyToKeepUp: Bool, now: Date) -> Bool {
        defer { lastPosition = position }
        guard wantsToPlay, !likelyToKeepUp, let last = lastPosition, abs(position - last) < 0.05 else {
            frozenSince = nil
            return false
        }
        let since = frozenSince ?? now
        frozenSince = since
        if now.timeIntervalSince(since) >= threshold {
            frozenSince = nil
            return true
        }
        return false
    }

    public mutating func reset() {
        lastPosition = nil
        frozenSince = nil
    }
}
