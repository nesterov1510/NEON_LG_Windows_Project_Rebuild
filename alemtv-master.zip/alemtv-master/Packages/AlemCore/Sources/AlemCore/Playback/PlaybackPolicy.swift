import Foundation

/// Кнопки пульта Siri Remote.
public enum RemoteKey: CaseIterable, Sendable {
    case up, down, left, right, select, playPause, menu
}

/// Что сейчас поверх видео (по приоритету: ошибка > список > программа > панель > ничего).
public enum PlayerOverlay: Sendable, Equatable {
    case none, panel, channelList, schedule, error
}

public enum PlaybackKind: Sendable {
    case live, timeshift, archive
}

public enum PlayerAction: Sendable, Equatable {
    case previousChannel, nextChannel, showChannelList, showPanel, hidePanel, togglePause
    /// Закрыть список каналов или программу (Menu работает, даже если в оверлее нечего фокусировать).
    case closeOverlay
    case skip(TimeInterval)
    case openGuide
    case ignore
}

/// Решения плеера без движка: пульт, перемотка эфира, опорное время EPG, возврат из фона.
public enum PlaybackPolicy {
    /// Задержка HLS-эфира (~3 сегмента по 6 с) + запас: ближе этого к «сейчас» при движении вперёд — эфир.
    public static let liveSnap: TimeInterval = 45
    public static let skipStep: TimeInterval = 10

    /// Таблица пульта (spec §4). `.ignore` — нажатие обрабатывает фокус оверлея.
    public static func action(for key: RemoteKey, overlay: PlayerOverlay, kind: PlaybackKind) -> PlayerAction {
        switch overlay {
        case .channelList, .schedule:
            return key == .menu ? .closeOverlay : .ignore
        case .error:
            // ↑/↓ не нужны кнопкам ошибки (они в ряд) — переключают канал, чтобы не застрять на мёртвом.
            switch key {
            case .menu: return .openGuide
            case .up: return kind == .archive ? .ignore : .previousChannel
            case .down: return kind == .archive ? .ignore : .nextChannel
            default: return .ignore
            }
        case .panel:
            switch key {
            case .menu: return .hidePanel
            case .playPause: return .togglePause
            default: return .ignore
            }
        case .none:
            switch key {
            case .up: return kind == .archive ? .ignore : .previousChannel
            case .down: return kind == .archive ? .ignore : .nextChannel
            case .left: return kind == .archive ? .skip(-skipStep) : .showChannelList
            case .right: return kind == .live ? .ignore : .skip(skipStep)
            case .select: return .showPanel
            case .playPause: return .togglePause
            case .menu: return .openGuide
            }
        }
    }

    /// Перемотка эфира/таймшифта на `seconds`. Назад — всегда таймшифт (не глубже архива);
    /// вперёд к эфиру ближе `liveSnap` — эфир.
    public static func skip(by seconds: TimeInterval, contentTime: Date, now: Date, archiveDepth: TimeInterval?) -> StreamMode {
        var behind = now.timeIntervalSince(contentTime.addingTimeInterval(seconds))
        if let archiveDepth { behind = min(behind, archiveDepth) }
        if seconds > 0, behind <= liveSnap { return .live }
        return .timeshift(behind: max(StreamURLBuilder.liveThreshold, behind))
    }

    /// Время, по которому ищется «текущая передача» сразу после запуска потока.
    public static func referenceTime(for mode: StreamMode, now: Date) -> Date {
        switch mode {
        case .live: return now
        case .timeshift(let behind): return now.addingTimeInterval(-behind)
        case .archive(let start, _): return start
        }
    }

    public enum ResumeAction: Equatable, Sendable {
        case reloadLive
        /// Запись/таймшифт: поток остановлен при уходе в фон — загрузить заново с места остановки.
        case reloadAtPosition
    }

    public static func resumeAfterBackground(isLive: Bool) -> ResumeAction {
        isLive ? .reloadLive : .reloadAtPosition
    }
}
