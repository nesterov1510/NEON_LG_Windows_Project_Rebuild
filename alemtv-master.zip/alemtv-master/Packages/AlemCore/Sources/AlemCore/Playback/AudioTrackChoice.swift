/// Звуковая дорожка потока (у части каналов их две: rus/kaz).
public struct AudioTrack: Sendable, Equatable, Identifiable {
    public var id: String
    public var name: String
    public var language: String?

    public init(id: String, name: String, language: String?) {
        self.id = id
        self.name = name
        self.language = language
    }
}

public enum AudioTrackChoice {
    /// Дорожки для меню «Звук»: по одной на язык; пусто, если разных языков меньше двух
    /// (VLC раздваивает единственную дорожку: «Track 1» без языка + «Track 2 [Turkmen]»).
    public static func selectable(_ tracks: [AudioTrack]) -> [AudioTrack] {
        var seen = Set<String>()
        let unique = tracks.filter { track in
            guard let language = track.language?.lowercased(), !language.isEmpty else { return false }
            return seen.insert(language).inserted
        }
        return unique.count > 1 ? unique : []
    }

    /// Дорожка запомненного языка, если выбор есть и такая дорожка есть; иначе — оставить выбор движка.
    public static func preferred(_ tracks: [AudioTrack], language: String?) -> AudioTrack? {
        guard let language = language?.lowercased() else { return nil }
        return selectable(tracks).first { $0.language?.lowercased() == language }
    }
}
