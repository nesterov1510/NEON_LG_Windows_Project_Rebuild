/// Ошибки обращения к порталу. Коды JSON-RPC: -32003 — нет доступа, -32002 — не найдено (терминал/сессия).
public enum PortalError: Error, Equatable, Sendable {
    case unauthorized(String)
    case notFound(String)
    case server(code: Int, message: String)
    case http(Int)
    case transport(String)
    case decoding(String)

    /// Сессия или терминал больше недействительны — нужен повторный вход.
    public var requiresSignIn: Bool {
        switch self {
        case .unauthorized, .notFound: return true
        default: return false
        }
    }

    /// Текст сервера для показа пользователю (если есть).
    public var serverMessage: String? {
        switch self {
        case .unauthorized(let m), .notFound(let m), .server(_, let m): return m.isEmpty ? nil : m
        default: return nil
        }
    }
}
