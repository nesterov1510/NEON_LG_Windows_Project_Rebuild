import Foundation

public protocol HTTPTransport: Sendable {
    /// POST; возвращает тело и HTTP-статус.
    func post(_ url: URL, headers: [String: String], body: Data) async throws -> (Data, Int)
}

public struct URLSessionTransport: HTTPTransport {
    let session: URLSession
    let timeout: TimeInterval

    public init(session: URLSession = .shared, timeout: TimeInterval = 15) {
        self.session = session
        self.timeout = timeout
    }

    public func post(_ url: URL, headers: [String: String], body: Data) async throws -> (Data, Int) {
        var request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: timeout)
        request.httpMethod = "POST"
        for (name, value) in headers { request.setValue(value, forHTTPHeaderField: name) }
        request.httpBody = body
        let (data, response) = try await session.data(for: request)
        return (data, (response as? HTTPURLResponse)?.statusCode ?? 0)
    }
}

/// Как представляется терминал порталу.
public struct TerminalInfo: Sendable, Equatable {
    public var terminalType: String
    public var firmwareVersion: String
    public var userAgent: String

    public init(terminalType: String, firmwareVersion: String, userAgent: String) {
        self.terminalType = terminalType
        self.firmwareVersion = firmwareVersion
        self.userAgent = userAgent
    }

    public static func appleTV(appVersion: String, osVersion: String) -> TerminalInfo {
        TerminalInfo(
            terminalType: "appletv",
            firmwareVersion: "tvOS \(osVersion); AlemTV \(appVersion)",
            userAgent: "AlemTV-tvOS/\(appVersion) (AppleTV; tvOS \(osVersion))"
        )
    }
}
