import Foundation

/// JSON-RPC 2.0 клиент портала IPTVPORTAL: `POST {base}/jsonrpc/{method}`.
public actor PortalClient {
    public let baseURL: URL
    public let terminal: TerminalInfo
    private let transport: HTTPTransport
    private let cipherFactory: @Sendable () -> AresCipher
    public private(set) var sessionID: String?
    public private(set) var macaddr: String?
    private var nextID = 0

    public init(baseURL: URL, terminal: TerminalInfo, transport: HTTPTransport = URLSessionTransport(),
                cipherFactory: @escaping @Sendable () -> AresCipher = { AresCipher.random() }) {
        self.baseURL = baseURL
        self.terminal = terminal
        self.transport = transport
        self.cipherFactory = cipherFactory
    }

    public func setSession(_ id: String?) { sessionID = id }
    public func setMacaddr(_ mac: String?) { macaddr = mac }

    public func call(_ method: String, _ params: [String: JSONValue] = [:], encrypted: Bool = false) async throws -> JSONValue {
        var params = params
        if params["macaddr"] == nil {
            if let sessionID { params["session_id"] = .string(sessionID) }
            else if let macaddr { params["macaddr"] = .string(macaddr) }
        }
        nextID += 1
        let envelope: JSONValue = ["jsonrpc": "2.0", "id": .int(nextID), "method": .string(method), "params": .object(params)]
        var body = try JSONEncoder().encode(envelope)
        var headers = [
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            "User-Agent": terminal.userAgent,
        ]
        var cipher: AresCipher?
        if encrypted {
            let c = cipherFactory()
            cipher = c
            headers["Ares-Cipher"] = try c.header()
            body = Data(try c.encrypt(body).utf8)
        }
        let url = baseURL.appendingPathComponent("jsonrpc").appendingPathComponent(method)
        let data: Data
        let status: Int
        do {
            (data, status) = try await transport.post(url, headers: headers, body: body)
        } catch {
            throw PortalError.transport(String(describing: type(of: error)))
        }
        guard (200..<300).contains(status) else { throw PortalError.http(status) }
        let response: JSONValue
        do {
            let plain = try cipher.map { try $0.decrypt(String(decoding: data, as: UTF8.self)) } ?? data
            response = try JSONDecoder().decode(JSONValue.self, from: plain)
        } catch {
            throw PortalError.decoding("\(method): \(error)")
        }
        if let error = response["error"], !error.isNull {
            let code = error["code"]?.int ?? 0
            let message = error["message"]?.string ?? ""
            switch code {
            case -32003: throw PortalError.unauthorized(message)
            case -32002: throw PortalError.notFound(message)
            default: throw PortalError.server(code: code, message: message)
            }
        }
        return response["result"] ?? .null
    }

    // MARK: - Методы

    public func getDomainConfig() async throws -> DomainConfig {
        try DomainConfig(json: await call("get_domain_config", ["terminal_type": .string(terminal.terminalType)]))
    }

    public func login(macaddr: String?) async throws -> LoginResult {
        try LoginResult(json: await call("login", terminalParams(macaddr: macaddr), encrypted: true))
    }

    public func registerTerminal(username: String, password: String, macaddr: String?) async throws -> LoginResult {
        var params = terminalParams(macaddr: macaddr)
        params["username"] = .string(username)
        params["password"] = .string(password)
        return try LoginResult(json: await call("register_terminal", params, encrypted: true))
    }

    public func unregisterTerminal(macaddr: String) async throws {
        _ = try await call("unregister_terminal", ["macaddr": .string(macaddr)], encrypted: true)
    }

    public func authorizeTerminal(nocache: Bool = false) async throws -> AuthorizeResult {
        var params: [String: JSONValue] = [
            "version": 2, "require_media_tokens": true, "require_media_keys": false, "result_as": "csv",
        ]
        if nocache {
            params["nocache"] = true
            params["require_domain_config"] = true
        }
        return try AuthorizeResult(json: await call("authorize_terminal", params))
    }

    public func checkUpdate() async throws -> CheckUpdateResult {
        try CheckUpdateResult(json: await call("check_update", ["program": "web browser", "require_media_tokens": true]))
    }

    /// Текущие передачи для списка каналов.
    public func epg(mediaIDs: [Int], languageID: Int?) async throws -> EPGResponse {
        var params: [String: JSONValue] = ["version": 2, "result_as": "csv", "media_id": .array(mediaIDs.map(JSONValue.int))]
        if let languageID { params["language_id"] = .int(languageID) }
        return try EPGResponse(json: await call("get_epg", params), defaultMediaID: nil)
    }

    /// Программа канала на день `YYYY-MM-DD` (зона сервера).
    public func epg(mediaID: Int, day: String, languageID: Int?) async throws -> EPGResponse {
        var params: [String: JSONValue] = [
            "version": 2, "result_as": "csv", "media_id": .int(mediaID),
            "start": .string("\(day) 00:00:00"), "stop": .string("\(day) 23:59:59"),
        ]
        if let languageID { params["language_id"] = .int(languageID) }
        return try EPGResponse(json: await call("get_epg", params), defaultMediaID: mediaID)
    }

    public func setFavorite(_ on: Bool, playlistID: Int, mediaID: Int) async throws {
        _ = try await call(on ? "insert_playlist_media" : "delete_playlist_media",
                           ["playlist_id": .int(playlistID), "media_id": .int(mediaID)])
    }

    public func setTerminalParams(_ params: [String: JSONValue]) async throws {
        _ = try await call("set_terminal_params", params)
    }

    private func terminalParams(macaddr: String?) -> [String: JSONValue] {
        [
            "macaddr": macaddr.map(JSONValue.string) ?? .null,
            "create_macaddr": .bool(macaddr == nil),
            "require_session": true,
            "require_user_id": true,
            "terminal_type": .string(terminal.terminalType),
            "firmware_version": .string(terminal.firmwareVersion),
        ]
    }
}
