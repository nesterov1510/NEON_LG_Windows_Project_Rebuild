import Foundation

/// Смещение часов «сервер − устройство» по полю `now` из ответов портала.
public struct ServerClock: Sendable, Equatable {
    public private(set) var offset: TimeInterval

    public init(offset: TimeInterval = 0) {
        self.offset = offset
    }

    public mutating func sync(serverNow: Date, deviceNow: Date = Date()) {
        offset = serverNow.timeIntervalSince(deviceNow)
    }

    public func now(deviceNow: Date = Date()) -> Date {
        deviceNow.addingTimeInterval(offset)
    }
}
