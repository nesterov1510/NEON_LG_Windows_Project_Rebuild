import Foundation

/// Время в ответах портала: "2026-10-03 21:00:00+0500" или без зоны (тогда — зона сервера, UTC+5).
public enum PortalDate {
    public static let serverTimeZone = TimeZone(secondsFromGMT: 5 * 3600)!

    private static func calendar(_ zone: TimeZone) -> Calendar {
        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = zone
        return calendar
    }

    public static func parse(_ text: String) -> Date? {
        let chars = Array(text)
        guard chars.count >= 19 else { return nil }
        func number(_ range: Range<Int>) -> Int? { Int(String(chars[range])) }
        guard let year = number(0..<4), let month = number(5..<7), let day = number(8..<10),
              let hour = number(11..<13), let minute = number(14..<16), let second = number(17..<19) else { return nil }
        var zone = serverTimeZone
        if chars.count >= 24, chars[19] == "+" || chars[19] == "-",
           let hh = number(20..<22), let mm = number(22..<24) {
            let sign = chars[19] == "-" ? -1 : 1
            zone = TimeZone(secondsFromGMT: sign * (hh * 3600 + mm * 60)) ?? serverTimeZone
        }
        let components = DateComponents(year: year, month: month, day: day, hour: hour, minute: minute, second: second)
        return calendar(zone).date(from: components)
    }

    /// "YYYY-MM-DD" дня в зоне сервера (так портал запрашивает EPG по дням).
    public static func dayString(_ date: Date) -> String {
        let c = calendar(serverTimeZone).dateComponents([.year, .month, .day], from: date)
        return String(format: "%04d-%02d-%02d", c.year ?? 0, c.month ?? 0, c.day ?? 0)
    }

    public static func startOfDay(_ date: Date) -> Date {
        calendar(serverTimeZone).startOfDay(for: date)
    }
}
