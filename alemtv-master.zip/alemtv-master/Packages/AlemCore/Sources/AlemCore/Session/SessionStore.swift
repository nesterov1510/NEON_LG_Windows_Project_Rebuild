import Foundation

public protocol PortalAPI: Sendable {
    func setSession(_ id: String?) async
    func setMacaddr(_ mac: String?) async
    func getDomainConfig() async throws -> DomainConfig
    func login(macaddr: String?) async throws -> LoginResult
    func registerTerminal(username: String, password: String, macaddr: String?) async throws -> LoginResult
    func unregisterTerminal(macaddr: String) async throws
    func authorizeTerminal(nocache: Bool) async throws -> AuthorizeResult
    func checkUpdate() async throws -> CheckUpdateResult
}

extension PortalClient: PortalAPI {}

public enum StartResult: Sendable {
    case signedIn(AuthorizeResult)
    case needsCredentials
}

public struct RefreshResult: Sendable {
    public var authorization: AuthorizeResult
    public var epgInfo: [Int: EPGInfo]?
    /// Каталог перезагружен (повторный вход, смена подписки или других данных на сервере).
    public var reloaded: Bool
}

/// Жизненный цикл терминала: MAC в Keychain, session_id в памяти, check_update.
public actor SessionStore {
    private let api: PortalAPI
    private let store: SecureStore
    private let macKey: String
    private var sessionID: String?

    public private(set) var domain: DomainConfig?
    public private(set) var authorization: AuthorizeResult?
    public private(set) var clock = ServerClock()

    public init(api: PortalAPI, store: SecureStore, macKey: String) {
        self.api = api
        self.store = store
        self.macKey = macKey
    }

    public var macaddr: String? { store.string(forKey: macKey) }

    public func updatePeriod() -> Int { domain?.portalUpdatePeriod ?? 300 }

    /// Холодный старт: конфиг домена и вход по сохранённому MAC.
    public func start() async throws -> StartResult {
        let config = try await api.getDomainConfig()
        domain = config
        if let now = config.serverNow { clock.sync(serverNow: now) }
        guard let mac = macaddr else { return .needsCredentials }
        do {
            return .signedIn(try await loginAndAuthorize(mac: mac))
        } catch let error as PortalError where error.requiresSignIn {
            return .needsCredentials
        }
    }

    /// Привязка терминала логином и паролем абонента.
    public func signIn(username: String, password: String) async throws -> AuthorizeResult {
        if domain == nil { domain = try await api.getDomainConfig() }
        let result = try await api.registerTerminal(username: username, password: password, macaddr: macaddr)
        if let mac = result.macaddr { store.set(mac, forKey: macKey) }
        guard let mac = result.macaddr ?? macaddr else { throw PortalError.decoding("register_terminal: no macaddr") }
        await api.setMacaddr(mac)
        sessionID = result.sessionID
        await api.setSession(result.sessionID)
        return try await authorize(nocache: false)
    }

    /// Новый session_id по MAC (после -32003, 403 стримера, смены сети).
    public func reauthorize() async throws -> AuthorizeResult {
        guard let mac = macaddr else { throw PortalError.unauthorized("no terminal") }
        return try await loginAndAuthorize(mac: mac)
    }

    /// Перечитать каталог (после смены языка или профиля).
    public func reload() async throws -> AuthorizeResult {
        try await authorize(nocache: true)
    }

    public func refresh() async throws -> RefreshResult {
        guard let current = authorization else { throw PortalError.unauthorized("not signed in") }
        let update: CheckUpdateResult
        do {
            update = try await api.checkUpdate()
        } catch let error as PortalError where error.requiresSignIn {
            let a = try await reauthorize()
            return RefreshResult(authorization: a, epgInfo: a.epgInfo, reloaded: true)
        }
        if let now = update.serverNow { clock.sync(serverNow: now) }
        guard update.authorized else {
            let a = try await reauthorize()
            return RefreshResult(authorization: a, epgInfo: a.epgInfo, reloaded: true)
        }
        var domainChanged = false
        if let updated = update.domainUpdatedOn, updated > (domain?.updatedOn ?? 0) {
            domain = try await api.getDomainConfig()
            domainChanged = true
        }
        if domainChanged
            || (update.subscriberUpdatedOn ?? 0) > current.subscriberUpdatedOn
            || (update.terminalUpdatedOn ?? 0) > current.terminalUpdatedOn {
            let a = try await authorize(nocache: true)
            return RefreshResult(authorization: a, epgInfo: a.epgInfo, reloaded: true)
        }
        var a = current
        if let tokens = update.tokens { a.tokens = tokens }
        authorization = a
        return RefreshResult(authorization: a, epgInfo: update.epgInfo, reloaded: false)
    }

    /// Избранное изменено на сервере — отразить в каталоге (SessionStore — единственный владелец).
    public func applyFavorite(_ on: Bool, playlistID: Int, mediaID: Int) {
        guard var a = authorization, let index = a.playlists.firstIndex(where: { $0.id == playlistID }) else { return }
        if on {
            if !a.playlists[index].mediaIDs.contains(mediaID) { a.playlists[index].mediaIDs.append(mediaID) }
        } else {
            a.playlists[index].mediaIDs.removeAll { $0 == mediaID }
        }
        authorization = a
    }

    /// Отвязка терминала. При ошибке сервера MAC остаётся: иначе терминал «потеряется» и займёт слот лимита.
    public func signOut() async throws {
        if let mac = macaddr { try await api.unregisterTerminal(macaddr: mac) }
        store.set(nil, forKey: macKey)
        sessionID = nil
        authorization = nil
        await api.setSession(nil)
        await api.setMacaddr(nil)
    }

    public func streamContext() -> StreamContext? {
        guard let sessionID, let authorization else { return nil }
        return StreamContext(sessionID: sessionID, domain: domain?.name ?? "tmalem",
                             tokens: authorization.tokens, serverNow: clock.now())
    }

    // MARK: - Внутреннее

    private func loginAndAuthorize(mac: String) async throws -> AuthorizeResult {
        await api.setSession(nil)
        await api.setMacaddr(mac)
        let result = try await api.login(macaddr: mac)
        sessionID = result.sessionID
        await api.setSession(result.sessionID)
        return try await authorize(nocache: false)
    }

    private func authorize(nocache: Bool) async throws -> AuthorizeResult {
        let a = try await api.authorizeTerminal(nocache: nocache)
        authorization = a
        if let now = a.serverNow { clock.sync(serverNow: now) }
        return a
    }
}
