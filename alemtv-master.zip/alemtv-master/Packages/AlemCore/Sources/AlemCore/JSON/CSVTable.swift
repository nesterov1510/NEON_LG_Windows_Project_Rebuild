/// Таблица `result_as:"csv"`: первая строка — имена колонок, остальные — значения.
public enum CSVTable {
    public static func rows(_ value: JSONValue?) -> [[String: JSONValue]] {
        guard let table = value?.array, let header = table.first?.array else { return [] }
        let names = header.map { $0.string ?? "" }
        return table.dropFirst().compactMap { row in
            guard let cells = row.array else { return nil }
            var dict: [String: JSONValue] = [:]
            for (i, name) in names.enumerated() where i < cells.count && !name.isEmpty {
                dict[name] = cells[i]
            }
            return dict
        }
    }
}
