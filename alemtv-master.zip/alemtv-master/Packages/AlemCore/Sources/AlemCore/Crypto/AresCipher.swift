import Foundation
import CommonCrypto
import Security

public enum AresCipherError: Error, Equatable {
    case rsa(String)
    case aes(Int32)
    case badBase64
}

/// Шифрование чувствительных JSON-RPC вызовов IPTVPORTAL (заголовок `Ares-Cipher`).
public struct AresCipher: Sendable {
    public static let iv: [UInt8] = Array("arescrypt       ".utf8)

    /// RSA-1024 модуль из system.js портала (e = 65537).
    static let modulusHex =
        "cf2cde3395737e94f0f0ca7474797d285170eb7acd41628a946f92a00138225a" +
        "23c2b7307da8c182536bfa325d7a111dc82eb0825c85614d807b46bdc0bea823" +
        "1dde941b2d435782dabed3381b48f30aa19bff261eec4086b56d5c45ea394b8f" +
        "386d1ad75b7e8c5d37d517e83e598719afb2b05b790e41f132858321f693c025"

    public let key: [UInt8]

    public init(key: [UInt8]) {
        precondition(key.count == 16, "AES-128 key must be 16 bytes")
        self.key = key
    }

    public static func random() -> AresCipher {
        var bytes = [UInt8](repeating: 0, count: 16)
        let status = SecRandomCopyBytes(kSecRandomDefault, bytes.count, &bytes)
        precondition(status == errSecSuccess, "SecRandomCopyBytes failed")
        return AresCipher(key: bytes)
    }

    /// 78 байт: struct `<H16s8s8sHHHHL` + ключ + IV.
    public static func headerBlock(key: [UInt8], timestamp: UInt32) -> [UInt8] {
        var out: [UInt8] = []
        out += le16(1)
        out += fixed("aes", 16)
        out += fixed("cbc", 8)
        out += fixed("base64", 8)
        out += le16(128) + le16(16) + le16(46) + le16(62)
        out += le32(timestamp)
        out += key
        out += iv
        return out
    }

    /// Значение HTTP-заголовка `Ares-Cipher`.
    public func header(timestamp: UInt32 = UInt32(Date().timeIntervalSince1970)) throws -> String {
        let block = Data(Self.headerBlock(key: key, timestamp: timestamp))
        var error: Unmanaged<CFError>?
        guard let encrypted = SecKeyCreateEncryptedData(try Self.publicKey(), .rsaEncryptionPKCS1, block as CFData, &error) else {
            throw AresCipherError.rsa(error.map { String(describing: $0.takeRetainedValue()) } ?? "encrypt failed")
        }
        return (encrypted as Data).base64EncodedString()
    }

    public func encrypt(_ plain: Data) throws -> String {
        try crypt(CCOperation(kCCEncrypt), plain).base64EncodedString()
    }

    public func decrypt(_ base64: String) throws -> Data {
        guard let data = Data(base64Encoded: base64, options: .ignoreUnknownCharacters), !data.isEmpty,
              data.count % kCCBlockSizeAES128 == 0 else {
            throw AresCipherError.badBase64
        }
        return try crypt(CCOperation(kCCDecrypt), data)
    }

    private func crypt(_ operation: CCOperation, _ input: Data) throws -> Data {
        var output = [UInt8](repeating: 0, count: input.count + kCCBlockSizeAES128)
        let outputCount = output.count
        var moved = 0
        let status = input.withUnsafeBytes { inBuffer in
            CCCrypt(operation, CCAlgorithm(kCCAlgorithmAES), CCOptions(kCCOptionPKCS7Padding),
                    key, key.count, Self.iv,
                    inBuffer.baseAddress, input.count,
                    &output, outputCount, &moved)
        }
        guard status == kCCSuccess else { throw AresCipherError.aes(status) }
        return Data(output.prefix(moved))
    }

    // MARK: - RSA

    static func publicKey() throws -> SecKey {
        let der = derSequence(derInteger(hexBytes(modulusHex)) + derInteger([0x01, 0x00, 0x01]))
        let attributes: [CFString: Any] = [
            kSecAttrKeyType: kSecAttrKeyTypeRSA,
            kSecAttrKeyClass: kSecAttrKeyClassPublic,
            kSecAttrKeySizeInBits: 1024,
        ]
        var error: Unmanaged<CFError>?
        guard let key = SecKeyCreateWithData(Data(der) as CFData, attributes as CFDictionary, &error) else {
            throw AresCipherError.rsa(error.map { String(describing: $0.takeRetainedValue()) } ?? "bad key")
        }
        return key
    }

    // MARK: - Байтовые помощники

    static func le16(_ v: UInt16) -> [UInt8] { [UInt8(v & 0xff), UInt8(v >> 8)] }
    static func le32(_ v: UInt32) -> [UInt8] { (0..<4).map { UInt8((v >> (8 * $0)) & 0xff) } }

    static func fixed(_ s: String, _ length: Int) -> [UInt8] {
        let bytes = Array(s.utf8.prefix(length))
        return bytes + [UInt8](repeating: 0, count: length - bytes.count)
    }

    static func hexBytes(_ hex: String) -> [UInt8] {
        var out: [UInt8] = []
        var index = hex.startIndex
        while index < hex.endIndex {
            let next = hex.index(index, offsetBy: 2)
            out.append(UInt8(hex[index..<next], radix: 16)!)
            index = next
        }
        return out
    }

    static func derLength(_ n: Int) -> [UInt8] {
        if n < 0x80 { return [UInt8(n)] }
        if n < 0x100 { return [0x81, UInt8(n)] }
        return [0x82, UInt8(n >> 8), UInt8(n & 0xff)]
    }

    static func derInteger(_ bytes: [UInt8]) -> [UInt8] {
        var body = Array(bytes.drop(while: { $0 == 0 }))
        if body.isEmpty || body[0] & 0x80 != 0 { body.insert(0, at: 0) }
        return [0x02] + derLength(body.count) + body
    }

    static func derSequence(_ content: [UInt8]) -> [UInt8] {
        [0x30] + derLength(content.count) + content
    }
}
