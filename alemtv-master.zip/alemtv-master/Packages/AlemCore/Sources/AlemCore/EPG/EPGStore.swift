import Foundation

public protocol EPGSource: Sendable {
    func epg(mediaIDs: [Int], languageID: Int?) async throws -> EPGResponse
    func epg(mediaID: Int, day: String, languageID: Int?) async throws -> EPGResponse
}

extension PortalClient: EPGSource {}

/// Кеш EPG по (канал, день, язык). Сбрасывается по `epg_info.updated_on`.
public actor EPGStore {
    private struct DayKey: Hashable {
        let mediaID: Int
        let day: String
        let languageID: Int?
    }

    static let chunkSize = 50

    private let source: EPGSource
    private var days: [DayKey: [Program]] = [:]
    private var versions: [Int: Int] = [:]

    public init(source: EPGSource) {
        self.source = source
    }

    public func programs(mediaID: Int, day: String, languageID: Int?) async throws -> [Program] {
        let key = DayKey(mediaID: mediaID, day: day, languageID: languageID)
        if let cached = days[key] { return cached }
        let programs = try await source.epg(mediaID: mediaID, day: day, languageID: languageID).programs
        days[key] = programs
        return programs
    }

    /// Текущая передача для каждого канала (запросы пачками по 50). Сбой пачки не теряет
    /// остальные; ошибка — только если не загрузилась ни одна.
    public func current(mediaIDs: [Int], languageID: Int?) async throws -> [Int: Program] {
        var result: [Int: Program] = [:]
        var lastError: Error?
        var loaded = false
        var start = 0
        while start < mediaIDs.count {
            let chunk = Array(mediaIDs[start..<min(start + Self.chunkSize, mediaIDs.count)])
            do {
                for program in try await source.epg(mediaIDs: chunk, languageID: languageID).programs {
                    result[program.mediaID] = program
                }
                loaded = true
            } catch {
                lastError = error
            }
            start += Self.chunkSize
        }
        if !loaded, let lastError { throw lastError }
        return result
    }

    /// «Что идёт сейчас» для списков каналов. Источник — расписание на день: общий запрос
    /// портала у части каналов расходится с эфиром (эфиры «+N» получают программу основного
    /// канала, CineMan и др. сдвинуты на +2 ч — сверено с титрами в кадре 05.10.2026).
    /// Общий запрос — только для каналов без расписания на день. Канала нет в ответе —
    /// сейчас передачи нет. Расписания кешируются по дням, грузятся параллельно.
    public func nowPlaying(mediaIDs: [Int], languageID: Int?, now: Date) async -> [Int: Program] {
        var result: [Int: Program] = [:]
        var withoutSchedule: [Int] = []
        await withTaskGroup(of: (Int, ScheduleLookup).self) { group in
            var pending = mediaIDs[...]
            for _ in 0..<Self.parallelDays {
                guard let id = pending.popFirst() else { break }
                group.addTask { (id, await self.lookup(mediaID: id, languageID: languageID, now: now)) }
            }
            for await (id, found) in group {
                switch found {
                case .onAir(let program): result[id] = program
                case .gap: break
                case .noSchedule: withoutSchedule.append(id)
                }
                if let next = pending.popFirst() {
                    group.addTask { (next, await self.lookup(mediaID: next, languageID: languageID, now: now)) }
                }
            }
        }
        if !withoutSchedule.isEmpty, let bulk = try? await current(mediaIDs: withoutSchedule, languageID: languageID) {
            for (id, program) in bulk where program.isOnAir(at: now) { result[id] = program }
        }
        return result
    }

    static let parallelDays = 8

    private enum ScheduleLookup: Sendable {
        case onAir(Program)
        case gap
        case noSchedule
    }

    /// Сегодня, затем вчера (передача через полночь). Пустое или незагруженное расписание — `.noSchedule`.
    private func lookup(mediaID: Int, languageID: Int?, now: Date) async -> ScheduleLookup {
        var hasSchedule = false
        for day in [PortalDate.dayString(now), PortalDate.dayString(now.addingTimeInterval(-86_400))] {
            guard let list = try? await programs(mediaID: mediaID, day: day, languageID: languageID), !list.isEmpty else { continue }
            hasSchedule = true
            if let program = list.first(where: { $0.isOnAir(at: now) }) { return .onAir(program) }
        }
        return hasSchedule ? .gap : .noSchedule
    }

    public func apply(_ info: [Int: EPGInfo]) {
        for (id, item) in info {
            if let known = versions[id], known != item.updatedOn {
                days = days.filter { $0.key.mediaID != id }
            }
            versions[id] = item.updatedOn
        }
    }

    public func clear() {
        days.removeAll()
        versions.removeAll()
    }
}

/// Когда перезапрашивать «сейчас в эфире»: сразу после окончания самой ранней из показанных
/// передач (там начинается следующая), но не реже раза в минуту.
public enum NowPlayingRefresh {
    public static let maxDelay: TimeInterval = 60
    public static let minDelay: TimeInterval = 5
    /// Запас после окончания: портал успевает переключить «текущую» передачу.
    public static let margin: TimeInterval = 2

    public static func delay(after programs: [Program], now: Date) -> TimeInterval {
        guard let earliest = programs.map(\.stop).min() else { return maxDelay }
        let untilEnd = earliest.timeIntervalSince(now) + margin
        return min(maxDelay, max(minDelay, untilEnd))
    }
}
