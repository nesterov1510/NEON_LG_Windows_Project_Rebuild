#!/usr/bin/env python3
"""Иконка tvOS (слои), Top Shelf и AccentColor из баннера Android-приложения AlemTV.

Временная графика (исходник 320x180 масштабируется вверх): заменить исходниками от владельцев AlemTV.
Требует Pillow и numpy: pip3 install pillow numpy.
"""
import json
import os

import numpy
from PIL import Image

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, "reference", "decompiled", "resources", "res", "drawable-xhdpi", "alem.png")
ASSETS = os.path.join(ROOT, "App", "Resources", "Assets.xcassets")
BRAND = os.path.join(ASSETS, "App Icon & Top Shelf Image.brandassets")
INFO = {"author": "xcode", "version": 1}

BACKGROUND = (255, 255, 255, 255)  # фон баннера: иконка целиком белая, без рамки


def cut_logo(banner):
    """Логотип с прозрачным фоном вместо белого, обрезанный по содержимому (передний слой для parallax)."""
    pixels = numpy.asarray(banner, dtype=numpy.float64)
    rgb = pixels[..., :3]
    alpha = numpy.clip((255 - rgb.min(axis=2)) / 120, 0, 1)
    safe = numpy.where(alpha > 0, alpha, 1)[..., None]
    rgb = numpy.clip(255 - (255 - rgb) / safe, 0, 255)
    logo = Image.fromarray(numpy.dstack([rgb, alpha * 255]).round().astype(numpy.uint8), "RGBA")
    return logo.crop(logo.getbbox())


logo = cut_logo(Image.open(SRC).convert("RGBA"))


def write_json(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        json.dump(data, f, indent=2)


def back(size):
    return Image.new("RGBA", size, BACKGROUND)


def front(size, scale=0.85):
    w, h = size
    ratio = min(w * scale / logo.width, h * scale / logo.height)
    resized = logo.resize((int(logo.width * ratio), int(logo.height * ratio)), Image.LANCZOS)
    layer = Image.new("RGBA", size, (0, 0, 0, 0))
    layer.paste(resized, ((w - resized.width) // 2, (h - resized.height) // 2), resized)
    return layer


def flat(size):
    image = back(size)
    image.alpha_composite(front(size, 0.6))
    return image.convert("RGB")


def imageset(directory, sizes, make):
    images = []
    for scale, size in sizes:
        name = f"image@{scale}.png"
        os.makedirs(directory, exist_ok=True)
        make(size).save(os.path.join(directory, name))
        images.append({"idiom": "tv", "scale": scale, "filename": name})
    write_json(os.path.join(directory, "Contents.json"), {"images": images, "info": INFO})


def imagestack(name, sizes):
    stack = os.path.join(BRAND, f"{name}.imagestack")
    write_json(os.path.join(stack, "Contents.json"),
               {"info": INFO, "layers": [{"filename": "Front.imagestacklayer"}, {"filename": "Back.imagestacklayer"}]})
    for layer, make in (("Front", front), ("Back", back)):
        directory = os.path.join(stack, f"{layer}.imagestacklayer")
        write_json(os.path.join(directory, "Contents.json"), {"info": INFO})
        imageset(os.path.join(directory, "Content.imageset"), sizes, make)


write_json(os.path.join(ASSETS, "Contents.json"), {"info": INFO})
imagestack("App Icon", [("1x", (400, 240)), ("2x", (800, 480))])
imagestack("App Icon - App Store", [("1x", (1280, 768))])
imageset(os.path.join(BRAND, "Top Shelf Image.imageset"), [("1x", (1920, 720)), ("2x", (3840, 1440))], flat)
imageset(os.path.join(BRAND, "Top Shelf Image Wide.imageset"), [("1x", (2320, 720)), ("2x", (4640, 1440))], flat)
write_json(os.path.join(BRAND, "Contents.json"), {
    "assets": [
        {"filename": "App Icon - App Store.imagestack", "idiom": "tv", "role": "primary-app-icon", "size": "1280x768"},
        {"filename": "App Icon.imagestack", "idiom": "tv", "role": "primary-app-icon", "size": "400x240"},
        {"filename": "Top Shelf Image Wide.imageset", "idiom": "tv", "role": "top-shelf-image-wide", "size": "2320x720"},
        {"filename": "Top Shelf Image.imageset", "idiom": "tv", "role": "top-shelf-image", "size": "1920x720"},
    ],
    "info": INFO,
})
write_json(os.path.join(ASSETS, "AccentColor.colorset", "Contents.json"), {
    "colors": [{"idiom": "universal", "color": {"color-space": "srgb",
                "components": {"red": "1.000", "green": "0.533", "blue": "0.000", "alpha": "1.000"}}}],
    "info": INFO,
})
print("assets ->", ASSETS)
