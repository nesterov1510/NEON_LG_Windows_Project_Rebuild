#!/bin/bash
# Сборка Release и загрузка в App Store Connect для TestFlight (внутренние тестировщики).
#   tools/testflight.sh            — архив + загрузка
#   tools/testflight.sh --archive  — только архив (проверка без загрузки)
# Номер сборки = число коммитов в git: каждая новая загрузка получает больший номер.
# Учётная запись Apple берётся из Xcode (Settings → Accounts).
set -euo pipefail
cd "$(dirname "$0")/.."

if [[ -n "$(git status --porcelain)" ]]; then
  echo "Есть незакоммиченные изменения — сборка должна соответствовать коммиту." >&2
  exit 1
fi

BUILD=$(git rev-list --count HEAD)
VERSION=$(grep -m1 'MARKETING_VERSION' project.yml | sed -E 's/.*"(.*)".*/\1/')
ARCHIVE="build/testflight/AlemTV-$VERSION-$BUILD.xcarchive"
echo "AlemTV $VERSION ($BUILD), коммит $(git rev-parse --short HEAD)"

xcodegen generate -q
swift test --package-path Packages/AlemCore 2>&1 | grep -E "Test run" || { echo "Тесты AlemCore не прошли" >&2; exit 1; }

xcodebuild archive -project AlemTV.xcodeproj -scheme AlemTV -configuration Release \
  -destination 'generic/platform=tvOS' -archivePath "$ARCHIVE" \
  -derivedDataPath build/release -allowProvisioningUpdates \
  CURRENT_PROJECT_VERSION="$BUILD" -quiet
echo "Архив: $ARCHIVE"

[[ "${1:-}" == "--archive" ]] && exit 0

# Системный PATH: rsync из Homebrew (/usr/local/bin) ломает упаковку IPA в Xcode («Copy failed»).
PATH=/usr/bin:/bin:/usr/sbin:/sbin xcodebuild -exportArchive -archivePath "$ARCHIVE" \
  -exportOptionsPlist tools/testflight/ExportOptions.plist \
  -exportPath build/testflight/export -allowProvisioningUpdates -quiet
echo "Загружено: $VERSION ($BUILD). Через 5–15 минут сборка появится в App Store Connect → TestFlight."
