#!/usr/bin/env python3
"""Делает обезличенные фикстуры для тестов AlemCore из reference/samples/ (результатов tools/probe.py).

Заменяет session_id, токены, логин/пароль, MAC и секрет домена; урезает каталог до 5 каналов.
"""
import json
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, "reference", "samples")
DST = os.path.join(ROOT, "Packages", "AlemCore", "Tests", "AlemCoreTests", "Fixtures")
KEEP = [1, 2, 33, 76, 108976]   # 108976 — канал без архива
MAC = "00:1A:79:00:00:01"


def load(name):
    with open(os.path.join(SRC, name), encoding="utf-8") as f:
        return json.load(f)


def dump(name, data):
    with open(os.path.join(DST, name), "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=1)


def anon_tokens(tokens):
    return {"Key-1": {**next(iter(tokens.values())), "name": "Key-1", "token1": "T1", "token2": "T2"}} if tokens else tokens


os.makedirs(DST, exist_ok=True)

d = load("get_domain_config.json")
d["result"]["auth_secret_key"] = ""
dump("get_domain_config.json", d)

dump("login.json", {"jsonrpc": "2.0", "id": 2, "result": {"session_id": "SID", "user_id": 1}})
dump("register_terminal.json", {"jsonrpc": "2.0", "id": 3, "result": {"session_id": "SID", "user_id": 1, "macaddr": MAC}})

a = load("authorize_terminal.json")
r = a["result"]
head, *rows = r["medialist"]
id_col, key_col = head.index("id"), head.index("key")
rows = [row for row in rows if row[id_col] in KEEP]
for row in rows:
    if row[key_col]:
        row[key_col] = "Key-1"
r["medialist"] = [head] + rows
r["tokens"] = anon_tokens(r.get("tokens"))
r["username"], r["password"], r["macaddr"] = "user", "pass", MAC
for k in ("personal_data", "guest", "room"):
    r.pop(k, None)
items = {"tv": [1, 2, 33, 76, 108976, 999999], "tv-national": [1, 2], "tv-favorites": [33]}
r["playlists"] = [p for p in r["playlists"] if p["name"] in items]
for p in r["playlists"]:
    p["playitems"] = items[p["name"]]
r["state"] = {**(r.get("state") or {}), "media_id": 33}
r["epg_info"] = [e for e in r.get("epg_info") or [] if e["id"] in KEEP]
if r.get("profile"):
    r["profile"]["password"] = None
for s in (r.get("services_enabled") or {}).values():
    s["username"] = s["password"] = s["session_id"] = None
dump("authorize_terminal.json", a)

c = load("check_update.json")
c["result"]["tokens"] = anon_tokens(c["result"].get("tokens"))
c["result"]["epg_info"] = [e for e in c["result"].get("epg_info") or [] if e["id"] in KEEP]
dump("check_update.json", c)
dump("check_update_unauthorized.json",
     {"jsonrpc": "2.0", "id": 2, "result": {"required": False, "critical": False, "domain_updated_on": 1790180081}})

dump("get_epg_day.json", load("get_epg_33_day.json"))
dump("get_epg_now.json", load("get_epg_nownext.json"))
print("fixtures written to", DST)
