#!/usr/bin/env python3
"""Пробный клиент IPTVPORTAL (AlemTV): вход, authorize_terminal, EPG, проверка потоков.

Только чтение, кроме register_terminal (привязка терминала к аккаунту).
Состояние терминала (псевдо-MAC) хранится в reference/samples/.terminal.json и переиспользуется.
"""
import base64, json, os, random, struct, sys, time, urllib.request, urllib.error, urllib.parse
from Crypto.Cipher import AES, PKCS1_v1_5
from Crypto.PublicKey import RSA

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "reference", "samples")
PORTAL = "http://telecom.alemtv.tm"
UA = ("Mozilla/5.0 (Linux; Android 12; AppleTV) AppleWebKit/537.36 (KHTML, like Gecko) "
      "IPTVPORTAL - ARES_Android_TV_v001 - Android - 1.266.0-modern! "
      "&apk_id=iptvportal.alemtv&apk_version=1.266.0-modern&apk_type=market")
TERMINAL_TYPE = "appletv"
FIRMWARE = "tvOS probe 0.1"

RSA_N = int("cf2cde3395737e94f0f0ca7474797d285170eb7acd41628a946f92a00138225a"
            "23c2b7307da8c182536bfa325d7a111dc82eb0825c85614d807b46bdc0bea823"
            "1dde941b2d435782dabed3381b48f30aa19bff261eec4086b56d5c45ea394b8f"
            "386d1ad75b7e8c5d37d517e83e598719afb2b05b790e41f132858321f693c025", 16)
IV = b"arescrypt       "

_id = 0


def save(name, data):
    os.makedirs(OUT, exist_ok=True)
    path = os.path.join(OUT, name)
    with open(path, "w" if isinstance(data, str) else "wb") as f:
        f.write(data)
    return path


def ares_cipher_header(key):
    blob = struct.pack("<H16s8s8sHHHHL", 1, b"aes", b"cbc", b"base64", 128, 16, 46, 62, int(time.time()))
    blob += key + IV
    enc = PKCS1_v1_5.new(RSA.construct((RSA_N, 65537))).encrypt(blob)
    return base64.b64encode(enc).decode()


def aes_enc(data, key):
    pad = 16 - len(data) % 16
    return base64.b64encode(AES.new(key, AES.MODE_CBC, IV).encrypt(data + bytes([pad]) * pad)).decode()


def aes_dec(text, key):
    raw = AES.new(key, AES.MODE_CBC, IV).decrypt(base64.b64decode(text))
    return raw[:-raw[-1]]


def rpc(method, params, encrypted=False):
    global _id
    _id += 1
    body = json.dumps({"jsonrpc": "2.0", "id": _id, "method": method, "params": params}).encode()
    headers = {"User-Agent": UA, "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"}
    if encrypted:
        key = os.urandom(16)
        headers["Ares-Cipher"] = ares_cipher_header(key)
        body = aes_enc(body, key).encode()
    req = urllib.request.Request(f"{PORTAL}/jsonrpc/{method}", data=body, headers=headers)
    with urllib.request.urlopen(req, timeout=30) as r:
        text = r.read()
    if encrypted:
        text = aes_dec(text.decode(), key)
    return json.loads(text)


def http_get(url, limit=None):
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=30) as r:
        data = r.read(limit) if limit else r.read()
        return r.status, r.geturl(), dict(r.headers), data


def creds():
    vals = {}
    for line in open(os.path.join(ROOT, ".credentials")):
        if "=" in line:
            k, v = line.strip().split("=", 1)
            vals[k] = v
    return vals["ALEMTV_LOGIN"], vals["ALEMTV_PASSWORD"]


def csv_rows(table):
    head, *rows = table
    return [dict(zip(head, r)) for r in rows]


def ts_scrambled(data):
    """Доля TS-пакетов со scrambling_control != 0 (без расшифровки)."""
    i = data.find(b"\x47")
    pkts = scr = 0
    while i + 188 <= len(data):
        if data[i] != 0x47:
            i = data.find(b"\x47", i + 1)
            if i < 0:
                break
            continue
        pid = ((data[i + 1] & 0x1F) << 8) | data[i + 2]
        if pid not in (0, 0x1FFF) and (data[i + 3] & 0x10):  # есть payload, не PAT/null
            pkts += 1
            scr += bool(data[i + 3] & 0xC0)
        i += 188
    return pkts, scr


def main():
    state_path = os.path.join(OUT, ".terminal.json")
    state = json.load(open(state_path)) if os.path.exists(state_path) else {}

    dc = rpc("get_domain_config", {"terminal_type": TERMINAL_TYPE})
    save("get_domain_config.json", json.dumps(dc, ensure_ascii=False, indent=1))
    print("get_domain_config:", "ok" if "result" in dc else dc.get("error"))

    base = {"require_session": True, "require_user_id": True,
            "terminal_type": TERMINAL_TYPE, "firmware_version": FIRMWARE}
    mac = state.get("macaddr")
    r = rpc("login", {**base, "macaddr": mac, "create_macaddr": mac is None}, encrypted=True)
    save("login.json", json.dumps(r, ensure_ascii=False, indent=1))
    res = r.get("result") or {}
    mac = res.get("macaddr") or ((r.get("error") or {}).get("extra") or {}).get("macaddr") or mac
    print("login:", "session" if res.get("session_id") else f"нет сессии ({r.get('error')})", "mac:", bool(mac))
    session = res.get("session_id")

    if not session:
        user, pwd = creds()
        r = rpc("register_terminal", {**base, "username": user, "password": pwd,
                                      "macaddr": mac, "create_macaddr": mac is None}, encrypted=True)
        save("register_terminal.json", json.dumps(r, ensure_ascii=False, indent=1))
        res = r.get("result") or {}
        mac = res.get("macaddr") or mac
        session = res.get("session_id")
        print("register_terminal:", "ok" if session else r.get("error") or r.get("result"))
        if not session:
            sys.exit(1)

    state["macaddr"] = mac
    save(".terminal.json", json.dumps(state))

    a = rpc("authorize_terminal", {"session_id": session, "version": 2, "require_media_tokens": True,
                                   "require_media_keys": False, "result_as": "csv"})
    save("authorize_terminal.json", json.dumps(a, ensure_ascii=False, indent=1))
    if "result" not in a:
        print("authorize_terminal error:", a.get("error"))
        sys.exit(1)
    A = a["result"]
    media = csv_rows(A["medialist"])
    enabled = A.get("medialist_enabled")
    tv = [m for m in media if m.get("is_tv") and (enabled is None or str(m["id"]) in enabled)]
    domain = (dc.get("result") or {}).get("name") or "tmalem"
    tokens = A.get("tokens") or {}
    print(f"authorize_terminal: media={len(media)} tv_enabled={len(tv)} "
          f"encrypted={sum(1 for m in tv if m.get('encrypted'))} "
          f"timeshift={sum(1 for m in tv if m.get('timeshift_url'))} "
          f"multicast={sum(1 for m in tv if str(m.get('host') or '').split('.')[0].isdigit() and 224 <= int(str(m['host']).split('.')[0]) <= 239)}")
    print("  auth:", sorted({str(m.get('auth')) for m in tv}), "protocols:", sorted({str(m.get('protocol')) for m in tv}))
    print("  playlists:", [p.get("name") for p in A.get("playlists", [])][:20])
    print("  menu:", [(m.get("title"), m.get("app")) for m in A.get("menu", []) if m.get("parent_id") == "menu"])
    print("  services_enabled:", [s.get("name") for s in A.get("services", []) if str(s.get("id")) in (A.get("services_enabled") or {})])
    print("  languages:", [l.get("iso639_1") for l in A.get("languages", [])], "keys:", bool(A.get("keys")), "tokens:", len(A.get("tokens") or {}))

    now = int(time.time())
    day = time.strftime("%Y-%m-%d", time.localtime(now))
    sample = [m for m in tv if m.get("timeshift_url") and m.get("encrypted")][:1] + \
             [m for m in tv if m.get("timeshift_url") and not m.get("encrypted")][:1] or tv[:2]
    for m in sample:
        e = rpc("get_epg", {"session_id": session, "version": 2, "result_as": "csv", "media_id": m["id"],
                            "language_id": (A.get("language") or {}).get("id"),
                            "start": f"{day} 00:00:00", "stop": f"{day} 23:59:59"})
        save(f"get_epg_{m['id']}.json", json.dumps(e, ensure_ascii=False, indent=1))
        progs = (e.get("result") or {}).get("programs") or []
        print(f"get_epg {m['id']} {m.get('name')}: {max(len(progs) - 1, 0)} передач")

        url = (m.get("path") if str(m.get("path") or "").startswith("http")
               else f"{m.get('protocol') or 'http'}://{m['host']}{':' + str(m['port']) if m.get('port') else ''}/{str(m.get('path') or '').lstrip('/')}")
        tok = f"token={session}"
        if m.get("key") and m["key"] in tokens:
            t = tokens[m["key"]]
            inner = (f"token={session}&token1={t['token1']}&token2={t['token2']}&domain={domain}"
                     f"&key={m['key']}&media_id={m['id']}&timestamp={int(time.time())}")
            tok = "token=" + urllib.parse.quote(inner, safe="")
        urls = {"live": url + ("&" if "?" in url else "?") + tok}
        if m.get("timeshift_url"):
            tsb = str(m["timeshift_url"]).split("?")[0].rsplit("/", 1)[0]
            start = (now - 2 * 3600) // 60 * 60
            urls["archive"] = f"{tsb}/index-{start}-600.m3u8?{tok}"
            urls["timeshift"] = f"{tsb}/timeshift_rel-300.m3u8?{tok}"
        for kind, u in urls.items():
            try:
                st, final, hdr, body = http_get(u, 200_000)
                save(f"stream_{m['id']}_{kind}.txt", f"URL: {u}\nFINAL: {final}\nSTATUS: {st}\n{json.dumps(hdr, indent=1)}\n\n"
                     + (body.decode(errors='replace') if b"#EXTM3U" in body[:20] else f"<binary {len(body)} bytes>"))
                print(f"  {kind}: {st} {hdr.get('Content-Type')}")
                text = body.decode(errors="replace")
                # спуститься до сегмента
                for _ in range(3):
                    if "#EXTM3U" not in text[:20]:
                        break
                    lines = [l for l in text.splitlines() if l and not l.startswith("#")]
                    if not lines:
                        break
                    final = urllib.parse.urljoin(final, lines[0])
                    st, final, hdr, body = http_get(final, 200_000)
                    text = body.decode(errors="replace") if b"#EXTM3U" in body[:20] else ""
                if body[:1] == b"\x47" or b"\x47" in body[:400]:
                    pkts, scr = ts_scrambled(body)
                    print(f"    сегмент TS: {len(body)} байт, пакетов с payload={pkts}, скремблировано={scr}")
                else:
                    print(f"    сегмент: {hdr.get('Content-Type')} {len(body)} байт, начало={body[:8].hex()}")
            except urllib.error.HTTPError as ex:
                print(f"  {kind}: HTTP {ex.code}")
            except Exception as ex:
                print(f"  {kind}: {type(ex).__name__}: {ex}")


if __name__ == "__main__":
    main()
