#!/usr/bin/env python3
"""Генерирует App/Resources/Localizable.xcstrings (ru — исходный язык, tk, en).

Туркменские строки частично взяты из локали портала (resources/portal/locale/tk.js);
помеченные «# tk?» — машинный перевод, требуют вычитки носителем.
"""
import json
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "App", "Resources", "Localizable.xcstrings")

STRINGS = {
    # key: (ru, en, tk)
    "login.title": ("Вход", "Login", "Girmek"),
    "login.username": ("Имя", "Username", "Ulanyjynyň ady"),
    "login.password": ("Пароль", "Password", "Açar sözi"),
    "login.submit": ("Войти", "Sign in", "Girmek"),
    "login.error.denied": ("Доступ запрещен", "Access denied", "Inkär edildi"),
    "login.changePortal": ("Сменить портал", "Change portal", "Portaly üýtgetmek"),  # tk?
    "error.network": ("Сервис недоступен! Проверьте подключение к сети.", "Service unavailable! Check your network connection.", "Hyzmat elýeterli däl! Ulgama birikmäni barlaň."),  # tk?
    "error.retry": ("Повтор", "Repeat", "Gaýtalamak"),
    "guide.channels": ("Каналы", "Channels", "Telekanallar"),  # tk?
    "guide.favorites": ("Избранное", "Favorites", "Saýlanan"),
    "guide.settings": ("Настройки", "Settings", "Sazlamalar"),
    "channel.schedule": ("Программа передач", "TV guide", "Teleýaýlymlaryň sanawy"),  # tk?
    "channel.addFavorite": ("В избранное", "Add to favorites", "Saýlanana goşmak"),  # tk?
    "channel.removeFavorite": ("Убрать из избранного", "Remove from favorites", "Saýlanandan aýyrmak"),  # tk?
    "epg.empty": ("Программа передач отсутствует", "TV listings not found", "Teleýaýlymlaryň sanawy ýok"),
    "epg.today": ("Сегодня", "Today", "Şu gün"),
    "epg.archive": ("В архиве", "In archive", "Arhiwde"),  # tk?
    "epg.live": ("Сейчас в эфире", "On air now", "Häzir efirde"),  # tk?
    "player.unavailable": ("Канал недоступен", "The channel is unavailable", "Telekanal elýeterli däl"),
    "player.recordingUnavailable": ("Видео недоступно", "The video is unavailable", "Wideo elýeterli däl"),
    "player.goLive": ("В эфир", "Go live", "Efire"),  # tk?
    "player.startOver": ("С начала", "Start over", "Başdan"),  # tk?
    "player.back10": ("−10 с", "−10 s", "−10 s"),
    "player.forward10": ("+10 с", "+10 s", "+10 s"),
    "player.behindLive": ("%@ от эфира", "%@ behind live", "efirden %@ yzda"),  # tk?
    "player.info": ("Программа", "Program", "Gepleşik"),  # tk?
    "player.continue.title": ("Продолжить просмотр?", "Continue watching?", "Tomaşa etmegi dowam etmelimi?"),  # tk?
    "player.continue": ("Продолжить", "Continue", "Dowam etmek"),
    "settings.profile": ("Профиль", "Profile", "Şahsy bölüm"),
    "settings.language": ("Язык", "Language", "Dil"),
    "settings.portal": ("Портал", "Portal", "Portal"),
    "settings.about": ("О приложении", "About", "Programma barada"),  # tk?
    "settings.version": ("Версия", "Version", "Wersiýa"),  # tk?
    "settings.terminal": ("Терминал (MAC)", "Terminal (MAC)", "Terminal (MAC)"),
    "settings.logout": ("Выход из аккаунта", "Logout", "Çykmak"),
    "settings.logout.confirm": ("Отвязать это устройство от аккаунта?", "Unlink this device from the account?", "Bu enjamy hasapdan aýyrmalymy?"),  # tk?
    "profile.enterPassword": ("Введите пароль для профиля", "Enter password for profile", "Şahsy bölümi üçin açar sözüni giriziň"),
    "profile.wrongPassword": ("Ошибка ввода", "Enter failure", "Girizişde ýalňyşlyk"),
    "portal.confirm": ("Сменить портал? Потребуется войти заново.", "Switch portal? You will need to sign in again.", "Portaly üýtgetmelimi? Täzeden girmeli bolarsyňyz."),  # tk?
    "common.cancel": ("Отмена", "Cancel", "Bes etmek"),
    "common.ok": ("OK", "OK", "OK"),
    "player.audio": ("Звук", "Audio", "Ses"),  # tk?
    "player.live": ("Эфир", "Live", "Efir"),  # tk?
    "player.pause": ("Пауза", "Pause", "Pauza"),
    "player.play": ("Смотреть", "Play", "Görmek"),  # tk?
    "settings.engine": ("Воспроизведение: VLCKit 4.0.0-a25, лицензия LGPL 2.1. Исходники: code.videolan.org/videolan/VLCKit", "Playback: VLCKit 4.0.0-a25, LGPL 2.1 license. Source: code.videolan.org/videolan/VLCKit", "Görkezmek: VLCKit 4.0.0-a25, LGPL 2.1 ygtyýarnamasy. Çeşme kody: code.videolan.org/videolan/VLCKit"),  # tk?
}


def unit(value):
    return {"stringUnit": {"state": "translated", "value": value}}


catalog = {
    "sourceLanguage": "ru",
    "strings": {
        key: {"localizations": {"ru": unit(ru), "en": unit(en), "tk": unit(tk)}}
        for key, (ru, en, tk) in sorted(STRINGS.items())
    },
    "version": "1.0",
}
os.makedirs(os.path.dirname(OUT), exist_ok=True)
with open(OUT, "w", encoding="utf-8") as f:
    json.dump(catalog, f, ensure_ascii=False, indent=2)
print(f"{len(STRINGS)} keys -> {OUT}")
