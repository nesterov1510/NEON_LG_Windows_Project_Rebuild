#!/bin/bash
# Смоук-проверка движка в симуляторе: каждый тип канала должен заиграть (кадр > 0) за 15 с.
# Терминал уже должен быть в Keychain симулятора; первый запуск: SEED_MAC=<mac> tools/smoke_channels.sh
set -u
DEVICE="${DEVICE:-Apple TV 4K (3rd generation)}"
APP=$(find ~/Library/Developer/Xcode/DerivedData -path "*/Build/Products/Debug-appletvsimulator/AlemTV.app" -not -path "*Index.noindex*" -maxdepth 6 -type d | head -1)
[[ -d "$APP" ]] || { echo "Сборка для симулятора не найдена" >&2; exit 1; }
xcrun simctl boot "$DEVICE" 2>/dev/null
xcrun simctl bootstatus "$DEVICE" -b >/dev/null
xcrun simctl install "$DEVICE" "$APP" || exit 1
fail=0
while read -r name id mode; do
  xcrun simctl terminate "$DEVICE" com.alexvamp.alemtv 2>/dev/null
  xcrun simctl launch "$DEVICE" com.alexvamp.alemtv -debugChannelID "$id" -debugMode "$mode" ${SEED_MAC:+-seedMAC "$SEED_MAC"} >/dev/null
  sleep 15
  line=$(xcrun simctl spawn "$DEVICE" log show --last 15s --info \
    --predicate 'subsystem == "com.alexvamp.alemtv" AND category == "player"' --style compact 2>/dev/null \
    | grep -o 'playing [0-9]*x[0-9]* audio=[0-9]*' | tail -1)
  if [[ "$line" =~ playing\ [1-9][0-9]*x[1-9] ]]; then
    echo "OK   $name ($mode): $line"
  else
    echo "FAIL $name ($mode): ${line:-нет воспроизведения}"
    fail=1
  fi
done <<'EOF'
HEVC+AAC 1 live
H.264+AAC 11 live
H.264+MP2 116 live
HEVC+MP2 10 live
MPEG-2+MP2 41 live
HEVC+AAC 1 archive
HEVC+AAC 1 timeshift
EOF
xcrun simctl terminate "$DEVICE" com.alexvamp.alemtv 2>/dev/null
exit $fail
