window.beletWebosIdentity = function () { return {model: 'Kali Linux PC', osVersion: 'Linux'}; };
