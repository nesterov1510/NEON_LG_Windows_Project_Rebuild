(function () {
  var proxyBase = typeof window.__NEON_PROXY_BASE__ === 'string' ? window.__NEON_PROXY_BASE__ : '';
  if (!proxyBase || typeof window.XMLHttpRequest !== 'function') return;

  function toProxyUrl(url) {
    if (typeof url !== 'string') return url;
    if (url.indexOf(proxyBase + '/') === 0) return url;
    var match = /^(https?):\/\/(.+)$/i.exec(url);
    if (!match) return url;
    return proxyBase + '/' + match[1].toLowerCase() + '/' + match[2];
  }

  window.__neonToProxyUrl = toProxyUrl;

  var proto = window.XMLHttpRequest.prototype;
  var origOpen = proto.open;
  proto.open = function (method, url) {
    var args = Array.prototype.slice.call(arguments);
    var rawUrl = typeof url === 'string' ? url : String(url || '');
    var proxied = toProxyUrl(rawUrl);
    if (proxied !== rawUrl) {
      args[1] = proxied;
      this.__neonOrigUrl = rawUrl;
      try {
        Object.defineProperty(this, 'responseURL', {
          configurable: true,
          get: function () {
            if (this.readyState >= 2) {
              try {
                var finalUrl = this.getResponseHeader('X-Neon-Final-URL');
                if (finalUrl) return finalUrl;
              } catch (e) {}
            }
            return this.__neonOrigUrl || '';
          }
        });
      } catch (e) {}
    } else if (this.__neonOrigUrl) {
      delete this.__neonOrigUrl;
      try { delete this.responseURL; } catch (e) {}
    }
    return origOpen.apply(this, args);
  };
}());

window.beletWebosIdentity = function () { return {model: 'Kali Linux PC', osVersion: 'Linux'}; };

(function () {
  var toProxyUrl = window.__neonToProxyUrl;
  var video = document.getElementById('video');
  var proto = window.HTMLMediaElement && window.HTMLMediaElement.prototype;
  var srcDesc = proto && Object.getOwnPropertyDescriptor(proto, 'src');
  if (!toProxyUrl || !video || !srcDesc || !srcDesc.set || !srcDesc.get) return;
  var origUrl = '';
  Object.defineProperty(video, 'src', {
    configurable: true,
    get: function () {
      var real = srcDesc.get.call(video);
      if (!real) { origUrl = ''; return ''; }
      if (real.indexOf('blob:') === 0) return real;
      return origUrl || real;
    },
    set: function (value) {
      var raw = (value === null || value === undefined) ? '' : String(value);
      if (!raw || raw.indexOf('blob:') === 0 || raw.indexOf('data:') === 0) {
        origUrl = '';
        return srcDesc.set.call(video, raw);
      }
      origUrl = raw;
      return srcDesc.set.call(video, toProxyUrl(raw));
    }
  });
}());
