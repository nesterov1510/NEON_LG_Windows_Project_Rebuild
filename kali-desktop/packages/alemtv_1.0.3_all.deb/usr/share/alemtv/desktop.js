(function () {
  var proxyBase = typeof window.__NEON_PROXY_BASE__ === 'string' ? window.__NEON_PROXY_BASE__ : '';
  if (!proxyBase || typeof window.XMLHttpRequest !== 'function') return;

  function toProxyUrl(url) {
    if (typeof url !== 'string') return url;
    if (url.indexOf(proxyBase + '/') === 0) return url;
    var match = /^(https?):\/\/(.+)$/i.exec(url);
    if (!match) return url;
    return proxyBase + '/' + match[1].toLowerCase() + '/' + match[2];
  }

  window.__neonToProxyUrl = toProxyUrl;

  var proto = window.XMLHttpRequest.prototype;
  var origOpen = proto.open;
  proto.open = function (method, url) {
    var args = Array.prototype.slice.call(arguments);
    var rawUrl = typeof url === 'string' ? url : String(url || '');
    var proxied = toProxyUrl(rawUrl);
    if (proxied !== rawUrl) {
      args[1] = proxied;
      this.__neonOrigUrl = rawUrl;
      try {
        Object.defineProperty(this, 'responseURL', {
          configurable: true,
          get: function () {
            if (this.readyState >= 2) {
              try {
                var finalUrl = this.getResponseHeader('X-Neon-Final-URL');
                if (finalUrl) return finalUrl;
              } catch (e) {}
            }
            return this.__neonOrigUrl || '';
          }
        });
      } catch (e) {}
    } else if (this.__neonOrigUrl) {
      delete this.__neonOrigUrl;
      try { delete this.responseURL; } catch (e) {}
    }
    return origOpen.apply(this, args);
  };
}());

(function () {
  var video = document.getElementById('videoElement');
  var proto = window.HTMLMediaElement && window.HTMLMediaElement.prototype;
  if (!video || !proto) return;

  var srcDesc = Object.getOwnPropertyDescriptor(proto, 'src');
  var nativeLoad = proto.load;
  var nativePlay = proto.play;
  var nativePause = proto.pause;
  if (!srcDesc || !srcDesc.set || !nativeLoad || !nativePlay) return;

  var toProxyUrl = window.__neonToProxyUrl || function (u) { return u; };
  var targetUrl = '';
  var hlsInstance = null;
  var playGen = 0;
  var strategies = [];
  var strategyIndex = 0;
  var loaded = false;
  var manifestParsed = false;
  var mediaRecovered = false;
  var insideHlsAttach = false;
  var insideHlsDetach = false;
  var suppressNativeError = false;
  var appOnError = null;
  var syntheticCode = 0;

  function isHlsCandidate(url) {
    if (!url || !/^https?:\/\//i.test(url)) return false;
    var clean = url.split('#')[0].split('?')[0].toLowerCase();
    if (/\.m3u8$/.test(clean)) return true;
    return !/\.(mp4|m4v|webm|mkv|avi|mov|mp3|aac|ogg|wav|flac)$/.test(clean);
  }

  function destroyHls() {
    manifestParsed = false;
    if (!hlsInstance) return;
    var h = hlsInstance;
    hlsInstance = null;
    insideHlsDetach = true;
    suppressNativeError = true;
    try { h.destroy(); } catch (e) {}
    suppressNativeError = false;
    insideHlsDetach = false;
  }

  function clearNativeSrc() {
    suppressNativeError = true;
    insideHlsDetach = true;
    try { video.removeAttribute('src'); } catch (e) {}
    try {
      while (video.firstChild) video.removeChild(video.firstChild);
    } catch (e) {}
    try { nativeLoad.call(video); } catch (e) {}
    insideHlsDetach = false;
    suppressNativeError = false;
  }

  function buildStrategies(url) {
    var list = [];
    var hlsSupported = false;
    try { hlsSupported = !!(window.Hls && window.Hls.isSupported()); } catch (e) {}
    if (isHlsCandidate(url) && hlsSupported) list.push('hls');
    if (/^https?:\/\//i.test(url) && toProxyUrl(url) !== url) list.push('native-proxy');
    list.push('native-direct');
    return list;
  }

  function notifyFailure() {
    if (typeof appOnError !== 'function') return;
    syntheticCode = video.error ? 0 : 4;
    try {
      appOnError.call(video);
    } finally {
      syntheticCode = 0;
    }
  }

  function advanceStrategy(gen) {
    if (gen !== playGen) return;
    var nextGen = ++playGen;
    destroyHls();
    if (strategyIndex + 1 < strategies.length) {
      strategyIndex += 1;
      startStrategy(nextGen);
      return;
    }
    notifyFailure();
  }

  function startStrategy(gen) {
    if (gen !== playGen || !targetUrl) return;
    var strat = strategies[strategyIndex];
    if (!strat) {
      notifyFailure();
      return;
    }
    if (strat === 'hls') {
      var hls;
      manifestParsed = false;
      mediaRecovered = false;
      try {
        hls = new window.Hls({
          enableWorker: false,
          lowLatencyMode: false,
          backBufferLength: 10,
          maxBufferLength: 30,
          manifestLoadingTimeOut: 15000,
          levelLoadingTimeOut: 15000,
          fragLoadingTimeOut: 15000,
          manifestLoadingMaxRetry: 2,
          levelLoadingMaxRetry: 2,
          fragLoadingMaxRetry: 3
        });
      } catch (e) {
        advanceStrategy(gen);
        return;
      }
      hlsInstance = hls;
      hls.on(window.Hls.Events.ERROR, function (_ev, data) {
        if (gen !== playGen || hlsInstance !== hls || !data || !data.fatal) return;
        if (data.type === window.Hls.ErrorTypes.MEDIA_ERROR && !mediaRecovered) {
          mediaRecovered = true;
          try { hls.recoverMediaError(); return; } catch (e) {}
        }
        advanceStrategy(gen);
      });
      hls.on(window.Hls.Events.MANIFEST_PARSED, function () {
        if (gen !== playGen || hlsInstance !== hls) return;
        manifestParsed = true;
        try {
          var p = nativePlay.call(video);
          if (p && typeof p.catch === 'function') p.catch(function () {});
        } catch (e) {}
      });
      hls.on(window.Hls.Events.MEDIA_ATTACHED, function () {
        if (gen !== playGen || hlsInstance !== hls) return;
        try { hls.loadSource(targetUrl); } catch (e) { advanceStrategy(gen); }
      });
      insideHlsAttach = true;
      try {
        hls.attachMedia(video);
      } catch (e) {
        insideHlsAttach = false;
        advanceStrategy(gen);
        return;
      }
      insideHlsAttach = false;
      return;
    }

    var resolved = strat === 'native-proxy' ? toProxyUrl(targetUrl) : targetUrl;
    destroyHls();
    clearNativeSrc();
    try {
      srcDesc.set.call(video, resolved);
      nativeLoad.call(video);
      var np = nativePlay.call(video);
      if (np && typeof np.catch === 'function') np.catch(function () {});
    } catch (e) {
      advanceStrategy(gen);
    }
  }

  var errorDesc = Object.getOwnPropertyDescriptor(proto, 'error');
  if (errorDesc && errorDesc.get) {
    Object.defineProperty(video, 'error', {
      configurable: true,
      get: function () {
        var realErr = errorDesc.get.call(video);
        if (realErr) return realErr;
        return syntheticCode ? { code: syntheticCode } : null;
      }
    });
  }

  Object.defineProperty(video, 'onerror', {
    configurable: true,
    get: function () { return appOnError; },
    set: function (fn) { appOnError = typeof fn === 'function' ? fn : null; }
  });

  video.addEventListener('error', function () {
    if (!targetUrl || suppressNativeError) return;
    advanceStrategy(playGen);
  }, false);

  Object.defineProperty(video, 'src', {
    configurable: true,
    get: function () {
      var real = srcDesc.get ? srcDesc.get.call(video) : '';
      if (real && real.indexOf('blob:') === 0) return real;
      return targetUrl || real;
    },
    set: function (value) {
      var str = (value === null || value === undefined) ? '' : String(value).trim();
      if (str.indexOf('blob:') === 0) {
        return srcDesc.set.call(video, str);
      }
      playGen += 1;
      loaded = false;
      destroyHls();
      targetUrl = str;
      strategies = targetUrl ? buildStrategies(targetUrl) : [];
      strategyIndex = 0;
      if (!targetUrl) clearNativeSrc();
    }
  });

  video.load = function () {
    if (insideHlsAttach || insideHlsDetach || loaded || !targetUrl) {
      return nativeLoad.call(video);
    }
    loaded = true;
    playGen += 1;
    strategyIndex = 0;
    startStrategy(playGen);
  };

  video.play = function () {
    if (targetUrl && !loaded) {
      loaded = true;
      playGen += 1;
      strategyIndex = 0;
      startStrategy(playGen);
      return Promise.resolve();
    }
    if (hlsInstance && !manifestParsed) {
      return Promise.resolve();
    }
    return nativePlay.call(video);
  };

  if (nativePause) {
    video.pause = function () {
      return nativePause.call(video);
    };
  }
}());
