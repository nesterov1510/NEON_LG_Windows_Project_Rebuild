"""Unit tests for Alem TV packaging and integration (LG webOS IPK & Samsung Tizen WGT)."""

import datetime
import io
import json
import tarfile
import zipfile
import pytest

from cryptography import x509
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import NameOID

from alemtv_app import (
    ALEMTV_APP_ID,
    ALEMTV_DEFAULT_PORTAL,
    ALEMTV_PKG_ID,
    ALEMTV_PORTALS,
    ALEMTV_WEBOS_ID,
    build_alemtv_html,
    build_alemtv_ipk,
    build_alemtv_wgt,
    get_alemtv_assets,
)
from core import Api
from samsung_tizen import (
    sign_wgt_bytes,
    verify_wgt_signatures,
)

def test_alemtv_assets_exist():
    assets = get_alemtv_assets()
    for key in ('icon', 'large_icon', 'splash', 'ui'):
        assert key in assets, f"Missing asset {key}"
        assert len(assets[key]) > 0
        assert assets[key].startswith(b'\x89PNG\r\n\x1a\n')

def test_alemtv_portals_catalog():
    assert len(ALEMTV_PORTALS) >= 7
    hosts = [p['host'] for p in ALEMTV_PORTALS]
    expected_hosts = [
        'telecom.alemtv.tm',
        'astu.tmalem.tv',
        'ark.alemtv.tm',
        'local-astu.alemtv.tm',
        'iptv.tmalem.tv',
        'iptv-org.github.io',
        'go.iptvportal.ru',
        'nextouch.iptvportal.ru',
    ]
    for eh in expected_hosts:
        assert eh in hosts

def test_build_alemtv_html_structure():
    html = build_alemtv_html()
    assert '<!DOCTYPE html>' in html
    assert 'Alem TV' in html
    assert 'SilkyOpenChannel' in html
    assert 'loadSilkyOpenChannels' in html
    assert 'jsonrpc' in html
    assert 'authorize_terminal' in html
    assert 'get_domain_config' in html
    assert 'get_epg' in html
    assert 'check_update' in html
    assert 'buildTokenQuery' in html
    assert 'cf2cde3395737e94f0f0ca7474797d285170eb7acd41628a946f92a00138225a' in html  # RSA modulus
    assert 'arescrypt       ' in html
    assert 'videoElement' in html
    assert 'playerOsd' in html
    assert '10009' in html  # Tizen Return key
    assert '461' in html    # webOS Back key
    assert 'splashPortalSelector' in html
    assert 'scanAndConnectPortal' in html
    assert 'customPortalInput' in html
    assert 'updateSplashSelector' in html
    assert 'parseMedialistTable' in html
    assert 'loginModal' in html
    assert 'customMacInput' in html
    assert 'submitSubscriberLogin' in html
    for eh in ['telecom.alemtv.tm', 'astu.tmalem.tv', 'ark.alemtv.tm', 'local-astu.alemtv.tm', 'iptv.tmalem.tv', 'iptv-org.github.io', 'go.iptvportal.ru', 'nextouch.iptvportal.ru']:
        assert eh in html

def test_build_alemtv_ipk_structure():
    ipk_bytes = build_alemtv_ipk()
    assert ipk_bytes.startswith(b'!<arch>\n')

    pos = len(b'!<arch>\n')
    members = {}
    while pos < len(ipk_bytes):
        hdr = ipk_bytes[pos:pos + 60]
        assert len(hdr) == 60
        assert hdr[58:60] == b'`\n'
        name = hdr[:16].decode('ascii').strip()
        assert not name.endswith('/')  # LG appInstallService rejects GNU '/' suffix
        size = int(hdr[48:58].decode('ascii').strip())
        pos += 60
        members[name] = ipk_bytes[pos:pos + size]
        pos += size + (size % 2)

    assert list(members.keys()) == ['debian-binary', 'control.tar.gz', 'data.tar.gz']
    assert members['debian-binary'] == b'2.0\n'

    # Control tar.gz
    with tarfile.open(fileobj=io.BytesIO(members['control.tar.gz']), mode='r:gz') as tf:
        names = tf.getnames()
        assert names == ['control']
        ctrl_txt = tf.extractfile('control').read().decode('utf-8')
        assert f'Package: {ALEMTV_WEBOS_ID}\n' in ctrl_txt
        assert 'webOS-Package-Format-Version: 2\n' in ctrl_txt

    # Data tar.gz
    with tarfile.open(fileobj=io.BytesIO(members['data.tar.gz']), mode='r:gz') as tf:
        names = tf.getnames()
        base = f'usr/palm/applications/{ALEMTV_WEBOS_ID}'
        for req in (f'{base}/appinfo.json', f'{base}/index.html', f'{base}/icon.png', f'{base}/largeIcon.png', f'{base}/splash.png'):
            assert req in names
        appinfo = json.loads(tf.extractfile(f'{base}/appinfo.json').read().decode('utf-8'))
        assert appinfo['id'] == ALEMTV_WEBOS_ID
        assert appinfo['title'] == 'Alem TV'
        assert appinfo['resolution'] == '1920x1080'

def test_build_alemtv_wgt_and_sign():
    unsigned_wgt = build_alemtv_wgt()
    assert unsigned_wgt.startswith(b'PK')

    with zipfile.ZipFile(io.BytesIO(unsigned_wgt), 'r') as zf:
        names = set(zf.namelist())
        assert {'config.xml', 'index.html', 'icon.png'}.issubset(names)
        cfg = zf.read('config.xml').decode('utf-8')
        assert f'package="{ALEMTV_PKG_ID}"' in cfg
        assert f'id="{ALEMTV_APP_ID}"' in cfg
        assert 'AlemTV' in cfg
        assert 'http://tizen.org/privilege/tv.inputdevice' in cfg
        assert 'http://tizen.org/privilege/internet' in cfg

    # Generate in-memory self-signed test certificates
    now = datetime.datetime.now(datetime.timezone.utc)
    a_key = rsa.generate_private_key(65537, 2048)
    d_key = rsa.generate_private_key(65537, 2048)
    a_ca_key = rsa.generate_private_key(65537, 2048)
    d_ca_key = rsa.generate_private_key(65537, 2048)

    a_ca = (
        x509.CertificateBuilder()
        .subject_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, 'Author CA')]))
        .issuer_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, 'Author CA')]))
        .public_key(a_ca_key.public_key())
        .serial_number(1)
        .not_valid_before(now - datetime.timedelta(days=1))
        .not_valid_after(now + datetime.timedelta(days=3650))
        .add_extension(x509.BasicConstraints(ca=True, path_length=None), critical=True)
        .sign(a_ca_key, hashes.SHA256())
    )
    a_leaf = (
        x509.CertificateBuilder()
        .subject_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, 'NEON')]))
        .issuer_name(a_ca.subject)
        .public_key(a_key.public_key())
        .serial_number(2)
        .not_valid_before(now - datetime.timedelta(days=1))
        .not_valid_after(now + datetime.timedelta(days=3650))
        .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
        .sign(a_ca_key, hashes.SHA256())
    )

    d_ca = (
        x509.CertificateBuilder()
        .subject_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, 'Distributor CA')]))
        .issuer_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, 'Distributor CA')]))
        .public_key(d_ca_key.public_key())
        .serial_number(1)
        .not_valid_before(now - datetime.timedelta(days=1))
        .not_valid_after(now + datetime.timedelta(days=3650))
        .add_extension(x509.BasicConstraints(ca=True, path_length=None), critical=True)
        .sign(d_ca_key, hashes.SHA256())
    )
    d_leaf = (
        x509.CertificateBuilder()
        .subject_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, 'Tizen Distributor')]))
        .issuer_name(d_ca.subject)
        .public_key(d_key.public_key())
        .serial_number(2)
        .not_valid_before(now - datetime.timedelta(days=1))
        .not_valid_after(now + datetime.timedelta(days=3650))
        .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
        .sign(d_ca_key, hashes.SHA256())
    )

    signed_wgt = sign_wgt_bytes(
        unsigned_wgt,
        a_key,
        [a_leaf, a_ca],
        d_key,
        [d_leaf, d_ca],
    )
    assert signed_wgt.startswith(b'PK')
    assert len(signed_wgt) > len(unsigned_wgt)

    verify_result = verify_wgt_signatures(signed_wgt)
    assert verify_result is True

def test_api_alemtv_methods():
    api = Api()
    ipk = api.build_alemtv_ipk()
    assert ipk.startswith(b'!<arch>\n')

    wgt = api.build_samsung_alemtv_wgt()
    assert wgt.startswith(b'PK')

def test_alemtv_js_syntax_validity():
    import os
    import shutil
    import subprocess
    import tempfile
    from alemtv_app import build_alemtv_js

    node_bin = shutil.which('node')
    if not node_bin:
        pytest.skip("Node.js not available in environment")

    js_code = build_alemtv_js()
    fd, tf_path = tempfile.mkstemp(suffix='.js')
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            f.write(js_code)
        proc = subprocess.run([node_bin, '-c', tf_path], capture_output=True, text=True)
        assert proc.returncode == 0, f"JS Syntax Error:\n{proc.stderr}"
    finally:
        if os.path.exists(tf_path):
            os.remove(tf_path)

def test_alemtv_custom_portal_persistence():
    from alemtv_app import build_alemtv_js, build_alemtv_html
    api = Api()

    # Test custom portal normalization
    norm = api._normalize_portal_url("astu.tmalem.tv/")
    assert norm == "http://astu.tmalem.tv"

    norm_ip = api._normalize_portal_url("192.168.1.80:8080/")
    assert norm_ip == "http://192.168.1.80:8080"

    # Test custom portal baked into JS
    js = build_alemtv_js(default_portal="http://astu.tmalem.tv")
    assert 'var DEFAULT_PORTAL = "http://astu.tmalem.tv";' in js
    assert 'lastBaked !== bakedDefault' in js
    assert 'splashServerButtons' in js
    assert '65385' in js  # Samsung Tizen Select/OK keycode

    # Test custom portal in HTML
    html = build_alemtv_html(default_portal="http://astu.tmalem.tv")
    assert 'id="splashServerButtons"' in html
    assert 'http://astu.tmalem.tv' in html

def test_alemtv_silky_open_channel():
    """Verify SilkyOpenChannel fallback test streams and M3U parser work properly in JS."""
    import os
    import shutil
    import subprocess
    import tempfile
    from alemtv_app import build_alemtv_js

    node_bin = shutil.which('node')
    if not node_bin:
        pytest.skip("Node.js not available in environment")

    js = build_alemtv_js()
    runner = '''
var window = { addEventListener: function() {} };
var document = {
  readyState: 'loading',
  addEventListener: function() {},
  getElementById: function() { return { querySelectorAll: function() { return []; }, appendChild: function(){}, classList: { add: function(){}, remove: function(){} }, style: {}, textContent: '' }; },
  querySelectorAll: function() { return []; },
  createElement: function() { return { querySelectorAll: function() { return []; }, appendChild: function(){}, style: {}, classList: { add: function(){}, remove: function(){} }, dataset: {} }; }
};
var localStorage = { getItem: function() { return null; }, setItem: function() {}, removeItem: function() {} };
''' + js + '''
// Test SilkyOpenChannel channel list
var silkyList = window.getSilkyOpenChannelsList();
if (!Array.isArray(silkyList) || silkyList.length < 5) {
  throw new Error('silkyList invalid: ' + JSON.stringify(silkyList));
}
silkyList.forEach(function(ch) {
  if (!ch.title || !ch.stream_url) {
    throw new Error('channel missing title or stream_url: ' + JSON.stringify(ch));
  }
});

// Test M3U parser using String.fromCharCode(10)
var sampleM3u = ['#EXTM3U', '#EXTINF:-1 tvg-id=\"1\" tvg-logo=\"http://logo.png\" group-title=\"TestGroup\",Test Channel', 'http://test.stream/live.m3u8'].join(String.fromCharCode(10));
var parsed = window.parseM3uChannels(sampleM3u);
if (!parsed || parsed.length !== 1 || parsed[0].title !== 'Test Channel' || parsed[0].stream_url !== 'http://test.stream/live.m3u8') {
  throw new Error('m3u parser failed: ' + JSON.stringify(parsed));
}

// Test auth success with silkyList
window.handleAuthSuccess({ channels: silkyList, session_id: 'silky_open' });
if (!window.authData.channels || window.authData.channels.length < 5) {
  throw new Error('authData channels missing: ' + JSON.stringify(window.authData.channels));
}

process.exit(0);
'''
    fd, tf_path = tempfile.mkstemp(suffix='.js')
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            f.write(runner)
        p = subprocess.run([node_bin, tf_path], capture_output=True, text=True, timeout=15)
        assert p.returncode == 0, f"SilkyOpenChannel JS test failed:\nSTDOUT: {p.stdout}\nSTDERR: {p.stderr}"
    finally:
        if os.path.exists(tf_path):
            os.remove(tf_path)

def test_alemtv_stream_url_builder_appletv_alignment():
    """Verify JS Stream URL builder replicates Apple TV tvOS StreamURLBuilder test vectors."""
    import os
    import shutil
    import subprocess
    import tempfile
    from alemtv_app import build_alemtv_js

    node_bin = shutil.which('node')
    if not node_bin:
        pytest.skip("Node.js not available in environment")

    js = build_alemtv_js()
    runner = '''
var window = { addEventListener: function() {} };
var document = {
  readyState: 'loading',
  addEventListener: function() {},
  getElementById: function() { return { querySelectorAll: function() { return []; }, appendChild: function(){}, classList: { add: function(){}, remove: function(){} }, style: {}, textContent: '' }; },
  querySelectorAll: function() { return []; },
  createElement: function() { return { querySelectorAll: function() { return []; }, appendChild: function(){}, style: {}, classList: { add: function(){}, remove: function(){} }, dataset: {} }; }
};
var localStorage = { getItem: function() { return null; }, setItem: function() {}, removeItem: function() {} };
''' + js + '''
var altyn = {
  id: 1, index: 1, name: 'Altyn Asyr', scheme: 'http', host: '119.235.117.209', port: 8010,
  path: 'AltynAsyr/video.m3u8', auth: 'iptvportal', key: 'Key-1', encrypted: true,
  timeshift_url: 'http://119.235.117.213:8020/AltynAsyr', timeshift_archive_length: 259200,
  timeshift_auth: 'iptvportal'
};
window.authData.tokens = { 'Key-1': { name: 'Key-1', token1: 'T1', token2: 'T2' } };
window.authData.domain = 'tmalem';

// Test 1: Live with composite token
var liveUrl = window.resolveStreamUrl(altyn, altyn.auth, 'live');
if (liveUrl.indexOf('http://119.235.117.209:8010/AltynAsyr/video.m3u8?token=') !== 0) {
  throw new Error('live url unexpected: ' + liveUrl);
}

// Test 2: Channel without key uses plain token (when session exists)
var noKeyCh = Object.assign({}, altyn, { key: null });
var noKeyUrl = window.resolveStreamUrl(noKeyCh, noKeyCh.auth, 'live');
if (noKeyUrl !== 'http://119.235.117.209:8010/AltynAsyr/video.m3u8') {
  throw new Error('noKeyUrl unexpected: ' + noKeyUrl);
}

// Test 3: Channel without auth has no query
var noAuthCh = Object.assign({}, altyn, { auth: null });
var noAuthUrl = window.resolveStreamUrl(noAuthCh, null, 'live');
if (noAuthUrl !== 'http://119.235.117.209:8010/AltynAsyr/video.m3u8') {
  throw new Error('noAuthUrl unexpected: ' + noAuthUrl);
}

// Test 4: Absolute path is used as is
var absCh = Object.assign({}, altyn, { path: 'http://cdn.example/x/index.m3u8?a=1', auth: null });
var absUrl = window.resolveStreamUrl(absCh, null, 'live');
if (absUrl !== 'http://cdn.example/x/index.m3u8?a=1') {
  throw new Error('absUrl unexpected: ' + absUrl);
}

// Test 5: Missing scheme defaults to http and no port
var noSchemeCh = Object.assign({}, altyn, { scheme: null, port: null, auth: null });
var noSchemeUrl = window.resolveStreamUrl(noSchemeCh, null, 'live');
if (noSchemeUrl !== 'http://119.235.117.209/AltynAsyr/video.m3u8') {
  throw new Error('noSchemeUrl unexpected: ' + noSchemeUrl);
}

// Test 6: Timeshift base drops file and query
var tsCh = Object.assign({}, altyn, { timeshift_url: 'http://h:1/Ch/index.m3u8?x=1', auth: null, timeshift_auth: null });
var tsUrl = window.resolveStreamUrl(tsCh, null, 'timeshift', { behind: 5 });
if (tsUrl !== 'http://h:1/Ch/video-timeshift_rel-5.m3u8') {
  throw new Error('tsUrl unexpected: ' + tsUrl);
}

// Test 7: Archive URL format
var archUrl = window.resolveStreamUrl(tsCh, null, 'archive', { start: 1700000000 * 1000, duration: 600 * 1000 });
if (archUrl !== 'http://h:1/Ch/index-1700000000-600.m3u8') {
  throw new Error('archUrl unexpected: ' + archUrl);
}

// Test 8: PortalDate parser with Turkmenistan UTC+5
var pDate = window.parsePortalDate('2026-10-03 21:00:00');
if (!pDate || pDate.toISOString() !== '2026-10-03T16:00:00.000Z') {
  throw new Error('pDate mismatch: ' + (pDate ? pDate.toISOString() : 'null'));
}

process.exit(0);
'''
    fd, tf_path = tempfile.mkstemp(suffix='.js')
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            f.write(runner)
        p = subprocess.run([node_bin, tf_path], capture_output=True, text=True, timeout=15)
        assert p.returncode == 0, f"Node tests failed:\nSTDOUT: {p.stdout}\nSTDERR: {p.stderr}"
    finally:
        if os.path.exists(tf_path):
            os.remove(tf_path)

def test_alemtv_play_channel_navigation():
    """Verify selecting/playing a channel transitions to player screen, loads video URL, and handles return."""
    import os
    import shutil
    import subprocess
    import tempfile
    from alemtv_app import build_alemtv_js

    node_bin = shutil.which('node')
    if not node_bin:
        pytest.skip("Node.js not available in environment")

    js = build_alemtv_js()
    runner = '''
var domElements = {};
function makeElem(id) {
  return {
    id: id,
    tagName: 'DIV',
    style: {},
    className: '',
    classList: {
      add: function(c) { this[c] = true; },
      remove: function(c) { delete this[c]; },
      contains: function(c) { return !!this[c]; }
    },
    textContent: '',
    src: '',
    paused: true,
    play: function() { this.paused = false; return Promise.resolve(); },
    pause: function() { this.paused = true; },
    load: function() {},
    querySelectorAll: function() { return []; },
    appendChild: function() {},
    dataset: {}
  };
}

var window = { addEventListener: function() {} };
var document = {
  readyState: 'loading',
  addEventListener: function() {},
  getElementById: function(id) {
    if (!domElements[id]) domElements[id] = makeElem(id);
    return domElements[id];
  },
  querySelectorAll: function() { return []; },
  createElement: function(tag) {
    var el = makeElem('');
    el.tagName = tag.toUpperCase();
    return el;
  }
};
var localStorage = { getItem: function() { return null; }, setItem: function() {}, removeItem: function() {} };
''' + js + '''
var silkyList = window.getSilkyOpenChannelsList();
window.handleAuthSuccess({ channels: silkyList, session_id: 'silky_open' });

var ch = silkyList[0];
if (!ch || !ch.stream_url) {
  throw new Error('First channel missing stream_url: ' + JSON.stringify(ch));
}

// Call playChannel
window.playChannel(ch);

// Verify player screen is active and displayed
var playerScreen = document.getElementById("playerScreen");
if (playerScreen.style.display !== 'block' || playerScreen.className.indexOf('active') === -1) {
  throw new Error('playerScreen display not block or not active: ' + JSON.stringify(playerScreen));
}

// Verify main screen is hidden
var mainScreen = document.getElementById("mainScreen");
if (mainScreen.style.display !== 'none') {
  throw new Error('mainScreen display not none: ' + JSON.stringify(mainScreen));
}

// Verify videoElement loaded channel stream URL
var video = document.getElementById("videoElement");
if (video.src !== ch.stream_url) {
  throw new Error('videoElement.src expected ' + ch.stream_url + ', got ' + video.src);
}

// Verify return back to channel list
window.backToChannelList();
if (mainScreen.style.display !== 'flex' || mainScreen.className.indexOf('active') === -1) {
  throw new Error('mainScreen not restored after backToChannelList');
}
if (video.src !== '') {
  throw new Error('videoElement.src not cleared after backToChannelList: ' + video.src);
}

process.exit(0);
'''
    fd, tf_path = tempfile.mkstemp(suffix='.js')
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            f.write(runner)
        p = subprocess.run([node_bin, tf_path], capture_output=True, text=True, timeout=15)
        assert p.returncode == 0, f"Play channel navigation test failed:\nSTDOUT: {p.stdout}\nSTDERR: {p.stderr}"
    finally:
        if os.path.exists(tf_path):
            os.remove(tf_path)
