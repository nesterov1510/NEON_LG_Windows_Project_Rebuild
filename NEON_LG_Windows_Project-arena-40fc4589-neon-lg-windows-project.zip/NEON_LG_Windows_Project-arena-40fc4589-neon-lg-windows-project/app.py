"""Modern WebView2 desktop launcher."""
import webview
from core import Api, resource

if __name__ == '__main__':
    with open(resource('ui.html'), 'r', encoding='utf-8') as f:
        html = f.read()
    api = Api()
    file_dialog_enum = getattr(webview, 'FileDialog', None)
    api.open_dialog_type = getattr(file_dialog_enum, 'OPEN', None) or getattr(webview, 'OPEN_DIALOG', 10)
    window = webview.create_window(
        'NEON / LG webOS Region Console',
        html=html,
        js_api=api,
        width=1440,
        height=920,
        min_size=(940, 680),
        background_color='#060a08',
    )
    api.window = window
    try:
        webview.start(debug=False)
    finally:
        api.close()
