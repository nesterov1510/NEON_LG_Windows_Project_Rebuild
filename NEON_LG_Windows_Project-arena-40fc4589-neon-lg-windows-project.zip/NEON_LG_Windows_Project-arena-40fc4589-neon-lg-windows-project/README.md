# NEON — LG webOS + VPN Hotspot

Unofficial Windows desktop utility for `lennylxx/lg-geolock-bypass`. Includes a modern dark-glass sidebar UI, real TV command output, saved OpenVPN profile shortcuts (certificate/key and `auth-user-pass`), and direct Windows Wi-Fi Hotspot + ICS controls.

## Windows 8.1 + Windows 10/11 — Modern Desktop Installer (`app_legacy.py`)

The `app_legacy.py` edition is built with **PyQt5** specifically for **Windows 8.1**, and also runs smoothly on **Windows 10 and Windows 11** (without requiring WebView2). It includes:
- Modern dark-glass sidebar navigation with subtle animated Matrix backdrop toggle (`Matrix Backdrop`), rounded pill switches, KPI telemetry cards, syntax-colored live terminal, animated connection scanner, custom multi-size Win32 application icon, and instant **RU / EN** language switcher.
- Full LG webOS SSH control (`9922`), **webOS 26** `/media/developer/temp` toggle, automatic NVRAM backup value display on Read, and TV reboot.
- Background OpenVPN runner with **username/password (`auth-user-pass`) support** (temporary credentials wiped immediately after connect/fail/stop) and **emergency leak protection** (stops hotspot & ICS automatically if the OpenVPN tunnel drops unexpectedly).
- Dual-mode Wi-Fi Hotspot engine: uses **Windows Hosted Network (`netsh wlan`)** on Windows 8.1 / compatible drivers, and automatically falls back to **Windows Mobile Hotspot (WinRT)** on Windows 10/11 adapters that dropped Hosted Network support.
- Built-in **Diagnostics** tab checking OS/build, Administrator UAC status, OpenVPN binary, Wi-Fi hotspot capability, and live adapter ICS states.
- Full **NSIS Windows Installer** (`NEON_Setup_Win81_10_11.exe`) creating Desktop & Start Menu shortcuts, Add/Remove Programs registration, and a complete uninstaller that removes all program files, shortcuts, registry entries, and `%APPDATA%\NEON` data.

Push changes to GitHub (or open **Actions → Build Windows 8.1 / 10 / 11 Installer → Run workflow**) and download **NEON-Windows-Installer** (`NEON_Setup_Win81_10_11.exe`), or **NeonLGControl-Windows81-Portable** for the portable folder build.

The modern WebView2 edition (`app.py` + `ui.html`) is also maintained for Windows 10/11 via **Actions → Build Windows app**.

## OpenVPN integration

NEON runs `openvpn.exe` as a hidden background process and displays its live log/status in the NEON terminal; it does **not** open the OpenVPN GUI. Both certificate/key `.ovpn` profiles and `auth-user-pass` profiles are supported. Browse to `.ovpn` files; their paths are remembered in `%APPDATA%\NEON\profiles.json` and non-secret app preferences in `%APPDATA%\NEON\settings.json`. VPN and TV passwords are never saved to disk.

**One-time Windows dependency:** OpenVPN Community must be installed once to provide `openvpn.exe` and the TAP/Wintun network driver. The driver is a Windows system component that needs administrator installation.

## VPN hotspot on Windows 8.1 & Windows 10/11

1. Install OpenVPN Community once, then run NEON as administrator. In **VPN HOTSPOT**, browse to an `.ovpn` profile (if `auth-user-pass` is present, enter your VPN username/password).
2. Press **Connect VPN**. Wait for **Initialization Sequence Completed** in the live terminal before starting the hotspot.
3. Enter the hotspot SSID and password, then press **Start VPN Hotspot**. NEON automatically selects Hosted Network (Win 8.1) or Mobile Hotspot (Win 10/11), detects the connected VPN and hotspot virtual adapters, and configures ICS routing.
4. If adapter detection fails, use **Refresh Adapters**, choose the VPN/public and hotspot/private adapters manually, and click **Route VPN → Hotspot**. Always test a client's public IP/DNS to confirm VPN egress.

NEON stops the hosted network/mobile hotspot and its own ICS route on normal exit, disconnect, or unexpected tunnel exit. **This is not a guaranteed OS-level kill switch:** a system crash, forced kill, or driver/provider change can still bypass routing. Test with a non-sensitive device first.

## TV regions

The UI lists United States `22282`, CIS/SNG `3642` (requested; **not verified by upstream**), EU/KR group `19461`, and other codes. Upstream lists US `22282` as fully verified; compatibility varies by TV model/firmware. Region writes modify NVRAM and can affect features/apps. Always run **Read Current** first and proceed at your own risk.

`change_region.sh` and `UPSTREAM-LICENSE` come from upstream. NEON is independent and unaffiliated with LG or OpenVPN.
